package com.bnpp.cardif.sugar.core.tsp.basket;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.basket.BasketService;
import com.bnpp.cardif.sugar.core.api.basket.BasketValidator;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.task.TaskService;
import com.bnpp.cardif.sugar.domain.basket.test.BasketMockUtility;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class BasketValidatorTSPTest {
    private static final String SCOPE = "MyScope";

    @Mock
    BasketService service;

    @Mock
    TaskService taskService;

    @Mock
    BusinessScopeValidator scopeValidator;

    @InjectMocks
    BasketValidator validator = new BasketValidatorTSP();

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreationWithoutScope() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket = new Basket();
        validator.checkCreation(Lists.newArrayList(basket));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreationWithNonExistingScope() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket = new Basket();
        basket.setScope(SCOPE);
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00602, SCOPE)).when(scopeValidator)
                .checkExistence(SCOPE);
        validator.checkCreation(Lists.newArrayList(basket));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreationWithTwoScopes() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket = new Basket();
        basket.setScope(SCOPE);
        Basket basket1 = new Basket();
        basket1.setScope(SCOPE + "1");
        validator.checkCreation(Lists.newArrayList(basket, basket1));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreationWithoutName() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket = new Basket();
        basket.setScope(SCOPE);

        validator.checkCreation(Lists.newArrayList(basket));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreationWithExistingName() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket = new Basket();
        basket.setScope(SCOPE);
        basket.setSymbolicName("BasketTest");
        when(service.getAllUnfiltered(SCOPE)).thenReturn(Lists.newArrayList(basket));
        validator.checkCreation(Lists.newArrayList(basket));
    }

    @Test
    public void testCheckCreationOK() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket = new Basket();
        basket.setScope(SCOPE);
        basket.setSymbolicName("BasketTest");

        validator.checkCreation(Lists.newArrayList(basket));
    }

    @Test
    public void testCheckUpdateOK() throws SugarTechnicalException, SugarFunctionalException {

        Basket basket = new Basket();
        basket.setScope(SCOPE);
        basket.setSymbolicName("BasketTest");
        basket.setBasketId(new BasketId("VALUE", "ISSUER", "SCHEME"));
        when(service.get(Lists.newArrayList(basket.getBasketId()), SCOPE)).thenReturn(Lists.newArrayList(basket));
        validator.checkUpdate(Lists.newArrayList(basket));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckUpdateChangeName() throws SugarTechnicalException, SugarFunctionalException {

        Basket basket = new Basket();
        basket.setScope(SCOPE);
        basket.setSymbolicName("BasketTest");
        basket.setBasketId(new BasketId("VALUE", "ISSUER", "SCHEME"));
        Basket basket1 = new Basket();
        basket1.setScope(SCOPE);
        basket1.setSymbolicName("BasketTest1");
        basket1.setBasketId(new BasketId("VALUE", "ISSUER", "SCHEME"));
        when(service.get(Lists.newArrayList(basket.getBasketId()), SCOPE)).thenReturn(Lists.newArrayList(basket));
        validator.checkUpdate(Lists.newArrayList(basket1));
    }

    @Test
    public void testGet() throws SugarTechnicalException, SugarFunctionalException {
        validator.checkGet(SCOPE);
        Mockito.verify(scopeValidator, Mockito.times(1)).checkExistence(SCOPE);
    }

    @Test
    public void testGetAll() throws SugarTechnicalException, SugarFunctionalException {
        validator.checkGetAll(SCOPE);
        Mockito.verify(scopeValidator, Mockito.times(1)).checkExistence(SCOPE);
    }

    @Test
    public void testDeleteOK() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket = BasketMockUtility.buildClaimBasket();
        SearchResults<Task> searchResult = new SearchResults<Task>();
        List<Task> emptyResult = Lists.newArrayList();
        searchResult.setResults(emptyResult);
        when(taskService.getTasksInBasket(Mockito.anyString(), Mockito.any(BasketId.class), Mockito.anyInt(),
                Mockito.anyInt())).thenReturn(searchResult);
        when(service.get(Lists.newArrayList(basket.getBasketId()), SCOPE)).thenReturn(Lists.newArrayList(basket));
        validator.checkDelete(Lists.newArrayList(basket.getBasketId()), basket.getScope());
    }

    @Test(expected = SugarFunctionalException.class)
    public void testDeleteKO() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket = BasketMockUtility.buildClaimBasket();
        SearchResults<Task> searchResult = new SearchResults<Task>();
        List<Task> notEmptyResult = Lists.newArrayList(new Task());
        searchResult.setResults(notEmptyResult);
        when(taskService.getTasksInBasket(Mockito.anyString(), Mockito.any(BasketId.class), Mockito.anyInt(),
                Mockito.anyInt())).thenReturn(searchResult);
        when(service.get(Lists.newArrayList(basket.getBasketId()), SCOPE)).thenReturn(Lists.newArrayList(basket));
        validator.checkDelete(Lists.newArrayList(basket.getBasketId()), basket.getScope());
        Mockito.verify(scopeValidator, Mockito.times(1)).checkExistence(SCOPE);
    }

    @Test
    public void testCheckExistence() throws SugarTechnicalException, SugarFunctionalException {
        Basket basket1 = BasketMockUtility.buildClaimBasket();
        when(service.get(Mockito.anyListOf(BasketId.class), Mockito.anyString()))
                .thenReturn(Lists.newArrayList(basket1));
        validator.checkExistence(Lists.newArrayList(basket1.getBasketId(), basket1.getBasketId()), basket1.getScope());
    }
}
