package com.bnpp.cardif.sugar.core.tsp.businessscope;

import static org.mockito.Matchers.anyListOf;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpp.cardif.sugar.security.SecurityHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.SugarRoles;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class BusinessScopeValidatorTSPTest {
    private static final String SCOPE_NAME = "Test_Scope";

    private static final String USERNAME = "jakadi";

    private static final String PASSWORD = "iconnect";

    private static final String FIRSTNAME = "Jacques";

    private static final String LASTNAME = "KADI";

    private static final String AUTHORITY = SugarRoles.SUGAR_ADMIN.name();

    @Mock
    private BusinessScopeService businessScopeService;
    
    @Mock
    private SecurityHelper securityHelper;

    @InjectMocks
    private BusinessScopeValidator validator = new BusinessScopeValidatorTSP();

    @Before
    public void init() {
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(AUTHORITY));

        AuthenticatedUser user = new AuthenticatedUser(USERNAME, PASSWORD, null, FIRSTNAME, LASTNAME,
                grantedAuthorities, "test version");
        user.setBusinessScopes(Lists.newArrayList(SCOPE_NAME));
        Authentication actualAuthentication = new UsernamePasswordAuthenticationToken(user, null,
                user.getAuthorities());

        SecurityContextHolder.getContext().setAuthentication(actualAuthentication);
        securityHelper.setIsSecurityEnabled(true);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreationValidityWithSameName() throws SugarFunctionalException, SugarTechnicalException {
        BusinessScope scope = buildBusinessScope();

        BusinessScope fetchedScope = buildBusinessScope();
        when(businessScopeService.getBySymbolicName(anyListOf(String.class)))
                .thenReturn(Lists.newArrayList(fetchedScope));
        validator.checkCreationValidity(Lists.newArrayList(scope));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreationValidityWithDuplicatedNames()
            throws SugarFunctionalException, SugarTechnicalException {
        BusinessScope scope = buildBusinessScope();
        BusinessScope scope1 = buildBusinessScope();
        validator.checkCreationValidity(Lists.newArrayList(scope, scope1));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreationValidityWithEmptyName() throws SugarFunctionalException, SugarTechnicalException {
        BusinessScope scope = new BusinessScope();
        scope.setSymbolicName("");

        validator.checkCreationValidity(Lists.newArrayList(scope));
    }

    @Test
    public void testCheckCreationValidityOK() throws SugarFunctionalException, SugarTechnicalException {
        BusinessScope scope = buildBusinessScope();
        List<String> nameAsList = Lists.newArrayList(SCOPE_NAME);
        when(businessScopeService.getBySymbolicName(nameAsList)).thenReturn(new ArrayList<BusinessScope>());
        validator.checkCreationValidity(Lists.newArrayList(scope));
        verify(businessScopeService).getBySymbolicName(nameAsList);

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckExistenceKO() throws SugarTechnicalException, SugarFunctionalException {
        validator.checkExistence(SCOPE_NAME);
    }

    @Test
    public void testCheckExistenceOK() throws SugarTechnicalException, SugarFunctionalException {
        BusinessScope fetchedScope = buildBusinessScope();
        when(businessScopeService.getBySymbolicName(anyListOf(String.class)))
                .thenReturn(Lists.newArrayList(fetchedScope));
        validator.checkExistence(SCOPE_NAME);
        verify(businessScopeService).getBySymbolicName(Lists.newArrayList(SCOPE_NAME));
    }

    private BusinessScope buildBusinessScope() {
        BusinessScope fetchedScope = new BusinessScope();
        fetchedScope.setSymbolicName(SCOPE_NAME);
        return fetchedScope;
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckUpdateValidityScopeNotExist() throws SugarTechnicalException, SugarFunctionalException {
        BusinessScope scope = buildBusinessScope();
        validator.checkUpdateValidity(Lists.newArrayList(scope));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckUpdateValidityScopeChangedId() throws SugarTechnicalException, SugarFunctionalException {
        BusinessScope scope = buildBusinessScope();
        scope.setBusinessScopeId(new BusinessScopeId("VALUE", "ISSUER", "SCHEME"));

        BusinessScope mockedScope = mock(BusinessScope.class);
        when(mockedScope.getBusinessScopeId()).thenReturn(new BusinessScopeId("TOTO", "TOTO", "TOTO"));
        when(businessScopeService.getBySymbolicName(Lists.newArrayList(scope.getSymbolicName())))
                .thenReturn(Lists.newArrayList(mockedScope));
        validator.checkUpdateValidity(Lists.newArrayList(scope));
    }
}
