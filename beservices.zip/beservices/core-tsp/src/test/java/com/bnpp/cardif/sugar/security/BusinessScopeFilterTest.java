package com.bnpp.cardif.sugar.security;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.authentication.InsufficientAuthenticationException;

import com.bnppa.sesame.services.common.model.Joining;
import com.bnppa.sesame.services.standard.proxy.ArrayOfTns3NillableJoining;
import com.bnppa.sesame.services.standard.proxy.AuthorizationServicesWSP;

@RunWith(MockitoJUnitRunner.class)
public class BusinessScopeFilterTest {
    private static final String joiningType = "SCOPE";

    private static final String joiningSource = "SUGAR";

    @Mock
    private AuthorizationServicesWSP authorizationServicesWSP;

    @InjectMocks
    private SesameBusinessScopeFilter sesameBusinessScopeFilter = new SesameBusinessScopeFilter();

    @Test(expected = InsufficientAuthenticationException.class)
    public void validateBusinessScopeJoiningFailsTest() {
        AuthenticatedUser authenticatedUser = Mockito.mock(AuthenticatedUser.class);
        ArrayOfTns3NillableJoining joinings = new ArrayOfTns3NillableJoining();
        Joining joining = new Joining();
        String realScope = "Syldavia";
        joining.setInterv(realScope);
        joining.setSource(joiningSource);
        joining.setJoiningType(joiningType);
        String scopeParam = "SYLDAVIA";
        joinings.getJoining().add(joining);
        sesameBusinessScopeFilter.validateBusinessScopeJoining(authenticatedUser, joinings, scopeParam);
    }

    @Test
    public void validateBusinessScopeJoiningTest() {
        AuthenticatedUser authenticatedUser = Mockito.mock(AuthenticatedUser.class);
        ArrayOfTns3NillableJoining joinings = new ArrayOfTns3NillableJoining();
        Joining joining = new Joining();
        String realScope = "Syldavia";
        joining.setInterv(realScope);
        joining.setSource(joiningSource);
        joining.setJoiningType(joiningType);
        joinings.getJoining().add(joining);
        String scopeParam = realScope;
        sesameBusinessScopeFilter.validateBusinessScopeJoining(authenticatedUser, joinings, scopeParam);
    }

}
