package com.bnpp.cardif.sugar.core.tsp.acl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.dao.api.acl.AclDAO;
import com.bnpp.cardif.sugar.dao.api.acl.AclDAO.AclContext;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class AclServiceTSPTest {
    private static final String SCOPE = "fakeScope";

    @Mock
    private AclDAO aclDAO;

    @Mock
    private BusinessScopeService scopeService;

    @Mock
    private DocumentSecurityHelper securityHelper;

    @Mock
    private BusinessScopeValidator scopeValidator;

    @InjectMocks
    private AclServiceTSP aclService = new AclServiceTSP();

    @Before
    public void setUp() {
        aclService.init();
    }

    @Test
    public void testAssingDefault() throws Exception {
        BusinessScope scope = mockBusinessScope();
        AclId aclId = new AclId(UUID.randomUUID().toString(), "MyIssuer", "MyScheme");
        AccessControlList acl = new AccessControlList();
        acl.setAclId(aclId);

        when(aclDAO.get(aclId, scope.getSymbolicName())).thenReturn(acl);
        when(aclDAO.searchAcl(scope.getBusinessScopeId(), scope.getSymbolicName(), AclContext.BUSINESSSCOPE))
                .thenReturn(aclId);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "MyIssuer", 1);
        aclService.assignDefault(scope.getSymbolicName(), classId);

        verify(aclDAO).assign(aclId, classId, AclContext.CLASS, scope.getSymbolicName());
    }

    @Test(expected = SugarTechnicalException.class)
    public void testGetFails() throws SugarTechnicalException, SugarFunctionalException {
        aclService.get("any", mock(AclId.class));
    }

    private BusinessScope mockBusinessScope() throws SugarTechnicalException, SugarFunctionalException {
        BusinessScope scope = new BusinessScope();
        scope.setBusinessScopeId(new BusinessScopeId(UUID.randomUUID().toString(), "issuer", "scheme"));
        scope.setSymbolicName(SCOPE);
        when(scopeService.getBySymbolicName(Lists.newArrayList(scope.getSymbolicName())))
                .thenReturn(Lists.newArrayList(scope));
        return scope;
    }

    @Test
    public void testGetByBasketId() throws Exception {
        BasketId id = new BasketId(UUID.randomUUID().toString(), "MyIsuseir", "MyScheme");
        AclId aclId = new AclId(UUID.randomUUID().toString(), "MyIsuseir", "MyScheme");
        AccessControlList acl = new AccessControlList();
        acl.setAclId(aclId);
        acl.setScope(SCOPE);

        when(aclDAO.searchAcl(id, SCOPE)).thenReturn(aclId);
        when(aclDAO.get(aclId, SCOPE)).thenReturn(acl);

        aclService.getByBasketId(SCOPE, id);

        verify(aclDAO, times(1)).searchAcl(id, SCOPE);
        verify(aclDAO, times(1)).get(aclId, SCOPE);
    }

    @Test
    public void testGetByClassId() throws Exception {
        ClassId id = new ClassId(UUID.randomUUID().toString(), "MyIsuseir", 1);
        AclId aclId = new AclId(UUID.randomUUID().toString(), "MyIsuseir", "MyScheme");
        AccessControlList acl = new AccessControlList();
        acl.setAclId(aclId);
        acl.setScope(SCOPE);
        when(aclDAO.searchAcl(id, AclContext.INSTANCE, SCOPE)).thenReturn(aclId);
        when(aclDAO.get(aclId, SCOPE)).thenReturn(acl);

        aclService.getByClassId(SCOPE, id, true);

        verify(aclDAO, times(1)).searchAcl(id, AclContext.INSTANCE, SCOPE);
        verify(aclDAO, times(1)).get(aclId, SCOPE);
    }

    @Test
    public void testAssignToBasket() throws Exception {
        AclId aclId = new AclId(UUID.randomUUID().toString(), "MyIsuseir", "MyScheme");
        BasketId id = new BasketId(UUID.randomUUID().toString(), "MyIsuseir", "MyScheme");
        when(aclDAO.searchAcl(id, SCOPE)).thenReturn(aclId);
        AccessControlList aclMock = mock(AccessControlList.class);
        when(aclDAO.get(aclId, SCOPE)).thenReturn(aclMock);
        when(aclMock.getScope()).thenReturn(SCOPE);
        when(aclMock.getAclId()).thenReturn(aclId);

        assertEquals(aclMock, aclService.getByBasketId(SCOPE, id));
        aclService.assignToBasket(SCOPE, aclId, id);
        verify(aclDAO, times(1)).assign(aclId, id, SCOPE);
        verify(aclDAO, times(1)).remove(id, SCOPE);
    }

    @Test
    public void testAssignToClass() throws Exception {
        AclId aclId = new AclId(UUID.randomUUID().toString(), "MyIsuseir", "MyScheme");
        ClassId id = new ClassId(UUID.randomUUID().toString(), "MyIsuseir", 1);
        when(aclDAO.searchAcl(id, AclContext.INSTANCE, SCOPE)).thenReturn(aclId);
        AccessControlList aclMock = mock(AccessControlList.class);
        when(aclDAO.get(aclId, SCOPE)).thenReturn(aclMock);
        when(aclMock.getScope()).thenReturn(SCOPE);
        when(aclMock.getAclId()).thenReturn(aclId);
        assertEquals(aclMock, aclService.getByClassId(SCOPE, id, true));
        aclService.assignToClass(SCOPE, aclId, id, true);

        verify(aclDAO, times(1)).assign(aclId, id, AclContext.INSTANCE, SCOPE);
        verify(aclDAO, times(1)).remove(SCOPE, id, AclContext.INSTANCE);
    }

    @Test
    public void testGetByScope() throws Exception {
        BusinessScope scope = mockBusinessScope();

        AccessControlList acl = new AccessControlList();
        acl.setAclId(new AclId(UUID.randomUUID().toString(), "MyIsuseir", "MyScheme"));
        acl.setScope(SCOPE);

        when(aclDAO.searchAcl(scope.getBusinessScopeId(), SCOPE, AclContext.BUSINESSSCOPE)).thenReturn(acl.getAclId());
        when(aclDAO.get(acl.getAclId(), SCOPE)).thenReturn(acl);

        assertEquals(acl, aclService.getByScope(SCOPE));
        verify(aclDAO).get(acl.getAclId(), SCOPE);
    }

    @Test
    public void testGetDefault() throws Exception {
        BusinessScope scope = mockBusinessScope();

        AccessControlList acl = new AccessControlList();
        acl.setAclId(new AclId(UUID.randomUUID().toString(), "MyIsuseir", "MyScheme"));
        acl.setScope(SCOPE);

        when(aclDAO.searchAcl(scope.getBusinessScopeId(), SCOPE, AclContext.DEFAULT)).thenReturn(acl.getAclId());
        when(aclDAO.get(acl.getAclId(), SCOPE)).thenReturn(acl);

        assertEquals(acl, aclService.getDefault(SCOPE));
        verify(aclDAO).get(acl.getAclId(), SCOPE);
    }
}
