package com.bnpp.cardif.sugar.security;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;

public class UserService {

    @Autowired
    private DocumentSecurityHelper documentSecurityHelper;

    @PreAuthorize("hasRole('admin')")
    public Collection<? extends GrantedAuthority> getAuthorities(UserDetails userDetails) {
        return userDetails.getAuthorities();
    }

    @PreAuthorize("hasPermission(#document, T(org.springframework.security.acls.domain.BasePermission).READ)")
    public String getDocument(Document document) {
        return "Document has been returned";
    }

    // @PreAuthorize("hasPermission(#document.getData().getClazz(),
    // T(org.springframework.security.acls.domain.BasePermission).CREATE)")
    public String createDocument(Document document) throws SugarFunctionalException {
        documentSecurityHelper.checkStoreValidity(document);
        return "Document has been returned";
    }

    public void createDocuments(List<Document> documents) throws SugarFunctionalException {
        for (Document doc : documents) {
            documentSecurityHelper.checkStoreValidity(doc);
        }
    }

    public DocumentSecurityHelper getDocumentSecurityHelper() {
        return documentSecurityHelper;
    }

    public void setDocumentSecurityHelper(DocumentSecurityHelper documentSecurityHelper) {
        this.documentSecurityHelper = documentSecurityHelper;
    }

}
