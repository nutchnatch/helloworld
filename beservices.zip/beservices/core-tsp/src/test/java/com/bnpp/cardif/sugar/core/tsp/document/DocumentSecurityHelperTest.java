package com.bnpp.cardif.sugar.core.tsp.document;

import static org.mockito.Mockito.spy;

import org.junit.Before;
import org.junit.Test;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;

public class DocumentSecurityHelperTest {
    private DocumentSecurityHelper helper;

    @Before
    public void setUp() throws Exception {
        helper = spy(new DocumentSecurityHelper());
    }

    @Test(expected = SugarFunctionalException.class)
    public void testStoreDocumentWithNoData() throws Exception {
        Document document = DocumentMockUtil.buildMedicalReportWithoutId();
        document.setData(null);
        helper.checkStoreValidity(document);
    }

}
