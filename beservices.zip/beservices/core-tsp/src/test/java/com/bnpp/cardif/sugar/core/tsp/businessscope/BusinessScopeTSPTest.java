package com.bnpp.cardif.sugar.core.tsp.businessscope;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.businessscope.BusinessScopeDAO;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class BusinessScopeTSPTest {

    @Mock
    private BusinessScopeDAO businessScopeDAO;

    @Mock
    private IdFactory businessScopeIdFactory;

    @Mock
    private SugarEventBus eventBus;

    @Mock
    private BusinessScopeValidator validator;

    @InjectMocks
    private BusinessScopeTSP businessScopeTSP;

    @Before
    public void setUp() {
        businessScopeTSP.init();
    }

    @Test
    public void testStore() throws SugarTechnicalException, SugarFunctionalException {
        String idValue = "IdValue";
        String idIssuer = "IdIssuer";
        String idScheme = "IdScheme";
        Mockito.when(businessScopeIdFactory.generateBusinessScopeId())
                .thenReturn(new BusinessScopeId(idValue, idIssuer, idScheme));

        BusinessScope scope = new BusinessScope();
        businessScopeTSP.store(Lists.newArrayList(scope));
        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(businessScopeDAO).store(storeCaptor.capture());
        List<BusinessScope> storedScopes = storeCaptor.getValue();

        assertEquals(1, storedScopes.size());
        BusinessScope storedScope = storedScopes.get(0);
        assertEquals(idValue, storedScope.getBusinessScopeId().getValue());
        assertEquals(idScheme, storedScope.getBusinessScopeId().getScheme());
        assertEquals(idIssuer, storedScope.getBusinessScopeId().getIssuer());
        assertNotNull(storedScope.getCreationDate());
        assertNotNull(storedScope.getUpdateDate());
    }

}
