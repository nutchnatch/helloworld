package com.bnpp.cardif.sugar.core.tsp.task;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.basket.BasketValidator;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.document.DocumentValidator;
import com.bnpp.cardif.sugar.core.api.task.TaskService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.task.test.TaskMockUtility;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TaskStatus;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class TaskValidatorTest {
    @Mock
    private BasketValidator basketValidator;

    @Mock
    private DocumentValidator documentValidator;

    @Mock
    private BusinessScopeValidator businessScopeValidator;

    @Mock
    private TaskService taskService;

    @InjectMocks
    TaskValidatorTSP taskValidator = new TaskValidatorTSP();

    @Test
    public void testThereAreDifferentScopes() {
        assertFalse(taskValidator.thereAreDifferentScopes(Lists.newArrayList("Syldavia", "Syldavia", "Syldavia")));
        assertTrue(taskValidator.thereAreDifferentScopes(Lists.newArrayList("Gopal", "Syldavia", "Syldavia")));
    }

    @Test
    public void testValidateCreation() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        taskValidator.validateCreation(Lists.newArrayList(task));
        Mockito.verify(basketValidator, Mockito.times(1)).checkExistence(anyListOf(BasketId.class), anyString());
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyListOf(String.class));
        Mockito.verify(documentValidator, Mockito.times(1)).checkExistence(anyString(), anyListOf(Id.class));
    }

    @Test
    public void testValidateUpdateStatus() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Mockito.when(taskService.get(anyString(), anyListOf(TaskId.class))).thenReturn(Lists.newArrayList(task));
        taskValidator.validateUpdateStatus(task.getScope(), Lists.newArrayList(task.getTaskId()),
                TaskStatus.PENDING.toString());
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyString());
    }

    @Test(expected = SugarFunctionalException.class)
    public void testValidateUpdateStatusNonExistingTask() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Task task2 = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Mockito.when(taskService.get(anyString(), anyListOf(TaskId.class))).thenReturn(Lists.newArrayList(task));
        taskValidator.validateUpdateStatus(task.getScope(), Lists.newArrayList(task.getTaskId(), task2.getTaskId()),
                TaskStatus.PENDING.toString());
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyString());
    }

    @Test(expected = SugarFunctionalException.class)
    public void testValidateUpdateStatusNonExistingStatus() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Mockito.when(taskService.get(anyString(), anyListOf(TaskId.class))).thenReturn(Lists.newArrayList(task));
        taskValidator.validateUpdateStatus(task.getScope(), Lists.newArrayList(task.getTaskId()), "NonExistingStatus");
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyString());
    }

    @Test(expected = SugarFunctionalException.class)
    public void testValidateLockNonExistingTask() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Task task2 = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Mockito.when(taskService.get(anyString(), anyListOf(TaskId.class))).thenReturn(Lists.newArrayList(task));
        taskValidator.validateLock(task.getScope(), Lists.newArrayList(task.getTaskId(), task2.getTaskId()));
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyString());
    }

    @Test(expected = SugarFunctionalException.class)
    public void testValidateLockAlreadyLock() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        task.setLockerName("LOCKER");
        Mockito.when(taskService.get(anyString(), anyListOf(TaskId.class))).thenReturn(Lists.newArrayList(task));
        taskValidator.validateLock(task.getScope(), Lists.newArrayList(task.getTaskId()));
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyString());
    }

    @Test
    public void testValidateGetTaskInBasket() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Mockito.when(taskService.get(anyString(), anyListOf(TaskId.class))).thenReturn(Lists.newArrayList(task));
        taskValidator.validateGetTaskInBasket(task.getScope(), Mockito.mock(BasketId.class));
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyString());
        Mockito.verify(basketValidator, Mockito.times(1)).checkExistence(Mockito.anyListOf(BasketId.class),
                anyString());
    }

    @Test
    public void testValidateGetTaskForDocument() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Mockito.when(taskService.get(anyString(), anyListOf(TaskId.class))).thenReturn(Lists.newArrayList(task));
        taskValidator.validateGetTaskInBasket(task.getScope(), Mockito.mock(BasketId.class));
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyString());
        Mockito.verify(basketValidator, Mockito.times(1)).checkExistence(Mockito.anyListOf(BasketId.class),
                anyString());
    }

    @Test
    public void testValidateGet() throws SugarTechnicalException, SugarFunctionalException {
        Task task = TaskMockUtility.generateBlankTask(DocumentMockUtil.buildClaimDocument());
        Mockito.when(taskService.get(anyString(), anyListOf(TaskId.class))).thenReturn(Lists.newArrayList(task));
        taskValidator.validateGet(task.getScope(), Lists.newArrayList(task.getTaskId()));
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(anyString());
    }
}
