package com.bnpp.cardif.sugar.core.tsp.tagclass;

import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagValueType;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class TagClassValidatorTSPTest {
    private static final String SCOPE = "Syldavia";

    @Mock
    TagclassService tagclassService;

    @Mock
    BusinessScopeValidator businessScopeValidator;

    @InjectMocks
    TagClassValidator tagClassValidator = new TagClassValidatorTSP();

    @Before
    public void setUp() throws Exception {

    }

    @Test(expected = SugarFunctionalException.class)
    public void testEmptySymbolicName() throws SugarFunctionalException, SugarTechnicalException {
        TagClass testTag = new TagClass();
        testTag.setSymbolicName("");
        testTag.setScope(SCOPE);
        tagClassValidator.checkCreationValidity(Lists.newArrayList(testTag));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testExistingSymbolicName() throws SugarFunctionalException, SugarTechnicalException {
        TagClass tagToStore = new TagClass();
        tagToStore.setSymbolicName("claim");
        tagToStore.setScope(SCOPE);

        TagClass fetchedTag = new TagClass();
        fetchedTag.setSymbolicName("claim");
        fetchedTag.setScope(SCOPE);

        when(tagclassService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(fetchedTag));
        tagClassValidator.checkCreationValidity(Lists.newArrayList(tagToStore));

    }

    @Test
    public void testStoreOK() throws SugarFunctionalException, SugarTechnicalException {
        TagClass tagToStore = new TagClass();
        tagToStore.setSymbolicName("claim");
        tagToStore.setScope(SCOPE);

        tagToStore.setTagType(TagValueType.STRING);
        tagClassValidator.checkCreationValidity(Lists.newArrayList(tagToStore));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testUpdateCheckNameChanged() throws SugarFunctionalException, SugarTechnicalException {
        TagClass tagToStore = new TagClass();
        tagToStore.setSymbolicName("claim1");
        tagToStore.setScope(SCOPE);
        tagToStore.setClassId(new ClassId("value1", "issuer", 0));
        TagClass fetchedTag = new TagClass();
        fetchedTag.setSymbolicName("claim");
        fetchedTag.setScope(SCOPE);
        fetchedTag.setClassId(new ClassId("value1", "issuer", 0));
        when(tagclassService.get(anyString(), anyListOf(ClassId.class))).thenReturn(Lists.newArrayList(fetchedTag));
        tagClassValidator.checkUpdateValidity(Lists.newArrayList(tagToStore));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testUpdateCheckIdChanged() throws SugarFunctionalException, SugarTechnicalException {
        TagClass tagToStore = new TagClass();
        tagToStore.setSymbolicName("claim");
        tagToStore.setScope(SCOPE);
        tagToStore.setClassId(new ClassId("value1", "issuer", 0));
        TagClass fetchedTag = new TagClass();
        fetchedTag.setSymbolicName("claim");
        fetchedTag.setScope(SCOPE);
        fetchedTag.setClassId(new ClassId("value2", "issuer", 0));
        when(tagclassService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(fetchedTag));
        tagClassValidator.checkUpdateValidity(Lists.newArrayList(tagToStore));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckUpdateNonExisting() throws SugarFunctionalException, SugarTechnicalException {
        TagClass tagToStore = new TagClass();
        tagToStore.setSymbolicName("claim1");
        tagToStore.setScope(SCOPE);

        when(tagclassService.get(anyString(), anyListOf(ClassId.class))).thenReturn(new ArrayList<TagClass>());
        tagClassValidator.checkUpdateValidity(Lists.newArrayList(tagToStore));
    }

    @Test
    public void testCheckGetAll() throws SugarTechnicalException, SugarFunctionalException {
        tagClassValidator.checkGetAllValidity(SCOPE);
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(SCOPE);
    }

    @Test
    public void testCheckGetBySymbolicName() throws SugarTechnicalException, SugarFunctionalException {
        tagClassValidator.checkGetBySymbolicNameValidity(SCOPE);
        Mockito.verify(businessScopeValidator, Mockito.times(1)).checkExistence(SCOPE);
    }

}
