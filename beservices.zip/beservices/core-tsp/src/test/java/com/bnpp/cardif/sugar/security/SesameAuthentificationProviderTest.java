package com.bnpp.cardif.sugar.security;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/sugar-security-test.xml" })
@Ignore
public class SesameAuthentificationProviderTest {
    private static final String NONEXISTING_USERNAME_PASSWORD = "WRONG";

    private static final String EXISTING_USERNAME = "jakadi";

    private static final String EXISTING_PASSWORD = "iconnect";

    @Autowired
    AuthenticationProvider authenticationProvider;

    @Test
    public void testAuthenticate_successfully() {
        Authentication authentication = new UsernamePasswordAuthenticationToken(EXISTING_USERNAME, EXISTING_PASSWORD);
        Authentication actualAuthentication = authenticationProvider.authenticate(authentication);
        assertNotNull(actualAuthentication);
        assertNotNull(actualAuthentication.getAuthorities());
        assertEquals(2, actualAuthentication.getAuthorities().size());
        assertTrue(actualAuthentication.isAuthenticated());
    }

    @Test(expected = BadCredentialsException.class)
    public void authenticate_fails_on_wrong_credentials() throws Exception {
        Authentication authentication = new UsernamePasswordAuthenticationToken(NONEXISTING_USERNAME_PASSWORD,
                NONEXISTING_USERNAME_PASSWORD);
        authenticationProvider.authenticate(authentication);
    }

    @Test(expected = BadCredentialsException.class)
    public void authenticate_fails_on_empty_username() throws Exception {
        Authentication authentication = new UsernamePasswordAuthenticationToken("", NONEXISTING_USERNAME_PASSWORD);
        authenticationProvider.authenticate(authentication);
    }

    @Test(expected = BadCredentialsException.class)
    public void authenticate_fails_on_empty_password() throws Exception {
        Authentication authentication = new UsernamePasswordAuthenticationToken(NONEXISTING_USERNAME_PASSWORD, "");
        authenticationProvider.authenticate(authentication);
    }

    @Test(expected = BadCredentialsException.class)
    public void authenticate_fails_on_null_username() throws Exception {
        Authentication authentication = new UsernamePasswordAuthenticationToken(null, NONEXISTING_USERNAME_PASSWORD);
        authenticationProvider.authenticate(authentication);
    }

    @Test(expected = BadCredentialsException.class)
    public void authenticate_fails_on_null_password() throws Exception {
        Authentication authentication = new UsernamePasswordAuthenticationToken(NONEXISTING_USERNAME_PASSWORD, null);
        authenticationProvider.authenticate(authentication);
    }

    @Test(expected = BadCredentialsException.class)
    public void authenticate_fails_WrongPassword_only() throws Exception {
        Authentication authentication = new UsernamePasswordAuthenticationToken(EXISTING_USERNAME,
                NONEXISTING_USERNAME_PASSWORD);
        authenticationProvider.authenticate(authentication);
    }
}
