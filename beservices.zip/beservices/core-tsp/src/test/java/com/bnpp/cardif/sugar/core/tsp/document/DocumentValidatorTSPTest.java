package com.bnpp.cardif.sugar.core.tsp.document;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.api.document.DocumentValidator;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ChildObject;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ParentId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.MCODocumentClassType.AllowedChildren;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOAllowedValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagValueType;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class DocumentValidatorTSPTest {
    private static final String DEFAULT_SCOPE = "Syldavia";

    private static final int MaxSearchNumber = 10;

    @Mock
    BusinessScopeValidator businessScopeValidator;

    @Mock
    DocumentClassValidator documentClassValidator;

    @Mock
    DocumentClassService documentClassService;

    @Mock
    DocumentService documentService;

    @Mock
    TagClassValidator tagClassValidator;

    @Mock
    TagclassService tagClassService;

    @InjectMocks
    DocumentValidator validator = new DocumentValidatorTSP();

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreValidityWithEmptyList() throws SugarFunctionalException, SugarTechnicalException {
        ArrayList<Document> newArrayList = Lists.newArrayList();
        validator.checkStoreValidity(newArrayList);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithoutData() throws SugarFunctionalException, SugarTechnicalException {
        Document document = new Document();
        document.setScope(DEFAULT_SCOPE);
        validator.checkStoreValidity(Lists.newArrayList(document));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreMultiScope() throws SugarFunctionalException, SugarTechnicalException {
        Document document = new Document();
        document.setScope(DEFAULT_SCOPE);
        document.setData(new ElectronicDocumentDataType());
        Document document1 = new Document();
        document1.setScope("Gopal");
        document1.setData(new ElectronicDocumentDataType());

        validator.checkStoreValidity(Lists.newArrayList(document, document1));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithoutCategory() throws SugarFunctionalException, SugarTechnicalException {
        Document document = new Document();
        document.setScope(DEFAULT_SCOPE);
        document.setData(new ElectronicDocumentDataType());
        document.getData().setClassId(new ClassId("Value", "Issuer", 0));
        DocumentClass clazz = DocumentMockUtil.buildFakeDocumentClass();
        clazz.setCategory(Category.ENVELOPE);
        clazz.setFirstLevel(true);
        clazz.setActive(true);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class))).thenReturn(Lists.newArrayList(clazz));
        validator.checkStoreValidity(Lists.newArrayList(document));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithWrongCategory() throws SugarFunctionalException, SugarTechnicalException {
        Document document = new Document();
        document.setScope(DEFAULT_SCOPE);
        document.setData(new ElectronicDocumentDataType());
        document.getData().setClassId(new ClassId("Value", "Issuer", 0));
        document.setCategory(Category.DOCUMENT);
        DocumentClass clazz = DocumentMockUtil.buildFakeDocumentClass();
        clazz.setCategory(Category.ENVELOPE);
        clazz.setFirstLevel(true);
        clazz.setActive(true);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class))).thenReturn(Lists.newArrayList(clazz));
        validator.checkStoreValidity(Lists.newArrayList(document));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithoutURI() throws SugarFunctionalException, SugarTechnicalException {
        Document document = new Document();
        document.setScope(DEFAULT_SCOPE);
        document.setData(new ElectronicDocumentDataType());
        document.getData().setClassId(new ClassId("Value", "Issuer", 0));
        document.setCategory(Category.DOCUMENT);
        DocumentClass clazz = DocumentMockUtil.buildFakeDocumentClass();
        clazz.setCategory(Category.DOCUMENT);
        clazz.setFirstLevel(true);
        clazz.setActive(true);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class))).thenReturn(Lists.newArrayList(clazz));
        validator.checkStoreValidity(Lists.newArrayList(document));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreEnvAndDocWithoutURI() throws SugarFunctionalException, SugarTechnicalException {
        Document envelope = createEnvelopeAndDocument();
        Document document = envelope.getChildObject().getDocument().get(0);
        document.setFileData(new FileData(null, null));
        validator.checkStoreValidity(Lists.newArrayList(envelope));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreEnvAndDocWithEmptyURI() throws SugarFunctionalException, SugarTechnicalException {
        Document envelope = createEnvelopeAndDocument();
        Document document = envelope.getChildObject().getDocument().get(0);
        document.setFileData(new FileData(null, Lists.newArrayList("")));
        validator.checkStoreValidity(Lists.newArrayList(envelope));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreEnvAndDocumentWithDocumentFile()
            throws SugarFunctionalException, SugarTechnicalException {
        Document envelope = createEnvelopeAndDocument();
        Document document = envelope.getChildObject().getDocument().get(0);
        document.setFileData(new FileData(Lists.newArrayList(new DocumentFile()), Lists.newArrayList("URI")));
        validator.checkStoreValidity(Lists.newArrayList(envelope));
    }

    private Document createEnvelopeAndDocument() throws SugarTechnicalException, SugarFunctionalException {
        String scope = DEFAULT_SCOPE;
        Document envelope = new Document();
        envelope.setScope(scope);
        envelope.setData(new ElectronicDocumentDataType());
        envelope.getData().setClassId(new ClassId("EnvIdValue", "Issuer", 0));
        envelope.setId(new Id("envId", "issuer", "scheme"));
        envelope.setCategory(Category.ENVELOPE);
        DocumentClass envClazz = DocumentMockUtil.buildFakeDocumentClass();
        envClazz.setCategory(Category.ENVELOPE);
        envClazz.setFirstLevel(true);
        envClazz.setActive(true);
        when(documentClassService.get(scope, Lists.newArrayList(envelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(envClazz));
        Document document = new Document();
        document.setScope(scope);
        document.setData(new ElectronicDocumentDataType());
        document.getData().setClassId(new ClassId("DocIdValue", "Issuer", 0));
        document.setCategory(Category.DOCUMENT);
        DocumentClass clazz = DocumentMockUtil.buildFakeDocumentClass();
        document.setParentId(envelope.getParentId());

        clazz.setCategory(Category.DOCUMENT);
        clazz.setFirstLevel(false);
        clazz.setActive(true);
        envelope.setChildObject(new ChildObject(Lists.newArrayList(document), null));
        when(documentClassService.get(scope, Lists.newArrayList(document.getData().getClassId())))
                .thenReturn(Lists.newArrayList(clazz));
        return envelope;
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreChildWithoutClass() throws SugarFunctionalException, SugarTechnicalException {

        Document document = new Document();
        document.setScope(DEFAULT_SCOPE);
        document.setData(new ElectronicDocumentDataType());

        validator.checkStoreValidity(Lists.newArrayList(document));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithNonExistingClass() throws SugarTechnicalException, SugarFunctionalException {
        Document document = new Document();
        document.setScope(DEFAULT_SCOPE);
        document.setData(new ElectronicDocumentDataType());
        document.getData().setClassId(new ClassId("Value", "Issuer", 0));
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00206, document.getData().getClassId()))
                .when(documentClassValidator).checkExistence(anyListOf(ClassId.class), anyString());
        validator.checkStoreValidity(Lists.newArrayList(document));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithDisabledClass() throws SugarTechnicalException, SugarFunctionalException {
        Document document = new Document();
        document.setScope(DEFAULT_SCOPE);
        document.setData(new ElectronicDocumentDataType());
        document.getData().setClassId(new ClassId("Value", "Issuer", 0));
        DocumentClass clazz = DocumentMockUtil.buildFakeDocumentClass();
        clazz.setCategory(Category.ENVELOPE);
        clazz.setFirstLevel(true);
        clazz.setActive(false);

        when(documentClassService.get(anyString(), anyListOf(ClassId.class))).thenReturn(Lists.newArrayList(clazz));
        validator.checkStoreValidity(Lists.newArrayList(document));
    }

    @Test
    public void testCheckChildReferedById() throws SugarFunctionalException, SugarTechnicalException {
        Document envelope = DocumentMockUtil.buildEnvelope();

        Document mockedChild = DocumentMockUtil.buildClaimDocument();
        System.out.println("Envelope id " + envelope.getId().getValue());
        System.out.println("Document id " + mockedChild.getId().getValue());
        DocumentClass firstLevelClazz = DocumentMockUtil.buildFakeDocumentClass();
        firstLevelClazz.setFirstLevel(true);
        envelope.getChildObject().getId().add(mockedChild.getId());
        when(documentClassService.get(envelope.getScope(), Lists.newArrayList(envelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(firstLevelClazz));
        validator.checkStoreValidity(Lists.newArrayList(envelope));
        verify(documentService, Mockito.times(1)).get(mockedChild.getScope(), Lists.newArrayList(mockedChild.getId()),
                true, false);

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreTwoEnvelopesFirstLevel() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));

        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.isActive()).thenReturn(true);
        Document envelope = DocumentMockUtil.buildEnvelope();
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document childEnvelope = DocumentMockUtil.buildEnvelope();
        envelope.getChildObject().getDocument().add(childEnvelope);
        validator.checkStoreValidity(Lists.newArrayList(envelope));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithoutFirstLevel() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(false);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.isActive()).thenReturn(true);
        Document envelope = DocumentMockUtil.buildEnvelope();
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document childEnvelope = DocumentMockUtil.buildEnvelope();
        envelope.getChildObject().getDocument().add(childEnvelope);
        validator.checkStoreValidity(Lists.newArrayList(envelope));
    }

    @Test
    public void testComputeDocumentValidityCodeValidData() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        validator.computeValidityCode(document, (Lists.<Document> newArrayList()));
        assertEquals(ValdtyCode.VALID, document.getData().getValidityCode());

    }

    @Test
    public void testComputeDocumentValidityCodeLogicalEnvelope()
            throws SugarTechnicalException, SugarFunctionalException {
        Document logicalEnvelope = DocumentMockUtil.buildEnvelope();
        Document firstLevelEnvelope = DocumentMockUtil.buildEnvelope();
        Document document1 = DocumentMockUtil.buildClaimDocument();

        attacheChildToEnvelope(firstLevelEnvelope, logicalEnvelope);
        attacheChildToEnvelope(logicalEnvelope, document1);

        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        ArrayList<Document> flatDocuments = Lists.newArrayList(firstLevelEnvelope, logicalEnvelope, document1);
        validator.computeValidityCode(firstLevelEnvelope, flatDocuments);
        assertEquals(ValdtyCode.VALID, firstLevelEnvelope.getData().getValidityCode());
    }

    @Test
    public void testComputeDocumentValidityCodeValidDataWithChildrenValidData()
            throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = DocumentMockUtil.buildEnvelope();
        envelope.getData().setConfdntltyLvl("");
        envelope.getData().setDirectionCode("");
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document document = DocumentMockUtil.buildClaimDocument();
        attacheChildToEnvelope(envelope, document);
        Document document2 = DocumentMockUtil.buildClaimDocument();
        attacheChildToEnvelope(envelope, document2);
        when(documentService.get(document.getScope(), Lists.newArrayList(document.getId(), document2.getId()), true,
                false)).thenReturn(Lists.newArrayList(document, document2));
        List<Document> children = Lists.newArrayList(document2);

        validator.computeValidityCode(envelope, children);
        assertEquals(ValdtyCode.VALID, envelope.getData().getValidityCode());

    }

    @Test
    public void testComputeDocumentValidityCodeWithChildrenInvalidData()
            throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = DocumentMockUtil.buildEnvelope();
        envelope.getData().setConfdntltyLvl("");
        envelope.getData().setDirectionCode("");
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document document = DocumentMockUtil.buildClaimDocument();
        attacheChildToEnvelope(envelope, document);
        Document document2 = DocumentMockUtil.buildClaimDocument();
        document2.getData().setName(null);
        attacheChildToEnvelope(envelope, document2);
        when(documentService.get(document.getScope(), Lists.newArrayList(document.getId(), document2.getId()), true,
                false)).thenReturn(Lists.newArrayList(document, document2));
        List<Document> children = Lists.newArrayList(document2);

        validator.computeValidityCode(envelope, children);
        assertEquals(ValdtyCode.INVALID, envelope.getData().getValidityCode());

    }

    @Test
    public void testComputeDocumentValidityCodeInvalidData() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        document.getData().setName(null);

        validator.computeValidityCode(document, (Lists.<Document> newArrayList()));
        assertEquals(ValdtyCode.INVALID, document.getData().getValidityCode());

    }

    @Test
    public void testComputeDocumentValidityCodeValidTag() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.getTagReference())
                .thenReturn(Lists.newArrayList(new MCOTagReference("SubscriberName", true, false)));
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        TagClass tag = new TagClass();
        tag.setSymbolicName("SubscriberName");
        when(tagClassService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(tag));
        validator.computeValidityCode(document, (Lists.<Document> newArrayList()));
        assertEquals(ValdtyCode.VALID, document.getData().getValidityCode());

    }

    @Test
    public void testComputeDocumentValidityCodeWithChildrenEnvelopeUnderCreation()
            throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = DocumentMockUtil.buildEnvelope();
        envelope.getData().setConfdntltyLvl("");
        envelope.getData().setDirectionCode("");
        envelope.getData().setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document document = DocumentMockUtil.buildClaimDocument();
        document.getData().setValidityCode(ValdtyCode.INVALID);
        attacheChildToEnvelope(envelope, document);
        Document document2 = DocumentMockUtil.buildClaimDocument();
        document2.getData().setName(null);

        attacheChildToEnvelope(envelope, document2);
        when(documentService.get(document.getScope(), Lists.newArrayList(document.getId()), true, false))
                .thenReturn(Lists.newArrayList(document));
        List<Document> children = Lists.newArrayList(document2);

        validator.computeValidityCode(envelope, children);
        assertEquals(ValdtyCode.UNDER_CONSTRUCTION, envelope.getData().getValidityCode());
        assertEquals(ValdtyCode.UNDER_CONSTRUCTION, document.getData().getValidityCode());
        assertEquals(ValdtyCode.UNDER_CONSTRUCTION, document2.getData().getValidityCode());
    }

    @Test
    public void testComputeDocumentValidityCodeInvalidTag() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.getTagReference())
                .thenReturn(Lists.newArrayList(new MCOTagReference("Unknown", true, false)));
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        TagClass tag = new TagClass();
        tag.setSymbolicName("Unknown");
        when(tagClassService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(tag));
        validator.computeValidityCode(document, Lists.<Document> newArrayList());
        assertEquals(ValdtyCode.INVALID, document.getData().getValidityCode());
    }

    @Test
    public void testComputeDocumentValidityCodeInvalidTagPattern()
            throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.getTagReference())
                .thenReturn(Lists.newArrayList(new MCOTagReference("SubscriberName", true, false)));
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        TagClass tag = new TagClass();
        tag.setSymbolicName("SubscriberName");
        tag.setPattern("[a-z]");
        tag.setTagType(TagValueType.STRING);
        when(tagClassService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(tag));
        validator.computeValidityCode(document, Lists.<Document> newArrayList());
        assertEquals(ValdtyCode.INVALID, document.getData().getValidityCode());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testComputeDocumentTagValueNotAllowed() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.getTagReference())
                .thenReturn(Lists.newArrayList(new MCOTagReference("SubscriberName", true, false)));
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        TagClass tag = new TagClass();
        tag.setSymbolicName("SubscriberName");
        tag.setTagType(TagValueType.CHOICELIST);
        tag.getAllowedValue().add(new MCOAllowedValue(null, "unknown1"));
        when(tagClassService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(tag));
        validator.computeValidityCode(document, Lists.<Document> newArrayList());
        assertEquals(ValdtyCode.INVALID, document.getData().getValidityCode());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testComputeDocumentValidityCodeUnvalidKO() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        document.getData().setValidityCode(ValdtyCode.VALID);
        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.getTagReference())
                .thenReturn(Lists.newArrayList(new MCOTagReference("SubscriberName", true, false)));
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        TagClass tag = new TagClass();
        tag.setSymbolicName("SubscriberName");
        tag.setTagType(TagValueType.CHOICELIST);
        tag.getAllowedValue().add(new MCOAllowedValue(null, "unknown"));
        when(tagClassService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(tag));
        validator.computeValidityCode(document, Lists.<Document> newArrayList());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreFirstLevelWithParent() throws SugarTechnicalException, SugarFunctionalException {

        DocumentClass mockDocClass = mock(DocumentClass.class);

        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());

        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.isActive()).thenReturn(true);
        Document envelope = DocumentMockUtil.buildEnvelope();
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document parentEnvelope = DocumentMockUtil.buildEnvelope();
        envelope.setParentId(new ParentId(parentEnvelope.getId()));
        validator.checkStoreValidity(Lists.newArrayList(envelope));

    }

    @Test
    public void testParentValidationOK() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass docClass = Mockito.mock(DocumentClass.class);
        ClassId docClassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        when(docClass.isFirstLevel()).thenReturn(false);
        when(docClass.getCategory()).thenReturn(Category.DOCUMENT);
        when(docClass.getClassId()).thenReturn(docClassId);
        when(docClass.isActive()).thenReturn(true);

        DocumentClass physicalEnvClass = mock(DocumentClass.class);
        when(physicalEnvClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId phyclassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(docClassId, docClass.getLongLabel());
        when(physicalEnvClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(physicalEnvClass.isFirstLevel()).thenReturn(true);
        when(physicalEnvClass.getLongLabel()).thenReturn("physicalEnvClass");
        when(physicalEnvClass.getClassId()).thenReturn(phyclassId);
        when(physicalEnvClass.isActive()).thenReturn(true);

        Document document1 = DocumentMockUtil.buildClaimDocument();
        document1.getData().setName("document1");

        Document parentEnvelope = DocumentMockUtil.buildEnvelope();
        parentEnvelope.getData().setClassId(phyclassId);
        parentEnvelope.getData().setName("parentEnvelope");

        includeChildIntoEnvelope(parentEnvelope, document1);

        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(parentEnvelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(physicalEnvClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document1.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));

        when(documentService.get(DEFAULT_SCOPE, Lists.newArrayList(parentEnvelope.getId()), false, false))
                .thenReturn(Lists.newArrayList(parentEnvelope));

        validator.checkStoreValidity(Lists.newArrayList(document1));

        verify(documentService, Mockito.times(1)).get(eq(DEFAULT_SCOPE), anyListOf(Id.class), anyBoolean(),
                anyBoolean());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testParentValidationNOK() throws SugarTechnicalException, SugarFunctionalException {

        DocumentClass physicalEnvClass = mock(DocumentClass.class);
        when(physicalEnvClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId phyclassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(phyclassId, physicalEnvClass.getLongLabel());
        when(physicalEnvClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(physicalEnvClass.isFirstLevel()).thenReturn(true);
        when(physicalEnvClass.getLongLabel()).thenReturn("physicalEnvClass");
        when(physicalEnvClass.getClassId()).thenReturn(phyclassId);
        when(physicalEnvClass.isActive()).thenReturn(true);

        DocumentClass docClass = Mockito.mock(DocumentClass.class);
        ClassId docClassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        when(docClass.isFirstLevel()).thenReturn(false);
        when(docClass.getCategory()).thenReturn(Category.DOCUMENT);
        when(docClass.getClassId()).thenReturn(docClassId);
        when(docClass.isActive()).thenReturn(true);

        Document document1 = DocumentMockUtil.buildClaimDocument();
        document1.getData().setName("document1");

        Document parentEnvelope = DocumentMockUtil.buildEnvelope();
        parentEnvelope.getData().setClassId(phyclassId);
        parentEnvelope.getData().setName("parentEnvelope");

        includeChildIntoEnvelope(parentEnvelope, document1);

        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(parentEnvelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(physicalEnvClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document1.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));

        when(documentService.get(DEFAULT_SCOPE, Lists.newArrayList(parentEnvelope.getId()), false, false))
                .thenReturn(Lists.newArrayList(parentEnvelope));

        validator.checkStoreValidity(Lists.newArrayList(document1));

    }

    @Test
    public void testCheckStoreMultiLevelValid() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass logicalEnvClass = mock(DocumentClass.class);
        when(logicalEnvClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId logclassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);

        when(logicalEnvClass.isFirstLevel()).thenReturn(false);
        when(logicalEnvClass.getClassId()).thenReturn(logclassId);
        when(logicalEnvClass.getLongLabel()).thenReturn("logicalEnvClass");
        when(logicalEnvClass.isActive()).thenReturn(true);

        DocumentClass physicalEnvClass = mock(DocumentClass.class);
        when(physicalEnvClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId phyclassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        when(physicalEnvClass.isFirstLevel()).thenReturn(true);
        when(physicalEnvClass.getLongLabel()).thenReturn("physicalEnvClass");
        when(physicalEnvClass.getClassId()).thenReturn(phyclassId);
        when(physicalEnvClass.isActive()).thenReturn(true);

        DocumentClass docClass = Mockito.mock(DocumentClass.class);
        ClassId docClassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        when(docClass.isFirstLevel()).thenReturn(false);
        when(docClass.getCategory()).thenReturn(Category.DOCUMENT);
        when(docClass.getClassId()).thenReturn(docClassId);
        when(docClass.isActive()).thenReturn(true);

        Document document1 = DocumentMockUtil.buildClaimDocument();
        Document document2 = DocumentMockUtil.buildClaimDocument();
        Document document3 = DocumentMockUtil.buildClaimDocument();
        Document document4 = DocumentMockUtil.buildClaimDocument();

        Document childEnvelope1 = DocumentMockUtil.buildEnvelope();
        Document childEnvelope2 = DocumentMockUtil.buildEnvelope();
        Document parentEnvelope = DocumentMockUtil.buildEnvelope();

        includeChildIntoEnvelope(childEnvelope1, document1);
        includeChildIntoEnvelope(childEnvelope1, document2);
        includeChildIntoEnvelope(childEnvelope1, document3);
        includeChildIntoEnvelope(childEnvelope2, document4);

        includeChildIntoEnvelope(parentEnvelope, childEnvelope1);
        includeChildIntoEnvelope(parentEnvelope, childEnvelope2);

        document1.getData().setName("document1");
        document2.getData().setName("document2");
        document3.getData().setName("document3");
        document4.getData().setName("document4");

        childEnvelope1.getData().setName("childEnvelope1");
        childEnvelope2.getData().setName("childEnvelope2");
        parentEnvelope.getData().setName("parentEnvelope");

        childEnvelope1.getData().setClassId(logclassId);
        childEnvelope2.getData().setClassId(logclassId);
        parentEnvelope.getData().setClassId(phyclassId);

        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(parentEnvelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(physicalEnvClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(childEnvelope1.getData().getClassId())))
                .thenReturn(Lists.newArrayList(logicalEnvClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(childEnvelope2.getData().getClassId())))
                .thenReturn(Lists.newArrayList(logicalEnvClass));

        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document1.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document2.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document3.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document4.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));

        validator.checkStoreValidity(Lists.newArrayList(parentEnvelope));

        verify(documentService, Mockito.times(0)).get(eq(DEFAULT_SCOPE), anyListOf(Id.class), anyBoolean(),
                anyBoolean());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreMultiLevelInvalidChild() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass logicalEnvClass = mock(DocumentClass.class);
        when(logicalEnvClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId logclassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(logclassId, logicalEnvClass.getLongLabel());
        when(logicalEnvClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(logicalEnvClass.isFirstLevel()).thenReturn(false);
        when(logicalEnvClass.getClassId()).thenReturn(logclassId);
        when(logicalEnvClass.getLongLabel()).thenReturn("logicalEnvClass");
        when(logicalEnvClass.isActive()).thenReturn(true);

        DocumentClass physicalEnvClass = mock(DocumentClass.class);
        when(physicalEnvClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId phyclassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        when(physicalEnvClass.isFirstLevel()).thenReturn(true);
        when(physicalEnvClass.getLongLabel()).thenReturn("physicalEnvClass");
        when(physicalEnvClass.getClassId()).thenReturn(phyclassId);
        when(physicalEnvClass.isActive()).thenReturn(true);

        DocumentClass docClass = Mockito.mock(DocumentClass.class);
        ClassId docClassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        when(docClass.isFirstLevel()).thenReturn(false);
        when(docClass.getCategory()).thenReturn(Category.DOCUMENT);
        when(docClass.getClassId()).thenReturn(docClassId);
        when(docClass.isActive()).thenReturn(true);

        Document document1 = DocumentMockUtil.buildClaimDocument();
        Document document2 = DocumentMockUtil.buildClaimDocument();
        Document document3 = DocumentMockUtil.buildClaimDocument();
        Document document4 = DocumentMockUtil.buildClaimDocument();

        Document childEnvelope1 = DocumentMockUtil.buildEnvelope();
        Document childEnvelope2 = DocumentMockUtil.buildEnvelope();
        Document parentEnvelope = DocumentMockUtil.buildEnvelope();

        includeChildIntoEnvelope(childEnvelope1, document1);
        includeChildIntoEnvelope(childEnvelope1, document2);
        includeChildIntoEnvelope(childEnvelope1, document3);
        includeChildIntoEnvelope(childEnvelope2, document4);

        includeChildIntoEnvelope(parentEnvelope, childEnvelope1);
        includeChildIntoEnvelope(parentEnvelope, childEnvelope2);

        document1.getData().setName("document1");
        document2.getData().setName("document2");
        document3.getData().setName("document3");
        document4.getData().setName("document4");

        childEnvelope1.getData().setName("childEnvelope1");
        childEnvelope2.getData().setName("childEnvelope2");
        parentEnvelope.getData().setName("parentEnvelope");

        childEnvelope1.getData().setClassId(logclassId);
        childEnvelope2.getData().setClassId(logclassId);
        parentEnvelope.getData().setClassId(phyclassId);

        System.out.println(parentEnvelope.getData().getClassId());
        System.out.println(physicalEnvClass.getClassId());
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(parentEnvelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(physicalEnvClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(childEnvelope1.getData().getClassId())))
                .thenReturn(Lists.newArrayList(logicalEnvClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(childEnvelope2.getData().getClassId())))
                .thenReturn(Lists.newArrayList(logicalEnvClass));

        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document1.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document2.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document3.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));
        when(documentClassService.get(DEFAULT_SCOPE, Lists.newArrayList(document4.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));

        validator.checkStoreValidity(Lists.newArrayList(parentEnvelope));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckUpdateFirstLevelWithParent() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass mockDocClass = mock(DocumentClass.class);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());

        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.isActive()).thenReturn(true);
        Document envelope = DocumentMockUtil.buildEnvelope();
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document parentEnvelope = DocumentMockUtil.buildEnvelope();
        envelope.setParentId(new ParentId(parentEnvelope.getId()));
        Map<Id, Document> docIdToOldDoc = new HashMap<Id, Document>();
        validator.checkUpdateValidity(Lists.newArrayList(envelope), docIdToOldDoc);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckUpdateMissingChildren() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        DocumentClass mockDocClass = mock(DocumentClass.class);
        ClassId docClassId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        when(mockDocClass.isFirstLevel()).thenReturn(false);
        when(mockDocClass.getClassId()).thenReturn(docClassId);
        when(mockDocClass.isActive()).thenReturn(true);
        when(documentClassService.get(document.getScope(), Lists.newArrayList(document.getData().getClassId())))
                .thenReturn(Lists.newArrayList(mockDocClass));

        DocumentClass mockEnvClass = mock(DocumentClass.class);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(docClassId, mockDocClass.getLongLabel());

        when(mockEnvClass.getCategory()).thenReturn(Category.ENVELOPE);
        when(mockEnvClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        when(mockEnvClass.isFirstLevel()).thenReturn(true);
        when(mockEnvClass.getClassId()).thenReturn(classId);
        when(mockEnvClass.isActive()).thenReturn(true);
        Document envelope = DocumentMockUtil.buildEnvelope();
        when(documentClassService.get(envelope.getScope(), Lists.newArrayList(envelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(mockEnvClass));

        Document document2 = DocumentMockUtil.buildClaimDocument();
        includeChildIntoEnvelope(envelope, document);
        Document storedEnvelope = DocumentMockUtil.buildEnvelope();
        includeChildIntoEnvelope(storedEnvelope, document);
        includeChildIntoEnvelope(storedEnvelope, document2);

        when(documentService.get(envelope.getScope(), Lists.newArrayList(envelope.getId()), true, false))
                .thenReturn(Lists.newArrayList(storedEnvelope));
        Map<Id, Document> docIdToOldDoc = new HashMap<Id, Document>();
        docIdToOldDoc.put(envelope.getId(), storedEnvelope);
        validator.checkUpdateValidity(Lists.newArrayList(envelope), docIdToOldDoc);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testUpdateChildDocumentIsCurrentDocument() throws SugarFunctionalException, SugarTechnicalException {

        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));

        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.isActive()).thenReturn(true);

        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document envelope = DocumentMockUtil.buildEnvelope();
        envelope.getChildObject().getId().add(envelope.getId());
        Map<Id, Document> docIdToOldDoc = new HashMap<Id, Document>();
        validator.checkUpdateValidity(Lists.newArrayList(envelope), docIdToOldDoc);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testUpdateChildDocumentIsParentDocument() throws SugarFunctionalException, SugarTechnicalException {

        DocumentClass mockDocClass = mock(DocumentClass.class);
        when(mockDocClass.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));

        when(mockDocClass.isFirstLevel()).thenReturn(true);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(mockDocClass.isActive()).thenReturn(true);

        DocumentClass mockDocClass2 = mock(DocumentClass.class);
        when(mockDocClass2.getCategory()).thenReturn(Category.ENVELOPE);
        ClassId classId2 = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren2 = new AllowedChildren(classId2, mockDocClass2.getLongLabel());
        when(mockDocClass2.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren2));

        when(mockDocClass2.isFirstLevel()).thenReturn(false);
        when(mockDocClass2.getClassId()).thenReturn(classId2);
        when(mockDocClass2.isActive()).thenReturn(true);

        Document envelope = DocumentMockUtil.buildEnvelope();
        Document childComponent = DocumentMockUtil.buildEnvelope();
        Document child2 = DocumentMockUtil.buildEnvelope();
        childComponent.setParentId(new ParentId(child2.getId()));
        childComponent.getChildObject().getId().add(child2.getId());
        child2.setParentId(new ParentId(envelope.getId()));

        when(documentClassService.get(envelope.getScope(), Lists.newArrayList(envelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(mockDocClass));
        when(documentClassService.get(child2.getScope(), Lists.newArrayList(child2.getData().getClassId())))
                .thenReturn(Lists.newArrayList(mockDocClass2));
        when(documentService.get(envelope.getScope(), Lists.newArrayList(envelope.getId()), true, false))
                .thenReturn(Lists.newArrayList(envelope));
        when(documentService.get(child2.getScope(), Lists.newArrayList(child2.getId()), true, false))
                .thenReturn(Lists.newArrayList(child2));
        Map<Id, Document> docIdToOldDoc = new HashMap<Id, Document>();
        docIdToOldDoc.put(envelope.getId(), envelope);
        // docIdToOldDoc.put(envelope.getId(), envelope);
        validator.checkUpdateValidity(Lists.newArrayList(childComponent), docIdToOldDoc);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindEmptyOperator() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(Levels.TAG, "TagName", null, Types.STRING, Lists.newArrayList(""));
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindEmptyType() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(Levels.TAG, "TagName", Operators.CONTAINS, null, Lists.newArrayList(""));
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindEmptyLevel() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(null, "TagName", Operators.CONTAINS, Types.STRING, Lists.newArrayList(""));
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindEmptyName() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(Levels.TAG, null, Operators.CONTAINS, Types.STRING, Lists.newArrayList(""));
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindEmptyValues() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(Levels.TAG, "TagName", Operators.CONTAINS, Types.STRING, null);
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindOrderClauseEmptyLevel() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(Levels.TAG, "TagName", Operators.CONTAINS, Types.STRING,
                Lists.newArrayList(""));
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindOrderClauseEmptyName() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, null, Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(Levels.TAG, "TagName", Operators.CONTAINS, Types.STRING,
                Lists.newArrayList(""));
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindOrderClauseEmptyType() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", null, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(Levels.TAG, "TagName", Operators.CONTAINS, Types.STRING,
                Lists.newArrayList(""));
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindWrongItem() throws SugarFunctionalException, SugarTechnicalException {
        String scope = DEFAULT_SCOPE;
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        Criterion criterion = new Criterion(Levels.TAG, "TagName", Operators.CONTAINS, Types.STRING,
                Lists.newArrayList(""));
        criteria.setItem(Item.FOLDER);
        criteria.getCriterionList().add(criterion);
        validator.checkFindValidity(scope, criteria, orderClause, MaxSearchNumber);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckUpdateNotAllowedClassesMultipleLevelDocument()
            throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = DocumentMockUtil.buildEnvelope();
        Document envelope2 = DocumentMockUtil.buildEnvelope();
        envelope2.getData().getClassId().setValue("subEnv");
        Document document = DocumentMockUtil.buildClaimDocument();
        envelope2.getChildObject().getDocument().add(document);
        envelope.getChildObject().getDocument().add(envelope2);

        DocumentClass phyClass = Mockito.mock(DocumentClass.class);
        when(phyClass.isFirstLevel()).thenReturn(true);
        when(phyClass.getCategory()).thenReturn(Category.ENVELOPE);
        when(phyClass.isActive()).thenReturn(true);

        DocumentClass logClass = Mockito.mock(DocumentClass.class);
        when(logClass.isFirstLevel()).thenReturn(false);
        when(logClass.getCategory()).thenReturn(Category.ENVELOPE);
        when(logClass.isActive()).thenReturn(true);
        when(logClass.getAllowedChildren())
                .thenReturn(Lists.newArrayList(new AllowedChildren(new ClassId("MyValue", "MyIssuer", 0), "allowed")));
        DocumentClass docClass = Mockito.mock(DocumentClass.class);
        when(docClass.isFirstLevel()).thenReturn(false);
        when(docClass.getCategory()).thenReturn(Category.DOCUMENT);
        when(docClass.isActive()).thenReturn(true);
        when(docClass.getClassId()).thenReturn(document.getData().getClassId());

        when(documentClassService.get(envelope.getScope(), Lists.newArrayList(envelope.getData().getClassId())))
                .thenReturn(Lists.newArrayList(phyClass));
        when(documentClassService.get(envelope2.getScope(), Lists.newArrayList(envelope2.getData().getClassId())))
                .thenReturn(Lists.newArrayList(logClass));
        when(documentClassService.get(document.getScope(), Lists.newArrayList(document.getData().getClassId())))
                .thenReturn(Lists.newArrayList(docClass));
        Map<Id, Document> docIdToOldDoc = new HashMap<Id, Document>();
        validator.checkUpdateValidity(Lists.newArrayList(envelope), docIdToOldDoc);
    }

    private void attacheChildToEnvelope(Document envelope, Document child) {
        envelope.getChildObject().getId().add(child.getId());
        child.setParentId(new ParentId(envelope.getId()));
    }

    private void includeChildIntoEnvelope(Document envelope, Document child) {
        envelope.getChildObject().getDocument().add(child);
        child.setParentId(new ParentId(envelope.getId()));
    }

}
