package com.bnpp.cardif.sugar.security;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00005;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;

import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;

public class DocumentSecurityHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentSecurityHelper.class);

    @PreAuthorize("hasPermission(#document, T(org.springframework.security.acls.domain.BasePermission).CREATE)")
    public void checkStoreValidity(Document document) throws SugarFunctionalException {
        LOGGER.info("Checking validity for Document : " + document);
        if (document.getData() == null) {
            throw ExceptionBuilder.createFunctionalException(F00005, document.getId());
        }
    }

}
