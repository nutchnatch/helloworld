package com.bnpp.cardif.sugar.core.tsp.documentfile;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileValidator;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class DocumentFileValidatorTSPTest {

    @Mock
    BusinessScopeValidator scopeValidator;

    @InjectMocks
    DocumentFileValidator validator = new DocumentFileValidatorTSP();

    @Test(expected = SugarFunctionalException.class)
    public void testAddValidityEmptyContent() throws SugarTechnicalException, SugarFunctionalException {
        DocumentFile documentFile = new DocumentFile();
        validator.checkAddValidity(Lists.newArrayList(documentFile));
    }

}
