package com.bnpp.cardif.sugar.core.tsp.documentfile;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileValidator;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.documentfile.DocumentFileDAO;
import com.bnpp.cardif.sugar.domain.documentfile.DocumentFileBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class DocumentFileServiceTSPTest {
    @Mock
    private DocumentFileDAO documentFileDAO;

    @Mock
    private SugarEventBus eventBus;

    @Mock
    DocumentFileValidator validator;

    @InjectMocks
    private final DocumentFileServiceTSP documentFileService = new DocumentFileServiceTSP();

    @Test
    public void testAdd() throws SugarTechnicalException, FileNotFoundException, IOException, SugarFunctionalException {
        ArrayList<DocumentFile> filesToStore = new ArrayList<DocumentFile>();
        DocumentFile file = DocumentFileBuilder.scope("SYLDAVIA").name("My document").build();
        FileDataSource fileDataSource = new FileDataSource("src/test/resources/log4j.xml");
        file.setContent(new DataHandler(fileDataSource));

        filesToStore.add(file);

        List<DocumentFile> storedFiles = documentFileService.add(filesToStore);

        verify(documentFileDAO).store(filesToStore);
        assertEquals(filesToStore.size(), storedFiles.size());
        assertNotNull(storedFiles.get(0).getURI());
        assertNotNull(storedFiles.get(0).getCreateDate());
        assertEquals(file.getScope(), filesToStore.get(0).getScope());
        assertNull(storedFiles.get(0).getContent());
    }

    @Test
    public void testGet() throws SugarTechnicalException, SugarFunctionalException {
        URI uri = new URI();
        uri.setValue("My URI !!");
        String scope = "/SYLDAVIA";
        DocumentFile documentFile = new DocumentFile();
        documentFile.setScope(scope);

        List<URI> uris = Lists.newArrayList(uri);
        List<DocumentFile> addedDocumentFiles = Lists.newArrayList(documentFile);
        when(documentFileDAO.get(scope, uris)).thenReturn(addedDocumentFiles);
        List<DocumentFile> result = documentFileService.get(scope, uris);
        verify(documentFileDAO).get(scope, uris);
        assertEquals(addedDocumentFiles, result);
    }

    @Test
    public void testDelte() throws SugarTechnicalException, SugarFunctionalException {
        URI uri = new URI();
        uri.setValue("My URI !!");
        String scope = "SYLDAVIA";
        DocumentFile documentFile = new DocumentFile();
        documentFile.setScope(scope);

        List<URI> uris = Lists.newArrayList(uri);
        List<URI> result = documentFileService.delete(scope, uris);
        verify(documentFileDAO).delete(scope, uri.getValue());
        assertEquals(Lists.newArrayList(uri), result);
    }
}
