package com.bnpp.cardif.sugar.core.tsp.fact;

import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.DOCUMENT;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.fact.ReportingValidator;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.dao.api.fact.FactDAO;
import com.bnpp.cardif.sugar.dao.api.reporting.ReportingDAO;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.Fact;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class ReportingServiceTSPTest {
    private static final String SCOPE = "Syldavia";

    @Mock
    private FactDAO factDAO;

    @Mock
    private ReportingDAO reportingDAO;

    @Mock
    private DocumentClassService documentClassService;

    @Mock
    private ReportingValidator validator;

    @InjectMocks
    private final ReportingServiceTSP reportingService = new ReportingServiceTSP();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    @Ignore
    public void test() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildEnvelope();
        Event event = new Event(SCOPE, DOCUMENT, CREATE, document, document.getId());
        reportingService.onEvent(event);

        ArgumentCaptor<String> scopeCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Fact> captor = ArgumentCaptor.forClass(Fact.class);
        verify(factDAO).store(scopeCaptor.capture(), captor.capture());
        assertEquals("scope", scopeCaptor.getValue());
        assertEquals(ObjectType.DOCUMENT, captor.getValue().getType());
        assertEquals(Action.CREATE, captor.getValue().getAction());
    }

    @Test
    public void testGetEnvelopeFlowsReport() throws Exception {
        DocumentClass clazz = new DocumentClass();
        clazz.setClassId(new ClassId("class id value", "CARDIF", 2));
        when(documentClassService.search(SCOPE, Category.ENVELOPE, false)).thenReturn(Lists.newArrayList(clazz));

        EnvelopeFlows flows = new EnvelopeFlows();
        flows.setClassId(new ClassId(clazz.getClassId().getValue(), "CARDIF", 0));
        when(reportingDAO.getEnvelopesAndDocumentFlow(anyString(), anyString(), anyString()))
                .thenReturn(Lists.newArrayList(flows));

        when(documentClassService.get(SCOPE, Lists.newArrayList(flows.getClassId())))
                .thenThrow(new SugarTechnicalException("No class for version 0"));

        DocumentFile report = reportingService.getEnvelopeFlowsReport(SCOPE, new Date(), new Date());
        assertNotNull(report);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testGetEnvelopeFlowsReportWithNonExistignEnvelopeClass() throws Exception {
        DocumentClass clazz = new DocumentClass();
        clazz.setClassId(new ClassId("class id value", "CARDIF", 2));
        when(documentClassService.search(SCOPE, Category.ENVELOPE, false)).thenReturn(Lists.newArrayList(clazz));

        EnvelopeFlows flows = new EnvelopeFlows();
        flows.setClassId(new ClassId("other id value", "CARDIF", 0));
        when(reportingDAO.getEnvelopesAndDocumentFlow(anyString(), anyString(), anyString()))
                .thenReturn(Lists.newArrayList(flows));

        when(documentClassService.get(SCOPE, Lists.newArrayList(flows.getClassId())))
                .thenThrow(new SugarTechnicalException("No class for version 0"));

        reportingService.getEnvelopeFlowsReport(SCOPE, new Date(), new Date());
    }
}