package com.bnpp.cardif.sugar.core.tsp.folder;

import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.api.folder.FolderValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.folder.test.FolderMockUtility;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOAllowedValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagValueType;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class FolderValidatorTSPTest {
    private static final String SCOPE = "Syldavia";

    @Mock
    FolderService folderService;

    @Mock
    TagClassValidator tagValidator;

    @Mock
    FolderClassValidator folderClassValidator;

    @Mock
    FolderClassService classService;

    @Mock
    BusinessScopeValidator scopeValidator;

    @Mock
    TagclassService tagService;

    @InjectMocks
    FolderValidator validator = new FolderValidatorTSP();

    @Before
    public void setUp() throws Exception {
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreValidityEmptyList() throws SugarTechnicalException, SugarFunctionalException {
        List<Folder> folders = new ArrayList<Folder>();
        validator.checkCreationValidity(folders);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithoutScope() throws SugarTechnicalException, SugarFunctionalException {
        Folder folder = new Folder();
        folder.setData(new FolderDataType());
        folder.getData().setName("FolderTest");
        validator.checkCreationValidity(Lists.newArrayList(folder));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithDifferentScope() throws SugarTechnicalException, SugarFunctionalException {
        Folder folder = new Folder();
        folder.setData(new FolderDataType());
        folder.getData().setName("FolderTest");
        folder.setScope(SCOPE);
        Folder folder1 = new Folder();
        folder1.setData(new FolderDataType());
        folder1.getData().setName("FolderTest1");
        folder1.setScope("Gopal");
        validator.checkCreationValidity(Lists.newArrayList(folder, folder1));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testcheckUpdateValidityClosedFolder() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass folderClass = buildFolderClass();
        Folder folderToStore = FolderMockUtility.buildClaimFolder(1);
        folderToStore.setData(new FolderDataType());
        folderToStore.getData().setName("FolderTest1");
        folderToStore.setScope(SCOPE);
        folderToStore.getData().setOwner("Owner");
        folderToStore.getData().setClassId(new ClassId());

        folderToStore.getData().setStatusCode(FolderStatusCodeType.CLOSE);
        when(folderService.get(anyListOf(FolderId.class), anyString())).thenReturn(Lists.newArrayList(folderToStore));
        when(classService.get(anyListOf(ClassId.class), anyString())).thenReturn(Lists.newArrayList(folderClass));
        validator.checkUpdateValidity(Lists.newArrayList(folderToStore));
    }

    private FolderClass buildFolderClass() {
        FolderClass clazz = new FolderClass();
        clazz.setClassId(new ClassId(UUID.randomUUID().toString(), "TOTO", 0));
        clazz.setScope(SCOPE);
        clazz.setActive(true);
        clazz.setLongLabel("my component class " + Math.random());
        return clazz;
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithNonExistingScope() throws SugarTechnicalException, SugarFunctionalException {
        Folder folder = new Folder();
        folder.setData(new FolderDataType());
        folder.getData().setName("FolderTest");
        folder.setScope(SCOPE);
        Folder folder1 = new Folder();
        folder1.setData(new FolderDataType());
        folder1.getData().setName("FolderTest1");
        folder1.setScope(SCOPE);
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00602)).when(scopeValidator)
                .checkExistence(anyString());
        validator.checkCreationValidity(Lists.newArrayList(folder, folder1));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreWithNonExistingTag() throws SugarTechnicalException, SugarFunctionalException {
        Folder folder = new Folder();
        folder.setData(new FolderDataType());
        folder.getData().setName("FolderTest");
        folder.setScope(SCOPE);
        Folder folder1 = new Folder();
        folder1.setData(new FolderDataType());
        folder1.getData().setName("FolderTest1");
        folder1.setScope(SCOPE);
        folder1.setTags(new Tags());
        folder1.getTags().getTag().add(new Tag("TOTO", "Subscriber"));
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00206)).when(tagValidator)
                .checkExistence(anyString(), anyListOf(String.class));
        validator.checkCreationValidity(Lists.newArrayList(folder, folder1));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreValidityExistingName() throws SugarTechnicalException, SugarFunctionalException {
        Folder folder = new Folder();
        folder.setData(new FolderDataType());
        folder.getData().setName("FolderTest");
        folder.setScope(SCOPE);
        Folder folder1 = new Folder();
        folder1.setData(new FolderDataType());
        folder1.getData().setName("FolderTest");
        folder1.setScope(SCOPE);
        folder1.setFolderId(new FolderId());
        when(folderService.getBySymbolicName(anyString(), anyString())).thenReturn(folder1);
        validator.checkCreationValidity(Lists.newArrayList(folder));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testFindWrongMax() throws SugarFunctionalException, SugarTechnicalException {
        String scope = "Syldavia";
        OrderClause orderClause = new OrderClause(Levels.TAG, "CreatnDate", Types.TIMESTAMP, false);
        Criteria criteria = new Criteria();
        criteria.setItem(Item.FOLDER);
        Criterion criterion = new Criterion(Levels.TAG, "TagName", Operators.CONTAINS, Types.STRING,
                Lists.newArrayList(""));
        criteria.getCriterionList().add(criterion);

        validator.checkFindValidity(scope, criteria, orderClause, -10);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreValiditySameName() throws SugarTechnicalException, SugarFunctionalException {
        Folder folder = new Folder();
        folder.setData(new FolderDataType());
        folder.getData().setName("FolderTest");
        folder.setScope(SCOPE);
        Folder folder1 = new Folder();
        folder1.setData(new FolderDataType());
        folder1.getData().setName("FolderTest");
        folder1.setScope(SCOPE);
        validator.checkCreationValidity(Lists.newArrayList(folder, folder1));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckUpdateChildComponentIsEmpty() throws SugarTechnicalException, SugarFunctionalException {
        Folder folder = FolderMockUtility.buildClaimFolder(1);
        TagClass tagClass = new TagClass();
        FolderClass folderClass = buildFolderClass();
        when(tagService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(tagClass));
        when(folderService.get(anyListOf(FolderId.class), anyString())).thenReturn(Lists.newArrayList(folder));
        when(classService.get(anyListOf(ClassId.class), anyString())).thenReturn(Lists.newArrayList(folderClass));
        folder.setChildComponents(null);
        validator.checkUpdateValidity(Lists.newArrayList(folder));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckStoreValidityTagValueNotAllowed() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass folderClass = buildFolderClass();
        folderClass.getTagReference().add(new MCOTagReference("Subscriber", false, false));
        Folder folderToStore = FolderMockUtility.buildClaimFolder(1);
        folderToStore.setData(new FolderDataType());
        folderToStore.getData().setName("FolderTest1");
        folderToStore.setScope(SCOPE);
        folderToStore.getData().setOwner("Owner");
        folderToStore.getData().setClassId(new ClassId());
        folderToStore.setTags(new Tags());
        Tag tag = new Tag("TOTO", "Subscriber");
        folderToStore.getTags().getTag().add(tag);
        TagClass tagClass = new TagClass();
        tagClass.setTagType(TagValueType.CHOICELIST);
        tagClass.getAllowedValue().add(new MCOAllowedValue(null, "TATA"));

        folderToStore.getData().setStatusCode(FolderStatusCodeType.OPEN);
        when(tagService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(tagClass));
        when(folderService.get(anyListOf(FolderId.class), anyString())).thenReturn(Lists.newArrayList(folderToStore));
        when(classService.get(anyListOf(ClassId.class), anyString())).thenReturn(Lists.newArrayList(folderClass));
        validator.checkCreationValidity(Lists.newArrayList(folderToStore));
    }
}
