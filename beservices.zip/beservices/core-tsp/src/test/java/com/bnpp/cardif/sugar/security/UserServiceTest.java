package com.bnpp.cardif.sugar.security;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnppa.sesame.services.common.model.UserIdentity;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlEntry;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.GrantType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {

    private static final String USERNAME = "jakadi";

    private static final String PASSWORD = "iconnect";

    private static final String FIRSTNAME = "Jacques";

    private static final String LASTNAME = "KADI";

    private static final String AUTHORITY = "admin";

    @Mock
    private AclService aclService;
    
    @Mock
    private DocumentSecurityHelper documentSecurityHelper;

    @InjectMocks
    private UserService userService;

    @Before
    public void init() {
        UserIdentity userIdentity = new UserIdentity();
        userIdentity.setFirstName(FIRSTNAME);
        userIdentity.setLastName(LASTNAME);

        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(AUTHORITY));

        AuthenticatedUser user = new AuthenticatedUser(USERNAME, PASSWORD, null, FIRSTNAME, LASTNAME,
                grantedAuthorities, "test version");
        user.setAuthorities(grantedAuthorities);
        Authentication actualAuthentication = new UsernamePasswordAuthenticationToken(user, null,
                user.getAuthorities());

        SecurityContextHolder.getContext().setAuthentication(actualAuthentication);
    }

    @Test
    public void testGetDocument() throws SugarTechnicalException, SugarFunctionalException {
        Document myDocument = new Document();
        myDocument.setId(new Id("12345", "issuer", "scheme"));
        myDocument.setScope("MyScope");

        AclId aclId = new AclId("876", "issuer", "scheme");
        AccessControlList acl = new AccessControlList();
        acl.setAclId(aclId);
        acl.setScope(myDocument.getScope());
        AccessControlEntry ace1 = new AccessControlEntry();
        ace1.setGrant(GrantType.ALLOW);
        ace1.setPermission("READ");
        ace1.getPrincipal().add("admin");
        acl.getAccessControlEntry().add(ace1);

        Mockito.when(aclService.getByDocumentId(myDocument.getScope(), myDocument.getId())).thenReturn(acl);
        Mockito.when(aclService.get(myDocument.getScope(), aclId)).thenReturn(acl);

        userService.getDocument(myDocument);
    }

    @Test
    public void testCreateDocument() throws SugarTechnicalException, SugarFunctionalException {
        Document myDocument = new Document();
        myDocument.setData(new ElectronicDocumentDataType());
        myDocument.getData().setClassId(new ClassId("DocClass", "Issuer", 0));
        myDocument.setId(new Id("12345", "issuer", "scheme"));
        myDocument.setScope("MyScope");

        AclId aclId = new AclId("876", "issuer", "scheme");
        AccessControlList acl = new AccessControlList();
        acl.setAclId(aclId);
        acl.setScope(myDocument.getScope());
        AccessControlEntry ace1 = new AccessControlEntry();
        ace1.setGrant(GrantType.ALLOW);
        ace1.setPermission("CREATE");
        ace1.getPrincipal().add("admin");
        acl.getAccessControlEntry().add(ace1);
        acl.setScope(myDocument.getScope());

        Mockito.when(aclService.getByClassId(myDocument.getScope(), myDocument.getData().getClassId(), false))
                .thenReturn(acl);
        Mockito.when(aclService.get(acl.getScope(), aclId)).thenReturn(acl);

        userService.createDocument(myDocument);
    }

    @Test(expected = AccessDeniedException.class)
    public void testCreateDocumentFailsNoAclId() throws SugarTechnicalException, SugarFunctionalException {
        Document myDocument = new Document();
        myDocument.setData(new ElectronicDocumentDataType());
        myDocument.getData().setClassId(new ClassId("DocClass", "Issuer", 0));
        myDocument.setId(new Id("12345", "issuer", "scheme"));
        myDocument.setScope("MyScope");

        userService.createDocument(myDocument);
    }

    @Test(expected = AccessDeniedException.class)
    public void testCreateDocumentsFailsNoAclId() throws SugarTechnicalException, SugarFunctionalException {
        Document myDocument = new Document();
        myDocument.setData(new ElectronicDocumentDataType());
        myDocument.getData().setClassId(new ClassId("DocClass", "Issuer", 0));
        myDocument.setId(new Id("12345", "issuer", "scheme"));
        myDocument.setScope("MyScope");

        List<Document> documents = new ArrayList<>();
        documents.add(myDocument);
        Mockito.when(aclService.getByClassId(myDocument.getScope(), myDocument.getData().getClassId(), false))
                .thenReturn(null);
        userService.createDocuments(documents);
    }

    @Test(expected = AccessDeniedException.class)
    public void testGetDocumentFails() throws SugarTechnicalException, SugarFunctionalException {
        Document myDocument = new Document();
        myDocument.setId(new Id("12345", "issuer", "scheme"));
        myDocument.setScope("MyScope");

        AclId aclId = new AclId("876", "issuer", "scheme");
        AccessControlList acl = new AccessControlList();
        acl.setAclId(aclId);
        AccessControlEntry ace1 = new AccessControlEntry();
        ace1.setGrant(GrantType.ALLOW);
        ace1.setPermission("READ");
        ace1.getPrincipal().add("Anotherone");
        acl.getAccessControlEntry().add(ace1);
        acl.setScope(myDocument.getScope());
        Mockito.when(aclService.getByDocumentId(myDocument.getScope(), myDocument.getId())).thenReturn(acl);
        Mockito.when(aclService.get(acl.getScope(), aclId)).thenReturn(acl);

        userService.getDocument(myDocument);
    }

    @Test
    public void testGetAuthorities() {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        userService.getAuthorities(userDetails);
    }
}
