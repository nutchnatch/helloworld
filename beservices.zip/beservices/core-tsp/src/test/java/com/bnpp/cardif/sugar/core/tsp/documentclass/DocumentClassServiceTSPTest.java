package com.bnpp.cardif.sugar.core.tsp.documentclass;

import static com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category.ENVELOPE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassValidator;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.core.tsp.util.ObjectCloner;
import com.bnpp.cardif.sugar.dao.api.documentclass.DocumentClassDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class DocumentClassServiceTSPTest {
    private static String SCOPE = "myFakeScope";

    @Mock
    private DocumentClassDAO documentClassDAO;

    @Mock
    private SugarEventBus eventBus;

    @Mock
    private AclService aclService;

    @Mock
    private DocumentSecurityHelper documentSecurityHelper;

    @Mock
    private IdFactory classIdFactory;

    @Mock
    private DocumentClassValidator documentClassValidator;

    @InjectMocks
    private DocumentClassServiceTSP documentClassServiceTSP;

    @Before
    public void setUp() throws SugarTechnicalException, SugarFunctionalException {
        documentClassServiceTSP.init();
        when(aclService.getByClassId(anyString(), any(ClassId.class), anyBoolean()))
                .thenReturn(mock(AccessControlList.class));
    }

    @Test
    public void testSearchNonActiveDocumentClasses() throws Exception {
        DocumentClass version0 = buildDocumentClass();
        version0.setActive(true);

        DocumentClass version1 = buildDocumentClass();
        version1.getClassId().setValue(version0.getClassId().getValue());
        version1.getClassId().setIssuer(version0.getClassId().getIssuer());
        version1.getClassId().setVersId(version0.getClassId().getVersId() + 1);
        version1.setActive(false);

        DocumentClass version2 = buildDocumentClass();
        version2.getClassId().setValue(version0.getClassId().getValue());
        version2.getClassId().setIssuer(version0.getClassId().getIssuer());
        version2.getClassId().setVersId(version0.getClassId().getVersId() + 2);
        version2.setActive(false);

        List<DocumentClass> version1AsList = Lists.newArrayList(version1, version2);
        when(documentClassDAO.get(SCOPE, Lists.newArrayList(version1.getClassId(), version2.getClassId())))
                .thenReturn(version1AsList);
        when(documentClassDAO.search(SCOPE, Category.DOCUMENT, false)).thenReturn(version1AsList);

        List<DocumentClass> fetchedClasses = documentClassServiceTSP.search(SCOPE, Category.DOCUMENT, false);

        assertEquals(2, fetchedClasses.size());
        assertEquals(version1, fetchedClasses.get(0));
        assertEquals(version2, fetchedClasses.get(1));
    }

    @Test
    public void testSearchActiveDocumentClasses() throws Exception {
        DocumentClass version0 = buildDocumentClass();
        version0.setActive(false);

        DocumentClass version1 = buildDocumentClass();
        version1.getClassId().setValue(version0.getClassId().getValue());
        version1.getClassId().setIssuer(version0.getClassId().getIssuer());
        version1.getClassId().setVersId(version0.getClassId().getVersId() + 1);
        version1.setActive(true);

        DocumentClass version2 = buildDocumentClass();
        version2.getClassId().setValue(version0.getClassId().getValue());
        version2.getClassId().setIssuer(version0.getClassId().getIssuer());
        version2.getClassId().setVersId(version0.getClassId().getVersId() + 2);
        version2.setActive(false);

        List<DocumentClass> version1AsList = Lists.newArrayList(version1);
        when(documentClassDAO.get(SCOPE, Lists.newArrayList(version1.getClassId()))).thenReturn(version1AsList);
        when(documentClassDAO.search(SCOPE, Category.DOCUMENT, true)).thenReturn(version1AsList);

        List<DocumentClass> fetchedClasses = documentClassServiceTSP.search(SCOPE, Category.DOCUMENT, true);
        assertEquals(1, fetchedClasses.size());
        assertEquals(version1, fetchedClasses.get(0));
    }

    @Test
    public void testSearchAllActiveClasses() throws Exception {
        DocumentClass version0 = buildDocumentClass();
        version0.setCategory(ENVELOPE);
        version0.setActive(true);

        DocumentClass version1 = buildDocumentClass();
        version1.setActive(true);

        when(documentClassDAO.get(SCOPE, Lists.newArrayList(version0.getClassId(), version1.getClassId())))
                .thenReturn(Lists.newArrayList(version0, version1));

        when(documentClassDAO.search(SCOPE, null, true)).thenReturn(Lists.newArrayList(version0, version1));

        List<DocumentClass> fetchedClasses = documentClassServiceTSP.search(SCOPE, null, true);

        assertEquals(2, fetchedClasses.size());
        assertTrue(fetchedClasses.contains(version0));
        assertTrue(fetchedClasses.contains(version1));
    }

    @Test
    public void testSearchDocumentClasses() throws Exception {
        List<DocumentClass> fakeClasses = Lists.newArrayList(buildDocumentClass());
        when(documentClassDAO.search(SCOPE, null, false)).thenReturn(fakeClasses);
        when(documentClassDAO.get(SCOPE, Lists.newArrayList(fakeClasses.get(0).getClassId()))).thenReturn(fakeClasses);

        List<DocumentClass> fetchedClasses = documentClassServiceTSP.search(SCOPE, null, false);

        assertNotNull(fetchedClasses);
        assertFalse(fetchedClasses.isEmpty());
        assertEquals(fakeClasses, fetchedClasses);
    }

    @Test
    public void testSearchDocumentClassesWithAnotherScope() throws Exception {
        List<DocumentClass> fakeClasses = Lists.newArrayList(buildDocumentClass());
        when(documentClassDAO.search(SCOPE, null, false)).thenReturn(fakeClasses);

        List<DocumentClass> fetchedClasses = documentClassServiceTSP.search("a", Category.DOCUMENT, false);
        assertEquals(0, fetchedClasses.size());
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testAddDocumentClassAndAddDefaultACL() throws Exception {

        when(documentClassDAO.search(SCOPE, null, false)).thenReturn(new ArrayList<DocumentClass>());
        List<DocumentClass> fakeClasses = Lists.newArrayList(buildDocumentClass(), buildDocumentClass());

        documentClassServiceTSP.add(fakeClasses);

        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentClassDAO).store(storeCaptor.capture());
        List<DocumentClass> storedClasses = storeCaptor.getValue();
        assertNotNull(storedClasses.get(0).getCreateDate());
        assertNotNull(storedClasses.get(0).getLastUpdateDate());

        ArgumentCaptor<String> scopeCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<ClassId> classCaptor = ArgumentCaptor.forClass(ClassId.class);
        verify(aclService, times(2)).assignDefault(scopeCaptor.capture(), classCaptor.capture());
        assertEquals(fakeClasses.get(0).getScope(), scopeCaptor.getAllValues().get(0));
        assertEquals(fakeClasses.get(0).getClassId(), classCaptor.getAllValues().get(0));
        assertEquals(fakeClasses.get(1).getScope(), scopeCaptor.getAllValues().get(1));
        assertEquals(fakeClasses.get(1).getClassId(), classCaptor.getAllValues().get(1));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testAddDocumentClassWithNoLongLabel() throws Exception {
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00204)).when(documentClassValidator)
                .checkCreationValidity(anyListOf(DocumentClass.class));
        List<DocumentClass> fakeClasses = Lists.newArrayList(buildDocumentClass());
        fakeClasses.get(0).setLongLabel("");
        documentClassServiceTSP.add(fakeClasses);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testAddDocumentClassWithAlreadyExistingLabel() throws Exception {
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00205)).when(documentClassValidator)
                .checkCreationValidity(anyListOf(DocumentClass.class));

        List<DocumentClass> fakeClasses = Lists.newArrayList(buildDocumentClass());
        fakeClasses.get(0).setLongLabel("Contract");
        when(documentClassDAO.search(SCOPE, null, false)).thenReturn(fakeClasses);
        documentClassServiceTSP.add(fakeClasses);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testUpdateTwoDocumentClassesChangingVersion() throws Exception {
        DocumentClass class1 = buildDocumentClass();
        DocumentClass activeClass = buildDocumentClass();

        activeClass.setActive(true);

        when(documentClassDAO.get(SCOPE, Lists.newArrayList(class1.getClassId())))
                .thenReturn(Lists.newArrayList(ObjectCloner.clone(class1)));

        when(documentClassDAO.get(SCOPE, Lists.newArrayList(activeClass.getClassId())))
                .thenReturn(Lists.newArrayList(ObjectCloner.clone(activeClass)));

        List<DocumentClass> classes = Lists.newArrayList(ObjectCloner.clone(class1), ObjectCloner.clone(activeClass));
        documentClassServiceTSP.update(classes, true);

        verify(documentClassDAO, times(1)).store(classes);
        assertEquals(1, classes.get(0).getClassId().getVersId());
        assertEquals(1, classes.get(1).getClassId().getVersId());

        ArgumentCaptor<List> captor = ArgumentCaptor.forClass(List.class);
        verify(documentClassDAO, times(1)).update(captor.capture());
        assertEquals(activeClass.getClassId(), ((DocumentClass) captor.getValue().get(0)).getClassId());

        verify(aclService, times(4)).assignToClass(anyString(), any(AclId.class), any(ClassId.class), anyBoolean());
    }

    /**
     * Check if documentClass store fails previous version is not deactivated
     * 
     * @throws Exception
     */
    @Test
    public void testUpdateDocumentClassChangingVersionTransactionnal() throws Exception {
        DocumentClass activeClass = buildDocumentClass();
        activeClass.setActive(true);
        when(documentClassDAO.get(SCOPE, Lists.newArrayList(activeClass.getClassId())))
                .thenReturn(Lists.newArrayList(ObjectCloner.clone(activeClass)));

        Mockito.doThrow(new SugarTechnicalException()).when(documentClassDAO)
                .store(Mockito.anyListOf(DocumentClass.class));

        List<DocumentClass> classes = Lists.newArrayList(ObjectCloner.clone(activeClass));
        try {
            documentClassServiceTSP.update(classes, true);
        }
        catch (SugarTechnicalException e) {
        }
        verify(documentClassDAO, times(0)).update(Mockito.anyListOf(DocumentClass.class));
    }

    @Test
    public void testUpdateTwoDocumentClassesWithoutVersionChange() throws Exception {
        List<DocumentClass> classes = Lists.newArrayList(buildDocumentClass(), buildDocumentClass());
        when(documentClassDAO.get(classes.get(0).getScope(), Lists.newArrayList(classes.get(0).getClassId())))
                .thenReturn(Lists.newArrayList(classes.get(0)));
        when(documentClassDAO.get(classes.get(1).getScope(), Lists.newArrayList(classes.get(1).getClassId())))
                .thenReturn(Lists.newArrayList(classes.get(1)));
        documentClassServiceTSP.update(classes, false);

        verify(documentClassDAO, times(0)).store(classes);
        verify(documentClassDAO, times(1)).update(classes);
        assertNotNull(classes.get(0).getLastUpdateDate());
        assertNotNull(classes.get(1).getLastUpdateDate());
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testUpdateInactiveDocumentClasseVersionChange() throws Exception {
        List<DocumentClass> classes = Lists.newArrayList(buildDocumentClass());
        classes.get(0).setActive(false);
        when(documentClassDAO.get(anyString(), anyListOf(ClassId.class))).thenReturn(classes);
        documentClassServiceTSP.update(classes, true);
        ArgumentCaptor<List> captor = ArgumentCaptor.forClass(List.class);
        verify(documentClassDAO, times(0)).update(captor.capture());
        assertNotNull(classes.get(0).getLastUpdateDate());
        verify(documentClassDAO, times(1)).store(classes);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Test
    public void testActivate() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass firstVersion = DocumentMockUtil.buildFakeDocumentClass();
        firstVersion.setActive(true);
        DocumentClass secondVersion = DocumentMockUtil.buildFakeDocumentClass();
        ClassId firstVersionClassId = firstVersion.getClassId();
        secondVersion.setClassId(new ClassId(firstVersionClassId.getValue(), firstVersionClassId.getIssuer(),
                firstVersionClassId.getVersId() + 1));
        secondVersion.setActive(true);
        when(documentClassDAO.get(firstVersion.getScope(), Lists.newArrayList(firstVersion.getClassId())))
                .thenReturn(Lists.newArrayList(firstVersion));
        when(documentClassDAO.get(secondVersion.getScope(), Lists.newArrayList(secondVersion.getClassId())))
                .thenReturn(Lists.newArrayList(secondVersion));
        when(documentClassDAO.getAllVersions(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(firstVersion, secondVersion));

        documentClassServiceTSP.activate(firstVersion.getScope(), Lists.newArrayList(firstVersion.getClassId()), true);
        ArgumentCaptor<List> captor = ArgumentCaptor.forClass(List.class);
        verify(documentClassDAO, times(1)).update(captor.capture());
        List<DocumentClass> updatedClazz = captor.getValue();
        assertEquals(2, updatedClazz.size());
        assertTrue(updatedClazz.get(0).isActive());
        assertFalse(updatedClazz.get(1).isActive());
    }

    private DocumentClass buildDocumentClass() {
        DocumentClass clazz = new DocumentClass();
        clazz.setClassId(new ClassId(UUID.randomUUID().toString(), "Cardif", 0));
        clazz.setScope(SCOPE);
        clazz.setLongLabel("my component class " + Math.random());
        clazz.setCategory(Category.DOCUMENT);
        return clazz;
    }

    @Test
    public void testGet() throws Exception {
        DocumentClass clazz = buildDocumentClass();
        when(documentClassDAO.get(SCOPE, Lists.newArrayList(clazz.getClassId()))).thenReturn(Lists.newArrayList(clazz));

        List<ClassId> ids = Lists.newArrayList(clazz.getClassId());
        List<DocumentClass> result = documentClassServiceTSP.get(clazz.getScope(), ids);
        assertEquals(1, result.size());
        assertEquals(clazz, result.get(0));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testGetWithNoAllRequestedClasses() throws Exception {
        DocumentClass clazz = buildDocumentClass();
        when(documentClassDAO.get(clazz.getScope(), Lists.newArrayList(clazz.getClassId())))
                .thenReturn(Lists.newArrayList(clazz));

        List<ClassId> ids = Lists.newArrayList(clazz.getClassId(), new ClassId("id1", "", 0));
        documentClassServiceTSP.get("scope", ids);
    }

}
