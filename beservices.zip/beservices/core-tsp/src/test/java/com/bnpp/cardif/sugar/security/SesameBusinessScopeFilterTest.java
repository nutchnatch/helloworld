package com.bnpp.cardif.sugar.security;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/sugar-security-test.xml" })
@Ignore
public class SesameBusinessScopeFilterTest {
    private static final String USERNAME = "jakadi";

    private static final String PASSWORD = "iconnect";

    @Autowired
    AuthenticationProvider authenticationProvider;

    @Autowired
    private SesameBusinessScopeFilter authenticationFilter;

    @Before
    public void setUp() {
        initAuthentication();
    }

    @Test
    public void testCheckAuthorizationForValidScope() throws IOException, ServletException {
        HttpServletRequest request = mockRequest("Syldavia");
        HttpServletResponse response = mock(HttpServletResponse.class);

        Authentication actualAuthentication = authenticationFilter.attemptAuthentication(request, response);

        AuthenticatedUser authenticatedUser = (AuthenticatedUser) actualAuthentication.getPrincipal();
        assertEquals("Syldavia", authenticatedUser.getBusinessScopes());
    }

    @Test(expected = InsufficientAuthenticationException.class)
    public void testCheckAuthorizationForScopeFails() throws IOException, ServletException {
        HttpServletRequest request = mockRequest("AnotherScope");
        HttpServletResponse response = mock(HttpServletResponse.class);

        authenticationFilter.attemptAuthentication(request, response);
    }

    @Test(expected = BadCredentialsException.class)
    public void testCheckAuthorizationForEmptyScopeFails() throws IOException, ServletException {
        HttpServletRequest request = mockRequest("");
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);

        authenticationFilter.attemptAuthentication(request, response);
    }

    private Authentication initAuthentication() {
        Authentication authentication = new UsernamePasswordAuthenticationToken(USERNAME, PASSWORD);
        Authentication actualAuthentication = authenticationProvider.authenticate(authentication);

        AuthenticationManager authenticationManager = mock(AuthenticationManager.class);
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(actualAuthentication);
        authenticationFilter.setAuthenticationManager(authenticationManager);
        return actualAuthentication;
    }

    private HttpServletRequest mockRequest(String scope) {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getMethod()).thenReturn("POST");
        when(request.getParameter(SesameBusinessScopeFilter.SCOPE_PARAMETER)).thenReturn(scope);
        return request;
    }
}
