package com.bnpp.cardif.sugar.core.tsp.task;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.tsp.basket.BasketServiceTSP;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class TaskGeneratorServiceDroolsTest {
    private static final String SCOPE = "Syldavia";

    @Mock
    private BasketServiceTSP basketService;

    @Mock
    private TaskServiceTSP taskDAO;

    @Mock
    private DocumentClassService documentClassService;

    @Mock
    private SugarEventBus eventBus;

    @Mock
    private IdFactory idFactory;

    @InjectMocks
    private final TaskGeneratorServiceDrools drools = new TaskGeneratorServiceDrools();

    @Captor
    private ArgumentCaptor<ArrayList<Task>> storeCaptor;

    @Before
    public void init() throws SugarFunctionalException {
        drools.setXlsPath("drools/sugar-drools-task-test1b.xls");
        drools.setWorksheet("Routage");
        drools.setEncoding("UTF-8");

        List<Basket> baskets = new ArrayList<>();

        baskets.add(new Basket(new BasketId("12345", "ArondorTest", "Scheme"),
                Lists.newArrayList(new MCOI18NLabel("Basket1", "FR")), "Basket1", SCOPE));
        baskets.add(new Basket(new BasketId("12346", "ArondorTest", "Scheme"),
                Lists.newArrayList(new MCOI18NLabel("Basket1", "FR")), "Basket2", SCOPE));

        baskets.add(new Basket(new BasketId("12346", "ArondorTest", "Scheme"),
                Lists.newArrayList(new MCOI18NLabel("Basket1", "FR")), "EnvelopToIndex", SCOPE));
        baskets.add(new Basket(new BasketId("12346", "ArondorTest", "Scheme"),
                Lists.newArrayList(new MCOI18NLabel("Basket1", "FR")), "GoodsInsurance", SCOPE));
        baskets.add(new Basket(new BasketId("12346", "ArondorTest", "Scheme"),
                Lists.newArrayList(new MCOI18NLabel("Basket1", "FR")), "PersonalInsurance", SCOPE));
        baskets.add(new Basket(new BasketId("12346", "ArondorTest", "Scheme"),
                Lists.newArrayList(new MCOI18NLabel("Basket1", "FR")), "EnvelopToIndex", SCOPE));

        List<DocumentClass> documentClasses = new ArrayList<>();

        documentClasses.add(_documentClass("b21ba156-f5be-407e-a0b5-6c74aedea9ee", "PaperMail"));
        documentClasses.add(_documentClass("1a943a2d-b563-4491-8a71-a99307af2c00", "Snail"));
        documentClasses.add(_documentClass("74018512-d00a-4de8-904e-184bddd2e412", "Invoice"));
        try {
            Mockito.when(basketService.getAllUnfiltered(anyString())).thenReturn(baskets);
            Mockito.when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                    .thenReturn(documentClasses);
        }
        catch (SugarTechnicalException e) {
        }

    }

    private DocumentClass _documentClass(String id, String name) {
        DocumentClass clz = new DocumentClass();
        clz.setClassId(new ClassId(id, "CARDIF", 0));
        clz.setLongLabel(name);
        return clz;
    }

    @Test
    public void testLoad() throws SugarTechnicalException, SugarFunctionalException {
        drools.generate(null, null, null, Action.CREATE);
    }

    @Test
    public void testBasket1() throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = DocumentMockUtil.buildEnvelope();

        drools.generate(envelope, null, null, Action.CREATE);

        Mockito.verify(taskDAO).create(storeCaptor.capture());

        ArrayList<Task> tasks = storeCaptor.getValue();

        Task task = tasks.get(0);
        Assert.assertNotNull(task);
        Assert.assertEquals("Routage Papier", task.getName());
        Assert.assertEquals("12345", task.getBasketId().getValue());
    }

    @Test
    public void testBasket2_NoSend() throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = DocumentMockUtil.buildEnvelope();
        envelope.getData().getClassId().setValue("1a943a2d-b563-4491-8a71-a99307af2c00");
        drools.generate(envelope, null, null, Action.CREATE);

        Mockito.verify(taskDAO, Mockito.times(0)).create(storeCaptor.capture());
    }

    @Test
    public void testBasket2_Send() throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = DocumentMockUtil.buildEnvelope();
        envelope.getData().getClassId().setValue("74018512-d00a-4de8-904e-184bddd2e412");
        drools.generate(envelope, null, null, Action.CREATE);

        Mockito.verify(taskDAO, Mockito.times(1)).create(storeCaptor.capture());

        ArrayList<Task> tasks = storeCaptor.getValue();
        Task task = tasks.get(0);
        Assert.assertNotNull(tasks);
        Assert.assertEquals("Routage Autre", task.getName());
        Assert.assertEquals("12346", task.getBasketId().getValue());
    }

}
