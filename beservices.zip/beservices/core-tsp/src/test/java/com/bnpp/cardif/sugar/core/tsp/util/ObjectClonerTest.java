package com.bnpp.cardif.sugar.core.tsp.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Test;

import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;

public class ObjectClonerTest {
    @Test
    public void testDeepClone() {
        Document ori = DocumentMockUtil.buildClaimDocument();
        Document clone = ObjectCloner.clone(ori);
        assertFalse(ori == clone);
        assertEquals(ori, clone);
    }
}
