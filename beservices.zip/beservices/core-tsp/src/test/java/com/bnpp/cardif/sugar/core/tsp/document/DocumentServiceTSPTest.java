package com.bnpp.cardif.sugar.core.tsp.document;

import static com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels.ATTRIBUTE;
import static com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators.EQUALS_TO;
import static com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types.STRING;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.AdditionalAnswers.returnsFirstArg;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.core.api.document.DocumentValidator;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.api.task.TaskGeneratorService;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.core.tsp.folder.SecurityContextInitializer;
import com.bnpp.cardif.sugar.core.tsp.task.TaskServiceTSP;
import com.bnpp.cardif.sugar.core.tsp.util.ValidatorHelper;
import com.bnpp.cardif.sugar.dao.api.document.DocumentDAO;
import com.bnpp.cardif.sugar.domain.documentfile.DocumentFileBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.folder.test.FolderMockUtility;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ParentId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.MCODocumentClassType.AllowedChildren;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class DocumentServiceTSPTest {
    private static final String SCOPE = "Syldavia";

    private static final String ISSUER = null;

    private static final String SCHEME = null;

    @Mock
    private DocumentDAO documentDAO;

    @Mock
    private DocumentClassService documentClassService;

    @Mock
    private DocumentFileService documentFileService;

    @Mock
    private IdFactory documentIdFactory;

    @Mock
    private DocumentSecurityHelper documentSecurityHelper;

    @Mock
    private FolderService folderService;

    @Mock
    private AclService aclService;

    @Mock
    private BusinessScopeService businessScopeService;

    @Mock
    private SugarEventBus eventBus;

    @Mock
    private FolderClassService folderClassService;

    @Mock
    private TaskGeneratorService<Document, URI, DocumentFile> taskGenerateService;

    @Mock
    private TaskServiceTSP taskServiceTSP;

    @Mock
    private DocumentValidator validator;

    @InjectMocks
    private final DocumentServiceTSP documentService = new DocumentServiceTSP();

    @Before
    public void setUp() throws SugarTechnicalException, SugarFunctionalException {
        SecurityContextInitializer.initContext();
        when(documentIdFactory.generateDocumentID()).thenReturn(mock(Id.class));
        DocumentClass mockDocClass = mock(DocumentClass.class);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        AllowedChildren allowedChildren = new AllowedChildren(classId, mockDocClass.getLongLabel());
        when(mockDocClass.getAllowedChildren()).thenReturn(Lists.newArrayList(allowedChildren));
        DurationType duration = new DurationType(new BigInteger("1"), "MONTH");
        when(mockDocClass.getRetentionDuration()).thenReturn(duration);
        when(mockDocClass.getClassId()).thenReturn(classId);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));

        when(aclService.getByClassId(any(String.class), any(ClassId.class), any(boolean.class)))
                .thenReturn(mock(AccessControlList.class));
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testStoreOneEnvelopeAndTwoChildrenDocuments() throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = buildEnvelopeIncludingTwoChildrenWithoutId();
        documentService.store(Lists.newArrayList(envelope));

        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).store(storeCaptor.capture());

        List<Document> storedDocuments = storeCaptor.getValue();
        assertEquals(3, storedDocuments.size());
        Document storedEnvelope = storedDocuments.get(0);
        assertEquals(Category.ENVELOPE, storedEnvelope.getCategory());
        assertEquals(storedEnvelope.getChildObject().getId().get(0), storedDocuments.get(1).getId());
        assertEquals(storedEnvelope.getChildObject().getId().get(1), storedDocuments.get(2).getId());
        assertTrue(storedEnvelope.getChildObject().getDocument().isEmpty());

        for (Document storedDocument : storedDocuments) {
            assertNotNull(storedDocument.getData());
            assertNotNull(storedDocument.getData().getCreatnDate());
            assertNotNull(storedDocument.getId());
        }
    }

    @Test
    public void testDeleteAllParents() throws SugarFunctionalException, SugarTechnicalException {
        Document env = DocumentMockUtil.buildEnvelope();

        Document env1 = DocumentMockUtil.buildEnvelope();
        env1.setParentId(new ParentId(env.getId()));
        env.getChildObject().getId().add(env1.getId());
        Document env11 = DocumentMockUtil.buildEnvelope();
        env11.setParentId(new ParentId(env1.getId()));
        env1.getChildObject().getId().add(env11.getId());
        Document claim = DocumentMockUtil.buildClaimDocument();
        claim.setParentId(new ParentId(env11.getId()));
        env11.getChildObject().getId().add(claim.getId());

        when(documentService.get("Syldavia", Lists.newArrayList(env.getId()), false, false))
                .thenReturn(Lists.newArrayList(env));
        when(documentService.get("Syldavia", Lists.newArrayList(env1.getId()), false, false))
                .thenReturn(Lists.newArrayList(env1));
        when(documentService.get("Syldavia", Lists.newArrayList(env11.getId()), false, false))
                .thenReturn(Lists.newArrayList(env11));

        List<Document> documentsToDelete = new ArrayList<Document>();
        Map<Id, Document> documentsToUpdate = new HashMap<Id, Document>();
        documentService.computeParentsToDelete("Syldavia", claim, documentsToDelete, documentsToUpdate);
        assertEquals(4, documentsToDelete.size());
        assertEquals(claim, documentsToDelete.get(0));
        assertEquals(env11, documentsToDelete.get(1));
        assertEquals(env1, documentsToDelete.get(2));
        assertEquals(env, documentsToDelete.get(3));

        assertEquals(0, documentsToUpdate.size());
    }

    @Test
    public void testDeleteAllParentsUntilRootOne() throws SugarFunctionalException, SugarTechnicalException {
        Document env = DocumentMockUtil.buildEnvelope();

        Document env1 = DocumentMockUtil.buildEnvelope();
        env1.setParentId(new ParentId(env.getId()));
        env.getChildObject().getId().add(env1.getId());

        Document env2 = DocumentMockUtil.buildEnvelope();
        env2.setParentId(new ParentId(env.getId()));
        env.getChildObject().getId().add(env2.getId());

        Document env11 = DocumentMockUtil.buildEnvelope();
        env11.setParentId(new ParentId(env1.getId()));
        env1.getChildObject().getId().add(env11.getId());
        Document claim = DocumentMockUtil.buildClaimDocument();
        claim.setParentId(new ParentId(env11.getId()));
        env11.getChildObject().getId().add(claim.getId());

        when(documentService.get("Syldavia", Lists.newArrayList(env.getId()), false, false))
                .thenReturn(Lists.newArrayList(env));
        when(documentService.get("Syldavia", Lists.newArrayList(env1.getId()), false, false))
                .thenReturn(Lists.newArrayList(env1));
        when(documentService.get("Syldavia", Lists.newArrayList(env11.getId()), false, false))
                .thenReturn(Lists.newArrayList(env11));

        List<Document> documentsToDelete = new ArrayList<Document>();
        Map<Id, Document> documentsToUpdate = new HashMap<Id, Document>();
        documentService.computeParentsToDelete("Syldavia", claim, documentsToDelete, documentsToUpdate);
        assertEquals(3, documentsToDelete.size());
        assertEquals(claim, documentsToDelete.get(0));
        assertEquals(env11, documentsToDelete.get(1));
        assertEquals(env1, documentsToDelete.get(2));

        assertEquals(1, documentsToUpdate.size());
        assertEquals(env, Lists.newArrayList(documentsToUpdate.values()).get(0));
        assertFalse(env.getChildObject().getId().contains(env1.getId()));
        assertTrue(env.getChildObject().getId().contains(env2.getId()));
    }

    @Test
    public void testStoreEnvelopesWithChildrenEnvelop() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass mockDocClass = mock(DocumentClass.class);
        ClassId classId = new ClassId(UUID.randomUUID().toString(), "CARDIF", 0);
        when(mockDocClass.isFirstLevel()).thenReturn(false);
        when(mockDocClass.getClassId()).thenReturn(classId);

        Document envelope = DocumentMockUtil.buildEnvelope();
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockDocClass));
        Document childEnvelope = DocumentMockUtil.buildEnvelope();
        envelope.getChildObject().getDocument().add(childEnvelope);
        documentService.store(Lists.newArrayList(envelope));
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testRetentionStartDate() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        Date startDate = DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2000);
        document.getData().setRetentionStartDate(startDate);

        documentService.store(Lists.newArrayList(document));

        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).store(storeCaptor.capture());

        List<Document> storedDocuments = storeCaptor.getValue();
        for (Document storedDocument : storedDocuments) {
            assertNotNull(storedDocument.getData());
            assertNotNull(storedDocument.getData().getCreatnDate());
            assertNotNull(storedDocument.getData().getRetentionEndDate());
            assertTrue(storedDocument.getData().getRetentionEndDate().after(startDate));
        }
    }

    /**
     * Dates can have different milliseconds
     */
    private static void assertDatesEqual(Date date1, Date date2) {
        assertTrue("Dates " + date1 + " and " + date2 + " are not equal !",
                Math.abs(date1.getTime() - date2.getTime()) < 2000);
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testRetentionDateFolderAttached() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();

        List<Document> documentAsList = Lists.newArrayList(document);

        Date startDate = DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2000);
        document.getData().setRetentionStartDate(startDate);

        documentService.store(documentAsList);

        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).store(storeCaptor.capture());

        List<Document> storedDocuments = storeCaptor.getValue();
        for (Document storedDocument : storedDocuments) {
            assertNotNull(storedDocument.getData());
            assertNotNull(storedDocument.getData().getCreatnDate());

            assertDatesEqual(DocumentMockUtil.dateFor(Calendar.JANUARY, 12, 2001),
                    storedDocument.getData().getRetentionEndDate());
        }

        /**
         * Document attachment to a Folder can only occur if document is already
         * stored
         */

        Folder mockedFolder = FolderMockUtility.buildClaimFolder(1);
        mockedFolder.getData().setStatusCode(FolderStatusCodeType.OPEN);
        ArrayList<Folder> mockedFolders = Lists.newArrayList(mockedFolder);
        when(folderService.getAllFoldersAttached(any(Document.class))).thenReturn(mockedFolders);
        when(folderClassService.get(anyListOf(ClassId.class), anyString()))
                .thenReturn(Lists.newArrayList(mock(FolderClass.class)));

        when(documentDAO.fetch(SCOPE, Lists.newArrayList(document.getId()))).thenReturn(documentAsList);

        documentService.update(documentAsList);

        ArgumentCaptor<List> updateCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).update(updateCaptor.capture());

        List<Document> updatedDocuments = updateCaptor.getValue();
        for (Document storedDocument : updatedDocuments) {
            assertNotNull(storedDocument.getData());
            assertNotNull(storedDocument.getData().getCreatnDate());
            assertNull(storedDocument.getData().getRetentionEndDate());
        }
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testRetentionDateNoFolderAttached() throws SugarTechnicalException, SugarFunctionalException {
        ArrayList<Folder> mockedFolders = Lists.newArrayList();
        when(folderService.getAllFoldersAttached(any(Document.class))).thenReturn(mockedFolders);
        Document document = DocumentMockUtil.buildClaimDocument();
        assertEquals(DocumentStatusCode.NEW.toString(), document.getStatus().getCode());
        when(folderClassService.get(anyListOf(ClassId.class), anyString()))
                .thenReturn(Lists.newArrayList(mock(FolderClass.class)));

        Date startDate = DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2000);
        document.getData().setRetentionStartDate(startDate);

        documentService.store(Lists.newArrayList(document));

        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).store(storeCaptor.capture());

        List<Document> storedDocuments = storeCaptor.getValue();
        for (Document storedDocument : storedDocuments) {
            assertNotNull(storedDocument.getData());
            assertNotNull(storedDocument.getData().getCreatnDate());

            // assertEquals(DocumentUtilTest.dateFor(Calendar.JANUARY, 12,
            // 2001), storedDocument.getData()
            // .getRetentionEndDate());
            assertDatesEqual(DocumentMockUtil.dateFor(Calendar.JANUARY, 12, 2001),
                    storedDocument.getData().getRetentionEndDate());
        }
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testRetentionDateFolderClosedAttached() throws SugarTechnicalException, SugarFunctionalException {
        Folder mockedFolder = FolderMockUtility.buildClaimFolder(1);
        mockedFolder.getData().setStatusCode(FolderStatusCodeType.CLOSE);
        mockedFolder.getData().setCloseDate(DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2000));
        ArrayList<Folder> mockedFolders = Lists.newArrayList(mockedFolder);
        when(folderService.getAllFoldersAttached(any(Document.class))).thenReturn(mockedFolders);
        Document document = DocumentMockUtil.buildClaimDocument();
        FolderClass folderClassMocked = mock(FolderClass.class);
        DurationType defaultDuration = new DurationType(new BigInteger("1"), "MONTH");
        when(folderClassMocked.getRetentionDuration()).thenReturn(defaultDuration);
        when(folderClassService.get(anyListOf(ClassId.class), anyString()))
                .thenReturn(Lists.newArrayList(folderClassMocked));

        Date startDate = DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2000);
        document.getData().setRetentionStartDate(startDate);

        documentService.store(Lists.newArrayList(document));

        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).store(storeCaptor.capture());

        List<Document> storedDocuments = storeCaptor.getValue();
        for (Document storedDocument : storedDocuments) {
            assertNotNull(storedDocument.getData());
            assertNotNull(storedDocument.getData().getCreatnDate());
            assertNotNull(storedDocument.getData().getRetentionEndDate());
            assertTrue(storedDocument.getData().getRetentionEndDate().after(startDate));
        }
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testRetentionStartDateNull() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        Date startDate = null;
        document.getData().setRetentionStartDate(startDate);

        documentService.store(Lists.newArrayList(document));

        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).store(storeCaptor.capture());

        List<Document> storedDocuments = storeCaptor.getValue();
        for (Document storedDocument : storedDocuments) {
            assertNotNull(storedDocument.getData());

            assertNotNull(storedDocument.getData().getCreatnDate());
            assertNull(storedDocument.getData().getRetentionEndDate());
        }
    }

    @Test
    public void testStoreOneEnvelopeAndFireEvents() throws Exception {
        Document envelope = buildEnvelopeIncludingTwoChildren();
        List<Document> storedDocuments = documentService.store(Lists.newArrayList(envelope));

        documentService.fireStoreDocEvent(storedDocuments);

        ArgumentCaptor<Event> eventCaptor = ArgumentCaptor.forClass(Event.class);
        verify(eventBus, times(3)).post(eventCaptor.capture());
        assertEquals(3, eventCaptor.getAllValues().size());
        assertEquals(envelope, eventCaptor.getAllValues().get(0).getObject());
        assertEquals(envelope.getId(), eventCaptor.getAllValues().get(0).getId());
    }

    @Test
    public void testGetDocument() throws SugarFunctionalException, SugarTechnicalException {
        List<Id> ids = Lists.newArrayList(new Id());
        documentService.get(SCOPE, ids, false, false);
        verify(documentDAO).fetch(SCOPE, ids);
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testDeleteEnvelope() throws Exception {
        Document envelope = DocumentMockUtil.buildEnvelope();
        Document child1 = DocumentMockUtil.buildClaimDocument();
        Document child2 = DocumentMockUtil.buildClaimDocument();
        attachChildToEnvelope(envelope, child1);
        attachChildToEnvelope(envelope, child2);

        List<Id> ids = Lists.newArrayList(envelope.getId());
        when(documentDAO.fetch(envelope.getScope(), ids)).thenReturn(Lists.newArrayList(envelope));
        when(documentDAO.fetch(envelope.getScope(), Lists.newArrayList(child1.getId(), child2.getId())))
                .thenReturn(Lists.newArrayList(child1, child2));
        when(documentDAO.update(anyListOf(Document.class))).then(returnsFirstArg());
        List<Document> deletedDocs = documentService.delete(Lists.newArrayList(envelope.getId()), envelope.getScope());

        ArgumentCaptor<List> updateCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).update(updateCaptor.capture());
        when(documentDAO.update(anyListOf(Document.class))).thenReturn(updateCaptor.getValue());

        assertEquals(3, deletedDocs.size());
        for (Document deletedDoc : deletedDocs) {
            assertEquals(DocumentStatusCode.DELETED.toString(), deletedDoc.getStatus().getCode());
        }
        assertTrue(ValidatorHelper.getSubListOfDocumentId(deletedDocs).contains(envelope.getId()));
        verify(taskServiceTSP, times(3)).getTasksForDocument(anyString(), any(Id.class));
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testDeleteEnvelopeUnderConstruction() throws Exception {
        Document envelope = DocumentMockUtil.buildEnvelope();
        Document chid1 = DocumentMockUtil.buildClaimDocument();
        Document chid2 = DocumentMockUtil.buildClaimDocument();
        envelope.getData().setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
        chid1.getData().setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
        chid2.getData().setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
        includeChildIntoEnvelope(envelope, chid1);
        includeChildIntoEnvelope(envelope, chid2);

        List<Id> ids = Lists.newArrayList(envelope.getId());
        when(documentDAO.fetch(envelope.getScope(), ids)).thenReturn(Lists.newArrayList(envelope));
        List<Document> deletedDocs = documentService.delete(Lists.newArrayList(envelope.getId()), envelope.getScope());

        ArgumentCaptor<List> deleteCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).delete(anyString(), deleteCaptor.capture());

        List<Id> deletedCaptured = deleteCaptor.getValue();
        assertEquals(3, deletedCaptured.size());
        assertEquals(3, deletedDocs.size());
        for (Document deletedDoc : deletedDocs) {
            assertEquals(DocumentStatusCode.DELETED.toString(), deletedDoc.getStatus().getCode());
        }
        verify(taskServiceTSP, times(3)).getTasksForDocument(anyString(), any(Id.class));
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testDeleteDocumentsIncludedInEnvelope() throws Exception {
        Document envelope = DocumentMockUtil.buildEnvelope();
        Document document = DocumentMockUtil.buildClaimDocument();
        attachChildToEnvelope(envelope, document);
        attachChildToEnvelope(envelope, DocumentMockUtil.buildClaimDocument());

        when(documentDAO.fetch(envelope.getScope(), Lists.newArrayList(envelope.getId())))
                .thenReturn(Lists.newArrayList(envelope));
        when(documentDAO.fetch(envelope.getScope(), Lists.newArrayList(document.getId())))
                .thenReturn(Lists.newArrayList(document));
        when(documentDAO.update(anyListOf(Document.class))).then(returnsFirstArg());
        List<Document> deletedDocs = documentService.delete(Lists.newArrayList(document.getId()), envelope.getScope());

        ArgumentCaptor<List> updateCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).update(updateCaptor.capture());
        when(documentDAO.update(anyListOf(Document.class))).thenReturn(updateCaptor.getValue());

        assertEquals(1, deletedDocs.size());
        for (Document deletedDoc : deletedDocs) {

            assertEquals(deletedDoc.getStatus().getCode(), "DELETED");
        }
        assertEquals(document.getId(), deletedDocs.get(0).getId());
        verify(taskServiceTSP, times(1)).getTasksForDocument(anyString(), any(Id.class));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testDeleteDocumentsAttachedClosedFolder() throws Exception {

        Folder mockedFolder = FolderMockUtility.buildClaimFolder(1);
        mockedFolder.getData().setStatusCode(FolderStatusCodeType.CLOSE);
        mockedFolder.getData().setCloseDate(DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2000));
        ArrayList<Folder> mockedFolders = Lists.newArrayList(mockedFolder);
        when(folderService.getAllFoldersAttached(any(Document.class))).thenReturn(mockedFolders);
        Document document = DocumentMockUtil.buildClaimDocument();

        Document envelope = DocumentMockUtil.buildEnvelope();
        attachChildToEnvelope(envelope, document);

        when(documentDAO.fetch(envelope.getScope(), Lists.newArrayList(envelope.getId())))
                .thenReturn(Lists.newArrayList(envelope));
        when(documentDAO.fetch(envelope.getScope(), Lists.newArrayList(document.getId())))
                .thenReturn(Lists.newArrayList(document));

        documentService.delete(Lists.newArrayList(envelope.getId()), envelope.getScope());
    }

    @Test
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public void testDeleteDocumentsAttachedOpenFolder() throws Exception {
        Folder mockedFolder = FolderMockUtility.buildClaimFolder(1);
        mockedFolder.getData().setStatusCode(FolderStatusCodeType.OPEN);

        ArrayList<Folder> mockedFolders = Lists.newArrayList(mockedFolder);

        Document document = DocumentMockUtil.buildClaimDocument();
        Document envelope = DocumentMockUtil.buildEnvelope();
        attachChildToEnvelope(envelope, document);

        mockedFolder.getChildComponents().getId().add(document.getId());
        mockedFolder.getChildComponents().getDocument().add(document);

        List<Id> idsEnvelope = Lists.newArrayList(envelope.getId());
        List<Id> idsDocument = Lists.newArrayList(document.getId());

        when(folderService.getAllFoldersAttached(any(Document.class))).thenReturn(mockedFolders);

        when(documentDAO.fetch(envelope.getScope(), idsEnvelope)).thenReturn(Lists.newArrayList(envelope));
        when(documentDAO.fetch(envelope.getScope(), idsDocument)).thenReturn(Lists.newArrayList(document));
        documentService.delete(Lists.newArrayList(envelope.getId()), envelope.getScope());
        ArgumentCaptor<List> updateCaptor = ArgumentCaptor.forClass(List.class);
        verify(folderService).update(updateCaptor.capture(), Mockito.anyString());
        when(folderService.update(anyListOf(Folder.class), anyString())).thenReturn(updateCaptor.getValue());

        List<Folder> updatedFolder = updateCaptor.getValue();
        assertFalse(updatedFolder.get(0).getChildComponents().getId().contains(document.getId()));
    }

    @Test
    public void testGetEnvelopeIncludingChildren() throws SugarFunctionalException, SugarTechnicalException {
        Document envelope = DocumentMockUtil.buildEnvelope();
        Id id1 = generateDocumentID();
        Id id2 = generateDocumentID();
        envelope.getChildObject().getId().add(id1);
        envelope.getChildObject().getId().add(id2);
        when(documentDAO.fetch(SCOPE, Lists.newArrayList(envelope.getId()))).thenReturn(Lists.newArrayList(envelope));
        Document claimDocument1 = DocumentMockUtil.buildClaimDocument();
        Document claimDocument2 = DocumentMockUtil.buildClaimDocument();
        claimDocument1.setId(id1);
        claimDocument2.setId(id2);
        when(documentDAO.fetch(SCOPE, Lists.newArrayList(id1, id2)))
                .thenReturn(Lists.newArrayList(claimDocument1, claimDocument1));

        List<Id> ids = Lists.newArrayList(envelope.getId());

        documentService.get(SCOPE, ids, true, false);

        verify(documentDAO).fetch(SCOPE, ids);
    }

    @Test
    public void testGetEnvelopeIncludingChildrenWithoutChild()
            throws SugarFunctionalException, SugarTechnicalException {
        Document envelope = buildEnvelopeIncludingTwoChildrenWithoutId();
        envelope.setChildObject(null);
        when(documentDAO.fetch(SCOPE, Lists.newArrayList(envelope.getId()))).thenReturn(Lists.newArrayList(envelope));
        List<Id> ids = Lists.newArrayList(envelope.getId());
        documentService.get(SCOPE, ids, true, false);
        verify(documentDAO).fetch(SCOPE, ids);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testGetDocumentFails() throws SugarFunctionalException, SugarTechnicalException {
        documentService.get(SCOPE, new ArrayList<Id>(), false, false);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testFind() throws Exception {
        long start = 0;
        long max = 0;
        SearchResults<Document> resultsMock = mock(SearchResults.class);
        when(documentDAO.find(anyString(), any(Criteria.class), any(OrderClause.class), anyLong(), anyLong()))
                .thenReturn(resultsMock);

        Criteria criteria = new Criteria();
        criteria.getCriterionList()
                .add(new Criterion(ATTRIBUTE, "Scope", EQUALS_TO, STRING, Lists.newArrayList(SCOPE)));
        SearchResults<Document> results = documentService.find(criteria, null, start, max);

        verify(documentDAO).find(SCOPE, criteria, null, start, max);
        assertEquals(resultsMock, results);
    }

    @SuppressWarnings("unchecked")
    @Test(expected = SugarTechnicalException.class)
    public void testFindFailsFromDAO() throws Exception {
        when(documentDAO.find(anyString(), any(Criteria.class), any(OrderClause.class), anyLong(), anyLong()))
                .thenThrow(SugarTechnicalException.class);
        Criteria criteria = new Criteria();
        criteria.getCriterionList()
                .add(new Criterion(ATTRIBUTE, "Scope", EQUALS_TO, STRING, Lists.newArrayList(SCOPE)));
        documentService.find(criteria, null, 0, 0);
    }

    @Test
    public void testUpdateOneDocument() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass mockedDocumentClass = Mockito.mock(DocumentClass.class);
        // Document documentToFetch = DocumentUtilTest.buildClaimDocument();

        DurationType defaultDuration = new DurationType(new BigInteger("1"), "MONTH");
        when(mockedDocumentClass.getRetentionDuration()).thenReturn(defaultDuration);
        when(documentClassService.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockedDocumentClass));

        Document document = DocumentMockUtil.buildClaimDocument();
        Calendar cal = Calendar.getInstance();
        cal.set(2000, Calendar.DECEMBER, 12);
        document.getData().setUpdtDate(cal.getTime());
        Date startDate = DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2000);
        document.getData().setRetentionStartDate(startDate);
        List<Document> documents = Lists.newArrayList(document);

        when(documentDAO.fetch(anyString(), anyListOf(Id.class))).thenReturn(Lists.newArrayList(documents));
        when(documentDAO.update(anyListOf(Document.class))).thenReturn(documents);
        List<Document> updatedDocuments = documentService.update(documents);

        verify(documentDAO).update(documents);
        /*
         * 2 EVENTS = 1 READ (when fetching old revision of document) + 1 UPDATE
         */
        verify(eventBus, times(2)).post(any(Event.class));
        assertEquals(1, updatedDocuments.size());

        Document storedDocument = updatedDocuments.get(0);
        assertNotNull(storedDocument.getData().getUpdtDate());
        assertEquals(document.getId(), storedDocument.getId());
        // assertTrue(storedDocument.getData().getRetentionEndDate().after(startDate));

        assertFalse(storedDocument.getData().getUpdtDate().equals(cal.getTime()));
    }

    @Test
    public void testGetOneDocumentWithOneDocumentFile() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildClaimDocument();

        document.setFileData(new FileData());
        document.getFileData().getURI().add("URI");
        List<Document> documents = Lists.newArrayList(document);
        when(documentDAO.fetch(anyString(), anyListOf(Id.class))).thenReturn(documents);
        when(documentFileService.get(anyString(), anyListOf(URI.class)))
                .thenReturn(Lists.newArrayList(new DocumentFile()));
        Id id = new Id();
        List<Document> fetchedDocuments = documentService.get(SCOPE, Lists.newArrayList(id), true, true);
        verify(documentFileService).get(SCOPE, Lists.newArrayList(new URI("URI")));
        assertFalse(fetchedDocuments.get(0).getFileData().getDocumentFile().isEmpty());
        assertTrue(fetchedDocuments.get(0).getFileData().getURI().isEmpty());
    }

    @Test(expected = SugarTechnicalException.class)
    public void testUpdateOneDocumentWithNoId() throws SugarTechnicalException, SugarFunctionalException {
        Document document = DocumentMockUtil.buildMedicalReportWithoutId();
        Calendar cal = Calendar.getInstance();
        cal.set(2000, Calendar.DECEMBER, 12);
        document.getData().setUpdtDate(cal.getTime());
        List<Document> documents = Lists.newArrayList(document);

        when(documentDAO.update(anyListOf(Document.class))).thenReturn(documents);
        documentService.update(documents);
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testUpdateOneEnvelopeAndTwoChildrenDocuments()
            throws SugarTechnicalException, SugarFunctionalException {
        Document envelope = buildEnvelopeIncludingTwoChildren();
        envelope.getData().setUpdtDate(DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2000));
        List<Document> documents = Lists.newArrayList(envelope);

        Document child1 = envelope.getChildObject().getDocument().get(0);
        Document child2 = envelope.getChildObject().getDocument().get(1);

        when(documentDAO.fetch(child1.getScope(), Lists.newArrayList(envelope.getId(), child1.getId(), child2.getId())))
                .thenReturn(Lists.newArrayList(envelope, child1, child2));
        when(documentDAO.fetch(envelope.getScope(), Lists.newArrayList(envelope.getId())))
                .thenReturn(Lists.newArrayList(envelope));

        documentService.update(documents);
        ArgumentCaptor<List> updateCaptor = ArgumentCaptor.forClass(List.class);
        verify(documentDAO).update(updateCaptor.capture());

        List<Document> updatedDocuments = updateCaptor.getValue();

        assertEquals(3, updatedDocuments.size());
        /*
         * 4 = 1 READ ( when fetching old revisions) + 3 UPDATE
         */
        verify(eventBus, times(4)).post(any(Event.class));

        for (Document updatedDocument : updatedDocuments) {
            assertNotNull(updatedDocument.getData().getUpdtDate());
        }
    }

    @Test(expected = SugarFunctionalException.class)
    public void testUpdateDocumentsWithUpdateDateBeforeCreation()
            throws SugarFunctionalException, SugarTechnicalException {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, 1);
        Document document = DocumentMockUtil.buildClaimDocument();
        Document documentToFetch = DocumentMockUtil.buildClaimDocument();
        documentToFetch.setId(document.getId());
        documentToFetch.getData().setCreatnDate(cal.getTime());
        when(documentDAO.fetch(document.getScope(), Lists.newArrayList(document.getId())))
                .thenReturn(Lists.newArrayList(documentToFetch));
        documentService.update(Lists.newArrayList(document));
    }

    @Test
    public void testUpdateCreationDate() throws SugarFunctionalException, SugarTechnicalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        Document documentToFetch = DocumentMockUtil.buildClaimDocument();
        when(documentDAO.fetch(anyString(), anyListOf(Id.class))).thenReturn(Lists.newArrayList(documentToFetch));
        document.getData().setCreatnDate(DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2010));
        document.getData().setUpdtDate(new Date());
        documentService.checkDocumentDates(documentToFetch, document);
        assertNotEquals(DocumentMockUtil.dateFor(Calendar.DECEMBER, 12, 2010), document.getData().getCreatnDate());
        assertEquals(documentToFetch.getData().getCreatnDate(), document.getData().getCreatnDate());
    }

    @Test
    public void testReplaceDocumentFilesByItsURI() throws Exception {
        Document document = new Document();
        document.setFileData(new FileData());

        DocumentFile file1 = DocumentFileBuilder.scope("syldavia").URI("uri1").build();
        document.getFileData().getDocumentFile().add(file1);
        DocumentFile file2 = DocumentFileBuilder.scope("syldavia").URI("uri2").build();
        document.getFileData().getDocumentFile().add(file2);

        documentService.replaceDocumentFilesByItsURI(document);

        assertTrue(document.getFileData().getDocumentFile().isEmpty());
        assertEquals(2, document.getFileData().getURI().size());
        assertTrue(document.getFileData().getURI().contains(file1.getURI()));
        assertTrue(document.getFileData().getURI().contains(file2.getURI()));
    }

    private Document buildEnvelopeIncludingTwoChildrenWithoutId() {
        Document envelope = DocumentMockUtil.buildEnvelope();
        envelope.getChildObject().getDocument().add(DocumentMockUtil.buildMedicalReportWithoutId());
        envelope.getChildObject().getDocument().add(DocumentMockUtil.buildMedicalReportWithoutId());

        return envelope;
    }

    private Document buildEnvelopeIncludingTwoChildren() {
        Document envelope = DocumentMockUtil.buildEnvelope();
        envelope.getChildObject().getDocument().add(DocumentMockUtil.buildClaimDocument());
        envelope.getChildObject().getDocument().add(DocumentMockUtil.buildClaimDocument());

        return envelope;
    }

    private void attachChildToEnvelope(Document envelope, Document child) {
        envelope.getChildObject().getId().add(child.getId());
        child.setParentId(new ParentId(envelope.getId()));
    }

    private void includeChildIntoEnvelope(Document envelope, Document child) {
        envelope.getChildObject().getDocument().add(child);
        child.setParentId(new ParentId(envelope.getId()));
    }

    private Id generateDocumentID() {
        Id id = new Id();
        id.setIssuer(ISSUER);
        id.setScheme(SCHEME);
        id.setValue(UUID.randomUUID().toString());
        return id;
    }
}
