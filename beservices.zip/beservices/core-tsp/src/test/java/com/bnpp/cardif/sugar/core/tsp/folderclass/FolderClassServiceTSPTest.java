package com.bnpp.cardif.sugar.core.tsp.folderclass;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassValidator;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.folderclass.FolderClassDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.folderclass.test.FolderClassMockUtility;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class FolderClassServiceTSPTest {
    private static final String SCOPE = "fakeScope";

    @Mock
    private FolderClassDAO folderClassDAO;

    @Mock
    private SugarEventBus eventBus;

    @Mock
    private AclService aclService;

    @Mock
    private DocumentSecurityHelper documentSecurityHelper;

    @Mock
    private IdFactory classIdFactory;

    @Mock
    private FolderClassValidator folderClassValidator;

    @InjectMocks
    private FolderClassServiceTSP folderClassServiceTSP;

    @Before
    public void setUp() throws SugarTechnicalException, SugarFunctionalException {
        when(aclService.getByClassId(anyString(), any(ClassId.class), anyBoolean()))
                .thenReturn(mock(AccessControlList.class));
    }

    @Test
    public void testAddDocumentClassAndAddDefaultACL() throws Exception {
        List<FolderClass> fakeClasses = Lists.newArrayList(buildFolderClass(), buildFolderClass());
        folderClassServiceTSP.add(fakeClasses);

        ArgumentCaptor<List> storeCaptor = ArgumentCaptor.forClass(List.class);
        verify(folderClassDAO).add(storeCaptor.capture());
        List<FolderClass> storedClasses = storeCaptor.getValue();
        for (FolderClass storedClass : storedClasses) {
            assertNotNull(storedClass.getCreationDate());
            assertNotNull(storedClass.getUpdateDate());
        }

        ArgumentCaptor<String> scopeCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<ClassId> classCaptor = ArgumentCaptor.forClass(ClassId.class);
        verify(aclService, times(2)).assignDefault(scopeCaptor.capture(), classCaptor.capture());
        assertEquals(fakeClasses.get(0).getScope(), scopeCaptor.getAllValues().get(0));
        assertEquals(fakeClasses.get(0).getClassId(), classCaptor.getAllValues().get(0));
        assertEquals(fakeClasses.get(1).getScope(), scopeCaptor.getAllValues().get(1));
        assertEquals(fakeClasses.get(1).getClassId(), classCaptor.getAllValues().get(1));
    }

    @Test(expected = SugarFunctionalException.class)
    public void testAddDocumentClassWithNoLongLabel() throws Exception {
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00204)).when(folderClassValidator)
                .checkCreationValidity(anyListOf(FolderClass.class));

        List<FolderClass> fakeClasses = Lists.newArrayList(buildFolderClass());
        fakeClasses.get(0).setLongLabel("");
        folderClassServiceTSP.add(fakeClasses);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testAddDocumentClassWithAlreadyExistingLabel() throws Exception {
        List<FolderClass> fakeClasses = Lists.newArrayList(buildFolderClass());
        fakeClasses.get(0).setLongLabel("Contract");
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00205, "Contract"))
                .when(folderClassValidator).checkCreationValidity(anyListOf(FolderClass.class));

        folderClassServiceTSP.add(fakeClasses);
    }

    @Test
    public void testUpdateTwoDocumentClassesChangingVersion() throws Exception {
        List<FolderClass> classes = Lists.newArrayList(buildFolderClass(), buildFolderClass());
        FolderClass activeClass = classes.get(1);
        activeClass.setActive(true);
        when(folderClassDAO.get(anyListOf(ClassId.class), anyString())).thenReturn(classes);
        folderClassServiceTSP.update(classes, true);

        verify(folderClassDAO, times(1)).add(classes);
        verify(folderClassDAO, times(0)).update(classes);
        verify(aclService, times(4)).assignToClass(anyString(), any(AclId.class), any(ClassId.class), anyBoolean());
        verify(folderClassValidator).checkUpdateValidity(classes);
    }

    @Test
    public void testUpdateFolderClassWithoutChangeVersion() throws Exception {
        List<FolderClass> classes = Lists.newArrayList(buildFolderClass(), buildFolderClass());
        when(folderClassDAO.get(anyListOf(ClassId.class), anyString())).thenReturn(classes);
        FolderClass activeClass = classes.get(1);
        activeClass.setActive(true);
        folderClassServiceTSP.update(classes, false);

        verify(folderClassDAO, times(0)).add(classes);
        verify(folderClassDAO, times(1)).update(classes);
        verify(folderClassValidator).checkUpdateValidity(classes);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testUpdateCheckingKO() throws Exception {
        List<FolderClass> classes = Lists.newArrayList(buildFolderClass(), buildFolderClass());
        FolderClass activeClass = classes.get(1);
        activeClass.setActive(true);
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.G666)).when(folderClassValidator)
                .checkUpdateValidity(anyListOf(FolderClass.class));
        folderClassServiceTSP.update(classes, false);
    }

    @Test
    public void testGet() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass clazz = buildFolderClass();
        when(folderClassDAO.get(Lists.newArrayList(clazz.getClassId()), SCOPE)).thenReturn(Lists.newArrayList(clazz));

        List<FolderClass> result = folderClassServiceTSP.get(Lists.newArrayList(clazz.getClassId()), SCOPE);
        assertEquals(1, result.size());
        assertEquals(clazz, result.get(0));
    }

    @Test
    public void testGetAll() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass activeClass = buildFolderClass();

        when(folderClassDAO.get(Lists.newArrayList(activeClass.getClassId()), SCOPE))
                .thenReturn(Lists.newArrayList(activeClass));
        when(folderClassDAO.getAll(SCOPE, true)).thenReturn(Lists.newArrayList(activeClass));

        List<FolderClass> result = folderClassServiceTSP.getAll(SCOPE, true);
        assertEquals(1, result.size());
        assertEquals(activeClass, result.get(0));
    }

    @Test
    public void testActivate() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass firstVersion = FolderClassMockUtility.buildFolderClassContractManagement();
        firstVersion.setActive(true);
        firstVersion.getClassId().setVersId(0);
        FolderClass secondVersion = FolderClassMockUtility.buildFolderClassContractManagement();
        ClassId firstVersionClassId = firstVersion.getClassId();
        secondVersion.setClassId(new ClassId(firstVersionClassId.getValue(), firstVersionClassId.getIssuer(),
                firstVersionClassId.getVersId() + 1));
        secondVersion.setActive(true);
        when(folderClassDAO.get(anyListOf(ClassId.class), anyString())).thenReturn(Lists.newArrayList(firstVersion));
        when(folderClassDAO.getAllVersions(anyListOf(ClassId.class), anyString()))
                .thenReturn(Lists.newArrayList(firstVersion, secondVersion));

        folderClassServiceTSP.setActive(Lists.newArrayList(firstVersion.getClassId()), true, firstVersion.getScope());
        ArgumentCaptor<List> captor = ArgumentCaptor.forClass(List.class);
        verify(folderClassDAO, times(2)).setActive(captor.capture(), anyBoolean(), anyString(), any(Date.class));
        // verify(folderClassDAO, times(1)).setActive(captor.capture(), false,
        // firstVersion.getScope(), any(Date.class));
        List<ClassId> activeClazz = captor.getAllValues().get(0);
        assertEquals(1, activeClazz.size());
        assertEquals(0, activeClazz.get(0).getVersId());
        List<ClassId> notActiveClazz = captor.getAllValues().get(1);
        assertEquals(1, notActiveClazz.size());
        assertEquals(1, notActiveClazz.get(0).getVersId());
    }

    private FolderClass buildFolderClass() {
        FolderClass clazz = new FolderClass();
        clazz.setClassId(new ClassId(UUID.randomUUID().toString(), "TOTO", 0));
        clazz.setScope(SCOPE);
        clazz.setActive(true);
        clazz.setLongLabel("my component class " + Math.random());
        return clazz;
    }

    @After
    public void tearDown() {
    }
}
