package com.bnpp.cardif.sugar.core.tsp.folder;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpp.cardif.sugar.security.SecurityHelper;
import com.bnppa.sesame.services.common.model.UserIdentity;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.SugarRoles;
import com.google.common.collect.Lists;

public class SecurityContextInitializer {
    private static final String USERNAME = "jakadi";

    private static final String PASSWORD = "iconnect";

    private static final String FIRSTNAME = "Jacques";

    private static final String LASTNAME = "KADI";

    private static final String AUTHORITY = SugarRoles.SUGAR_ADMIN.name();

    private static final String ALLOWED_SCOPE = "Syldavia";

    public static void initContext() {
        UserIdentity userIdentity = new UserIdentity();
        userIdentity.setFirstName(FIRSTNAME);
        userIdentity.setLastName(LASTNAME);

        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(AUTHORITY));

        AuthenticatedUser user = new AuthenticatedUser(USERNAME, PASSWORD, null, FIRSTNAME, LASTNAME,
                grantedAuthorities, "test version");
        user.setBusinessScopes(Lists.newArrayList(ALLOWED_SCOPE));
        user.setAuthorities(grantedAuthorities);
        Authentication actualAuthentication = new UsernamePasswordAuthenticationToken(user, null,
                user.getAuthorities());

        SecurityContextHolder.getContext().setAuthentication(actualAuthentication);
    }
}
