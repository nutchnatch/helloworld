package com.bnpp.cardif.sugar.security;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bnppa.sesame.services.common.model.UserIdentity;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.SugarRoles;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class SecurityHelperTest {

    private static final String USERNAME = "jakadi";

    private static final String PASSWORD = "iconnect";

    private static final String FIRSTNAME = "Jacques";

    private static final String LASTNAME = "KADI";

    private static final String AUTHORITY = SugarRoles.SUGAR_ADMIN.name();

    private static final String ALLOWED_SCOPE = "Syldavia";
    
    @InjectMocks
    private SecurityHelper securityHelper = new SecurityHelper();

    @Before
    public void init() {
        UserIdentity userIdentity = new UserIdentity();
        userIdentity.setFirstName(FIRSTNAME);
        userIdentity.setLastName(LASTNAME);

        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority(AUTHORITY));

        AuthenticatedUser user = new AuthenticatedUser(USERNAME, PASSWORD, null, FIRSTNAME, LASTNAME,
                grantedAuthorities, "test version");
        user.setBusinessScopes(Lists.newArrayList(ALLOWED_SCOPE));
        user.setAuthorities(grantedAuthorities);
        Authentication actualAuthentication = new UsernamePasswordAuthenticationToken(user, null,
                user.getAuthorities());

        SecurityContextHolder.getContext().setAuthentication(actualAuthentication);
        securityHelper.setIsSecurityEnabled(true);
    }

    @Test
    public void testIsAdmin() {
        assertTrue(securityHelper.isAdmin());
    }

    @Test
    public void testIsUserAllowedInScope() {
        assertTrue(securityHelper.isUserAllowedInScope(ALLOWED_SCOPE));
        assertFalse(securityHelper.isUserAllowedInScope("Gopal"));
    }
}
