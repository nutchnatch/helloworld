package com.bnpp.cardif.sugar.core.tsp.documentclass;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.security.SecurityHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class DocumentClassValidatorTSPTest {
    @Mock
    TagClassValidator tagClassValidator;

    @Mock
    DocumentClassService documentClassService;

    @Mock
    BusinessScopeValidator businessScopeValidator;
    
    @Mock
    private SecurityHelper securityHelper;

    @InjectMocks
    DocumentClassValidator validator = new DocumentClassValidatorTSP();

    @Before
    public void setUp() throws Exception {
        securityHelper.setIsSecurityEnabled(true);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreateWithNoName() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setScope("Syldavia");
        validator.checkCreationValidity(Lists.newArrayList(documentClass));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreateWithExistName() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        DocumentClass fetched1 = new DocumentClass();
        fetched1.setLongLabel("testClass1");
        fetched1.setScope("Syldavia");
        DocumentClass fetched = new DocumentClass();
        fetched.setLongLabel("testClass");
        fetched.setScope("Syldavia");
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenReturn(Lists.newArrayList(fetched, fetched1));
        validator.checkCreationValidity(Lists.newArrayList(documentClass));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreateWithoutCategory() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        DocumentClass fetched1 = new DocumentClass();
        fetched1.setLongLabel("testClass1");
        DocumentClass fetched = new DocumentClass();
        fetched.setLongLabel("testClass1");
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenReturn(Lists.newArrayList(fetched, fetched1));
        validator.checkCreationValidity(Lists.newArrayList(documentClass));
        verify(documentClassService).search(anyString(), any(Category.class), anyBoolean());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreateWithoutRetentionDuration() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        documentClass.setCategory(Category.DOCUMENT);
        DocumentClass fetched1 = new DocumentClass();
        fetched1.setLongLabel("testClass1");

        DocumentClass fetched = new DocumentClass();
        fetched.setLongLabel("testClass1");
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenReturn(Lists.newArrayList(fetched, fetched1));
        validator.checkCreationValidity(Lists.newArrayList(documentClass));
        verify(documentClassService).search(anyString(), any(Category.class), anyBoolean());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreateWithoutRetentionDurationTimeUnit()
            throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        documentClass.setCategory(Category.DOCUMENT);
        DocumentClass fetched1 = new DocumentClass();
        fetched1.setLongLabel("testClass1");
        documentClass.setRetentionDuration(new DurationType(new BigInteger("1"), null));
        DocumentClass fetched = new DocumentClass();
        fetched.setLongLabel("testClass1");
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenReturn(Lists.newArrayList(fetched, fetched1));
        validator.checkCreationValidity(Lists.newArrayList(documentClass));
        verify(documentClassService).search(anyString(), any(Category.class), anyBoolean());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreateWithWrongRetentionDurationTimeUnit()
            throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        documentClass.setCategory(Category.DOCUMENT);
        DocumentClass fetched1 = new DocumentClass();
        fetched1.setLongLabel("testClass1");
        documentClass.setRetentionDuration(new DurationType(new BigInteger("1"), "TOTO"));
        DocumentClass fetched = new DocumentClass();
        fetched.setLongLabel("testClass1");
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenReturn(Lists.newArrayList(fetched, fetched1));
        validator.checkCreationValidity(Lists.newArrayList(documentClass));
        verify(documentClassService).search(anyString(), any(Category.class), anyBoolean());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreateWithoutRetentionDurationValue()
            throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        documentClass.setCategory(Category.DOCUMENT);
        DocumentClass fetched1 = new DocumentClass();
        fetched1.setLongLabel("testClass1");
        documentClass.setRetentionDuration(new DurationType(null, "DAY"));
        DocumentClass fetched = new DocumentClass();
        fetched.setLongLabel("testClass1");
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenReturn(Lists.newArrayList(fetched, fetched1));
        validator.checkCreationValidity(Lists.newArrayList(documentClass));
        verify(documentClassService).search(anyString(), any(Category.class), anyBoolean());

    }

    @Test
    public void testCheckCreateOK() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        documentClass.setCategory(Category.DOCUMENT);
        documentClass.setRetentionDuration(new DurationType(new BigInteger("1"), "DAY"));
        DocumentClass fetched1 = new DocumentClass();
        fetched1.setLongLabel("testClass1");

        DocumentClass fetched = new DocumentClass();
        fetched.setLongLabel("testClass1");
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenReturn(Lists.newArrayList(fetched, fetched1));
        validator.checkCreationValidity(Lists.newArrayList(documentClass));
        verify(documentClassService).search(anyString(), any(Category.class), anyBoolean());

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCheckCreateWithDifferentScopes() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        DocumentClass documentClass1 = new DocumentClass();
        documentClass1.setLongLabel("testClass1");
        documentClass1.setScope("Gopal");

        validator.checkCreationValidity(Lists.newArrayList(documentClass, documentClass1));
    }

    @Test(expected = SugarFunctionalException.class)
    public void updateChangingLongLabel() throws SugarTechnicalException, SugarFunctionalException {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setLongLabel("testClass");
        documentClass.setScope("Syldavia");
        documentClass.setCategory(Category.DOCUMENT);
        documentClass.setClassId(new ClassId(UUID.randomUUID().toString(), "issuer", 0));
        documentClass.setRetentionDuration(new DurationType(new BigInteger("1"), "DAY"));
        DocumentClass fetched = new DocumentClass();
        fetched.setLongLabel("testClass1");
        fetched.setClassId(documentClass.getClassId());
        when(documentClassService.get(anyString(), Mockito.anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(fetched));
        validator.checkUpdateValidity(Lists.newArrayList(documentClass));
    }
}
