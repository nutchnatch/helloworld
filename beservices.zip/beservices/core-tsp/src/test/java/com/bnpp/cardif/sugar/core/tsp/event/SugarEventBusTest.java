package com.bnpp.cardif.sugar.core.tsp.event;

import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.DOCUMENT;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.google.common.collect.Lists;

public class SugarEventBusTest {
    private List<Event> handledEvents;

    private SugarEventBus eventBus;

    @Before
    public void setUp() throws Exception {
        eventBus = new SugarEventBus();
        handledEvents = new ArrayList<Event>();
    }

    @Test
    public void testRegisterAndPostOneNonAllowedEvent() {
        TestSubscriber subscriber = new TestSubscriber();
        subscriber.getRegisteredEvents().clear();

        eventBus.register(subscriber);
        eventBus.post(new TestEvent<String>());
        assertEquals(0, handledEvents.size());
    }

    @Test
    public void testRegisterAndPostOneCreateComponentEvent() {
        TestSubscriber subscriber = new TestSubscriber();
        subscriber.getRegisteredEvents().put(ObjectType.DOCUMENT, Lists.newArrayList(Action.CREATE));
        eventBus.register(subscriber);

        Document document = DocumentMockUtil.buildClaimDocument();
        Event event = new Event("Syldavia", DOCUMENT, CREATE, document, document.getId());
        eventBus.post(event);

        assertEquals(1, handledEvents.size());
        assertEquals(event, handledEvents.get(0));
        assertEquals(document, handledEvents.get(0).getObject());
        assertEquals(document.getId(), handledEvents.get(0).getId());
    }

    @Test
    public void testRegisterEventAndPostOneUpdateComponentEvent() {
        TestSubscriber subscriber = new TestSubscriber();
        subscriber.getRegisteredEvents().put(ObjectType.DOCUMENT, Lists.newArrayList(Action.UPDATE));
        eventBus.register(subscriber);

        Document document = DocumentMockUtil.buildClaimDocument();
        Event event = new Event("Syldavia", DOCUMENT, UPDATE, document, document.getId());
        eventBus.post(event);
        assertEquals(1, handledEvents.size());
        assertEquals(event, handledEvents.get(0));
        assertEquals(document, handledEvents.get(0).getObject());
        assertEquals(document.getId(), handledEvents.get(0).getId());
    }

    private class TestEvent<T> extends Event {
        public TestEvent() {
            super("", null, null, null, null);
        }

        @Override
        public ObjectType getObjectType() {
            return null;
        }

        @Override
        public Action getAction() {
            return null;
        }

        @Override
        public String getId() {
            return "";
        }
    }

    private class TestSubscriber extends EventSubscriber {
        @Override
        protected void onEvent(Event event) {
            handledEvents.add(event);
        }
    }
}