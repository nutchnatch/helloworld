package com.bnpp.cardif.sugar.core.tsp.fact;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;

@RunWith(MockitoJUnitRunner.class)
public class ReportingValidatorTSPTest {

    private static final String SCOPE = "Syldavia";

    @Mock
    BusinessScopeValidator scopeValidator;

    @InjectMocks
    ReportingValidatorTSP reportingValidator = new ReportingValidatorTSP();

    @Test(expected = SugarFunctionalException.class)
    public void testStartingDateAfterEndingDate() throws SugarTechnicalException, SugarFunctionalException {
        Date endingDate = new Date();
        Date startingDate = new Date(endingDate.getTime() + (1000 * 60 * 60 * 24));
        reportingValidator.validateScopeAndDates(SCOPE, startingDate, endingDate);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testEndingDateAfterCurrentDate() throws SugarTechnicalException, SugarFunctionalException {
        Date today = new Date();
        Date endingDate = new Date(today.getTime() + (1000 * 60 * 60 * 24));
        Date startingDate = today;
        reportingValidator.validateScopeAndDates(SCOPE, startingDate, endingDate);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testNullStartingDate() throws SugarTechnicalException, SugarFunctionalException {
        Date endingDate = new Date();
        reportingValidator.validateScopeAndDates(SCOPE, null, endingDate);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testNullEndingDate() throws SugarTechnicalException, SugarFunctionalException {
        Date startinDate = new Date();
        reportingValidator.validateScopeAndDates(SCOPE, startinDate, null);
    }
}
