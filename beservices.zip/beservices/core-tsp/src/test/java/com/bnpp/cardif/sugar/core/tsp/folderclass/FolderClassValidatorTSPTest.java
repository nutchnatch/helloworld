package com.bnpp.cardif.sugar.core.tsp.folderclass;

import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigInteger;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class FolderClassValidatorTSPTest {
    @Mock
    FolderClassService folderClassService;

    @Mock
    TagClassValidator tagClassValidator;

    @Mock
    BusinessScopeValidator businessScopeValidator;

    @InjectMocks
    FolderClassValidator folderClassValidator = new FolderClassValidatorTSP();

    @Test(expected = SugarFunctionalException.class)
    public void testCreationValidityNoName() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass clazz = new FolderClass();
        clazz.setScope("Syldavia");
        folderClassValidator.checkCreationValidity(Lists.newArrayList(clazz));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCreationValidityExistingName() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass clazz = new FolderClass();
        clazz.setScope("Syldavia");
        clazz.setLongLabel("FakeFolder");

        FolderClass fetchedClass = new FolderClass();
        fetchedClass.setScope("Syldavia");
        fetchedClass.setLongLabel("FakeFolder");
        when(folderClassService.getAll(anyString(), anyBoolean())).thenReturn(Lists.newArrayList(fetchedClass));

        folderClassValidator.checkCreationValidity(Lists.newArrayList(clazz));

    }

    @Test(expected = SugarFunctionalException.class)
    public void testCreationValidityNoExistingTag() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass clazz = new FolderClass();
        clazz.setScope("Syldavia");
        clazz.setLongLabel("FakeFolder");
        doThrow(ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00206, "TagTest"))
                .when(tagClassValidator).checkExistence(anyString(), anyListOf(String.class));
        folderClassValidator.checkCreationValidity(Lists.newArrayList(clazz));

    }

    @Test
    public void testCreationValidityOK() throws SugarTechnicalException, SugarFunctionalException {
        FolderClass clazz = new FolderClass();
        clazz.setScope("Syldavia");
        clazz.setLongLabel("FakeFolder");
        clazz.setRetentionDuration(new DurationType(new BigInteger("1"), "DAY"));
        FolderClass fetchedClass = new FolderClass();
        fetchedClass.setScope("Syldavia");
        fetchedClass.setLongLabel("FakeFolder1");
        when(folderClassService.getAll(anyString(), anyBoolean())).thenReturn(Lists.newArrayList(fetchedClass));

        folderClassValidator.checkCreationValidity(Lists.newArrayList(clazz));
        // verify(tagClassValidator).checkExistence(anyString(), anyList());
        verify(folderClassService).getAll("Syldavia", false);

    }
}
