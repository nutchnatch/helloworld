package com.ossnms.bicnet.reportmanager.server.topology;

import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createPtp;

import java.util.ArrayList;
import java.util.List;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.ossnms.bicnet.bcb.facade.elementMgmt.PhysicalTerminationPointReply;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPoint;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPointMarkable;

public class PTPReplyAnswer implements Answer<PhysicalTerminationPointReply> {

	@Override
	public PhysicalTerminationPointReply answer(InvocationOnMock invocation) throws Throwable {
		if (!(invocation.getArguments()[2] instanceof IPhysicalTerminationPointMarkable[])) {
            throw new AssertionError("PTPReplyAnswer used for other method than getPTPList");
        }

        IPhysicalTerminationPointMarkable[] ptpMarkables = (IPhysicalTerminationPointMarkable[]) invocation.getArguments()[2];
        List<IPhysicalTerminationPoint> ptps = new ArrayList<>();
        IPhysicalTerminationPoint lastPtp = null;
        for (IPhysicalTerminationPointMarkable ptpMarkable : ptpMarkables) {
        	lastPtp = createPtp(ptpMarkable.getPtpId(), ptpMarkable.getParentNeId());
            ptps.add(lastPtp);
        }
        IPhysicalTerminationPoint[] ptpArray = ptps.toArray(new IPhysicalTerminationPoint[ptps.size()]);
        return new PhysicalTerminationPointReply(ptpArray, true, lastPtp);
	}

}
