package com.ossnms.bicnet.reportmanager.server.topology;

import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createNe;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createPhysicalTrail;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createTopologicalContainer;
import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.topoMgmt.ITopologyMgrFacade;
import com.ossnms.bicnet.bcb.facade.topoMgmt.PhysicalTrailReply;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerReply;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrailId;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrailMarkable;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainerId;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainerMarkable;
import com.ossnms.bicnet.bcb.model.topoMgmt.ProtectedPhysicalTrail;

@RunWith(MockitoJUnitRunner.class)
public class TopologyDataTest {

    @Mock private ITopologyMgrFacade topologyFacade;
    @Mock private IEMObjectMgrFacade dcnManagerFacade;
    @InjectMocks private TopologyData testObj;

    private static final ITopologicalContainer ROOT = createTopologicalContainer(0, -1);
    private static final ITopologicalContainer TC1 = createTopologicalContainer(1, 4);
    private static final ITopologicalContainer TC2 = createTopologicalContainer(2, 0);
    private static final ITopologicalContainer TC3 = createTopologicalContainer(3, 5);
    private static final ITopologicalContainer TC4 = createTopologicalContainer(4, 0);
    private static final ITopologicalContainer TC5 = createTopologicalContainer(5, 1);

    @Before
    public void setUp() throws Exception {
        when(topologyFacade.getPhysicalTrailList(any(ISessionContext.class), any(IPhysicalTrailId.class), any(IPhysicalTrailMarkable[].class), anyInt())).thenReturn(createPhysicalTrailReply());
        when(topologyFacade.getTopologicalContainerList(any(ISessionContext.class), any(ITopologicalContainerId.class), any(ITopologicalContainerMarkable[].class), anyInt(), any(ITopologicalContainerId.class))).thenReturn(createTopologicalContainerReply());

        when(dcnManagerFacade.getNEList(any(ISessionContext.class), any(INEId.class), any(INEMarkable[].class), anyInt())).then(new NEReplyAnswer());
    }

    @Test
    public void testGetNonProtectedPhysicalTrails() throws Exception {
        List<ProtectedPhysicalTrail> protectedPhysicalTrails = createProtectedPhysicalTrails();
        List<IPhysicalTrail> physicalTrails = testObj.getNonProtectedPhysicalTrails(protectedPhysicalTrails);
        assertThat(physicalTrails, contains(createPhysicalTrail(2, 1)));
    }

    @Test
    public void testGetTopologicalContainers() throws Exception {
        List<ITopologicalContainer> topologicalContainers = testObj.getTopologicalContainers();
        assertThat(topologicalContainers, contains(ROOT, TC2, TC4, TC1, TC5, TC3));
    }

    @Test
    public void testGetNes() throws Exception {
        List<IPhysicalTrail> physicalTrails = Arrays.asList(createPhysicalTrail(5, 8), createPhysicalTrail(6, 4));
        List<INE> nes = testObj.getNes(physicalTrails);

        assertThat(nes, Matchers.containsInAnyOrder(createNe(4), createNe(5), createNe(6), createNe(8)));
    }

    private PhysicalTrailReply createPhysicalTrailReply() {
        IPhysicalTrail physicalTrail = createPhysicalTrail(2, 1);
        IPhysicalTrail protectedPT1 = createPhysicalTrail(1, 2);
        IPhysicalTrail protectedPT2 = createPhysicalTrail(1, 3);
        return new PhysicalTrailReply(new IPhysicalTrail[]{physicalTrail, protectedPT1, protectedPT2}, true, protectedPT2);
    }

    private List<ProtectedPhysicalTrail> createProtectedPhysicalTrails() {
        IPhysicalTrail protectedPT1 = createPhysicalTrail(1, 2);
        IPhysicalTrail protectedPT2 = createPhysicalTrail(1, 3);
        return Collections.singletonList(new ProtectedPhysicalTrail(protectedPT1, protectedPT2));
    }

    private TopologicalContainerReply createTopologicalContainerReply() {
        return new TopologicalContainerReply(new ITopologicalContainer[]{ROOT, TC1, TC2, TC3, TC4, TC5}, true, TC5);
    }
}