package com.ossnms.bicnet.reportmanager.server.topology.mapper;

import com.ossnms.bicnet.bcb.model.topoMgmt.GeoBounds;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoDistance;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoPoint;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLink;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.TopologicalConnector;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItem;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createConnector;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createGraphicalLink;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createTopologicalContainer;
import static org.hamcrest.Matchers.isEmptyString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class TopologicalContainerMapperTest {

    private static final List<IGraphicalLink> DEFAULT_GLS = Collections.singletonList(createGraphicalLink(1));
    private static final Collection<TopologicalConnector> DEFAULT_CONNECTORS = Collections.singletonList(createConnector(1, 1));

    private TopologicalContainerMapper testObj = new TopologicalContainerMapper();

    @Before
    public void setUp() throws Exception {
        testObj.initMapBounds(new GeoBounds(new GeoPoint(1, 1), new GeoDistance(10000, 10000)));
    }

    @Test
    public void testFromRootContainer() throws Exception {
        ITopologicalContainer root = createTopologicalContainer(0, -1);
        TCItem tcItem = testObj.from(root, DEFAULT_GLS, DEFAULT_CONNECTORS);

        assertEquals(0, tcItem.getTCId());
        assertEquals(null, tcItem.getTCAdditionalInfo());

        // change following values so that the generic assert doesn't fail
        tcItem.setTCId(1);
        tcItem.setTCAdditionalInfo("Additional Info");

        AssertUtils.assertFieldsNotEmptyOrDefault(tcItem, "TCItem");
    }

    @Test
    public void testFromNonRootContainer() throws Exception {
        ITopologicalContainer tc = createTopologicalContainer(2, 1);
        TCItem tcItem = testObj.from(tc, DEFAULT_GLS, DEFAULT_CONNECTORS);

        assertEquals(null, tcItem.getWidth());
        assertEquals(null, tcItem.getHeight());

        // change following values so that the generic assert doesn't fail
        tcItem.setWidth(1.0);
        tcItem.setHeight(1.0);

        AssertUtils.assertFieldsNotEmptyOrDefault(tcItem, "TCItem");
    }

    @Test
    public void testFromWithNullIconId() throws Exception {
        ITopologicalContainer tc = createTopologicalContainer(2, 1);
        tc.setIconIdId(null);

        TCItem tcItem = testObj.from(tc, DEFAULT_GLS, DEFAULT_CONNECTORS);

        assertThat(tcItem.getIconId(), isEmptyString());
    }
}