package com.ossnms.bicnet.reportmanager.server.topology.mapper;

import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItem;
import org.junit.Test;

import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createTopologicalSymbol;
import static com.ossnms.bicnet.reportmanager.server.topology.mapper.AssertUtils.assertFieldsNotEmptyOrDefault;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

/**
 * Tests that all TSItem fields are mapped from ITopologicalSymbol fields
 */
public class TopologicalSymbolMapperTest {

    private TopologicalSymbolMapper testObj = new TopologicalSymbolMapper();

    @Test
    public void testFrom() throws Exception {
        ITopologicalSymbol symbol = createTopologicalSymbol(1, 1);
        TSItem tsItem = testObj.from(symbol);
        assertFieldsNotEmptyOrDefault(tsItem, "TSItem");
    }

    @Test
    public void testLogicalParents() throws Exception {
        ITopologicalSymbol symbol = createTopologicalSymbol(1, 1, 1, 3, 5);
        TSItem tsItem = testObj.from(symbol);
        assertThat(tsItem.getParentTcs(), containsInAnyOrder(1, 3, 5));
    }
}