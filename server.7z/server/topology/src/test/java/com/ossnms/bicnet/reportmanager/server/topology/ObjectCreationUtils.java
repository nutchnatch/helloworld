package com.ossnms.bicnet.reportmanager.server.topology;

import java.util.Arrays;

import com.ossnms.bicnet.bcb.facade.elementMgmt.AllowedChannelsPkgItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.EquipmentIdItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.EquipmentItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.PhysicalTerminationPointItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.GraphicalLinkItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.OpticalCapacityFacetItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.PhysicalTrailItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerIdItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolItem;
import com.ossnms.bicnet.bcb.model.common.AdministrativeState;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.elementMgmt.ChannelType;
import com.ossnms.bicnet.bcb.model.elementMgmt.IAllowedChannelsPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipment;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPoint;
import com.ossnms.bicnet.bcb.model.elementMgmt.ObjectTemplate;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.networkMgmt.ConnectionEnds;
import com.ossnms.bicnet.bcb.model.networkMgmt.Direction;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayer;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerList;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerSet;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoPoint;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLink;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainerId;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.bicnet.bcb.model.topoMgmt.NetworkViewObjectType;
import com.ossnms.bicnet.bcb.model.topoMgmt.TopologicalConnector;

public class ObjectCreationUtils {

    protected ObjectCreationUtils() {
    }

    public static IPhysicalTrail createPhysicalTrail(int aNeId, int zNeId) {
        PhysicalTrailItem pt = new PhysicalTrailItem();
        pt.setProviderName(BiCNetComponentType.TOPOLOGY_MANAGER);
        pt.setDirection(Direction.UNIDIRECTIONAL);
        pt.setAEndTpParentParentNeId(aNeId);
        pt.setAEndTpParentPtpId(1);
        pt.setZEndTpParentParentNeId(zNeId);
        pt.setZEndTpParentPtpId(1);
        pt.setTerminatedLayers(new TransportLayerList(Arrays.asList(TransportLayer.OPTICAL)));
        pt.setNonterminatedLayers(TransportLayerSet.of(TransportLayer.OCH));
        pt.setUserLabel("User label");
        pt.setUserComment("User comment");
        pt.setAdministrativeState(AdministrativeState.UNLOCKED);
        pt.setTmfUserLabel("Tmf user label");
        pt.setTmfOwner("Tmf owner");
        pt.setNeStorage(ConnectionEnds.BOTH);
        pt.setCostFactor1(1);
        pt.setCostFactor2(2);
        pt.setCostFactor3(3);
        pt.setPreventDeletion(true);
        pt.setPtpAEndName("PTPA");
        pt.setPtpZEndName("PTPZ");

        pt.setCableConduitNames(new String[]{"CableConduit1"});

        pt.addOptionalFacet(new OpticalCapacityFacetItem(1, 2));
        return pt;
    }

    public static ITopologicalContainer createTopologicalContainer(int id, int ownerId) {
        ITopologicalContainer tc = new TopologicalContainerItem();
        tc.setId(id);
        tc.setParentParentName(BiCNetComponentType.TOPOLOGY_MANAGER);
        tc.setOwnedByContainerParentParentName(BiCNetComponentType.TOPOLOGY_MANAGER);
        tc.setOwnedByContainerId(ownerId);
        tc.setName("TC" + id);
        tc.setIconIdId("Default");
        tc.setIconPosition(new GeoPoint(400, 500));
        tc.setBackgroundImageId(1);
        tc.setAdditionalInfo("Additional info");
        return tc;
    }


    public static ITopologicalSymbol createTopologicalSymbol(int id, int ownerId, int... logicalParents) {
        TopologicalSymbolItem ts = new TopologicalSymbolItem();
        ts.setId(id);
        ts.setOwnedByContainerId(ownerId);
        ts.setIconIdId("iconId");
        ts.setName("NEName");
        ts.setPosition(new GeoPoint(1, 2));
        ts.setNetworkElementId(1);
        ts.setLogicalParents(createLogicalParentsArray(ownerId, logicalParents));
        ts.setLockAutomaticPositioning(true);
        return ts;
    }

    private static ITopologicalContainerId[] createLogicalParentsArray(int ownerId, int[] logicalParents) {
        if (logicalParents.length == 0) {
            return new ITopologicalContainerId[]{new TopologicalContainerIdItem(BiCNetComponentType.TOPOLOGY_MANAGER, 0, ownerId)};
        }

        ITopologicalContainerId[] logicalParentsArray = new ITopologicalContainerId[logicalParents.length];
        for (int i = 0; i < logicalParents.length; i++) {
            logicalParentsArray[i] = new TopologicalContainerIdItem(BiCNetComponentType.TOPOLOGY_MANAGER, 0, logicalParents[i]);
        }
        return logicalParentsArray;
    }

    public static IGraphicalLink createGraphicalLink(int ownerId) {
        IGraphicalLink gl = new GraphicalLinkItem();
        gl.setOwnerId(ownerId);
        gl.setAEndId(1);
        gl.setAEndType(NetworkViewObjectType.TOPOLOGICAL_SYMBOL);
        gl.setZEndId(2);
        gl.setZEndType(NetworkViewObjectType.TOPOLOGICAL_CONTAINER);
        gl.setShape(new GeoPoint[]{new GeoPoint(10, 10)});
        return gl;
    }

    public static TopologicalConnector createConnector(int symbolId, int containerId) {
        ITopologicalSymbol symbol = createTopologicalSymbol(symbolId, containerId);
        ITopologicalContainerId ownerId = createTopologicalContainer(containerId, 1);
        return new TopologicalConnector(symbol.getParentParentName(), symbol.getParentId(), symbol.getId(), ownerId.getParentParentName(), ownerId.getParentId(), ownerId.getId(), new GeoPoint(20.0, 20.0));
    }

    public static INE createNe(int id) {
        NEItem ne = new NEItem();
        ne.setId(id);
        ne.setIdName("NE" + id);
        return ne;
    }

    public static IPhysicalTerminationPoint createPtp(int id, int parentNeId) {
        IPhysicalTerminationPoint ptp = new PhysicalTerminationPointItem();
        ptp.setParentNeId(parentNeId);
        ptp.setPtpId(id);  
        ptp.setPhysicalLocation("a1|b2|c3");
        ptp.setDirectionId(10);
        IEquipmentId eqId = new EquipmentIdItem(parentNeId, id);
        ptp.setSupportingEquipment(new IEquipmentId[]{eqId});
        
        IAllowedChannelsPkg channel = new AllowedChannelsPkgItem();
        channel.setChannelsType(ChannelType.MIXED);
        channel.setChannelsAllowed(new int[]{2,4,6,8});
        ptp.addOptionalFacet(channel);
        
        return ptp;
    }
    
    public static IEquipment createEquipment(int id, int parentNeId) {
    	IEquipment eq = new EquipmentItem();
    	eq.setEqId(id);
    	eq.setParentNeId(parentNeId);
    	//LAxI Card
    	eq.setActualEquipmentType(ObjectTemplate.fromOrdinal(3213));
    	eq.setRequiredEquipmentType(ObjectTemplate.fromOrdinal(3213));
    	eq.setCardDirection(1);
    	return eq; 
    }
}
