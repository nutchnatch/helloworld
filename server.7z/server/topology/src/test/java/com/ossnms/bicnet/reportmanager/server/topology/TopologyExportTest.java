package com.ossnms.bicnet.reportmanager.server.topology;

import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createConnector;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createGraphicalLink;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createPhysicalTrail;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createTopologicalContainer;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createTopologicalSymbol;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.topoMgmt.GraphicalLinkReply;
import com.ossnms.bicnet.bcb.facade.topoMgmt.ITopologyMgrFacade;
import com.ossnms.bicnet.bcb.facade.topoMgmt.PhysicalTrailReply;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerIdItem;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerReply;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolReply;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPointId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPointMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.TpDirection;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerSet;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoBounds;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoDistance;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoPoint;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLink;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLinkId;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLinkMarkable;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrailId;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrailMarkable;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainerId;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainerMarkable;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbolId;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbolMarkable;
import com.ossnms.bicnet.bcb.model.topoMgmt.ProtectedPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.TopologicalConnector;
import com.ossnms.bicnet.reportmanager.server.topology.mapper.TopologyMapper;
import com.ossnms.bicnet.reportmanager.server.topology.xml.PTItems;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItems;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItems;

@RunWith(MockitoJUnitRunner.class)
public class TopologyExportTest {

    private static final TopologicalContainerIdItem OWNER_CONTAINER = new TopologicalContainerIdItem(BiCNetComponentType.TOPOLOGY_MANAGER, 0, 0);

    @Mock private ITopologyMgrFacade topologyFacade;
    @Mock private IEMObjectMgrFacade dcnManagerFacade;
    @Mock private INetworkDataManagerFacade ndmFacade;
    @InjectMocks private TopologyData topologyData;
    private TopologyExport testObj;

    @Before public void setUp() throws Exception {
        testObj = new TopologyExport(topologyData, new TopologyMapper());

        when(topologyFacade.getPhysicalTrailList(any(ISessionContext.class), any(IPhysicalTrailId.class), any(IPhysicalTrailMarkable[].class), anyInt())).thenReturn(createPhysicalTrailReply());
        when(topologyFacade.getTopologicalContainerList(any(ISessionContext.class), any(ITopologicalContainerId.class), any(ITopologicalContainerMarkable[].class), anyInt(), any(ITopologicalContainerId.class))).thenReturn(createTopologicalContainerReply());
        when(topologyFacade.getTopologicalSymbolList(any(ISessionContext.class), any(ITopologicalSymbolId.class), any(ITopologicalSymbolMarkable[].class), anyInt(), any(ITopologicalContainerId.class))).thenReturn(createTopologicalSymbolReply());
        when(topologyFacade.getGraphicalLinkList(any(ISessionContext.class), any(IGraphicalLinkId.class), any(IGraphicalLinkMarkable[].class), anyInt(), eq(OWNER_CONTAINER))).thenReturn(createGraphicalLinkReply());
        when(topologyFacade.getProtectedPhysicalTrailList(any(ISessionContext.class))).thenReturn(createProtectedPhysicalTrailListResponse());
        when(topologyFacade.getTopologicalConnectors(any(ISessionContext.class), eq(OWNER_CONTAINER))).thenReturn(createConnectorsResponse());
        when(topologyFacade.getMapBounds(any(ISessionContext.class))).thenReturn(createMapBoundsResponse());

        when(dcnManagerFacade.getNEList(any(ISessionContext.class), any(INEId.class), any(INEMarkable[].class), anyInt())).then(new NEReplyAnswer());

        when(ndmFacade.getEquipmentList(any(ISessionContext.class), any(IEquipmentId.class), any(IEquipmentMarkable[].class), anyInt(), any(IEquipmentMarkable.class))).then(new EquipmentReplyAnswer());
        when(ndmFacade.getPhysicalTerminationPointList(any(ISessionContext.class), any(IPhysicalTerminationPointId.class), any(IPhysicalTerminationPointMarkable[].class),
                anyInt(), any(IPhysicalTerminationPointMarkable.class), any(TransportLayerSet.class), any(TpDirection.class))).then(new PTPReplyAnswer());
    }

    @Test public void testExportPTItems() throws Exception {
        PTItems ptItems = testObj.exportPTItems();

        assertThat(ptItems.getPTItem(), hasSize(1));
        assertThat(ptItems.getProtectedPTItem(), hasSize(1));
    }

    @Test public void testExportPTNamesNotEmpty() throws Exception {
        PTItems ptItems = testObj.exportPTItems();
        assertEquals("NE2", ptItems.getPTItem().get(0).getANeIdName());
        assertEquals("NE1", ptItems.getPTItem().get(0).getZNeIdName());
    }

    @Test public void testExportRootContainerMapArea() throws Exception {
        TCItems tcItems = testObj.exportTCItems();

        assertEquals(0, tcItems.getTCItem().get(0).getTCId());
        assertEquals(1, tcItems.getTCItem().get(0).getPositionX(), 0);
        assertEquals(1, tcItems.getTCItem().get(0).getPositionY(), 0);
        assertEquals(10000, tcItems.getTCItem().get(0).getWidth(), 0);
        assertEquals(10000, tcItems.getTCItem().get(0).getHeight(), 0);
    }

    @Test public void testExportTCItems() throws Exception {
        TCItems tcItems = testObj.exportTCItems();

        assertThat(tcItems.getTCItem(), not(empty()));
        assertThat(tcItems.getTCItem().get(0).getGLItems(), not(empty()));
        assertThat(tcItems.getTCItem().get(0).getConnectors(), not(empty()));
    }

    @Test public void testExportTSItems() throws Exception {
        TSItems tsItems = testObj.exportTSItems();
        assertThat(tsItems.getTSItem(), not(empty()));
    }

    private PhysicalTrailReply createPhysicalTrailReply() {
        IPhysicalTrail physicalTrail = createPhysicalTrail(2, 1);
        IPhysicalTrail protectedPT1 = createPhysicalTrail(1, 2);
        IPhysicalTrail protectedPT2 = createPhysicalTrail(1, 3);
        return new PhysicalTrailReply(new IPhysicalTrail[]{physicalTrail, protectedPT1, protectedPT2}, true, protectedPT2);
    }

    private ProtectedPhysicalTrail[] createProtectedPhysicalTrailListResponse() {
        IPhysicalTrail protectedPT1 = createPhysicalTrail(1, 2);
        IPhysicalTrail protectedPT2 = createPhysicalTrail(1, 3);
        return new ProtectedPhysicalTrail[]{new ProtectedPhysicalTrail(protectedPT1, protectedPT2)};
    }

    private TopologicalContainerReply createTopologicalContainerReply() {
        ITopologicalContainer root = createTopologicalContainer(0, -1);
        return new TopologicalContainerReply(new ITopologicalContainer[]{root}, true, root);
    }

    private TopologicalSymbolReply createTopologicalSymbolReply() {
        ITopologicalSymbol symbol = createTopologicalSymbol(1, 0);
        return new TopologicalSymbolReply(new ITopologicalSymbol[]{symbol}, true, symbol);
    }

    private GraphicalLinkReply createGraphicalLinkReply() {
        IGraphicalLink graphicalLink = createGraphicalLink(0);
        return new GraphicalLinkReply(new IGraphicalLink[]{graphicalLink}, true, graphicalLink);
    }

    private TopologicalConnector[] createConnectorsResponse() {
        return new TopologicalConnector[]{createConnector(1, 0)};
    }

    private GeoBounds createMapBoundsResponse() {
        return new GeoBounds(new GeoPoint(1, 1), new GeoDistance(10000, 10000));
    }

}