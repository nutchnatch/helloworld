package com.ossnms.bicnet.reportmanager.server.topology;

import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createEquipment;

import java.util.ArrayList;
import java.util.List;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.ossnms.bicnet.bcb.facade.elementMgmt.EquipmentReply;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipment;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentMarkable;

public class EquipmentReplyAnswer implements Answer<EquipmentReply> {

	@Override
	public EquipmentReply answer(InvocationOnMock invocation) throws Throwable {
		if (!(invocation.getArguments()[2] instanceof IEquipmentMarkable[])) {
            throw new AssertionError("EquipmentReplyAnswer used for other method than getEquipmentList");
        }

        IEquipmentMarkable[] eqMarkables = (IEquipmentMarkable[]) invocation.getArguments()[2];
        List<IEquipment> equipmts = new ArrayList<>();
        IEquipment lastEq = null;
        for (IEquipmentMarkable eqMarkable : eqMarkables) {
        	lastEq = createEquipment(eqMarkable.getEqId(), eqMarkable.getParentNeId());
        	equipmts.add(lastEq);
        }
        IEquipment[] eqArray = equipmts.toArray(new IEquipment[equipmts.size()]);
        return new EquipmentReply(eqArray, true, lastEq);
	}

}
