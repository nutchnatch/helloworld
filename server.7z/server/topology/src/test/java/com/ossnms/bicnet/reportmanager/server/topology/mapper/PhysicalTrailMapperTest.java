package com.ossnms.bicnet.reportmanager.server.topology.mapper;

import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createEquipment;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createNe;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createPhysicalTrail;
import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createPtp;
import static com.ossnms.bicnet.reportmanager.server.topology.mapper.AssertUtils.assertFieldsNotEmptyOrDefault;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.isEmptyOrNullString;
import static org.hamcrest.Matchers.isEmptyString;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipment;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPoint;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayer;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerList;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerSet;
import com.ossnms.bicnet.bcb.model.topoMgmt.IOpticalCapacityFacet;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.reportmanager.server.topology.xml.PTItem;
import com.ossnms.bicnet.reportmanager.server.topology.xml.ProtectedPTItem;

public class PhysicalTrailMapperTest {

    private PhysicalTrailMapper testObj = new PhysicalTrailMapper();
    private IPhysicalTrail physicalTrail;

    @Before
    public void setUp() throws Exception {
        testObj.initNeNames(createNes());
        testObj.savePtps(createPtps());
        testObj.saveEquipments(createEquipments());
        physicalTrail = createDefaultPhysicalTrail();
    }

	@Test
    public void testFrom() throws Exception {
        PTItem ptItem = testObj.from(physicalTrail);
        assertFieldsNotEmptyOrDefault(ptItem, "PTItem");
    }

    @Test
    public void testFromCableConduits() throws Exception {
        physicalTrail.setCableConduitNames(new String[]{"CableConduit1", "CableConduit2"});
        PTItem ptItem = testObj.from(physicalTrail);
        assertThat(ptItem.getCableConduitNames(), containsInAnyOrder("CableConduit1", "CableConduit2"));
    }

    @Test
    public void testFromWithEmptyCableConduits() throws Exception {
        physicalTrail.setCableConduitNames(new String[0]);
        PTItem ptItem = testObj.from(physicalTrail);
        assertThat(ptItem.getCableConduitNames(), empty());
    }

    @Test
    public void testFromWithNullCableConduits() throws Exception {
        physicalTrail.setCableConduitNames(null);
        PTItem ptItem = testObj.from(physicalTrail);
        assertThat(ptItem.getCableConduitNames(), empty());
    }

    @Test
    public void testFromOccupancyFacet() throws Exception {
        PTItem ptItem = testObj.from(physicalTrail);
        assertThat(ptItem.getOpticalOccupancyAZ(), not(isEmptyOrNullString()));
        assertThat(ptItem.getOpticalOccupancyZA(), not(isEmptyOrNullString()));
    }

    @Test
    public void testFromWithNoOccupancyFacet() throws Exception {
        physicalTrail.removeOptionalFacet(IOpticalCapacityFacet.class);
        PTItem ptItem = testObj.from(physicalTrail);
        assertThat(ptItem.getOpticalOccupancyAZ(), isEmptyString());
        assertThat(ptItem.getOpticalOccupancyZA(), isEmptyString());
    }

    @Test
    public void testFromTerminatedLayers() throws Exception {
        physicalTrail.setTerminatedLayers(new TransportLayerList(Arrays.asList(TransportLayer.OPTICAL, TransportLayer.OCH)));
        PTItem ptItem = testObj.from(physicalTrail);
        assertEquals("optical,och", ptItem.getTerminatedLayers());
    }

    @Test
    public void testFromNonTerminatedLayers() throws Exception {
        physicalTrail.setNonterminatedLayers(TransportLayerSet.of(TransportLayer.ODU3, TransportLayer.RS256));
        PTItem ptItem = testObj.from(physicalTrail);
        assertEquals("odu3,rs256", ptItem.getNonTerminatedLayers());
    }

    @Test
    public void testFromProtected() throws Exception {
        IPhysicalTrail ptWithZNeId2 = createPhysicalTrail(1, 2);
        IPhysicalTrail ptWithZNeId3 = createPhysicalTrail(1, 3);

        ProtectedPTItem protectedPTItem = testObj.from(ptWithZNeId2, ptWithZNeId3);

        assertEquals(2, protectedPTItem.getProtectedPt1().getZNeId());
        assertEquals(3, protectedPTItem.getProtectedPt2().getZNeId());
        assertFieldsNotEmptyOrDefault(protectedPTItem, "ProtectedPTItem");
    }

    private IPhysicalTrail createDefaultPhysicalTrail() {
        return createPhysicalTrail(1, 2);
    }

    private List<INE> createNes() {
        return Arrays.asList(createNe(1), createNe(2), createNe(3));
    }
    
    private List<IEquipment> createEquipments() {
    	return Arrays.asList(createEquipment(1,1), createEquipment(1,2), createEquipment(1,3));
    }
    
    private List<IPhysicalTerminationPoint> createPtps() {
    	return Arrays.asList(createPtp(1,1), createPtp(1,2), createPtp(1,3));
   	}
}