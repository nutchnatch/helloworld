package com.ossnms.bicnet.reportmanager.server.topology;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEReply;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.ArrayList;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.topology.ObjectCreationUtils.createNe;

/**
 * Answers NE requests by
 */
public class NEReplyAnswer implements Answer<NEReply> {
    @Override
    public NEReply answer(InvocationOnMock invocation) throws Throwable {
        if (!(invocation.getArguments()[2] instanceof INEMarkable[])) {
            throw new AssertionError("NEReplyAnswer used for other method than getNEList");
        }

        INEMarkable[] neMarkables = (INEMarkable[]) invocation.getArguments()[2];
        List<INE> nes = new ArrayList<>();
        INE lastNe = null;
        for (INEMarkable neMarkable : neMarkables) {
            lastNe = createNe(neMarkable.getId());
            nes.add(lastNe);
        }
        INE[] neArray = nes.toArray(new INE[nes.size()]);
        return new NEReply(neArray, true, lastNe);
    }
}
