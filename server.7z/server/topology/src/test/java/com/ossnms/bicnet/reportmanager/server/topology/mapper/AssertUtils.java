package com.ossnms.bicnet.reportmanager.server.topology.mapper;

import org.apache.commons.lang3.ClassUtils;

import java.lang.reflect.Field;
import java.util.Collection;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.isEmptyString;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Utility method that asserts that all fields of an object are initialized
 */
public class AssertUtils {

    public static void assertFieldsNotEmptyOrDefault(Object object, String objectPath) throws IllegalAccessException {
        Field[] fields = object.getClass().getDeclaredFields();
        for (Field field : fields) {
            String fieldPath = objectPath + "." + field.getName();
            field.setAccessible(true);
            Object value = field.get(object);
            assertObjectValueNotEmptyOrDefault(value, fieldPath);
        }
    }

    private static void assertObjectValueNotEmptyOrDefault(Object value, String fieldPath) throws IllegalAccessException {
        assertNotNull(fieldPath + " is null", value);
        if (Collection.class.isAssignableFrom(value.getClass())) {
            assertCollectionNotEmpty((Collection) value, fieldPath);
        } else if (String.class.isAssignableFrom(value.getClass())) {
            assertStringNotEmpty((String) value, fieldPath);
        } else if (Number.class.isAssignableFrom(ClassUtils.primitiveToWrapper(value.getClass()))) {
            assertNumberNotDefaultValue((Number) value, fieldPath);
        } else if (Character.class.isAssignableFrom(ClassUtils.primitiveToWrapper(value.getClass()))) {
            assertCharacterNotDefaultValue((Character) value, fieldPath);
        } else if (Boolean.class.isAssignableFrom(ClassUtils.primitiveToWrapper(value.getClass()))) {
            assertBooleanNotDefaultValue((Boolean) value, fieldPath);
        } else {
            assertFieldsNotEmptyOrDefault(value, fieldPath);
        }
    }

    private static void assertCollectionNotEmpty(Collection<?> collection, String fieldPath) throws IllegalAccessException {
        assertThat(fieldPath + " is empty", collection, not(empty()));
        for (Object value : collection) {
            assertObjectValueNotEmptyOrDefault(value, fieldPath);
        }
    }

    private static void assertStringNotEmpty(String value, String fieldPath) {
        assertThat(fieldPath + " is empty", value, not(isEmptyString()));
    }

    private static void assertNumberNotDefaultValue(Number value, String fieldPath) {
        assertThat(fieldPath + " has default value", value.doubleValue(), not(0.0));
    }

    private static void assertCharacterNotDefaultValue(Character value, String fieldPath) {
        assertThat(fieldPath + " has default value", value, not((char) 0));
    }

    private static void assertBooleanNotDefaultValue(Boolean value, String fieldPath) {
        assertTrue(fieldPath + " has default value", value);
    }
}
