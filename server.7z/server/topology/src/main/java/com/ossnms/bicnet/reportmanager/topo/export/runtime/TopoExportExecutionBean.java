package com.ossnms.bicnet.reportmanager.topo.export.runtime;

import java.util.concurrent.Future;

import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.topology.TopologyExport;
import com.ossnms.bicnet.reportmanager.server.topology.xml.PTItems;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItems;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItems;

@Stateless
@Local(ITopoExportReadExecution.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class TopoExportExecutionBean implements ITopoExportReadExecution {

    public TopoExportExecutionBean() {
    }

    @Inject
    private TopologyExport topologyExport;

    @Override
    @Asynchronous
    public Future<PTItems> fetchPTs() throws BcbException {
        try {
            PTItems ptItems = topologyExport.exportPTItems();
            return new AsyncResult<>(ptItems);
        } catch (BcbException e) {
            throw new BcbException(e);
        }
    }

    @Override
    @Asynchronous
    public Future<TCItems> fetchTCs() throws BcbException {
        TCItems ptItems = topologyExport.exportTCItems();
        return new AsyncResult<>(ptItems);
    }

    @Override
    @Asynchronous
    public Future<TSItems> fetchTSs() throws BcbException {
        TSItems ptItems = topologyExport.exportTSItems();
        return new AsyncResult<>(ptItems);
    }
}
