package com.ossnms.bicnet.reportmanager.server.topology.reader;

import org.apache.commons.lang3.ArrayUtils;

import com.ossnms.bicnet.bcb.facade.elementMgmt.PhysicalTerminationPointReply;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPoint;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPointId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPointMarkable;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;

public class PTPs extends BcbReplyReader<IPhysicalTerminationPointId, IPhysicalTerminationPoint, PhysicalTerminationPointReply> {
    private final ISessionContext context;
    private final INetworkDataManagerFacade networkDataManager;
    private final IPhysicalTerminationPointMarkable[] filter;

    public PTPs(ISessionContext context, INetworkDataManagerFacade networkDataManager, IPhysicalTerminationPointMarkable[] filter) {
        this.context = context;
        this.networkDataManager = networkDataManager;
        this.filter = ArrayUtils.clone(filter);
    }

    @Override
    protected PhysicalTerminationPointReply nextReply(IPhysicalTerminationPointId lastId) throws BcbException {
        return networkDataManager.getPhysicalTerminationPointList(context, lastId, filter, 500, null, null, null);
    }

    @Override
    protected IPhysicalTerminationPoint[] data(PhysicalTerminationPointReply physicalTerminationPointReply) {
        return physicalTerminationPointReply.getData();
    }

    @Override
    protected IPhysicalTerminationPointId lastId(PhysicalTerminationPointReply physicalTerminationPointReply) {
        return physicalTerminationPointReply.getLastReadId();
    }

    @Override protected boolean isLast(PhysicalTerminationPointReply physicalTerminationPointReply) {
        return physicalTerminationPointReply.endOfFile();
    }
}
