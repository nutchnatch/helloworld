package com.ossnms.bicnet.reportmanager.server.topology.reader;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.topoMgmt.GraphicalLinkReply;
import com.ossnms.bicnet.bcb.facade.topoMgmt.ITopologyMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLink;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLinkId;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainerId;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;

public class GraphicalLinks extends BcbReplyReader<IGraphicalLinkId, IGraphicalLink, GraphicalLinkReply> {
    private final ISessionContext context;
    private final ITopologyMgrFacade topologyManager;
    private final ITopologicalContainerId visibleWithing;

    public GraphicalLinks(ISessionContext context, ITopologyMgrFacade topologyManager, ITopologicalContainerId visibleWithing) {
        this.context = context;
        this.topologyManager = topologyManager;
        this.visibleWithing = visibleWithing;
    }

    @Override
    protected GraphicalLinkReply nextReply(IGraphicalLinkId lastId) throws BcbException {
        return topologyManager.getGraphicalLinkList(context, lastId, null, 500, visibleWithing);
    }

    @Override protected IGraphicalLink[] data(GraphicalLinkReply graphicalLinkReply) {
        return graphicalLinkReply.getData();
    }

    @Override protected IGraphicalLinkId lastId(GraphicalLinkReply graphicalLinkReply) {
        return graphicalLinkReply.getLastReadId();
    }

    @Override protected boolean isLast(GraphicalLinkReply graphicalLinkReply) {
        return graphicalLinkReply.endOfFile();
    }
}
