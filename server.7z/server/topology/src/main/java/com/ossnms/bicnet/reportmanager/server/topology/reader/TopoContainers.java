package com.ossnms.bicnet.reportmanager.server.topology.reader;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.topoMgmt.ITopologyMgrFacade;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalContainerReply;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainerId;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;

public class TopoContainers extends BcbReplyReader<ITopologicalContainerId, ITopologicalContainer, TopologicalContainerReply> {

    private final ISessionContext context;
    private final ITopologyMgrFacade topologyManager;
    private final ITopologicalContainerId visibleWithin;

    public TopoContainers(ISessionContext context, ITopologyMgrFacade topologyManager) {
        this(context, topologyManager, null);
    }

    public TopoContainers(ISessionContext context, ITopologyMgrFacade topologyManager, ITopologicalContainerId visibleWithin) {
        this.context = context;
        this.topologyManager = topologyManager;
        this.visibleWithin = visibleWithin;
    }

    @Override
    protected TopologicalContainerReply nextReply(ITopologicalContainerId lastId) throws BcbException {
        return topologyManager.getTopologicalContainerList(context, lastId, null, 500, visibleWithin);
    }

    @Override protected ITopologicalContainer[] data(TopologicalContainerReply topologicalContainerReply) {
        return topologicalContainerReply.getData();
    }

    @Override protected ITopologicalContainerId lastId(TopologicalContainerReply topologicalContainerReply) {
        return topologicalContainerReply.getLastReadId();
    }

    @Override protected boolean isLast(TopologicalContainerReply topologicalContainerReply) {
        return topologicalContainerReply.endOfFile();
    }
}
