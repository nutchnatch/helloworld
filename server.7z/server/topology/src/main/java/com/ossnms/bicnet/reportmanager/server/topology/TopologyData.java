package com.ossnms.bicnet.reportmanager.server.topology;

import static java.util.Arrays.asList;
import static java.util.Arrays.stream;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;
import static java.util.stream.Stream.of;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.elementMgmt.EquipmentItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.PhysicalTerminationPointItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.topoMgmt.ITopologyMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipment;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPoint;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPointMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoBounds;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLink;
import com.ossnms.bicnet.bcb.model.topoMgmt.INetworkViewObject;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.bicnet.bcb.model.topoMgmt.ProtectedPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.TopologicalConnector;
import com.ossnms.bicnet.reportmanager.dcn.read.NEReader;
import com.ossnms.bicnet.reportmanager.server.topology.reader.Equipment;
import com.ossnms.bicnet.reportmanager.server.topology.reader.GraphicalLinks;
import com.ossnms.bicnet.reportmanager.server.topology.reader.PTPs;
import com.ossnms.bicnet.reportmanager.server.topology.reader.PhysicalTrails;
import com.ossnms.bicnet.reportmanager.server.topology.reader.TopoContainers;
import com.ossnms.bicnet.reportmanager.server.topology.reader.TopoSymbols;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

/**
 * Fetches topology data from Topology server using its façades.
 */
public class TopologyData {

    private static final Logger LOGGER = LoggerFactory.getLogger(TopologyData.class);

    private final ISessionContext context;
    private final IEMObjectMgrFacade dcnManager;
    private final ITopologyMgrFacade topologyManager;
    private final INetworkDataManagerFacade networkDataManager;

    @Inject public TopologyData(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcnManager, 
                                @BiCNet ITopologyMgrFacade topologyManager, @BiCNet INetworkDataManagerFacade networkDataManager) {
        this.context = context;
        this.dcnManager = dcnManager;
        this.topologyManager = topologyManager;
        this.networkDataManager = networkDataManager;
    }

    List<IPhysicalTrail> getNonProtectedPhysicalTrails(List<ProtectedPhysicalTrail> protectedPhysicalTrails) throws BcbException {
        Set<IPhysicalTrail> protectedPTs = protectedPhysicalTrails.stream()
                .flatMap(pt -> of(pt.getPhysicalTrail1(), pt.getPhysicalTrail2()))
                .collect(toSet());

        return new PhysicalTrails(context, topologyManager).read()
                .filter(physicalTrail -> !protectedPTs.contains(physicalTrail))
                .collect(toList());
    }

    List<ProtectedPhysicalTrail> getProtectedPhysicalTrails() throws BcbException {
        return asList(topologyManager.getProtectedPhysicalTrailList(context));
    }

    List<ITopologicalContainer> getTopologicalContainers() throws BcbException {
        return sortByLevels(new TopoContainers(context, topologyManager).read().collect(toList()));
    }

    private static List<ITopologicalContainer> sortByLevels(Collection<ITopologicalContainer> containers) {
        Map<Integer, List<ITopologicalContainer>> mapByOwnerId =
                containers.stream().collect(groupingBy(INetworkViewObject::getOwnedByContainerId));

        List<ITopologicalContainer> sortedContainers = new ArrayList<>(containers.size());

        sortedContainers.addAll(mapByOwnerId.get(-1));

        for (int i = 0; i < sortedContainers.size(); i++) {
            int tcId = sortedContainers.get(i).getId();
            List<ITopologicalContainer> ownedContainers = mapByOwnerId.get(tcId);
            if (ownedContainers != null) {
                sortedContainers.addAll(ownedContainers);
            }
        }

        return sortedContainers;
    }

    Stream<ITopologicalSymbol> getTopologicalSymbols() throws BcbException {
        return new TopoSymbols(context, topologyManager).read();
    }

    List<IGraphicalLink> getGraphicalLinks(ITopologicalContainer owner) {
        return new GraphicalLinks(context, topologyManager, owner.getTopologicalContainerId()).read().collect(toList());
    }

    List<TopologicalConnector> getConnectors(ITopologicalContainer owner) {
        try {
            return asList(topologyManager.getTopologicalConnectors(context, owner));
        } catch (BcbException e) {
            LOGGER.error("Failed to acess topology", e);
            return emptyList();
        }
    }

    List<INE> getNes(Collection<IPhysicalTrail> physicalTrails) throws BcbException {
        return new NEReader(context, dcnManager, fromPTs(physicalTrails)).read().collect(toList());
    }

    private INEMarkable[] fromPTs(Collection<IPhysicalTrail> pts) {
        return pts.stream()
                .flatMapToInt(pt -> IntStream.of(pt.getAEndTpParentParentNeId(), pt.getZEndTpParentParentNeId()))
                .distinct()
                .mapToObj(TopologyData::createNEMarkable)
                .toArray(INEMarkable[]::new);
    }

    private static INEMarkable createNEMarkable(int neId) {
        INEMarkable neMarkable = NEItem.markableNE(null);
        neMarkable.setId(neId);
        return neMarkable;
    }

    GeoBounds getMapBounds() throws BcbException {
        return topologyManager.getMapBounds(context);
    }

    List<IEquipment> getEquipments(List<IPhysicalTerminationPoint> ptps) throws BcbException {
        IEquipmentMarkable[] filter = getEquipmentMarkables(ptps);

        IEquipmentMarkable selectedAtribute = new EquipmentItem().toMarkableEquipment();
        selectedAtribute.markRequiredEquipmentType(true);
        selectedAtribute.markCardDirection(true);

        return new Equipment(context, networkDataManager, selectedAtribute, filter).read().collect(toList());
    }

    private static IEquipmentMarkable[] getEquipmentMarkables(List<IPhysicalTerminationPoint> ptps) {
        return ptps.stream()
                .flatMap(ptp -> stream(ptp.getSupportingEquipment()).map(id -> equipmentMarkable(id, ptp)))
                .toArray(IEquipmentMarkable[]::new);
    }

    private static IEquipmentMarkable equipmentMarkable(IEquipmentId equipmentId, IPhysicalTerminationPoint ptp) {
        IEquipmentMarkable markable = new EquipmentItem().toMarkableEquipment();
        markable.setEqId(equipmentId.getEqId());
        markable.setParentNeId(ptp.getParentNeId());
        return markable;
    }

    List<IPhysicalTerminationPoint> getPTPs(Collection<IPhysicalTrail> physicalTrails) throws BcbException {
        return new PTPs(context, networkDataManager, getPTPMarkables(physicalTrails)).read().collect(toList());
    }

    private IPhysicalTerminationPointMarkable[] getPTPMarkables(Collection<IPhysicalTrail> physicalTrails) {
        return physicalTrails.stream()
                .flatMap(pt -> of(aEndPtpM(pt), zEndPtpM(pt)))
                .distinct()
                .toArray(IPhysicalTerminationPointMarkable[]::new);
    }

    private static IPhysicalTerminationPointMarkable aEndPtpM(IPhysicalTrail pt) {
        IPhysicalTerminationPointMarkable aEndPtpM = new PhysicalTerminationPointItem().toMarkablePhysicalTerminationPoint();
        aEndPtpM.setPtpId(pt.getAEndTpParentPtpId());
        aEndPtpM.setParentNeId(pt.getAEndTpParentParentNeId());
        return aEndPtpM;
    }

    private static IPhysicalTerminationPointMarkable zEndPtpM(IPhysicalTrail pt) {
        IPhysicalTerminationPointMarkable zEndPtpM = new PhysicalTerminationPointItem().toMarkablePhysicalTerminationPoint();
        zEndPtpM.setPtpId(pt.getZEndTpParentPtpId());
        zEndPtpM.setParentNeId(pt.getZEndTpParentParentNeId());
        return zEndPtpM;
    }
}
