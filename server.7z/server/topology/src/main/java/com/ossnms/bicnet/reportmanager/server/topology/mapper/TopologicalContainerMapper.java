package com.ossnms.bicnet.reportmanager.server.topology.mapper;

import com.ossnms.bicnet.bcb.model.topoMgmt.GeoBounds;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoPoint;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLink;
import com.ossnms.bicnet.bcb.model.topoMgmt.INetworkViewObjectId;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.TopologicalConnector;
import com.ossnms.bicnet.reportmanager.server.topology.xml.Connector;
import com.ossnms.bicnet.reportmanager.server.topology.xml.GLEndpoint;
import com.ossnms.bicnet.reportmanager.server.topology.xml.GLItem;
import com.ossnms.bicnet.reportmanager.server.topology.xml.Point;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItem;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Maps BCB ITopologicalContainer instances to JAXB TCItem instances
 */
class TopologicalContainerMapper {
    private GeoBounds mapBounds;

    TCItem from(ITopologicalContainer tc, List<IGraphicalLink> gls, Collection<TopologicalConnector> connectors) {
        TCItem tcItem = new TCItem();

        tcItem.setTCId(tc.getId());
        tcItem.setIconId(StringUtils.defaultString(tc.getIconIdId()));
        tcItem.setBackImageId(tc.getBackgroundImageId());
        tcItem.setTCName(tc.getName());
        tcItem.setOwningTcId(tc.getOwnedByContainerId());

        if (isRootContainer(tc)) {
            mapRootContainerArea(tcItem);
        } else {
            mapContainerIconPosition(tcItem, tc);
            tcItem.setTCAdditionalInfo(StringUtils.defaultIfEmpty(tc.getAdditionalInfo(), null));
        }

        tcItem.setGLItems(mapGLs(gls));
        tcItem.setConnectors(mapConnectors(connectors));

        return tcItem;
    }

    void initMapBounds(GeoBounds mapBounds) {
        this.mapBounds = mapBounds;
    }

    private boolean isRootContainer(ITopologicalContainer tc) {
        return tc.getId() == 0;
    }

    private void mapRootContainerArea(TCItem tcItem) {
        tcItem.setPositionX(mapBounds.getPosition().getX());
        tcItem.setPositionY(mapBounds.getPosition().getY());
        tcItem.setWidth(mapBounds.getSize().getX());
        tcItem.setHeight(mapBounds.getSize().getY());
    }

    private void mapContainerIconPosition(TCItem tcItem, ITopologicalContainer tc) {
        tcItem.setPositionX(tc.getIconPosition().getX());
        tcItem.setPositionY(tc.getIconPosition().getY());
    }

    private List<GLItem> mapGLs(List<IGraphicalLink> gls) {
        List<GLItem> glItems = new ArrayList<>();
        for (IGraphicalLink gl : gls) {
            GLItem glItem = from(gl);
            if (glItem != null) {
                glItems.add(glItem);
            }
        }
        return glItems;
    }

    private GLItem from(IGraphicalLink gl) {
        if(gl.getShape().length == 0) {
            return null;
        }

        GLItem glItem = new GLItem();
        glItem.setAEnd(mapEndpoint(gl.getAEnd()));
        glItem.setZEnd(mapEndpoint(gl.getZEnd()));

        List<Point> shape = new ArrayList<>();
        for (GeoPoint geoPoint : gl.getShape()) {
            Point point = new Point();
            point.setX(geoPoint.getX());
            point.setY(geoPoint.getY());
            shape.add(point);
        }
        glItem.setShape(shape);

        return glItem;
    }

    private GLEndpoint mapEndpoint(INetworkViewObjectId endpoint) {
        GLEndpoint glEndpoint = new GLEndpoint();
        glEndpoint.setId(endpoint.getId());
        glEndpoint.setType(endpoint.type().toString());
        return glEndpoint;
    }

    private List<Connector> mapConnectors(Collection<TopologicalConnector> connectors) {
        List<Connector> connectorItems = new ArrayList<>();
        for (TopologicalConnector connector : connectors) {
            connectorItems.add(mapConnector(connector));
        }
        return connectorItems;
    }

    private Connector mapConnector(TopologicalConnector connector) {
        Connector connectorItem = new Connector();
        connectorItem.setSymbolId(connector.getSymbol().getId());
        connectorItem.setX(connector.getPosition().getX());
        connectorItem.setY(connector.getPosition().getY());
        return connectorItem;
    }
}
