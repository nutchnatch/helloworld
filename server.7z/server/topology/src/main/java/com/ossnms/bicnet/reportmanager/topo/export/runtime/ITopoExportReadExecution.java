package com.ossnms.bicnet.reportmanager.topo.export.runtime;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.runtime.IExportReadExecution;
import com.ossnms.bicnet.reportmanager.server.topology.xml.PTItems;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItems;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItems;

import javax.ejb.Asynchronous;
import java.util.concurrent.Future;

public interface ITopoExportReadExecution extends IExportReadExecution {

    @Asynchronous
    Future<PTItems> fetchPTs() throws BcbException;

    @Asynchronous
    Future<TCItems> fetchTCs() throws BcbException;

    @Asynchronous
    Future<TSItems> fetchTSs() throws BcbException;
}
