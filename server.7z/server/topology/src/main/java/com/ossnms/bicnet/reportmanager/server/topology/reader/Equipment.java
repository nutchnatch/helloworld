package com.ossnms.bicnet.reportmanager.server.topology.reader;

import org.apache.commons.lang3.ArrayUtils;

import com.ossnms.bicnet.bcb.facade.elementMgmt.EquipmentReply;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipment;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentMarkable;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;

public class Equipment extends BcbReplyReader<IEquipmentId, IEquipment, EquipmentReply> {
    private final ISessionContext context;
    private final INetworkDataManagerFacade networkDataManager;
    private final IEquipmentMarkable selectedAttribute;
    private final IEquipmentMarkable[] filters;

    public Equipment(ISessionContext context, INetworkDataManagerFacade networkDataManager, IEquipmentMarkable selectedAttribute, IEquipmentMarkable[] filters) {
        this.context = context;
        this.networkDataManager = networkDataManager;
        this.selectedAttribute = selectedAttribute;
        this.filters = ArrayUtils.clone(filters);
    }

    @Override
    protected EquipmentReply nextReply(IEquipmentId lastId) throws BcbException {
        return networkDataManager.getEquipmentList(context, lastId, filters, 500, selectedAttribute);
    }

    @Override protected IEquipment[] data(EquipmentReply equipmentReply) {
        return equipmentReply.getData();
    }

    @Override protected IEquipmentId lastId(EquipmentReply equipmentReply) {
        return equipmentReply.getLastReadId();
    }

    @Override protected boolean isLast(EquipmentReply equipmentReply) {
        return equipmentReply.endOfFile();
    }
}
