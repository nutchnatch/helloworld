package com.ossnms.bicnet.reportmanager.topo.export.messaging.input;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.runtime.IExportReadExecution;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItems;
import com.ossnms.bicnet.reportmanager.topo.export.runtime.ITopoExportReadExecution;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class TSReader implements IReaderBuilder<TSItems> {

    private ITopoExportReadExecution topoExecution;

    public TSReader(){
    }

    @Override
    public Future<TSItems> readObject() throws BcbException, ExecutionException, InterruptedException {

        return topoExecution.fetchTSs();
    }

    @Override
    public void setExecution(IExportReadExecution execution) {
        this.topoExecution = (ITopoExportReadExecution) execution;
    }

    @Override
    public String getName() {
        return Constants.TOPOLOGICAL_SYMBOLS;
    }
}
