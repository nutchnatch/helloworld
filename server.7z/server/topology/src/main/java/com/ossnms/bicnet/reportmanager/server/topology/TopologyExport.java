package com.ossnms.bicnet.reportmanager.server.topology;

import static java.util.stream.Collectors.toSet;
import static java.util.stream.Stream.concat;

import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import javax.inject.Inject;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPoint;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.ProtectedPhysicalTrail;
import com.ossnms.bicnet.reportmanager.server.topology.mapper.TopologyMapper;
import com.ossnms.bicnet.reportmanager.server.topology.xml.PTItems;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItems;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItems;

/**
 * Exports topology information (Physical Trails, Topological Containers and
 * Topological Symbols)
 */
public class TopologyExport {

    private final TopologyData topologyData;
    private final TopologyMapper topologyMapper;

    @Inject public TopologyExport(TopologyData topologyData, TopologyMapper topologyMapper) {
        this.topologyData = topologyData;
        this.topologyMapper = topologyMapper;
    }

    public PTItems exportPTItems() throws BcbException {
        List<ProtectedPhysicalTrail> protectedPhysicalTrails = topologyData.getProtectedPhysicalTrails();
        List<IPhysicalTrail> physicalTrails = topologyData.getNonProtectedPhysicalTrails(protectedPhysicalTrails);

        if (physicalTrails.isEmpty() && protectedPhysicalTrails.isEmpty()) {
            return new PTItems();
        }

        Collection<IPhysicalTrail> allTrails = joinTrails(physicalTrails, protectedPhysicalTrails);
        topologyMapper.initNeNames(topologyData.getNes(allTrails));
        List<IPhysicalTerminationPoint> ptps = topologyData.getPTPs(allTrails);
        topologyMapper.savePTPS(ptps);
        topologyMapper.saveEquipments(topologyData.getEquipments(ptps));

        PTItems result = new PTItems();
        physicalTrails.stream().map(topologyMapper::from).forEach(result.getPTItem()::add);

        protectedPhysicalTrails.stream()
                .map(trail -> topologyMapper.from(trail.getPhysicalTrail1(), trail.getPhysicalTrail2()))
                .forEach(result.getProtectedPTItem()::add);

        return result;
    }

    private static Collection<IPhysicalTrail> joinTrails(List<IPhysicalTrail> physicalTrails, List<ProtectedPhysicalTrail> protectedPhysicalTrails) {
        Stream<IPhysicalTrail> pts = physicalTrails.stream();
        Stream<IPhysicalTrail> protectedPts = protectedPhysicalTrails.stream()
                .flatMap(ptp -> Stream.of(ptp.getPhysicalTrail1(), ptp.getPhysicalTrail2()));

        return concat(pts, protectedPts).collect(toSet());
    }

    public TCItems exportTCItems() throws BcbException {
        topologyMapper.initMapBounds(topologyData.getMapBounds());
        TCItems result = new TCItems();
        topologyData.getTopologicalContainers().stream()
                .map(container -> topologyMapper.from(container,
                        topologyData.getGraphicalLinks(container),
                        topologyData.getConnectors(container)))
                .forEach(result.getTCItem()::add);
        return result;
    }

    public TSItems exportTSItems() throws BcbException {
        TSItems result = new TSItems();
        topologyData.getTopologicalSymbols()
                .map(topologyMapper::from)
                .forEach(result.getTSItem()::add);
        return result;
    }
}
