package com.ossnms.bicnet.reportmanager.server.topology.mapper;

import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainerId;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Maps BCB ITopologicalSymbol instances to JAXB TCItem instances
 */
class TopologicalSymbolMapper {
    TSItem from(ITopologicalSymbol ts) {
        TSItem tsItem = new TSItem();
        tsItem.setId(ts.getId());
        tsItem.setPositionX(ts.getPosition().getX());
        tsItem.setPositionY(ts.getPosition().getY());
        tsItem.setNEId(ts.getNetworkElementId());
        tsItem.setNEIdName(ts.getName());
        tsItem.setOwningTcId(ts.getOwnedByContainerId());
        tsItem.setParentTcs(getLogicalParentIds(ts));
        tsItem.setLockAutomaticPositioning(ts.getLockAutomaticPositioning());
        return tsItem;
    }

    private List<Integer> getLogicalParentIds(ITopologicalSymbol ts) {
        List<Integer> parentIds = new ArrayList<>();
        for (ITopologicalContainerId logicalParent : ts.getLogicalParents()) {
            parentIds.add(logicalParent.getId());
        }
        return parentIds;
    }
}
