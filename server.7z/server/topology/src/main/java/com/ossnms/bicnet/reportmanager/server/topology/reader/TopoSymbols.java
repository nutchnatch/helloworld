package com.ossnms.bicnet.reportmanager.server.topology.reader;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.topoMgmt.ITopologyMgrFacade;
import com.ossnms.bicnet.bcb.facade.topoMgmt.TopologicalSymbolReply;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbolId;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;

public class TopoSymbols extends BcbReplyReader<ITopologicalSymbolId, ITopologicalSymbol, TopologicalSymbolReply> {

    private final ISessionContext context;
    private final ITopologyMgrFacade topologyManager;

    public TopoSymbols(ISessionContext context, ITopologyMgrFacade topologyManager) {
        this.context = context;
        this.topologyManager = topologyManager;
    }

    @Override
    protected TopologicalSymbolReply nextReply(ITopologicalSymbolId lastId) throws BcbException {
        return topologyManager.getTopologicalSymbolList(context, lastId, null, 500, null);
    }

    @Override protected ITopologicalSymbol[] data(TopologicalSymbolReply topologicalSymbolReply) {
        return topologicalSymbolReply.getData();
    }

    @Override protected ITopologicalSymbolId lastId(TopologicalSymbolReply topologicalSymbolReply) {
        return topologicalSymbolReply.getLastReadId();
    }

    @Override protected boolean isLast(TopologicalSymbolReply topologicalSymbolReply) {
        return topologicalSymbolReply.endOfFile();
    }
}
