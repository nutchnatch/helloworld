package com.ossnms.bicnet.reportmanager.topo.export.messaging.input;

import java.util.Collection;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.StreamSupport;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.ItemExecution;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.servicelocator.BeanUtils;
import com.ossnms.bicnet.reportmanager.topo.export.runtime.ITopoExportReadExecution;

public class TopoItemExecution extends ItemExecution {

    private final Iterable<IReaderBuilder> readers;

    public TopoItemExecution(Iterable<IReaderBuilder> readers){
        this.readers = readers;
    }

    @Override
    public List<Object> executeItem() throws BcbException {

        List<Object> itemsToBeExported = processReaders(readers);

        return itemsToBeExported;
    }

    @Override
    public String getName() {
        StringJoiner joiner = new StringJoiner(", ");
        StreamSupport.stream(readers.spliterator(), false)
                .map(reader -> joiner.add(reader.getName()))
                .toArray();

        return joiner.toString();
    }

    @Override
    protected Collection<IReaderBuilder> buildReaders(Iterable<IReaderBuilder> exportableItems) {

        ITopoExportReadExecution topoExecution = BeanUtils.resolveBeanBayInterface(ITopoExportReadExecution.class);
        Builder<IReaderBuilder> builder = ImmutableList.builder();
        exportableItems.forEach(iReader -> {
            iReader.setExecution(topoExecution);
            builder.add(iReader);
        });

        return builder.build();
    }

    public Iterable<IReaderBuilder> getReaders() {
        return readers;
    }
}