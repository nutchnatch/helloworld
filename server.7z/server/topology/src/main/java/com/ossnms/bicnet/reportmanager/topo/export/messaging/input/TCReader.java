package com.ossnms.bicnet.reportmanager.topo.export.messaging.input;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.runtime.IExportReadExecution;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItems;
import com.ossnms.bicnet.reportmanager.topo.export.runtime.ITopoExportReadExecution;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class TCReader implements IReaderBuilder<TCItems> {

    private ITopoExportReadExecution topoExecution;

    public TCReader(){
    }

    @Override
    public Future<TCItems> readObject() throws BcbException, ExecutionException, InterruptedException {

        return topoExecution.fetchTCs();
    }

    @Override
    public void setExecution(IExportReadExecution execution) {
        this.topoExecution = (ITopoExportReadExecution) execution;
    }

    @Override
    public String getName() {
        return Constants.TOPOLOGICAL_CONTAINERS;
    }
}
