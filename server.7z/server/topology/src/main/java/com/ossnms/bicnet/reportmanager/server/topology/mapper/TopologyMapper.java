package com.ossnms.bicnet.reportmanager.server.topology.mapper;

import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipment;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPoint;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.topoMgmt.GeoBounds;
import com.ossnms.bicnet.bcb.model.topoMgmt.IGraphicalLink;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalContainer;
import com.ossnms.bicnet.bcb.model.topoMgmt.ITopologicalSymbol;
import com.ossnms.bicnet.bcb.model.topoMgmt.TopologicalConnector;
import com.ossnms.bicnet.reportmanager.server.topology.xml.PTItem;
import com.ossnms.bicnet.reportmanager.server.topology.xml.ProtectedPTItem;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItem;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItem;

import java.util.Collection;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

/**
 * Maps BCB Topology instances to JAXB instances
 */
public class TopologyMapper {
    private PhysicalTrailMapper ptMapper = new PhysicalTrailMapper();
    private TopologicalContainerMapper tcMapper = new TopologicalContainerMapper();
    private TopologicalSymbolMapper tsMapper = new TopologicalSymbolMapper();

    public PTItem from(IPhysicalTrail pt) {
        return ptMapper.from(pt);
    }

    public ProtectedPTItem from(IPhysicalTrail pt1, IPhysicalTrail pt2) {
        return ptMapper.from(pt1, pt2);
    }

    public TCItem from(ITopologicalContainer tc, List<IGraphicalLink> gls, Collection<TopologicalConnector> connectors) {
        return tcMapper.from(tc, gls, connectors);
    }

    public TSItem from(ITopologicalSymbol ts) {
        return tsMapper.from(ts);
    }

    public void initNeNames(List<INE> nes) {
        ptMapper.initNeNames(nes);
    }

    public void initMapBounds(GeoBounds mapBounds) {
        tcMapper.initMapBounds(mapBounds);
    }

	public void savePTPS(List<IPhysicalTerminationPoint> ptps) {
		ptMapper.savePtps(ptps);
	}

	public void saveEquipments(List<IEquipment> equipments) {
		ptMapper.saveEquipments(equipments);
		
	}
}
