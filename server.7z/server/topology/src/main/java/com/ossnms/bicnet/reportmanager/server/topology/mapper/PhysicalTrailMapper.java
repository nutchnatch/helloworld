package com.ossnms.bicnet.reportmanager.server.topology.mapper;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.collections.IteratorUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.ossnms.bicnet.bcb.facade.elementMgmt.EquipmentIdItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.PhysicalTerminationPointIdItem;
import com.ossnms.bicnet.bcb.model.elementMgmt.ChannelType;
import com.ossnms.bicnet.bcb.model.elementMgmt.IAllowedChannelsPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipment;
import com.ossnms.bicnet.bcb.model.elementMgmt.IEquipmentId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPoint;
import com.ossnms.bicnet.bcb.model.elementMgmt.IPhysicalTerminationPointId;
import com.ossnms.bicnet.bcb.model.elementMgmt.ObjectTemplate;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerList;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerSet;
import com.ossnms.bicnet.bcb.model.topoMgmt.IOpticalCapacityFacet;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.reportmanager.server.topology.xml.EndPointAdditionalAttributes;
import com.ossnms.bicnet.reportmanager.server.topology.xml.EndpointInformation;
import com.ossnms.bicnet.reportmanager.server.topology.xml.PTItem;
import com.ossnms.bicnet.reportmanager.server.topology.xml.ProtectedPTItem;

/**
 * Maps BCB IPhysicalTrail instances to JAXB PTItem instances
 */
class PhysicalTrailMapper {
    private Map<Integer, String> neNames;
    private Map<IPhysicalTerminationPointId, IPhysicalTerminationPoint> ptpMap;
    private Map<IEquipmentId, IEquipment> equipmentMap;

    PTItem from(IPhysicalTrail pt) {
        PTItem ptItem = new PTItem();
        ptItem.setProviderName(pt.getProviderName().name());
        ptItem.setDirection(pt.getDirection().toString());

        ptItem.setANeId(pt.getAEndTpParentParentNeId());
        ptItem.setANeIdName(neNames.get(pt.getAEndTpParentParentNeId()));
        ptItem.setAPTPId(pt.getAEndTpParentPtpId());
        ptItem.setAPTPName(pt.getPtpAEndName());

        ptItem.setZNeId(pt.getZEndTpParentParentNeId());
        ptItem.setZNeIdName(neNames.get(pt.getZEndTpParentParentNeId()));
        ptItem.setZPTPId(pt.getZEndTpParentPtpId());
        ptItem.setZPTPName(pt.getPtpZEndName());

        ptItem.setTerminatedLayers(pt.getTerminatedLayers() != null ? pt.getTerminatedLayers().toDbString() : "");
        ptItem.setNonTerminatedLayers(toXml(pt.getNonterminatedLayers()));

        ptItem.setUserLabel(pt.getUserLabel());
        ptItem.setUserComment(StringUtils.defaultString(pt.getUserComment()));
        ptItem.setAdministrativeState(pt.getAdministrativeState().toString());
        ptItem.setTmfUserLabel(StringUtils.defaultString(pt.getTmfUserLabel()));
        ptItem.setTmfOwner(StringUtils.defaultString(pt.getTmfOwner()));
        ptItem.setNeStorage(pt.getNeStorage().toString());

        ptItem.setCableConduitNames(Arrays.asList(ArrayUtils.nullToEmpty(pt.getCableConduitNames())));

        ptItem.setCostFactor1(pt.getCostFactor1());
        ptItem.setCostFactor2(pt.getCostFactor2());
        ptItem.setCostFactor3(pt.getCostFactor3());

        ptItem.setPreventDeletion(pt.getPreventDeletion());
     
        mapOpticalOccupancy(ptItem, pt);
        
        EndpointInformation endPointInformation = new EndpointInformation();
        ptItem.setEndpointInformation(endPointInformation);
        mapEndpointInformation(endPointInformation, pt);
        
        EndPointAdditionalAttributes endpointAdditional = new EndPointAdditionalAttributes();
        ptItem.setEndPointAdditionalAttributes(endpointAdditional);
        mapChannelInformation(endpointAdditional, pt);

        return ptItem;
    }

    private void mapEndpointInformation(EndpointInformation endPointInformation, IPhysicalTrail pt) {
    	
    	IPhysicalTerminationPointId aEndPTPId = new PhysicalTerminationPointIdItem(pt.getAEndTpParentParentNeId(), pt.getAEndTpParentPtpId());
    	fillEndpointInformation(endPointInformation, aEndPTPId, true);
    	
    	IPhysicalTerminationPointId zEndPTPId = new PhysicalTerminationPointIdItem(pt.getZEndTpParentParentNeId(),pt.getZEndTpParentPtpId());
    	fillEndpointInformation(endPointInformation, zEndPTPId, false);
    	
	}

	private void fillEndpointInformation(EndpointInformation endPointInformation, IPhysicalTerminationPointId ptpId, boolean aEnd) {
		IPhysicalTerminationPoint ptp = ptpMap.get(ptpId);
    	
		if (ptp != null) {
			int equipmentId = ptp.getSupportingEquipment()[0].getEqId();
			IEquipment equipment = equipmentMap.get(new EquipmentIdItem(ptpId.getParentNeId(), equipmentId));
			
			if (equipment != null) {
				fillEquipmentType(endPointInformation, aEnd, equipment);
				fillDirection(endPointInformation, aEnd, ptp);
			}
			
			fillPortLocation(endPointInformation, aEnd, ptp);
		}
	}

	private void fillDirection(EndpointInformation endPointInformation,	boolean aEnd, IPhysicalTerminationPoint ptp) {
		int cardDirection = ptp.getDirectionId();
		if (cardDirection != 0 && aEnd) {
			endPointInformation.setAEndDirection(Integer.toString(cardDirection));
		} else if (cardDirection != 0) {
			endPointInformation.setZEndDirection(Integer.toString(cardDirection));
		}
	}

	private void fillEquipmentType(EndpointInformation endPointInformation,	boolean aEnd, IEquipment equipment) {
		
		ObjectTemplate eqType = equipment.getRequiredEquipmentType();
		if (eqType != null && aEnd) {
			endPointInformation.setAEndModuleType(eqType.guiLabel());
		} else if (eqType != null) {
			endPointInformation.setZEndModuleType(eqType.guiLabel());
		}
	}
	
	private void fillPortLocation(EndpointInformation endPointInformation,	boolean aEnd, IPhysicalTerminationPoint ptp) {
		
		String location = ptp.getPhysicalLocation();
		if (StringUtils.isNotBlank(location) && aEnd) {
			endPointInformation.setAEndPortLocation(location);
		} else if (StringUtils.isNotBlank(location)) {
			endPointInformation.setZEndPortLocation(location);
		}
	}

	ProtectedPTItem from(IPhysicalTrail pt1, IPhysicalTrail pt2) {
        ProtectedPTItem protectedPTItem = new ProtectedPTItem();
        protectedPTItem.setProtectedPt1(from(pt1));
        protectedPTItem.setProtectedPt2(from(pt2));
        return protectedPTItem;
    }

    void initNeNames(List<INE> nes) {
        neNames = new HashMap<>();
        for (INE ne : nes) {
            neNames.put(ne.getId(), ne.getIdName());
        }
    }

    private void mapOpticalOccupancy(PTItem ptItem, IPhysicalTrail pt) {
        String opticalOccupancyAZ = "";
        String opticalOccupancyZA = "";

        IOpticalCapacityFacet opticalCapacity = (IOpticalCapacityFacet) pt.getFacette(IOpticalCapacityFacet.class);
        if (opticalCapacity != null) {
            opticalOccupancyAZ = String.valueOf(opticalCapacity.getOccupancyAZ());
            opticalOccupancyZA = String.valueOf(opticalCapacity.getOccupancyZA());
        }

        ptItem.setOpticalOccupancyAZ(opticalOccupancyAZ);
        ptItem.setOpticalOccupancyZA(opticalOccupancyZA);
    }
    
    private void mapChannelInformation(EndPointAdditionalAttributes endpointAdditional, IPhysicalTrail pt) {

        IPhysicalTerminationPointId aEndPTPId = new PhysicalTerminationPointIdItem(pt.getAEndTpParentParentNeId(),pt.getAEndTpParentPtpId());
        IAllowedChannelsPkg aEndChannels = getChannelInfo(aEndPTPId);
        fillEndpointAdditionalAtributes(endpointAdditional, aEndChannels, true);
        	
        IPhysicalTerminationPointId zEndPTPId = new PhysicalTerminationPointIdItem(pt.getZEndTpParentParentNeId(),pt.getZEndTpParentPtpId());
        IAllowedChannelsPkg zEndChannels = getChannelInfo(zEndPTPId);
        fillEndpointAdditionalAtributes(endpointAdditional, zEndChannels, false);
    }

    private IAllowedChannelsPkg getChannelInfo(IPhysicalTerminationPointId aEndPTPId) {
    	
    	IPhysicalTerminationPoint ptp = ptpMap.get(aEndPTPId);
    	if (ptp != null) {
    		return (IAllowedChannelsPkg) ptp.getFacette(IAllowedChannelsPkg.class);
    	}
    	return null;
    }
    
	private void fillEndpointAdditionalAtributes(EndPointAdditionalAttributes endAdditional, IAllowedChannelsPkg allowedChannels, boolean aEnd) {
		//guarantee that the tags will exist 
		if(aEnd) {
			endAdditional.setAEndNeChannelTypes("");
			endAdditional.setAEndNeChannelsAllowed(Collections.emptyList());
		} else {
			endAdditional.setZEndNeChannelTypes("");
			endAdditional.setZEndNeChannelsAllowed(Collections.emptyList());
		}

		if (allowedChannels == null) {
			return;
		}
		
		ChannelType type = allowedChannels.getChannelsType();
		if (type != null) {
			if (aEnd) {
				endAdditional.setAEndNeChannelTypes(type.guiLabel());
			} else {
				endAdditional.setZEndNeChannelTypes(type.guiLabel());
			}
		}
		
		int[] channels = allowedChannels.getChannelsAllowed();
		if (channels != null) {
			if (aEnd) {
				endAdditional.setAEndNeChannelsAllowed(IntStream.of(channels).boxed().collect(Collectors.toList()));
			} else {
				endAdditional.setZEndNeChannelsAllowed(IntStream.of(channels).boxed().collect(Collectors.toList()));
			}
		}
        
	}


    @SuppressWarnings("unchecked")
    private String toXml(TransportLayerSet layers) {
        if (layers == null) {
            return "";
        }
        return new TransportLayerList(IteratorUtils.toList(layers.iterator())).toDbString();
    }

	public void savePtps(List<IPhysicalTerminationPoint> ptps) {
		ptpMap = ptps.stream().collect(Collectors.toMap(IPhysicalTerminationPoint::getPhysicalTerminationPointId, Function.identity()));
	}

	public void saveEquipments(List<IEquipment> equipments) {
		equipmentMap = equipments.stream().collect(Collectors.toMap(IEquipment::getEquipmentId, Function.identity()));	
	}

}
