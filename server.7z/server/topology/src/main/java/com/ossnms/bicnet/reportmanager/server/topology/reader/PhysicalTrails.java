package com.ossnms.bicnet.reportmanager.server.topology.reader;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.topoMgmt.ITopologyMgrFacade;
import com.ossnms.bicnet.bcb.facade.topoMgmt.PhysicalTrailReply;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrail;
import com.ossnms.bicnet.bcb.model.topoMgmt.IPhysicalTrailId;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;

public class PhysicalTrails extends BcbReplyReader<IPhysicalTrailId, IPhysicalTrail, PhysicalTrailReply> {

    private final ISessionContext context;
    private final ITopologyMgrFacade topologyManager;

    public PhysicalTrails(ISessionContext context, ITopologyMgrFacade topologyManager) {
        this.context = context;
        this.topologyManager = topologyManager;
    }

    @Override
    protected PhysicalTrailReply nextReply(IPhysicalTrailId lastId) throws BcbException {
        return topologyManager.getPhysicalTrailList(context, lastId, null, 500);
    }

    @Override protected IPhysicalTrail[] data(PhysicalTrailReply physicalTrailReply) {
        return physicalTrailReply.getData();
    }

    @Override protected IPhysicalTrailId lastId(PhysicalTrailReply physicalTrailReply) {
        return physicalTrailReply.getLastReadId();
    }

    @Override protected boolean isLast(PhysicalTrailReply physicalTrailReply) {
        return physicalTrailReply.endOfFile();
    }
}
