package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.runtime.BatchExecutor;
import com.ossnms.bicnet.reportmanager.server.runtime.BatchStatus;
import com.ossnms.bicnet.reportmanager.server.runtime.Configuration;
import com.ossnms.bicnet.reportmanager.server.runtime.IExecutionConfiguration;
import com.ossnms.bicnet.reportmanager.server.runtime.IExecutor;
import com.ossnms.bicnet.reportmanager.server.runtime.IStepConfiguration;
import com.ossnms.bicnet.reportmanager.server.runtime.JobConfiguration;
import com.ossnms.bicnet.reportmanager.server.runtime.SimpleExecutor;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.JobRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Local;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ExecutionReasonException;

@Stateless
@Local(JobExecutor.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class JobExecutorBean implements JobExecutor {

    private static final Logger LOGGER = LoggerFactory.getLogger(JobExecutorBean.class);

    private SessionContext sessionContext;
    private JobRepository jobRepository;

    public JobExecutorBean() {
    }

    @Inject public JobExecutorBean(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    @Resource public void setSessionContext(SessionContext sessionContext) {
        this.sessionContext = sessionContext;
    }

    @Asynchronous @Override public Future<Boolean> execute(JobConfiguration job, List<Configuration> steps, PersistedJobExecution execution,
                                                           List<JobListener> jobListeners) {
        LOGGER.debug("Started job execution {}", execution.getJobName());

        try {
            jobStarted(execution, jobListeners);

            List<Object> processedObjects = new ArrayList<>();
             for (int i = 0; i < steps.size() && !sessionContext.wasCancelCalled(); i++) {
                IExecutor stepExecutor = createExecutor(steps.get(i));
                if(null != stepExecutor && stepExecutor.accept(steps.get(i))){
                    execution.setCancelListener(stepExecutor);
                    processedObjects.addAll(stepExecutor.process());
                    execution.removeCancelListener(stepExecutor);
                }
            }
            job.resultPostProcess(processedObjects);
            job.marshall();

            if (sessionContext.wasCancelCalled()) {
                setFinishStatus(BatchStatus.CANCELED, execution, null);
            } else {
                setFinishStatus(BatchStatus.FINISHED, execution, null);
            }
        } catch (Exception e) {
            LOGGER.error("Job execution {} failed with exception", execution.getJobName(), e);
            setFinishStatus(BatchStatus.FAILED, execution, ExecutionReasonException.format());
        } finally {
            jobFinished(execution, jobListeners);
        }
        return new AsyncResult<>(true);
    }

    private IExecutor createExecutor(Configuration configuration){
        if(configuration instanceof IStepConfiguration){
            return new BatchExecutor((IStepConfiguration) configuration);
        }
        else if(configuration instanceof IExecutionConfiguration){
            return new SimpleExecutor((IExecutionConfiguration) configuration);
        }
        return null;
    }

    @Override public long run(JobConfiguration configuration) throws BcbException {
        return runConfiguration(configuration, configuration.getJobListeners(), configuration.getSteps());
    }

    private long runConfiguration(JobConfiguration jobConfiguration, List<JobListener> jobListeners, List<Configuration> steps) {
        JobExecutor self = sessionContext.getBusinessObject(JobExecutor.class);
        PersistedJobExecution execution = jobRepository.createNewExecution(jobConfiguration.getJobName());
        Future<Boolean> processHandle = self.execute(jobConfiguration, steps, execution, jobListeners);
        execution.setExecutionHandle(processHandle);
        return execution.getExecutionId();
    }

    @Override public void cancel(PersistedJobExecution jobExecution) {
        jobExecution.cancel();
    }

    @Override public void fail(PersistedJobExecution jobExecution, String exitStatus) {
        jobExecution.cancel();
        setFinishStatus(BatchStatus.FAILED, jobExecution, exitStatus);
    }

    private void jobStarted(PersistedJobExecution execution, Iterable<JobListener> jobListeners) {
        execution.start();
        jobRepository.persistExecution(execution);

        for (JobListener jobListener : jobListeners) {
            jobListener.beforeJob(execution);
        }
    }

    private void setFinishStatus(BatchStatus status, PersistedJobExecution execution, String exitStatus) {
        execution.finish(status, exitStatus);
        jobRepository.persistExecution(execution);
    }

    private void jobFinished(PersistedJobExecution execution, List<JobListener> jobListeners) {
        for (JobListener jobListener : jobListeners) {
            jobListener.afterJob(execution);
        }

        LOGGER.debug("Finished job execution {} with status {}", execution.getJobName(), execution.getBatchStatus());
    }

}
