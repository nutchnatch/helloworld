package com.ossnms.bicnet.reportmanager.server.runtime.execution;


import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.runtime.Configuration;
import com.ossnms.bicnet.reportmanager.server.runtime.JobConfiguration;

import javax.ejb.Asynchronous;
import java.util.List;
import java.util.concurrent.Future;


public interface JobExecutor {
    @Asynchronous Future<Boolean> execute(JobConfiguration jobConfiguration, List<Configuration> steps, PersistedJobExecution execution, List<JobListener> jobListeners);

    long run(JobConfiguration jobConfiguration) throws BcbException;

    void cancel(PersistedJobExecution jobExecution);

    void fail(PersistedJobExecution jobExecution, String exitStatus);
}
