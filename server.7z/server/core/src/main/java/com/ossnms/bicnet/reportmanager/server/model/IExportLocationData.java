package com.ossnms.bicnet.reportmanager.server.model;


import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportLocation;

import java.util.List;

public interface IExportLocationData {

    List<ExportLocationDto> getExportLocationList();

    ExportLocationDto getExportLocationDtoById(String exportId);

    PersistedExportLocation persistExportLocation(PersistedExportLocation persistedExportLocation, boolean isNew);

    PersistedExportLocation getExportLocationById(String exportId);
}
