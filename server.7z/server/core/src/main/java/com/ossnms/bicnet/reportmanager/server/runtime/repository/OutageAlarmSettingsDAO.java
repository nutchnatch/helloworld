package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmSettings;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.*;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem.EXPORTABLE_BY_NAME;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem.FIND_ALL_EXPORTABLE_ITEMS;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmSettings.FIND_ALL_OUTAGE_ALARM_SETTINGS;

@Stateful
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class OutageAlarmSettingsDAO {

    @PersistenceContext(type = PersistenceContextType.TRANSACTION)
    private EntityManager em;

    public List<PersistedOutageAlarmSettings> findAll() {
        TypedQuery<PersistedOutageAlarmSettings> query = em.createNamedQuery(FIND_ALL_OUTAGE_ALARM_SETTINGS, PersistedOutageAlarmSettings.class);
        return query.getResultList();
    }

    public int deleteAll(){
        Query query = em.createQuery("DELETE FROM PersistedOutageAlarmSettings");
        int result = query.executeUpdate();
        return result;
    }

    public void persist(PersistedOutageAlarmSettings execution) {
        if (execution.getId() == null) {
            em.persist(execution);
        } else {
            em.merge(execution);
        }
        em.flush();
    }

}
