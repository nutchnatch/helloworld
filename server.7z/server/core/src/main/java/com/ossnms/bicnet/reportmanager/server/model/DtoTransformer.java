package com.ossnms.bicnet.reportmanager.server.model;


import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.dto.ReportExecutionDto;
import com.ossnms.bicnet.reportmanager.dto.JobExecutionStatus;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.server.runtime.BatchStatus;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.*;

import java.util.Collection;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class DtoTransformer {

    private DtoTransformer() {
    }

    public static ReportExecutionDto from(JobExecution execution) {
        ReportExecutionDto dto = new ReportExecutionDto();
        dto.setJobName(execution.getJobName());
        dto.setExecutionId(execution.getExecutionId());
        dto.setStartTime(((PersistedJobExecution) execution).getStartTimeSeconds());
        dto.setEndTime(((PersistedJobExecution) execution).getEndTimeSeconds());
        dto.setStatus(from(execution.getBatchStatus()));
        return dto;
    }

    private static JobExecutionStatus from(BatchStatus status) {
        return JobExecutionStatus.values()[status.ordinal()];
    }

    public static ExportableItemDto from(IExportablePersistedItem exportable){
        ExportableItemDto dto = new ExportableItemDto();
        dto.setId(exportable.getId());
        dto.setSelection(exportable.getSelection());
        dto.setExportableName(exportable.getItemName());
        dto.setReaders(getReaders(exportable.getReaders()));
        dto.setExportableItemType(exportable.getItemType());
        return dto;
    }

    public static ExportableReaderDto from(IExportablePersistedReader exportable){
        ExportableReaderDto dto = new ExportableReaderDto();
        dto.setId(exportable.getId());
        dto.setSelection(exportable.getSelection());
        dto.setExportableName(exportable.getItemName());
        dto.setReaderType(exportable.getReaderType());
        return dto;
    }

    private static Iterable<ExportableReaderDto> getReaders(Collection readers){

        List<IExportablePersistedReader> tranformReaders = (List<IExportablePersistedReader>) readers.stream()
                .map((Function<PersistedExportableReader, IExportablePersistedReader>) exportedReaders -> exportedReaders)
                .collect(Collectors.toList());

        return tranformReaders.stream()
                .map(new ExportableReaderDtoTransformer())
                .collect(Collectors.toList());

    }

    private static class ExportableReaderDtoTransformer implements Function<IExportablePersistedReader, ExportableReaderDto>{

        @Override
        public ExportableReaderDto apply(IExportablePersistedReader iExportableReader) {
            return ReaderDtoTransformer.from(iExportableReader);
        }
    }
}
