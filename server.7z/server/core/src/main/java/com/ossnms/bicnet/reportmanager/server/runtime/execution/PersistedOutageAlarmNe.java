package com.ossnms.bicnet.reportmanager.server.runtime.execution;


import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "RM_OUTAGE_ALARM_NE")
@NamedQueries({
        @NamedQuery(name= PersistedOutageAlarmNe.FIND_ALL_OUTAGE_ALARM_NES,
        query = "SELECT e FROM PersistedOutageAlarmNe e",
        hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),

        @NamedQuery(name= PersistedOutageAlarmNe.REMOVE_ALL_OUTAGE_ALARM_NES,
                query = "DELETE FROM PersistedOutageAlarmNe",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),
        @NamedQuery(name=PersistedOutageAlarmNe.OUTAGE_ALARM_NE_BY_SETTINGS_ID,
                query = "SELECT ne FROM PersistedOutageAlarmNe ne WHERE ne.outageAlarmSettings=:outageAlarmSettings"),
        @NamedQuery(name= PersistedOutageAlarmNe.OUTAGE_ALARM_NE_BY_NAME,
                query = "SELECT e FROM PersistedOutageAlarmNe e WHERE e.neName=:neName",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")})
})
public class PersistedOutageAlarmNe implements IOutageAlarmNe {

    public static final String FIND_ALL_OUTAGE_ALARM_NES = "PersistedOutageAlarmNe.findALL";
    public static final String REMOVE_ALL_OUTAGE_ALARM_NES = "PersistedOutageAlarmNe.removeALL";
    public static final String OUTAGE_ALARM_NE_BY_NAME = "PersistedOutageAlarmNe.byName";
    public static final String OUTAGE_ALARM_NE_BY_SETTINGS_ID = "PersistedExportableReader.neBySettingsId";

    @Id
    @Column(name = "NE_ID")
    private int id;
    @Column(name = "NE_NAME")
    private String neName;

    @ManyToOne(optional=false)
    @JoinColumn(name = "OUTAGE_ALARM_ID", referencedColumnName = "OUTAGE_ALARM_ID")
    private PersistedOutageAlarmSettings outageAlarmSettings;

    @Override
    public String getNeName() {
        return neName;
    }

    public void setNeName(String neName) {
        this.neName = neName;
    }

    @Override
    public int getNeId() {
        return id;
    };

    public void setId(int id) {
        this.id = id;
    }

    public PersistedOutageAlarmSettings getOutageAlarmSettings() {
        return outageAlarmSettings;
    }

    public void setOutageAlarmSettings(PersistedOutageAlarmSettings outageAlarmSettings) {
        this.outageAlarmSettings = outageAlarmSettings;
    }

    @Override public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        IOutageAlarmNe execution = (IOutageAlarmNe) other;

        return Objects.equals(id, execution.getNeId());

    }

    @Override
    public int hashCode() {
        return id ^ id >>> 31;
    }

    @Override
    public String toString() {
        return "IOutageAlarmNe{" +
                "id=" + id +
                " name=" + neName +
                '}';
    }

}
