package com.ossnms.bicnet.reportmanager.server.model;


import com.ossnms.bicnet.bcb.model.ecs.ExternalCommunicationProtocol;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.IExportLocation;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportLocation;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.ExportLocationRepository;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

@Stateless
public class ExportLocationBean implements IExportLocationData{
    private ExportLocationRepository exportLocationRepository;

    public ExportLocationBean(){
    }

    @Inject
    public ExportLocationBean(ExportLocationRepository exportLocationRepository){
        this.exportLocationRepository = exportLocationRepository;
    }


    @Override
    public List<ExportLocationDto> getExportLocationList() {
        List<PersistedExportLocation> exportLocationList = exportLocationRepository.getAllExportLocationList();
        List<ExportLocationDto> exportLocationDtoList = new ArrayList<>();

        if(null == exportLocationList || exportLocationList.isEmpty()) {
            return Collections.emptyList();
        }

        Iterator<PersistedExportLocation> iterator = exportLocationList.iterator();
        while (iterator.hasNext()) {
            exportLocationDtoList.add(convertToDto(iterator.next()));
        }

        return exportLocationDtoList;
    }

    @Override
    public ExportLocationDto getExportLocationDtoById(String exportId) {
        PersistedExportLocation persistedExportLocation = exportLocationRepository.getExportLocationById(exportId);
        return persistedExportLocation == null ? null : convertToDto(persistedExportLocation);
    }

    private ExportLocationDto convertToDto(IExportLocation exportLocationData) {
        ExportLocationDto exportLocationDto = new ExportLocationDto();

        exportLocationDto.setExportId(exportLocationData.getExportId());
        exportLocationDto.setTransferSettings(new TransferSettings(exportLocationData.getKeepLocal() == 1,
                ExternalCommunicationProtocol.fromName(exportLocationData.getExportLocation())));

        return exportLocationDto;
    }

    @Override
    public PersistedExportLocation persistExportLocation(PersistedExportLocation persistedExportLocation, boolean isNew) {
        exportLocationRepository.persistExecution(persistedExportLocation, isNew);
        return persistedExportLocation;
    }

    @Override
    public PersistedExportLocation getExportLocationById(String exportId) {
        PersistedExportLocation persistedExportLocation = exportLocationRepository.getExportLocationById(exportId);
        return persistedExportLocation;
    }

}
