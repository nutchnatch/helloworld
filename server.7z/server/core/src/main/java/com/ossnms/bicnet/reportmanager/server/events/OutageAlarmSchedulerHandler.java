package com.ossnms.bicnet.reportmanager.server.events;

import static com.ossnms.bicnet.reportmanager.util.Constants.ACTION_TYPE_REPORT_EXECUTION;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

import javax.inject.Inject;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.platform.ISchedulerEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import com.ossnms.bicnet.reportmanager.dto.ImmutableAlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.dto.ImmutableOutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmNeDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.OutageAlarmManagerHelper;
import com.ossnms.bicnet.reportmanager.server.fm.export.FMAlarmDataReader;
import com.ossnms.bicnet.reportmanager.server.fm.export.FMAlarmExportConfiguration;
import com.ossnms.bicnet.reportmanager.server.model.IOutageAlarmData;
import com.ossnms.bicnet.reportmanager.server.model.ReportData;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import com.ossnms.bicnet.reportmanager.server.schedule.events.SchedulerVisitor;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import com.ossnms.bicnet.reportmanager.util.Constants;

public class OutageAlarmSchedulerHandler implements SchedulerVisitor {

    private final JobOperator jobOperator;
    private final ISessionContext context;
    private final ISchedulerEjbFacade scheduler;
    private final IOutageAlarmData outageAlarmData;
    private final FMAlarmDataReader fmAlarmDataReader;

    private static final Logger LOGGER = LoggerFactory.getLogger(OutageAlarmSchedulerHandler.class);
    @Inject
    private OutageAlarmManagerHelper outageAlarmManagerHelper;
    @Inject
    private IOutageAlarmData outageAlarmDataBean;
    @Inject
    private ReportData reportDataBean;

    @Inject
    public OutageAlarmSchedulerHandler(@BiCNet ISessionContext context, JobOperator jobOperator, @BiCNet ISchedulerEjbFacade scheduler, 
                                        IOutageAlarmData outageAlarmData, FMAlarmDataReader fmAlarmDataReader) {
        this.jobOperator = jobOperator;
        this.context = context;
        this.scheduler = scheduler;
        this.outageAlarmData = outageAlarmData;
        this.fmAlarmDataReader = fmAlarmDataReader;
    }

    @Override
    public boolean onScheduleExecution(ScheduleExecution scheduleExecution) throws BcbException {
        LOGGER.debug("On ScheduleExecution {}", scheduleExecution);
        if (Objects.equals(ACTION_TYPE_REPORT_EXECUTION, scheduleExecution.getActionType())) {
            String reportId = scheduleExecution.getActionParameter();
            if(!Objects.equals(reportId, Constants.ALARMS_OUTAGE_REPORT)) {
                return false;
            }

            FMAlarmExportConfiguration fmAlarmExportConfiguration = jobOperator.configuration(FMAlarmExportConfiguration.class);
            OutageAlarmSettingsDto outageAlarmSettingsDto = outageAlarmData.getOutageAlarmSettingsItems();
            ILogRecordFilter recordFilter = outageAlarmData.getOutageRecordFilter(fmAlarmDataReader.getNewFilter());

            INEId[] neIds = outageAlarmSettingsDto.getNes().stream()
                    .map(OutageAlarmNeDto::getNeId)
                    .map(NEIdItem::new)
                    .toArray(INEId[]::new);

            jobOperator.start(fmAlarmExportConfiguration.withFilterAndNes(recordFilter, neIds));
            
            // Automatic moving time range
            if(outageAlarmSettingsDto.getAutomaticTimeRange()) {
                ReportDataDto reportData = reportDataBean.getReportData(context, Constants.ALARMS_OUTAGE_REPORT);
                ISchedule schedule = reportData.getSchedule();
                if (schedule != null) {
                    Date nextExecutionTime = scheduler.getNextExecutionTime(context, schedule.getScheduleId());

                    // Calculate periodicity(delta) to add to the time range
                    Date now = DateUtils.truncate(new Date(), Calendar.SECOND);
                    long delta = nextExecutionTime.getTime() - now.getTime();

                    Date startDate = new Date(outageAlarmSettingsDto.getStartDate());
                    Date endDate = new Date(outageAlarmSettingsDto.getEndDate());
                    
                    OutageAlarmSettingsDto changedDto = ImmutableOutageAlarmSettingsDto.copyOf(outageAlarmSettingsDto)
                            .withStartDate(startDate.getTime() + delta)
                            .withEndDate(endDate.getTime() + delta);
                    
                    outageAlarmManagerHelper.persistOutageAlarmSettings(outageAlarmDataBean, changedDto);
                }
            }
        }
        
        return true;
    }
}
