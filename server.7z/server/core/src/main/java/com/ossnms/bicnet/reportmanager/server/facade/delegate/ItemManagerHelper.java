package com.ossnms.bicnet.reportmanager.server.facade.delegate;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.server.model.IExportableData;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ItemManagerHelper {

    private List<PersistedExportableReader> updateItemReaders(IExportableItem item, PersistedExportableItem exportableItem) {
        List<PersistedExportableReader> persistedReders =
                CollectionUtils.isEmpty(exportableItem.getReaders()) ? fetchReaders(item, exportableItem)
                        : (List<PersistedExportableReader>) exportableItem.getReaders();

        StreamSupport.stream(item.getReaders().spliterator(), false)
                .map(reader -> {
                    persistedReders.stream()
                            .filter(r -> reader.getName().equals(r.getItemName()))
                            .map(r -> {
                                r.setItemName(reader.getName());
                                r.setSelection(reader.getSelection());
                                r.setItemType(reader.getExportableReaderIdentification());
                                return r;
                            }).collect(Collectors.toList());

                    return reader;
                }).collect(Collectors.toList());
        return persistedReders;
    }

    public List<PersistedExportableReader> fetchReaders(IExportableItem item, PersistedExportableItem persistedItem){
        return StreamSupport.stream(item.getReaders().spliterator(), false)
                .map(reader -> {
                    PersistedExportableReader exportableReader = new PersistedExportableReader();
                    exportableReader.setExportableItem(persistedItem);
                    exportableReader.setItemName(reader.getName());
                    exportableReader.setSelection(reader.getSelection());
                    exportableReader.setItemType(reader.getExportableReaderIdentification());

                    return exportableReader;
                }).collect(Collectors.toList());
    }

    private void persistItemSelection(IExportableItem[] exportableItems, IExportableData exportableDataBean) {
        Arrays.stream(exportableDataBean.getAllExportableItems())
                .filter(item -> !ArrayUtils.contains(exportableItems, item))
                .map(item -> {
                    Iterable<PersistedExportableItem> itemToPersistList = exportableDataBean.getItemByName(item.getName());
                    PersistedExportableItem itemToPersist = itemToPersistList.iterator().next();
                    itemToPersist.setSelection(0);
                    exportableDataBean.persistItem(itemToPersist);
                    return item;
                }).toArray();
    }

    public void persisItemsAndReaders(IExportableItem[] exportableItems, IExportableData exportableDataBean) {
        persistItemSelection(exportableItems, exportableDataBean);
        Arrays.stream(exportableItems)
                .filter(item -> item.getExportableElement() == ExportableItemType.DCN_MANAGEMENT ||
                        item.getExportableElement() == ExportableItemType.TOPOLOGICAL_MANAGEMENT)
                .map(item -> {
                    Iterable<PersistedExportableItem> persistedItemList = exportableDataBean.getItemByName(item.getName());

                    PersistedExportableItem exportableItem = persistedItemList.iterator().hasNext() ?
                            persistedItemList.iterator().next() : new PersistedExportableItem();

                    exportableItem.setItemName(item.getName());
                    exportableItem.setSelection(item.getSelection());
                    exportableItem.setItemType(item.getExportableElement());

                    List<PersistedExportableReader> persistedReders = updateItemReaders(item, exportableItem);
                    exportableItem.setReaders(persistedReders);
                    exportableDataBean.persistItem(exportableItem);
                    exportableItem.getReaders().stream()
                            .map(reader -> exportableDataBean.persistReader((PersistedExportableReader) reader))
                            .toArray();

                    return item;
                })
                .collect(Collectors.toList());
    }
}
