package com.ossnms.bicnet.reportmanager.server.model;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.IOutageAlarmNe;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmNe;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmSettings;

import java.util.List;

public interface IOutageAlarmData {

    PersistedOutageAlarmSettings getOutageAlarmSettingsFomDB();
    OutageAlarmSettingsDto getOutageAlarmSettingsItems();
    PersistedOutageAlarmSettings persistSettings(PersistedOutageAlarmSettings outageAlarmSettings);
    PersistedOutageAlarmNe persistNe(PersistedOutageAlarmNe outageAlarmNe);
    void deleteAllSettings();
    void deleteAllNes();
    List<IOutageAlarmNe> getOutageAlarmNeBySettings(PersistedOutageAlarmSettings outageAlarmSettings);
    ILogRecordFilter getOutageRecordFilter(ILogRecordFilter filter);
    INE[] getAllOutageAlarmNe();
    List<PersistedOutageAlarmNe> getAllOutageAlarmNes();

}
