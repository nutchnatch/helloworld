package com.ossnms.bicnet.reportmanager.server.messaging;

import com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageListener;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.platform.NotificationType;
import com.ossnms.bicnet.messaging.direct.listener.BiCNetDirectMessageListener.BiCNetDirectMessageListenerBuilder;

import java.util.Map;
import java.util.Set;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer.ATP_SCHEDULER;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.ALARM_COUNTERS;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.SCHEDULE;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.ATTRIBUTE_VALUE_CHANGE;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.SCHEDULE_EXECUTION;
import static com.ossnms.bicnet.messaging.util.BiCNetNotificationTypeBuilder.builder;

public class ListenersConfiguration {

    /**
     * Subscription configuration for {@link com.ossnms.bicnet.messaging.layering.listener.BiCNetLayeringMessageListener}
     */
    public Map<BiCNetMessageLayer, Map<ManagedObjectType, Set<NotificationType>>> layering() {
        return of(ATP_SCHEDULER, schedulerNotifications());
    }

    /**
     * @return map of managed object types and notifications for the types
     */
    private Map<ManagedObjectType, Set<NotificationType>> schedulerNotifications() {
        return builder()
                .forObject(SCHEDULE).notif(SCHEDULE_EXECUTION)
                .build();
    }


    /**
     * Subscription configuration for {@link IBiCNetDirectMessageListener}
     */
    public IBiCNetDirectMessageListener direct(IBiCNetDirectMessageListener messageListener) {
        BiCNetDirectMessageListenerBuilder builder = new BiCNetDirectMessageListenerBuilder(messageListener);
        builder.acceptsNotification(ATTRIBUTE_VALUE_CHANGE).forObjects(ALARM_COUNTERS);
        return builder.build();
    }
}

