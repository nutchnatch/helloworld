package com.ossnms.bicnet.reportmanager.server.facade.delegate;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.events.Scheduler;
import com.ossnms.bicnet.reportmanager.server.logging.Logger;
import com.ossnms.bicnet.reportmanager.server.logging.Messages;
import org.apache.commons.lang3.StringUtils;

import java.util.Collection;

public class LoggerHelper {

    public void logToCommandLog(final ISessionContext sessionContext, final String reportId, Collection<String> messages,
                                Messages message, Scheduler scheduler, Logger logger) throws BcbException {
        if(null != scheduler.findSchedule(sessionContext, reportId)){
            FluentIterable.from(messages)
                    .filter(input -> !StringUtils.EMPTY.equals(input))
                    .transform((Function<String, Object>) input -> {
                        logger.commandLog(sessionContext, input, reportId);
                        return input;
                    }).last();
        }
        else{
            logger.commandLog(sessionContext, message.format(reportId), reportId);
        }
    }
    
    public void logToCommandLog(final ISessionContext sessionContext, final String reportId, Collection<String> messages,
             Logger logger) throws BcbException {
            FluentIterable.from(messages)
            .filter(input -> !StringUtils.EMPTY.equals(input))
            .transform((Function<String, Object>) input -> {
                logger.commandLog(sessionContext, input, reportId);
                return input;
            }).last();
    }

}
