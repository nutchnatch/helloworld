package com.ossnms.bicnet.reportmanager.server.messaging;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageListener;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IVisitor;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.messaging.layering.listener.BiCNetLayeringMessageListener;
import com.ossnms.bicnet.reportmanager.server.events.ConfigurationSchedulerHandler;
import com.ossnms.bicnet.reportmanager.server.events.InventorySchedulerHandler;
import com.ossnms.bicnet.reportmanager.server.events.OutageAlarmSchedulerHandler;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters.AlarmCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.listeners.AlarmForwardingSchedules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.io.Serializable;
import java.util.Collection;
import java.util.Objects;

import static com.ossnms.bicnet.bcb.messaging.IBiCNetMessage.PROP_SENDER_ID;
import static com.ossnms.bicnet.messaging.layering.listener.BiCNetLayeringMessageListener.DefaultFlowModes.DISCARD;
import static com.ossnms.bicnet.reportmanager.util.Constants.BICNET_COMPONENT_TYPE;
import static java.util.Arrays.asList;

public class MessageListener extends BiCNetLayeringMessageListener implements IBiCNetDirectMessageListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(MessageListener.class);
    private final Collection<IVisitor> notificationHandlers;

    @Inject MessageListener(ConfigurationSchedulerHandler configurationSchedulesHandler,
                            InventorySchedulerHandler inventorySchedulerHandler,
                            OutageAlarmSchedulerHandler outageAlarmSchedulerHandler,
                            AlarmCounters alarmCounters,
                            AlarmForwardingSchedules alarmForwardingSchedules) {
        setDefaultFlowMode(DISCARD); // ignore all NE notifications from mediation
        notificationHandlers = asList(
                configurationSchedulesHandler,
                inventorySchedulerHandler,
                outageAlarmSchedulerHandler,
                alarmCounters,
                alarmForwardingSchedules);
    }

    /**
     * On direct message
     */
    @Override public void onMessage(ISessionContext context, IBiCNetMessage message) throws BcbException {
        handleMessage(message);
    }

    @Override
    protected void onLayerMessage(ISessionContext context, IBiCNetMessage message, IBiCNetMessageDispatcher dispatcher) throws BcbException {
        LOGGER.debug("On message {}", message);
        if (Objects.equals(BICNET_COMPONENT_TYPE.name(), message.getStringProperty(PROP_SENDER_ID))) {
            LOGGER.debug("Own message was ignored");
        } else {
            handleMessage(message);
        }
    }

    private void handleMessage(IBiCNetMessage message) throws BcbException {
        final Serializable payload = message.getObject();
        if (payload instanceof Notification[]) {
            for (Notification notification : (Notification[]) payload) {
                dispatch(notification);
            }
        } else if (payload instanceof Notification) {
            dispatch((Notification) payload);
        } else {
            LOGGER.warn("Message body was ignored {}", payload);
        }
    }

    private void dispatch(final Notification notification) throws BcbException {
        for (IVisitor notificationHandler : notificationHandlers) {
            notification.dispatch(notificationHandler);
        }
    }
}
