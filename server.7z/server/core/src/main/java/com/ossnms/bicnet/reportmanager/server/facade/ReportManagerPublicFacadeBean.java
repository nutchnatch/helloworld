package com.ossnms.bicnet.reportmanager.server.facade;


import com.ossnms.bicnet.bcb.facade.IMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.common.File;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.Log4jLevel;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.scs.ScsComponentState;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.AlarmsForwardingService;
import com.ossnms.bicnet.reportmanager.server.messaging.MessagingService;
import com.ossnms.bicnet.reportmanager.server.model.IExportableData;
import com.ossnms.bicnet.reportmanager.util.Constants;
import com.ossnms.bicnet.util.versions.ServerComponentVersionInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

/**
 * Implementation of IMgrFacade that makes this JEE module a CF.
 * <p/>
 * It will handle the CF BicNet Life cycle (IScsControllable), describe the CF (IBicNetService) and provide CF security
 * info (ISecurityManageable)
 * <p/>
 * <p/>
 * To configure this CF a property file called SCS.reportManager.properties must be deployed in
 * {@code $JBOSS_HOME\deployments\bicnet.ear\conf}
 * <p/>
 * see {@code SCS.reportManager.properties} for more info about this configuration file.
 * <p/>
 * <p/>
 * CF must also add some properties to
 * {@code $JBOSS_HOME\deployments\bicnet.ear\conf\SCS.TNMS.dependency.properties} and to
 * {@code $JBOSS_HOME\deployments\bicnet.ear\conf\SCS.properties}.
 * <p/>
 * <p/>
 * The changes in {@code SCS.TNMS.dependency.properties} must be done in @P SCS project and changes in
 * {@code SCS.properties} are done during TNMS installation process.
 * Take a look on those files on a TNMS installation for more details.
 */
@Stateless(name = "ReportManagerPublicFacade")
@Local(IMgrFacade.class)
public class ReportManagerPublicFacadeBean implements IMgrFacade {

    private static final String NAME = "ReportManager";
    private static final String REPORT_MANAGER_CF = "Report Manager CF";
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportManagerPublicFacadeBean.class);

    @Inject private IExportableData exportableData;
    @Inject MessagingService messagingService;
    @Inject AlarmsForwardingService alarmsForwarding;

    @Override public String getName(ISessionContext sessionContext) throws BcbException {
        return NAME;
    }

    @Override public String getDescription(ISessionContext sessionContext) throws BcbException {
        return REPORT_MANAGER_CF;
    }

    @Override public BiCNetComponentType getComponentType(ISessionContext sessionContext) throws BcbException {
        return Constants.BICNET_COMPONENT_TYPE;
    }

    @Override public Log4jLevel getLog4JDefaultLevel(ISessionContext sessionContext) throws BcbException {
        return Log4jLevel.INFO;
    }

    @Override public ComponentVersionInformation getVersion(ISessionContext sessionContext) throws BcbException {
        return ServerComponentVersionInfo.getVersionInfo(getClass());
    }

    @Override public boolean isTraceDataCollectionSupported(ISessionContext sessionContext) throws BcbException {
        return false;
    }

    @Override public void collectTraceData(ISessionContext sessionContext, File destinationFolder) throws BcbException {
    }

    @Override public void start(ISessionContext sessionContext) throws BcbException {
        LOGGER.info("{}.startConfiguerationExport()", NAME);
    }

    @Override public void init(ISessionContext sessionContext) throws BcbException {
        LOGGER.info("{}.init()", NAME);
        exportableData.persistDefaultItems();
        alarmsForwarding.start();
        messagingService.start();
    }

    @Override
    public void doSync(ISessionContext sessionContext, IBiCNetComponentId[] with, ScsSyncMode syncMode, SyncCategory syncCategory) throws BcbException {
    }

    @Override
    public void doForcedSync(ISessionContext sessionContext, IBiCNetComponentId[] with, ScsSyncMode syncMode, SyncCategory syncCategory) throws BcbException {
    }

    @Override public void doFullSync(ISessionContext sessionContext) throws BcbException {
    }

    @Override public void shutDown(ISessionContext sessionContext) throws BcbException {
        LOGGER.info("{}.shutDown()", NAME);
        messagingService.stop();
    }

    @Override public void stop(ISessionContext sessionContext) throws BcbException {
        LOGGER.info("{}.stop()", NAME);
    }

    @Override public ScsComponentState getState(ISessionContext sessionContext) throws BcbException {
        ScsComponentState scsComponentState = new ScsComponentState();
        scsComponentState.setOperState(OperationalState.ENABLED);
        scsComponentState.setSyncState(ScsSyncState.SYNCHRONIZED);
        return scsComponentState;
    }

    @Override public boolean isStartSupported(ISessionContext sessionContext) throws BcbException {
        return false;
    }

    @Override public boolean isStopSupported(ISessionContext sessionContext) throws BcbException {
        return false;
    }

    @Override public boolean isSyncSupported(ISessionContext sessionContext) throws BcbException {
        return false;
    }

    @Override public String[] getOperations() {
        return new String[0];
    }

    @Override public ISecurableObject[] getSecurableObjects() {
        return new ISecurableObject[0];
    }
}
