package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.IExportablePersistedReader;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader;

import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;

@Singleton
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ExportableReaderRepository {

    private ExportableReadersDAO storage;

    public ExportableReaderRepository() {
    }

    @Inject public ExportableReaderRepository(ExportableReadersDAO storage) {
        this.storage = storage;
    }

    public List<IExportablePersistedReader> getAllExportableReaders(){
        return storage.findAll().stream()
                .collect(Collectors.toList());
    }

    public int deleteAll(){
        return storage.deleteAll();
    }

    public PersistedExportableReader createExportableReaders(PersistedExportableReader persistedExportableReader) {
        persistExecution(persistedExportableReader);
        return persistedExportableReader;
    }

    public List<IExportablePersistedReader> getReaderByItem(PersistedExportableItem item){
        return storage.getReaderByItem(item).stream().collect(Collectors.toList());
    }

    public List<PersistedExportableReader> getReaderByItemList(PersistedExportableItem item) {
        return storage.getReaderByItem(item);
    }

    public List<PersistedExportableReader> getReaderByName(String readerName){
        return storage.getItemByName(readerName);
    }

    public void persistExecution(PersistedExportableReader exportableReader) {
        storage.persist(exportableReader);
    }
}
