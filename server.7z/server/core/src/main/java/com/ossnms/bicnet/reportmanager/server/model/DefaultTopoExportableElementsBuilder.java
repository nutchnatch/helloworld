package com.ossnms.bicnet.reportmanager.server.model;


import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.Collection;

public final class DefaultTopoExportableElementsBuilder {

    protected static PersistedExportableItem createTopoExportableItems(){
        PersistedExportableItem topoItem = new PersistedExportableItem();
        topoItem.setSelection(1);
        topoItem.setItemName(Constants.TOPO);
        topoItem.setItemType(ExportableItemType.TOPOLOGICAL_MANAGEMENT);
        topoItem.setReaders((Collection) createTopoReaders(topoItem));
        return topoItem;
    }

    private static Iterable<PersistedExportableReader> createTopoReaders(PersistedExportableItem item){
        Builder builder = ImmutableList.builder();
        builder.add(createTSReader(item));
        builder.add(createPTReader(item));
        builder.add(createTCReader(item));
        return builder.build();
    }

    private static PersistedExportableReader createTSReader(PersistedExportableItem item){
        PersistedExportableReader tsReader = new PersistedExportableReader();
        tsReader.setSelection(1);
        tsReader.setItemName(Constants.TOPOLOGICAL_SYMBOLS);
        tsReader.setItemType(ExportableReaderType.TOPOLOGICAL_SYMBOL);
        tsReader.setExportableItem(item);

        return tsReader;
    }

    private static PersistedExportableReader createPTReader(PersistedExportableItem item){
        PersistedExportableReader ptReader = new PersistedExportableReader();
        ptReader.setSelection(1);
        ptReader.setItemName(Constants.PHISICAL_TRAILS);
        ptReader.setItemType(ExportableReaderType.PHISICAL_TRAIL);
        ptReader.setExportableItem(item);

        return ptReader;
    }

    private static PersistedExportableReader createTCReader(PersistedExportableItem item){
        PersistedExportableReader tcReader = new PersistedExportableReader();
        tcReader.setSelection(1);
        tcReader.setItemName(Constants.TOPOLOGICAL_CONTAINERS);
        tcReader.setItemType(ExportableReaderType.TOPOLOGICAL_CONTAINER);
        tcReader.setExportableItem(item);

        return tcReader;
    }
}
