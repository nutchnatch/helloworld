package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;

public interface IExportablePersistedReader {

    Long getId();

    String getItemName();

    int getSelection();

    ExportableReaderType getReaderType();

    void setExportableItem(PersistedExportableItem exportableItem);
}
