package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.*;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem.EXPORTABLE_BY_NAME;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem.FIND_ALL_EXPORTABLE_ITEMS;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem.REMOVE_ALL_EXPORTABLE_ITEMS;

@Stateful
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ExportableItemsDAO {

    @PersistenceContext(type = PersistenceContextType.TRANSACTION)
    private EntityManager em;

    public List<PersistedExportableItem> findAll() {
        TypedQuery<PersistedExportableItem> query = em.createNamedQuery(FIND_ALL_EXPORTABLE_ITEMS, PersistedExportableItem.class);
        return query.getResultList();
    }

    public int deleteAll(){
        Query query = em.createQuery("DELETE FROM PersistedExportableItem");
        int result = query.executeUpdate();
        return result;
    }

    public List<PersistedExportableItem> getItemByName(String itemName){
        TypedQuery<PersistedExportableItem> query = em.createNamedQuery(EXPORTABLE_BY_NAME, PersistedExportableItem.class)
                .setParameter("itemName", itemName);
        return query.getResultList();
    }

    public void persist(PersistedExportableItem execution) {
        if (execution.getId() == null) {
            em.persist(execution);
        } else {
            em.merge(execution);
        }
        em.flush();
    }

}
