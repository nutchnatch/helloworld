package com.ossnms.bicnet.reportmanager.server.facade;

import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.ENABLED;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableAlarmMessagingCriteriaSettings.copyOf;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableOutageAlarmNeDto.ne;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ACTIVATION;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.CRITERIA_ACTIVATION;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.CRITERIA_ALARMNUMBER;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.CRITERIA_SEVERITY;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.OCCURENCES_UNTIL;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.PERIODIC;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.START_TIME;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ScheduleStatusChanged;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ScheduleStatusDisabled;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.StartedManually;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.WEEKLY;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.reportmanager.api.ChangedAttributes;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dcn.read.NEReader;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmNeDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.export.server.ExportConfiguration;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;
import com.ossnms.bicnet.reportmanager.server.configuration.SettingsRepository;
import com.ossnms.bicnet.reportmanager.server.events.Scheduler;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.AlarmMessagingManagerHelper;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.DcnDataRequestHelper;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.ExportLocationManagerHelper;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.ItemManagerHelper;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.LoggerHelper;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.OutageAlarmManagerHelper;
import com.ossnms.bicnet.reportmanager.server.fm.export.FMAlarmDataReader;
import com.ossnms.bicnet.reportmanager.server.fm.export.FMAlarmExportConfiguration;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.AlarmMessagingSettings;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.ScheduleDetails;
import com.ossnms.bicnet.reportmanager.server.inventory.InventoryExportConfiguration;
import com.ossnms.bicnet.reportmanager.server.logging.Logger;
import com.ossnms.bicnet.reportmanager.server.logging.Messages;
import com.ossnms.bicnet.reportmanager.server.model.IExportLocationData;
import com.ossnms.bicnet.reportmanager.server.model.IExportableData;
import com.ossnms.bicnet.reportmanager.server.model.IOutageAlarmData;
import com.ossnms.bicnet.reportmanager.server.model.ReportData;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import com.ossnms.bicnet.reportmanager.util.Constants;
import com.ossnms.bicnet.util.LoggerDateFormat;

@Stateless(name = "ReportManagerPrivateFacade")
@Remote(IReportManagerPrivateFacade.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ReportManagerPrivateFacadeBean implements IReportManagerPrivateFacade {

    @Inject private JobOperator jobOperator;
    @Inject private Scheduler scheduler;
    @Inject private ReportData reportData;
    @Inject private Logger logger;
    @Inject private SettingsRepository systemSettingsRepository;
    @Inject private IExportableData exportableDataBean;
    @Inject private IExportLocationData exportLocationDataBean;
    @Inject private DcnDataRequestHelper dcnDataHeper;
    @Inject private ItemManagerHelper itemManagerHelper;
    @Inject private ExportLocationManagerHelper exportLocationManagerHelper;
    @Inject private LoggerHelper loggerHelper;
    @Inject private IOutageAlarmData outageAlarmDataBean;
    @Inject private AlarmMessagingSettings alarmMessagingSettings;
    @Inject private OutageAlarmManagerHelper outageAlarmManagerHelper;
    @Inject private AlarmMessagingManagerHelper alarmMessagingManagerHelper;
    @Inject private FMAlarmDataReader fmAlarmDataReader;
    @Inject private NEReader nesReader;

    @Override
    public void startInventoryReport(ISessionContext sessionContext, String reportId, TransferSettings transferSettings) throws BcbException {
        InventoryExportConfiguration inventoryExportConfiguration = jobOperator.configuration(InventoryExportConfiguration.class);
        logger.commandLog(sessionContext, StartedManually.format(reportId), reportId);
        jobOperator.start(inventoryExportConfiguration.withTransferSettings(transferSettings));
    }

    @Override
    public void startConfigurationReport(ISessionContext sessionContext, String reportId, IExportableItem[] exportableItems, TransferSettings transferSettings) throws BcbException {
        ExportConfiguration expotjob = jobOperator.configuration(ExportConfiguration.class);
        logger.commandLog(sessionContext, StartedManually.format(reportId), reportId);
        jobOperator.start(expotjob.withSettings(exportableItems, transferSettings));
    }

    @Override
    public void startAlarmOutageReport(ISessionContext sessionContext, String reportId, ILogRecordFilter recordFilter, INEId[] nes) throws BcbException {
        logger.commandLog(sessionContext, StartedManually.format(reportId), reportId);
        FMAlarmExportConfiguration fmAlarmExportConfiguration = jobOperator.configuration(FMAlarmExportConfiguration.class);
        jobOperator.start(fmAlarmExportConfiguration.withFilterAndNes(recordFilter, nes));
    }

    @Override
    public void scheduleConfigurationReport(ISessionContext sessionContext, String reportId, ISchedule schedule, IScheduleMarkable mark,
                                            IExportableItem[] exportableItems, ExportLocationDto exportLocationDto) throws BcbException {
        Messages scheduleMessage = scheduleData(sessionContext, reportId, schedule);
        itemManagerHelper.persisItemsAndReaders(exportableItems, exportableDataBean);
        Optional.ofNullable(exportLocationDto).ifPresent(location -> exportLocationManagerHelper.persistExportLocation(exportLocationDataBean,
                exportLocationDto));
        notifyAndLogData(sessionContext, reportId, mark, scheduleMessage);
    }

    @Override
    public void scheduleInventoryReport(ISessionContext sessionContext, String reportId, ISchedule schedule,
                                        IScheduleMarkable mark, ExportLocationDto exportLocationDto) throws BcbException {
        Messages scheduleMessage = scheduleData(sessionContext, reportId, schedule);
        Optional.ofNullable(exportLocationDto).ifPresent(location -> exportLocationManagerHelper.persistExportLocation(exportLocationDataBean,
                exportLocationDto));
        notifyAndLogData(sessionContext, reportId, mark, scheduleMessage);
    }

    @Override
    public void scheduleOutageAlarm(ISessionContext sessionContext, String reportId, ISchedule schedule,
                                    IScheduleMarkable mark, OutageAlarmSettingsDto alarmSettingsDto) throws BcbException {
        Messages scheduleMessage = scheduleData(sessionContext, reportId, schedule);
        outageAlarmManagerHelper.persistOutageAlarmSettings(outageAlarmDataBean, alarmSettingsDto);
        notifyAndLogData(sessionContext, reportId, mark, scheduleMessage);
    }

    private Messages scheduleData(ISessionContext sessionContext, String reportId, ISchedule schedule) throws BcbException {
        scheduler.scheduleReportExecution(sessionContext, schedule, reportId);
        return Objects.equals(ENABLED, schedule.getActivation()) ? ScheduleStatusChanged : ScheduleStatusDisabled;
    }

    private void notifyAndLogData(ISessionContext sessionContext, String reportId, IScheduleMarkable mark, Messages scheduleMessage) throws BcbException {
        List<String> attributes = getChanges(mark, reportId).stream()
                .map(ChangedAttributes::getMessage)
                .filter(input -> !StringUtils.isEmpty(input))
                .collect(toList());

        loggerHelper.logToCommandLog(sessionContext, reportId, attributes, scheduleMessage, scheduler, logger);
        reportData.notifyClient(sessionContext, reportId);
    }


    private Collection<ChangedAttributes> getChanges(IScheduleMarkable markable, String reportId) {
        Builder<ChangedAttributes> builder = ImmutableList.builder();
        builder.add(new ChangedAttributes(markable.isMarkedActivation(), ACTIVATION.format(reportId, markable.getActivation() != null ? markable.getActivation().guiLabel() : null)));
        builder.add(new ChangedAttributes(markable.isMarkedStartTime(), START_TIME.format(reportId,
                LoggerDateFormat.format(markable.getStartTime()))));
        builder.add(new ChangedAttributes(markable.isMarkedUserPeriod(), PERIODIC.format(reportId,
                markable.getUserPeriod() / 1440 + " days and " + markable.getUserPeriod() % 1440 / 60) + " hours"));
        builder.add(new ChangedAttributes(markable.isMarkedWeeklyDays(), WEEKLY.format(reportId, markable.getWeeklyDays())));
        builder.add(new ChangedAttributes(markable.isMarkedMonthlyDays(), Messages.MONTHLY.format(reportId, markable.getMonthlyDays())));
        builder.add(new ChangedAttributes(markable.isMarkedOccurrencesUntilEnd(), OCCURENCES_UNTIL.format(reportId, markable.getOccurrencesUntilEnd())));
        return builder.build();
    }

    @Override public ReportDataDto getReportData(ISessionContext sessionContext, String reportId) throws BcbException {
        return reportData.getReportData(sessionContext, reportId);
    }

    @Override public SystemSettings getSystemSettings(ISessionContext sessionContext) {
        return systemSettingsRepository.getDto();
    }

    @Override public void updateSystemSettings(ISessionContext sessionContext, SystemSettings settings, Collection<String> updateMessages) {
        systemSettingsRepository.persistDto(settings);
        for (String updateMessage : updateMessages) {
            logger.commandLog(sessionContext, updateMessage, "Report Manager Settings");
        }
    }

    @Override
    public List<DcnObject> getDcnList(ISessionContext sessionContext) throws BcbException {
        return dcnDataHeper.getDcnList();
    }

    @Override
    public AlarmMessagingCriteriaSettings getAlarmMessagingCriteriaSettings(ISessionContext sessionContext) throws BcbException {
        Collection<OutageAlarmNeDto> nes = nesReader.read().map(ne -> ne(ne.getId(), ne.getIdName())).sorted().collect(toList());
        return copyOf(alarmMessagingSettings.getAlarmMessagingCriteriaSettings()).withAllNEs(nes);
    }

    @Override
    public Boolean createScheduleAlarmMessaging(ISessionContext sessionContext, String reportId, IScheduleMarkable schedule) throws BcbException {
        Messages scheduleMessage = scheduleData(sessionContext, reportId, schedule);
        notifyAndLogData(sessionContext, reportId, schedule, scheduleMessage);
        alarmMessagingSettings.updateScheduleDetails(new ScheduleDetails(schedule).settings());
        return true;
    }

    @Override
    public Boolean createCriteriaAlarmMessaging(ISessionContext sessionContext, AlarmMessagingCriteriaSettings settings) throws BcbException {
        AlarmMessagingCriteriaSettings oldSettings = getAlarmMessagingCriteriaSettings(sessionContext);
        alarmMessagingSettings.persistSettings(settings);
        notifyAndLogCriteriaData(sessionContext, oldSettings, Constants.ALARM_MESSAGING_REPORT, settings);
        return true;
    }

    private void notifyAndLogCriteriaData(ISessionContext sessionContext, AlarmMessagingCriteriaSettings oldSettings, String reportId, AlarmMessagingCriteriaSettings settings) throws BcbException {
        List<String> attributes = getCriteriaChanges(settings, oldSettings, reportId).stream()
                .map(ChangedAttributes::getMessage)
                .filter(input -> !StringUtils.isEmpty(input))
                .collect(toList());

        loggerHelper.logToCommandLog(sessionContext, reportId, attributes, logger);
        reportData.notifyClient(sessionContext, reportId);
    }
    
    private Collection<ChangedAttributes> getCriteriaChanges(AlarmMessagingCriteriaSettings newSettings, AlarmMessagingCriteriaSettings oldSettings, String reportId) {
        Builder<ChangedAttributes> builder = ImmutableList.builder();
        if(newSettings.threshold().enabled()!=oldSettings.threshold().enabled()){builder.add(new ChangedAttributes(true,  CRITERIA_ACTIVATION.format(reportId, newSettings.threshold().enabled())));}
        if(!newSettings.threshold().number().equals(oldSettings.threshold().number())){builder.add(new ChangedAttributes(true, CRITERIA_ALARMNUMBER.format(reportId, newSettings.threshold().number())));}
        if(!newSettings.threshold().severity().equals(oldSettings.threshold().severity())){builder.add(new ChangedAttributes(true, CRITERIA_SEVERITY.format(reportId, AlarmSeverity.fromOrdinal(newSettings.threshold().severity()).guiLabel())));}
        return builder.build();
    }
    
    @Override
    public Iterable<ExportableItemDto> getExportableItems() {
        return exportableDataBean.getExportableItems();
    }

    @Override
    public List<ExportLocationDto> getExportLocationData() {
        return exportLocationDataBean.getExportLocationList();
    }


    @Override
    public ILogRecordFilter getAlarmFilter() throws BcbException {
        return fmAlarmDataReader.getNewFilter();
    }

    @Override
    public OutageAlarmSettingsDto getOutageAlarmSettingsItems() {
        return outageAlarmDataBean.getOutageAlarmSettingsItems();
    }
}
