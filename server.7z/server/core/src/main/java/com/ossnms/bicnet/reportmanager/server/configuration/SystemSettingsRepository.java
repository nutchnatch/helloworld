/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.configuration;

import com.ossnms.bicnet.reportmanager.api.SystemSettings;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.nio.file.Path;

import static com.ossnms.bicnet.reportmanager.api.ImmutableExportSettings.of;
import static com.ossnms.bicnet.reportmanager.api.ImmutableSystemSettings.settings;

@Stateful
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class SystemSettingsRepository implements SettingsRepository {

    public SystemSettingsRepository() {
        //required for bean construction
    }

    @PersistenceContext private EntityManager entityManager;

    public SystemSettingsRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public Integer inventoryRetentionNumber() {
        PersistedSettings settings = fetchSettings();
        return settings.getInventoryRetentionNumber();
    }

    
    @Override
    public Integer configurationRetentionNumber() {
        PersistedSettings settings = fetchSettings();
        return settings.getConfigurationRetentionNumber();
    }

    @Override
    public Integer outageRetentionNumber() {
        PersistedSettings settings = fetchSettings();
        return settings.getOutageRetentionNumber();
    }

    public void inventoryRetentionNumber(int retentionNumber) {
        PersistedSettings persistedSettings = fetchSettings();
        persistedSettings.setInventoryRetentionNumber(retentionNumber);
        persist(persistedSettings);
    }

    @Override
    public SystemSettings getDto() {
        PersistedSettings persistedSettings = fetchSettings();
        return settings(
                of(persistedSettings.getInventoryRetentionNumber(), getInventoryExportPath().toString()),
                of(persistedSettings.getConfigurationRetentionNumber(), getConfigurationExportPath().toString()),
                of(persistedSettings.getOutageRetentionNumber(), getOutageExportPath().toString()));
    }

    @Override
    public void persistDto(SystemSettings settings) {
        PersistedSettings persistedSettings = new PersistedSettings();
        persistedSettings.setInventoryRetentionNumber(settings.inventory().retentionNumber());
        persistedSettings.setConfigurationRetentionNumber(settings.configurationExport().retentionNumber());
        persistedSettings.setOutageRetentionNumber(settings.outageExport().retentionNumber());
        persist(persistedSettings);
    }

    private PersistedSettings fetchSettings() {
        PersistedSettings settings = entityManager.find(PersistedSettings.class, PersistedSettings.PRIMARY_KEY);
        if (settings == null) {
            return new PersistedSettings();
        }
        return settings;
    }

    private void persist(PersistedSettings settings) {
        if (settingsExist()) {
            entityManager.merge(settings);
        } else {
            entityManager.persist(settings);
        }
    }

    private boolean settingsExist() {
        return entityManager.find(PersistedSettings.class, PersistedSettings.PRIMARY_KEY) != null;
    }

    @Override
    public Path getInventoryExportPath() {
        return ComponentPathConfig.INVENTORY.getPath();
    }

    @Override
    public Path getConfigurationExportPath() {
        return ComponentPathConfig.CONFIGURATION.getPath();
    }
    
    @Override
    public Path getOutageExportPath() {
        return ComponentPathConfig.OUTAGE.getPath();
    }
}
