package com.ossnms.bicnet.reportmanager.server.facade.delegate;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Stream.concat;

import java.util.List;
import java.util.stream.Stream;

import javax.inject.Inject;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.reportmanager.dcn.read.ChannelReader;
import com.ossnms.bicnet.reportmanager.dcn.read.MediatorReader;
import com.ossnms.bicnet.reportmanager.dcn.read.NEReader;
import com.ossnms.bicnet.reportmanager.dcn.read.SystemReader;
import com.ossnms.bicnet.reportmanager.dcn.transform.ChannelToDcnObject;
import com.ossnms.bicnet.reportmanager.dcn.transform.MediatorToDcnObject;
import com.ossnms.bicnet.reportmanager.dcn.transform.NeToDcnObject;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.server.fm.export.FMAlarmDataReader;

public class DcnDataRequestHelper {

    private final NEReader neReader;
    private final FMAlarmDataReader alarmsReader;
    private final ChannelReader channelReaderReader;
    private final SystemReader systemReader;
    private final MediatorReader mediatorReaderReader;

    @Inject public DcnDataRequestHelper(NEReader neReader,
                                        FMAlarmDataReader alarmsReader,
                                        ChannelReader channelReaderReader,
                                        SystemReader systemReader,
                                        MediatorReader mediatorReaderReader) {
        this.neReader = neReader;
        this.alarmsReader = alarmsReader;
        this.channelReaderReader = channelReaderReader;
        this.systemReader = systemReader;
        this.mediatorReaderReader = mediatorReaderReader;
    }

    private Stream<DcnObject> getNes() {
        List<INE> nes = neReader.read().collect(toList());
        return nes.stream().map(new NeToDcnObject(alarmsReader.getSeveritiesByNes(nes), systemReader.getSystemNames()));
    }

    private Stream<DcnObject> getChannels() {
        return channelReaderReader.read().map(new ChannelToDcnObject());
    }

    private Stream<DcnObject> getMediators() {
        return mediatorReaderReader.read().map(new MediatorToDcnObject());
    }

    public List<DcnObject> getDcnList() {
        return concat(concat(getNes(), getChannels()), getMediators()).sorted().collect(toList());
    }
}
