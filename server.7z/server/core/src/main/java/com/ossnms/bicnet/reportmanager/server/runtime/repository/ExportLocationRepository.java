package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportLocation;

import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.List;

@Singleton
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ExportLocationRepository {

    private ExportLocationDAO storage;

    public ExportLocationRepository() {
    }

    @Inject public ExportLocationRepository(ExportLocationDAO storage) {
        this.storage = storage;
    }

    public List<PersistedExportLocation> getAllExportLocationList(){
        return storage.findAll();
    }

    public int deleteAll(){
        return storage.deleteAll();
    }

    public PersistedExportLocation createExportLocation(PersistedExportLocation persistedExportLocation) {
        persistExecution(persistedExportLocation, true);
        return persistedExportLocation;
    }

    public void persistExecution(PersistedExportLocation persistedExportLocation, boolean isNew) {
        storage.persist(persistedExportLocation, isNew);
    }

    public PersistedExportLocation getExportLocationById(String exportId) {
        return storage.findById(exportId);
    }
}
