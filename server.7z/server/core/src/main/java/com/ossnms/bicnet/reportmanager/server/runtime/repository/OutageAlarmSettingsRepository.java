package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.IExportablePersistedItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmSettings;

import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Singleton
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class OutageAlarmSettingsRepository {

    private OutageAlarmSettingsDAO storage;

    public OutageAlarmSettingsRepository() {
    }

    @Inject public OutageAlarmSettingsRepository(OutageAlarmSettingsDAO storage) {
        this.storage = storage;
    }

    public List<PersistedOutageAlarmSettings> getAllOutageAlarmSettingsList(){
        return storage.findAll();
    }

    public int deleteAll(){
        return storage.deleteAll();
    }

    public PersistedOutageAlarmSettings createExportableItems(PersistedOutageAlarmSettings outageAlarmSettings) {
        persistExecution(outageAlarmSettings);
        return outageAlarmSettings;
    }

    public void persistExecution(PersistedOutageAlarmSettings outageAlarmSettings) {
        storage.persist(outageAlarmSettings);
    }
}
