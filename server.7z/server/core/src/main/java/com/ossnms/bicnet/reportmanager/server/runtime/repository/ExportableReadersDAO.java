package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.*;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader.EXPORTABLE_READER_BY_NAME;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader.EXPORTABLE_READER_BY_ITEM_ID;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader.FIND_ALL_EXPORTABLE_READER;

@Stateful
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ExportableReadersDAO {

    @PersistenceContext(type = PersistenceContextType.TRANSACTION)
    private EntityManager em;

    public List<PersistedExportableReader> findAll() {
        TypedQuery<PersistedExportableReader> query = em.createNamedQuery(FIND_ALL_EXPORTABLE_READER, PersistedExportableReader.class);
        return query.getResultList();
    }

    public int deleteAll(){
        Query query = em.createQuery("DELETE FROM PersistedExportableReader");
        int result = query.executeUpdate();
        return result;
    }

    public List<PersistedExportableReader> getReaderByItem(PersistedExportableItem item){
        TypedQuery<PersistedExportableReader> query = em.createNamedQuery(EXPORTABLE_READER_BY_ITEM_ID, PersistedExportableReader.class)
                .setParameter("exportableItem", item);
        return query.getResultList();
    }

    public List<PersistedExportableReader> getItemByName(String readerName){
        TypedQuery<PersistedExportableReader> query = em.createNamedQuery(EXPORTABLE_READER_BY_NAME, PersistedExportableReader.class)
                .setParameter("itemName", readerName);
        return query.getResultList();
    }

    public void persist(PersistedExportableReader execution) {
        if (execution.getId() == null) {
            em.persist(execution);
        } else {
            em.merge(execution);
        }
        em.flush();
    }

}
