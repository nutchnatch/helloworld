package com.ossnms.bicnet.reportmanager.server.facade.delegate;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecordFilterCondition;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmNeDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.server.model.IOutageAlarmData;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.IOutageAlarmNe;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmNe;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmSettings;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CRITICAL;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.INDETERMINATE;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MAJOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MINOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.WARNING;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableOutageAlarmSettingsDto.builder;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;

public class OutageAlarmManagerHelper {

    public void persistOutageAlarmSettings(IOutageAlarmData outageAlarmDataBean, OutageAlarmSettingsDto alarmSettingsDto) {
        outageAlarmDataBean.persistSettings(convertToOutageAlarmSettings(alarmSettingsDto, outageAlarmDataBean));
    }

    private PersistedOutageAlarmSettings convertToOutageAlarmSettings(OutageAlarmSettingsDto dto, IOutageAlarmData outageAlarmDataBean) {
        PersistedOutageAlarmSettings settings = ofNullable(outageAlarmDataBean.getOutageAlarmSettingsFomDB())
                .orElseGet(PersistedOutageAlarmSettings::new);

        settings.setCritical(dto.getCritical());
        settings.setCleared(dto.getCleared());
        settings.setAcknowledged(dto.getAcknowledged());
        settings.setIndeterminate(dto.getIndeterminate());
        settings.setMajor(dto.getMajor());
        settings.setMinor(dto.getMinor());
        settings.setRaised(dto.getRaised());
        settings.setWarning(dto.getWarning());
        settings.setUnacknowledged(dto.getUnacknowledged());
        settings.setStartTime(dto.getStartDate());
        settings.setEndTime(dto.getEndDate());
        settings.setAutomaticTimeRange(dto.getAutomaticTimeRange());

        if(!outageAlarmDataBean.getAllOutageAlarmNes().isEmpty()) {
            outageAlarmDataBean.deleteAllNes();
        }

        List<IOutageAlarmNe> persistenceNeList = dto.getNes().stream()
                .map(neDto -> getOutageAlarmNe(neDto, settings))
                .collect(toList());

        settings.setOutageAlarmNes(persistenceNeList);
        return settings;
    }

    private PersistedOutageAlarmNe getOutageAlarmNe(OutageAlarmNeDto neDto, PersistedOutageAlarmSettings settings) {
        PersistedOutageAlarmNe persistenceNe = new PersistedOutageAlarmNe();
        persistenceNe.setNeName(neDto.getNeName());
        persistenceNe.setId(neDto.getNeId());
        persistenceNe.setOutageAlarmSettings(settings);
        return persistenceNe;
    }

    public OutageAlarmSettingsDto getOutageAlarmSettingsDto(PersistedOutageAlarmSettings settings, List<OutageAlarmNeDto> nes) {
        return builder()
                .raised(settings.getRaised())
                .cleared(settings.getCleared())
                .warning(settings.getWarning())
                .minor(settings.getMinor())
                .critical(settings.getCritical())
                .major(settings.getMajor())
                .indeterminate(settings.getIndeterminate())
                .acknowledged(settings.getAcknowledged())
                .unacknowledged(settings.getUnacknowledged())
                .startDate(settings.getStartTime())
                .endDate(settings.getEndTime())
                .automaticTimeRange(settings.getAutomaticTimeRange())
                .nes(nes)
                .build();
    }

    public void addOutageAlarmFilterConditions(PersistedOutageAlarmSettings outageAlarmSettings, IAlarmLogRecordFilterCondition alarmCondition) {
        alarmCondition.filterByRaisedTimeRange(new Date(outageAlarmSettings.getStartTime()), new Date(outageAlarmSettings.getEndTime()), Boolean.FALSE);

        Map<AlarmSeverity, Boolean> alarmSeverityMap = ImmutableMap.<AlarmSeverity, Boolean>builder()
                .put(WARNING, outageAlarmSettings.getWarning())
                .put(MINOR, outageAlarmSettings.getMinor())
                .put(MAJOR, outageAlarmSettings.getMajor())
                .put(CRITICAL, outageAlarmSettings.getCritical())
                .put(INDETERMINATE, outageAlarmSettings.getIndeterminate())
                .build();

        AlarmSeverity[] severities = alarmSeverityMap.entrySet().stream()
                .filter(Entry::getValue)
                .map(Entry::getKey)
                .toArray(AlarmSeverity[]::new);

        alarmCondition.filterBySeverities(severities, Boolean.FALSE);

        alarmCondition.filterByIsAcknowledged(isAcknowledged(outageAlarmSettings));
        alarmCondition.filterByIsCleared(isCleared(outageAlarmSettings));
    }

    private boolean isAcknowledged(PersistedOutageAlarmSettings alarmSettings) {
        return alarmSettings.getAcknowledged() && !alarmSettings.getUnacknowledged();
        }

    private boolean isCleared(PersistedOutageAlarmSettings alarmSettings) {
        return alarmSettings.getCleared() && !alarmSettings.getRaised();
        }

    public OutageAlarmSettingsDto getDefaultSettings() {
        return builder()
                .unacknowledged(true)
                .acknowledged(true)
                .raised(true)
                .cleared(true)
                .warning(true)
                .minor(true)
                .major(true)
                .critical(true)
                .indeterminate(true)
                .nes(new ArrayList<>())
                .startDate(new Date().getTime())
                .endDate(new Date().getTime())
                .automaticTimeRange(Boolean.FALSE)
                .build();
    }
}
