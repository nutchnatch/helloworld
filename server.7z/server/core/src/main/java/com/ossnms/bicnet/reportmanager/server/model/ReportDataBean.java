package com.ossnms.bicnet.reportmanager.server.model;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.NotificationType;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.ReportExecutionDto;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem.OperationStatus;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem.OperationType;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import com.ossnms.bicnet.reportmanager.server.messaging.MessagePublisher;
import com.ossnms.bicnet.reportmanager.server.runtime.BatchStatus;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import com.ossnms.bicnet.reportmanager.server.events.Scheduler;

@Stateless
public class ReportDataBean implements ReportData {

    private JobOperator jobOperator;
    private Scheduler scheduler;
    private MessagePublisher messagePublisher;

    public ReportDataBean() {
    }

    @Inject public ReportDataBean(JobOperator jobOperator, Scheduler scheduler, MessagePublisher messagePublisher) {
        this.jobOperator = jobOperator;
        this.scheduler = scheduler;
        this.messagePublisher = messagePublisher;
    }

    /**
     * Build {@link ReportDataDto} object with report details
     *
     * @param sessionContext context
     * @param reportId       report name
     * @return report data object
     * @throws BcbException
     */
    @Override
    public ReportDataDto getReportData(ISessionContext sessionContext, String reportId) throws BcbException {
        FluentIterable<JobExecution> executions = FluentIterable.from(jobOperator.getJobExecutions(reportId));

        Optional<ReportExecutionDto> lastExecution = executions
                .last()
                .transform(new JobExecutionToDto());

        Optional<ReportExecutionDto> lastSuccessful = executions
                .filter(new Finished())
                .last()
                .transform(new JobExecutionToDto());

        ISchedule schedule = scheduler.findSchedule(sessionContext, reportId);
        Long nextExecutionTime = scheduler.nextExecutionTime(sessionContext, schedule);

        return new ReportDataDto(
                lastExecution.orNull(),
                lastSuccessful.orNull(),
                schedule,
                reportId,
                nextExecutionTime);
    }

    /**
     * Send a client notification with report data
     *
     * @param sessionContext context
     * @param reportId       report name
     * @throws BcbException
     */
    @Override
    public void notifyClient(ISessionContext sessionContext, String reportId) throws BcbException {
        ReportDataDto data = getReportData(sessionContext, reportId);
        RMMessageItem messageItem = new RMMessageItem(NotificationType.OBJECT_CREATION, OperationStatus.SUCCESSFUL,
                OperationType.EXPORT, data, sessionContext.getUniqId(), true);
        messagePublisher.sendToClientImmediate(messageItem, reportId);
    }

    private static class JobExecutionToDto implements Function<JobExecution, ReportExecutionDto> {
        @Override public ReportExecutionDto apply(JobExecution input) {
            return DtoTransformer.from(input);
        }
    }

    private static class Finished implements Predicate<JobExecution> {
        @Override public boolean apply(JobExecution execution) {
            return execution.getBatchStatus() == BatchStatus.FINISHED;
        }
    }
}
