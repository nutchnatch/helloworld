package com.ossnms.bicnet.reportmanager.server.model;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecordFilterCondition;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmNeDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.OutageAlarmManagerHelper;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.IOutageAlarmNe;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmNe;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmSettings;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.OutageAlarmNeRepository;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.OutageAlarmSettingsRepository;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.dto.ImmutableOutageAlarmNeDto.ne;
import static java.util.stream.Collectors.toList;

@Stateless
public class OutageAlarmDataBean implements IOutageAlarmData{

    private OutageAlarmManagerHelper alarmManagerHelper;
    private OutageAlarmSettingsRepository outageAlarmSettingsRepository;
    private OutageAlarmNeRepository outageAlarmNeRepository;

    public OutageAlarmDataBean(){
    }

    @Inject public OutageAlarmDataBean(OutageAlarmSettingsRepository outageAlarmSettingsRepository,
                                       OutageAlarmNeRepository outageAlarmNeRepository, OutageAlarmManagerHelper alarmManagerHelper){
        this.outageAlarmNeRepository = outageAlarmNeRepository;
        this.outageAlarmSettingsRepository = outageAlarmSettingsRepository;
        this.alarmManagerHelper = alarmManagerHelper;
    }

    @Override
    public PersistedOutageAlarmSettings getOutageAlarmSettingsFomDB() {
        List<PersistedOutageAlarmSettings> alarmSettingsesList = outageAlarmSettingsRepository.getAllOutageAlarmSettingsList();
        if(null == alarmSettingsesList || alarmSettingsesList.isEmpty()) {
            return null;
        }
        return outageAlarmSettingsRepository.getAllOutageAlarmSettingsList().iterator().next();
    }

    @Override
    public OutageAlarmSettingsDto getOutageAlarmSettingsItems() {

        List<PersistedOutageAlarmSettings> settingses = outageAlarmSettingsRepository.getAllOutageAlarmSettingsList();
        if(null == settingses || settingses.isEmpty()) {
            return alarmManagerHelper.getDefaultSettings();
        }

        PersistedOutageAlarmSettings outageAlarmSettings = settingses.iterator().next();

        List<OutageAlarmNeDto> outageAlarmNes = outageAlarmSettings.getOutageAlarmNes().stream()
                .map(alarmNe -> ne(alarmNe.getNeId(), alarmNe.getNeName()))
                .collect(toList());

        return alarmManagerHelper.getOutageAlarmSettingsDto(outageAlarmSettings, outageAlarmNes);
    }

    @Override
    public PersistedOutageAlarmSettings persistSettings(PersistedOutageAlarmSettings outageAlarmSettings) {
        outageAlarmSettingsRepository.persistExecution(outageAlarmSettings);
        return outageAlarmSettings;
    }

    @Override
    public PersistedOutageAlarmNe persistNe(PersistedOutageAlarmNe outageAlarmNe) {
        outageAlarmNeRepository.persistExecution(outageAlarmNe);
        return outageAlarmNe;
    }

    @Override
    public void deleteAllSettings() {
        outageAlarmSettingsRepository.deleteAll();
    }

    @Override
    public void deleteAllNes() {
        outageAlarmNeRepository.deleteAll();
    }

    @Override
    public List<IOutageAlarmNe> getOutageAlarmNeBySettings(PersistedOutageAlarmSettings outageAlarmSettings) {
        return outageAlarmNeRepository.getNEsBySettings(outageAlarmSettings);
    }

    @Override
    public List<PersistedOutageAlarmNe> getAllOutageAlarmNes() {
        return outageAlarmNeRepository.getAllOutagealarmNEs();
    }

    @Override
    public INE[] getAllOutageAlarmNe() {
        PersistedOutageAlarmSettings outageAlarmSettings =
                outageAlarmSettingsRepository.getAllOutageAlarmSettingsList().iterator().next();

        return getOutageAlarmNeBySettings(outageAlarmSettings).stream()
                .map(IOutageAlarmNe::getNeId)
                .toArray(INE[]::new);
    }

    @Override
    public ILogRecordFilter getOutageRecordFilter(ILogRecordFilter filter) {
        PersistedOutageAlarmSettings outageAlarmSettings =
                outageAlarmSettingsRepository.getAllOutageAlarmSettingsList().iterator().next();

        IAlarmLogRecordFilterCondition alarmCondition = (IAlarmLogRecordFilterCondition) filter.newFilterCondition();
        filter.addFilterCondition(alarmCondition);

        alarmManagerHelper.addOutageAlarmFilterConditions(outageAlarmSettings, alarmCondition);
        return filter;
    }
}
