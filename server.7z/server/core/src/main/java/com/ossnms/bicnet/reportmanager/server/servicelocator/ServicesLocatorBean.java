package com.ossnms.bicnet.reportmanager.server.servicelocator;

import com.ossnms.bicnet.bcb.facade.ecs.IECSFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.inventoryMgmt.IInventoryExportFacade;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogMgrFacade;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.platform.ISchedulerEjbFacade;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.topoMgmt.ITopologyMgrFacade;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherConfig;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageDispatcher;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.messaging.BiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.messaging.direct.BiCNetDirectMessageDispatcherFactory;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;

import javax.ejb.Stateless;
import javax.enterprise.inject.Produces;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.EXTERNAL_COMMUNICATION_SERVICE;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.NETWORK_DATA_MANAGER;
import static com.ossnms.bicnet.reportmanager.util.Constants.BICNET_COMPONENT_TYPE;

/**
 * Factory for {@link BiCNet} components using {@link BiCNetServiceLocator}
 */
@Stateless
public class ServicesLocatorBean {

    @Produces @BiCNet public ISessionContext resolveSessionContext() throws UnexpectedException {
        return BiCNetServiceLocator.getInstance().getSecurityManager(BICNET_COMPONENT_TYPE).getSystemAccountContext();
    }

    @Produces @BiCNet public ISystemControlEjbFacade resolveSCSFacade() throws UnexpectedException {
        return BiCNetServiceLocator.getInstance().getScsManager(BICNET_COMPONENT_TYPE);
    }

    @Produces @BiCNet public IInventoryExportFacade resolveInventoryExportFacade() throws UnexpectedException {
        return (IInventoryExportFacade) BiCNetServiceLocator.getInstance().getPublicFacade(
                BiCNetComponentType.INVENTORY_MANAGER, BICNET_COMPONENT_TYPE);
    }

    @Produces @BiCNet public ILogMgrFacade resolveLogManagerFacade() throws UnexpectedException {
        return BiCNetServiceLocator.getInstance().getLogManager(BICNET_COMPONENT_TYPE);
    }

    @Produces @BiCNet public IFaultMgrFacade resolveFaultManagerFacade() throws UnexpectedException {
        return BiCNetServiceLocator.getInstance().getFaultManager(BICNET_COMPONENT_TYPE);
    }

    @Produces @BiCNet public IBiCNetMessageDispatcher resolveMessageDispatcher() {
        return BiCNetMessageDispatcherFactory.getInstance().getDispatcher(BICNET_COMPONENT_TYPE);
    }

    @Produces @BiCNet public ISchedulerEjbFacade resolveScheduler() throws UnexpectedException {
        return BiCNetServiceLocator.getInstance().getScheduler(BICNET_COMPONENT_TYPE);
    }

    @Produces @BiCNet public IEMObjectMgrFacade resolveNEFacade() throws UnexpectedException {
        return BiCNetServiceLocator.getInstance().getEmNeManager(BICNET_COMPONENT_TYPE);
    }
    
    @Produces @BiCNet public INetworkDataManagerFacade resolveNetworkDataManagerFacade() throws UnexpectedException {
        return (INetworkDataManagerFacade) BiCNetServiceLocator.getInstance().getPublicFacade(NETWORK_DATA_MANAGER, BICNET_COMPONENT_TYPE);
    }

    @Produces @BiCNet public ITopologyMgrFacade resolveTopologyManagerFacade() throws UnexpectedException {
        return BiCNetServiceLocator.getInstance().getTopologyManager(BICNET_COMPONENT_TYPE);
    }
    
    @Produces @BiCNet public IBiCNetMessageDispatcherConfig messageDispatcherConfig() throws UnexpectedException {
        return BiCNetMessageDispatcherFactory.getInstance().getDispatcherConfig(BICNET_COMPONENT_TYPE);
    }

    @Produces @BiCNet public IBiCNetDirectMessageDispatcher directMessageDispatcher() throws UnexpectedException {
        return BiCNetDirectMessageDispatcherFactory.getInstance().getDispatcher(BICNET_COMPONENT_TYPE.toString());
    }

    @Produces @BiCNet public IECSFacade externalCommunicationService() throws UnexpectedException {
        return (IECSFacade) BiCNetServiceLocator.getInstance().getPublicFacade(EXTERNAL_COMMUNICATION_SERVICE, BICNET_COMPONENT_TYPE);
    }
}
