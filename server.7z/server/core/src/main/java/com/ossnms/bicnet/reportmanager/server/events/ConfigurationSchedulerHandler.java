package com.ossnms.bicnet.reportmanager.server.events;

import com.ossnms.bicnet.bcb.facade.platform.ISchedulerEjbFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import com.ossnms.bicnet.reportmanager.export.server.ExportConfiguration;
import com.ossnms.bicnet.reportmanager.server.model.IExportLocationData;
import com.ossnms.bicnet.reportmanager.server.model.IExportableData;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import com.ossnms.bicnet.reportmanager.server.schedule.events.SchedulerVisitor;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import com.ossnms.bicnet.reportmanager.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

import java.util.Objects;

import static com.ossnms.bicnet.reportmanager.util.Constants.ACTION_TYPE_REPORT_EXECUTION;

public class ConfigurationSchedulerHandler implements SchedulerVisitor {

    private final JobOperator jobOperator;
    private final IExportableData exportableData;
    private final IExportLocationData exportLocationData;
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationSchedulerHandler.class);

    @Inject
    public ConfigurationSchedulerHandler(JobOperator jobOperator, @BiCNet ISchedulerEjbFacade scheduler,
                                         IExportableData exportableData, IExportLocationData exportLocationData) {

        this.jobOperator = jobOperator;
        this.exportableData = exportableData;
        this.exportLocationData = exportLocationData;
    }

    @Override
    public boolean onScheduleExecution(ScheduleExecution scheduleExecution) throws BcbException {
        LOGGER.debug("On ScheduleExecution {}", scheduleExecution);
        if (Objects.equals(ACTION_TYPE_REPORT_EXECUTION, scheduleExecution.getActionType())) {
            String reportId = scheduleExecution.getActionParameter();
            if(Objects.equals(reportId, Constants.CONFIGURATION_EXPORT_REPORT)) {
                ExportConfiguration expotjob = jobOperator.configuration(ExportConfiguration.class);
                jobOperator.start(expotjob.withSettings(exportableData.getAllExportableItems(),
                        exportLocationData.getExportLocationDtoById(reportId).getTransferSettings()));
            }
        }
        return true;
    }
}
