package com.ossnms.bicnet.reportmanager.server.model;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.dcn.ChannelExportReader;
import com.ossnms.bicnet.reportmanager.dto.export.dcn.DcnExportItem;
import com.ossnms.bicnet.reportmanager.dto.export.dcn.MediatorExportReader;
import com.ossnms.bicnet.reportmanager.dto.export.dcn.NEExportReader;
import com.ossnms.bicnet.reportmanager.dto.export.topo.PTExportReader;
import com.ossnms.bicnet.reportmanager.dto.export.topo.TCExportReader;
import com.ossnms.bicnet.reportmanager.dto.export.topo.TSExportReader;
import com.ossnms.bicnet.reportmanager.dto.export.topo.TopoExportItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.IExportablePersistedItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader;

import java.util.List;
import java.util.stream.Collectors;

public final class InterfaceTransformer {

    private InterfaceTransformer() {
    }

    public static IExportableItem from(IExportablePersistedItem exportable) {
        IExportableItem exportableItem = null;
        if(exportable.getItemType().equals(ExportableItemType.DCN_MANAGEMENT)){
            exportableItem = new DcnExportItem();
            exportableItem.setSelection(exportable.getSelection());
            exportableItem.setReaders(getReaders((List<PersistedExportableReader>) exportable.getReaders()));
        }if(exportable.getItemType().equals(ExportableItemType.TOPOLOGICAL_MANAGEMENT)){
            exportableItem = new TopoExportItem();
            exportableItem.setSelection(exportable.getSelection());
            exportableItem.setReaders(getReaders((List<PersistedExportableReader>) exportable.getReaders()));
        }

        return exportableItem;
    }

    private static Iterable<IExportableReader> getReaders(List<PersistedExportableReader> persistedReders){
        ImmutableList.Builder builder = ImmutableList.builder();

        persistedReders.stream()
                .map(iReader ->{
                    if(iReader.getReaderType().equals(ExportableReaderType.MEDIATOR)){
                        MediatorExportReader mediatorExportReader = new MediatorExportReader();
                        mediatorExportReader.setSelection(iReader.getSelection());
                        builder.add(mediatorExportReader);
                    }
                    if(iReader.getReaderType().equals(ExportableReaderType.CHANNEL)){
                        ChannelExportReader channelExportReader = new ChannelExportReader();
                        channelExportReader.setSelection(iReader.getSelection());
                        builder.add(channelExportReader);
                    }
                    if(iReader.getReaderType().equals(ExportableReaderType.NE)){
                        NEExportReader neExportReader = new NEExportReader();
                        neExportReader.setSelection(iReader.getSelection());
                        builder.add(neExportReader);
                    }
                    if(iReader.getReaderType().equals(ExportableReaderType.TOPOLOGICAL_CONTAINER)){
                        TCExportReader tcExportReader = new TCExportReader();
                        tcExportReader.setSelection(iReader.getSelection());
                        builder.add(tcExportReader);
                    }
                    if(iReader.getReaderType().equals(ExportableReaderType.TOPOLOGICAL_SYMBOL)){
                        TSExportReader tsExportReader = new TSExportReader();
                        tsExportReader.setSelection(iReader.getSelection());
                        builder.add(tsExportReader);
                    }
                    if(iReader.getReaderType().equals(ExportableReaderType.PHISICAL_TRAIL)){
                        PTExportReader ptExportReader = new PTExportReader();
                        ptExportReader.setSelection(iReader.getSelection());
                        builder.add(ptExportReader);
                    }
                    return builder;
                }).collect(Collectors.toList());
        return builder.build();
    }
}
