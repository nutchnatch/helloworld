package com.ossnms.bicnet.reportmanager.server.messaging;

import java.io.Serializable;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.messaging.BiCNetMessage;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import com.ossnms.bicnet.reportmanager.util.Constants;

@Stateless
public class MessagePublisher {

    private IBiCNetMessageDispatcher messageDispatcher;

    public MessagePublisher() {
    }

    @Inject public MessagePublisher(@BiCNet IBiCNetMessageDispatcher messageDispatcher) {
        this.messageDispatcher = messageDispatcher;
    }

    /**
     * Send message to client not waiting for transaction commit
     *
     * @param messageItem message
     * @param actionType  value for {@code Constants.ACTION_TYPE}
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void sendToClientImmediate(Serializable messageItem, String actionType) {
        sentToClient(messageItem, IBiCNetMessage.PROP_CLIENT_SCOPE_VAL_PRIVATE, actionType);
    }

    /**
     * Send message to client on transaction commit
     *
     * @param messageItem message
     * @param actionType  value for {@code Constants.ACTION_TYPE}
     */
    public void sendToClientOnCommit(Serializable messageItem, String actionType) {
        sentToClient(messageItem, IBiCNetMessage.PROP_CLIENT_SCOPE_VAL_PRIVATE, actionType);
    }

    private void sentToClient(Serializable messageItem, String scope, String actionType) {
        IBiCNetMessage message = new BiCNetMessage();
        message.setStringProperty(IBiCNetMessage.PROP_SENDER_ID, Constants.BICNET_COMPONENT_TYPE.toString());
        message.setStringProperty(IBiCNetMessage.PROP_CLIENT_SCOPE, scope);
        message.setStringProperty(Constants.ACTION_TYPE, actionType);
        message.setObject(messageItem);
        messageDispatcher.sendToClient(message);
    }
}
