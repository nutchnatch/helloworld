package com.ossnms.bicnet.reportmanager.server.facade.delegate;

import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmNeDto;

import java.util.List;
import java.util.stream.Stream;

import static com.ossnms.bicnet.reportmanager.dto.ImmutableOutageAlarmNeDto.ne;
import static java.util.stream.Collectors.toList;

public class AlarmMessagingManagerHelper {

    public List<OutageAlarmNeDto> convertDcnDDataToOutage(List<DcnObject> dcnObjs) {
        return dcnObjs.stream()
                .map(dcnObj -> dcnObj.neId().map(id -> ne(id, dcnObj.name())))
                .flatMap(opt -> opt.map(Stream::of).orElseGet(Stream::empty))
                .collect(toList());
    }
}
