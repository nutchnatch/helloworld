package com.ossnms.bicnet.reportmanager.server.events;

import com.ossnms.bicnet.bcb.facade.platform.ISchedulerEjbFacade;
import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.facade.platform.ScheduleReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import com.ossnms.bicnet.reportmanager.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.Date;

import static com.ossnms.bicnet.reportmanager.util.Constants.ACTION_TYPE_REPORT_EXECUTION;
import static java.util.Optional.ofNullable;

public class ExecutionScheduler implements Scheduler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExecutionScheduler.class);
    private static final ISchedule[] NO_SCHEDULES = new ISchedule[0];

    private final ISchedulerEjbFacade scheduler;

    @Inject public ExecutionScheduler(@BiCNet ISchedulerEjbFacade scheduler) {
        this.scheduler = scheduler;
    }

    @Override public boolean onScheduleExecution(ScheduleExecution execution) throws BcbException {
        return false;
    }

    @Override
    public void scheduleReportExecution(ISessionContext context, ISchedule schedule, String reportId) throws BcbException {
        LOGGER.debug("New report ({}) schedule: {}", reportId, schedule);
        schedule.setId(0L);
        schedule.setActionType(ACTION_TYPE_REPORT_EXECUTION);
        schedule.setActionParameter(reportId);
        schedule.setDestination(Constants.BICNET_COMPONENT_TYPE.name());

        deleteSchedule(context, reportId);
        scheduler.createSchedule(context, schedule);
    }

    @Override public ISchedule findSchedule(ISessionContext context, String reportId) throws BcbException {
        ISchedule[] schedules = findSchedules(context, reportId);
        return schedules.length > 0 ? schedules[0] : null;
    }

    private void deleteSchedule(ISessionContext context, String reportId) throws BcbException {
        for (ISchedule schedule : findSchedules(context, reportId)) {
            scheduler.deleteSchedule(context, schedule);
        }
    }

    private ISchedule[] findSchedules(ISessionContext context, String reportId) throws BcbException {
        IScheduleMarkable example = ScheduleItem.markableSchedule(null);
        example.setDestination(Constants.BICNET_COMPONENT_TYPE.name());
        example.setActionType(ACTION_TYPE_REPORT_EXECUTION);
        example.setActionParameter(reportId);
        IScheduleMarkable[] filter = {example};

        return ofNullable(scheduler.getScheduleList(context, null, filter, -1))
                .map(ScheduleReply::getData)
                .orElse(NO_SCHEDULES);
    }

    @Override public Long nextExecutionTime(ISessionContext context, ISchedule schedule) throws BcbException {
        if (schedule == null) {
            return null;
        }
        Date nextExecutionTime = scheduler.getNextExecutionTime(context, schedule);
        if (nextExecutionTime == null) {
            return null;
        }
        return nextExecutionTime.getTime();
    }
}
