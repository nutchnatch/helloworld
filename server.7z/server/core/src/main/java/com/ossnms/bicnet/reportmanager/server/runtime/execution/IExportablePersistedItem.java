package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;

import java.util.Collection;

public interface IExportablePersistedItem {

    Long getId();

    String getItemName();

    int getSelection();

    Collection getReaders();

    ExportableItemType getItemType();
}
