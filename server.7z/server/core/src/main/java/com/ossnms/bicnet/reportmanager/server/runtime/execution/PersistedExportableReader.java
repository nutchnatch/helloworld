package com.ossnms.bicnet.reportmanager.server.runtime.execution;


import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "RM_EXPORTABLE_READERS")
@NamedQueries({
        @NamedQuery(name= PersistedExportableReader.FIND_ALL_EXPORTABLE_READER,
                query = "SELECT e FROM PersistedExportableReader e",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),
        @NamedQuery(name= PersistedExportableReader.REMOVE_ALL_EXPORTABLE_READER,
                query = "DELETE FROM PersistedExportableReader",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),
        @NamedQuery(name= PersistedExportableReader.EXPORTABLE_READER_BY_ITEM_ID,
                query = "SELECT r FROM PersistedExportableReader r WHERE r.exportableItem=:exportableItem",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),
        @NamedQuery(name= PersistedExportableReader.EXPORTABLE_READER_BY_NAME,
                query = "SELECT e FROM PersistedExportableReader e WHERE e.itemName=:itemName",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")})
})

public class PersistedExportableReader implements IExportablePersistedReader {


    public static final String FIND_ALL_EXPORTABLE_READER = "PersistedExportableReader.findALL";
    public static final String EXPORTABLE_READER_BY_NAME = "PersistedExportableReader.findByName";
    public static final String REMOVE_ALL_EXPORTABLE_READER = "PersistedExportableReader.removeALL";
    public static final String EXPORTABLE_READER_BY_ITEM_ID = "PersistedExportableReader.rreaderByItemId";

    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RmExportableReaderSequenceGenerator")
    @SequenceGenerator(name = "RmExportableReaderSequenceGenerator", sequenceName = "RM_EXPORTABLE_READER_SEQUENCE",
            allocationSize = 1)
    @Id
    @Column(name = "READER_ID")
    private Long id;
    @Column(name = "READER_NAME")
    private String itemName;
    @Column(name = "SELECTION")
    private int selection;
    @Column(name = "ITEM_TYPE")
    private ExportableReaderType itemType;

    @ManyToOne(optional=false)
    @JoinColumn(name = "ITEM_ID", referencedColumnName = "ITEM_ID")
    private PersistedExportableItem exportableItem;

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    @Override
    public int getSelection() {
        return selection;
    }

    public void setSelection(int selection) {
        this.selection = selection;
    }

    public PersistedExportableItem getExportableItem() {
        return exportableItem;
    }

    @Override
    public void setExportableItem(PersistedExportableItem exportableItem) {
        this.exportableItem = exportableItem;
    }

    public ExportableReaderType getReaderType() {
        return itemType;
    }

    public void setItemType(ExportableReaderType itemType) {
        this.itemType = itemType;
    }

    @Override public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        IExportablePersistedReader execution = (IExportablePersistedReader) other;

        return Objects.equals(id, execution.getId());

    }

    @Override
    public int hashCode() {
        return (int) (id ^ id >>> 32);
    }

    @Override
    public String toString() {
        return "PersistedExportableReader{" +
                "id=" + id +
                " name=" + itemName +
                " selection=" + selection +
                '}';
    }
}
