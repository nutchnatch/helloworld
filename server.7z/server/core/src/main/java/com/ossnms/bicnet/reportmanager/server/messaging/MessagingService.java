package com.ossnms.bicnet.reportmanager.server.messaging;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherConfig;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageDispatcher;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

import javax.inject.Inject;

public class MessagingService {
    private final IBiCNetMessageDispatcherConfig messageDispatcherConfig;
    private final IBiCNetDirectMessageDispatcher directMessageDispatcher;
    private final MessageListener messageListener;
    private final ListenersConfiguration listenersConfiguration;

    @Inject public MessagingService(@BiCNet IBiCNetMessageDispatcherConfig messageDispatcherConfig,
                                    @BiCNet IBiCNetDirectMessageDispatcher directMessageDispatcher,
                                    MessageListener messageListener,
                                    ListenersConfiguration listenersConfiguration) {
        this.messageDispatcherConfig = messageDispatcherConfig;
        this.directMessageDispatcher = directMessageDispatcher;
        this.messageListener = messageListener;
        this.listenersConfiguration = listenersConfiguration;
    }

    /**
     * Subscribes to notifications
     */
    public void start() {
        listenersConfiguration.layering().forEach((layer, notifications) ->
                messageDispatcherConfig.addListener(layer, messageListener, notifications));
        directMessageDispatcher.register(listenersConfiguration.direct(messageListener));
    }

    /**
     * Unsubscribes from notifications
     */
    public void stop() {
        listenersConfiguration.layering().forEach(messageDispatcherConfig::removeListener);
        directMessageDispatcher.unregister();
    }
}
