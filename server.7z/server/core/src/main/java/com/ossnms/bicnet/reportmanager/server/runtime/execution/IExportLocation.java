package com.ossnms.bicnet.reportmanager.server.runtime.execution;


public interface IExportLocation {

    String getExportId();

    String getExportLocation();

    int getKeepLocal();
}
