package com.ossnms.bicnet.reportmanager.server.model;

import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader;

import java.util.List;

public interface IExportableData {

    Iterable<ExportableItemDto> getExportableItems();

    PersistedExportableItem persistItem(PersistedExportableItem persistedExportableItem);

    Iterable<ExportableReaderDto> getExportableReaders(PersistedExportableItem item);

    PersistedExportableReader persistReader(PersistedExportableReader reader);

    int deleteAllItems();

    int deleteAllReaders();

    Iterable<PersistedExportableItem> getItemByName(String itemName);

    Iterable<PersistedExportableReader> getExportableReadersByItem(PersistedExportableItem item);

    IExportableItem[] getAllExportableItems();

    List<PersistedExportableReader> getReaderByName(String readerName);

    boolean persistDefaultItems();

}
