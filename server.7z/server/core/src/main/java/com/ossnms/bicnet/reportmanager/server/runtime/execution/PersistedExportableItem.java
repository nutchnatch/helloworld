package com.ossnms.bicnet.reportmanager.server.runtime.execution;


import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "RM_EXPORTABLE_ITEMS")
@NamedQueries({
        @NamedQuery(name= PersistedExportableItem.FIND_ALL_EXPORTABLE_ITEMS,
        query = "SELECT e FROM PersistedExportableItem e",
        hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),

        @NamedQuery(name= PersistedExportableItem.REMOVE_ALL_EXPORTABLE_ITEMS,
                query = "DELETE FROM PersistedExportableItem",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),
        @NamedQuery(name= PersistedExportableItem.EXPORTABLE_BY_NAME,
                query = "SELECT e FROM PersistedExportableItem e WHERE e.itemName=:itemName",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")})
})
public class PersistedExportableItem implements IExportablePersistedItem {

    public static final String FIND_ALL_EXPORTABLE_ITEMS = "PersistedExportableItem.findALL";
    public static final String REMOVE_ALL_EXPORTABLE_ITEMS = "PersistedExportableItem.removeALL";
    public static final String EXPORTABLE_BY_NAME = "PersistedExportableItem.byName";
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RmExportableItemsSequenceGenerator")
    @SequenceGenerator(name = "RmExportableItemsSequenceGenerator", sequenceName = "RM_EXPORTABLE_ITEM_SEQUENCE",
            allocationSize = 1)
    @Id
    @Column(name = "ITEM_ID")
    private Long id;
    @Column(name = "ITEM_NAME")
    private String itemName;
    @Column(name = "SELECTION")
    private int selection;
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "ITEM_TYPE")
    private ExportableItemType itemType;

    @OneToMany(mappedBy = "exportableItem", targetEntity = PersistedExportableReader.class, cascade=CascadeType.ALL, fetch = FetchType.EAGER)
    private Collection readers;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    @Override
    public int getSelection() {
        return selection;
    }

    public void setSelection(int selection) {
        this.selection = selection;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public Collection getReaders() {
        return readers;
    }

    public void setReaders(Collection readers) {
        this.readers = readers;
    }

    public ExportableItemType getItemType() {
        return itemType;
    }

    public void setItemType(ExportableItemType itemType) {
        this.itemType = itemType;
    }

    @Override public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        IExportablePersistedItem execution = (IExportablePersistedItem) other;

        return Objects.equals(id, execution.getId());

    }

    @Override
    public int hashCode() {
        return (int) (id ^ id >>> 32);
    }

    @Override
    public String toString() {
        return "PersistedExportableItem{" +
                "id=" + id +
                " name=" + itemName +
                " selection=" + selection +
                '}';
    }
}
