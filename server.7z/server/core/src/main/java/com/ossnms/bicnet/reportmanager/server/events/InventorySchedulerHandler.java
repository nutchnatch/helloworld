package com.ossnms.bicnet.reportmanager.server.events;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import com.ossnms.bicnet.reportmanager.server.inventory.InventoryExportConfiguration;
import com.ossnms.bicnet.reportmanager.server.model.IExportLocationData;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import com.ossnms.bicnet.reportmanager.server.schedule.events.SchedulerVisitor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.Objects;

import static com.ossnms.bicnet.reportmanager.util.Constants.ACTION_TYPE_REPORT_EXECUTION;
import static com.ossnms.bicnet.reportmanager.util.Constants.INVENTORY_EXPORT_REPORT;

public class InventorySchedulerHandler implements SchedulerVisitor {

    private final JobOperator jobOperator;
    private final IExportLocationData exportLocationData;
    private static final Logger LOGGER = LoggerFactory.getLogger(InventorySchedulerHandler.class);

    @Inject
    public InventorySchedulerHandler(JobOperator jobOperator, IExportLocationData exportLocationData) {
        this.jobOperator = jobOperator;
        this.exportLocationData = exportLocationData;
    }

    @Override
    public boolean onScheduleExecution(ScheduleExecution execution) throws BcbException {
        LOGGER.debug("On ScheduleExecution {}", execution);
        if (Objects.equals(ACTION_TYPE_REPORT_EXECUTION, execution.getActionType())) {
            String reportId = execution.getActionParameter();
            if(Objects.equals(reportId, INVENTORY_EXPORT_REPORT)) {
                TransferSettings settings = exportLocationData.getExportLocationDtoById(reportId).getTransferSettings();
                InventoryExportConfiguration job = jobOperator.configuration(InventoryExportConfiguration.class);
                jobOperator.start(job.withTransferSettings(settings));
            }
        }
        return true;
    }
}
