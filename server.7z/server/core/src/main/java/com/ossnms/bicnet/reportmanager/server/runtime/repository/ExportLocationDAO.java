package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportLocation;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportLocation.EXPORT_LOCATION_BY_ID;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportLocation.FIND_ALL_EXPORT_LOCATION;

@Stateful
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ExportLocationDAO {

    @PersistenceContext(type = PersistenceContextType.TRANSACTION)
    private EntityManager em;

    public List<PersistedExportLocation> findAll() {
        TypedQuery<PersistedExportLocation> query = em.createNamedQuery(FIND_ALL_EXPORT_LOCATION, PersistedExportLocation.class);
        return query.getResultList();
    }

    public int deleteAll(){
        Query query = em.createQuery("DELETE FROM PersistedExportLocation");
        int result = query.executeUpdate();
        return result;
    }

    public PersistedExportLocation findById(String exportId) {
        TypedQuery<PersistedExportLocation> query = em.createNamedQuery(EXPORT_LOCATION_BY_ID, PersistedExportLocation.class)
                .setParameter("exportId", exportId);
        return query.getResultList().isEmpty() ? null : query.getSingleResult();
    }

    public void persist(PersistedExportLocation persistedExportLocation, boolean isNew) {
        if (isNew) {
            em.persist(persistedExportLocation);
        } else {
            em.merge(persistedExportLocation);
        }
        em.flush();
    }
}
