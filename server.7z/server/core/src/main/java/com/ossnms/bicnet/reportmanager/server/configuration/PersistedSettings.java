/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.configuration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import static com.ossnms.bicnet.reportmanager.api.ExportSettings.DEFAULT;

@Entity(name = "RM_SETTINGS") class PersistedSettings {

    static final int PRIMARY_KEY = 1;

    @Id @Column(name = "ID")
    private int id = PRIMARY_KEY;

    @Column(name = "INVENTORY_RETENTION")
    private int inventoryRetentionNumber = DEFAULT.retentionNumber();

    @Column(name = "CONFIGURATION_RETENTION")
    private int configurationRetentionNumber = DEFAULT.retentionNumber();

    @Column(name = "OUTAGE_RETENTION")
    private int outageRetentionNumber = DEFAULT.retentionNumber();

    public int getInventoryRetentionNumber() {
        return inventoryRetentionNumber;
    }

    public void setInventoryRetentionNumber(int inventoryRetentionNumber) {
        this.inventoryRetentionNumber = inventoryRetentionNumber;
    }

    public int getConfigurationRetentionNumber() {
        return configurationRetentionNumber;
    }

    public void setConfigurationRetentionNumber(int configurationRetentionNumber) {
        this.configurationRetentionNumber = configurationRetentionNumber;
    }

    public int getOutageRetentionNumber() {
        return outageRetentionNumber;
    }

    public void setOutageRetentionNumber(int outageRetentionNumber) {
        this.outageRetentionNumber = outageRetentionNumber;
    }
}
