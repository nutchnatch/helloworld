package com.ossnms.bicnet.reportmanager.server.runtime;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.JobExecutor;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedJobExecution;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.JobRepository;
import com.ossnms.bicnet.reportmanager.server.servicelocator.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.io.Serializable;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ExecutionReasonTimeout;

@Stateless
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class JobOperatorBean implements JobOperator {

    private static final Logger LOGGER = LoggerFactory.getLogger(JobOperatorBean.class);
    private static final long TIMEOUT_MILLISECONDS = 30 * 60 * 1000; //30 minutes

    private JobExecutor jobExecutor;
    private JobRepository jobRepository;
    private TimerService timerService;

    public JobOperatorBean() {
    }

    @Inject public JobOperatorBean(JobExecutor jobExecutor, JobRepository jobRepository) {
        this.jobExecutor = jobExecutor;
        this.jobRepository = jobRepository;
    }

    @Resource public void setTimerService(TimerService timerService) {
        this.timerService = timerService;
    }

    @Override public long start(String jobName) throws BcbException {
        return start(resolveJob(jobName));
    }

    @Override public long start(JobConfiguration jobConfiguration) throws BcbException {
        LOGGER.info("Starting job {}", jobConfiguration.getJobName());
        return  withTimeout(jobExecutor.run(jobConfiguration), TIMEOUT_MILLISECONDS);
    }

    @Override public void stop(long executionId) {
        PersistedJobExecution jobExecution = jobRepository.getRunningExecution(executionId);
        if (jobExecution != null) {
            jobExecutor.cancel(jobExecution);
        }
    }

    private long withTimeout(long executionId, long timeout) {
        timerService.createTimer(timeout, executionId);
        return executionId;
    }

    @Timeout public void onTimeout(Timer timer) {
        Serializable executionId = timer.getInfo();
        if (!(executionId instanceof Long)) {
            return;
        }
        PersistedJobExecution jobExecution = jobRepository.getRunningExecution((Long) executionId);
        if (jobExecution != null) {
            LOGGER.warn("Job timeout occurred for {}", jobExecution);
            jobExecutor.fail(jobExecution, ExecutionReasonTimeout.format());
        }
    }

    @Override public List<JobExecution> getJobExecutions(final String jobName) {
        return jobRepository.getExecutions(jobName);
    }
    
    public <T extends JobConfiguration> T configuration(Class<T> jobClass) throws BcbException {
        T jobConfiguration = BeanUtils.getBean(jobClass);
        if (jobConfiguration == null) {
            throw new BcbException("Job Configuration not found for class " + jobClass.getSimpleName());
        }
        return jobConfiguration;
    }

    private JobConfiguration resolveJob(String jobName) throws BcbException {
        JobConfiguration jobConfiguration = BeanUtils.getBean(jobName);
        if (jobConfiguration == null) {
            throw new BcbException("Job Configuration not found " + jobName);
        }
        return jobConfiguration;
    }
}
