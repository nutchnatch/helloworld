package com.ossnms.bicnet.reportmanager.server.model;

import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.IExportablePersistedReader;

public final class ReaderDtoTransformer {

    private ReaderDtoTransformer(){
    }

    public static ExportableReaderDto from(IExportablePersistedReader reader){
        ExportableReaderDto readerDto = new ExportableReaderDto();
        readerDto.setId(reader.getId());
        readerDto.setExportableName(reader.getItemName());
        readerDto.setSelection(reader.getSelection());
        readerDto.setReaderType(reader.getReaderType());
        return readerDto;
    }
}
