package com.ossnms.bicnet.reportmanager.server.runtime.execution;

public interface IOutageAlarmNe {

    String getNeName();
    int getNeId();
}
