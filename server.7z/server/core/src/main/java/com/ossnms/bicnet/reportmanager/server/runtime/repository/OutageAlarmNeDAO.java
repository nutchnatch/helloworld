package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.IOutageAlarmNe;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmNe;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmSettings;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.*;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmNe.FIND_ALL_OUTAGE_ALARM_NES;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmNe.OUTAGE_ALARM_NE_BY_SETTINGS_ID;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmSettings.FIND_ALL_OUTAGE_ALARM_SETTINGS;

@Stateful
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class OutageAlarmNeDAO {

    @PersistenceContext(type = PersistenceContextType.TRANSACTION)
    private EntityManager em;

    public List<PersistedOutageAlarmNe> findAll() {
        TypedQuery<PersistedOutageAlarmNe> query = em.createNamedQuery(FIND_ALL_OUTAGE_ALARM_NES, PersistedOutageAlarmNe.class);
        return query.getResultList();
    }

    public List<PersistedOutageAlarmNe> getOutageAlarmNeBySettings(PersistedOutageAlarmSettings settings) {
        TypedQuery<PersistedOutageAlarmNe> query = em.createNamedQuery(OUTAGE_ALARM_NE_BY_SETTINGS_ID, PersistedOutageAlarmNe.class)
                .setParameter("outageAlarmSettings", settings);
        return query.getResultList();
    }

    public int deleteAll(){
        Query query = em.createQuery("DELETE FROM PersistedOutageAlarmNe");
        int result = query.executeUpdate();
        return result;
    }

    public void persist(PersistedOutageAlarmNe execution) {
        if (execution.getNeId() == 0) {
            em.persist(execution);
        } else {
            em.merge(execution);
        }
        em.flush();
    }

}
