package com.ossnms.bicnet.reportmanager.server.runtime.execution;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;
import java.util.Objects;

@Entity
@Table(name = "RM_EXPORT_LOCATION")
@NamedQueries({
        @NamedQuery(name= PersistedExportLocation.FIND_ALL_EXPORT_LOCATION,
                query = "SELECT e FROM PersistedExportLocation e",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),
        @NamedQuery(name= PersistedExportLocation.REMOVE_ALL_EXPORT_LOCATION,
                query = "DELETE FROM PersistedExportLocation",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")}),
        @NamedQuery(name= PersistedExportLocation.EXPORT_LOCATION_BY_ID,
                query = "SELECT e FROM PersistedExportLocation e WHERE e.exportId=:exportId",
                hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")})
})
public class PersistedExportLocation implements IExportLocation {

    public static final String FIND_ALL_EXPORT_LOCATION = "PersistedExportLocation.findALL";
    public static final String REMOVE_ALL_EXPORT_LOCATION = "PersistedExportLocation.removeALL";
    public static final String EXPORT_LOCATION_BY_ID = "PersistedExportLocation.byId";

    @Id
    @Column(name = "EXPORT_ID")
    private String exportId;
    @Column(name = "EXPORT_LOCATION")
    private String exportLocation;
    @Column(name = "KEEP_LOCAL")
    private int keepLocal;


    @Override
    public String getExportId() {
        return exportId;
    }

    public void setExportId(String exportId) {
        this.exportId = exportId;
    }

    @Override
    public String getExportLocation() {
        return exportLocation;
    }

    public void setExportLocation(String exportLocation) {
        this.exportLocation = exportLocation;
    }

    @Override
    public int getKeepLocal() {
        return keepLocal;
    }

    public void setKeeplocal(int keepLocal) {
        this.keepLocal = keepLocal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PersistedExportLocation)) return false;
        PersistedExportLocation that = (PersistedExportLocation) o;
        return getKeepLocal() == that.getKeepLocal() &&
                Objects.equals(getExportId(), that.getExportId()) &&
                Objects.equals(getExportLocation(), that.getExportLocation());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getExportId(), getExportLocation(), getKeepLocal());
    }

    @Override
    public String toString() {
        return "PersistedExportLocation{" +
                "exportId='" + exportId + '\'' +
                ", exportLocation='" + exportLocation + '\'' +
                ", keepLocal=" + keepLocal +
                '}';
    }
}