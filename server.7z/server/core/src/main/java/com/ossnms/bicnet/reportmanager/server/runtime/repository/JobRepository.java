package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Nullable;
import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedJobExecution;

@Singleton
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class JobRepository {

    private final Map<Long, PersistedJobExecution> runningExecutions = new ConcurrentHashMap<>();

    private JobExecutionsDAO storage;

    public JobRepository() {
    }

    @Inject public JobRepository(JobExecutionsDAO storage) {
        this.storage = storage;
    }


    public PersistedJobExecution createNewExecution(String jobName) {
        PersistedJobExecution execution = new PersistedJobExecution(jobName);
        persistExecution(execution);
        return execution;
    }

    public List<JobExecution> getExecutions(final String jobName) {
        return FluentIterable
                .from(storage.findByJobName(jobName))
                .transform(new Function<PersistedJobExecution, JobExecution>() {
                    @Nullable @Override public JobExecution apply(PersistedJobExecution input) {
                        return input;
                    }
                })
                .toList();
    }

    /**
     * Resolves running execution
     *
     * @param executionId id of execution
     * @return execution if it is still running or null if not
     */
    public PersistedJobExecution getRunningExecution(long executionId) {
        return runningExecutions.get(executionId);
    }

    public void persistExecution(PersistedJobExecution execution) {
        storage.persist(execution);
        cacheRunningExecution(execution);
    }

    private void cacheRunningExecution(PersistedJobExecution execution) {
        if (execution.getEndTime() == null) {
            runningExecutions.put(execution.getExecutionId(), execution);
        } else {
            runningExecutions.remove(execution.getExecutionId());
        }
    }

}
