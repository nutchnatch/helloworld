package com.ossnms.bicnet.reportmanager.server.runtime.execution;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.QueryHint;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.util.Collection;
import java.util.Objects;

import static javax.persistence.GenerationType.SEQUENCE;

@Entity
@Table(name = "RM_OUTAGE_ALARM_SETTINGS")
@NamedQueries(@NamedQuery(name = PersistedOutageAlarmSettings.FIND_ALL_OUTAGE_ALARM_SETTINGS,
        query = "SELECT e FROM PersistedOutageAlarmSettings e",
        hints = @QueryHint(name = "org.hibernate.readOnly", value = "true")))
public class PersistedOutageAlarmSettings {

    public static final String FIND_ALL_OUTAGE_ALARM_SETTINGS = "PersistedOutageAlarmSettings.findALL";

    @GeneratedValue(strategy = SEQUENCE, generator = "RmOutageAlarmSettingsSequenceGenerator")
    @SequenceGenerator(name = "RmOutageAlarmSettingsSequenceGenerator", sequenceName = "RM_ALARM_SETTINGS_SEQUENCE", allocationSize = 1)
    @Id @Column(name = "OUTAGE_ALARM_ID")
    private Long id;
    @Column(name = "WARNING")
    private boolean warning;
    @Column(name = "MINOR")
    private boolean minor;
    @Column(name = "MAJOR")
    private boolean major;
    @Column(name = "CRITICAL")
    private boolean critical;
    @Column(name = "INDETERMINATE")
    private boolean indeterminate;
    @Column(name = "UNACKNOWLODGE")
    private boolean unacknowledged;
    @Column(name = "ACKNOWLODGE")
    private boolean acknowledged;
    @Column(name = "CLEARED")
    private boolean cleared;
    @Column(name = "RAISED")
    private boolean raised;
    @Column(name = "START_TIME")
    private Long startTime;
    @Column(name = "END_TIME")
    private Long endTime;
    @Column(name = "AUTOMATIC_TIMERANGE")
    private Boolean automaticTimeRange;


    @OneToMany(mappedBy = "outageAlarmSettings", targetEntity = PersistedOutageAlarmNe.class, cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Collection<IOutageAlarmNe> outageAlarmNes;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean getWarning() {
        return warning;
    }

    public void setWarning(boolean warning) {
        this.warning = warning;
    }

    public boolean getMinor() {
        return minor;
    }

    public void setMinor(boolean minor) {
        this.minor = minor;
    }

    public boolean getMajor() {
        return major;
    }

    public void setMajor(boolean major) {
        this.major = major;
    }

    public boolean getCritical() {
        return critical;
    }

    public void setCritical(boolean critical) {
        this.critical = critical;
    }

    public boolean getIndeterminate() {
        return indeterminate;
    }

    public void setIndeterminate(boolean indeterminate) {
        this.indeterminate = indeterminate;
    }

    public boolean getUnacknowledged() {
        return unacknowledged;
    }

    public void setUnacknowledged(boolean unacknowledged) {
        this.unacknowledged = unacknowledged;
    }

    public boolean getAcknowledged() {
        return acknowledged;
    }

    public void setAcknowledged(boolean acknowledged) {
        this.acknowledged = acknowledged;
    }

    public boolean getCleared() {
        return cleared;
    }

    public void setCleared(boolean cleared) {
        this.cleared = cleared;
    }

    public boolean getRaised() {
        return raised;
    }

    public void setRaised(boolean raised) {
        this.raised = raised;
    }

    public void setOutageAlarmNes(Collection<IOutageAlarmNe> outageAlarmNes) {
        this.outageAlarmNes = outageAlarmNes;
    }

    public Collection<IOutageAlarmNe> getOutageAlarmNes() {
        return outageAlarmNes;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public Boolean getAutomaticTimeRange() {
        return automaticTimeRange;
    }

    public void setAutomaticTimeRange(Boolean automaticTimeRange) {
        this.automaticTimeRange = automaticTimeRange;
    }

    @Override public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        PersistedOutageAlarmSettings execution = (PersistedOutageAlarmSettings) other;

        return Objects.equals(id, execution.getId());
    }

    @Override
    public int hashCode() {
        return (int) (id ^ id >>> 32);
    }

    @Override
    public String toString() {
        return "PersistedOutageAlarmSettings{" +
                "id=" + id +
                " warning=" + warning +
                " minor=" + minor +
                " major=" + major +
                " critical=" + critical +
                " indeterminate=" + indeterminate +
                " unacknowledged=" + unacknowledged +
                " acknowledged=" + acknowledged +
                " cleared=" + cleared +
                " raised=" + raised +
                " start-time=" + startTime +
                " end-time=" + endTime +
                " automaticTimerange=" + automaticTimeRange +
                '}';
    }
}
