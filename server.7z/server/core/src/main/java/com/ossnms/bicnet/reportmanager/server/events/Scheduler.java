/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.events;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution.IVisitor;

public interface Scheduler extends IVisitor {

    /**
     * Create/replace schedule for report
     *
     * @param context  session context
     * @param schedule report execution schedule
     * @param reportId id of report configuration
     * @throws BcbException
     */
    void scheduleReportExecution(ISessionContext context, ISchedule schedule, String reportId) throws BcbException;

    /**
     * Resolves a schedule for specified report
     *
     * @param context  session context
     * @param reportId report configuration id
     * @return report execution schedule or null
     * @throws BcbException
     */
    ISchedule findSchedule(ISessionContext context, String reportId) throws BcbException;

    /**
     * Request for next execution time for specified schedule
     *
     * @param context  session context
     * @param schedule schedule for which to calculate next execution
     * @return next execution time or null
     * @throws BcbException
     */
    Long nextExecutionTime(ISessionContext context, ISchedule schedule) throws BcbException;
}
