package com.ossnms.bicnet.reportmanager.server.configuration;


import java.nio.file.Path;
import java.nio.file.Paths;

import com.ossnms.bicnet.util.ApplicationProperties;

public class ComponentPathConfig {

    public static final ComponentPathConfig INVENTORY = new ComponentPathConfig("InventoryManager"); 
    public static final ComponentPathConfig CONFIGURATION = new ComponentPathConfig("ConfigurationExport");
    public static final ComponentPathConfig OUTAGE = new ComponentPathConfig("OutageExport");

    private static final ApplicationProperties PROPERTIES = ApplicationProperties.getInstance("reportManager-webdav.properties");
    private static final String BASE_FOLDER = "webdavBaseFolder";
    private static final String REPORT_MANAGER = "BaseReportManagerFolder";
    private static final String WEBDAV_FOLDER = "webdav.war";

    private final String componentName;

    ComponentPathConfig(String componentName) {
        this.componentName = componentName;
    }

    /**
     * Resolves path to component specific webdav folder
     *
     * @return path to component webdav folder
     */
    public Path getPath() {
        String baseWebdav = PROPERTIES.getProperty(BASE_FOLDER);
        String reportManager = PROPERTIES.getProperty(REPORT_MANAGER);
        String componentPath = PROPERTIES.getProperty(componentName);
        return Paths.get(baseWebdav, WEBDAV_FOLDER, reportManager, componentPath);
    }
}