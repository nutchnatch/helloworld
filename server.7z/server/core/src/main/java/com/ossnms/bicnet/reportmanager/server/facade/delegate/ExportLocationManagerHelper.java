package com.ossnms.bicnet.reportmanager.server.facade.delegate;

import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.server.model.IExportLocationData;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportLocation;

public class ExportLocationManagerHelper {

    public void persistExportLocation(IExportLocationData exportLocationData, ExportLocationDto exportLocationDto) {
       PersistedExportLocation exportLocationById = exportLocationData.getExportLocationById(exportLocationDto.getExportId());

       if (null == exportLocationById) {
           exportLocationData.persistExportLocation(convertToExportLocation(exportLocationDto), true);
       } else {
           exportLocationData.persistExportLocation(convertToExportLocation(exportLocationDto), false);
       }
    }

    private PersistedExportLocation convertToExportLocation(ExportLocationDto exportLocationDto) {
        PersistedExportLocation persistedExportLocation = new PersistedExportLocation();

        persistedExportLocation.setExportId(exportLocationDto.getExportId());
        persistedExportLocation.setExportLocation(exportLocationDto.getTransferSettings().getExternalCommunicationProtocol().name());
        persistedExportLocation.setKeeplocal(exportLocationDto.getTransferSettings().getKeepLocalFile() ? 1 : 0);

        return persistedExportLocation;
    }

}
