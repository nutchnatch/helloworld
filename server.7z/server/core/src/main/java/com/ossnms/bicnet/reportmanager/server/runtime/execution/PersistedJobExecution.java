package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import java.util.Date;
import java.util.Objects;
import java.util.concurrent.Future;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.ossnms.bicnet.reportmanager.server.runtime.BatchStatus;
import com.ossnms.bicnet.reportmanager.server.runtime.JobCancellableListener;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name = "RM_JOB_EXECUTION")
@NamedQuery(name = PersistedJobExecution.FIND_BY_JOB_NAME,
        query = "FROM PersistedJobExecution p WHERE p.jobName = :jobName order by p.id",
        hints = {@QueryHint(name = "org.hibernate.readOnly", value = "true")})
public class PersistedJobExecution implements JobExecution {

    public static final String FIND_BY_JOB_NAME = "PersistedJobExecution.findByJobName";
    private static final Logger LOGGER = LoggerFactory.getLogger(PersistedJobExecution.class);

    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "RmJobExecutionSequenceGenerator")
    @SequenceGenerator(name = "RmJobExecutionSequenceGenerator", sequenceName = "RM_JOB_EXECUTION_SEQUENCE",
            allocationSize = 1)
    @Id
    @Column(name = "EXECUTION_ID")
    private Long executionId;
    @Column(name = "JOB_NAME")
    private String jobName;
    @Column(name = "START_TIME")
    private Long startTimeSeconds;
    @Column(name = "END_TIME")
    private Long endTimeSeconds;
    @Transient
    private String exitStatus;
    @Enumerated(EnumType.ORDINAL) @Column(name = "STATUS")
    private BatchStatus batchStatus;

    @Transient //used only for running executions to cancel job
    private volatile Future<Boolean> executionHandle;
    @Transient //used only for running executions to cancel job
    private JobCancellableListener cancelListener;

    public PersistedJobExecution(String jobName) {
        batchStatus = BatchStatus.STARTING;
        this.jobName = jobName;
    }

    protected PersistedJobExecution() {
        //constructor for hibernate
    }

    public Long getExecutionId() {
        return executionId;
    }

    public void setExecutionId(Long executionId) {
        this.executionId = executionId;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public Long getStartTimeSeconds() {
        return startTimeSeconds;
    }

    public void setStartTimeSeconds(Long startTime) {
        startTimeSeconds = startTime;
    }

    public Long getEndTimeSeconds() {
        return endTimeSeconds;
    }

    public void setEndTimeSeconds(Long endTime) {
        endTimeSeconds = endTime;
    }

    public BatchStatus getBatchStatus() {
        return batchStatus;
    }

    public void setBatchStatus(BatchStatus batchStatus) {
        this.batchStatus = batchStatus;
    }

    @Override public Date getStartTime() {
        return startTimeSeconds == null ? null : new Date(startTimeSeconds);
    }

    @Override public Date getEndTime() {
        return endTimeSeconds == null ? null : new Date(endTimeSeconds);
    }

    public void setExecutionHandle(Future<Boolean> executionHandle) {
        this.executionHandle = executionHandle;
    }

    @Override public String getExitStatus() {
        return exitStatus;
    }

    /**
     * Execution can be started only once after it is created
     * Other startConfiguerationExport calls are ignored
     */
    public void start() {
        if (batchStatus == BatchStatus.STARTING) {
            LOGGER.debug("Job {} has started", jobName);
            startTimeSeconds = new Date().getTime();
            batchStatus = BatchStatus.STARTED;
        }
    }

    /**
     * Execution can be finished only ones.
     * Next finish calls are ignored
     *
     * @param status finish status
     */
    public void finish(BatchStatus status, String exitStatus) {
        if (batchStatus == BatchStatus.STARTED || batchStatus == BatchStatus.STOPPING) {
            LOGGER.debug("Job {} has finished with status {} and message {}", jobName, status, exitStatus);
            endTimeSeconds = new Date().getTime();
            batchStatus = status;
            this.exitStatus = exitStatus;
        }
    }

    /**
     * Execution can be canceled only if it is running
     * In other cases cancel call is ignored
     */
    public void cancel() {
        if (batchStatus == BatchStatus.STARTED) {
            LOGGER.debug("Job {} is canceled", jobName);
            batchStatus = BatchStatus.STOPPING;
            if (executionHandle != null) {
                executionHandle.cancel(true);
            }
            if (cancelListener != null) {
                cancelListener.cancelRequested();
            }
        }
    }

    @Override public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }

        JobExecution execution = (JobExecution) other;

        return Objects.equals(executionId, execution.getExecutionId());

    }

    @Override public int hashCode() {
        return (int) (executionId ^ executionId >>> 32);
    }


    public void setCancelListener(JobCancellableListener cancelListener) {
        this.cancelListener = cancelListener;
    }

    public void removeCancelListener(JobCancellableListener stopListener) {
        cancelListener = null;
    }

    @Override public String toString() {
        return "PersistedJobExecution{" +
                "executionId=" + executionId +
                ", jobName='" + jobName + '\'' +
                ", startTimeSeconds=" + startTimeSeconds +
                ", endTimeSeconds=" + endTimeSeconds +
                ", batchStatus=" + batchStatus +
                ", exitStatus=" + exitStatus +
                ", executionHandle=" + executionHandle +
                ", cancelListener=" + cancelListener +
                '}';
    }
}
