package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.IExportablePersistedItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;

import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Singleton
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ExportableItemsRepository {

    private ExportableItemsDAO storage;

    public ExportableItemsRepository() {
    }

    @Inject public ExportableItemsRepository(ExportableItemsDAO storage) {
        this.storage = storage;
    }

    public List<PersistedExportableItem> getAllExportableItemsList(){
        return storage.findAll();
    }

    public List<IExportablePersistedItem> getAllExportableItems(){

        return storage.findAll().stream()
                .map((Function<PersistedExportableItem, IExportablePersistedItem>) exportableItems -> exportableItems).collect(Collectors.toList());
    }

    public List<PersistedExportableItem> getItemByName(String itemName){
        return storage.getItemByName(itemName);
    }

    public int deleteAll(){
        return storage.deleteAll();
    }

    public PersistedExportableItem createExportableItems(PersistedExportableItem persistedExportableItem) {
        persistExecution(persistedExportableItem);
        return persistedExportableItem;
    }

    public void persistExecution(PersistedExportableItem exportableItems) {
        storage.persist(exportableItems);
    }
}
