package com.ossnms.bicnet.reportmanager.server.model;

import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.ExportableItemsRepository;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.ExportableReaderRepository;
import com.ossnms.bicnet.reportmanager.util.Constants;

import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Stateless
public class ExportableDataBean implements IExportableData{

    private ExportableItemsRepository itemRepository;
    private ExportableReaderRepository readerRepository;

    public ExportableDataBean(){
    }

    @Inject public ExportableDataBean(ExportableItemsRepository itemRepository, ExportableReaderRepository readerRepository){
        this.itemRepository = itemRepository;
        this.readerRepository = readerRepository;
    }

    @Override
    public Iterable<ExportableItemDto> getExportableItems() {
        return itemRepository.getAllExportableItemsList().stream()
                .peek(item -> item.setReaders(getExportableReadersList(item)))
                .map(DtoTransformer::from)
                .collect(Collectors.toList());
    }

    @Override
    public IExportableItem[] getAllExportableItems(){
        return itemRepository.getAllExportableItemsList().stream()
                .peek(item -> item.setReaders(getExportableReadersList(item)))
                .map(InterfaceTransformer::from)
                .toArray(IExportableItem[]::new);
    }

    @Override
    public List<PersistedExportableReader> getReaderByName(String readerName) {
        return readerRepository.getReaderByName(readerName);
    }

    @Override
    public boolean persistDefaultItems() {
        if(itemRepository.getItemByName(Constants.DCN_MANAGEMENT).isEmpty()){
            PersistedExportableItem dcnItem = DefaultDcnExportableElementsBuilder.createDcnExportableItems();
            itemRepository.createExportableItems(dcnItem);
        }
        if(itemRepository.getItemByName(Constants.TOPO).isEmpty()){
            PersistedExportableItem topoItem = DefaultTopoExportableElementsBuilder.createTopoExportableItems();
            itemRepository.createExportableItems(topoItem);
        }
        return true;
    }

    private Collection<PersistedExportableReader> getExportableReadersList(PersistedExportableItem item) {
        return readerRepository.getReaderByItemList(item);
    }

    @Override
    public Iterable<ExportableReaderDto> getExportableReaders(PersistedExportableItem item) {
        return readerRepository.getReaderByItem(item).stream()
                .map(DtoTransformer::from)
                .collect(Collectors.toList());
    }

    @Override
    public PersistedExportableItem persistItem(PersistedExportableItem persistedExportableItem) {
        return itemRepository.createExportableItems(persistedExportableItem);
    }

    @Override
    public PersistedExportableReader persistReader(PersistedExportableReader reader) {
        return readerRepository.createExportableReaders(reader);
    }

    @Override
    public int deleteAllItems() {
        return itemRepository.deleteAll();
    }

    @Override
    public int deleteAllReaders() {
        return readerRepository.deleteAll();
    }

    @Override
    public List<PersistedExportableItem> getItemByName(String itemName) {
        return itemRepository.getItemByName(itemName);
    }

    @Override
    public Iterable<PersistedExportableReader> getExportableReadersByItem(PersistedExportableItem item) {
        return readerRepository.getReaderByItemList(item);
    }

}
