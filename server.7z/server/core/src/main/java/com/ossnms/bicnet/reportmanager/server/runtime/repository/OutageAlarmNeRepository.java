package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.*;

import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;

@Singleton
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class OutageAlarmNeRepository {

    private OutageAlarmNeDAO storage;

    public OutageAlarmNeRepository() {
    }

    @Inject public OutageAlarmNeRepository(OutageAlarmNeDAO storage) {
        this.storage = storage;
    }

    public List<IOutageAlarmNe> getAllOutageAlarmNes(){
        return storage.findAll().stream()
                .collect(Collectors.toList());
    }

    public int deleteAll(){
        return storage.deleteAll();
    }

    public PersistedOutageAlarmNe createOutagealarmNEs(PersistedOutageAlarmNe persistedOutageAlarmNe) {
        persistExecution(persistedOutageAlarmNe);
        return persistedOutageAlarmNe;
    }

    public List<PersistedOutageAlarmNe> getAllOutagealarmNEs() {
        return storage.findAll();
    }

    public List<IOutageAlarmNe> getNEsBySettings(PersistedOutageAlarmSettings outageAlarmSettings){
        return storage.getOutageAlarmNeBySettings(outageAlarmSettings).stream().collect(Collectors.toList());
    }

    public void persistExecution(PersistedOutageAlarmNe exportableReader) {
        storage.persist(exportableReader);
    }
}
