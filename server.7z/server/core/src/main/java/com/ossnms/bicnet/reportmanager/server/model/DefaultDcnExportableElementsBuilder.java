package com.ossnms.bicnet.reportmanager.server.model;


import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.Collection;

public final class DefaultDcnExportableElementsBuilder {

    protected static PersistedExportableItem createDcnExportableItems(){
        PersistedExportableItem dcnItem = new PersistedExportableItem();
        dcnItem.setSelection(1);
        dcnItem.setItemName(Constants.DCN_MANAGEMENT);
        dcnItem.setItemType(ExportableItemType.DCN_MANAGEMENT);
        dcnItem.setReaders((Collection) createDcnReaders(dcnItem));
        return dcnItem;
    }

    private static Iterable<PersistedExportableReader> createDcnReaders(PersistedExportableItem item){
        Builder builder = ImmutableList.builder();
        builder.add(createMediatorReader(item));
        builder.add(createChannelReader(item));
        builder.add(createNetworkElementReader(item));
        return builder.build();
    }

    private static PersistedExportableReader createMediatorReader(PersistedExportableItem item){
        PersistedExportableReader mediatorReader = new PersistedExportableReader();
        mediatorReader.setSelection(1);
        mediatorReader.setItemName(Constants.MEDIATORS);
        mediatorReader.setItemType(ExportableReaderType.MEDIATOR);
        mediatorReader.setExportableItem(item);

        return mediatorReader;
    }

    private static PersistedExportableReader createChannelReader(PersistedExportableItem item){
        PersistedExportableReader channelReader = new PersistedExportableReader();
        channelReader.setSelection(1);
        channelReader.setItemName(Constants.CHANNELS);
        channelReader.setItemType(ExportableReaderType.CHANNEL);
        channelReader.setExportableItem(item);

        return channelReader;
    }

    private static PersistedExportableReader createNetworkElementReader(PersistedExportableItem item){
        PersistedExportableReader channelReader = new PersistedExportableReader();
        channelReader.setSelection(1);
        channelReader.setItemName(Constants.NETWORK_ELEMENTS);
        channelReader.setItemType(ExportableReaderType.NE);
        channelReader.setExportableItem(item);

        return channelReader;
    }
}
