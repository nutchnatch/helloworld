package com.ossnms.bicnet.reportmanager.server.runtime.repository;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedJobExecution.FIND_BY_JOB_NAME;

import java.util.List;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;

import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedJobExecution;

@Stateful
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class JobExecutionsDAO {

    @PersistenceContext(type = PersistenceContextType.EXTENDED) private EntityManager em;

    public List<PersistedJobExecution> findByJobName(final String jobName) {
        TypedQuery<PersistedJobExecution> query = em.createNamedQuery(FIND_BY_JOB_NAME, PersistedJobExecution.class);
        query.setParameter("jobName", jobName);
        return query.getResultList();
    }

    public void persist(PersistedJobExecution execution) {
        if (execution.getExecutionId() == null) {
            em.persist(execution);
        } else {
            em.merge(execution);
        }
        em.flush();
    }

}
