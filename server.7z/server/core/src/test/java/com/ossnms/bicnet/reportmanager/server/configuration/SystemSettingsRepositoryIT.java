/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.configuration;

import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import java.nio.file.Path;
import java.nio.file.Paths;

import static com.ossnms.bicnet.reportmanager.api.ImmutableExportSettings.of;
import static com.ossnms.bicnet.reportmanager.api.ImmutableSystemSettings.copyOf;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class SystemSettingsRepositoryIT {

    private static final String TEST_INVENTORY_EXPORT_PATH = "/test/webdav/webdav.war/reportmanager/networkinventory";
    private SystemSettingsRepository settingsRepository;

    @Before public void setUp() throws Exception {
        EntityManager entityManager = Persistence.createEntityManagerFactory("REPORT_MANAGER-PU").createEntityManager();
        settingsRepository = new SystemSettingsRepository(entityManager);
    }

    @Test public void shouldProvideDefaultValueForRetentionNumber() throws Exception {
        //given clean system settings

        //when options is requested
        Integer retentionNumber = settingsRepository.inventoryRetentionNumber();

        //then result should be default value
        assertThat(retentionNumber, is(90));
    }

    @Test public void shouldStoreRetentionNumber() throws Exception {
        //given system settings
        int retentionNumber = 42;

        //when retentionNumber is set
        settingsRepository.inventoryRetentionNumber(retentionNumber);

        //then the same value should be retrieved
        assertThat(settingsRepository.inventoryRetentionNumber(), is(retentionNumber));
    }

    @Test public void shouldStoreSettingsFromDto() throws Exception {
        //given system settings dto
        int retentionNumber = 37;
        SystemSettings settings = copyOf(SystemSettings.DEFAULT).withInventory(of(retentionNumber, "anyPath"));

        //when dto is saved
        settingsRepository.persistDto(settings);

        assertThat(settingsRepository.inventoryRetentionNumber(), is(retentionNumber));
    }

    @Test public void shouldFetchSettingsDto() throws Exception {
        //given settings with value
        int retentionNumber = 23;
        settingsRepository.inventoryRetentionNumber(retentionNumber);

        //when dto is fetched
        SystemSettings systemSettings = settingsRepository.getDto();

        //then it contains all settings
        assertThat(systemSettings.inventory().retentionNumber(), is(retentionNumber));
        assertThat(Paths.get(systemSettings.inventory().exportPath()), is(Paths.get(TEST_INVENTORY_EXPORT_PATH)));
    }

    @Test public void shouldProvideInventoryExportPath() throws Exception {
        Path inventoryExportPath = settingsRepository.getInventoryExportPath();
        assertThat(inventoryExportPath, is(Paths.get(TEST_INVENTORY_EXPORT_PATH)));
    }
}