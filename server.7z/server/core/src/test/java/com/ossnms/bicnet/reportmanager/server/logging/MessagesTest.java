package com.ossnms.bicnet.reportmanager.server.logging;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

public class MessagesTest {
    @Test public void shouldWorkWithoutArguments() throws Exception {
        String message = Messages.ExecutionStatusFinished.format();
        assertThat(message, is("Finished"));
    }

    @Test public void shouldWorkWithArguments() throws Exception {
        String message = Messages.ExecutionStatus.format("started", "report", "details");
        assertThat(message, is("started execution of report details"));
    }
}