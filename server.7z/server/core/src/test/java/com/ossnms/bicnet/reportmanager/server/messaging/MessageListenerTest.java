package com.ossnms.bicnet.reportmanager.server.messaging;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import com.ossnms.bicnet.messaging.BiCNetMessage;
import com.ossnms.bicnet.reportmanager.server.events.ConfigurationSchedulerHandler;
import com.ossnms.bicnet.reportmanager.server.events.InventorySchedulerHandler;
import com.ossnms.bicnet.reportmanager.server.events.OutageAlarmSchedulerHandler;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters.AlarmCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.listeners.AlarmForwardingSchedules;
import org.junit.Before;
import org.junit.Test;

import java.io.Serializable;

import static com.ossnms.bicnet.bcb.messaging.IBiCNetMessage.PROP_SENDER_ID;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.REPORT_MANAGER;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

public class MessageListenerTest {

    private MessageListener messageListener;
    private ConfigurationSchedulerHandler configurationSchedulerHandler;
    private InventorySchedulerHandler inventorySchedulerHandler;
    private OutageAlarmSchedulerHandler outageAlarmSchedulerHandler;
    private AlarmForwardingSchedules forwardingSchedules;
    private AlarmCounters alarmCounters;

    @Before public void setUp() throws Exception {
        configurationSchedulerHandler = mock(ConfigurationSchedulerHandler.class);
        inventorySchedulerHandler = mock(InventorySchedulerHandler.class);
        outageAlarmSchedulerHandler = mock(OutageAlarmSchedulerHandler.class);
        alarmCounters = mock(AlarmCounters.class);
        forwardingSchedules = mock(AlarmForwardingSchedules.class);
        messageListener = new MessageListener(configurationSchedulerHandler, inventorySchedulerHandler, outageAlarmSchedulerHandler, alarmCounters, forwardingSchedules);

    }

    @Test public void shouldTriggerSchedulerOnScheduleNotification() throws Exception {
        //given schedule execution notification
        ScheduleExecution scheduleExecution = new ScheduleExecution();
        IBiCNetMessage message = message(new ScheduleExecution[]{scheduleExecution});

        //when
        messageListener.onMessage(null, message, null);

        //then should trigger scheduler
        verify(configurationSchedulerHandler).onScheduleExecution(scheduleExecution);
        verify(inventorySchedulerHandler).onScheduleExecution(scheduleExecution);
        verify(outageAlarmSchedulerHandler).onScheduleExecution(scheduleExecution);
        verify(forwardingSchedules).onScheduleExecution(scheduleExecution);
    }

    @Test public void shouldTriggerDirectMessageHandler() throws Exception {
        //given notification
        AttributeValueChange notification = new AttributeValueChange();

        //when
        messageListener.onMessage(null, message(notification));

        //then should trigger direct handler
        verify(alarmCounters).onAttributeValueChange(notification);
    }

    @Test public void shouldIgnoreOwnNotifications() throws Exception {
        //given message from report manager
        ScheduleExecution scheduleExecution = new ScheduleExecution();
        IBiCNetMessage message = message(new ScheduleExecution[]{scheduleExecution});
        message.setStringProperty(PROP_SENDER_ID, REPORT_MANAGER.name());

        //when
        messageListener.onMessage(null, message, null);

        //then should ignore message
        verify(configurationSchedulerHandler, never()).onScheduleExecution(scheduleExecution);
        verify(inventorySchedulerHandler, never()).onScheduleExecution(scheduleExecution);
        verify(outageAlarmSchedulerHandler, never()).onScheduleExecution(scheduleExecution);
        verify(forwardingSchedules, never()).onScheduleExecution(scheduleExecution);
    }

    private IBiCNetMessage message(Serializable object) {
        IBiCNetMessage message = new BiCNetMessage();
        message.setObject(object);
        return message;
    }
}