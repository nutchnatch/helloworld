package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import java.util.ArrayList;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableItem.EXPORTABLE_BY_NAME;
import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader.EXPORTABLE_READER_BY_NAME;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;


public class PersistedExportableItemIT {

    private EntityManager em = Persistence.createEntityManagerFactory("REPORT_MANAGER-EI").createEntityManager();

    @Test public void shouldGenerateId() throws Exception {
        //given some execution
        IExportablePersistedItem persistedItem = new PersistedExportableItem();

        //when it is persisted
        persistItem(persistedItem);

        //then execution should have generated id
        assertThat(persistedItem.getId(), is(notNullValue()));
    }

    @Test public void readerShouldGenerateId() throws Exception {
        //given some execution
        PersistedExportableItem persistedItem = new PersistedExportableItem();

        //when it is persisted
        persistItem(persistedItem);

        //given some execution
        PersistedExportableReader reader = new PersistedExportableReader();
        reader.setExportableItem(persistedItem);

        //when it is persisted
        persistReader(reader);

        //then execution should have generated id
        assertThat(reader.getId(), is(notNullValue()));
    }

    @Test public void shouldFindPersistedExecution() throws Exception {
        //given some persisted execution
        PersistedExportableItem persisted = new PersistedExportableItem();
        Long id = persistItem(persisted);

        //when it is queried
        PersistedExportableItem found = fetch(id);

        //then it should be the same as persisted
        assertThat(found, is(persisted));
    }

    @Test public void shouldPersistFields() throws Exception {
        //given some persisted execution
        PersistedExportableItem persisted = new PersistedExportableItem();

        persisted.setItemName("DCN");
        persisted.setSelection(1);
        persisted.setItemType(ExportableItemType.DCN_MANAGEMENT);
        Long id = persistItem(persisted);

        //when it is fetched
        PersistedExportableItem found = fetch(id);

        //then it should contain all fields
        assertThat(found.getId(), is(id));
        assertThat(found.getItemName(), is(persisted.getItemName()));
        assertThat(found.getSelection(), is(persisted.getSelection()));
        assertThat(found.getItemType(), is(persisted.getItemType()));
    }

    @Test public void getAllItems(){

        PersistedExportableItem persisted = new PersistedExportableItem();

        persisted.setItemName("DCN");
        persisted.setSelection(1);
        persisted.setItemType(ExportableItemType.DCN_MANAGEMENT);
        Long id = persistItem(persisted);

        //when it is fetched
        PersistedExportableItem found = fetch(id);

        TypedQuery<PersistedExportableItem> query = em.createQuery("SELECT e FROM PersistedExportableItem e", PersistedExportableItem.class);
        assertThat(query.getResultList(), is(notNullValue()));
    }

    @Test public void getItemByName() throws Exception {

        //given some persisted execution
        PersistedExportableItem persistedItem = new PersistedExportableItem();
        persistedItem.setItemName("DCN");

        //create reader
        List<PersistedExportableReader> readerList = new ArrayList<>();
        PersistedExportableReader reader = new PersistedExportableReader();
        reader.setExportableItem(persistedItem);
        reader.setItemName("Channel");
        reader.setItemType(ExportableReaderType.CHANNEL);
        reader.setSelection(1);
        readerList.add(reader);

        persistedItem.setReaders(readerList);
        persistItem(persistedItem);

        TypedQuery<PersistedExportableItem> query = em.createNamedQuery(EXPORTABLE_BY_NAME, PersistedExportableItem.class)
                .setParameter("itemName", "DCN");
        List<PersistedExportableItem> items = query.getResultList();

        TypedQuery<PersistedExportableReader> queryReader = em.createNamedQuery(EXPORTABLE_READER_BY_NAME, PersistedExportableReader.class)
                .setParameter("itemName", "Channel");
        List<PersistedExportableReader> readers = queryReader.getResultList();

        assertThat(items.iterator().next().getItemName(), is(persistedItem.getItemName()));
        assertThat(readers.iterator().next().getItemName(), is("Channel"));

    }

    @Test public void deleteAllItems(){

        em.getTransaction().begin();
        Query query = em.createQuery("DELETE FROM PersistedExportableItem");
        int result = query.executeUpdate();
        em.getTransaction().commit();
        em.clear();
    }

    private Long persistItem(IExportablePersistedItem entity) {
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
        em.clear();
        return entity.getId();
    }

    private Long persistReader(IExportablePersistedReader entity) {
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
        em.clear();
        return entity.getId();
    }


    private PersistedExportableItem fetch(Long id) {
        return em.find(PersistedExportableItem.class, id);
    }
}