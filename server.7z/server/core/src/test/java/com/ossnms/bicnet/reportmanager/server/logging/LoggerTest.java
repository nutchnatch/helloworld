package com.ossnms.bicnet.reportmanager.server.logging;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.REPORT_MANAGER;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.ossnms.bicnet.bcb.facade.logMgmt.ILogMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.logMgmt.ICommandLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.ISystemEventLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;

public class LoggerTest {

    private ILogMgrFacade logManager;
    private Logger logger;

    private static ICommandLogRecord captureCommandLog(final ILogMgrFacade logManager) throws BcbException {
        ArgumentCaptor<ICommandLogRecord> recordCaptor = ArgumentCaptor.forClass(ICommandLogRecord.class);
        verify(logManager).createCommandLogRecord(any(ISessionContext.class), recordCaptor.capture());
        return recordCaptor.getValue();
    }

    private static ISystemEventLogRecord captureSystemEventLog(final ILogMgrFacade logManager) throws BcbException {
        ArgumentCaptor<ISystemEventLogRecord> recordCaptor = ArgumentCaptor.forClass(ISystemEventLogRecord.class);
        verify(logManager).createSystemEventLogRecord(any(ISessionContext.class), recordCaptor.capture());
        return recordCaptor.getValue();
    }

    @Before public void setUp() throws Exception {
        logManager = mock(ILogMgrFacade.class);
        logger = new Logger(logManager);
    }

    @Test public void shouldLog() throws Exception {
        //when
        logger.commandLog(null, null, null);
        logger.systemEventLog(null, null, null, null);
        //then
        verify(logManager).createCommandLogRecord(any(ISessionContext.class), any(ICommandLogRecord.class));
        verify(logManager).createSystemEventLogRecord(any(ISessionContext.class), any(ISystemEventLogRecord.class));
    }

    @Test public void shouldLogDescription() throws Exception {
        //given
        String description = "description";
        //when
        logger.commandLog(null, description, null);
        logger.systemEventLog(null, description, null, null);
        //then
        assertThat(captureCommandLog(logManager).getDescription(), is(description));
        assertThat(captureSystemEventLog(logManager).getDescription(), is(description));
    }

    @Test public void shouldLogAffectedObject() throws Exception {
        //given
        String affectedObject = "object name";
        //when
        logger.commandLog(null, null, affectedObject);
        logger.systemEventLog(null, null, affectedObject, null);
        //then
        assertThat(captureCommandLog(logManager).getAffectedObject(), is(affectedObject));
        assertThat(captureSystemEventLog(logManager).getAffectedObject(), is(affectedObject));
    }

    @Test public void shouldLogAffectedObjectDefault() throws Exception {
        //given
        String affectedObject = null;
        //when
        logger.commandLog(null, null, affectedObject);
        logger.systemEventLog(null, null, affectedObject, null);
        //then
        assertThat(captureCommandLog(logManager).getAffectedObject(), is(REPORT_MANAGER.guiLabel()));
        assertThat(captureSystemEventLog(logManager).getAffectedObject(), is(REPORT_MANAGER.guiLabel()));
    }

    @Test public void shouldLogComponent() throws Exception {
        //when
        logger.commandLog(null, null, null);
        logger.systemEventLog(null, null, null, null);
        //then
        assertThat(captureCommandLog(logManager).getComponent(), is(REPORT_MANAGER));
        assertThat(captureSystemEventLog(logManager).getComponent(), is(REPORT_MANAGER));
    }

    @Test public void shouldLogUser() throws Exception {
        //given
        String user = "user name";
        ISessionContext context = mock(ISessionContext.class);
        when(context.getUserName()).thenReturn(user);
        //when
        logger.commandLog(context, null, null);
        logger.systemEventLog(context, null, null, null);
        //then
        assertThat(captureCommandLog(logManager).getUserName(), is(user));
        assertThat(captureSystemEventLog(logManager).getUserName(), is(user));
    }

    @Test public void shouldLogSeverity() throws Exception {
        //given
        LogSeverity severity = LogSeverity.ERROR;
        //when
        logger.systemEventLog(null, null, null, severity);
        //then
        assertThat(captureSystemEventLog(logManager).getSeverity(), is(severity));
    }
}