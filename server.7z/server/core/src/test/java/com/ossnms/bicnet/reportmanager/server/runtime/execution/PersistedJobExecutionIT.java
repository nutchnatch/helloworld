package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import com.ossnms.bicnet.reportmanager.server.runtime.BatchStatus;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import org.junit.Test;


public class PersistedJobExecutionIT {

    private EntityManager em = Persistence.createEntityManagerFactory("REPORT_MANAGER-PU").createEntityManager();

    @Test public void shouldGenerateId() throws Exception {
        //given some execution
        JobExecution jobExecution = new PersistedJobExecution("Some job name");

        //when it is persisted
        persist(jobExecution);

        //then execution should have generated id 
        assertThat(jobExecution.getExecutionId(), is(notNullValue()));
    }

    @Test public void shouldFindPersistedExecution() throws Exception {
        //given some persisted execution
        PersistedJobExecution persisted = new PersistedJobExecution("Some job name");
        Long id = persist(persisted);

        //when it is queried
        PersistedJobExecution found = fetch(id);

        //then it should be the same as persisted 
        assertThat(found, is(persisted));
    }

    @Test public void shouldPersistFields() throws Exception {
        //given some persisted execution
        PersistedJobExecution persisted = new PersistedJobExecution("Some job name");
        persisted.setStartTimeSeconds(100L);
        persisted.setEndTimeSeconds(200L);
        persisted.setBatchStatus(BatchStatus.FINISHED);
        Long id = persist(persisted);

        //when it is fetched 
        PersistedJobExecution found = fetch(id);

        //then it should contain all fields
        assertThat(found.getExecutionId(), is(id));
        assertThat(found.getJobName(), is(persisted.getJobName()));
        assertThat(found.getStartTimeSeconds(), is(persisted.getStartTimeSeconds()));
        assertThat(found.getEndTimeSeconds(), is(persisted.getEndTimeSeconds()));
        assertThat(found.getBatchStatus(), is(persisted.getBatchStatus()));
    }

    private Long persist(JobExecution entity) {
        em.getTransaction().begin();
        em.persist(entity);
        em.getTransaction().commit();
        em.clear();
        return entity.getExecutionId();
    }

    private PersistedJobExecution fetch(Long id) {
        return em.find(PersistedJobExecution.class, id);
    }
}