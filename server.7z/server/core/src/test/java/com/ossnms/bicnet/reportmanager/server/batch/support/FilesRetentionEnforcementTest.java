/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.batch.support;

import com.ossnms.bicnet.reportmanager.server.files.FilesManager;
import com.ossnms.bicnet.reportmanager.server.files.PathFilter;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import com.ossnms.bicnet.reportmanager.server.support.FilesRetentionEnforcement;
import org.junit.Test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class FilesRetentionEnforcementTest {
    @Test public void shouldCleanupComponentFolderAfterJobExecution() throws Exception {
        //given listener configuration
        FilesManager filesManager = mock(FilesManager.class);
        PathFilter filesFilter = mock(PathFilter.class);
        FilesRetentionEnforcement listener = new FilesRetentionEnforcement(filesManager, filesFilter);
        JobExecution execution = mock(JobExecution.class);

        //when job is executed
        listener.afterJob(execution);
        
        //then listener should clean component folder
        verify(filesManager).enforceRetention(filesFilter);
    }
}