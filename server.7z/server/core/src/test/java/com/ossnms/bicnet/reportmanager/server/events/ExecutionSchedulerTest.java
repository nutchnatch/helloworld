package com.ossnms.bicnet.reportmanager.server.events;


import com.ossnms.bicnet.bcb.facade.platform.ISchedulerEjbFacade;
import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.facade.platform.ScheduleReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import com.ossnms.bicnet.reportmanager.util.Constants;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.REPORT_MANAGER;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ExecutionSchedulerTest {

    private String reportId;
    private Scheduler scheduler;
    private JobOperator jobOperator;
    private ISchedulerEjbFacade schedulerEjbFacade;

    @Before public void setUp() throws Exception {
        reportId = "some report";
        jobOperator = mock(JobOperator.class);
        schedulerEjbFacade = mock(ISchedulerEjbFacade.class);
        scheduler = new ExecutionScheduler(schedulerEjbFacade);
    }

    @Test public void shouldRunJobOnReportSchedule() throws Exception {
        //given report execution notification
        ScheduleExecution notification = new ScheduleExecution(null, 0L, null, Constants.ACTION_TYPE_REPORT_EXECUTION, reportId);

        //when scheduler process it
        scheduler.onScheduleExecution(notification);
    }

    @Test public void shouldIgnoreOtherSchedule() throws Exception {
        //given some other notification
        ScheduleExecution notification = new ScheduleExecution(null, 0L, null, "some other action", reportId);

        //when scheduler process it
        scheduler.onScheduleExecution(notification);

        //then it should be ignored
        verify(jobOperator, never()).start(reportId);
    }

    @Test public void shouldScheduleReportExecution() throws Exception {
        //given some schedule
        ISchedule schedule = new ScheduleItem();

        //when
        scheduler.scheduleReportExecution(null, schedule, reportId);

        //then proper schedule should be send to facade
        verify(schedulerEjbFacade).createSchedule(null, schedule);
        assertThat(schedule.getActionType(), is(Constants.ACTION_TYPE_REPORT_EXECUTION));
        assertThat(schedule.getActionParameter(), is(reportId));
        assertThat(schedule.getDestination(), is(REPORT_MANAGER.name()));
    }

    @Test public void shouldLocateConfiguredSchedule() throws Exception {
        //given some configured schedule
        ISchedule schedule = new ScheduleItem(null);
        schedule.setActionType(Constants.ACTION_TYPE_REPORT_EXECUTION);
        schedule.setActionParameter(reportId);
        schedule.setDestination(REPORT_MANAGER.name());
        // in scheduler component
        ScheduleReply scheduleReply = new ScheduleReply(new ISchedule[]{schedule}, true, null);
        IScheduleMarkable[] filter = {(IScheduleMarkable) schedule.toMarkable()};
        when(schedulerEjbFacade.getScheduleList(null, null, filter, -1)).thenReturn(scheduleReply);

        //when
        ISchedule foundSchedule = scheduler.findSchedule(null, reportId);

        //then should find configured schedule
        assertThat(foundSchedule, is(schedule));
    }

    @Test public void shouldNotLocateNonexistentSchedule() throws Exception {
        //given no configured schedules
        ScheduleReply emptyReply = new ScheduleReply(new ISchedule[0], true, null);
        when(schedulerEjbFacade.getScheduleList(any(ISessionContext.class), any(ISchedule.class), any(IScheduleMarkable[].class), anyInt())).thenReturn(emptyReply);

        //when
        ISchedule foundSchedule = scheduler.findSchedule(null, reportId);

        //then should not find any schedule
        assertThat(foundSchedule, is(nullValue()));
    }

    @Test public void shouldProvideNextExecutionTimeForSchedule() throws Exception {
        //given some schedule
        ISchedule schedule = mock(ISchedule.class);
        Date nextExecutionDate = new Date();
        when(schedulerEjbFacade.getNextExecutionTime(null, schedule)).thenReturn(nextExecutionDate);

        //when next execution is requested
        Long nextExecutionTime = scheduler.nextExecutionTime(null, schedule);

        //then
        assertThat(nextExecutionTime, is(nextExecutionDate.getTime()));
    }

    @Test public void checkNeCreation() {
        Map<String, Boolean> alarmSeverityMap = new HashMap<>();
        alarmSeverityMap.put(AlarmSeverity.WARNING.name(), true);
        alarmSeverityMap.put(AlarmSeverity.MINOR.name(), false);
        alarmSeverityMap.put(AlarmSeverity.MAJOR.name(), false);
        alarmSeverityMap.put(AlarmSeverity.CRITICAL.name(), false);
        alarmSeverityMap.put(AlarmSeverity.INDETERMINATE.name(), false);

        int numberOfAlarmSeverity = AlarmSeverity.getSize();

        ArrayList<AlarmSeverity> alarmSeverityList = new ArrayList<>();

        IntStream.range(0, numberOfAlarmSeverity)
                .filter(i -> AlarmSeverity.fromOrdinal(i).useInAlarmCorrelation() && alarmSeverityMap.get(AlarmSeverity.fromOrdinal(i).name()))
                .map(i -> {
                    alarmSeverityList.add(AlarmSeverity.fromOrdinal(i));
                    return i;
                })
                .toArray();


    }
}