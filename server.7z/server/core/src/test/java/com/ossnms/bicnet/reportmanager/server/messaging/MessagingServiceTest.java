package com.ossnms.bicnet.reportmanager.server.messaging;

import com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherConfig;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageListener;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.platform.NotificationType;
import org.junit.Test;

import java.util.Map;
import java.util.Set;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer.ATP_SCHEDULER;
import static java.util.Collections.emptyMap;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MessagingServiceTest {

    @Test public void shouldSubscribeMessageListenerOnStart() throws Exception {
        IBiCNetMessageDispatcherConfig messageDispatcherConfig = mock(IBiCNetMessageDispatcherConfig.class);
        IBiCNetDirectMessageDispatcher directMessageDispatcher = mock(IBiCNetDirectMessageDispatcher.class);
        MessageListener messageListener = mock(MessageListener.class);
        ListenersConfiguration layeredConfiguration = configuration(of(ATP_SCHEDULER, emptyMap()));
        MessagingService messagingService = new MessagingService(messageDispatcherConfig, directMessageDispatcher, messageListener, layeredConfiguration);

        messagingService.start();

        verify(messageDispatcherConfig).addListener(ATP_SCHEDULER, messageListener, emptyMap());
        verify(directMessageDispatcher).register(any(IBiCNetDirectMessageListener.class));
    }

    @Test public void shouldUnsubscribeMessageListenerOnStop() throws Exception {
        IBiCNetMessageDispatcherConfig messageDispatcherConfig = mock(IBiCNetMessageDispatcherConfig.class);
        IBiCNetDirectMessageDispatcher directMessageDispatcher = mock(IBiCNetDirectMessageDispatcher.class);
        MessageListener messageListener = mock(MessageListener.class);
        ListenersConfiguration layeredConfiguration = configuration(of(ATP_SCHEDULER, emptyMap()));
        MessagingService messagingService = new MessagingService(messageDispatcherConfig, directMessageDispatcher, messageListener, layeredConfiguration);

        messagingService.stop();

        verify(messageDispatcherConfig).removeListener(ATP_SCHEDULER, emptyMap());
        verify(directMessageDispatcher).unregister();
    }

    private ListenersConfiguration configuration(Map<BiCNetMessageLayer, Map<ManagedObjectType, Set<NotificationType>>> config) {
        ListenersConfiguration configuration = mock(ListenersConfiguration.class);
        when(configuration.layering()).thenReturn(config);
        return configuration;
    }
}