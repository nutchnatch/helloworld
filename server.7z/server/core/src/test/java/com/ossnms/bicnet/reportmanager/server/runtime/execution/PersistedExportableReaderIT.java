package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import java.util.List;
import java.util.stream.Collectors;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedExportableReader.EXPORTABLE_READER_BY_ITEM_ID;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;


public class PersistedExportableReaderIT {

    private EntityManager em = Persistence.createEntityManagerFactory("REPORT_MANAGER-EI").createEntityManager();

    @Test public void shouldGenerateId() throws Exception {

        //given some execution
        PersistedExportableItem persistedItem = new PersistedExportableItem();
        persist(persistedItem);

        //given some execution
        PersistedExportableReader reader = new PersistedExportableReader();
        reader.setExportableItem(persistedItem);

        //when it is persisted
        persist(reader);

        //then execution should have generated id 
        assertThat(reader.getId(), is(notNullValue()));
    }

    @Test public void shouldFindPersistedExecution() throws Exception {

        //given some persisted execution
        PersistedExportableItem persistedItem = new PersistedExportableItem();
        persist(persistedItem);

        //given some execution
        PersistedExportableReader reader = new PersistedExportableReader();
        reader.setExportableItem(persistedItem);
        Long id = persist(reader);

        //when it is queried
        PersistedExportableReader found = fetch(id);

        //then it should be the same as persisted
        assertThat(found, is(reader));
    }

    @Test public void shouldPersistFields() throws Exception {

        //given some persisted execution
        PersistedExportableItem persistedItem = new PersistedExportableItem();
        persistedItem.setItemName("DCN");
        persist(persistedItem);

        //given some persisted execution
        PersistedExportableReader persistedReader = new PersistedExportableReader();

        persistedReader.setExportableItem(persistedItem);
        persistedReader.setItemName("Channel");
        persistedReader.setSelection(1);
        persistedReader.setItemType(ExportableReaderType.CHANNEL);
        Long id = persist(persistedReader);

        //when it is fetched
        PersistedExportableReader found = fetch(id);

        TypedQuery<PersistedExportableReader> query = em.createNamedQuery(EXPORTABLE_READER_BY_ITEM_ID, PersistedExportableReader.class)
                .setParameter("exportableItem", persistedReader.getExportableItem());
        List<PersistedExportableReader> readers =  query.getResultList();

        //then it should contain all fields
        assertThat(found.getId(), is(id));
        assertThat(found.getItemName(), is(persistedReader.getItemName()));
        assertThat(found.getSelection(), is(persistedReader.getSelection()));
        assertThat(found.getReaderType(), is(persistedReader.getReaderType()));
        assertThat(readers.iterator().next().getId(), is(persistedReader.getId()));
    }


    private int deleteAll(){
        em.getTransaction().begin();
        Query query1 = em.createQuery("DELETE FROM PersistedExportableReader");
        return query1.executeUpdate();
    }

    @Test public void deleteAllItems(){

        deleteAll();

    }

    private Long persist(IExportablePersistedReader entityReader) {
        em.getTransaction().begin();
        em.persist(entityReader);
        em.getTransaction().commit();
        em.clear();
        return entityReader.getId();
    }

    private Long persist(IExportablePersistedItem entityItem) {
        em.getTransaction().begin();
        em.persist(entityItem);
        em.getTransaction().commit();
        em.clear();
        return entityItem.getId();
    }

    private PersistedExportableReader fetch(Long id) {
        return em.find(PersistedExportableReader.class, id);
    }
}