package com.ossnms.bicnet.reportmanager.server.messaging;


import static com.ossnms.bicnet.bcb.messaging.IBiCNetMessage.PROP_CLIENT_SCOPE;
import static com.ossnms.bicnet.bcb.messaging.IBiCNetMessage.PROP_CLIENT_SCOPE_VAL_PRIVATE;
import static com.ossnms.bicnet.bcb.messaging.IBiCNetMessage.PROP_SENDER_ID;
import static com.ossnms.bicnet.bcb.model.common.BiCNetComponentType.REPORT_MANAGER;
import static com.ossnms.bicnet.reportmanager.util.Constants.ACTION_TYPE;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.io.Serializable;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;

public class MessagePublisherTest {

    private IBiCNetMessageDispatcher messageDispatcher;
    private MessagePublisher messagePublisher;

    @Before public void setUp() throws Exception {
        messageDispatcher = mock(IBiCNetMessageDispatcher.class);
        messagePublisher = new MessagePublisher(messageDispatcher);
    }

    @Test public void shouldSendMessage() throws Exception {
        //when anything is send to client
        messagePublisher.sendToClientImmediate(null, "");

        //then bicnet message should be send to message dispatcher
        verify(messageDispatcher).sendToClient(any(IBiCNetMessage.class));
    }

    @Test public void shouldSendMessageWithMessageItem() throws Exception {
        //given
        Serializable messageItem = "some object";

        //when
        messagePublisher.sendToClientImmediate(messageItem, "");

        //then
        IBiCNetMessage sentMessage = captureSentMessage(messageDispatcher);
        assertThat(sentMessage.getObject(), is(messageItem));
    }

    @Test public void shouldSendMessageWithActionType() throws Exception {
        //given
        String actionType = "some report id";

        //when
        messagePublisher.sendToClientImmediate(null, actionType);

        //then
        IBiCNetMessage sentMessage = captureSentMessage(messageDispatcher);
        assertThat(sentMessage.getStringProperty(ACTION_TYPE), is(actionType));
    }

    @Test public void shouldSendMessageWithReportManagerSender() throws Exception {
        //when
        messagePublisher.sendToClientImmediate(null, "");

        //then
        IBiCNetMessage sentMessage = captureSentMessage(messageDispatcher);
        assertThat(sentMessage.getStringProperty(PROP_SENDER_ID), is(REPORT_MANAGER.name()));
    }

    @Test public void shouldSendMessageWithPrivateClientScope() throws Exception {
        //when
        messagePublisher.sendToClientImmediate(null, "");

        //then
        IBiCNetMessage sentMessage = captureSentMessage(messageDispatcher);
        assertThat(sentMessage.getStringProperty(PROP_CLIENT_SCOPE), is(PROP_CLIENT_SCOPE_VAL_PRIVATE));
    }

    private static IBiCNetMessage captureSentMessage(IBiCNetMessageDispatcher messageDispatcher) {
        ArgumentCaptor<IBiCNetMessage> message = ArgumentCaptor.forClass(IBiCNetMessage.class);
        verify(messageDispatcher).sendToClient(message.capture());
        return message.getValue();
    }
}