/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.files;

import org.junit.Test;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class RetentionNumberOfGroupsFilterTest {

    @Test public void emptyFolder_shouldReturnEmptyResult() throws Exception {
        //given empty folder
        List<Path> files = Collections.emptyList();

        //when files are filtered
        List<Path> toRemove = new RetentionNumberOfGroupsFilter(1).apply(files);

        //then result should be empty
        assertThat(toRemove, is(Collections.<Path>emptyList()));
    }


    @Test public void singleGroup_shouldReturnEmptyResult() throws Exception {
        //given one group of files
        List<Path> files = Arrays.asList(
                Paths.get("foo-1970-01-01_01.00.00.1.txt"),
                Paths.get("bar-1970-01-01_01.00.00.1.txt"),
                Paths.get("buzz-1970-01-01_01.00.00.1.txt"));

        //when filtered with one group maximum
        List<Path> toRemove = new RetentionNumberOfGroupsFilter(1).apply(files);

        //then result should be empty
        assertThat(toRemove, is(Collections.<Path>emptyList()));
    }

    @Test public void twoGroups_shouldFilterFirstGroup() throws Exception {
        //given two groups of files
        List<Path> files = Arrays.asList(
                Paths.get("foo-1970-01-01_01.00.00.1.csv"),
                Paths.get("bar-1970-01-01_01.00.00.1.csv"),
                Paths.get("buzz-1970-01-01_01.00.00.1.csv"),
                Paths.get("foo-1970-01-01_01.00.00.2.csv"),
                Paths.get("bar-1970-01-01_01.00.00.2.csv"),
                Paths.get("buzz-1970-01-01_01.00.00.2.csv")
        );

        //when filtered with one group maximum
        List<Path> toRemove = new RetentionNumberOfGroupsFilter(1).apply(files);

        //then result should be the first group
        assertThat(toRemove, containsInAnyOrder(
                Paths.get("foo-1970-01-01_01.00.00.1.csv"),
                Paths.get("bar-1970-01-01_01.00.00.1.csv"),
                Paths.get("buzz-1970-01-01_01.00.00.1.csv")));
    }

    @Test public void threeGroups_shouldFilterFirstTwoGroups() throws Exception {
        //given three groups of files
        List<Path> files = Arrays.asList(
                Paths.get("foo-1970-01-01_01.00.00.1.xml"),
                Paths.get("bar-1970-01-01_01.00.00.1.xml"),
                Paths.get("foo-1970-01-01_01.00.00.2.xml"),
                Paths.get("bar-1970-01-01_01.00.00.2.xml"),
                Paths.get("foo-1970-01-01_01.00.00.3.xml"),
                Paths.get("bar-1970-01-01_01.00.00.3.xml")
        );

        //when filtered with one group maximum
        List<Path> toRemove = new RetentionNumberOfGroupsFilter(1).apply(files);

        //then result should be the first group
        assertThat(toRemove, containsInAnyOrder(
                Paths.get("foo-1970-01-01_01.00.00.1.xml"),
                Paths.get("bar-1970-01-01_01.00.00.1.xml"),
                Paths.get("foo-1970-01-01_01.00.00.2.xml"),
                Paths.get("bar-1970-01-01_01.00.00.2.xml")
        ));
    }

    @Test public void notMatchedFiles_shouldFilterThemAsIndividualGroups() throws Exception {
        //given some files that don't match pattern
        List<Path> files = Arrays.asList(
                Paths.get("bar"),
                Paths.get("buzz"),
                Paths.get("fizz"),
                Paths.get("foo")
        );

        //when filtered with one group maximum
        List<Path> toRemove = new RetentionNumberOfGroupsFilter(1).apply(files);

        //then result should contain filtered out files as individual groups
        assertThat(toRemove, containsInAnyOrder(
                Paths.get("bar"),
                Paths.get("buzz"),
                Paths.get("fizz")
        ));
    }
}
