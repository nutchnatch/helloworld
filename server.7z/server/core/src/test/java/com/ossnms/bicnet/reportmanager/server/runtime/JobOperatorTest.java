package com.ossnms.bicnet.reportmanager.server.runtime;

import static java.util.Collections.singletonList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Queue;

import javax.ejb.SessionContext;
import javax.ejb.TimerService;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.dcn.ChannelExportReader;
import com.ossnms.bicnet.reportmanager.dto.export.dcn.DcnExportItem;
import com.ossnms.bicnet.reportmanager.server.executors.ItemProcessor;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;
import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.JobExecutor;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.JobExecutorBean;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedJobExecution;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.JobExecutionsDAO;
import com.ossnms.bicnet.reportmanager.server.runtime.repository.JobRepository;

public class JobOperatorTest {

    private String jobName;
    private JobOperator jobOperator;
    private JobConfiguration jobConfiguration;
    private JobExecution jobExecution;
    private DcnExportItem dcnItem;

    @Before public void setUp() throws Exception {
        jobName = "job name";

        //job repository
        JobExecutionsDAO jobExecutionsDAO = mock(JobExecutionsDAO.class);
        JobRepository jobRepository = spy(new JobRepository(jobExecutionsDAO));

        //job executor
        SessionContext sessionContext = mock(SessionContext.class);
        JobExecutor jobExecutor = new JobExecutorBean(jobRepository);
        ((JobExecutorBean) jobExecutor).setSessionContext(sessionContext);
        when(sessionContext.getBusinessObject(JobExecutor.class)).thenReturn(jobExecutor);

        //job configuration
        jobConfiguration = mock(JobConfiguration.class);
        when(jobConfiguration.getJobName()).thenReturn(jobName);

        //job execution
        jobExecution = new PersistedJobExecution(jobName);
        ((PersistedJobExecution) jobExecution).setExecutionId(1L);
        when(jobExecutionsDAO.findByJobName(jobName)).thenReturn(singletonList((PersistedJobExecution) jobExecution));
        doReturn(jobExecution).when(jobRepository).createNewExecution(jobName);

        //job operator
        jobOperator = new JobOperatorBean(jobExecutor, jobRepository);
        ((JobOperatorBean) jobOperator).setTimerService(mock(TimerService.class));

        //Readers and Items
        List<IExportableReader> readers = new ArrayList<>();
        ChannelExportReader reader = new ChannelExportReader();
        reader.setSelection(1);
        readers.add(reader);
        dcnItem = new DcnExportItem();
        dcnItem.setSelection(1);
        dcnItem.setReaders(readers);
    }

    @Test public void shouldBeAbleToSubmitAJob() throws Exception {
        //given some job configuration

        //when job is submitted
        long executionId = jobOperator.start(jobConfiguration);

        //then execution id is not zero
        assertThat(executionId, is(not(0L)));
    }

    @Test public void shouldBeAbleToStoreExecutions() throws Exception {
        //given some executed job
        jobOperator.start(jobConfiguration);

        //when
        List<JobExecution> jobExecutions = jobOperator.getJobExecutions(jobName);

        //then execution should be stored
        assertThat(jobExecutions, hasItem(jobExecution));
    }

    @Test public void shouldExecuteItemReader() throws Exception {
        //given a job configuration with reader
        ItemReader itemReader = mock(ItemReader.class);
        Configuration step = new BatchStep(itemReader, null);
        when(jobConfiguration.getSteps()).thenReturn(singletonList(step));

        //when
        jobOperator.start(jobConfiguration);

        //then
        verify(itemReader, times(1)).open();
        verify(itemReader, atLeastOnce()).readItem();
        verify(itemReader, times(1)).close();
    }

    @Test public void shouldExecuteItemProcessor() throws Exception {
        //given a job configuration with step
        ItemReader<String> itemReader = ((Queue<String>) new ArrayDeque<>(Arrays.asList("Item")))::poll;
        ItemProcessor<String, String> itemProcessor = mock(ItemProcessor.class);
        Configuration step = new BatchStep<>(itemReader, itemProcessor, null);
        when(jobConfiguration.getSteps()).thenReturn(singletonList(step));

        //when
        jobOperator.start(jobConfiguration);

        //then
        verify(itemProcessor, atLeastOnce()).processItem("Item");
    }

    @Test public void shouldExecuteItemWriter() throws Exception {
        //given a job configuration with step
        ItemReader<String> itemReader = ((Queue<String>) new ArrayDeque<>(Arrays.asList("Item")))::poll;
        ItemWriter<String> itemWriter = mock(ItemWriter.class);
        Configuration step = new BatchStep<>(itemReader, itemWriter);

        when(jobConfiguration.getSteps()).thenReturn(singletonList(step));

        //when
        jobOperator.start(jobConfiguration);

        //then
        verify(itemWriter, times(1)).open();
        verify(itemWriter, atLeastOnce()).writeItems("Item");
        verify(itemWriter, times(1)).close();
    }

    @Test public void shouldExecuteJobListener() throws Exception {
        //given a job configuration with job listener
        JobListener jobListener = mock(JobListener.class);

        when(jobConfiguration.getJobListeners()).thenReturn(singletonList(jobListener));

        //when
        jobOperator.start(jobConfiguration);

        //then
        verify(jobListener, times(1)).beforeJob(jobExecution);
        verify(jobListener, times(1)).afterJob(jobExecution);
    }
}

