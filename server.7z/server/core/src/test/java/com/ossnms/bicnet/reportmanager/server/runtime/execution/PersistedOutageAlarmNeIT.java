package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedOutageAlarmNe.OUTAGE_ALARM_NE_BY_SETTINGS_ID;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;


public class PersistedOutageAlarmNeIT {

    private EntityManager em = Persistence.createEntityManagerFactory("REPORT_MANAGER-PU").createEntityManager();

    @Test public void shouldGenerateId() throws Exception {

        //given some execution
        PersistedOutageAlarmSettings persistedSettings = new PersistedOutageAlarmSettings();
        persist(persistedSettings);

        //given some execution
        PersistedOutageAlarmNe ne = new PersistedOutageAlarmNe();
        ne.setOutageAlarmSettings(persistedSettings);

        //when it is persisted
        persist(ne);

        //then execution should have generated id
        assertThat(ne.getNeId(), is(notNullValue()));
    }

    @Test public void shouldFindPersistedExecution() throws Exception {

        //given some persisted execution
        PersistedOutageAlarmSettings persistedSettings = new PersistedOutageAlarmSettings();
        persist(persistedSettings);

        //given some execution
        PersistedOutageAlarmNe ne = new PersistedOutageAlarmNe();
        ne.setOutageAlarmSettings(persistedSettings);
        int id = persist(ne);

        //when it is queried
        PersistedOutageAlarmNe found = fetch(id);

        //then it should be the same as persisted
        assertThat(found, is(ne));
    }

    @Test public void shouldPersistFields() throws Exception {

        //given some persisted execution
        PersistedOutageAlarmSettings persistedSettings = new PersistedOutageAlarmSettings();

        persistedSettings.setAcknowledged(true);
        persistedSettings.setCleared(true);
        persistedSettings.setCritical(true);
        persist(persistedSettings);

        //given some persisted execution
        PersistedOutageAlarmNe ne = new PersistedOutageAlarmNe();
        ne.setOutageAlarmSettings(persistedSettings);

        ne.setNeName("NE1");
        ne.setId(1);
        int id = persist(ne);

        //when it is fetched
        PersistedOutageAlarmNe found = fetch(id);

        TypedQuery<PersistedOutageAlarmNe> query = em.createNamedQuery(OUTAGE_ALARM_NE_BY_SETTINGS_ID, PersistedOutageAlarmNe.class)
                .setParameter("outageAlarmSettings", ne.getOutageAlarmSettings());
        List<PersistedOutageAlarmNe> readers =  query.getResultList();

        //then it should contain all fields
        assertThat(found.getNeId(), is(id));
        assertThat(found.getNeName(), is(ne.getNeName()));
    }


    private int deleteAll(){
        em.getTransaction().begin();
        Query query1 = em.createQuery("DELETE FROM PersistedOutageAlarmNe");
        return query1.executeUpdate();
    }

    @Test public void deleteAllItems(){

        deleteAll();
    }

    private int persist(IOutageAlarmNe ne) {
        em.getTransaction().begin();
        em.persist(ne);
        em.getTransaction().commit();
        em.clear();
        return ne.getNeId();
    }

    private Long persist(PersistedOutageAlarmSettings outageAlarmSettings) {
        em.getTransaction().begin();
        em.persist(outageAlarmSettings);
        em.getTransaction().commit();
        em.clear();
        return outageAlarmSettings.getId();
    }

    private PersistedOutageAlarmNe fetch(int id) {
        return em.find(PersistedOutageAlarmNe.class, id);
    }
}