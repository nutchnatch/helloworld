/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.facade;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.export.server.ExportConfiguration;
import com.ossnms.bicnet.reportmanager.server.configuration.SystemSettingsRepository;
import com.ossnms.bicnet.reportmanager.server.events.Scheduler;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.ItemManagerHelper;
import com.ossnms.bicnet.reportmanager.server.facade.delegate.LoggerHelper;
import com.ossnms.bicnet.reportmanager.server.inventory.InventoryExportConfiguration;
import com.ossnms.bicnet.reportmanager.server.logging.Logger;
import com.ossnms.bicnet.reportmanager.server.model.ExportableDataBean;
import com.ossnms.bicnet.reportmanager.server.model.ReportDataBean;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static com.ossnms.bicnet.reportmanager.api.ImmutableExportSettings.of;
import static com.ossnms.bicnet.reportmanager.api.ImmutableSystemSettings.settings;
import static com.ossnms.bicnet.reportmanager.api.SystemSettings.DEFAULT;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ScheduleStatusChanged;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ScheduleStatusDisabled;
import static java.util.Arrays.asList;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ReportManagerPrivateFacadeBeanTest {

    private static final String REPORT_ID = "report";
    private static final IExportableItem[] DEFAULT_ITEM = new IExportableItem[0];
    private TransferSettings transferSettings;

    @Mock
    private JobOperator jobOperator;
    @Mock
    private ItemManagerHelper itemManagerHelper;
    @Mock
    private LoggerHelper loggerHelper;
    @Mock
    private Logger logger;
    @Mock
    private Scheduler scheduler;
    @Mock
    private SystemSettingsRepository settingsRepo;
    @Mock
    private ExportableDataBean exportableDataBean;
    @Mock
    private ReportDataBean reportDataBean;
    @Mock
    private ExportConfiguration exportConfiguration;
    @Mock
    private InventoryExportConfiguration inventoryExportConfiguration;

    @InjectMocks
    private ReportManagerPrivateFacadeBean privateFacade;

    @Before public void setUp() throws Exception {
        when(exportableDataBean.getAllExportableItems()).thenReturn(DEFAULT_ITEM);
        when(jobOperator.configuration(InventoryExportConfiguration.class)).thenReturn(inventoryExportConfiguration);
        transferSettings = mock(TransferSettings.class);
    }

    @Test public void startReportShouldExecuteInventoryReport() throws Exception {
        privateFacade.startInventoryReport(null, REPORT_ID, null);
        verify(jobOperator).start(inventoryExportConfiguration.withTransferSettings(transferSettings));
    }

    @Test public void startReport_shouldCreateCommandLog() throws Exception {
        privateFacade.startInventoryReport(null, REPORT_ID,null);
        verify(logger).commandLog(null, "report was started manually", REPORT_ID);
    }

    @Test public void scheduleReportShouldPersistConfigurationItems() throws Exception {
        ISchedule schedule = mock(ISchedule.class);
        IScheduleMarkable mark =  mock(IScheduleMarkable.class);
        when(mark.getStartTime()).thenReturn(new Date());

        privateFacade.scheduleConfigurationReport(null, REPORT_ID, schedule, mark, DEFAULT_ITEM, null);

        verify(itemManagerHelper).persisItemsAndReaders(DEFAULT_ITEM, exportableDataBean);
        verify(scheduler).scheduleReportExecution(null, schedule, REPORT_ID);
    }

    @Test public void disableScheduleReportCreateCommandLog() throws Exception {
        ISchedule schedule = mock(ISchedule.class);
        when(schedule.getActivation()).thenReturn(EnableSwitch.DISABLED);

        IScheduleMarkable mark =  mock(IScheduleMarkable.class);
        when(mark.getStartTime()).thenReturn(new Date());
        privateFacade.scheduleConfigurationReport(null, REPORT_ID, schedule, mark, DEFAULT_ITEM, null);

        verify(loggerHelper).logToCommandLog(null, REPORT_ID, CollectionUtils.EMPTY_COLLECTION,
                ScheduleStatusDisabled, scheduler, logger);
    }

    @Test public void enableScheduleReportCreateCommandLog() throws Exception {
        ISchedule schedule = mock(ISchedule.class);
        when(schedule.getActivation()).thenReturn(EnableSwitch.ENABLED);

        Collection<String> collection = new ArrayList<>();
        collection.add("report Schedule activation field updated with new value: Enabled");
        when(scheduler.findSchedule(Matchers.any(ISessionContext.class), Matchers.anyString())).thenReturn(schedule);

        IScheduleMarkable mark =  mock(IScheduleMarkable.class);
        when(mark.getStartTime()).thenReturn(new Date());
        when(mark.isMarkedActivation()).thenReturn(true);
        when(mark.getActivation()).thenReturn(EnableSwitch.ENABLED);

        privateFacade.scheduleConfigurationReport(null, REPORT_ID, schedule, mark, DEFAULT_ITEM, null);
        verify(loggerHelper).logToCommandLog(null, REPORT_ID, collection,
                ScheduleStatusChanged, scheduler, logger);
    }

    @Test public void shouldProvideSystemSettings() throws Exception {
        SystemSettings dto = settings(of(35, ""), of(42, ""), of(55, ""));
        when(settingsRepo.getDto()).thenReturn(dto);

        SystemSettings systemSettings = privateFacade.getSystemSettings(null);

        assertThat(systemSettings.inventory().retentionNumber(), is(35));
        assertThat(systemSettings.configurationExport().retentionNumber(), is(42));
        assertThat(systemSettings.outageExport().retentionNumber(), is(55));
    }

    @Test public void shouldPersistSystemSettings() throws Exception {
        SystemSettings systemSettings = DEFAULT;

        privateFacade.updateSystemSettings(null, systemSettings, Collections.emptyList());

        verify(settingsRepo).persistDto(systemSettings);
    }

    @Test public void shouldProvideCommandLogWithSettingsDifferences() throws Exception {
        SystemSettings systemSettings = DEFAULT;
        List<String> updateMessages = asList("Some difference", "Another difference");

        privateFacade.updateSystemSettings(null, systemSettings, updateMessages);

        verify(logger).commandLog(null, "Some difference", "Report Manager Settings");
        verify(logger).commandLog(null, "Another difference", "Report Manager Settings");
    }
}