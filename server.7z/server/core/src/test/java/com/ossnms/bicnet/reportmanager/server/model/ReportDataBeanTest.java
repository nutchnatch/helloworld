package com.ossnms.bicnet.reportmanager.server.model;


import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.ossnms.bicnet.reportmanager.server.runtime.BatchStatus;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import com.ossnms.bicnet.reportmanager.server.events.Scheduler;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.ReportExecutionDto;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import com.ossnms.bicnet.reportmanager.server.messaging.MessagePublisher;
import com.ossnms.bicnet.reportmanager.server.runtime.execution.PersistedJobExecution;

public class ReportDataBeanTest {

    public static final String JOB_NAME = "some test job";
    private JobOperator jobOperator;
    private Scheduler scheduler;
    private ISessionContext context;
    private ReportDataBean reportDataBean;

    @Before public void setup() {
        jobOperator = mock(JobOperator.class);
        scheduler = mock(Scheduler.class);
        context = mock(ISessionContext.class);
        reportDataBean = new ReportDataBean(jobOperator, scheduler, mock(MessagePublisher.class));
    }

    @Test public void shouldReturnNotNull() throws Exception {
        //given empty repository

        //when reportData is requested
        ReportDataDto reportData = reportDataBean.getReportData(context, JOB_NAME);

        //then it is not null
        assertThat(reportData, is(notNullValue()));
    }

    @Test public void shouldContainNextSchedule() throws Exception {
        //given configured schedule for job
        ISchedule scheduleItem = new ScheduleItem();
        when(scheduler.findSchedule(context, JOB_NAME)).thenReturn(scheduleItem);

        //when reportData is requested
        ReportDataDto reportData = reportDataBean.getReportData(context, JOB_NAME);

        //then reportData contains schedule
        assertThat(reportData.getSchedule(), is(scheduleItem));
    }

    @Test public void shouldResolveNextExecutionTime() throws Exception {
        //given configured schedule for job
        long nextExecutionTime = 100L;
        ISchedule scheduleItem = new ScheduleItem();
        when(scheduler.findSchedule(context, JOB_NAME)).thenReturn(scheduleItem);
        when(scheduler.nextExecutionTime(context, scheduleItem)).thenReturn(nextExecutionTime);

        //when reportData is requested
        ReportDataDto reportData = reportDataBean.getReportData(context, JOB_NAME);

        //then reportData contains next execution time
        assertThat(reportData.getNextExecutionTime(), is(nextExecutionTime));
    }

    @Test public void shouldContainCurrentExecution() throws Exception {
        //given no execution in repository

        //when reportData is requested
        ReportDataDto reportData = reportDataBean.getReportData(context, JOB_NAME);

        //then reportData contains last execution as current execution
        assertThat(reportData.getCurrentExecution(), is(nullValue()));
    }

    @Test public void shouldContainLastSuccessfulExecution() throws Exception {
        //given executions in repository
        PersistedJobExecution successful = new PersistedJobExecution(JOB_NAME);
        successful.setBatchStatus(BatchStatus.FINISHED);
        JobExecution anyOtherExecution = new PersistedJobExecution(JOB_NAME);
        when(jobOperator.getJobExecutions(JOB_NAME)).thenReturn(asList(successful, anyOtherExecution));

        //when reportData is requested
        ReportDataDto reportData = reportDataBean.getReportData(context, JOB_NAME);

        //then reportData contains last lastSuccessfulExecution
        ReportExecutionDto lastSuccessfulExecution = reportData.getLastSuccessfulExecution();
        assertThat(lastSuccessfulExecution.getExecutionId(), is(successful.getExecutionId()));
    }

    @Test public void shouldNotContainLastSuccessfulExecution() throws Exception {
        //given only started executions in repository
        JobExecution execution = new PersistedJobExecution(JOB_NAME);
        JobExecution jobExecution = new PersistedJobExecution(JOB_NAME);
        when(jobOperator.getJobExecutions(JOB_NAME)).thenReturn(asList(execution, jobExecution));

        //when reportData is requested
        ReportDataDto reportData = reportDataBean.getReportData(context, JOB_NAME);

        //then reportData does not contain last lastSuccessfulExecution
        assertThat(reportData.getLastSuccessfulExecution(), is(nullValue()));
    }
}