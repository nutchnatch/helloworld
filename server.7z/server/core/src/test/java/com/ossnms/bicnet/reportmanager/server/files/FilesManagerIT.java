package com.ossnms.bicnet.reportmanager.server.files;

import static com.ossnms.bicnet.reportmanager.server.configuration.ComponentPathConfig.INVENTORY;
import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.nio.file.Path;
import java.util.Date;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class FilesManagerIT {

    @Rule public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test public void testFileNameGeneration() {
        // given
        Date date = new Date(1L);
        String fileName = "ports";
        String fileExtension = "csv";

        // when file name is generated
        File file = new FilesManager(INVENTORY.getPath()).resolveReportFile(fileName, fileExtension, date);

        // then file path contains component path, name, extension and date 
        assertThat(file.toString(), allOf(
                containsString("networkinventory"),
                containsString(fileName),
                containsString(fileExtension),
                containsString("1970-01-01_01.00.00.1")));
    }

    @Test public void shouldEnforceRetentionPolicy() throws Exception {
        //given folder with some files
        Path componentPath = temporaryFolder.newFolder().toPath();
        FilesManager filesManager = new FilesManager(componentPath);
        filesManager.resolveReportFile("export", "csv", new Date(1L));
        filesManager.resolveReportFile("export", "csv", new Date(2L));
        filesManager.resolveReportFile("export", "csv", new Date(3L));

        //when retention configuration is enforced
        filesManager.enforceRetention(new RetentionNumberOfGroupsFilter(1));

        //then folder contains only 1 file
        File[] files = componentPath.toFile().listFiles();
        assertThat(asList(files), hasSize(1));
    }
}