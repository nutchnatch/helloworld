package com.ossnms.bicnet.reportmanager.server.runtime.execution;

import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;


public class PersistedOutageAlarmSettingsIT {

    private EntityManager em = Persistence.createEntityManagerFactory("REPORT_MANAGER-PU").createEntityManager();

    @Test public void shouldGenerateId() throws Exception {
        //given some execution
        PersistedOutageAlarmSettings persistedSettings = new PersistedOutageAlarmSettings();

        //when it is persisted
        persistOutageAlarmSettings(persistedSettings);

        //then execution should have generated id
        assertThat(persistedSettings.getId(), is(notNullValue()));
    }

    @Test public void outageAlarmNeShouldGenerateId() throws Exception {
        //given some execution
        PersistedOutageAlarmSettings persistedSettings = new PersistedOutageAlarmSettings();

        //when it is persisted
        persistOutageAlarmSettings(persistedSettings);

        //given some execution
        PersistedOutageAlarmNe ne = new PersistedOutageAlarmNe();
        ne.setOutageAlarmSettings(persistedSettings);

        //when it is persisted
        persistNe(ne);

        //then execution should have generated id
        assertThat(ne.getNeId(), is(notNullValue()));
    }

    @Test public void shouldFindPersistedExecution() throws Exception {
        //given some persisted execution
        PersistedOutageAlarmSettings persistedSettings = new PersistedOutageAlarmSettings();
        Long id = persistOutageAlarmSettings(persistedSettings);

        //when it is queried
        PersistedOutageAlarmSettings found = fetch(id);

        //then it should be the same as persisted
        assertThat(found, is(persistedSettings));
    }

    @Test public void shouldPersistFields() throws Exception {
        //given some persisted execution
        PersistedOutageAlarmSettings persistedSettings = new PersistedOutageAlarmSettings();

        persistedSettings.setAcknowledged(true);
        persistedSettings.setCleared(true);
        persistedSettings.setCritical(true);
        Long id = persistOutageAlarmSettings(persistedSettings);

        //when it is fetched
        PersistedOutageAlarmSettings found = fetch(id);

        //then it should contain all fields
        assertThat(found.getId(), is(id));
        assertThat(found.getAcknowledged(), is(persistedSettings.getAcknowledged()));
        assertThat(found.getCleared(), is(persistedSettings.getCleared()));
        assertThat(found.getCritical(), is(persistedSettings.getCritical()));
    }

    @Test public void getAllItems(){

        PersistedOutageAlarmSettings persistedSettings = new PersistedOutageAlarmSettings();

        persistedSettings.setAcknowledged(true);
        persistedSettings.setCleared(true);
        persistedSettings.setCritical(true);
        Long id = persistOutageAlarmSettings(persistedSettings);

        //when it is fetched
        PersistedOutageAlarmSettings found = fetch(id);

        TypedQuery<PersistedOutageAlarmSettings> query = em.createQuery("SELECT e FROM PersistedOutageAlarmSettings e", PersistedOutageAlarmSettings.class);
        assertThat(query.getResultList(), is(notNullValue()));
    }

    @Test public void deleteAllItems(){

        em.getTransaction().begin();
        Query query = em.createQuery("DELETE FROM PersistedOutageAlarmSettings");
        int result = query.executeUpdate();
        em.getTransaction().commit();
        em.clear();
    }

    private Long persistOutageAlarmSettings(PersistedOutageAlarmSettings settings) {
        em.getTransaction().begin();
        em.persist(settings);
        em.getTransaction().commit();
        em.clear();
        return settings.getId();
    }

    private int persistNe(IOutageAlarmNe ne) {
        em.getTransaction().begin();
        em.persist(ne);
        em.getTransaction().commit();
        em.clear();
        return ne. getNeId();
    }

    private PersistedOutageAlarmSettings fetch(Long id) {
        return em.find(PersistedOutageAlarmSettings.class, id);
    }
}