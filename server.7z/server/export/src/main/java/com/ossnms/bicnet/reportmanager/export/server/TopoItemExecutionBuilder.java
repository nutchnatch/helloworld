package com.ossnms.bicnet.reportmanager.export.server;

import com.ossnms.bicnet.reportmanager.dcn.messaging.input.IItemExecutor;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import com.ossnms.bicnet.reportmanager.export.server.reader.IReaderCreatorBuilder;
import com.ossnms.bicnet.reportmanager.export.server.reader.PTIReaderBuilder;
import com.ossnms.bicnet.reportmanager.export.server.reader.TCIReaderBuilder;
import com.ossnms.bicnet.reportmanager.export.server.reader.TSIReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.topo.export.messaging.input.TopoItemExecution;

import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static java.util.stream.Collectors.toList;

class TopoItemExecutionBuilder extends ItemExecutionBuilder {

    private static final IReaderCreatorBuilder[] BUILDERS =
            {new TSIReaderBuilder(), new TCIReaderBuilder(), new PTIReaderBuilder()};

    @Override
    IItemExecutor createItemExecutor(IExportableItem exportableItem) {
        return new TopoItemExecution(buildTopoReaders(exportableItem.getReaders()));
    }

    @Override
    boolean accept(ExportableItemType itemType) {
        return itemType == ExportableItemType.TOPOLOGICAL_MANAGEMENT;
    }

    private Iterable<IReaderBuilder> buildTopoReaders(Iterable<IExportableReader> exportableReaders) {
        return StreamSupport.stream(exportableReaders.spliterator(), false)
                .filter(IReportManagerExportItem::isSelected)
                .map(TopoItemExecutionBuilder::buildReader)
                .filter(Optional::isPresent).map(Optional::get)
                .collect(toList());
    }

    private static Optional<IReaderBuilder> buildReader(IExportableReader iExportableReader) {
        return Stream.of(BUILDERS)
                .filter(builder -> builder.accept(iExportableReader))
                .map(IReaderCreatorBuilder::createReader)
                .findFirst();
    }
}
