package com.ossnms.bicnet.reportmanager.export.server.reader;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TCItems;
import com.ossnms.bicnet.reportmanager.topo.export.messaging.input.TCReader;

public class TCIReaderBuilder implements IReaderCreatorBuilder<TCItems> {
    @Override
    public boolean accept(IExportableReader reader) {
        return reader.getExportableReaderIdentification() == ExportableReaderType.TOPOLOGICAL_CONTAINER;
    }

    @Override
    public IReaderBuilder<TCItems> createReader() {
        return new TCReader();
    }

}
