package com.ossnms.bicnet.reportmanager.export.server.reader;

import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;

public interface IReaderCreatorBuilder<READER_TYPE> {

    boolean accept(IExportableReader reader);
    IReaderBuilder<READER_TYPE> createReader();
}
