package com.ossnms.bicnet.reportmanager.export.server;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.joining;
import static java.util.stream.StreamSupport.stream;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.bind.JAXBException;

import com.ossnms.bicnet.bcb.facade.ecs.IECSFacade;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.IItemExecutor;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import com.ossnms.bicnet.reportmanager.export.server.marshal.BiCNetData;
import com.ossnms.bicnet.reportmanager.export.server.marshal.ExportMarshaller;
import com.ossnms.bicnet.reportmanager.server.configuration.SettingsRepository;
import com.ossnms.bicnet.reportmanager.server.files.FilesManager;
import com.ossnms.bicnet.reportmanager.server.files.RetentionNumberOfGroupsFilter;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.logging.Logger;
import com.ossnms.bicnet.reportmanager.server.model.ReportData;
import com.ossnms.bicnet.reportmanager.server.remote.RemoteExport;
import com.ossnms.bicnet.reportmanager.server.runtime.Configuration;
import com.ossnms.bicnet.reportmanager.server.runtime.ExecutionStep;
import com.ossnms.bicnet.reportmanager.server.runtime.IExecutionConfiguration;
import com.ossnms.bicnet.reportmanager.server.runtime.JobConfiguration;
import com.ossnms.bicnet.reportmanager.server.support.FilesRetentionEnforcement;
import com.ossnms.bicnet.reportmanager.server.support.JobStatusClientNotifications;
import com.ossnms.bicnet.reportmanager.server.support.JobStatusSystemEventLog;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import com.ossnms.bicnet.reportmanager.util.Constants;


@Named(Constants.CONFIGURATION_EXPORT_REPORT)
public class ExportConfiguration implements JobConfiguration {

    private final BiCNetData root = new BiCNetData();

    private static final String EXPORT_CONFIGURATION_RELATIVE_PATH = "reportmanager\\configuration";

    @Inject private SettingsRepository settingsRepository;
    @Inject @BiCNet private ISessionContext context;
    @Inject private ReportData reportDataBean;
    @Inject private Logger logger;
    @Inject ExportMarshaller marshaller;
    @Inject @BiCNet ISystemControlEjbFacade scsFacade;
    @Inject @BiCNet private IECSFacade ecsFacade;

    private TransferSettings settings;
    private Collection<IExecutionConfiguration> executionConfigurationList;

    @Override public String getJobName() {
        return Constants.CONFIGURATION_EXPORT_REPORT;
    }

    @Override public List<Configuration> getSteps() {
        return new ArrayList<>(executionConfigurationList);
    }

    public ExportConfiguration withSettings(IExportableItem[] exportableItems, TransferSettings settings) {
        executionConfigurationList = buildSteps(asList(exportableItems));
        this.settings = settings;
        return this;
    }

    @Override public List<JobListener> getJobListeners() {
        FilesManager filesManager = new FilesManager(settingsRepository.getConfigurationExportPath());
        RetentionNumberOfGroupsFilter filesFilter = new RetentionNumberOfGroupsFilter(settingsRepository.configurationRetentionNumber());
        return asList(
                new FilesRetentionEnforcement(filesManager, filesFilter),
                new JobStatusClientNotifications(context, reportDataBean),
                new JobStatusSystemEventLog(context, logger, getStepNames()));
    }

    private String getStepNames() {
        String stepNames = executionConfigurationList.stream()
                .map(IExecutionConfiguration::getExecutor)
                .map(IItemExecutor::getName)
                .collect(joining(", "));

        return "for: " + stepNames;
    }

    @Override public void resultPostProcess(List<Object> objects) {
        root.setElements(objects);
    }

    @Override public void marshall() throws JAXBException, BcbException {
        String serverVersion = scsFacade.getServerVersion(context).getBuild();
        root.setVersion(serverVersion);

        File file = createFile();
        marshaller.marshal(root, file);

        remoteExport(file);
    }

    /**
     * Create file to be exported
     */
    private File createFile() {
        FilesManager fileManager = new FilesManager(settingsRepository.getConfigurationExportPath());
        return fileManager.resolveReportFile("configuration-export", "xml", new Date());
    }

    /**
     * Remote export (if configured)
     */
    private void remoteExport(File file) throws BcbException {
        if (null != settings && settings.getExternalCommunicationProtocol().getRemoteExport()) {
            RemoteExport remoteExport = new RemoteExport(context, ecsFacade, settings, EXPORT_CONFIGURATION_RELATIVE_PATH);
            remoteExport.uploadFiles(asList(file));
        }
    }

    private Collection<IExecutionConfiguration> buildSteps(Iterable<IExportableItem> exportables) {
        return stream(exportables.spliterator(), false)
                .filter(IReportManagerExportItem::isSelected)
                .map(ExportConfiguration::createExecutionStep)
                .flatMap(opt -> opt.map(Stream::of).orElseGet(Stream::empty))
                .collect(Collectors.toList());
    }

    private static Optional<ExecutionStep> createExecutionStep(IExportableItem item) {
        DcnItemExecutionBuilder dcnExecutionBuilder = new DcnItemExecutionBuilder();
        TopoItemExecutionBuilder topoItemExecutionBuilder = new TopoItemExecutionBuilder();

        if (dcnExecutionBuilder.accept(item.getExportableElement())) {
            return Optional.ofNullable(dcnExecutionBuilder.getExecutionStep(item));
        }
        if (topoItemExecutionBuilder.accept(item.getExportableElement())) {
            return Optional.ofNullable(topoItemExecutionBuilder.getExecutionStep(item));
        }

        return Optional.empty();
    }
}