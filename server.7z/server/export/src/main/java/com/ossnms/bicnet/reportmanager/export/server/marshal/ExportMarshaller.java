package com.ossnms.bicnet.reportmanager.export.server.marshal;

import com.ossnms.bicnet.reportmanager.server.configuration.SettingsRepository;
import com.ossnms.bicnet.reportmanager.server.files.FilesManager;

import javax.inject.Inject;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.util.*;

/**
 * Responsible to convert data to XML format.
 */
public class ExportMarshaller {

    @Inject
    private SettingsRepository settingsRepository;

    public void marshal(BiCNetData root, File file) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(getClassesToBeBound(root));
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

        marshaller.setProperty(Marshaller.JAXB_SCHEMA_LOCATION, "");
        marshaller.marshal(root, file);
    }

    private static Class[] getClassesToBeBound(BiCNetData root) {
        Set<Class<?>> classes = new HashSet();
        classes.add(root.getClass());
        for (Object element : root.getElements()) {
            if (element instanceof JAXBElement) {
                classes.add(((JAXBElement) element).getValue().getClass());
            } else {
                classes.add(element.getClass());
            }
        }
        return classes.toArray(new Class[classes.size()]);
    }
}
