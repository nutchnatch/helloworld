package com.ossnms.bicnet.reportmanager.export.server.reader;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.topology.xml.PTItems;
import com.ossnms.bicnet.reportmanager.topo.export.messaging.input.PTReader;

public class PTIReaderBuilder implements IReaderCreatorBuilder<PTItems> {
    @Override
    public boolean accept(IExportableReader reader) {
        return reader.getExportableReaderIdentification() == ExportableReaderType.PHISICAL_TRAIL;
    }

    @Override
    public IReaderBuilder<PTItems> createReader() {
        return new PTReader();
    }

}
