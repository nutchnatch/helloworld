package com.ossnms.bicnet.reportmanager.export.server;

import com.ossnms.bicnet.reportmanager.dcn.messaging.input.ChannelReader;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.ContainerReader;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.DcnItemExecution;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.IItemExecutor;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.MediatorReader;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.NEReader;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.SystemReader;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;

import static com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType.DCN_MANAGEMENT;
import static java.util.Arrays.asList;

class DcnItemExecutionBuilder extends ItemExecutionBuilder {
    @Override
    IItemExecutor createItemExecutor(IExportableItem exportableItem) {
        return new DcnItemExecution(asList(
                new ContainerReader(),
                new SystemReader(),
                new MediatorReader(),
                new ChannelReader(),
                new NEReader()));
    }

    @Override
    boolean accept(ExportableItemType itemType) {
        return itemType == DCN_MANAGEMENT;
    }
}
