package com.ossnms.bicnet.reportmanager.export.server;


import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.IItemExecutor;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.server.runtime.ExecutionStep;
import com.ossnms.bicnet.reportmanager.server.runtime.IExecutionConfiguration;

abstract public class ItemExecutionBuilder {

    Builder<IExecutionConfiguration> builder = ImmutableList.builder();

    public ExecutionStep getExecutionStep(IExportableItem exportableItem) {
        return new ExecutionStep(createItemExecutor(exportableItem));
    }

    abstract IItemExecutor createItemExecutor(IExportableItem exportableItem);

    abstract boolean accept(ExportableItemType itemType);
}
