package com.ossnms.bicnet.reportmanager.export.server.reader;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.topology.xml.TSItems;
import com.ossnms.bicnet.reportmanager.topo.export.messaging.input.TSReader;

public class TSIReaderBuilder implements IReaderCreatorBuilder<TSItems> {
    @Override
    public boolean accept(IExportableReader reader) {
        return reader.getExportableReaderIdentification() == ExportableReaderType.TOPOLOGICAL_SYMBOL;
    }

    @Override
    public IReaderBuilder<TSItems> createReader() {
        return new TSReader();
    }

}
