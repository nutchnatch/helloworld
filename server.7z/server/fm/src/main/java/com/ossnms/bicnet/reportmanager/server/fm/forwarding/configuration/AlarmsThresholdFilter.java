package com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration;

import com.ossnms.bicnet.bcb.model.EnumOrdinalBase;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.Configuration.Threshold;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Comparator;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.NOT_ALARMED;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.ImmutableThreshold.threshold;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RaisedAlarms.fromCounters;
import static java.lang.Integer.MAX_VALUE;
import static java.util.Comparator.comparingInt;

public class AlarmsThresholdFilter {

    private static final Comparator<AlarmSeverity> comparator = comparingInt(EnumOrdinalBase::getOrdinal);
    private static final Threshold NON_REACHABLE_THRESHOLD = threshold(NOT_ALARMED, MAX_VALUE); //disables the filter
    private static final Logger LOGGER = LoggerFactory.getLogger(AlarmsThresholdFilter.class);

    private Threshold threshold;

    /**
     * Lifts key predicate to entry predicate
     */
    private static <K, V> Predicate<Entry<K, V>> byKey(Predicate<K> predicate) {
        return e -> predicate.test(e.getKey());
    }

    /**
     * Checks if counters reached threshold
     */
    public Boolean hasReachedThreshold(IAlarmCounters counters) {
        IntStream alarmsOverThreshold = fromCounters(counters).entrySet().stream()
                .filter(byKey(this::hasReachedThreshold))
                .mapToInt(Entry::getValue);
        boolean reached = alarmsOverThreshold.sum() >= threshold.alarms();
        
        LOGGER.debug("{} reached {} ", reached, counters);
        return reached;
    }

    /**
     * Checks if severity reached threshold
     */
    private boolean hasReachedThreshold(AlarmSeverity severity) {
        return comparator.compare(severity, threshold.severity()) >= 0;
    }

    /**
     * Updates filter configuration
     */
    public final AlarmsThresholdFilter updateFromConfiguration(Configuration configuration) {
        LOGGER.debug("Before update from config {}", threshold);
        threshold = configuration.threshold().orElse(NON_REACHABLE_THRESHOLD);
        LOGGER.debug("After configuration update {}", threshold);
        return this;
    }

    public Threshold getThreshold() {
        return threshold;
    }
}
