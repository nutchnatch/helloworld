package com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersMarkableItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersReply;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IAlarmCountersFacade;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersMarkable;
import com.ossnms.bicnet.bcb.model.faultMgmt.SupervisedObject;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange.IVisitor;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.subjects.PublishSubject;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Collection;
import java.util.Optional;
import java.util.function.Function;

import static com.ossnms.bicnet.bcb.model.common.TrafficDirection.NONE;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmClasses.all;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARM_MESSAGING_REPORT;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;

@Singleton public class AlarmCounters implements IVisitor {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlarmCounters.class);

    private final IAlarmCountersFacade facade;
    private final ISessionContext context;

    private final PublishSubject<IAlarmCounters> subject = PublishSubject.create();

    @Inject AlarmCounters(@BiCNet ISessionContext context, @BiCNet IFaultMgrFacade facade) {
        this.facade = facade;
        this.context = context;
    }

    /**
     * Wraps ids into supervised objects
     */
    static SupervisedObject[] supervised(Collection<? extends IManagedObjectId> ids) {
        return ids.stream().map(AlarmCounters::supervised).toArray(SupervisedObject[]::new);
    }

    private static SupervisedObject supervised(IManagedObjectId id) {
        return new SupervisedObject(id, NONE, all(), true);
    }


    /**
     * Fetches counters from FM by id
     *
     * @param id id of counters
     * @return counters from FM
     */
    public Optional<IAlarmCounters> fetch(IAlarmCountersId id) {
        try {
            return ofNullable(facade.getSingleAlarmCounters(context, id));
        } catch (BcbException e) {
            LOGGER.error("Failed to fetch AlarmCounters from FM {}", id, e);
            return empty();
        }
    }


    /**
     * Modifies counters on FM
     *
     * @param update an markable with updates
     * @return result of update
     */
    Optional<IAlarmCountersMarkable> modify(IAlarmCountersMarkable update) {
        try {
            return ofNullable(facade.modifyAlarmCounters(context, update));
        } catch (BcbException e) {
            LOGGER.error("Failed to modify AlarmCounters on FM {}", update, e);
            return empty();
        }
    }

    /**
     * Creates new counters on FM
     *
     * @return created counters
     */
    Optional<IAlarmCounters> create(IAlarmCounters counters) {
        try {
            return ofNullable(facade.createAlarmCounters(context, counters));
        } catch (BcbException e) {
            LOGGER.error("Failed to create AlarmCounters on FM {}", counters, e);
            return empty();
        }
    }

    /**
     * Updates counter on FM
     *
     * @param id     id of counters to update
     * @param update a function that prepares a markable with updates
     * @return result of update
     */
    Optional<IAlarmCountersMarkable> update(IAlarmCountersId id, Function<IAlarmCounters, IAlarmCountersMarkable> update) {
        return fetch(id).map(update).flatMap(this::modify);
    }


    public Observable<IAlarmCounters> updates() {
        return subject;
    }

    @Override public boolean onAttributeValueChange(AttributeValueChange attributeValueChange) throws BcbException {
        LOGGER.debug("AVC {}", attributeValueChange);
        IManagedObjectMarkable changedObject = attributeValueChange.getChangedObject();
        if (changedObject instanceof IAlarmCounters) {
            LOGGER.info("Processing alarm counters {}", changedObject);
            subject.onNext((IAlarmCounters) changedObject);
            return true;
        }
        return false;
    }

    public Observable<IAlarmCounters> initial() {
        return Observable.from(fetchAll());
    }

    private Iterable<IAlarmCounters> fetchAll() {
        try {
            AlarmCountersMarkableItem counters = new AlarmCountersMarkableItem(new AlarmCountersItem());
            counters.setName(ALARM_MESSAGING_REPORT);
            IAlarmCountersMarkable[] filter = {counters};
            AlarmCountersReply result = facade.getAlarmCountersList(context, null, filter, -1);
            return asList(result.getData());
        } catch (BcbException e) {
            return emptyList();
        }
    }

}