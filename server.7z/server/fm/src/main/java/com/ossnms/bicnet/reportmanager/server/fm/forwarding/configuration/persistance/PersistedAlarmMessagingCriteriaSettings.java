package com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.persistance;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.QueryHint;
import javax.persistence.Table;

@Entity
@Table(name = "RM_ALARMMESSAGING_SETTINGS")
@NamedQueries(@NamedQuery(
        name = PersistedAlarmMessagingCriteriaSettings.FIND_ALL_ALARMMESSAGING_SETTINGS,
        query = "SELECT e FROM PersistedAlarmMessagingCriteriaSettings e",
        hints = @QueryHint(name = "org.hibernate.readOnly", value = "true")))
public class PersistedAlarmMessagingCriteriaSettings {

    static final String FIND_ALL_ALARMMESSAGING_SETTINGS = "PersistedAlarmMessagingCriteriaSettings.findALL";

    @Id
    @Column(name = "ALARM_COUNTER_ID")
    private Integer alarmCounterId;
    @Column(name = "ENABLE")
    private Boolean enable;
    @Column(name = "ALARM_NUMBER")
    private int alarmNumber;
    @Column(name = "ALARM_SEVERITY")
    private int alarmSeverity;
    @Column(name = "SCHEDULE_DESCRIPTION")
    private String scheduleDescription;

    public Integer getAlarmCounterId() {
        return alarmCounterId;
    }

    public void setAlarmCounterId(Integer alarmCounterId) {
        this.alarmCounterId = alarmCounterId;
    }

    public Boolean getEnable() {
        return enable;
    }

    public void setEnable(Boolean enable) {
        this.enable = enable;
    }

    public int getAlarmNumber() {
        return alarmNumber;
    }

    public void setAlarmNumber(int alarmNumber) {
        this.alarmNumber = alarmNumber;
    }

    public int getAlarmSeverity() {
        return alarmSeverity;
    }

    public void setAlarmSeverity(int alarmSeverity) {
        this.alarmSeverity = alarmSeverity;
    }

    public String getScheduleDescription() {
        return scheduleDescription;
    }

    public void setScheduleDescription(String scheduleDescription) {
        this.scheduleDescription = scheduleDescription;
    }

    @Override public String toString() {
        return "PersistedAlarmMessagingCriteriaSettings{" +
                "alarmCounterId=" + alarmCounterId +
                ", enable=" + enable +
                ", alarmNumber=" + alarmNumber +
                ", alarmSeverity=" + alarmSeverity +
                ", scheduleDescription='" + scheduleDescription + '\'' +
                '}';
    }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PersistedAlarmMessagingCriteriaSettings that = (PersistedAlarmMessagingCriteriaSettings) o;

        return alarmCounterId != null ? alarmCounterId.equals(that.alarmCounterId) : that.alarmCounterId == null;

    }

    @Override public int hashCode() {
        return alarmCounterId != null ? alarmCounterId.hashCode() : 0;
    }
}
