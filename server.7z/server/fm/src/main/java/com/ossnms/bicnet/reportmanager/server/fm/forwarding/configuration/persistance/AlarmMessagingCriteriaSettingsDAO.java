package com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.persistance;

import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import java.util.List;

@Stateful
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class AlarmMessagingCriteriaSettingsDAO {

    @PersistenceContext(type = PersistenceContextType.TRANSACTION)
    private EntityManager em;

    public List<PersistedAlarmMessagingCriteriaSettings> findAll() {
        return em
                .createNamedQuery(PersistedAlarmMessagingCriteriaSettings.FIND_ALL_ALARMMESSAGING_SETTINGS, PersistedAlarmMessagingCriteriaSettings.class)
                .getResultList();
    }

    public int deleteAll(){
        return em.createQuery("DELETE FROM PersistedAlarmMessagingCriteriaSettings").executeUpdate();
    }

    
    public void merge(PersistedAlarmMessagingCriteriaSettings execution) {
        em.merge(execution);
        em.flush();
    }

    public void persist(PersistedAlarmMessagingCriteriaSettings execution) {
        em.persist(execution);
        em.flush();
    }

}
