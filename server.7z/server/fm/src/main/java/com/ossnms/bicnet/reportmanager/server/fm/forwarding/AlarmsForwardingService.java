package com.ossnms.bicnet.reportmanager.server.fm.forwarding;

import com.ossnms.bicnet.bcb.facade.platform.ISchedulerEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.AlarmMessagingSettings;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.AlarmsThresholdFilter;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.ManagedCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters.AlarmCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.listeners.AlarmForwardingSchedules;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.TriggerSettings;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.TriggerSettings.Periodic;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.TriggerSettings.Spontaneous;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RunningTotals;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.util.FilterWithing;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.inject.Inject;

import static java.util.concurrent.TimeUnit.MINUTES;
import static rx.Observable.merge;

public class AlarmsForwardingService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlarmsForwardingService.class);

    private final AlarmCounters alarmCounters;
    private final AlarmForwardingSchedules alarmForwardingSchedules;
    private final RunningTotals runningTotals;
    private final AlarmMessagingSettings configurations;
    private final JobOperator jobOperator;
    private final ManagedCounters countersFilter;
    private final AlarmsThresholdFilter thresholdFilter;

    @Inject public AlarmsForwardingService(@BiCNet ISessionContext context,
                                           @BiCNet ISchedulerEjbFacade scheduler,
                                           AlarmCounters alarmCounters,
                                           AlarmForwardingSchedules alarmForwardingSchedules,
                                           RunningTotals runningTotals,
                                           AlarmMessagingSettings configurations,
                                           JobOperator jobOperator) {
        this.alarmCounters = alarmCounters;
        this.alarmForwardingSchedules = alarmForwardingSchedules;
        this.runningTotals = runningTotals;
        this.configurations = configurations;
        this.jobOperator = jobOperator;
        countersFilter = new ManagedCounters();
        thresholdFilter = new AlarmsThresholdFilter();
    }

    public void start() {
        runningTotals.reloadData();

        // update alarms counters filter on configuration change
        countersFilter.fromConfiguration(configurations.actualConfig());
        configurations.updates().subscribe(countersFilter::fromConfiguration);

        // update threshold filter on configuration change
        thresholdFilter.updateFromConfiguration(configurations.actualConfig());
        configurations.updates().subscribe(thresholdFilter::updateFromConfiguration);

        // update totals on configuration change
        configurations.updates().subscribe(c -> runningTotals.reloadData());

        // count raised alarms
        Observable<IAlarmCounters> counters = merge(alarmCounters.initial(), alarmCounters.updates()).filter(countersFilter::isManaged);

        // update statistic on counters updates
        counters.subscribe(runningTotals::updateStatistics);

        // send email on schedule or when alarms threshold reached
        merge(onSchedule(), overThreshold(counters)).subscribe(this::startJob);
    }

    private void startJob(TriggerSettings trigger) {
        try {
            LOGGER.debug("Starting notification job {}", trigger);
            AlarmsForwardingConfiguration job = jobOperator.configuration(AlarmsForwardingConfiguration.class);
            jobOperator.start(job.withSettings(trigger));
        } catch (BcbException e) {
            LOGGER.error("Missing configuration for alarms forwarding job", e);
        }
    }

    private Observable<TriggerSettings> onSchedule() {
        return alarmForwardingSchedules.executions()
                .map(execution -> configurations.actualConfig().scheduleDescription())
                .map(Periodic::new);
    }

    private Observable<TriggerSettings> overThreshold(Observable<IAlarmCounters> counters) {
        return counters
                //Not more frequently that every 15 Minutes, only those that reached threshold 
                .lift(new FilterWithing<>(15, MINUTES, thresholdFilter::hasReachedThreshold))
                .map(counter -> new Spontaneous(thresholdFilter.getThreshold()));
    }
}
