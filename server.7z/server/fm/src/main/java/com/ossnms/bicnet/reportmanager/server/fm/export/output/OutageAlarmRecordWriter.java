package com.ossnms.bicnet.reportmanager.server.fm.export.output;

import static com.ossnms.bicnet.reportmanager.server.csv.CsvFormat.CSV_PREFERENCE;

import java.io.File;

import org.supercsv.cellprocessor.ift.CellProcessor;

import com.ossnms.bicnet.reportmanager.server.csv.CsvItemWriter;

public class OutageAlarmRecordWriter extends CsvItemWriter<OutageAlarmExportData> {


    private static final String[] header = {
            "Time",
            "Channel Time",
            "Domain Name",
            "Clear Time",
            "Alarm Duration",
            "NE / System Name",
            "NE Name",
            "Object Type",
            "Cause",
            "Equipment Type",
            "Location",
            "Container Location",
            "Shelf Location",
            "Severity",
            "Alarm Class",
            "Alarm Level",
            "Acknowledged by",
            "Acknowledged Time",
            "Unacknowledged Duration",
            "Computer Name",
            "Fault Condition",
            "Traffic Direction",
            "Additional Info",
            "Notes"
    };

    private static final String[] mappings = {
            "raiseTime",
            "affectedEmName",
            "affectedDomainName",
            "clearTime",
            "alarmDuration",
            "systemContainerName",
            "affectedNeName",
            "supplierAlarmIdAffectedObjectTypeExtendedGuiLabel",
            "effectiveProbableCauseGuiLabel",
            "equipmentTypeExtendedGuiLabel",
            "nativeLocation",
            "topoContainerName",
            "subrackLocation",
            "severity",
            "effectiveAlarmClass",
            "supplierAlarmIdProbableCause",
            "acknowledgedBy",
            "acknowledgeTime",
            "acknowledgeDuration",
            "computerName",
            "faultCondition",
            "trafficDirection",
            "addtionalInfo",
            "hasNotes"
    };

    private static final CellProcessor[] processors = new CellProcessor[mappings.length];

    public OutageAlarmRecordWriter(File resource) {
        super(header, mappings, processors, resource, CSV_PREFERENCE);
    }
}
