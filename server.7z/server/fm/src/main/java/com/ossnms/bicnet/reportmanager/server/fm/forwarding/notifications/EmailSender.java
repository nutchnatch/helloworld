package com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications;

import com.ossnms.bicnet.bcb.facade.ecs.IECSFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.EmailSender.Message;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

public class EmailSender implements ItemWriter<Message> {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailSender.class);
    private final IECSFacade ecs;
    private final ISessionContext context;

    @Inject public EmailSender(@BiCNet ISessionContext context, @BiCNet IECSFacade ecs) {
        this.ecs = ecs;
        this.context = context;
    }

    @Override public void writeItems(Message message) throws BcbException {
        LOGGER.info("Sending email {}", message);
        ecs.sendMessage(context, message.subject(), message.content());
    }

    public interface Message {
        String subject();

        String content();

        static Message message(String subject, String content) {
            return new Message() {
                @Override public String subject() {
                    return subject;
                }

                @Override public String content() {
                    return content;
                }

                @Override public String toString() {
                    return "Message{" + subject + ": " + content + " }";
                }
            };
        }
    }
}
