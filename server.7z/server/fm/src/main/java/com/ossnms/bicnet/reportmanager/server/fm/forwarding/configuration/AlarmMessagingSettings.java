package com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersIdItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersId;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings.ThresholdSettings;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.Configuration.Threshold;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.persistance.AlarmMessagingCriteriaSettingsRepository;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.persistance.PersistedAlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters.AlarmCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters.NeAlarmCounters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.subjects.PublishSubject;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.Optional;

import static com.google.common.base.Strings.nullToEmpty;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.fromOrdinal;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableAlarmMessagingCriteriaSettings.alarmMessaging;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableThresholdSettings.threshold;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.ImmutableConfiguration.configuration;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.ImmutableThreshold.threshold;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARM_MESSAGING_REPORT;
import static java.util.Collections.emptyList;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;

@Singleton public class AlarmMessagingSettings {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlarmMessagingSettings.class);
    private final NeAlarmCounters neCounters;
    private final AlarmCounters counters;
    private final AlarmMessagingCriteriaSettingsRepository repository;
    private final PublishSubject<Configuration> subject = PublishSubject.create();

    @Inject
    public AlarmMessagingSettings(AlarmMessagingCriteriaSettingsRepository repository,
                                  NeAlarmCounters neCounters, AlarmCounters counters) {
        this.repository = repository;
        this.neCounters = neCounters;
        this.counters = counters;
    }

    public AlarmMessagingCriteriaSettings getAlarmMessagingCriteriaSettings() {
        PersistedAlarmMessagingCriteriaSettings current = fetchSettings();
        Collection<INEId> nes = neCounters.supervisedNEs(new AlarmCountersIdItem(current.getAlarmCounterId()));
        return alarmMessaging(threshold(current.getEnable(), current.getAlarmNumber(), current.getAlarmSeverity()), nes);
    }

    public Optional<IAlarmCounters> currentCounters() {
        PersistedAlarmMessagingCriteriaSettings current = fetchSettings();
        return counters.fetch(new AlarmCountersIdItem(current.getAlarmCounterId()));
    }

    public void persistSettings(AlarmMessagingCriteriaSettings updated) {
        LOGGER.debug("Updating settings {}", updated);
        PersistedAlarmMessagingCriteriaSettings current = fetchSettings();
        repository.update(merge(current, updated.threshold()));

        AlarmCountersIdItem id = new AlarmCountersIdItem(current.getAlarmCounterId());
        neCounters.update(id, updated.selectedNEs());

        subject.onNext(config(current));
    }

    private PersistedAlarmMessagingCriteriaSettings fetchSettings() {
        return repository
                .getAlarmMessagingCriteriaSettings()
                .orElseGet(this::newSettings);
    }

    private PersistedAlarmMessagingCriteriaSettings merge(PersistedAlarmMessagingCriteriaSettings current, ThresholdSettings threshold) {
        current.setEnable(threshold.enabled());
        current.setAlarmNumber(threshold.number());
        current.setAlarmSeverity(threshold.severity());
        return current;
    }

    private PersistedAlarmMessagingCriteriaSettings newSettings() {
        LOGGER.warn("Settings not found, creating new settings");

        IAlarmCounters countersId = neCounters.create(ALARM_MESSAGING_REPORT, emptyList())
                .orElseThrow(() -> new RuntimeException("CANNOT CREATE COUNTER"));

        PersistedAlarmMessagingCriteriaSettings current = new PersistedAlarmMessagingCriteriaSettings();
        current.setAlarmCounterId(countersId.getId());
        current.setAlarmNumber(1);
        current.setAlarmSeverity(AlarmSeverity.WARNING.getOrdinal());
        current.setEnable(false);
        current.setScheduleDescription("no schedule");
        repository.create(current);

        subject.onNext(config(current));

        return current;
    }

    public Observable<Configuration> updates() {
        return subject;
    }

    public Configuration actualConfig() {
        return config(fetchSettings());
    }

    private Configuration config(PersistedAlarmMessagingCriteriaSettings current) {
        IAlarmCountersId counterId = new AlarmCountersIdItem(current.getAlarmCounterId());
        Threshold threshold = threshold(fromOrdinal(current.getAlarmSeverity()), current.getAlarmNumber());
        ImmutableConfiguration configuration = configuration(counterId, nullToEmpty(current.getScheduleDescription()));
        return current.getEnable() ? configuration.withThreshold(threshold) : configuration;
    }

    public Optional<String> server() {
        try {
            return ofNullable(InetAddress.getLocalHost().getHostName());
        } catch (UnknownHostException e) {
            LOGGER.error("Cannot resolve host name : ", e);
            return empty();
        }
    }

    public void updateScheduleDetails(String details) {
        PersistedAlarmMessagingCriteriaSettings current = fetchSettings();
        current.setScheduleDescription(details);
        repository.update(current);
    }
}
