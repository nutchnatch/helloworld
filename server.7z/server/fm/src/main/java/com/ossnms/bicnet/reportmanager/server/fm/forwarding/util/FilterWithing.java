package com.ossnms.bicnet.reportmanager.server.fm.forwarding.util;

import static rx.schedulers.Schedulers.computation;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;

import rx.Observable.Operator;
import rx.Scheduler;
import rx.Scheduler.Worker;
import rx.Subscriber;
import rx.exceptions.Exceptions;
import rx.functions.Action0;
import rx.observers.SerializedSubscriber;

public final class FilterWithing<T> implements Operator<T, T> {
    private final long intervalDuration;
    private final TimeUnit unit;
    private final Predicate<T> filter;
    private final Scheduler scheduler;

    /**
     * Returns an Observable that emits no more than one item emitted by the source Observable that matches filter during time window of a specified duration.
     * <p>
     * Item that does not match filter removes last clears current window
     * <p>
     * It differs from {@link rx.Observable#throttleLast(long, TimeUnit)} in that it starts next window on emitted item whereas {@link rx.Observable#throttleLast(long, TimeUnit)} ticks along at a scheduled interval.
     * <p>
     * It differs from {@link rx.Observable#throttleFirst(long, TimeUnit)} in that it also emits last item seen in the window whereas {@link rx.Observable#throttleFirst(long, TimeUnit)} drops all consequent items withing window.
     * <pre>
     *
     *    ___0___1_2_____3_4____-1________-1___5_6__-1______7_8_-1_9__________ source
     *
     *    filterWithing(5, seconds, isPositive)
     *
     *    ___0_______2_______4_________________5____________7_______9________  result
     *       |---5s--|---5s--|---5s--|         |---5s--|    |---5s--|---5s--|
     *
     * </pre>
     *
     * @param intervalDuration duration of window withing which items are not going
     * @param unit             the unit of time of intervalDuration
     * @param filter           a function that tests whether item should be emitted to subscribers
     */
    public FilterWithing(long intervalDuration, TimeUnit unit, Predicate<T> filter) {
        this(intervalDuration, unit, filter, computation());
    }

    public FilterWithing(long intervalDuration, TimeUnit unit, Predicate<T> filter, Scheduler scheduler) {
        this.intervalDuration = intervalDuration;
        this.unit = unit;
        this.filter = filter;
        this.scheduler = scheduler;
    }

    @Override
    public Subscriber<? super T> call(Subscriber<? super T> downstream) {
        final Worker worker = scheduler.createWorker();
        downstream.add(worker);

        SamplerSubscriber<T> sampler = new SamplerSubscriber<>(new SerializedSubscriber<>(downstream), worker, intervalDuration, unit, filter);
        downstream.add(sampler);

        return sampler;
    }

    private static final class SamplerSubscriber<T> extends Subscriber<T> implements Action0 {
        private final Subscriber<? super T> downstream;
        private final Worker worker;
        private final long time;
        private final TimeUnit unit;
        private final Predicate<T> filter;

        private static final Object EMPTY_TOKEN = new Object();
        private final AtomicReference<Object> lastValue = new AtomicReference<>(EMPTY_TOKEN);
        private final AtomicBoolean hasSchedule = new AtomicBoolean(false);

        SamplerSubscriber(Subscriber<? super T> downstream, Worker worker, long time, TimeUnit unit, Predicate<T> filter) {
            this.downstream = downstream;
            this.worker = worker;
            this.time = time;
            this.unit = unit;
            this.filter = filter;
        }

        @Override
        public void onStart() {
            request(Long.MAX_VALUE);
        }

        @Override
        public void onNext(T t) {
            if (filter.test(t)) {
                lastValue.set(t);
                emitOrWait();
            } else {
                lastValue.set(EMPTY_TOKEN);
            }
        }

        @Override
        public void onError(Throwable e) {
            downstream.onError(e);
            unsubscribe();
        }

        @Override
        public void onCompleted() {
            emitIfNonEmpty();
            downstream.onCompleted();
            unsubscribe();
        }

        /**
         * On schedule emmit last seen item
         */
        @Override
        public void call() {
            hasSchedule.set(false);
            emitIfNonEmpty();
        }

        /**
         * Emmit an item if there where no items recently.
         */
        private void emitOrWait() {
            boolean hadSchedule = hasSchedule.getAndSet(true);
            if (!hadSchedule) {
                emitIfNonEmpty();
            }
        }

        private void emitIfNonEmpty() {
            Object localValue = lastValue.getAndSet(EMPTY_TOKEN);
            if (localValue != EMPTY_TOKEN) {
                try {
                    @SuppressWarnings("unchecked")
                    T v = (T) localValue;
                    downstream.onNext(v);

                    hasSchedule.getAndSet(true);
                    worker.schedule(this, time, unit);
                } catch (RuntimeException e) {
                    Exceptions.throwOrReport(e, this);
                }
            }
        }
    }
}
