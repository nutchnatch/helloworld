package com.ossnms.bicnet.reportmanager.server.fm.forwarding.text;

import java.time.temporal.TemporalAccessor;

import static java.time.format.DateTimeFormatter.ofPattern;

/**
 * For date templates
 */
public enum MessagesDate implements MessageFormatter<TemporalAccessor> {
    AlarmMessageDate;

    @Override public String format(TemporalAccessor time) {
        return ofPattern(template()).format(time);
    }
}
