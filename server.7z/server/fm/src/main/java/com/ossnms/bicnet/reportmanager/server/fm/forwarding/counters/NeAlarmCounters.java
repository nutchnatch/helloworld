package com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersMarkableItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersMarkable;
import com.ossnms.bicnet.bcb.model.faultMgmt.SupervisedObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.Collection;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;

import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.ENABLED;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmCountersNotificationType.ALWAYS;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmType.BOTH;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters.AlarmCounters.supervised;
import static com.ossnms.bicnet.reportmanager.util.Constants.BICNET_COMPONENT_TYPE;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.toList;

public class NeAlarmCounters {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeAlarmCounters.class);
    private final AlarmCounters alarmCounters;

    @Inject public NeAlarmCounters(AlarmCounters alarmCounters) {
        this.alarmCounters = alarmCounters;
    }

    /**
     * Creates alarmCounters for specified NEs
     */
    public Optional<IAlarmCounters> create(String name, Collection<INEId> nes) {
        return alarmCounters.create(counters(name, nes));
    }

    /**
     * Updates NEs for alarmCounters
     */
    public Optional<IAlarmCountersMarkable> update(IAlarmCountersId id, Collection<INEId> nes) {
        return alarmCounters.update(id, counters -> replaceNEs(counters, nes));
    }

    /**
     * Fetches NEs for specified counter
     */
    public Collection<INEId> supervisedNEs(IAlarmCountersId id) {
        Collection<INEId> nes = alarmCounters.fetch(id)
                .map(IAlarmCounters::getSupervisedObjects)
                .map(NeAlarmCounters::extractNEs)
                .orElse(emptyList());
        LOGGER.debug("Fetched nes for counters {}, {}", id, nes);
        return nes;
    }

    private static IAlarmCounters counters(String name, Collection<INEId> nes) {
        IAlarmCounters counters = new AlarmCountersItem();
        counters.setName(name);
        counters.setSupervisedObjects(supervised(nes));
        counters.setActivationState(ENABLED);
        counters.setNotificationType(ALWAYS);
        counters.setAlarmType(BOTH);
        counters.setOwner(BICNET_COMPONENT_TYPE);
        return counters;
    }

    private static Collection<INEId> extractNEs(SupervisedObject[] supervisedObjects) {
        return Stream.of(supervisedObjects)
                .map(SupervisedObject::getMo)
                .flatMap(asInstanceOf(INEId.class))
                .collect(toList());
    }

    /**
     * Creates a function that casts object to specified class
     */
    private static <T, R> Function<T, Stream<R>> asInstanceOf(Class<R> clazz) {
        return t -> clazz.isInstance(t) ? Stream.of(clazz.cast(t)) : Stream.empty();
    }

    private static IAlarmCountersMarkable replaceNEs(IAlarmCounters counters, Collection<INEId> nes) {
        AlarmCountersMarkableItem update = new AlarmCountersMarkableItem(counters);
        update.setSupervisedObjects(supervised(nes));
        return update;
    }

}
