package com.ossnms.bicnet.reportmanager.server.fm.forwarding;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.AlarmMessagingSettings;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.AlarmForwardNotification;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.EmailSender;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.TriggerSettings;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RunningTotals;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.logging.Logger;
import com.ossnms.bicnet.reportmanager.server.runtime.BatchStep;
import com.ossnms.bicnet.reportmanager.server.runtime.Configuration;
import com.ossnms.bicnet.reportmanager.server.runtime.JobConfiguration;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import com.ossnms.bicnet.reportmanager.server.support.JobStatusSystemEventLog;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;

import static com.ossnms.bicnet.reportmanager.server.runtime.BatchStatus.FINISHED;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARM_MESSAGING_REPORT;
import static java.time.LocalTime.now;
import static java.util.Arrays.asList;

@Named(ALARM_MESSAGING_REPORT)
public class AlarmsForwardingConfiguration implements JobConfiguration {

    private final ISessionContext context;
    private final EmailSender emailSender;
    private final RunningTotals alarmStatistic;
    private final Logger logger;
    private final AlarmMessagingSettings alarmMessagingSettings;
    private TriggerSettings trigger;

    @Inject
    public AlarmsForwardingConfiguration(@BiCNet ISessionContext context, EmailSender emailSender, RunningTotals alarmStatistic, Logger logger, AlarmMessagingSettings alarmMessagingSettings) {
        this.emailSender = emailSender;
        this.alarmStatistic = alarmStatistic;
        this.context = context;
        this.logger = logger;
        this.alarmMessagingSettings = alarmMessagingSettings;
    }

    public AlarmsForwardingConfiguration withSettings(TriggerSettings trigger) {
        this.trigger = trigger;
        return this;
    }

    @Override public String getJobName() {
        return ALARM_MESSAGING_REPORT;
    }

    @Override public List<Configuration> getSteps() {
        Configuration sendEmail = new BatchStep<>(
                new AlarmForwardNotification(alarmMessagingSettings.server().orElse(""), trigger, alarmStatistic.statistics(), now()),
                emailSender);

        return asList(sendEmail);
    }

    @Override public List<JobListener> getJobListeners() {
        return asList(
                new ClearStatistics(alarmStatistic),
                new JobStatusSystemEventLog(context, logger));
    }

    private static class ClearStatistics implements JobListener {
        private final RunningTotals alarmStatistic;

        private ClearStatistics(RunningTotals alarmStatistic) {
            this.alarmStatistic = alarmStatistic;
        }

        @Override public void beforeJob(JobExecution jobExecution) {
        }

        @Override public void afterJob(JobExecution jobExecution) {
            if (FINISHED == jobExecution.getBatchStatus()) {
                alarmStatistic.clearStatistics();
            }
        }
    }
}
