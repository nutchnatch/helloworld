package com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics;

import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.AlarmMessagingSettings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.AbstractMap.SimpleImmutableEntry;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiFunction;
import java.util.function.Function;

import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RaisedAlarms.fromCounters;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RunningTotal.totalOf;
import static java.util.Collections.emptyMap;
import static java.util.stream.Collectors.toMap;

/**
 * Holds statistics of cleared and raised alarms since last email notification
 */
@Singleton public class RunningTotals {

    private static final Logger LOGGER = LoggerFactory.getLogger(RunningTotals.class);
    private final AlarmMessagingSettings settings;

    private Map<AlarmSeverity, RunningTotal> totals = emptyMap();

    @Inject public RunningTotals(AlarmMessagingSettings settings) {
        this.settings = settings;
    }


    void readData() {
        reloadData();
    }

    public void reloadData() {
        settings.currentCounters().ifPresent(this::updateStatistics);
    }

    /**
     * Updates value of entry
     */
    private static <K, T, R> Function<Entry<K, T>, Entry<K, R>> value(BiFunction<K, T, R> entryMapping) {
        return e -> new SimpleImmutableEntry<>(e.getKey(), entryMapping.apply(e.getKey(), e.getValue()));
    }

    /**
     * Updates value of entry
     */
    private static <K, T, R> Function<Entry<K, T>, Entry<K, R>> value(Function<T, R> valueMapping) {
        return e -> new SimpleImmutableEntry<>(e.getKey(), valueMapping.apply(e.getValue()));
    }

    /**
     * Updates cleared and raised alarms statistics
     */
    public void updateStatistics(IAlarmCounters counters) {
        LOGGER.debug("Updating from counters {}", counters);
        LOGGER.debug("Before update {}", totals);
        totals = fromCounters(counters).entrySet().stream()
                .map(value(this::runningTotal))
                .collect(toMap(Entry::getKey, Entry::getValue));
        LOGGER.debug("Updated statistics {}", totals);
    }

    /**
     * Clears cleared and raised alarms statistics
     */
    public void clearStatistics() {
        LOGGER.debug("Clearing statistics from {}", totals);
        totals = totals.entrySet().stream()
                .map(value(RunningTotal::reset))
                .collect(toMap(Entry::getKey, Entry::getValue));
        LOGGER.debug("Cleared {}", totals);
    }

    private RunningTotal runningTotal(AlarmSeverity severity, Integer total) {
        RunningTotal previousTotal = totals.getOrDefault(severity, totalOf(total));
        return previousTotal.next(total);
    }

    public Map<AlarmSeverity, RunningTotal> statistics() {
        return new HashMap<>(totals);
    }

}
