package com.ossnms.bicnet.reportmanager.server.fm.forwarding.text;

import static java.util.ResourceBundle.getBundle;

public interface MessageFormatter<T> {

    /**
     * Formats a template from resources for given argument
     */
    String format(T argument);

    /**
     * @return a name of the template
     * @see Enum#name() usualy is implemented by Enum
     */
    String name();

    default String template() {
        String baseName = MessageFormatter.class.getPackage().getName() + ".messages";
        return getBundle(baseName).getString(name());
    }
}