package com.ossnms.bicnet.reportmanager.server.fm.export.output;

import com.ossnms.bicnet.bcb.model.common.TrafficDirection;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.FaultCondition;
import com.ossnms.bicnet.bcb.model.faultMgmt.ProbableCause;

import java.util.Date;

public class OutageAlarmExportData {

    private static final String PRIMARY = "Primary";
    private static final String SECONDARY = "Secondary";

    private String state;
    private Date raiseTime;
    private String affectedEmName;
    private String affectedDomainName;
    private Date clearTime;
    private String alarmDuration;
    private String systemContainerName;
    private String affectedNeName;
    private String supplierAlarmIdAffectedObjectTypeExtendedGuiLabel;
    private String effectiveProbableCauseGuiLabel;
    private String equipmentTypeExtendedGuiLabel;
    private String nativeLocation;
    private String topoContainerName;
    private String subrackLocation;
    private AlarmSeverity severity;
    private String effectiveAlarmClass;
    private String alarmLevel;
    private ProbableCause supplierAlarmIdProbableCause;
    private String acknowledgedBy;
    private Date acknowledgeTime;
    private String acknowledgeDuration;
    private String computerName;
    private FaultCondition faultCondition;
    private TrafficDirection trafficDirection;
    private String addtionalInfo;
    private boolean hasNotes;

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public AlarmSeverity getSeverity() {
        return severity;
    }

    public void setSeverity(AlarmSeverity severity) {
        this.severity = severity;
    }

    public Date getRaiseTime() {
        return raiseTime;
    }

    public void setRaiseTime(Date raiseTime) {
        this.raiseTime = raiseTime;
    }

    public String getAffectedEmName() {
        return affectedEmName;
    }

    public void setAffectedEmName(String affectedEmName) {
        this.affectedEmName = affectedEmName;
    }

    public String getAffectedDomainName() {
        return affectedDomainName;
    }

    public void setAffectedDomainName(String affectedDomainName) {
        this.affectedDomainName = affectedDomainName;
    }

    public Date getClearTime() {
        return clearTime;
    }

    public void setClearTime(Date clearTime) {
        this.clearTime = clearTime;
    }

    public String getAlarmDuration() {
        return alarmDuration;
    }

    public void setAlarmDuration(String alarmDuration) {
        this.alarmDuration = alarmDuration;
    }

    public String getSystemContainerName() {
        return systemContainerName;
    }

    public void setSystemContainerName(String systemContainerName) {
        this.systemContainerName = systemContainerName;
    }

    public String getAffectedNeName() {
        return affectedNeName;
    }

    public void setAffectedNeName(String affectedNeName) {
        this.affectedNeName = affectedNeName;
    }

    public String getSupplierAlarmIdAffectedObjectTypeExtendedGuiLabel() {
        return supplierAlarmIdAffectedObjectTypeExtendedGuiLabel;
    }

    public void setSupplierAlarmIdAffectedObjectTypeExtendedGuiLabel(String supplierAlarmIdAffectedObjectTypeExtendedGuiLabel) {
        this.supplierAlarmIdAffectedObjectTypeExtendedGuiLabel = supplierAlarmIdAffectedObjectTypeExtendedGuiLabel;
    }

    public String getEffectiveProbableCauseGuiLabel() {
        return effectiveProbableCauseGuiLabel;
    }

    public void setEffectiveProbableCauseGuiLabel(String effectiveProbableCauseGuiLabel) {
        this.effectiveProbableCauseGuiLabel = effectiveProbableCauseGuiLabel;
    }

    public String getEquipmentTypeExtendedGuiLabel() {
        return equipmentTypeExtendedGuiLabel;
    }

    public void setEquipmentTypeExtendedGuiLabel(String equipmentTypeExtendedGuiLabel) {
        this.equipmentTypeExtendedGuiLabel = equipmentTypeExtendedGuiLabel;
    }

    public String getNativeLocation() {
        return nativeLocation;
    }

    public void setNativeLocation(String nativeLocation) {
        this.nativeLocation = nativeLocation;
    }

    public String getTopoContainerName() {
        return topoContainerName;
    }

    public void setTopoContainerName(String topoContainerName) {
        this.topoContainerName = topoContainerName;
    }

    public String getSubrackLocation() {
        return subrackLocation;
    }

    public void setSubrackLocation(String subrackLocation) {
        this.subrackLocation = subrackLocation;
    }

    public String getEffectiveAlarmClass() {
        return effectiveAlarmClass;
    }

    public void setEffectiveAlarmClass(String effectiveAlarmClass) {
        this.effectiveAlarmClass = effectiveAlarmClass;
    }

    public String getAlarmLevel() {
        if(supplierAlarmIdProbableCause != null) {
            return supplierAlarmIdProbableCause.isPrimaryAlarm() ? PRIMARY : SECONDARY;
        }
        return "";
    }

    public void setAlarmLevel(String alarmLevel) {
        this.alarmLevel = alarmLevel;
    }

    public ProbableCause getSupplierAlarmIdProbableCause() {
        return supplierAlarmIdProbableCause;
    }

    public void setSupplierAlarmIdProbableCause(ProbableCause supplierAlarmIdProbableCause) {
        this.supplierAlarmIdProbableCause = supplierAlarmIdProbableCause;
    }

    public String getAcknowledgedBy() {
        return acknowledgedBy;
    }

    public void setAcknowledgedBy(String acknowledgedBy) {
        this.acknowledgedBy = acknowledgedBy;
    }

    public Date getAcknowledgeTime() {
        return acknowledgeTime;
    }

    public void setAcknowledgeTime(Date acknowledgeTime) {
        this.acknowledgeTime = acknowledgeTime;
    }

    public String getAcknowledgeDuration() {
        return acknowledgeDuration;
    }

    public void setAcknowledgeDuration(String acknowledgeDuration) {
        this.acknowledgeDuration = acknowledgeDuration;
    }

    public String getComputerName() {
        return computerName;
    }

    public void setComputerName(String computerName) {
        this.computerName = computerName;
    }

    public FaultCondition getFaultCondition() {
        return faultCondition;
    }

    public void setFaultCondition(FaultCondition faultCondition) {
        this.faultCondition = faultCondition;
    }

    public TrafficDirection getTrafficDirection() {
        return trafficDirection;
    }

    public void setTrafficDirection(TrafficDirection trafficDirection) {
        this.trafficDirection = trafficDirection;
    }

    public String getAddtionalInfo() {
        return addtionalInfo;
    }

    public void setAddtionalInfo(String addtionalInfo) {
        this.addtionalInfo = addtionalInfo;
    }

    public boolean isHasNotes() {
        return hasNotes;
    }

    public void setHasNotes(boolean hasNotes) {
        this.hasNotes = hasNotes;
    }
}
