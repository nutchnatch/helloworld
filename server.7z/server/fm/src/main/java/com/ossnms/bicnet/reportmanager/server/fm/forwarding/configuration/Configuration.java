package com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration;

import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersId;
import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;
import org.immutables.value.Value.Style;

import java.util.Optional;

@Immutable @Style(of = "configuration")
public interface Configuration {

    @Parameter IAlarmCountersId counterId();

    @Parameter String scheduleDescription();

    Optional<Threshold> threshold();

    @Immutable @Style(of = "threshold") interface Threshold {

        @Parameter AlarmSeverity severity();

        @Parameter int alarms();
    }
}
