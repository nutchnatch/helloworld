package com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications;

import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.Configuration.Threshold;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesMustache.SpontaneousDetails;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesText.PeriodicLabel;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesText.SpontaneousLabel;
import static java.lang.String.valueOf;

public interface TriggerSettings {
    String settings();

    String trigger();

    class Spontaneous implements TriggerSettings {
        private final Threshold threshold;

        public Spontaneous(Threshold threshold) {
            this.threshold = threshold;
        }

        @Override public String settings() {
            return SpontaneousDetails.format(of(
                    "alarms", valueOf(threshold.alarms()),
                    "severity", threshold.severity().guiLabel()));
        }

        @Override public String trigger() {
            return SpontaneousLabel.text();
        }
    }

    class Periodic implements TriggerSettings {
        private final String settings;

        public Periodic(String settings) {
            this.settings = settings;
        }

        @Override public String settings() {
            return settings;
        }

        @Override public String trigger() {
            return PeriodicLabel.text();
        }
    }
}
