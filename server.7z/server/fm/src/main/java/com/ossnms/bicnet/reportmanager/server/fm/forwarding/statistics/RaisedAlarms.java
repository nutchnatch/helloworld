package com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmCount;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;

import java.util.AbstractMap.SimpleImmutableEntry;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;

import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CRITICAL;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.INDETERMINATE;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MAJOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MINOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.WARNING;
import static java.util.stream.Collectors.toMap;

public class RaisedAlarms {

    private static final Map<AlarmSeverity, Function<IAlarmCounters, AlarmCount>> SEVERITIES_GETTERS =
            ImmutableMap.<AlarmSeverity, Function<IAlarmCounters, AlarmCount>>builder()
                    .put(WARNING, IAlarmCounters::getWarning)
                    .put(MINOR, IAlarmCounters::getMinor)
                    .put(MAJOR, IAlarmCounters::getMajor)
                    .put(CRITICAL, IAlarmCounters::getCritical)
                    .put(INDETERMINATE, IAlarmCounters::getIndeterminate)
                    .build();

    /**
     * Converts alarmCounters to map of [AlarmSeverity -> raisedAlarms]
     */
    public static Map<AlarmSeverity, Integer> fromCounters(IAlarmCounters alarmCounters) {
        return SEVERITIES_GETTERS.entrySet().stream()
                .map(value(getter -> getter.apply(alarmCounters)))
                .filter(byValue(Objects::nonNull))
                .map(value(AlarmCount::getTotal))
                .collect(toMap(Entry::getKey, Entry::getValue));
    }

    /**
     * Changes value of entry
     */
    private static <K, T, R> Function<Entry<K, T>, Entry<K, R>> value(Function<T, R> function) {
        return e -> new SimpleImmutableEntry<>(e.getKey(), function.apply(e.getValue()));
    }

    /**
     * Checks value of entry
     */
    private static <K, V> Predicate<Entry<K, V>> byValue(Predicate<V> predicate) {
        return e -> predicate.test(e.getValue());
    }

}
