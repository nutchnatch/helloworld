package com.ossnms.bicnet.reportmanager.server.fm.forwarding.listeners;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import com.ossnms.bicnet.reportmanager.server.schedule.events.SchedulerVisitor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.subjects.PublishSubject;

import javax.inject.Singleton;
import java.util.Objects;

import static com.ossnms.bicnet.reportmanager.util.Constants.ACTION_TYPE_REPORT_EXECUTION;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARM_MESSAGING_REPORT;

/**
 * Listens to ScheduleExecutions and forwards them to subscribers
 */
@Singleton
public class AlarmForwardingSchedules implements SchedulerVisitor {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlarmForwardingSchedules.class);
    private final PublishSubject<ScheduleExecution> subject = PublishSubject.create();

    public Observable<ScheduleExecution> executions() {
        return subject;
    }

    @Override public boolean onScheduleExecution(ScheduleExecution scheduleExecution) throws BcbException {
        if (Objects.equals(scheduleExecution.getActionType(), ACTION_TYPE_REPORT_EXECUTION)
                && Objects.equals(scheduleExecution.getActionParameter(), ALARM_MESSAGING_REPORT)) {
            LOGGER.debug("Received schedule execution {}", scheduleExecution);
            subject.onNext(scheduleExecution);
            return true;
        } else {
            LOGGER.debug("Ignoring execution {}", scheduleExecution);
            return false;
        }
    }
}
