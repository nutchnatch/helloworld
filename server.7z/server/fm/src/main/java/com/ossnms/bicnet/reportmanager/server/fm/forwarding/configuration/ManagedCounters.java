package com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersIdItem;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

public class ManagedCounters {

    private static final IAlarmCountersId noCounter = new AlarmCountersIdItem(-1);
    private static final Logger LOGGER = LoggerFactory.getLogger(ManagedCounters.class);

    private IAlarmCountersId id = noCounter;

    public final void fromConfiguration(Configuration configuration) {
        LOGGER.debug("Updating managed counters from {}", id);
        id = configuration.counterId();
        LOGGER.debug("Updated managed counters to {}", id);
    }

    public boolean isManaged(IAlarmCountersId counters) {
        return Objects.equals(counters, id);
    }
}
