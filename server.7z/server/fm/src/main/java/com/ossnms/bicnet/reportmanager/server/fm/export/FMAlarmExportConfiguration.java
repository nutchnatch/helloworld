package com.ossnms.bicnet.reportmanager.server.fm.export;

import static java.util.Arrays.asList;
import static java.util.Arrays.stream;

import java.io.File;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecordFilterCondition;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.reportmanager.server.configuration.SettingsRepository;
import com.ossnms.bicnet.reportmanager.server.files.FilesManager;
import com.ossnms.bicnet.reportmanager.server.files.RetentionNumberOfGroupsFilter;
import com.ossnms.bicnet.reportmanager.server.fm.export.input.FMAlarmReader;
import com.ossnms.bicnet.reportmanager.server.fm.export.output.OutageAlarmRecordWriter;
import com.ossnms.bicnet.reportmanager.server.fm.export.process.OutageExportDataConverter;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.logging.Logger;
import com.ossnms.bicnet.reportmanager.server.model.ReportData;
import com.ossnms.bicnet.reportmanager.server.runtime.BatchStep;
import com.ossnms.bicnet.reportmanager.server.runtime.Configuration;
import com.ossnms.bicnet.reportmanager.server.runtime.JobConfiguration;
import com.ossnms.bicnet.reportmanager.server.support.FilesRetentionEnforcement;
import com.ossnms.bicnet.reportmanager.server.support.JobStatusClientNotifications;
import com.ossnms.bicnet.reportmanager.server.support.JobStatusSystemEventLog;
import com.ossnms.bicnet.reportmanager.server.support.ListReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import com.ossnms.bicnet.reportmanager.server.zip.ZipFiles;
import com.ossnms.bicnet.reportmanager.util.Constants;

@Named(Constants.ALARMS_OUTAGE_REPORT)
public class FMAlarmExportConfiguration implements JobConfiguration {

    @Inject private SettingsRepository settingsRepository;
    @Inject @BiCNet private ISessionContext context;
    @Inject private ReportData reportDataBean;
    @Inject private Logger logger;
    @Inject @BiCNet private IFaultMgrFacade fmManager;
    private ILogRecordFilter recordFilter;
    private INEId[] nes;


    @Override
    public String getJobName() {
        return Constants.ALARMS_OUTAGE_REPORT;
    }

    @Override public List<Configuration> getSteps() {
        Date exportDate = new Date();

        FilesManager filesManager = new FilesManager(settingsRepository.getOutageExportPath());
        File alarmsFile = filesManager.resolveReportFile("outage-alarms-records", "csv", exportDate);
        Configuration alarmExport = new BatchStep<>(
                new FMAlarmReader(context, fmManager, updateFilter(recordFilter, nes)),
                new OutageExportDataConverter(),
                new OutageAlarmRecordWriter(alarmsFile)
        );

        File zipFile = filesManager.resolveReportFile("outage-all-records", "zip", exportDate);
        Configuration archiveResults = new BatchStep<>(
                new ListReader<>(asList(alarmsFile)),
                new ZipFiles(zipFile)
        );

        return asList(alarmExport, archiveResults);
    }

    public FMAlarmExportConfiguration withFilterAndNes(ILogRecordFilter filter, INEId[] nes) {
        recordFilter = filter;
        this.nes = nes.clone();
        return this;
    }

    private ILogRecordFilter updateFilter(ILogRecordFilter filter, INEId[] nes) {
        IAlarmLogRecordFilterCondition neCondition = (IAlarmLogRecordFilterCondition) filter.newFilterCondition();

        int[] ids = stream(nes).mapToInt(INEId::getId).toArray();
        neCondition.filterByAffectedNes(null, ids, false);

        filter.addContextFilterCondition(neCondition);
        return filter;
    }

    @Override
    public List<JobListener> getJobListeners() {
        FilesManager filesManager = new FilesManager(settingsRepository.getOutageExportPath());
        RetentionNumberOfGroupsFilter filesFilter = new RetentionNumberOfGroupsFilter(settingsRepository.outageRetentionNumber());
        return asList(
                new FilesRetentionEnforcement(filesManager, filesFilter),
                new JobStatusClientNotifications(context, reportDataBean),
                new JobStatusSystemEventLog(context, logger));
    }
}
