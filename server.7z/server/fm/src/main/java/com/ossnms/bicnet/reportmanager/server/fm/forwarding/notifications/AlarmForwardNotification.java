package com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.EmailSender.Message;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RunningTotal;

import java.time.LocalTime;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CRITICAL;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.INDETERMINATE;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MAJOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MINOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.WARNING;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.EmailSender.Message.message;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RunningTotal.totalOf;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesDate.AlarmMessageDate;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesText.AlarmMessageSubject;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesMustache.AlarmCounterStatistics;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesMustache.AlarmMessageBody;
import static java.lang.String.valueOf;

public class AlarmForwardNotification implements ItemReader<Message> {

    private final String server;
    private final LocalTime time;
    private final TriggerSettings triggerSettings;
    private final Map<AlarmSeverity, RunningTotal> statistics;
    private final Queue<Message> messages = new LinkedList<>();

    public AlarmForwardNotification(String server, TriggerSettings triggerSettings, Map<AlarmSeverity, RunningTotal> statistics, LocalTime time) {
        this.server = server;
        this.statistics = statistics;
        this.triggerSettings = triggerSettings;
        this.time = time;
    }

    String subject() {
        return AlarmMessageSubject.text();
    }

    String content() {
        return AlarmMessageBody.format(ImmutableMap.<String, String>builder()
                .put("server", server)
                .put("trigger", triggerSettings.trigger())
                .put("settings", triggerSettings.settings())
                .put("time", AlarmMessageDate.format(time))
                .put("indeterminate", total(INDETERMINATE))
                .put("critical", total(CRITICAL))
                .put("major", total(MAJOR))
                .put("minor", total(MINOR))
                .put("warning", total(WARNING))
                .build());
    }

    private String total(AlarmSeverity severity) {
        RunningTotal total = statistics.getOrDefault(severity, totalOf(0));
        return AlarmCounterStatistics.format(of(
                "total", valueOf(total.getTotal()),
                "raised", valueOf(total.getRaised()),
                "cleared", valueOf(total.getCleared())));
    }

    @Override public void open() throws BcbException {
        messages.add(message(subject(), content()));
    }

    @Override public Message readItem() throws BcbException {
        return messages.poll();
    }
}
