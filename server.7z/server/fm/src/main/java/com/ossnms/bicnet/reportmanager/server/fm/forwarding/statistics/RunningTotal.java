package com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics;

import org.apache.commons.lang3.builder.EqualsBuilder;

import static java.lang.Math.abs;
import static java.util.Objects.hash;

public class RunningTotal {
    private final int total;
    private final int cleared;
    private final int raised;

    private RunningTotal(int total) {
        this(total, 0, 0);
    }

    public RunningTotal(int total, int raised, int cleared) {
        this.total = total;
        this.raised = raised;
        this.cleared = cleared;
    }

    public static RunningTotal totalOf(int total) {
        return new RunningTotal(total);
    }

    public RunningTotal next(int next) {
        int difference = next - total;
        return new RunningTotal(
                next,
                difference > 0 ? raised + abs(difference) : raised,
                difference < 0 ? cleared + abs(difference) : cleared);
    }

    public RunningTotal reset() {
        return totalOf(total);
    }

    public int getTotal() {
        return total;
    }

    public int getCleared() {
        return cleared;
    }

    public int getRaised() {
        return raised;
    }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RunningTotal that = (RunningTotal) o;

        return new EqualsBuilder()
                .append(total, that.total)
                .append(cleared, that.cleared)
                .append(raised, that.raised)
                .isEquals();
    }

    @Override public int hashCode() {
        return hash(total, cleared, raised);
    }

    @Override public String toString() {
        return "RunningTotal{" +
                "total=" + total +
                ", cleared=" + cleared +
                ", raised=" + raised +
                '}';
    }
}
