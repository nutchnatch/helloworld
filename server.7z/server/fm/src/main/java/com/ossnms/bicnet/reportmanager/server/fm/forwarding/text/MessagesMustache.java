package com.ossnms.bicnet.reportmanager.server.fm.forwarding.text;

import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BinaryOperator;

/**
 * For templates with mustaches {@code "{{key}} text {{anotherKey}}"}
 */
public enum MessagesMustache implements MessageFormatter<Map<String, String>> {
    AlarmMessageBody,
    AlarmCounterStatistics,
    SpontaneousDetails,
    PeriodicDetails,
    PeriodicSettings;

    /**
     * @param parameters a map with replacements for mustache placeholders
     */
    @Override public String format(Map<String, String> parameters) {
        return parameters.entrySet().stream()
                .reduce(template(), this::replace, first());
    }

    private String replace(String template, Entry<String, String> params) {
        return template.replaceAll(withMustaches(params.getKey()), params.getValue());
    }

    private String withMustaches(String key) {
        return "\\{\\{" + key + "}}";
    }

    private BinaryOperator<String> first() {
        return (left, right) -> left;
    }
}
