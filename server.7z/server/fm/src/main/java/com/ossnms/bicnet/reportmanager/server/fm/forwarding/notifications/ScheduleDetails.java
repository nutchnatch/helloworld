package com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications;

import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.SchedulePeriod;

import java.util.Objects;
import java.util.function.Supplier;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.MONTHLY;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.USER_DEFINED;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.WEEKLY;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesMustache.PeriodicDetails;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesMustache.PeriodicSettings;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesText.MonthlyLabel;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesText.PeriodicLabel;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesText.UserDefinedLabel;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.text.MessagesText.WeeklyLabel;
import static java.lang.String.valueOf;

public class ScheduleDetails {
    private final ISchedule schedule;

    public ScheduleDetails(ISchedule schedule) {
        this.schedule = schedule;
    }

    public String settings() {
        return PeriodicSettings.format(of(
                "label", period(schedule.getPeriod()),
                "details", details(schedule)));
    }

    private String period(SchedulePeriod period) {
        return matchPeriod(period,
                PeriodicLabel::text,
                WeeklyLabel::text,
                MonthlyLabel::text,
                UserDefinedLabel::text);
    }

    private static String details(ISchedule schedule) {
        return matchPeriod(schedule.getPeriod(),
                () -> PeriodicDetails.format(of(
                        "days", valueOf(schedule.getUserPeriod() / 1440),
                        "hours", valueOf(schedule.getUserPeriod() % 1440 / 60))),
                () -> schedule.getWeeklyDays().toString(),
                () -> schedule.getMonthlyDays().toString(),
                () -> ""
        );
    }

    private static <T> T matchPeriod(SchedulePeriod period, Supplier<T> userDefined, Supplier<T> weekly, Supplier<T> monthly, Supplier<T> otherwise) {
        if (Objects.equals(USER_DEFINED, period)) {
            return userDefined.get();
        } else if (Objects.equals(WEEKLY, period)) {
            return weekly.get();
        } else if (Objects.equals(MONTHLY, period)) {
            return monthly.get();
        } else {
            return otherwise.get();
        }
    }
}
