package com.ossnms.bicnet.reportmanager.server.fm.export.process;

import java.util.Date;
import java.util.StringJoiner;

import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.bicnet.reportmanager.server.executors.ItemProcessor;
import com.ossnms.bicnet.reportmanager.server.fm.export.output.OutageAlarmExportData;

public final class OutageExportDataConverter implements ItemProcessor<ILogRecord, OutageAlarmExportData> {

    @Override public OutageAlarmExportData processItem(ILogRecord item) {
        IAlarmLogRecord record = (IAlarmLogRecord) item;
        OutageAlarmExportData exportData = new OutageAlarmExportData();
        exportData.setState(record.getSeverity().guiLabel());
        exportData.setRaiseTime(record.getRaiseTime());
        exportData.setAffectedEmName(record.getAffectedEmName());
        exportData.setClearTime(record.getClearTime());
        if (record.getClearTime() != null && record.getRaiseTime() != null) {
            exportData.setAlarmDuration(getDuration(record.getRaiseTime(), record.getClearTime()));
        }
        exportData.setSystemContainerName(record.getSystemContainerName());
        exportData.setAffectedNeName(record.getAffectedNeName());
        exportData.setSupplierAlarmIdAffectedObjectTypeExtendedGuiLabel(record.getSupplierAlarmIdAffectedObjectTypeExtendedGuiLabel());
        exportData.setEffectiveProbableCauseGuiLabel(record.getEffectiveProbableCauseGuiLabel());
        exportData.setEquipmentTypeExtendedGuiLabel(record.getEquipmentTypeExtendedGuiLabel());
        exportData.setNativeLocation(record.getNativeLocation());
        exportData.setTopoContainerName(record.getTopoContainerName());
        exportData.setSubrackLocation(record.getSubrackLocation());
        exportData.setSeverity(record.getSeverity());
        exportData.setEffectiveAlarmClass(record.getEffectiveAlarmClass());
        exportData.setSupplierAlarmIdProbableCause(record.getSupplierAlarmIdProbableCause());
        exportData.setAcknowledgedBy(record.getAcknowledgedBy());
        exportData.setAcknowledgeTime(record.getAcknowledgeTime());
        if (record.getAcknowledgeTime() != null && record.getRaiseTime() != null) {
            exportData.setAcknowledgeDuration(getDuration(record.getRaiseTime(), record.getAcknowledgeTime()));
        }
        exportData.setComputerName(record.getComputerName());
        exportData.setFaultCondition(record.getFaultCondition());
        exportData.setTrafficDirection(record.getTrafficDirection());
        exportData.setAddtionalInfo(record.getAddtionalInfo());
        exportData.setHasNotes(record.getHasNotes());
        return exportData;
    }

    private static String getDuration(Date startDate, Date endDate) {
        final long secondsMilli = 1000L;
        final long minustesMilli = secondsMilli * 60L;
        final long hoursMilli = minustesMilli * 60L;
        final long daysMilli = hoursMilli * 24L;

        long difference = endDate.getTime() - startDate.getTime();
        final long elapsedDays = difference / daysMilli;

        difference %= daysMilli;
        final long elapsedHours = difference / hoursMilli;

        difference %= hoursMilli;
        final long elapsedMinutes = difference / minustesMilli;

        difference %= minustesMilli;
        final long elapsedSeconds = difference / secondsMilli;

        StringJoiner sj = new StringJoiner(" ");
        sj.add(Long.toString(elapsedDays) + " d");
        sj.add(Long.toString(elapsedHours) + " h");
        sj.add(Long.toString(elapsedMinutes) + " m");
        sj.add(Long.toString(elapsedSeconds) + " s");

        return sj.toString();
    }
}
