package com.ossnms.bicnet.reportmanager.server.fm.export.input;

import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogRecordIterator;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;

public class FMAlarmReader extends BcbReplyReader<Void, ILogRecord, ILogRecord[]> {

    private static final int PAGE_REQUEST_NUMBER = 1000;
    private static final ILogRecord[] EMPTY_REPLY = new ILogRecord[0];
    private final ISessionContext context;
    private final IFaultMgrFacade fmManager;
    private final ILogRecordFilter filter;
    private ILogRecordIterator iterator;
    private boolean hasItems;

    public FMAlarmReader(ISessionContext context, IFaultMgrFacade fmManager, ILogRecordFilter filter) {
        this.context = context;
        this.fmManager = fmManager;
        this.filter = filter;
    }

    private ILogRecordIterator iterator() throws BcbException {
        if (iterator == null) {
            iterator = fmManager.getLogRecords(context, filter, true, true);
        }
        return iterator;
    }

    @Override protected ILogRecord[] nextReply(Void lastId) throws BcbException {
        hasItems = iterator().hasNext(context);
        return hasItems ? iterator().getNext(context, PAGE_REQUEST_NUMBER) : EMPTY_REPLY;
    }

    @Override protected ILogRecord[] data(ILogRecord[] reply) {
        return reply;
    }

    @Override protected Void lastId(ILogRecord[] reply) {
        return null;
    }

    @Override protected boolean isLast(ILogRecord[] reply) {
        return !hasItems;
    }
}