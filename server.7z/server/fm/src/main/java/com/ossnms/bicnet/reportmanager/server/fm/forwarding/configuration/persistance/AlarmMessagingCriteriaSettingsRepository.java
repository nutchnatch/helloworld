package com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.persistance;

import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;

@Singleton
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class AlarmMessagingCriteriaSettingsRepository {

    private AlarmMessagingCriteriaSettingsDAO storage;

    public AlarmMessagingCriteriaSettingsRepository() {
    }

    @Inject public AlarmMessagingCriteriaSettingsRepository(AlarmMessagingCriteriaSettingsDAO storage) {
        this.storage = storage;
    }

    public Optional<PersistedAlarmMessagingCriteriaSettings> getAlarmMessagingCriteriaSettings(){
        List<PersistedAlarmMessagingCriteriaSettings> all = storage.findAll();
        if (all == null || all.isEmpty()) {
            return empty();
        }
        return ofNullable(all.get(0));
    }

    public int deleteAll(){
        return storage.deleteAll();
    }

    public void update(PersistedAlarmMessagingCriteriaSettings outageAlarmSettings) {
        storage.merge(outageAlarmSettings);
    }

    public void create(PersistedAlarmMessagingCriteriaSettings outageAlarmSettings) {
        storage.persist(outageAlarmSettings);
    }
}
