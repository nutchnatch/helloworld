package com.ossnms.bicnet.reportmanager.server.fm.export;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.logMgmt.LogIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.TrafficDirection;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmClasses;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.bcb.model.faultMgmt.SupervisedObject;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

/**
 * Fetches topology data from Topology server using its façades.
 */
public class FMAlarmDataReader {


    private static final IAlarmCounters[] DEFAULT_ALARM_COUNTERS = new IAlarmCounters[0];
    @Inject @BiCNet
    private ISessionContext context;

    @Inject @BiCNet
    private IFaultMgrFacade fmManager;

    private static final Logger LOGGER = LoggerFactory.getLogger(FMAlarmDataReader.class);

    public Map<INEId, IAlarmCounters> getSeveritiesByNes(List<INE> nes) {

        List<SupervisedObject> sos = new ArrayList<>();
        for (INE ne : nes) {
            sos.add(new SupervisedObject(ne, TrafficDirection.NONE, AlarmClasses.all(), true));
            sos.add(new SupervisedObject(new NetworkElementIdItem(ne.getId()), TrafficDirection.NONE, AlarmClasses.all(), true));
        }

        IAlarmCounters[] fmAlarmCounters = DEFAULT_ALARM_COUNTERS;
        try {
            fmAlarmCounters = fmManager.calculateAlarmSeverityForSupervisedObjs(context, sos);
        } catch (BcbException e) {
            LOGGER.error("Error calling calculateAlarmSeverityForSupervisedObjs from FM.", e);
        }
        return mergeAlarmCountersByNeId( fmAlarmCounters);
    }

    static Map<INEId, IAlarmCounters> mergeAlarmCountersByNeId(IAlarmCounters[] fmAlarmCounters) {
        HashMap<INEId, IAlarmCounters> map = new HashMap<>();

        for (IAlarmCounters fmAlarmcounter : fmAlarmCounters) {
            INEId neId = new NEIdItem(fmAlarmcounter.getSupervisedObjects()[0].getMo().neId().getNeId());

            IAlarmCounters alarmCounter = map.computeIfAbsent(neId, id -> fmAlarmcounter);

            //update severity on map for current NE
            if(fmAlarmcounter.getSeverity().getOrdinal() > alarmCounter.getSeverity().getOrdinal()) {
                alarmCounter.setSeverity(fmAlarmcounter.getSeverity());
            }
            //update acknowledged on map for current NE
            if(!fmAlarmcounter.getIsAcknowledged()) {
                alarmCounter.setIsAcknowledged(false);
            }
        }

        return map;
    }

    public ILogRecordFilter getNewFilter() throws BcbException {
        return fmManager.newFilter(context, new LogIdItem("Alarm Log"));
    }

}
