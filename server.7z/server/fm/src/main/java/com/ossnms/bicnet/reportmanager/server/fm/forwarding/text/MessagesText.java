package com.ossnms.bicnet.reportmanager.server.fm.forwarding.text;

/**
 * For text messages
 */
public enum MessagesText implements MessageFormatter<Void> {
    AlarmMessageSubject,
    SpontaneousLabel,
    PeriodicLabel,
    WeeklyLabel,
    MonthlyLabel,
    UserDefinedLabel;

    @Override public String format(Void nothing) {
        return template();
    }
    
    public String text() {
        return format(null);
    }
}
