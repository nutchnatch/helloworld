package com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications;

import com.ossnms.bicnet.bcb.facade.ecs.IECSFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.EmailSender.Message.message;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class EmailSenderTest {
    @Test public void shouldSendEmail() throws Exception {
        ISessionContext context = mock(ISessionContext.class);
        IECSFacade facade = mock(IECSFacade.class);

        new EmailSender(context, facade).writeItems(message("Subject", "Email Content"));

        ArgumentCaptor<String> sendSubject = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> sendContent = ArgumentCaptor.forClass(String.class);
        verify(facade).sendMessage(eq(context), sendSubject.capture(), sendContent.capture());
        assertThat(sendSubject.getValue(), is("Subject"));
        assertThat(sendContent.getValue(), is("Email Content"));
    }
}