package com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmCount;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.AlarmMessagingSettings;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CRITICAL;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.INDETERMINATE;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.WARNING;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RunningTotal.totalOf;
import static java.util.Collections.emptyMap;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class RunningTotalsTest {
    @Test public void shouldStartEmpty() throws Exception {
        RunningTotals runningTotals = new RunningTotals(settings(empty()));
        runningTotals.readData();

        assertThat(runningTotals.statistics(), is(emptyMap()));
    }

    @Test public void shouldInitializeFromSettings() throws Exception {
        IAlarmCounters counters = counters(4, 1, 2, 10, 0);

        RunningTotals runningTotals = new RunningTotals(settings(of(counters)));
        runningTotals.readData();

        assertThat(runningTotals.statistics(), hasEntry(CRITICAL, totalOf(10)));
        assertThat(runningTotals.statistics(), hasEntry(WARNING, totalOf(4)));
    }

    @Test public void shouldHaveEmptyDifferenceOnFirstUpdate() throws Exception {
        RunningTotals runningTotals = new RunningTotals(settings(empty()));

        runningTotals.updateStatistics(counters(0, 0, 0, 10, 10));

        assertThat(runningTotals.statistics(), hasEntry(INDETERMINATE, totalOf(10)));
        assertThat(runningTotals.statistics(), hasEntry(CRITICAL, totalOf(10)));
    }

    @Test public void shouldUpdateStatisticsOnChange() throws Exception {
        RunningTotals runningTotals = new RunningTotals(settings(empty()));
        runningTotals.updateStatistics(counters(0, 0, 0, 10, 10));

        runningTotals.updateStatistics(counters(0, 0, 0, 5, 20));

        assertThat(runningTotals.statistics(), hasEntry(INDETERMINATE, new RunningTotal(20, 10, 0)));
        assertThat(runningTotals.statistics(), hasEntry(CRITICAL, new RunningTotal(5, 0, 5)));
    }

    @Test public void shouldClearDifference() throws Exception {
        RunningTotals runningTotals = new RunningTotals(settings(empty()));
        runningTotals.updateStatistics(counters(0, 0, 0, 10, 10));

        runningTotals.updateStatistics(counters(0, 0, 0, 5, 20));
        runningTotals.clearStatistics();

        assertThat(runningTotals.statistics(), hasEntry(INDETERMINATE, totalOf(20)));
        assertThat(runningTotals.statistics(), hasEntry(CRITICAL, totalOf(5)));

    }


    private AlarmMessagingSettings settings(Optional<IAlarmCounters> counters) {
        AlarmMessagingSettings settings = mock(AlarmMessagingSettings.class);
        when(settings.currentCounters()).thenReturn(counters);
        return settings;
    }

    private IAlarmCounters counters(int warning, int minor, int major, int critical, int indeterminate) {
        AlarmCountersItem counters = new AlarmCountersItem();
        counters.setWarning(count(warning));
        counters.setMinor(count(minor));
        counters.setMajor(count(major));
        counters.setCritical(count(critical));
        counters.setIndeterminate(count(indeterminate));
        return counters;
    }

    private AlarmCount count(int total) {
        return new AlarmCount(total, 0);
    }

}