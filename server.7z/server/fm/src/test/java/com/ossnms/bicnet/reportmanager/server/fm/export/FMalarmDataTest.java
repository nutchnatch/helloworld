package com.ossnms.bicnet.reportmanager.server.fm.export;

import static com.ossnms.bicnet.reportmanager.server.fm.export.FMAlarmDataReader.mergeAlarmCountersByNeId;
import static org.junit.Assert.assertEquals;

import java.util.Map;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.model.common.TrafficDirection;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmClasses;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.bcb.model.faultMgmt.SupervisedObject;

public class FMalarmDataTest {

    @Test public void testMergeAlarmCountersByNeId_differentSev() throws Exception {
        AlarmCountersItem ac1 = createAlarmCountersItem(1, AlarmSeverity.CLEARED, true);
        AlarmCountersItem ac2 = createAlarmCountersItem(1, AlarmSeverity.MINOR, true);

        Map<INEId, IAlarmCounters> acMap = mergeAlarmCountersByNeId(new IAlarmCounters[]{ac1, ac2});
        IAlarmCounters c = acMap.get(neId(1));
        assertEquals(AlarmSeverity.MINOR, c.getSeverity());
        assertEquals(true, c.getIsAcknowledged());
    }

    @Test public void testMergeAlarmCountersByNeId_SevEqual() throws Exception {
        AlarmCountersItem ac1 = createAlarmCountersItem(1, AlarmSeverity.CLEARED, true);
        AlarmCountersItem ac2 = createAlarmCountersItem(1, AlarmSeverity.CLEARED, true);

        Map<INEId, IAlarmCounters> acMap = mergeAlarmCountersByNeId(new IAlarmCounters[]{ac1, ac2});
        IAlarmCounters c = acMap.get(neId(1));
        assertEquals(AlarmSeverity.CLEARED, c.getSeverity());
        assertEquals(true, c.getIsAcknowledged());
    }

    @Test public void testMergeAlarmCountersByNeId_OnlyOneSO() throws Exception {
        AlarmCountersItem ac1 = createAlarmCountersItem(1, AlarmSeverity.CLEARED, true);

        Map<INEId, IAlarmCounters> acMap = mergeAlarmCountersByNeId(new IAlarmCounters[]{ac1});
        IAlarmCounters c = acMap.get(neId(1));
        assertEquals(AlarmSeverity.CLEARED, c.getSeverity());
        assertEquals(true, c.getIsAcknowledged());
    }

    @Test public void testMergeAlarmCountersByNeId_Ack() throws Exception {
        AlarmCountersItem ac1 = createAlarmCountersItem(1, AlarmSeverity.CLEARED, false);
        AlarmCountersItem ac2 = createAlarmCountersItem(1, AlarmSeverity.CLEARED, true);

        Map<INEId, IAlarmCounters> acMap = mergeAlarmCountersByNeId(new IAlarmCounters[]{ac1, ac2});
        IAlarmCounters c = acMap.get(neId(1));
        assertEquals(AlarmSeverity.CLEARED, c.getSeverity());
        assertEquals(false, c.getIsAcknowledged());
    }

    @Test public void testMergeAlarmCountersByNeId_MultipleNes() throws Exception {
        AlarmCountersItem ac1 = createAlarmCountersItem(1, AlarmSeverity.CLEARED, true);
        AlarmCountersItem ac2 = createAlarmCountersItem(1, AlarmSeverity.MINOR, true);
        AlarmCountersItem ac3 = createAlarmCountersItem(2, AlarmSeverity.CRITICAL, false);
        AlarmCountersItem ac4 = createAlarmCountersItem(2, AlarmSeverity.MAJOR, true);

        Map<INEId, IAlarmCounters> acMap = mergeAlarmCountersByNeId(new IAlarmCounters[]{ac1, ac2, ac3, ac4});
        IAlarmCounters c1 = acMap.get(neId(1));
        IAlarmCounters c2 = acMap.get(neId(2));
        assertEquals(AlarmSeverity.MINOR, c1.getSeverity());
        assertEquals(true, c1.getIsAcknowledged());
        assertEquals(AlarmSeverity.CRITICAL, c2.getSeverity());
        assertEquals(false, c2.getIsAcknowledged());
    }

    private INEId neId(int id) {
        return new NEIdItem(id);
    }

    private AlarmCountersItem createAlarmCountersItem(int neId, AlarmSeverity as, boolean ack) {
        AlarmCountersItem ac1 = new AlarmCountersItem();
        SupervisedObject so1 = new SupervisedObject(new NEIdItem(neId), TrafficDirection.NONE, AlarmClasses.all(), false);
        ac1.setSupervisedObjects(new SupervisedObject[]{so1});
        ac1.setSeverity(as);
        ac1.setIsAcknowledged(ack);
        return ac1;
    }

}
