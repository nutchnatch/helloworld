package com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmCount;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import org.junit.Test;

import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CRITICAL;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MAJOR;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.ImmutableConfiguration.configuration;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.ImmutableThreshold.threshold;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class AlarmsThresholdFilterTest {
    @Test public void shouldIgnoreLowerAlarms() throws Exception {
        AlarmsThresholdFilter filter = filter(CRITICAL, 10);
        IAlarmCounters alarms = alarms(10, 10, 10, 0, 0);

        assertThat(filter.hasReachedThreshold(alarms), is(false));
    }

    @Test public void shouldSumAlarms() throws Exception {
        AlarmsThresholdFilter filter = filter(MAJOR, 10);
        IAlarmCounters alarms = alarms(0, 0, 5, 5, 5);

        assertThat(filter.hasReachedThreshold(alarms), is(true));
    }

    @Test public void shouldIncludeCurrentLevel() throws Exception {
        AlarmsThresholdFilter filter = filter(MAJOR, 10);
        IAlarmCounters alarms = alarms(0, 0, 10, 0, 0);

        assertThat(filter.hasReachedThreshold(alarms), is(true));
    }

    private IAlarmCounters alarms(int warning, int minor, int major, int critical, int indeterminate) {
        AlarmCountersItem counters = new AlarmCountersItem();
        counters.setWarning(count(warning));
        counters.setMinor(count(minor));
        counters.setMajor(count(major));
        counters.setCritical(count(critical));
        counters.setIndeterminate(count(indeterminate));
        return counters;
    }

    private AlarmCount count(int total) {
        return new AlarmCount(total, 0);
    }

    private AlarmsThresholdFilter filter(AlarmSeverity severity, int alarms) {
        return new AlarmsThresholdFilter().updateFromConfiguration(
                configuration(new AlarmCountersIdItem(1), "").withThreshold(threshold(severity, alarms)));
    }
}