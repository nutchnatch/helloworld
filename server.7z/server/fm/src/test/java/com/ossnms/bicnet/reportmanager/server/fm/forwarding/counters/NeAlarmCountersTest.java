package com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCountersMarkable;
import org.junit.Test;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Optional;
import java.util.function.Function;

import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.ENABLED;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmCountersNotificationType.ALWAYS;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmType.BOTH;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters.AlarmCounters.supervised;
import static com.ossnms.bicnet.reportmanager.util.Constants.BICNET_COMPONENT_TYPE;
import static java.util.Arrays.asList;
import static java.util.Optional.ofNullable;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NeAlarmCountersTest {
    @Test public void shouldExtractNEs() throws Exception {
        IAlarmCountersId id = new AlarmCountersIdItem(42);
        AlarmCounters alarmCounters = alarmCounters(id, counters(ne(1), ne(2)));
        NeAlarmCounters neAlarmCounters = new NeAlarmCounters(alarmCounters);

        Collection<INEId> nes = neAlarmCounters.supervisedNEs(id);

        assertThat(nes, containsInAnyOrder(ne(1), ne(2)));
    }

    @Test public void shouldExtractNoNesForAbsentCounters() throws Exception {
        IAlarmCountersId id = new AlarmCountersIdItem(17);
        AlarmCounters alarmCounters = alarmCounters(id, null);
        NeAlarmCounters neAlarmCounters = new NeAlarmCounters(alarmCounters);

        Collection<INEId> nes = neAlarmCounters.supervisedNEs(id);

        assertThat(nes, is(empty()));
    }

    @Test public void shouldNotExtractNonNEs() throws Exception {
        IAlarmCountersId id = new AlarmCountersIdItem(13);
        AlarmCounters alarmCounters = alarmCounters(id, counters(new ASIdItem(1), ne(2)));
        NeAlarmCounters neAlarmCounters = new NeAlarmCounters(alarmCounters);

        Collection<INEId> nes = neAlarmCounters.supervisedNEs(id);

        assertThat(nes, containsInAnyOrder(ne(2)));
    }

    @Test public void shouldCreateNeCounters() throws Exception {
        AlarmCounters alarmCounters = alarmCounters(new AlarmCountersIdItem(3), null);
        NeAlarmCounters neAlarmCounters = new NeAlarmCounters(alarmCounters);

        Optional<IAlarmCounters> createdCounters = neAlarmCounters.create("report name", asList(ne(1), ne(2)));

        IAlarmCounters created = createdCounters.orElseThrow(() -> new AssertionError("Should be present"));
        assertThat(created.getName(), is("report name"));
        assertThat(created.getSupervisedObjects(), is(supervised(asList(ne(1), ne(2)))));
        assertThat(created.getActivationState(), is(ENABLED));
        assertThat(created.getAlarmType(), is(BOTH));
        assertThat(created.getNotificationType(), is(ALWAYS));
        assertThat(created.getOwner(), is(BICNET_COMPONENT_TYPE));
    }

    private AlarmCounters alarmCounters(IAlarmCountersId id, @Nullable IAlarmCounters counters) {
        AlarmCounters alarmCounters = mock(AlarmCounters.class);
        when(alarmCounters.fetch(id)).thenReturn(ofNullable(counters));
        when(alarmCounters.modify(any(IAlarmCountersMarkable.class))).then(mock -> ofNullable(mock.getArguments()[0]));
        when(alarmCounters.create(any(IAlarmCounters.class))).then(mock -> ofNullable(mock.getArguments()[0]));
        when(alarmCounters.update(any(IAlarmCountersId.class), any(Function.class))).thenCallRealMethod();
        return alarmCounters;
    }

    private IAlarmCounters counters(IManagedObjectId... ids) {
        AlarmCountersItem counters = new AlarmCountersItem();
        counters.setSupervisedObjects(supervised(asList(ids)));
        return counters;
    }

    private INEId ne(int id) {
        return new NEIdItem(id);
    }

}