package com.ossnms.bicnet.reportmanager.server.fm.forwarding.util;

import org.junit.Test;
import rx.observers.TestSubscriber;
import rx.schedulers.TestScheduler;
import rx.subjects.TestSubject;

import java.util.function.Predicate;

import static java.util.concurrent.TimeUnit.MINUTES;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.junit.Assert.assertThat;

public class FilterWithingTest {

    private final Predicate<Integer> isPositive = i -> i >= 0;
    private final TestScheduler scheduler = new TestScheduler();
    private final TestSubject<Integer> subject = TestSubject.create(scheduler);
    private final TestSubscriber<Integer> subscriber = TestSubscriber.create();

    @Test public void shouldEmmitFirstItemImmediately() throws Exception {
        subject.lift(new FilterWithing<>(15, MINUTES, isPositive, scheduler)).subscribe(subscriber);


        //----1------------- subject
        //----1------------- subscriber
        //-----?------------ assert
        //    |--15MIN--|

        subject.onNext(1);
        scheduler.triggerActions();

        assertThat(subscriber.getOnNextEvents(), contains(1));
    }

    @Test public void shouldNotWrongFirstItem() throws Exception {
        subject.lift(new FilterWithing<>(15, MINUTES, isPositive, scheduler)).subscribe(subscriber);

        //----(-1)--------- subject
        //----------------- subscriber
        //--------?-------- assert
        //    |--15MIN--|

        subject.onNext(-1);
        scheduler.triggerActions();

        assertThat(subscriber.getOnNextEvents(), empty());
    }

    @Test public void shouldNotDuplicateFirstItemAfterWindowEnd() throws Exception {
        subject.lift(new FilterWithing<>(15, MINUTES, isPositive, scheduler)).subscribe(subscriber);

        //----1-------------- subject
        //----1-------------- subscriber
        //-----------------?- assert
        //    |--15MIN--|

        subject.onNext(1);
        scheduler.advanceTimeBy(20, MINUTES);

        assertThat(subscriber.getOnNextEvents(), contains(1));
    }

    @Test public void shouldIgnoreItemsWithingWindow() throws Exception {
        subject.lift(new FilterWithing<>(15, MINUTES, isPositive, scheduler)).subscribe(subscriber);


        //----1-2--3--4----- subject
        //----1------------- subscriber
        //--------------?--- assert
        //    |--15MIN---|


        subject.onNext(1);
        subject.onNext(2);
        scheduler.advanceTimeBy(5, MINUTES);
        subject.onNext(3);
        scheduler.advanceTimeBy(1, MINUTES);
        subject.onNext(4);
        scheduler.advanceTimeBy(1, MINUTES);

        assertThat("Should ignore next notifications withing window",
                subscriber.getOnNextEvents(), contains(1));
    }

    @Test public void shouldPropagateLastItemOfTheWindow() throws Exception {
        subject.lift(new FilterWithing<>(15, MINUTES, isPositive, scheduler)).subscribe(subscriber);


        //----1-2----3---------------- subject
        //----1----------3------------ subscriber
        //------------------?--------- assert
        //    |--15MIN---|--15MIN---|

        subject.onNext(1);
        subject.onNext(2);
        scheduler.advanceTimeBy(5, MINUTES);
        subject.onNext(3);
        scheduler.advanceTimeBy(10, MINUTES);

        assertThat("Should emmit last notification after window ends",
                subscriber.getOnNextEvents(), contains(1, 3));
    }

    @Test public void shouldCreateWindowOnLastEmittedItem() throws Exception {
        subject.lift(new FilterWithing<>(15, MINUTES, isPositive, scheduler)).subscribe(subscriber);


        //----1---2--------3------------- subject
        //----1----------2----------3---- subscriber
        //-------------------?---------?- assert
        //    |--15MIN---|--15MIN---|

        subject.onNext(1);
        scheduler.advanceTimeBy(5, MINUTES);
        subject.onNext(2);
        scheduler.advanceTimeBy(10, MINUTES);

        subject.onNext(3);
        scheduler.advanceTimeBy(5, MINUTES);
        assertThat("Should not emmit notification after window ends",
                subscriber.getOnNextEvents(), contains(1, 2));

        scheduler.advanceTimeBy(10, MINUTES);
        assertThat("Should emmit last notification after window ends",
                subscriber.getOnNextEvents(), contains(1, 2, 3));

    }

    @Test public void shouldClearWindowIfLastItemDoesNotMatchFilter() throws Exception {
        subject.lift(new FilterWithing<>(15, MINUTES, isPositive, scheduler)).subscribe(subscriber);


        //----1---2--(-3)------------- subject
        //----1----------------------- subscriber
        //-----------------?---------- assert
        //    |--15MIN---|--15MIN---|

        subject.onNext(1);
        subject.onNext(2);
        scheduler.advanceTimeBy(5, MINUTES);
        subject.onNext(-3);
        scheduler.advanceTimeBy(10, MINUTES);

        assertThat("Should clear window on item that does not match filter",
                subscriber.getOnNextEvents(), contains(1));
    }

    @Test public void shouldEmmitItemImmediatelyAfterWindow() throws Exception {
        subject.lift(new FilterWithing<>(15, MINUTES, isPositive, scheduler)).subscribe(subscriber);

        //----1------------2-3--4-------- subject
        //----1------------2--------4---- subscriber
        //---------------------?-------?- assert
        //    |--15MIN---|--15MIN---|

        subject.onNext(1);
        scheduler.advanceTimeBy(16, MINUTES);
        subject.onNext(2);
        subject.onNext(3);
        scheduler.advanceTimeBy(5, MINUTES);

        assertThat("Should emmit first item in text window immediately",
                subscriber.getOnNextEvents(), contains(1, 2));

        subject.onNext(4);
        scheduler.advanceTimeBy(10, MINUTES);

        assertThat("Should emmit last item of window after window ends",
                subscriber.getOnNextEvents(), contains(1, 2, 4));
    }

}
