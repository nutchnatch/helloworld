package com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics;

import org.junit.Test;

import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RunningTotal.totalOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class RunningTotalTest {

    @Test public void shouldInitializeWithEmptyDifference() throws Exception {
        RunningTotal runningTotal = totalOf(10);

        assertThat(runningTotal, is(new RunningTotal(10, 0, 0)));
    }

    @Test public void shouldClearDifferenceOnReset() throws Exception {
        RunningTotal previous = new RunningTotal(10, 11, 12);

        RunningTotal next = previous.reset();

        assertThat(next, is(new RunningTotal(10, 0, 0)));
    }

    @Test public void shouldIncreaseClearedOnDecreasedTotal() throws Exception {
        RunningTotal previous = new RunningTotal(15, 100, 100);

        RunningTotal next = previous.next(10);

        assertThat(next, is(new RunningTotal(10, 100, 105)));
    }

    @Test public void shouldIncreaseRaisedOnIncreasedTotal() throws Exception {
        RunningTotal previous = new RunningTotal(10, 100, 100);

        RunningTotal next = previous.next(15);

        assertThat(next, is(new RunningTotal(15, 105, 100)));
    }

    @Test public void shouldNotChangeDiffOnSameTotal() throws Exception {
        RunningTotal previous = new RunningTotal(15, 100, 100);

        RunningTotal next = previous.next(15);

        assertThat(next, is(new RunningTotal(15, 100, 100)));
    }


}