package com.ossnms.bicnet.reportmanager.server.fm.forwarding.counters;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEMarkableItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersMarkableItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import org.junit.Test;
import rx.Subscription;
import rx.observers.TestObserver;

import java.util.Date;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;

public class AlarmCountersTest {
    
    @Test public void shouldPublishCountersOnAVC() throws Exception {
        TestObserver<IAlarmCounters> testObserver = new TestObserver<>();
        AlarmCounters alarmCounters = new AlarmCounters(null, null);
        alarmCounters.updates().subscribe(testObserver);
        AlarmCountersMarkableItem first = markable(1);
        AlarmCountersMarkableItem second = markable(2);

        avc(first).dispatch(alarmCounters);
        avc(second).dispatch(alarmCounters);

        testObserver.assertReceivedOnNext(asList(first, second));
    }

    @Test public void shouldNotPublishToUnsubscribedObserver() throws Exception {
        TestObserver<IAlarmCounters> testObserver = new TestObserver<>();
        AlarmCounters alarmCounters = new AlarmCounters(null, null);
        Subscription subscription = alarmCounters.updates().subscribe(testObserver);
        AlarmCountersMarkableItem first = markable(1);
        AlarmCountersMarkableItem second = markable(2);

        avc(first).dispatch(alarmCounters);
        subscription.unsubscribe();
        avc(second).dispatch(alarmCounters);

        testObserver.assertReceivedOnNext(asList(first));
    }
    
    @Test public void shouldIgnoreNonCountersAVC() throws Exception {
        TestObserver<IAlarmCounters> testObserver = new TestObserver<>();
        AlarmCounters alarmCounters = new AlarmCounters(null, null);
        alarmCounters.updates().subscribe(testObserver);
        IManagedObjectMarkable wrongMarkable = new NEMarkableItem(new NEItem());

        avc(wrongMarkable).dispatch(alarmCounters);

        testObserver.assertReceivedOnNext(emptyList());
    }
    
    @Test public void shouldIgnoreNonAVCNotifications() throws Exception {
        TestObserver<IAlarmCounters> testObserver = new TestObserver<>();
        AlarmCounters alarmCounters = new AlarmCounters(null, null);
        alarmCounters.updates().subscribe(testObserver);

        new ObjectDeletion(new Date(), markable(1)).dispatch(alarmCounters);
        new ObjectCreation(new Date(), markable(2)).dispatch(alarmCounters);

        testObserver.assertReceivedOnNext(emptyList());
    }

    private AttributeValueChange avc(IManagedObjectMarkable markable) {
        return new AttributeValueChange(new Date(), markable);
    }

    private AlarmCountersMarkableItem markable(int id) {
        AlarmCountersItem item = new AlarmCountersItem();
        item.setId(id);
        return new AlarmCountersMarkableItem(item);
    }

}