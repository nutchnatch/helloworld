package com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications;

import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.Configuration.Threshold;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.EmailSender.Message;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.TriggerSettings.Periodic;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications.TriggerSettings.Spontaneous;
import com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics.RunningTotal;
import org.hamcrest.Matcher;
import org.junit.Test;

import java.time.LocalTime;
import java.util.Map;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CRITICAL;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.INDETERMINATE;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MAJOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MINOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.WARNING;
import static com.ossnms.bicnet.reportmanager.server.fm.forwarding.configuration.ImmutableThreshold.threshold;
import static java.time.LocalTime.now;
import static java.util.Collections.emptyMap;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

public class AlarmForwardNotificationTest {
    @Test public void shouldNotContainEmptyPatterns() throws Exception {
        String message = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), emptyMap(), now()).content();

        assertThat(message, not(containsString("{{")));
        assertThat(message, not(containsString("}}")));
    }

    @Test public void shouldContainServerName() throws Exception {
        String server = "TNMS Installation";

        String message = new AlarmForwardNotification(server, new Spontaneous(threshold(WARNING, 0)), emptyMap(), now()).content();

        assertThat(message, containingLine("Server: TNMS Installation"));
    }

    @Test public void shouldContainNotificationTime() throws Exception {
        LocalTime time = LocalTime.of(23, 22, 21);

        String message = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), emptyMap(), time).content();

        assertThat(message, containingLine("Time: 23:22:21"));
    }

    @Test public void shouldContainIndeterminateCounters() throws Exception {
        Map<AlarmSeverity, RunningTotal> statistics = of(INDETERMINATE, new RunningTotal(10, 11, 12));

        String message = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), statistics, now()).content();

        assertThat(message, containingLine("Indeterminate: 10+11+12"));
    }

    @Test public void shouldContainCriticalCounters() throws Exception {
        Map<AlarmSeverity, RunningTotal> statistics = of(CRITICAL, new RunningTotal(1, 2, 3));

        String message = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), statistics, now()).content();

        assertThat(message, containingLine("Critical: 1+2+3"));
    }

    @Test public void shouldContainMajorCounters() throws Exception {
        Map<AlarmSeverity, RunningTotal> statistics = of(MAJOR, new RunningTotal(5, 4, 3));

        String message = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), statistics, now()).content();

        assertThat(message, containingLine("Major: 5+4+3"));
    }


    @Test public void shouldContainMinorCounters() throws Exception {
        Map<AlarmSeverity, RunningTotal> statistics = of(MINOR, new RunningTotal(1, 3, 2));

        String message = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), statistics, now()).content();

        assertThat(message, containingLine("Minor: 1+3+2"));
    }

    @Test public void shouldContainWarningCounters() throws Exception {
        Map<AlarmSeverity, RunningTotal> statistics = of(WARNING, new RunningTotal(0, 2, 10));

        String message = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), statistics, now()).content();

        assertThat(message, containingLine("Warning: 0+2+10"));
    }

    @Test public void shouldBeSpontaneousOnThreshold() throws Exception {

        String message = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), emptyMap(), now()).content();

        assertThat(message, containingLine("Trigger: Spontaneous"));
    }

    @Test public void shouldBePeriodicOnSchedule() throws Exception {
        String message = new AlarmForwardNotification("", new Periodic(""), emptyMap(), now()).content();

        assertThat(message, containingLine("Trigger: Periodic"));
    }

    @Test public void shouldDescribeThresholdTriggerSettings() throws Exception {
        Threshold threshold = threshold(MAJOR, 13);

        String message = new AlarmForwardNotification("", new Spontaneous(threshold), emptyMap(), now()).content();

        assertThat(message, containingLine("Settings: 13 alarms of severity Major or higher"));
    }


    @Test public void fullMessageTest() throws Exception {
        String server = "server name";
        LocalTime time = LocalTime.of(19, 27, 13);
        Threshold threshold = threshold(WARNING, 11);
        Map<AlarmSeverity, RunningTotal> statistics = of(
                WARNING, new RunningTotal(1, 2, 3),
                MAJOR, new RunningTotal(10, 0, 0));

        AlarmForwardNotification notification = new AlarmForwardNotification(server, new Spontaneous(threshold), statistics, time);

        assertThat(notification.subject(), is("Alarm Report"));
        assertThat(notification.content(), is("Server: server name\n" +
                "Time: 19:27:13\n" +
                "Trigger: Spontaneous\n" +
                "Settings: 11 alarms of severity Warning or higher\n" +
                "Indeterminate: 0+0+0\n" +
                "Critical: 0+0+0\n" +
                "Major: 10+0+0\n" +
                "Minor: 0+0+0\n" +
                "Warning: 1+2+3\n"));
    }

    @Test public void shouldReadOnlyOneMessage() throws Exception {
        ItemReader<Message> reader = new AlarmForwardNotification("", new Spontaneous(threshold(WARNING, 0)), emptyMap(), now());

        reader.open();

        assertThat(reader.readItem(), is(notNullValue()));
        assertThat(reader.readItem(), is(nullValue()));
    }

    private Matcher<String> containingLine(String text) {
        return containsString(text + "\n");
    }

}