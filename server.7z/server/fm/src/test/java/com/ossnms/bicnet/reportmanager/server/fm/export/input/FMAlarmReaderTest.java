package com.ossnms.bicnet.reportmanager.server.fm.export.input;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.List;
import java.util.Queue;
import java.util.stream.IntStream;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmLogRecordItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogRecordIterator;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;

public class FMAlarmReaderTest {
    @Test public void readAll() throws Exception {
        ISessionContext context = mock(ISessionContext.class);
        ILogRecordFilter filter = mock(ILogRecordFilter.class);
        AlarmLogRecordItem item = new AlarmLogRecordItem();
        AlarmLogRecordItem item2 = new AlarmLogRecordItem();

        IFaultMgrFacade fmManager = mock(IFaultMgrFacade.class);
        when(fmManager.getLogRecords(context, filter, true, true)).thenReturn(new LogsItererator(asList(item, item2)));

        FMAlarmReader reader = new FMAlarmReader(context, fmManager, filter);


        List<ILogRecord> records = reader.read().collect(toList());


        assertThat(records, contains(item, item2));
    }

    @Test public void readItem() throws Exception {
        ISessionContext context = mock(ISessionContext.class);
        ILogRecordFilter filter = mock(ILogRecordFilter.class);
        AlarmLogRecordItem item = new AlarmLogRecordItem();
        AlarmLogRecordItem item2 = new AlarmLogRecordItem();

        IFaultMgrFacade fmManager = mock(IFaultMgrFacade.class);
        when(fmManager.getLogRecords(context, filter, true, true)).thenReturn(new LogsItererator(asList(item, item2)));

        FMAlarmReader reader = new FMAlarmReader(context, fmManager, filter);


        reader.open();
        assertThat(reader.readItem(), is(item));
        assertThat(reader.readItem(), is(item2));
        assertThat(reader.readItem(), nullValue());
    }

    class LogsItererator implements ILogRecordIterator {

        private final Queue<ILogRecord> items;

        LogsItererator(Collection<ILogRecord> items) {
            this.items = new ArrayDeque<>(items);
        }

        @Override public ILogRecord[] getNext(ISessionContext sessionContext, int howMany) throws BcbException {
            return IntStream.range(0, Math.min(items.size(), howMany))
                    .mapToObj(i -> items.poll())
                    .toArray(ILogRecord[]::new);
        }

        @Override public int getPos(ISessionContext sessionContext) throws BcbException {
            return 0;
        }

        @Override public int getSize(ISessionContext sessionContext) throws BcbException {
            return items.size();
        }

        @Override public void move(ISessionContext sessionContext, int howMany) throws BcbException {

        }

        @Override public boolean hasNext(ISessionContext sessionContext) throws BcbException {
            return !items.isEmpty();
        }

        @Override public int getPageSize(ISessionContext sessionContext) throws BcbException {
            return 0;
        }

        @Override public void close(ISessionContext sessionContext) throws BcbException {

        }

        @Override public boolean isSortApplied() throws BcbException {
            return false;
        }

        @Override public int getTotalSize() throws BcbException {
            return 0;
        }

        @Override public int getFilteredSize() {
            return 0;
        }

        @Override public boolean isTruncated() {
            return false;
        }

        @Override public ILogRecordFilter getLogRecordFilter() {
            return null;
        }
    }
}