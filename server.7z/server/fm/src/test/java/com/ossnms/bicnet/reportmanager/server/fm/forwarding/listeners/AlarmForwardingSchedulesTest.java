package com.ossnms.bicnet.reportmanager.server.fm.forwarding.listeners;

import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import org.junit.Test;
import rx.observers.TestObserver;

import java.util.Arrays;

import static com.ossnms.bicnet.reportmanager.util.Constants.ACTION_TYPE_REPORT_EXECUTION;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARM_MESSAGING_REPORT;
import static java.util.Collections.emptyList;

public class AlarmForwardingSchedulesTest {
    @Test public void shouldPublishReceivedSchedules() throws Exception {
        AlarmForwardingSchedules alarmForwardingSchedules = new AlarmForwardingSchedules();
        TestObserver<ScheduleExecution> testObserver = new TestObserver<>();
        ScheduleExecution scheduleExecution = execution(ALARM_MESSAGING_REPORT);

        alarmForwardingSchedules.executions().subscribe(testObserver);
        alarmForwardingSchedules.onScheduleExecution(scheduleExecution);

        testObserver.assertReceivedOnNext(Arrays.asList(scheduleExecution));
    }

    @Test public void shouldIgnoreSchedulesForWrongActionType() throws Exception {
        AlarmForwardingSchedules alarmForwardingSchedules = new AlarmForwardingSchedules();
        TestObserver<ScheduleExecution> testObserver = new TestObserver<>();
        ScheduleExecution scheduleExecution = execution("wrong action");

        alarmForwardingSchedules.executions().subscribe(testObserver);
        alarmForwardingSchedules.onScheduleExecution(scheduleExecution);

        testObserver.assertReceivedOnNext(emptyList());
    }

    private ScheduleExecution execution(String actionParam) {
        ScheduleExecution scheduleExecution = new ScheduleExecution();
        scheduleExecution.setActionType(ACTION_TYPE_REPORT_EXECUTION);
        scheduleExecution.setActionParameter(actionParam);
        return scheduleExecution;
    }
}