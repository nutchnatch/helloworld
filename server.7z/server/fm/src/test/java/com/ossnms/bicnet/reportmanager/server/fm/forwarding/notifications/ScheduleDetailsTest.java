package com.ossnms.bicnet.reportmanager.server.fm.forwarding.notifications;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.common.DayOfMonth;
import com.ossnms.bicnet.bcb.model.common.DayOfWeek;
import com.ossnms.bicnet.bcb.model.common.DaysOfMonth;
import com.ossnms.bicnet.bcb.model.common.DaysOfWeek;
import org.junit.Test;

import java.util.stream.IntStream;

import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.MONTHLY;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.USER_DEFINED;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.WEEKLY;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class ScheduleDetailsTest {

    @Test public void shouldDescribePeriodicScheduleSetting() throws Exception {
        int days = 1440;
        int hours = 60;
        ScheduleItem schedule = schedulePeriodic(2 * days + 3 * hours);
        ScheduleItem everyHour = schedulePeriodic(1 * hours);
        ScheduleItem everyDay = schedulePeriodic(1 * days);

        String message = new ScheduleDetails(schedule).settings();
        String messageHourly = new ScheduleDetails(everyHour).settings();
        String messageDaily = new ScheduleDetails(everyDay).settings();

        assertThat(message, is("Periodic, 2 days and 3 hours"));
        assertThat(messageHourly, is("Periodic, 0 days and 1 hours"));
        assertThat(messageDaily, is("Periodic, 1 days and 0 hours"));
    }

    @Test public void shouldDescribeWeeklyScheduleSettings() throws Exception {
        ScheduleItem scheduleAll = scheduleWeekly(DayOfWeek.getAllValues().stream().toArray(DayOfWeek[]::new));
        ScheduleItem scheduleNone = scheduleWeekly();
        ScheduleItem scheduleSome = scheduleWeekly(DayOfWeek.TUESDAY);

        String messageAll = new ScheduleDetails(scheduleAll).settings();
        String messageNone = new ScheduleDetails(scheduleNone).settings();
        String messageSome = new ScheduleDetails(scheduleSome).settings();

        assertThat(messageAll, is("Weekly, [monday, tuesday, wednesday, thursday, friday, saturday, sunday]"));
        assertThat(messageNone, is("Weekly, []"));
        assertThat(messageSome, is("Weekly, [tuesday]"));
    }


    @Test public void shouldDescribeMonthlyScheduleSettings() throws Exception {
        ScheduleItem scheduleAll = scheduleMonthly(IntStream.range(1, 32).mapToObj(DayOfMonth::fromOrdinal).toArray(DayOfMonth[]::new));
        ScheduleItem scheduleNone = scheduleMonthly();
        ScheduleItem scheduleSome = scheduleMonthly(DayOfMonth.FIFTH, DayOfMonth.NINTH);

        String messageAll = new ScheduleDetails(scheduleAll).settings();
        String messageNone = new ScheduleDetails(scheduleNone).settings();
        String messageSome = new ScheduleDetails(scheduleSome).settings();

        assertThat(messageAll, is("Monthly, [first, second, third, fourth, fifth, sixth, seventh, eighth, ninth, tenth, eleventh, twelfth, thirteenth, fourteenth, fifteenth, sixteenth, seventeenth, eighteenth, nineteenth, twentieth, twentyfirst, twentysecond, twentythird, twentyfourth, twentyfifth, twentysixth, twentyseventh, twentyeighth, twentyninth, thirtieth, thirtyfirst]"));
        assertThat(messageNone, is("Monthly, []"));
        assertThat(messageSome, is("Monthly, [fifth, ninth]"));
    }


    private ScheduleItem schedulePeriodic(int userPeriod) {
        ScheduleItem scheduleItem = new ScheduleItem();
        scheduleItem.setPeriod(USER_DEFINED);
        scheduleItem.setUserPeriod(userPeriod);
        return scheduleItem;
    }

    private ScheduleItem scheduleWeekly(DayOfWeek... days) {
        ScheduleItem scheduleItem = new ScheduleItem();
        scheduleItem.setPeriod(WEEKLY);
        scheduleItem.setWeeklyDays(DaysOfWeek.of(days));
        return scheduleItem;
    }

    private ScheduleItem scheduleMonthly(DayOfMonth... days) {
        ScheduleItem scheduleItem = new ScheduleItem();
        scheduleItem.setPeriod(MONTHLY);
        scheduleItem.setMonthlyDays(DaysOfMonth.of(days));
        return scheduleItem;
    }
}