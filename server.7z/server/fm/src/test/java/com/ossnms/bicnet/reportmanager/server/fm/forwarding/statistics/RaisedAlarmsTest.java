package com.ossnms.bicnet.reportmanager.server.fm.forwarding.statistics;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmCount;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import org.junit.Test;

import java.util.Map;

import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CRITICAL;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.INDETERMINATE;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MAJOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MINOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.WARNING;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

public class RaisedAlarmsTest {
    @Test public void shouldExtractRaisedAlarms() throws Exception {
        IAlarmCounters counters = new AlarmCountersItem();
        counters.setWarning(count(12));
        counters.setMinor(count(3));
        counters.setMajor(count(5));
        counters.setCritical(count(7));
        counters.setIndeterminate(count(10));

        Map<AlarmSeverity, Integer> alarms = RaisedAlarms.fromCounters(counters);

        assertThat(alarms, hasEntry(WARNING, 12));
        assertThat(alarms, hasEntry(MINOR, 3));
        assertThat(alarms, hasEntry(MAJOR, 5));
        assertThat(alarms, hasEntry(CRITICAL, 7));
        assertThat(alarms, hasEntry(INDETERMINATE, 10));
        assertThat(alarms.keySet(), hasSize(5));
    }
    
    @Test public void shouldIgnoreEmpty() throws Exception {
        IAlarmCounters counters = new AlarmCountersItem();
        counters.setWarning(count(12));

        Map<AlarmSeverity, Integer> alarms = RaisedAlarms.fromCounters(counters);

        assertThat(alarms, hasEntry(WARNING, 12));
        assertThat(alarms.keySet(), hasSize(1));
    
    }

    private AlarmCount count(int total) {
        return new AlarmCount(total, 0);
    }
}