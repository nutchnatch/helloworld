package com.ossnms.bicnet.reportmanager.dcn.transform;

import static com.ossnms.bicnet.reportmanager.dcn.transform.PropertyToJaxb.properties;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collector;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportChannel;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Channel;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.EMs;

public class ChannelToJaxbEm implements Function<ExportChannel, Channel> {
    @Override public Channel apply(ExportChannel exportChannel) {
        Channel em = new Channel();
        em.setIDName(exportChannel.getIdName());
        em.setType(exportChannel.getType());
        em.getProperty().addAll(properties(exportChannel.getProperties()));
        em.setConcurrentActivationsLimit(exportChannel.getConcurrentActivationsLimit());
        em.setConcurrentActivationsLimited(exportChannel.getConcurrentActivationsLimited());
        em.setMediatorName(exportChannel.getMediator());
        return em;
    }

    public static Collector<Channel, ?, EMs> toEMs() {
        return collectingAndThen(toList(), ChannelToJaxbEm::ems);
    }

    private static EMs ems(Collection<Channel> channels) {
        EMs result = new EMs();
        result.getEM().addAll(channels);
        return result;
    }
}
