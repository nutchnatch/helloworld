package com.ossnms.bicnet.reportmanager.dcn.read;

import static java.util.Arrays.stream;

import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IDcnExportFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ChannelsReply;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportChannel;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class ExportChannelsReader extends BcbReplyReader<Integer, ExportChannel, ChannelsReply> {

    private final ISessionContext context;
    private final IDcnExportFacade dcn;

    @Inject public ExportChannelsReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcn) {
        this.dcn = dcn;
        this.context = context;
    }

    @Override protected ExportChannel[] data(ChannelsReply reply) {
        return reply.getData();
    }

    @Override protected ChannelsReply nextReply(Integer lastId) throws BcbException {
        return dcn.getExportChannels(context, lastId == null ? 0 : lastId, 100);
    }

    @Override protected Integer lastId(ChannelsReply channelsReply) {
        return stream(channelsReply.getData())
                .map(ExportChannel::getChannelId)
                .filter(id -> id > 0)
                .max(Integer::compare)
                .orElse(0);
    }

    @Override protected boolean isLast(ChannelsReply channelsReply) {
        return channelsReply.getEof();
    }
}
