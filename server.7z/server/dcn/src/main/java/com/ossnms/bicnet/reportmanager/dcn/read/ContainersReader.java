package com.ossnms.bicnet.reportmanager.dcn.read;

import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;

import java.util.Optional;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class ContainersReader extends BcbReplyReader<IGenericContainerId, IGenericContainer, GenericContainerReply> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContainersReader.class);

    private final ISessionContext context;
    private final IEMObjectMgrFacade dcnManager;

    @Inject public ContainersReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcnManager) {
        this.context = context;
        this.dcnManager = dcnManager;
    }

    public Optional<String> containerName(IGenericContainerId containerId) {
        try {
            // to improve: cache previously fetched container
            return ofNullable(dcnManager.getSingleGenericContainer(context, containerId))
                    .map(IGenericContainer::getIdName);
        } catch (BcbException e) {
            LOGGER.error("Failed to get container from dcn manager", e);
            return empty();
        }
    }

    @Override
    protected GenericContainerReply nextReply(IGenericContainerId lastId) throws BcbException {
        return dcnManager.getGenericContainerList(context, lastId, null, 500);
    }

    @Override protected IGenericContainer[] data(GenericContainerReply reply) {
        return reply.getData();
    }

    @Override protected IGenericContainerId lastId(GenericContainerReply reply) {
        return reply.getLastReadId();
    }

    @Override protected boolean isLast(GenericContainerReply genericContainerReply) {
        return genericContainerReply.endOfFile();
    }
}
