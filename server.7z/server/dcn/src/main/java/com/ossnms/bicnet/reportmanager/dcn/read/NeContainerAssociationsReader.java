package com.ossnms.bicnet.reportmanager.dcn.read;

import static com.ossnms.bicnet.reportmanager.dcn.values.ImmutableAssignment.of;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentMarkable;
import com.ossnms.bicnet.reportmanager.dcn.values.Assignment;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class NeContainerAssociationsReader extends BcbReplyReader<INeGenericContainerAssignmentId, INeGenericContainerAssignment, NeGenericContainerAssignmentReply> {
    private final ISessionContext context;
    private final IEMObjectMgrFacade dcnManager;
    private final ContainersReader containersReader;
    private final INeGenericContainerAssignmentMarkable[] filters;

    @Inject
    public NeContainerAssociationsReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcnManager, ContainersReader containersReader){
        this(context, dcnManager, containersReader, null);
    }
    
    public NeContainerAssociationsReader(ISessionContext context, IEMObjectMgrFacade dcnManager, ContainersReader containersReader, INeGenericContainerAssignmentMarkable[] filters) {
        this.context = context;
        this.dcnManager = dcnManager;
        this.containersReader = containersReader;
        this.filters = ArrayUtils.clone(filters);
    }

    public Collection<Assignment> assignments(INEId neId) {
        return fetchAssignments(neId)
                .map(this::toValue)
                .flatMap(opt -> opt.map(Stream::of).orElseGet(Stream::empty))
                .collect(toList());
    }

    private Optional<Assignment> toValue(INeGenericContainerAssignment assignment) {
        return containersReader.containerName(assignment.getGenericContainer())
                .map(container -> of(container, assignment.getPrimary()));
    }

    private Stream<INeGenericContainerAssignment> fetchAssignments(INEId neId) {
        INeGenericContainerAssignmentMarkable byNeId = (INeGenericContainerAssignmentMarkable) new NeGenericContainerAssignmentItem().toMarkable();
        byNeId.setNetworkElementId(neId.getId());
        INeGenericContainerAssignmentMarkable[] filter = {byNeId};

        return new NeContainerAssociationsReader(context, dcnManager, containersReader, filter).read();
    }

    @Override
    protected NeGenericContainerAssignmentReply nextReply(INeGenericContainerAssignmentId lastId) throws BcbException {
        return dcnManager.getNeGenericContainerAssignmentList(context, lastId, filters, 500);
    }

    @Override protected INeGenericContainerAssignment[] data(NeGenericContainerAssignmentReply reply) {
        return reply.getData();
    }

    @Override protected INeGenericContainerAssignmentId lastId(NeGenericContainerAssignmentReply reply) {
        return reply.getLastReadId();
    }

    @Override protected boolean isLast(NeGenericContainerAssignmentReply neGenericContainerAssignmentReply) {
        return neGenericContainerAssignmentReply.endOfFile();
    }
}
