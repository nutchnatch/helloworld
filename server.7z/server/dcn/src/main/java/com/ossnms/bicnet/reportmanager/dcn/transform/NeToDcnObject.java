package com.ossnms.bicnet.reportmanager.dcn.transform;

import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.DISABLED;
import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.ENABLED;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableAlarm.alarm;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableNE.builder;
import static java.util.Optional.ofNullable;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.reportmanager.dto.DcnObject.Alarm;
import com.ossnms.bicnet.reportmanager.dto.DcnObject.NE;

public class NeToDcnObject implements Function<INE, NE> {

    private final Map<INEId, IAlarmCounters> severities;
    private final Map<ISystemContainerId, String> systemNames;

    public NeToDcnObject(Map<INEId, IAlarmCounters> severities, Map<ISystemContainerId, String> systemNames) {
        this.severities = severities;
        this.systemNames = systemNames;
    }

    @Override public NE apply(INE ne) {
        return builder()
                .name(ne.getIdName())
                .address(ne.getDisplayAddress())
                .state(ne.getDisplayState())
                .neId(ne.getId())
                .neName(ofNullable(ne.getRealNeName()))
                .alarm(getAlarm(ne))
                .channelId(ne.getAssociatedEmId())
                .maintenanceState(negate(ne.getEventForwarding()))
                .operationalState(ne.getOperationalState())
                .systemId(ne.getAssociatedSystemContainerId())
                .systemName(getSystemName(ne))
                .build();
    }

    private Optional<String> getSystemName(INE ne) {
        return ofNullable(systemNames.get(ne.getAssociatedSystemContainer()));
    }

    private Optional<Alarm> getAlarm(INE ne) {
        return ofNullable(severities.get(ne))
                .map(counter -> alarm(counter.getSeverity(), counter.getIsAcknowledged()));
    }

    private static EnableSwitch negate(EnableSwitch aSwitch) {
        return Objects.equals(ENABLED, aSwitch) ? DISABLED : ENABLED;
    }

}
