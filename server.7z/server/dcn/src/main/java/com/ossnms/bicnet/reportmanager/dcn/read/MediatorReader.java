package com.ossnms.bicnet.reportmanager.dcn.read;

import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class MediatorReader extends BcbReplyReader<IMediatorId, IMediator, MediatorReply> {

    private final ISessionContext context;
    private final IEMObjectMgrFacade dcnManager;

    @Inject public MediatorReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcnManager) {
        this.context = context;
        this.dcnManager = dcnManager;
    }

    @Override
    protected MediatorReply nextReply(IMediatorId lastId) throws BcbException {
        return dcnManager.getMediatorList(context, lastId, null, 100);
    }

    @Override protected IMediator[] data(MediatorReply reply) {
        return reply.getData();
    }

    @Override protected IMediatorId lastId(MediatorReply reply) {
        return reply.getLastReadId();
    }

    @Override protected boolean isLast(MediatorReply mediatorReply) {
        return mediatorReply.endOfFile();
    }
}
