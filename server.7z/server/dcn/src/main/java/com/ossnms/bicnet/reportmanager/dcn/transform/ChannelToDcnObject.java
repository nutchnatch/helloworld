package com.ossnms.bicnet.reportmanager.dcn.transform;

import static com.ossnms.bicnet.reportmanager.dto.ImmutableChannel.channel;

import java.util.function.Function;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.reportmanager.dto.DcnObject.Channel;

public class ChannelToDcnObject implements Function<IEM, Channel> {
    @Override public Channel apply(IEM em) {
        return channel(em.getIdName(), em.getDisplayAddress(), em.getDisplayState());
    }
}
