package com.ossnms.bicnet.reportmanager.dcn.transform;

import static com.ossnms.bicnet.reportmanager.dcn.transform.PropertyToJaxb.properties;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collector;

import com.ossnms.bicnet.bcb.model.emObjMgmt.TaxonomyNeType;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.DcnAttributes;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.NEs;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.NeTypeTaxonomy;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.NetworkElement;
import com.ossnms.bicnet.reportmanager.dcn.values.FullNe;
import com.ossnms.bicnet.reportmanager.dcn.values.NeAdditionalInfo;

public class NeToJaxbNe implements Function<FullNe, NetworkElement> {

    @Override public NetworkElement apply(FullNe fullNe) {
        NetworkElement ne = new NetworkElement();

        ne.setIDName(fullNe.ne().getIdName());
        ne.setType(fullNe.ne().getType());
        ne.setParentEM(fullNe.ne().getChannel());
        ne.setSystemContainer(fullNe.system().orElse(null));
        ne.getAssignedContainer().addAll(AssignmentToJaxb.toJaxb(fullNe.assignments()));
        ne.getProperty().addAll(properties(fullNe.ne().getProperties()));

        ofNullable(fullNe.ne().getNeTypeTaxonomy())
                .map(this::taxonomy)
                .ifPresent(ne::setNeTypeTaxonomy);

        ne.setDcnAttributes(fullNe.neAdditionalInfo().map(this::dcnAttributes).orElseGet(DcnAttributes::new));
        ne.setMountMode(fullNe.neAdditionalInfo().flatMap(NeAdditionalInfo::getMountMode).orElse(""));
        ne.setNeSoftwareVersion(fullNe.neAdditionalInfo().flatMap(NeAdditionalInfo::getNeSwVersion).orElse(""));

        return ne;
    }

    private DcnAttributes dcnAttributes(NeAdditionalInfo neInfo) {
        DcnAttributes dcnAttributes = new DcnAttributes();

        dcnAttributes.setLocalInterface(neInfo.getLocalInterface().orElse(""));
        dcnAttributes.setLocalInterfaceMask(neInfo.getLocalInterfaceMask().orElse(""));
        dcnAttributes.setRouterInterface(neInfo.getRouterInterface().orElse(""));
        dcnAttributes.setRouterInterfaceMask(neInfo.getRouterInterfaceMask().orElse(""));
        dcnAttributes.setDcnInterface(neInfo.getDcnInterface().orElse(""));
        dcnAttributes.setDcnInterfaceMask(neInfo.getDcnInterfaceMask().orElse(""));
        dcnAttributes.setManagementInterface(neInfo.getManagementInterface().orElse(""));
        dcnAttributes.setManagementInterfaceMask(neInfo.getManagementInterfaceMask().orElse(""));
        dcnAttributes.setEonType(neInfo.getEonType().orElse(""));
        dcnAttributes.setGateway(neInfo.getGateway().orElse(""));

        return dcnAttributes;
    }

    private NeTypeTaxonomy taxonomy(TaxonomyNeType neTypeTaxonomy) {
        NeTypeTaxonomy taxonomy = new NeTypeTaxonomy();
        taxonomy.setNeFamilyLabel(neTypeTaxonomy.getNeFamilyLabel());
        taxonomy.setNeSubTypeLabel(neTypeTaxonomy.getNeSubTypeLabel());
        taxonomy.setNeTypeLabel(neTypeTaxonomy.getNeTypeLabel());
        return taxonomy;
    }

    public static Collector<NetworkElement, ?, NEs> toNEs() {
        return collectingAndThen(toList(), NeToJaxbNe::nes);
    }

    private static NEs nes(Collection<NetworkElement> nes) {
        NEs result = new NEs();
        result.getNE().addAll(nes);
        return result;
    }
}
