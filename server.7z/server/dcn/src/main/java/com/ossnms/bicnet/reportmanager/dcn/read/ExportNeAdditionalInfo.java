package com.ossnms.bicnet.reportmanager.dcn.read;

import static com.ossnms.bicnet.reportmanager.dcn.values.ImmutableNeAdditionalInfo.builder;
import static java.util.Arrays.stream;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toMap;

import java.util.Map;
import java.util.Optional;

import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementReply;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.EnumBase;
import com.ossnms.bicnet.bcb.model.elementMgmt.ApsDescription;
import com.ossnms.bicnet.bcb.model.elementMgmt.ApsDetails;
import com.ossnms.bicnet.bcb.model.elementMgmt.EonType;
import com.ossnms.bicnet.bcb.model.elementMgmt.IMTera7100NetworkPropertiesFacet;
import com.ossnms.bicnet.bcb.model.elementMgmt.IManagementInterfaceFacet;
import com.ossnms.bicnet.bcb.model.elementMgmt.IMountDetailsPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElement;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementId;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.ISoftwareManager;
import com.ossnms.bicnet.bcb.model.elementMgmt.IpNetworkAddress;
import com.ossnms.bicnet.bcb.model.elementMgmt.MemoryBankDetails;
import com.ossnms.bicnet.bcb.model.elementMgmt.MountDirection;
import com.ossnms.bicnet.reportmanager.dcn.values.NeAdditionalInfo;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public final class ExportNeAdditionalInfo extends BcbReplyReader<INetworkElementId, INetworkElement, NetworkElementReply> {

    private static final INetworkElementMarkable[] EMPTY_FILTER = {NetworkElementItem.markableNetworkElement(null)};

    private final ISessionContext context;
    private final INetworkDataManagerFacade networkManager;
    private final INetworkElementMarkable[] filter = EMPTY_FILTER;

    @Inject
    public ExportNeAdditionalInfo(@BiCNet ISessionContext context, @BiCNet INetworkDataManagerFacade networkManager) {
        this.context = context;
        this.networkManager = networkManager;
    }

    public Map<Integer, NeAdditionalInfo> getExportNeAdditionalInfo() {
        return read()
                .filter(ExportNeAdditionalInfo::hasAdditionalInfoFacets)
                .collect(toMap(INetworkElement::getNeId, ExportNeAdditionalInfo::buildNeAdditionalInfo));
    }

    private static boolean hasAdditionalInfoFacets(INetworkElement ne) {
        return ne.hasFacette(IMTera7100NetworkPropertiesFacet.class)
                || ne.hasFacette(IManagementInterfaceFacet.class)
                || ne.hasFacette(IMountDetailsPkg.class)
                || ne.hasFacette(ISoftwareManager.class);
    }

    private static NeAdditionalInfo buildNeAdditionalInfo(INetworkElement ne) {

        Optional<IMTera7100NetworkPropertiesFacet> networkProperties = ofNullable(ne.getFacette(IMTera7100NetworkPropertiesFacet.class))
                .map(IMTera7100NetworkPropertiesFacet.class::cast);

        Optional<IpNetworkAddress> routeInterface = networkProperties.map(IMTera7100NetworkPropertiesFacet::getRouterInterface);
        Optional<IpNetworkAddress> dcnInterface = networkProperties.map(IMTera7100NetworkPropertiesFacet::getDcnInterface);

        Optional<EonType> eonType = networkProperties.map(IMTera7100NetworkPropertiesFacet::getEonType);

        Optional<IpNetworkAddress> managementInterface = ofNullable(ne.getFacette(IManagementInterfaceFacet.class))
                .map(IManagementInterfaceFacet.class::cast)
                .map(IManagementInterfaceFacet::getManagementInterface);

        Optional<MountDirection> mountDirection = ofNullable(ne.getFacette(IMountDetailsPkg.class))
                .map(IMountDetailsPkg.class::cast)
                .map(IMountDetailsPkg::getDirection);

        Optional<ApsDetails> apsDetails = ofNullable(ne.getFacette(ISoftwareManager.class))
                .map(ISoftwareManager.class::cast)
                .map(ISoftwareManager::getApsList)
                .flatMap(apsList -> stream(apsList).findFirst());

        Optional<String> neSwVersion = apsDetails.map(ApsDetails::getMemoryBank)
                .map(MemoryBankDetails::getApsDescription)
                .map(ApsDescription::getVersion);

        return builder()
                .eonType(eonType.map(EnumBase::name))
                .managementInterface(managementInterface.map(IpNetworkAddress::getAddress))
                .managementInterfaceMask(managementInterface.map(IpNetworkAddress::getMask))
                .routerInterface(routeInterface.map(IpNetworkAddress::getAddress))
                .routerInterfaceMask(routeInterface.map(IpNetworkAddress::getMask))
                .dcnInterface(dcnInterface.map(IpNetworkAddress::getAddress))
                .dcnInterfaceMask(dcnInterface.map(IpNetworkAddress::getMask))
                .gateway(networkProperties.map(IMTera7100NetworkPropertiesFacet::getGateway))
                .mountMode(mountDirection.map(EnumBase::name))
                .neSwVersion(neSwVersion)
                .build();
    }

    @Override
    protected NetworkElementReply nextReply(INetworkElementId lastId) throws BcbException {
        return networkManager.getNetworkElementList(context, lastId, filter, 500);
    }

    @Override protected INetworkElement[] data(NetworkElementReply networkElementReply) {
        return networkElementReply.getData();
    }

    @Override protected INetworkElementId lastId(NetworkElementReply networkElementReply) {
        return networkElementReply.getLastReadId();
    }

    @Override protected boolean isLast(NetworkElementReply networkElementReply) {
        return networkElementReply.endOfFile();
    }
}
