package com.ossnms.bicnet.reportmanager.dcn.transform;

import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.ContainerAssignment;
import com.ossnms.bicnet.reportmanager.dcn.values.Assignment;

import java.util.Collection;

import static java.util.stream.Collectors.toList;

final class AssignmentToJaxb {

    private AssignmentToJaxb() {
    }

    static Collection<ContainerAssignment> toJaxb(Collection<Assignment> assignments) {
        return assignments.stream()
                .map(AssignmentToJaxb::toJaxb)
                .collect(toList());
    }

    private static ContainerAssignment toJaxb(Assignment assignment) {
        ContainerAssignment containerAssignment = new ContainerAssignment();
        containerAssignment.setIsPrimary(assignment.isPrimary());
        containerAssignment.setIDName(assignment.name());
        return containerAssignment;
    }
}
