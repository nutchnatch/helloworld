package com.ossnms.bicnet.reportmanager.dcn.transform;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collector;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.GenericContainer;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.GenericContainers;
import com.ossnms.bicnet.reportmanager.dcn.read.ContainersReader;

public class ContainerToJaxb implements Function<IGenericContainer, GenericContainer> {

    private static final int ROOT_CONTAINER = 0;
    private final ContainersReader containersReader;

    public ContainerToJaxb(ContainersReader containersReader) {
        this.containersReader = containersReader;
    }

    @Override public GenericContainer apply(IGenericContainer container) {
        GenericContainer genericContainer = new GenericContainer();
        genericContainer.setIDName(container.getIdName());
        genericContainer.setDescription(container.getDescription());
        genericContainer.setUserText(container.getUserLabel());
        if (container.getId() != ROOT_CONTAINER) { //don't add parent container for Root
            containersReader.containerName(container.getParent())
                    .ifPresent(genericContainer::setParentContainer);
        }
        return genericContainer;
    }

    public static Collector<GenericContainer, ?, GenericContainers> toGenericContainers() {
        return collectingAndThen(toList(), ContainerToJaxb::containers);
    }

    private static GenericContainers containers(Collection<GenericContainer> containers) {
        GenericContainers result = new GenericContainers();
        result.getGenericContainer().addAll(containers);
        return result;
    }
}
