package com.ossnms.bicnet.reportmanager.dcn.read;

import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toMap;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INamedObjectPkg;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class SystemReader extends BcbReplyReader<ISystemContainerId, ISystemContainer, SystemContainerReply> {
    private static final Logger LOGGER = LoggerFactory.getLogger(SystemReader.class);
    private static final ISystemContainerId NOT_A_SYSTEM = new SystemContainerIdItem(0);

    private final ISessionContext context;
    private final IEMObjectMgrFacade dcnManager;

    @Inject public SystemReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcnManager) {
        this.context = context;
        this.dcnManager = dcnManager;
    }

    public Optional<String> resolveSystemName(ISystemContainerId systemId) {
        if (Objects.equals(NOT_A_SYSTEM, systemId)) {
            return empty();
        }
        try {
            // to improve: cache already fetched systems
            return ofNullable(dcnManager.getSingleSystemContainer(context, systemId))
                    .map(ISystemContainer::getIdName);
        } catch (BcbException e) {
            LOGGER.error("Failed to fetch system container {} from dcn manager", systemId, e);
            return empty();
        }
    }

    @Override protected ISystemContainer[] data(SystemContainerReply reply) {
        return reply.getData();
    }

    @Override
    protected SystemContainerReply nextReply(ISystemContainerId lastId) throws BcbException {
        return dcnManager.getSystemContainerList(context, lastId, null, 500);
    }

    @Override protected ISystemContainerId lastId(SystemContainerReply reply) {
        return reply.getLastReadId();
    }

    @Override protected boolean isLast(SystemContainerReply reply) {
        return reply.endOfFile();
    }

    public Map<ISystemContainerId, String> getSystemNames() {
        return read().collect(toMap(s -> s, INamedObjectPkg::getIdName));
    }
}
