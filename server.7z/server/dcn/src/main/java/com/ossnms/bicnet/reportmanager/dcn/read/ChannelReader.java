package com.ossnms.bicnet.reportmanager.dcn.read;

import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class ChannelReader extends BcbReplyReader<IEMId, IEM, EMReply> {

    private final IEMObjectMgrFacade dcnManager;
    private final ISessionContext context;

    @Inject public ChannelReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcnManager) {
        this.dcnManager = dcnManager;
        this.context = context;
    }

    @Override protected EMReply nextReply(IEMId lastId) throws BcbException {
        return dcnManager.getEMList(context, lastId, null, 500);
    }

    @Override protected IEM[] data(EMReply reply) {
        return reply.getData();
    }

    @Override protected IEMId lastId(EMReply reply) {
        return reply.getLastReadId();
    }

    @Override protected boolean isLast(EMReply emReply) {
        return emReply.endOfFile();
    }
}
