package com.ossnms.bicnet.reportmanager.dcn.runtime;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.EMs;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.GenericContainers;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Mediators;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.NEs;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.SystemContainers;
import com.ossnms.bicnet.reportmanager.server.runtime.IExportReadExecution;

import javax.ejb.Asynchronous;
import java.util.concurrent.Future;

public interface IDcnExportReadExecution extends IExportReadExecution {

    @Asynchronous Future<Mediators> fetchMediators() throws BcbException;

    @Asynchronous Future<EMs> fetchChannels() throws BcbException;

    @Asynchronous Future<NEs> fetchNEs() throws BcbException;

    @Asynchronous Future<GenericContainers> fetchContainers();

    @Asynchronous Future<SystemContainers> fetchSystems();
}
