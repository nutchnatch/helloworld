package com.ossnms.bicnet.reportmanager.dcn.messaging.input;

import java.util.Collection;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.EMs;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Mediators;
import com.ossnms.bicnet.reportmanager.dcn.runtime.IDcnExportReadExecution;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.servicelocator.BeanUtils;
import com.ossnms.bicnet.reportmanager.util.Constants;

public class DcnItemExecution extends ItemExecution {

    private final Iterable<IReaderBuilder> readers;

    public DcnItemExecution(Iterable<IReaderBuilder> readers){
        this.readers = readers;
    }

    @Override
    public List<Object> executeItem() throws BcbException {

        List<Object> itemsToBeExported = processReaders(readers);

        Mediators[] mediators = getMediators(itemsToBeExported);

        EMs[] channels = getChannels(itemsToBeExported);

        setChannelMediator(mediators[0], channels[0]);

        return itemsToBeExported;
    }

    private void setChannelMediator(Mediators mediator, EMs channel) {
        channel.getEM().stream()
                .map(currentChannel -> {
                    mediator.getMediator().stream()
                            .filter(currentMediator -> currentMediator.getIDName().equals(currentChannel.getMediatorName()))
                            .map(currentMediator -> {
                                currentChannel.setMediator(currentMediator);
                                return currentMediator;
                            }).toArray();
                    return currentChannel;
                })
                .toArray();
    }

    private EMs[] getChannels(List<Object> itemsToBeExported) {
        return itemsToBeExported.stream()
                    .filter(item -> item instanceof EMs)
                    .map(o -> (EMs) o).toArray(EMs[]::new);
    }

    private Mediators[] getMediators(List<Object> itemsToBeExported) {
        return itemsToBeExported.stream()
                    .filter(item -> item instanceof Mediators)
                    .map(o -> (Mediators) o)
                    .toArray(Mediators[]::new);
    }

    @Override
    public String getName() {
        return Constants.DCN_MANAGEMENT;
    }

    @Override
    protected Collection<IReaderBuilder> buildReaders(Iterable<IReaderBuilder> exportableItems){

        IDcnExportReadExecution readExecution = BeanUtils.resolveBeanBayInterface(IDcnExportReadExecution.class);
        Builder<IReaderBuilder> builder = ImmutableList.builder();
        exportableItems.forEach(iReader -> {
            iReader.setExecution(readExecution);
            builder.add(iReader);
        });

        return builder.build();
    }
}