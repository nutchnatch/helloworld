package com.ossnms.bicnet.reportmanager.dcn.read;

import static java.util.Arrays.stream;

import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IDcnExportFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportNE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NesReply;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class ExportNesReader extends BcbReplyReader<Integer, ExportNE, NesReply> {
    private final ISessionContext context;
    private final IDcnExportFacade dcn;

    @Inject public ExportNesReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcn) {
        this.dcn = dcn;
        this.context = context;
    }

    @Override protected ExportNE[] data(NesReply nesReply) {
        return nesReply.getData();
    }

    @Override protected NesReply nextReply(Integer lastId) throws BcbException {
        return dcn.getExportNEs(context, lastId == null ? 0 : lastId, 500);
    }

    @Override protected Integer lastId(NesReply nesReply) {
        return stream(nesReply.getData())
                .map(ExportNE::getNeId)
                .filter(id -> id > 0)
                .max(Integer::compare)
                .orElse(0);
    }

    @Override protected boolean isLast(NesReply nesReply) {
        return nesReply.getEof();
    }
}
