package com.ossnms.bicnet.reportmanager.dcn.runtime;

import static com.ossnms.bicnet.reportmanager.dcn.transform.ChannelToJaxbEm.toEMs;
import static com.ossnms.bicnet.reportmanager.dcn.transform.ContainerToJaxb.toGenericContainers;
import static com.ossnms.bicnet.reportmanager.dcn.transform.MediatorToJaxbAs.toMediators;
import static com.ossnms.bicnet.reportmanager.dcn.transform.NeToJaxbNe.toNEs;
import static com.ossnms.bicnet.reportmanager.dcn.transform.SystemToJaxb.toSystemContainers;
import static com.ossnms.bicnet.reportmanager.dcn.values.ImmutableFullNe.copyOf;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.EMs;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.GenericContainers;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Mediators;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.NEs;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.SystemContainers;
import com.ossnms.bicnet.reportmanager.dcn.read.ContainersReader;
import com.ossnms.bicnet.reportmanager.dcn.read.ExportChannelsReader;
import com.ossnms.bicnet.reportmanager.dcn.read.ExportMediatorsReader;
import com.ossnms.bicnet.reportmanager.dcn.read.ExportNeAdditionalInfo;
import com.ossnms.bicnet.reportmanager.dcn.read.ExportNesReader;
import com.ossnms.bicnet.reportmanager.dcn.read.NEReader;
import com.ossnms.bicnet.reportmanager.dcn.read.NeContainerAssociationsReader;
import com.ossnms.bicnet.reportmanager.dcn.read.SystemContainerAssociationsReader;
import com.ossnms.bicnet.reportmanager.dcn.read.SystemReader;
import com.ossnms.bicnet.reportmanager.dcn.transform.ChannelToJaxbEm;
import com.ossnms.bicnet.reportmanager.dcn.transform.ContainerToJaxb;
import com.ossnms.bicnet.reportmanager.dcn.transform.MediatorToJaxbAs;
import com.ossnms.bicnet.reportmanager.dcn.transform.NeToJaxbNe;
import com.ossnms.bicnet.reportmanager.dcn.transform.SystemToJaxb;
import com.ossnms.bicnet.reportmanager.dcn.values.FullNe;
import com.ossnms.bicnet.reportmanager.dcn.values.FullSystem;
import com.ossnms.bicnet.reportmanager.dcn.values.ImmutableFullNe;
import com.ossnms.bicnet.reportmanager.dcn.values.ImmutableFullSystem;
import com.ossnms.bicnet.reportmanager.dcn.values.NeAdditionalInfo;

@Stateless
@Local(IDcnExportReadExecution.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class DcnExportExecutionBean implements IDcnExportReadExecution {

    public DcnExportExecutionBean() {
    }

    @Inject private NeContainerAssociationsReader neAssignmentReader;
    @Inject private SystemContainerAssociationsReader systemAssignmentsReader;
    @Inject private SystemReader systemReader;
    @Inject private NEReader neReader;
    @Inject private ContainersReader containersReader;
    @Inject private ExportNeAdditionalInfo neAdditionalInfo;
    @Inject private ExportMediatorsReader mediatorsReader;
    @Inject private ExportChannelsReader channelsReader;
    @Inject private ExportNesReader exportNesReader;

    @Override @Asynchronous public Future<Mediators> fetchMediators() throws BcbException {
        Mediators mediators = mediatorsReader.read()
                .map(new MediatorToJaxbAs())
                .collect(toMediators());
        return new AsyncResult<>(mediators);
    }

    @Override @Asynchronous public Future<EMs> fetchChannels() throws BcbException {
        EMs ems = channelsReader.read()
                .map(new ChannelToJaxbEm())
                .collect(toEMs());
        return new AsyncResult<>(ems);
    }

    @Override @Asynchronous public Future<NEs> fetchNEs() throws BcbException {
        Map<Integer, NeAdditionalInfo> exportNeAdditionalInfo = neAdditionalInfo.getExportNeAdditionalInfo();

        NEs nes = exportNesReader.read()
                .map(ImmutableFullNe::of)
                .map(this::enrichWithAssociations)
                .map(this::enrichWithSystem)
                .map(ne -> enrichWithAdditionalInfo(ne, exportNeAdditionalInfo))
                .map(new NeToJaxbNe())
                .collect(toNEs());
        return new AsyncResult<>(nes);
    }

    @Override @Asynchronous public Future<GenericContainers> fetchContainers() {
        GenericContainers containers = containersReader.read()
                .map(new ContainerToJaxb(containersReader))
                .collect(toGenericContainers());
        return new AsyncResult<>(containers);
    }

    @Override @Asynchronous public Future<SystemContainers> fetchSystems() {
        SystemContainers systemContainers = systemReader.read()
                .map(ImmutableFullSystem::of)
                .map(this::enrichWithAssociations)
                .map(new SystemToJaxb())
                .collect(toSystemContainers());
        return new AsyncResult<>(systemContainers);
    }

    private FullNe enrichWithSystem(FullNe ne) {
        return neReader.readNe(ne.ne().getNeId())
                .map(INE::getAssociatedSystemContainer)
                .flatMap(systemReader::resolveSystemName)
                .map(system -> (FullNe) copyOf(ne).withSystem(system)).orElse(ne);
    }

    private FullSystem enrichWithAssociations(FullSystem system) {
        return ImmutableFullSystem.copyOf(system).withAssignments(systemAssignmentsReader.assignments(system.system()));
    }

    private FullNe enrichWithAssociations(FullNe ne) {
        return copyOf(ne).withAssignments(neAssignmentReader.assignments(new NEIdItem(ne.ne().getNeId())));
    }

    private FullNe enrichWithAdditionalInfo(FullNe ne, Map<Integer, NeAdditionalInfo> exportNeAdditionalInfo) {
        Optional<NeAdditionalInfo> neInfo = Optional.ofNullable(exportNeAdditionalInfo.get(ne.ne().getNeId()));
        return neInfo.isPresent() ? copyOf(ne).withNeAdditionalInfo(neInfo) : ne;
    }

}
