package com.ossnms.bicnet.reportmanager.dcn.transform;

import static com.ossnms.bicnet.reportmanager.dcn.transform.AssignmentToJaxb.toJaxb;
import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collector;

import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.SystemContainer;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.SystemContainers;
import com.ossnms.bicnet.reportmanager.dcn.values.FullSystem;

public class SystemToJaxb implements Function<FullSystem, SystemContainer> {

    @Override public SystemContainer apply(FullSystem fullSystem) {
        SystemContainer systemContainer = new SystemContainer();
        systemContainer.setIDName(fullSystem.system().getIdName());
        systemContainer.setDescription(fullSystem.system().getDescription());
        systemContainer.setUserText(fullSystem.system().getUserLabel());
        systemContainer.getAssignedContainer().addAll(toJaxb(fullSystem.assignments()));
        return systemContainer;
    }

    public static Collector<SystemContainer, ?, SystemContainers> toSystemContainers() {
        return collectingAndThen(toList(), SystemToJaxb::systemContainers);
    }

    private static SystemContainers systemContainers(Collection<SystemContainer> systems) {
        SystemContainers result = new SystemContainers();
        result.getSystemContainer().addAll(systems);
        return result;
    }
}
