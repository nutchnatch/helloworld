package com.ossnms.bicnet.reportmanager.dcn.read;

import static com.ossnms.bicnet.reportmanager.dcn.values.ImmutableAssignment.of;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentMarkableItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentMarkable;
import com.ossnms.bicnet.reportmanager.dcn.values.Assignment;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class SystemContainerAssociationsReader extends BcbReplyReader<ISystemGenericContainerAssignmentId, ISystemGenericContainerAssignment, SystemGenericContainerAssignmentReply> {
    private final ISessionContext context;
    private final IEMObjectMgrFacade dcnManager;
    private final ContainersReader containersReader;
    private final ISystemGenericContainerAssignmentMarkable[] filters;

    @Inject
    public SystemContainerAssociationsReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcnManager, ContainersReader containersReader) {
        this(context, dcnManager, containersReader, null);
    }

    public SystemContainerAssociationsReader(ISessionContext context, IEMObjectMgrFacade dcnManager, ContainersReader containersReader, ISystemGenericContainerAssignmentMarkable[] filters) {
        this.context = context;
        this.dcnManager = dcnManager;
        this.containersReader = containersReader;
        this.filters = ArrayUtils.clone(filters);
    }

    public Collection<Assignment> assignments(ISystemContainerId systemId) {
        return fetchAssignments(systemId)
                .map(this::toValue)
                .flatMap(opt -> opt.map(Stream::of).orElseGet(Stream::empty))
                .collect(toList());
    }

    private Optional<Assignment> toValue(ISystemGenericContainerAssignment assignment) {
        return containersReader.containerName(assignment.getGenericContainer())
                .map(container -> of(container, assignment.getPrimary()));
    }

    private Stream<ISystemGenericContainerAssignment> fetchAssignments(ISystemContainerId systemId) {
        ISystemGenericContainerAssignmentMarkable bySystem = new SystemGenericContainerAssignmentMarkableItem(new SystemGenericContainerAssignmentItem());
        bySystem.setSystemContainerId(systemId.getId());
        ISystemGenericContainerAssignmentMarkable[] filter = {bySystem};

        return new SystemContainerAssociationsReader(context, dcnManager, containersReader, filter).read();
    }

    @Override
    protected SystemGenericContainerAssignmentReply nextReply(ISystemGenericContainerAssignmentId lastId) throws BcbException {
        return dcnManager.getSystemGenericContainerAssignmentList(context, lastId, filters, 500);
    }

    @Override protected ISystemGenericContainerAssignment[] data(SystemGenericContainerAssignmentReply reply) {
        return reply.getData();
    }

    @Override protected ISystemGenericContainerAssignmentId lastId(SystemGenericContainerAssignmentReply reply) {
        return reply.getLastReadId();
    }

    @Override protected boolean isLast(SystemGenericContainerAssignmentReply systemGenericContainerAssignmentReply) {
        return systemGenericContainerAssignmentReply.endOfFile();
    }
}
