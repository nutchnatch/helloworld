package com.ossnms.bicnet.reportmanager.dcn.messaging.input;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.SystemContainers;
import com.ossnms.bicnet.reportmanager.dcn.runtime.IDcnExportReadExecution;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.runtime.IExportReadExecution;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class SystemReader implements IReaderBuilder<SystemContainers> {

    private IDcnExportReadExecution dcnExecution;

    @Override
    public Future<SystemContainers> readObject() throws BcbException, ExecutionException, InterruptedException {
        return dcnExecution.fetchSystems();
    }

    @Override
    public void setExecution(IExportReadExecution execution) {
        dcnExecution = (IDcnExportReadExecution) execution;
    }

    @Override
    public String getName() {
        return Constants.SYSTEM;
    }
}
