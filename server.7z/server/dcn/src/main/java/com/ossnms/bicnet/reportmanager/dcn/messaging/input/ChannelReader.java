package com.ossnms.bicnet.reportmanager.dcn.messaging.input;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.EMs;
import com.ossnms.bicnet.reportmanager.dcn.runtime.IDcnExportReadExecution;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.runtime.IExportReadExecution;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class ChannelReader implements IReaderBuilder<EMs> {

    private IDcnExportReadExecution dcnExecution;

    @Override
    public Future<EMs> readObject() throws BcbException, ExecutionException, InterruptedException {
        return dcnExecution.fetchChannels();
    }

    @Override
    public void setExecution(IExportReadExecution execution) {
        dcnExecution = (IDcnExportReadExecution) execution;
    }

    @Override
    public String getName() {
        return Constants.CHANNELS;
    }
}
