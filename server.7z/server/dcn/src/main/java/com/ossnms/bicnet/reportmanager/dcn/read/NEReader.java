package com.ossnms.bicnet.reportmanager.dcn.read;

import static com.google.common.collect.Iterables.partition;
import static java.util.Arrays.asList;
import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static java.util.stream.StreamSupport.stream;
import static org.apache.commons.lang3.ArrayUtils.getLength;
import static org.apache.commons.lang3.ArrayUtils.nullToEmpty;

import java.util.Optional;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class NEReader extends BcbReplyReader<INEId, INE, NEReply> {

    private static final int MAX_FILTER_LENGTH = 1000; // size of filter that doesn't overflow stack

    private final ISessionContext context;
    private final IEMObjectMgrFacade dcnManager;
    private final INEMarkable[] filter;

    private static final Logger LOGGER = LoggerFactory.getLogger(NEReader.class);

    @Inject public NEReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcnManager) {
        this(context, dcnManager, null);
    }

    public NEReader(ISessionContext context, IEMObjectMgrFacade dcnManager, INEMarkable[] filter) {
        this.context = context;
        this.dcnManager = dcnManager;
        this.filter = ArrayUtils.clone(filter);
    }

    private static Stream<INEMarkable[]> split(INEMarkable[] array, int partitionSize) {
        return stream(partition(asList(nullToEmpty(array)), partitionSize).spliterator(), false)
                .map(list -> list.stream().toArray(INEMarkable[]::new));
    }

    @Override public Stream<INE> read() {
        return MAX_FILTER_LENGTH < getLength(filter)
                ? split(filter, MAX_FILTER_LENGTH)
                    .flatMap(filterPart -> new NEReader(context, dcnManager, filterPart).read())
                    .distinct() //different parts of the filter can match the same INE
                : super.read();
    }

    public Optional<INE> readNe(int neId) {
        try {
            return ofNullable(dcnManager.getSingleNE(context, new NEIdItem(neId)));
        } catch (BcbException e) {
            LOGGER.error("Failed to fetch NE {} from dcn manager", neId, e);
            return empty();
        }
    }

    @Override protected NEReply nextReply(INEId lastId) throws BcbException {
        return dcnManager.getNEList(context, lastId, filter, 500);
    }

    @Override protected INE[] data(NEReply reply) {
        return reply.getData();
    }

    @Override protected INEId lastId(NEReply reply) {
        return reply.getLastReadId();
    }

    @Override protected boolean isLast(NEReply neReply) {
        return neReply.endOfFile();
    }

}
