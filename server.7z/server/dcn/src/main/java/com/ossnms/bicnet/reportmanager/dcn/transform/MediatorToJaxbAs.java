package com.ossnms.bicnet.reportmanager.dcn.transform;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.function.Function;
import java.util.stream.Collector;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportMediator;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Mediator;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Mediators;

public class MediatorToJaxbAs implements Function<ExportMediator, Mediator> {

    @Override
    public Mediator apply(ExportMediator exportDomain) {
        Mediator me = new Mediator();
        me.setIDName(exportDomain.getIdName());
        me.setConcurrentActivationsLimit(exportDomain.getConcurrentActivationsLimit());
        me.setConcurrentActivationsLimited(exportDomain.getConcurrentActivationsLimited());
        me.setDescription(exportDomain.getDescription());
        me.setHost(exportDomain.getHost());
        me.setReconnectInterval(exportDomain.getReconnectInterval());
        me.setType(exportDomain.getType());
        return me;
    }

    public static Collector<Mediator, ?, Mediators> toMediators() {
        return collectingAndThen(toList(), MediatorToJaxbAs::mediators);
    }

    private static Mediators mediators(Collection<Mediator> mediators) {
        Mediators result = new Mediators();
        result.getMediator().addAll(mediators);
        return result;
    }
}
