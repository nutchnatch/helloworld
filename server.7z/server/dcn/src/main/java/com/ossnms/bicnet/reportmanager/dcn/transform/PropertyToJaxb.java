package com.ossnms.bicnet.reportmanager.dcn.transform;

import static java.util.Arrays.stream;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.function.Function;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.bcb.model.common.Property;

class PropertyToJaxb implements Function<Property, com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Property> {

    @Override
    public com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Property apply(@Nonnull Property input) {
        return transform(input);
    }

    static Collection<com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Property> properties(final Property[] properties) {
        return stream(ofNullable(properties).orElse(new Property[0]))
                .map(PropertyToJaxb::transform)
                .collect(toList());
    }

    private static com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Property transform(@Nonnull Property input) {
        com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Property property =
                new com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Property();
        property.setName(input.getName());
        property.setValue(input.getValue());
        return property;
    }
}
