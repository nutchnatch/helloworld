package com.ossnms.bicnet.reportmanager.dcn.read;

import java.util.Arrays;

import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IDcnExportFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorsReply;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;

public class ExportMediatorsReader extends BcbReplyReader<Integer, ExportMediator, MediatorsReply> {

    private final IDcnExportFacade dcn;
    private final ISessionContext context;

    @Inject public ExportMediatorsReader(@BiCNet ISessionContext context, @BiCNet IEMObjectMgrFacade dcn) {
        this.dcn = dcn;
        this.context = context;
    }

    @Override protected ExportMediator[] data(MediatorsReply reply) {
        return reply.getData();
    }

    @Override protected MediatorsReply nextReply(Integer lastId) throws BcbException {
        return dcn.getExportMediators(context, lastId == null ? 0 : lastId, 50);
    }

    @Override protected Integer lastId(MediatorsReply mediatorsReply) {
        return Arrays.stream(mediatorsReply.getData())
                .map(ExportMediator::getMediatorId)
                .filter(id -> id > 0)
                .max(Integer::compare)
                .orElse(0);
    }

    @Override protected boolean isLast(MediatorsReply mediatorsReply) {
        return mediatorsReply.getEof();
    }
}
