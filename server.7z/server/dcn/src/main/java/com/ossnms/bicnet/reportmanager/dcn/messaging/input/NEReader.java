package com.ossnms.bicnet.reportmanager.dcn.messaging.input;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.NEs;
import com.ossnms.bicnet.reportmanager.dcn.runtime.IDcnExportReadExecution;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import com.ossnms.bicnet.reportmanager.server.runtime.IExportReadExecution;
import com.ossnms.bicnet.reportmanager.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class NEReader implements IReaderBuilder<NEs> {

    private final Logger LOGGER = LoggerFactory.getLogger(NEReader.class);
    private IDcnExportReadExecution dcnExecution;

    public NEReader(){

    }

    @Override
    public Future<NEs> readObject() throws BcbException, ExecutionException, InterruptedException {

        return dcnExecution.fetchNEs();
    }

    @Override
    public void setExecution(IExportReadExecution execution) {
        this.dcnExecution = (IDcnExportReadExecution) execution;
    }

    @Override
    public String getName() {
        return Constants.NETWORK_ELEMENTS;
    }
}
