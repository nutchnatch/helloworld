package com.ossnms.bicnet.reportmanager.dcn.values;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import java.util.List;

@Immutable public interface FullSystem {
    @Parameter ISystemContainer system();

    List<Assignment> assignments();
}
