package com.ossnms.bicnet.reportmanager.dcn.transform;

import static com.ossnms.bicnet.reportmanager.dto.ImmutableMediator.mediator;

import java.util.function.Function;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.reportmanager.dto.DcnObject.Mediator;

public class MediatorToDcnObject implements Function<IMediator, Mediator> {
    @Override public Mediator apply(IMediator m) {
        return mediator(m.getIdName(), m.getDisplayAddress(), m.getDisplayState());
    }
}
