package com.ossnms.bicnet.reportmanager.dcn.values;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

@Immutable public interface Assignment {
    @Parameter String name();

    @Parameter Boolean isPrimary();
}
