package com.ossnms.bicnet.reportmanager.dcn.values;

import java.util.List;
import java.util.Optional;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportNE;

@Immutable public interface FullNe {
    @Parameter ExportNE ne();

    Optional<String> system();

    List<Assignment> assignments();
    
    Optional<NeAdditionalInfo> neAdditionalInfo();
}
