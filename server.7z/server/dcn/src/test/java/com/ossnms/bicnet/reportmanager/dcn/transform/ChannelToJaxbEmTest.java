package com.ossnms.bicnet.reportmanager.dcn.transform;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportChannel;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Channel;

public class ChannelToJaxbEmTest {

    @Test
    public void shouldTransformChanel() {

        ExportChannel channel = new ExportChannel();
        channel.setIdName("Channel");
        channel.setType("ChannelType");
        channel.setProperties(new Property[] {createPropersties()});
        channel.setConcurrentActivationsLimit("ConcurrentLimit");
        channel.setConcurrentActivationsLimited(true);
        channel.setMediator("Mediator");

        Channel transformedChannel = new ChannelToJaxbEm().apply(channel);
        assertThat(transformedChannel.getIDName(), is("Channel"));
        assertThat(transformedChannel.getType(), is("ChannelType"));
        assertThat(transformedChannel.getMediatorName(), is("Mediator"));
    }

    private static Property createPropersties() {
        Property property =
                new Property();
        property.setName("PropertyName");
        property.setValue("PropertyValue");
        return property;
    }
}
