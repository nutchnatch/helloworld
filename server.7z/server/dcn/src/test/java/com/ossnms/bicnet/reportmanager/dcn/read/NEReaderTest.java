package com.ossnms.bicnet.reportmanager.dcn.read;

import static java.util.stream.IntStream.range;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;

public class NEReaderTest {

    private final ISessionContext context = mock(ISessionContext.class);

    private static IEMObjectMgrFacade dcnManager(INE... nes) throws BcbException {
        IEMObjectMgrFacade dcnManager = mock(IEMObjectMgrFacade.class);
        when(dcnManager.getNEList(any(), any(), any(), anyInt())).thenReturn(new NEReply(nes, true, null));
        return dcnManager;
    }

    private static INE ne(int id) {
        NEItem ne = new NEItem();
        ne.setId(id);
        return ne;
    }

    private static INEMarkable[] filter(int size) {
        return range(0, size).boxed().map(id -> ne(id).toMarkableNE(false)).toArray(INEMarkable[]::new);
    }

    @Test public void shouldWorkWithNullFilter() throws Exception {
        long size = new NEReader(context, dcnManager(ne(1)), null).read().count();

        assertThat(size, is(1L));
    }

    @Test public void shouldWorkWithSmallFilter() throws Exception {
        INEMarkable[] filter = filter(10);

        long size = new NEReader(context, dcnManager(ne(1)), filter).read().count();

        assertThat(size, is(1L));
    }

    @Test public void shouldPartitionLargeFilter() throws Exception {
        INEMarkable[] filter = filter(10000);

        long size = new NEReader(context, dcnManager(ne(1)), filter).read().count();

        assertThat(size, is(1L));
    }
}