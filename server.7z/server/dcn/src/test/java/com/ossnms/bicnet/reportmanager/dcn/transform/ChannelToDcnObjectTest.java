package com.ossnms.bicnet.reportmanager.dcn.transform;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;

public class ChannelToDcnObjectTest {

    @Test
    public void testConvertEmsToDtos() throws Exception {

        EMItem emItem = new EMItem();
        emItem.setIdName("EM 1");
        emItem.setDisplayAddress("2.3.4.5");
        emItem.setDisplayState("Active");
        emItem.setAssociatedMediatorId(1);


        DcnObject dcnObject = new ChannelToDcnObject().apply(emItem);

        assertEquals(emItem.getIdName(), dcnObject.name());
        assertEquals("Channel", dcnObject.type());
        assertEquals(emItem.getDisplayAddress(), dcnObject.address());
        assertEquals(emItem.getDisplayState(), dcnObject.state());
    }

    
}
