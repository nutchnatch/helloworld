package com.ossnms.bicnet.reportmanager.dcn.transform;

import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.ContainerAssignment;
import com.ossnms.bicnet.reportmanager.dcn.values.Assignment;
import com.ossnms.bicnet.reportmanager.dcn.values.ImmutableAssignment;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class AssignmentToJaxbTest {

    @Test
    public void shouldTransformAssignment() {
        List<Assignment> assignmentList = new ArrayList<>();
        assignmentList.add(ImmutableAssignment.of("Assignment1", true));
        assignmentList.add(ImmutableAssignment.of("Assignment2", true));

        Collection<ContainerAssignment> containerAssignments = AssignmentToJaxb.toJaxb(assignmentList);
        assertTrue(!containerAssignments.isEmpty());
        containerAssignments.stream()
                .map(assignment -> {
                    assertTrue(assignment.getIDName().startsWith("Assignment"));
                    assertTrue(assignment.isIsPrimary());
                    return assignment;
                })
                .toArray();
    }
}
