package com.ossnms.bicnet.reportmanager.dcn.transform;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;

public class MediatorToDcnObjectTest {
    @Test public void testConvertMediatorsToDtos() throws Exception {

        MediatorItem mediatorItem = new MediatorItem();
        mediatorItem.setIdName("Mediator 1");
        mediatorItem.setDisplayAddress("1.2.3.4");
        mediatorItem.setDisplayState("Running");

        DcnObject dcnObject = new MediatorToDcnObject().apply(mediatorItem);


        assertEquals(mediatorItem.getIdName(), dcnObject.name());
        assertEquals("Mediator", dcnObject.type());
        assertEquals(mediatorItem.getDisplayAddress(), dcnObject.address());
        assertEquals(mediatorItem.getDisplayState(), dcnObject.state());
    }
}