package com.ossnms.bicnet.reportmanager.dcn.transform;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportMediator;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.Mediator;

public class MediatorToJaxbAsTest {

    @Test
    public void shouldTransformMediator() {

        ExportMediator exportMediator = new ExportMediator();
        exportMediator.setIdName("Mediator");
        exportMediator.setConcurrentActivationsLimit("Any Limit");
        exportMediator.setConcurrentActivationsLimited(true);
        exportMediator.setDescription("Mediator description");
        exportMediator.setHost("Mediator host");
        exportMediator.setReconnectInterval("Interval");
        exportMediator.setType("Type");

        Mediator mediator = new MediatorToJaxbAs().apply(exportMediator);
        assertThat(mediator.getIDName(), is("Mediator"));
        assertThat(mediator.getDescription(), is("Mediator description"));
        assertThat(mediator.getHost(), is("Mediator host"));

    }
}
