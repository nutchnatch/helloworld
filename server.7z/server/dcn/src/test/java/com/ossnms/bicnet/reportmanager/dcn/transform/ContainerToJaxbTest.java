package com.ossnms.bicnet.reportmanager.dcn.transform;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.GenericContainer;

public class ContainerToJaxbTest {

    @Test
    public void shouldTransformContainer() {
        GenericContainerItem containerItem = new GenericContainerItem();
        containerItem.setIdName("Container");
        containerItem.setDescription("Container description");
        containerItem.setUserLabel("Container user text");
        containerItem.setId(0);

        GenericContainer genericContainer = new ContainerToJaxb(null).apply(containerItem);

        assertThat(genericContainer.getIDName(), is("Container"));
        assertThat(genericContainer.getDescription(), is("Container description"));
        assertThat(genericContainer.getUserText(), is("Container user text"));
    }
}
