package com.ossnms.bicnet.reportmanager.dcn.transform;

import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.DISABLED;
import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.ENABLED;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CLEARED;
import static java.util.Optional.of;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmCountersItem;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmCounters;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.dto.DcnObject.Alarm;

public class NeToDcnObjectTest {
    @Test public void should() throws Exception {
        Map<INEId, IAlarmCounters> severities = new HashMap<>();
        severities.put(new NEIdItem(1), counter(CLEARED, true));
        severities.put(new NEIdItem(2), counter(AlarmSeverity.MINOR, false));

        Map<ISystemContainerId, String> systems = new HashMap<>();
        systems.put(new SystemContainerIdItem(1), "System 1");

        NEItem neItem = new NEItem();
        neItem.setId(1);
        neItem.setIdName("EM 1");
        neItem.setDisplayAddress("2.3.4.5");
        neItem.setDisplayState("Active");
        neItem.setAssociatedEmId(1);
        neItem.setAssociatedSystemContainerId(1);
        neItem.setEventForwarding(DISABLED);
        neItem.setOperationalState(OperationalState.DISABLED);


        DcnObject dcnObject = new NeToDcnObject(severities, systems).apply(neItem);

        
        assertEquals(neItem.getIdName(), dcnObject.name());
        assertEquals("NE", dcnObject.type());
        assertEquals(neItem.getDisplayAddress(), dcnObject.address());
        assertEquals(neItem.getDisplayState(), dcnObject.state());
        assertNotNull(dcnObject.channelId());
        assertEquals(of(neItem.getAssociatedEmId()), dcnObject.channelId());
        assertEquals(of(CLEARED), dcnObject.alarm().map(Alarm::severity));
        assertEquals(of(ENABLED), dcnObject.maintenanceState());
        assertEquals(of(OperationalState.DISABLED), dcnObject.operationalState());
        assertEquals(of(true), dcnObject.alarm().map(Alarm::acknowledge));
        assertEquals(of("System 1"), dcnObject.systemName());
    }

    private AlarmCountersItem counter(AlarmSeverity severity, boolean isAcknowledged) {
        AlarmCountersItem minor = new AlarmCountersItem();
        minor.setSeverity(severity);
        minor.setIsAcknowledged(isAcknowledged);
        return minor;
    }
}