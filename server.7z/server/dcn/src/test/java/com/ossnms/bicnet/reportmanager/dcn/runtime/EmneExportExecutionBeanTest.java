package com.ossnms.bicnet.reportmanager.dcn.runtime;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import org.junit.Test;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class EmneExportExecutionBeanTest {

//    @Test public void shouldReadEmptyDomainReply() throws Exception {
//        DomainsReply emptyReply = new DomainsReply(true, new ExportDomain[0]);
//        IEMObjectMgrFacade dcn = mock(IEMObjectMgrFacade.class);
//        when(dcn.getExportDomains(any(ISessionContext.class), anyInt(), anyInt())).thenReturn(emptyReply);
//
//        Object item = new DcnExportExecutionBean(null, dcn).fetchMediators().get();
//
//        assertThat(item, instanceOf(ASs.class));
//    }
//
//    @Test public void shouldReadDomains() throws Exception {
//        DomainsReply domainsReply = new DomainsReply(true, new ExportDomain[]{
//                newDomain("Domain name 1"), newDomain("Domain name 2")});
//        IEMObjectMgrFacade dcn = mock(IEMObjectMgrFacade.class);
//        when(dcn.getExportDomains(any(ISessionContext.class), anyInt(), anyInt())).thenReturn(domainsReply);
//
//        ASs ass = (ASs) new DcnExportExecutionBean(null, dcn).fetchMediators().get();
//
//        assertThat(ass.getAS(), hasSize(2));
//        assertThat(ass.getAS().get(0).getIDName(), is("Domain name 1"));
//        assertThat(ass.getAS().get(1).getIDName(), is("Domain name 2"));
//    }
//
//    @Test public void shouldReadMultipleDomainReplies() throws Exception {
//        DomainsReply firstReply = new DomainsReply(false, new ExportDomain[]{
//                newDomain("Domain name 1"), newDomain("Domain name 3")});
//        DomainsReply lastReply = new DomainsReply(true, new ExportDomain[]{newDomain("Domain name 2")});
//        IEMObjectMgrFacade dcn = mock(IEMObjectMgrFacade.class);
//        when(dcn.getExportDomains(any(ISessionContext.class), eq(0), anyInt())).thenReturn(firstReply);
//        when(dcn.getExportDomains(any(ISessionContext.class), eq(2), anyInt())).thenReturn(lastReply);
//
//        ASs ass = (ASs) new DcnExportExecutionBean(null, dcn).fetchMediators().get();
//
//         assertThat(ass.getAS(), hasSize(3));
//        assertThat(ass.getAS().get(0).getIDName(), is("Domain name 1"));
//        assertThat(ass.getAS().get(1).getIDName(), is("Domain name 3"));
//        assertThat(ass.getAS().get(2).getIDName(), is("Domain name 2"));
//    }
//
//    private ExportDomain newDomain(String name) {
//        return new ExportDomain(name, "parent EM", 42, true, new String[]{"ne1", "ne2"});
//    }
}