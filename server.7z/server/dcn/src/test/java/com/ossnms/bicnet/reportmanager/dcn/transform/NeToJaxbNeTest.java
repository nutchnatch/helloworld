package com.ossnms.bicnet.reportmanager.dcn.transform;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isEmptyString;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import java.util.Optional;

import org.junit.Test;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportNE;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.NetworkElement;
import com.ossnms.bicnet.reportmanager.dcn.values.ImmutableAssignment;
import com.ossnms.bicnet.reportmanager.dcn.values.ImmutableFullNe;
import com.ossnms.bicnet.reportmanager.dcn.values.ImmutableNeAdditionalInfo;

public class NeToJaxbNeTest {
    @Test public void shouldTransformAssignments() throws Exception {
        ImmutableFullNe fullNe = ImmutableFullNe.of(new ExportNE())
                .withAssignments(
                        ImmutableAssignment.of("Primary container", true),
                        ImmutableAssignment.of("Secondary container", false));

        NetworkElement networkElement = new NeToJaxbNe().apply(fullNe);

        assertThat(networkElement.getAssignedContainer(), hasSize(2));
        assertThat(networkElement.getAssignedContainer().get(0).getIDName(), is("Primary container"));
        assertThat(networkElement.getAssignedContainer().get(0).isIsPrimary(), is(true));
        assertThat(networkElement.getAssignedContainer().get(1).getIDName(), is("Secondary container"));
        assertThat(networkElement.getAssignedContainer().get(1).isIsPrimary(), is(false));
    }
    
    @Test public void shouldExportSystem() throws Exception {
        ImmutableFullNe neWithSystem = ImmutableFullNe.of(new ExportNE())
                .withSystem("System name");
        ImmutableFullNe neWithoutSystem = ImmutableFullNe.of(new ExportNE())
                .withSystem(Optional.empty());

        NetworkElement neWith = new NeToJaxbNe().apply(neWithSystem);
        NetworkElement neWithout = new NeToJaxbNe().apply(neWithoutSystem);

        assertThat(neWith.getSystemContainer(), is("System name"));
        assertThat(neWithout.getSystemContainer(), is(nullValue()));

    }
    
    @Test
    public void shouldExportAdditionalInfo() {
    	ImmutableNeAdditionalInfo additionalInfo = ImmutableNeAdditionalInfo.builder().eonType("PRNE").localInterface("192.168.1.1")
    			.mountMode("mountMode").build();
    	
    	ImmutableFullNe neWithAdditionalInfo = ImmutableFullNe.of(new ExportNE()).withNeAdditionalInfo(additionalInfo);
    	ImmutableFullNe neWithoutAdditionalInfo = ImmutableFullNe.of(new ExportNE()).withNeAdditionalInfo(Optional.empty());
    	
    	NetworkElement neWith = new NeToJaxbNe().apply(neWithAdditionalInfo);
        NetworkElement neWithout = new NeToJaxbNe().apply(neWithoutAdditionalInfo);
        
        assertThat(neWith.getDcnAttributes().getEonType(), is("PRNE"));
        assertThat(neWith.getDcnAttributes().getGateway(), isEmptyString());
        assertThat(neWith.getDcnAttributes().getLocalInterface(), is("192.168.1.1"));
        assertThat(neWith.getDcnAttributes().getLocalInterfaceMask(), isEmptyString());
        assertThat(neWith.getDcnAttributes().getDcnInterface(), isEmptyString());
        assertThat(neWith.getDcnAttributes().getDcnInterfaceMask(), isEmptyString());
        assertThat(neWith.getDcnAttributes().getRouterInterface(), isEmptyString());
        assertThat(neWith.getDcnAttributes().getRouterInterfaceMask(), isEmptyString());
        assertThat(neWith.getDcnAttributes().getManagementInterface(), isEmptyString());
        assertThat(neWith.getDcnAttributes().getManagementInterfaceMask(), isEmptyString());
        assertThat(neWith.getMountMode(), is("mountMode"));
        assertThat(neWith.getNeSoftwareVersion(), isEmptyString());
        
        assertThat(neWithout.getDcnAttributes(), notNullValue());
        assertThat(neWithout.getMountMode(), isEmptyString());
        assertThat(neWithout.getNeSoftwareVersion(), isEmptyString());
    }
}