package com.ossnms.bicnet.reportmanager.dcn.transform;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.reportmanager.configuration.jaxb.dcn.SystemContainer;
import com.ossnms.bicnet.reportmanager.dcn.values.ImmutableAssignment;
import com.ossnms.bicnet.reportmanager.dcn.values.ImmutableFullSystem;

public class SystemToJaxbTest {

    @Test
    public void shouldTransformSystem() {
        SystemContainerItem container = new SystemContainerItem();
        container.setIdName("ContainerName");
        container.setDescription("Description");
        container.setUserLabel("ContainerLabel");

        ImmutableFullSystem fullSystem = ImmutableFullSystem.of(container)
                .withAssignments(ImmutableAssignment.of("Assignment1", true), ImmutableAssignment.of("Assignment2", true));

        SystemContainer systemContainer = new SystemToJaxb().apply(fullSystem);
        systemContainer.getAssignedContainer().stream()
                .map(assignment -> {
                    assertTrue(assignment.getIDName().startsWith("Assignment"));
                    assertTrue(assignment.isIsPrimary());
                    return assignment;
                })
                .toArray();

        assertThat(systemContainer.getIDName(), is("ContainerName"));
        assertThat(systemContainer.getDescription(), is("Description"));
    }
}
