package com.ossnms.bicnet.reportmanager.server.inventory.input;

import com.ossnms.bicnet.bcb.facade.inventoryMgmt.IInventoryExportFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.Shelf;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfReply;


public class ShelfReader extends InventoryItemReader<Shelf, ShelfReply> {

    private final ISessionContext context;
    private final IInventoryExportFacade inventoryManager;
    private final int pageSize;

    public ShelfReader(ISessionContext context, IInventoryExportFacade inventoryManager, int pageSize) {
        this.context = context;
        this.inventoryManager = inventoryManager;
        this.pageSize = pageSize;
    }

    @Override protected ShelfReply nextReply(Integer lastId) throws BcbException {
        return inventoryManager.getShelves(context, lastId == null ? 0 : lastId, pageSize);
    }

    @Override protected Shelf[] data(ShelfReply shelfReply) {
        return shelfReply.getData();
    }

    @Override protected boolean isLast(ShelfReply shelfReply) {
        return shelfReply.getEof();
    }
}
