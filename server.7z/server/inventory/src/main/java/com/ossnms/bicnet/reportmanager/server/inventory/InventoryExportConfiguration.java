package com.ossnms.bicnet.reportmanager.server.inventory;

import com.ossnms.bicnet.bcb.facade.ecs.IECSFacade;
import com.ossnms.bicnet.bcb.facade.inventoryMgmt.IInventoryExportFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.reportmanager.server.configuration.SettingsRepository;
import com.ossnms.bicnet.reportmanager.server.files.FilesManager;
import com.ossnms.bicnet.reportmanager.server.files.RetentionNumberOfGroupsFilter;
import com.ossnms.bicnet.reportmanager.server.inventory.input.CardReader;
import com.ossnms.bicnet.reportmanager.server.inventory.input.PortReader;
import com.ossnms.bicnet.reportmanager.server.inventory.input.ShelfReader;
import com.ossnms.bicnet.reportmanager.server.inventory.output.CardWriter;
import com.ossnms.bicnet.reportmanager.server.inventory.output.PortWriter;
import com.ossnms.bicnet.reportmanager.server.inventory.output.ShelfWriter;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.logging.Logger;
import com.ossnms.bicnet.reportmanager.server.model.ReportData;
import com.ossnms.bicnet.reportmanager.server.remote.RemoteExport;
import com.ossnms.bicnet.reportmanager.server.runtime.BatchStep;
import com.ossnms.bicnet.reportmanager.server.runtime.Configuration;
import com.ossnms.bicnet.reportmanager.server.runtime.JobConfiguration;
import com.ossnms.bicnet.reportmanager.server.support.FilesRetentionEnforcement;
import com.ossnms.bicnet.reportmanager.server.support.JobStatusClientNotifications;
import com.ossnms.bicnet.reportmanager.server.support.JobStatusSystemEventLog;
import com.ossnms.bicnet.reportmanager.server.support.ListReader;
import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import com.ossnms.bicnet.reportmanager.server.zip.ZipFiles;
import com.ossnms.bicnet.reportmanager.util.Constants;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;

/*
    This configuration can be migrated to batch.xml : 

    <job id="Inventory Export" xmlns="http://xmlns.jcp.org/xml/ns/javaee" version="1.0">
        <step id="Inventory Export.shelvesExport">
            <chunk>
                <reader ref="shelfReader">
                    <properties>
                        <property name="pageSize" value="1000"/>
                    </properties>
                </reader>
                <writer ref="csvItemWriter">
                    <properties>
                        <property name="header" value="..."/>
                        <property name="mapping" value="..."/>
                        <property name="format" value="..."/>
                        <property name="processors" value="..."/>
                        <property name="resource" value="..."/>
                    </properties>
                </writer>
            </chunk>
        </step>

        <step id="Inventory Export.cardsExport">
            ...
        </step>

        <step id="Inventory Export.portsExport">
            ...
        </step>

        <step id="Inventory Export.archiveResults">
            ...
        </step>

        <listeners>
            <listener ref="jobStatusClientNotifications"/>
            <listener ref="jobStatusSystemEventLog"/>
        </listeners>
    </job>
 */

@Named(Constants.INVENTORY_EXPORT_REPORT)
public class InventoryExportConfiguration implements JobConfiguration {

    private static final int PAGE_SIZE = 25000;
    private static final String EXPORT_INVENTORY_RELATIVE_PATH = "reportmanager\\networkinventory";

    @Inject private SettingsRepository settingsRepository;
    @Inject @BiCNet
    private ISessionContext context;
    @Inject @BiCNet private IInventoryExportFacade inventoryManager;
    @Inject private ReportData reportDataBean;
    @Inject private Logger logger;
    @Inject @BiCNet private IECSFacade ecsFacade;
    private TransferSettings transferSettings;

    @Override public String getJobName() {
        return Constants.INVENTORY_EXPORT_REPORT;
    }

    @Override public List<Configuration> getSteps() {
        Date exportDate = new Date();
        List<Configuration> configurationSteps = new ArrayList<>();

        FilesManager filesManager = new FilesManager(settingsRepository.getInventoryExportPath());
        File shelvesFile = filesManager.resolveReportFile("inventoryItems-shelves", "csv", exportDate);
        Configuration shelvesExport = new BatchStep<>(
                new ShelfReader(context, inventoryManager, PAGE_SIZE),
                new ShelfWriter(shelvesFile));

        File cardsFile = filesManager.resolveReportFile("inventoryItems-cards", "csv", exportDate);
        Configuration cardsExport = new BatchStep<>(
                new CardReader(context, inventoryManager, PAGE_SIZE),
                new CardWriter(cardsFile));

        File portsFile = filesManager.resolveReportFile("inventoryItems-ports", "csv", exportDate);
        Configuration portsExport = new BatchStep<>(
                new PortReader(context, inventoryManager, PAGE_SIZE),
                new PortWriter(portsFile));

        File zipFile = filesManager.resolveReportFile("inventoryItems-all", "zip", exportDate);
        Configuration archiveResults = new BatchStep<>(
                new ListReader<>(asList(shelvesFile, cardsFile, portsFile)),
                new ZipFiles(zipFile));

        configurationSteps.addAll(asList(shelvesExport, cardsExport, portsExport, archiveResults));

        if (null != transferSettings && transferSettings.getExternalCommunicationProtocol().getRemoteExport()) {
            Configuration remoteArchiveResults = new BatchStep<>(
                    new ListReader<>(asList(shelvesFile, cardsFile, portsFile, zipFile)),
                    new RemoteExport(context, ecsFacade, transferSettings, EXPORT_INVENTORY_RELATIVE_PATH));

            configurationSteps.add(remoteArchiveResults);
        }

        return configurationSteps;
    }

    public InventoryExportConfiguration withTransferSettings(TransferSettings transferSettings) {
        this.transferSettings = transferSettings;
        return this;
    }

    @Override public List<JobListener> getJobListeners() {
        FilesManager filesManager = new FilesManager(settingsRepository.getInventoryExportPath());
        RetentionNumberOfGroupsFilter filesFilter = new RetentionNumberOfGroupsFilter(settingsRepository.inventoryRetentionNumber());
        return asList(
                new FilesRetentionEnforcement(filesManager, filesFilter),
                new JobStatusClientNotifications(context, reportDataBean),
                new JobStatusSystemEventLog(context, logger));
    }
}

