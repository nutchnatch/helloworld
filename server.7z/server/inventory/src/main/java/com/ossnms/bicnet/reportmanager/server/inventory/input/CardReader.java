package com.ossnms.bicnet.reportmanager.server.inventory.input;

import com.ossnms.bicnet.bcb.facade.inventoryMgmt.IInventoryExportFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.Card;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.CardReply;


public final class CardReader extends InventoryItemReader<Card, CardReply> {

    private final ISessionContext context;
    private final IInventoryExportFacade inventoryManager;
    private final int pageSize;

    public CardReader(ISessionContext context, IInventoryExportFacade inventoryManager, int pageSize) {
        this.context = context;
        this.inventoryManager = inventoryManager;
        this.pageSize = pageSize;
    }


    @Override protected CardReply nextReply(Integer lastId) throws BcbException {
        return inventoryManager.getCards(context, lastId == null ? 0 : lastId, pageSize);
    }

    @Override protected Card[] data(CardReply cardReply) {
        return cardReply.getData();
    }

    @Override protected boolean isLast(CardReply cardReply) {
        return cardReply.getEof();
    }
}
