package com.ossnms.bicnet.reportmanager.server.inventory.input;


import static org.apache.commons.lang3.ArrayUtils.getLength;

import com.ossnms.bicnet.bcb.model.inventoryMgmt.Reply;
import com.ossnms.bicnet.reportmanager.server.support.BcbReplyReader;

/**
 * Base class that reads items from Inventory using pagination
 *
 * @param <Item>      type of item to read (i.e. Card)
 * @param <ItemReply> type of items container (i.e. CardReply)
 */
abstract class InventoryItemReader<Item, ItemReply extends Reply> extends BcbReplyReader<Integer, Item, ItemReply> {

    private int pageStart;

    @Override protected Integer lastId(ItemReply itemReply) {
        pageStart += getLength(data(itemReply));
        return pageStart;
    }
}
