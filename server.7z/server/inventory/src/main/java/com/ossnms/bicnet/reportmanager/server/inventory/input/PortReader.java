package com.ossnms.bicnet.reportmanager.server.inventory.input;

import com.ossnms.bicnet.bcb.facade.inventoryMgmt.IInventoryExportFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.Port;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.PortReply;

public final class PortReader extends InventoryItemReader<Port, PortReply> {

    private final ISessionContext context;
    private final IInventoryExportFacade inventoryManager;
    private final int pageSize;

    public PortReader(ISessionContext context, IInventoryExportFacade inventoryManager, int pageSize) {
        this.context = context;
        this.inventoryManager = inventoryManager;
        this.pageSize = pageSize;
    }

    @Override protected PortReply nextReply(Integer lastId) throws BcbException {
        return inventoryManager.getPorts(context, lastId == null ? 0 : lastId, pageSize);
    }

    @Override protected Port[] data(PortReply portReply) {
        return portReply.getData();
    }

    @Override protected boolean isLast(PortReply portReply) {
        return portReply.getEof();
    }
}
