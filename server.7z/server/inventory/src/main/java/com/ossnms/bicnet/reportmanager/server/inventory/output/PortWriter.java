package com.ossnms.bicnet.reportmanager.server.inventory.output;

import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.ACTUAL_APPLICATION_CODE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.ADMINISTRATIVE_STATE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.CONNECTOR_LOCATION;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.EQUIPMENT_STATE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.IS_ACTIVE_NE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.LOCATION;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.MODULE_TYPE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.NE_ID_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.NE_REAL_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.NE_SYSTEM_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.PART_NUMBER;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.PORT_MODE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.REQUIRED_APPLICATION_CODE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.PortElements.SERIAL_NUMBER;
import static com.ossnms.bicnet.reportmanager.server.csv.CsvFormat.CSV_PREFERENCE;

import java.io.File;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;

import com.ossnms.bicnet.bcb.model.inventoryMgmt.Port;
import com.ossnms.bicnet.reportmanager.server.csv.CsvItemWriter;
import com.ossnms.bicnet.reportmanager.server.support.FormatEnumBase;


/**
 * Port configuration for CsvItemWriter
 */
public class PortWriter extends CsvItemWriter<Port> {

    private static final String[] header = {
            "NE name",
            "NE Network Name",
            "NE/System Name",
            "Location",
            "Connector location",
            "Administrative state",
            "Equipment state",
            "Port mode",
            "Required application code",
            "Actual application code",
            "Part number",
            "Module type",
            "Serial number",
            "Active NE"
    };

    private static final String[] mappings = {
            NE_ID_NAME.name(),
            NE_REAL_NAME.name(),
            NE_SYSTEM_NAME.name(),
            LOCATION.name(),
            CONNECTOR_LOCATION.name(),
            ADMINISTRATIVE_STATE.name(),
            EQUIPMENT_STATE.name(),
            PORT_MODE.name(),
            REQUIRED_APPLICATION_CODE.name(),
            ACTUAL_APPLICATION_CODE.name(),
            PART_NUMBER.name(),
            MODULE_TYPE.name(),
            SERIAL_NUMBER.name(),
            IS_ACTIVE_NE.name()
    };

    private static final CellProcessor[] processors = {
            null,                                   // NE_ID_NAME
            null,                                   // NE_REAL_NAME
            null,                                   // NE_SYSTEM_NAME
            null,                                   // LOCATION
            null,                                   // CONNECTOR_LOCATION
            new Optional(new FormatEnumBase()),     // ADMINISTRATIVE_STATE
            new Optional(new FormatEnumBase()),     // EQUIPMENT_STATE
            null,                                   // PORT_MODE
            null,                                   // REQUIRED_APPLICATION_CODE
            null,                                   // ACTUAL_APPLICATION_CODE
            null,                                   // PART_NUMBER
            null,                                   // MODULE_TYPE
            null,                                   // SERIAL_NUMBER
            null                                    // IS_ACTIVE_NE
    };

    public PortWriter(File resource) {
        super(header, mappings, processors, resource, CSV_PREFERENCE);
    }
}
