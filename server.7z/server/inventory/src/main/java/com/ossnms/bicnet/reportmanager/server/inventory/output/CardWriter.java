package com.ossnms.bicnet.reportmanager.server.inventory.output;

import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.ADMINISTRATIVE_STATE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.BOOT_FWCODE_NUMBER;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.CARD_MODE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.CLEI;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.CODE_NUMBER;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.CODE_NUMBER2;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.COMPACT_FLASH_CARD;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.DIRECTION;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.EQUIPMENT_STATE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.EXPECTED_EQUIPMENT_TYPE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.INSTALLED_EQUIPMENT_TYPE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.IS_ACTIVE_NE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.LOCATION;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.NE_ID_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.NE_REAL_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.NE_SYSTEM_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.CardElements.SERIAL_NUMBER;
import static com.ossnms.bicnet.reportmanager.server.csv.CsvFormat.CSV_PREFERENCE;

import java.io.File;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ift.CellProcessor;

import com.ossnms.bicnet.bcb.model.inventoryMgmt.Card;
import com.ossnms.bicnet.reportmanager.server.csv.CsvItemWriter;
import com.ossnms.bicnet.reportmanager.server.support.FormatEnumBase;

/**
 * Card configuration for CsvItemWriter
 */
public class CardWriter extends CsvItemWriter<Card> {


    private static final String[] header = {
            "NE name",
            "NE Network Name",
            "NE/System Name",
            "Location",
            "Expected equipment type",
            "Installed equipment type",
            "Serial number",
            "Boot FW/SW code number",
            "HW code number",
            "HW code number (2nd)",
            "Common language equipment identifier",
            "Administrative state",
            "Equipment state",
            "Card mode",
            "Direction",
            "Compact flash card",
            "Active NE"
    };
    private static final String[] mappings = {
            NE_ID_NAME.name(),
            NE_REAL_NAME.name(),
            NE_SYSTEM_NAME.name(),
            LOCATION.name(),
            EXPECTED_EQUIPMENT_TYPE.name(),
            INSTALLED_EQUIPMENT_TYPE.name(),
            SERIAL_NUMBER.name(),
            BOOT_FWCODE_NUMBER.name(),
            CODE_NUMBER.name(),
            CODE_NUMBER2.name(),
            CLEI.name(),
            ADMINISTRATIVE_STATE.name(),
            EQUIPMENT_STATE.name(),
            CARD_MODE.name(),
            DIRECTION.name(),
            COMPACT_FLASH_CARD.name(),
            IS_ACTIVE_NE.name()
    };

    private static final CellProcessor[] processors = {
            null,                                   // NE_ID_NAME
            null,                                   // NE_REAL_NAME
            null,                                   // NE_SYSTEM_NAME
            null,                                   // LOCATION
            null,                                   // EXPECTED_EQUIPMENT_TYPE
            null,                                   // INSTALLED_EQUIPMENT_TYPE
            null,                                   // SERIAL_NUMBER
            null,                                   // BOOT_FWCODE_NUMBER
            null,                                   // CODE_NUMBER
            null,                                   // CODE_NUMBER2
            null,                                   // CLEI
            new Optional(new FormatEnumBase()),     // ADMINISTRATIVE_STATE,
            new Optional(new FormatEnumBase()),     // EQUIPMENT_STATE,
            new Optional(new FormatEnumBase()),     // CARD_MODE,
            null,                                   // DIRECTION,
            null,                                   // COMPACT_FLASH_CARD,
            null                                    // IS_ACTIVE_NE
    };

    public CardWriter(File resource) {
        super(header, mappings, processors, resource, CSV_PREFERENCE);
    }
}
