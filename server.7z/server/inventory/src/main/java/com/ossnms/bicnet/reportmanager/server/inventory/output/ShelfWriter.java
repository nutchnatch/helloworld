package com.ossnms.bicnet.reportmanager.server.inventory.output;

import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.ACTUAL_SHELF_TYPE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.BOOT_FWCODE_NUMBER;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.CLEI;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.CODE_NUMBER;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.CODE_NUMBER2;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.DIRECTIONS;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.IS_ACTIVE_NE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.LOCATION;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.NE_ID_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.NE_REAL_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.NE_SUB_TYPE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.NE_SYSTEM_NAME;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.NE_TYPE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.REQUIRED_SHELF_TYPE;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.SERIAL_NUMBER;
import static com.ossnms.bicnet.bcb.model.inventoryMgmt.ShelfElements.SHELF_SUBSYSTEM_ID;
import static com.ossnms.bicnet.reportmanager.server.csv.CsvFormat.CSV_PREFERENCE;

import java.io.File;

import org.supercsv.cellprocessor.ift.CellProcessor;

import com.ossnms.bicnet.bcb.model.inventoryMgmt.Shelf;
import com.ossnms.bicnet.reportmanager.server.csv.CsvItemWriter;

/**
 * Shelf configuration for CsvItemWriter
 */
public class ShelfWriter extends CsvItemWriter<Shelf> {

    private static final String[] header = {
            "NE name",
            "NE Network Name",
            "NE/System Name",
            "Location",
            "NE type",
            "NE subtype",
            "Required shelf type",
            "Actual shelf type",
            "Serial number",
            "Boot FW/SW code number",
            "HW code number",
            "HW code number (2nd)",
            "Common language equipment identifier",
            "Shelf subsystem identifier",
            "Directions",
            "Active NE"
    };

    private static final String[] mappings = {
            NE_ID_NAME.name(),
            NE_REAL_NAME.name(),
            NE_SYSTEM_NAME.name(),
            LOCATION.name(),
            NE_TYPE.name(),
            NE_SUB_TYPE.name(),
            REQUIRED_SHELF_TYPE.name(),
            ACTUAL_SHELF_TYPE.name(),
            SERIAL_NUMBER.name(),
            BOOT_FWCODE_NUMBER.name(),
            CODE_NUMBER.name(),
            CODE_NUMBER2.name(),
            CLEI.name(),
            SHELF_SUBSYSTEM_ID.name(),
            DIRECTIONS.name(),
            IS_ACTIVE_NE.name()
    };

    private static final CellProcessor[] processors = new CellProcessor[mappings.length];

    public ShelfWriter(File resource) {
        super(header, mappings, processors, resource, CSV_PREFERENCE);
    }
}
