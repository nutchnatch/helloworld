package com.ossnms.bicnet.reportmanager.server.inventory.input;

import static java.util.stream.Collectors.toList;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.inventoryMgmt.IInventoryExportFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.Port;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.PortReply;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;

public class InventoryItemReaderTest {

    private ISessionContext mockContext;
    private IInventoryExportFacade mockInventory;
    private int pageSize;

    @Before public void setUp() throws BcbException {
        pageSize = 5;
        mockContext = mock(ISessionContext.class);
        mockInventory = mock(IInventoryExportFacade.class);
    }

    @Test public void nullDataReply() throws BcbException {
        // given empty inventory
        PortReply nullDataReply = new PortReply(true, null);
        when(mockInventory.getPorts(mockContext, 0, pageSize)).thenReturn(nullDataReply);

        // then read item should be null
        Port reply = readPort();
        assertEquals(reply, null);
    }

    @Test public void emptyReply() throws BcbException {
        // given empty inventory
        PortReply emptyReply = new PortReply(true, new Port[0]);
        when(mockInventory.getPorts(mockContext, 0, pageSize)).thenReturn(emptyReply);

        // then read item should be null
        Port reply = readPort();
        assertEquals(reply, null);
    }

    @Test public void nonEmptyReply() throws BcbException {
        // given not empty inventory
        PortReply notEmptyReply = new PortReply(true, new Port[]{new Port()});
        when(mockInventory.getPorts(mockContext, 0, pageSize)).thenReturn(notEmptyReply);

        // then read item should be not null
        assertThat(readPort(), notNullValue());
    }

    @Test public void lessThanOnePage() throws BcbException {
        // given inventory with 1 item but requested more items
        Port[] inventoryItems = {new Port()};
        when(mockInventory.getPorts(mockContext, 0, pageSize)).thenReturn(new PortReply(true, inventoryItems));

        // then read items should contain only inventory items
        assertThat(readPorts().size(), is(inventoryItems.length));
    }

    @Test public void severalPages() throws BcbException {
        // given inventory with data for 3 pages
        Port[] pageData = new Port[pageSize];
        Arrays.fill(pageData, new Port());
        when(mockInventory.getPorts(mockContext, 0, pageSize)).thenReturn(new PortReply(false, pageData));
        when(mockInventory.getPorts(mockContext, pageSize, pageSize)).thenReturn(new PortReply(false, pageData));
        when(mockInventory.getPorts(mockContext, 2 * pageSize, pageSize)).thenReturn(new PortReply(true, pageData));

        // then read items should contain all inventory data
        assertThat(readPorts().size(), is(3 * pageData.length));
    }

    private Port readPort() throws BcbException {
        ItemReader<Port> reader = new PortReader(mockContext, mockInventory, pageSize);
        reader.open();
        return reader.readItem();
    }

    private List<Port> readPorts() {
        PortReader reader = new PortReader(mockContext, mockInventory, pageSize);
        reader.open();
        return reader.read().collect(toList());
    }
}