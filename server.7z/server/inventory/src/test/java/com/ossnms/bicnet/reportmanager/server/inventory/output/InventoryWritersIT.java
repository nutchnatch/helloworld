package com.ossnms.bicnet.reportmanager.server.inventory.output;

import static java.util.Arrays.asList;
import static org.apache.commons.io.FileUtils.readLines;
import static org.hamcrest.Matchers.contains;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.util.List;

import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.AdministrativeState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CardModeType;
import com.ossnms.bicnet.bcb.model.elementMgmt.EquipmentState;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.Card;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.Port;
import com.ossnms.bicnet.bcb.model.inventoryMgmt.Shelf;

public class InventoryWritersIT {

    @Rule public TemporaryFolder tempFolder = new TemporaryFolder();

    @Test public void testShelfExport() throws Exception {
        //given shelves to export
        List shelves = asList(
                new Shelf("7090_60M_2", "10.46.211.102", "7090_60M_2", "1", "7090 M 7090-60 2.00 10", null, null, "shelf type", "0-132", "Build 2.3.0_p30", null, null, null, "0", "0 + 0 + 0 + 0 + 0 + 0", true),
                new Shelf());

        //when shelves are exported
        File exportFile = tempFolder.newFile();
        write(shelves, new ShelfWriter(exportFile));

        //then export file should contain header and shelves rows
        assertThat(readLines(exportFile), contains(
                "\"NE name\",\"NE Network Name\",\"NE/System Name\",\"Location\",\"NE type\",\"NE subtype\",\"Required shelf type\",\"Actual shelf type\",\"Serial number\",\"Boot FW/SW code number\",\"HW code number\",\"HW code number (2nd)\",\"Common language equipment identifier\",\"Shelf subsystem identifier\",\"Directions\",\"Active NE\"",
                "\"7090_60M_2\",\"10.46.211.102\",\"7090_60M_2\",\"1\",\"7090 M 7090-60 2.00 10\",,,\"shelf type\",\"0-132\",\"Build 2.3.0_p30\",,,,\"0\",\"0 + 0 + 0 + 0 + 0 + 0\",\"true\"",
                ",,,,,,,,,,,,,,,\"false\""));
    }

    @Test public void testCardExport() throws Exception {
        //given cards to export
        List cards = asList(
                new Card("7090_60M_2", "10.46.211.102", "7090_60M_2", "1-1-2", "IG08", "IG08", "CXQEN000062S42024-L5813-A1-1", "CPLD 3703:00.02,PCB:0", null, null, null, null, EquipmentState.IN_SERVICE, CardModeType.NOT_APPLICABLE, "0", "", false),
                new Card());

        //when cards are exported
        File exportFile = tempFolder.newFile();
        write(cards, new CardWriter(exportFile));

        //then export file should contain header and cards rows
        assertThat(readLines(exportFile), contains(
                "\"NE name\",\"NE Network Name\",\"NE/System Name\",\"Location\",\"Expected equipment type\",\"Installed equipment type\",\"Serial number\",\"Boot FW/SW code number\",\"HW code number\",\"HW code number (2nd)\",\"Common language equipment identifier\",\"Administrative state\",\"Equipment state\",\"Card mode\",\"Direction\",\"Compact flash card\",\"Active NE\"",
                "\"7090_60M_2\",\"10.46.211.102\",\"7090_60M_2\",\"1-1-2\",\"IG08\",\"IG08\",\"CXQEN000062S42024-L5813-A1-1\",\"CPLD 3703:00.02,PCB:0\",,,,,\"In Service\",\"Not Applicable\",\"0\",\"\",\"false\"",
                ",,,,,,,,,,,,,,,,\"false\""));
    }

    @Test public void testPortExport() throws Exception {
        //given ports to export
        List ports = asList(
                new Port("7090_60M_2", "10.46.211.102", "7090_60M_2", "1-1-1.xg-1", null, AdministrativeState.UNLOCKED, null, "10GbE", "RateMatch", "10GBASE_LR", "FTLX1472M3BCL-T1", "WOCUALLGAB", null, "USJ15TWB", true),
                new Port());

        //when ports are exported
        File exportFile = tempFolder.newFile();
        write(ports, new PortWriter(exportFile));

        //then export file should contain header and ports rows
        assertThat(readLines(exportFile), contains(
                "\"NE name\",\"NE Network Name\",\"NE/System Name\",\"Location\",\"Connector location\",\"Administrative state\",\"Equipment state\",\"Port mode\",\"Required application code\",\"Actual application code\",\"Part number\",\"Module type\",\"Serial number\",\"Active NE\"",
                "\"7090_60M_2\",\"10.46.211.102\",\"7090_60M_2\",\"1-1-1.xg-1\",,\"Unlocked\",,\"10GbE\",\"RateMatch\",\"10GBASE_LR\",\"FTLX1472M3BCL-T1\",,\"USJ15TWB\",\"true\"",
                ",,,,,,,,,,,,,\"false\""));
    }

    private static void write(List items, ItemWriter writer) throws BcbException {
        writer.open();
        writer.writeItems(items);
        writer.close();
    }
}