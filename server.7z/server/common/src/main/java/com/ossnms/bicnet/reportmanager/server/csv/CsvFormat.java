package com.ossnms.bicnet.reportmanager.server.csv;

import org.supercsv.prefs.CsvPreference;
import org.supercsv.prefs.CsvPreference.Builder;
import org.supercsv.quote.AlwaysQuoteMode;

public interface CsvFormat {
    CsvPreference CSV_PREFERENCE = new Builder('"', ',', "\n").useQuoteMode(new AlwaysQuoteMode()).build();
}
