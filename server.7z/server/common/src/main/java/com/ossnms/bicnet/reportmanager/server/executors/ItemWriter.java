package com.ossnms.bicnet.reportmanager.server.executors;

import com.ossnms.bicnet.bcb.model.BcbException;

/**
 * ItemWriter defines the batch artifact that writes to a
 * list of items for chunk processing.
 */
public interface ItemWriter<Item> {

    /**
     * The writeItems method writes a list of item
     * for the current chunk.
     *
     * @param item specifies the list of items to write.
     */
    void writeItems(Item item) throws BcbException;

    /**
     * The open method prepares the writer to write items.
     *
     * @throws BcbException is thrown for any errors.
     */
    default void open() throws BcbException {
    }

    /**
     * The close method marks the end of use of the
     * ItemWriter.
     *
     * @throws BcbException is thrown for any errors.
     */
    default void close() throws BcbException {
    }
}
