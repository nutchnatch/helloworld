package com.ossnms.bicnet.reportmanager.server.runtime;

import com.ossnms.bicnet.reportmanager.dcn.messaging.input.IItemExecutor;

/**
 * Basic Execution Step configuration container
 */
public class ExecutionStep implements IExecutionConfiguration {
    private final IItemExecutor executor;

    public ExecutionStep(IItemExecutor executor){
        this.executor = executor;
    }

    @Override public IItemExecutor getExecutor() {
        return executor;
    }

}
