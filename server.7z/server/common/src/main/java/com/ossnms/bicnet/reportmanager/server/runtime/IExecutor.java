package com.ossnms.bicnet.reportmanager.server.runtime;

import com.ossnms.bicnet.bcb.model.BcbException;

import java.util.List;

public interface IExecutor extends JobCancellableListener {

    boolean accept(Configuration configuration);

    List<Object> process() throws BcbException;
}
