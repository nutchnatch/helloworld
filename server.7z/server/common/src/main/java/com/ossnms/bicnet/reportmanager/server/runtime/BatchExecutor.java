package com.ossnms.bicnet.reportmanager.server.runtime;


import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.ItemProcessor;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;
import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;

public class BatchExecutor extends StepExecutor{
    public static final Logger LOGGER = LoggerFactory.getLogger(BatchExecutor.class);

    private final ItemReader reader;
    private final ItemWriter writer;
    private final ItemProcessor processor;

    public BatchExecutor(IStepConfiguration configuration) {
        reader = configuration.getReader();
        writer = configuration.getWriter();
        processor = configuration.getProcessor();
    }

    @Override
    public List<Object> process() throws BcbException {
        LOGGER.debug("Started step");
        
        open();
        for(Object item = readItem(); item != null; item = readItem()) {
            write(process(item));
        }
        close();

        LOGGER.debug("Finished step");
        return new ArrayList<>();
    }

    private void write(Object writeItem) throws BcbException {
        if (writer != null) {
            writer.writeItems(writeItem);
        }
    }

    private Object process(Object readItem) throws BcbException {
        return processor == null ? readItem : processor.processItem(readItem);
    }

    private Object readItem() throws BcbException {
        return reader == null ? null : reader.readItem();
    }

    private void close() throws BcbException {
        if (reader != null) {
            reader.close();
        }

        if (writer != null) {
            writer.close();
        }
    }

    private void open() throws BcbException {
        if (reader != null) {
            reader.open();
        }

        if (writer != null) {
            writer.open();
        }
    }

    @Override
    public boolean accept(Configuration configuration) {
        return configuration instanceof IStepConfiguration;
    }
}
