package com.ossnms.bicnet.reportmanager.server.servicelocator;

import java.lang.reflect.Type;
import java.util.Set;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class BeanUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(BeanUtils.class);

    private BeanUtils() {
    }

    /**
     * Lookups BeanManager from InitialContext
     * @return bean manager instance
     */
    public static BeanManager lookupBeanManager() {
        try {
            Context initialContext = new InitialContext();
            return (BeanManager) initialContext.lookup("java:comp/BeanManager");
        } catch (NamingException e) {
            LOGGER.error("Couldn't get BeanManager through JNDI");
            return null;
        }
    }

    /**
     * Resolves bean for specified type using bean manager
     * @param type requested bean type
     * @param <T> type of requested bean
     * @return resolved bean
     */
    public static <T> T getBean(Type type) {
        BeanManager beanManager = lookupBeanManager();
        if (beanManager == null) {
            return null;
        }
        return resolveBean(beanManager, beanManager.getBeans(type));
    }

    /**
     * Resolves bean with specified name using bean manager
     * @param name requested bean name
     * @param <T> type of requested bean
     * @return resolved bean
     */
    public static <T> T getBean(String name) {
        BeanManager beanManager = lookupBeanManager();
        if (beanManager == null) {
            return null;
        }
        return resolveBean(beanManager, beanManager.getBeans(name));
    }

    private static <T> T resolveBean(BeanManager bm, Set<Bean<?>> beans) {
        Bean<?> bean = bm.resolve(beans);
        if (bean == null) {
            return null;
        }
        CreationalContext<?> ctx = bm.createCreationalContext(bean);
        return (T) bm.getReference(bean, bean.getBeanClass(), ctx);
    }

    public static <T> T resolveBeanBayInterface(Class interfaceReference){
            final BeanManager beanManager = lookupBeanManager();
            final Set<Bean<?>> beans = beanManager.getBeans(interfaceReference);
            final Bean<?> bean = beanManager.resolve(beans);
            final CreationalContext<?> creationalContext = beanManager.createCreationalContext(bean);
            return (T) beanManager.getReference(bean, interfaceReference, creationalContext);
    }
}
