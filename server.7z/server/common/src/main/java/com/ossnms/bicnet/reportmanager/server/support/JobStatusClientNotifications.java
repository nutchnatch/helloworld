package com.ossnms.bicnet.reportmanager.server.support;

import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.model.ReportData;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;

/**
 * JobListener that notifies client about status of current report
 */
public class JobStatusClientNotifications implements JobListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(JobStatusClientNotifications.class);
    private final ISessionContext sessionContext;
    private final ReportData reportData;

    public JobStatusClientNotifications(ISessionContext sessionContext, ReportData reportData) {
        this.sessionContext = sessionContext;
        this.reportData = reportData;
    }

    @Override public void beforeJob(JobExecution jobExecution) {
        notifyClient(jobExecution);
    }

    @Override public void afterJob(JobExecution jobExecution) {
        notifyClient(jobExecution);
    }

    private void notifyClient(JobExecution jobExecution) {
        try {
            reportData.notifyClient(sessionContext, jobExecution.getJobName());
        } catch (BcbException e) {
            LOGGER.warn("Failed to notify client", e);
        }
    }
}
