package com.ossnms.bicnet.reportmanager.server.events;

import rx.Observable;

import javax.ejb.Local;

@Local
public interface EventSource<T> {

    void subscribe();

    Observable<T> observe();
}
