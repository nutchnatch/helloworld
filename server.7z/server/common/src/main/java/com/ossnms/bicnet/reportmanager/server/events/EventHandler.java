package com.ossnms.bicnet.reportmanager.server.events;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.functions.Action1;

import javax.annotation.Nonnull;

public abstract class EventHandler<T> implements Action1<T> {

    protected EventHandler() {

    }

    @Override
    public final void call(T event) {
        final Logger logger = LoggerFactory.getLogger(getClass());
            logger.info("Processing event {}.", event);
            handleEvent(event);
    }

    protected abstract void handleEvent(@Nonnull T event);

}
