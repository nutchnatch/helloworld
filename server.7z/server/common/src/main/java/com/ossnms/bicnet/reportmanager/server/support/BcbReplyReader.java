package com.ossnms.bicnet.reportmanager.server.support;

import static java.util.Collections.addAll;
import static java.util.stream.StreamSupport.stream;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Optional;
import java.util.Queue;
import java.util.Spliterators.AbstractSpliterator;
import java.util.function.Consumer;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;

public abstract class BcbReplyReader<ID, ITEM, REPLY> implements ItemReader<ITEM> {
    private static final Logger LOGGER = LoggerFactory.getLogger(BcbReplyReader.class);
    private Iterator<ITEM> iterator;

    @Override public void open() {
        iterator = read().iterator();
    }

    @Override public ITEM readItem() {
        return iterator.hasNext() ? iterator.next() : null;
    }

    public Stream<ITEM> read() {
        return stream(new SpliteratorReader<>(this), false);
    }

    protected abstract REPLY nextReply(ID lastId) throws BcbException;

    protected abstract ITEM[] data(REPLY reply);

    protected abstract ID lastId(REPLY reply);

    protected abstract boolean isLast(REPLY reply);

    private static final class SpliteratorReader<ID, ITEM, REPLY> extends AbstractSpliterator<ITEM> {
        private final BcbReplyReader<ID, ITEM, REPLY> replyReader;
        private final Queue<ITEM> queue = new ArrayDeque<>();
        private ID lastId;
        private boolean hasLastReply;

        private SpliteratorReader(BcbReplyReader<ID, ITEM, REPLY> replyReader) {
            super(Long.MAX_VALUE, 0);
            this.replyReader = replyReader;
        }

        @Override public boolean tryAdvance(Consumer<? super ITEM> action) {
            if (queue.isEmpty()) {
                requestNext();
            }

            if (queue.isEmpty()) {
                return false;
            } else {
                action.accept(queue.poll());
                return true;
            }
        }

        private void requestNext() {
            try {
                if (!hasLastReply) {
                    Optional<REPLY> reply = Optional.ofNullable(replyReader.nextReply(lastId));
                    reply.map(replyReader::data).ifPresent(data -> addAll(queue, data));
                    lastId = reply.map(replyReader::lastId).orElse(null);
                    hasLastReply = reply.map(replyReader::isLast).orElse(true);
                }
            } catch (BcbException e) {
                LOGGER.error("Failed to read a reply", e);
            }
        }

    }
}
