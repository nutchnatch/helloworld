package com.ossnms.bicnet.reportmanager.server.remote;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.ecs.IECSFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ecs.FileSettings;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;

/**
 * ItemWriter that exports (remotely) each file item.
 */
public class RemoteExport implements ItemWriter<File> {

    public static final Logger LOGGER = LoggerFactory.getLogger(RemoteExport.class);
    private final TransferSettings transferSettings;
    private ISessionContext sessionContext;
    private IECSFacade ecsFacade;
    private String relativePath;
    private List<File> filesToExport = new ArrayList<>();

    /**
     * Remote Export
     *
     * @param sessionContext   - User session context
     * @param ecsFacade        - External Communication Service Facade
     * @param transferSettings - Transfer settings (settings configured by the user)
     * @param relativePath     - Relative path to be used in the remote server
     */
    public RemoteExport(ISessionContext sessionContext, IECSFacade ecsFacade, TransferSettings transferSettings, String relativePath) {
        this.transferSettings = transferSettings;
        this.sessionContext = sessionContext;
        this.ecsFacade = ecsFacade;
        this.relativePath = relativePath;
    }

    @Override public void writeItems(File iter) throws BcbException {
        filesToExport.add(iter);
    }

    @Override public void close() throws BcbException {
        uploadFiles(filesToExport);
    }

    public void uploadFiles(List<File> files) throws BcbException {
        String[] fileNames = files.stream().map(File::getName).toArray(String[]::new);

        Optional<FileSettings> fileSettings = files.stream().findFirst()
                .map(file -> file.getAbsolutePath().split(file.getName())[0])
                .map(localDirectory -> new FileSettings(localDirectory, fileNames, relativePath));

        try {
            if (fileSettings.isPresent()) {
                ecsFacade.uploadFile(sessionContext, transferSettings, fileSettings.get());
                LOGGER.debug("Send files to remote server");
            }
        } catch (BcbException e) {
            throw new BcbException("Unable to send file to a remote server", e);
        }
    }
}