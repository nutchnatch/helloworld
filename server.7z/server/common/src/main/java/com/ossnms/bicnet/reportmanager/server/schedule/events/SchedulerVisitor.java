package com.ossnms.bicnet.reportmanager.server.schedule.events;

import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution.IVisitor;

public interface SchedulerVisitor extends IVisitor {
}
