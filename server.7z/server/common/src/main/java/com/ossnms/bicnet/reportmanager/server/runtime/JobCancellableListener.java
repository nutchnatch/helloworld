package com.ossnms.bicnet.reportmanager.server.runtime;


public interface JobCancellableListener {
    void cancelRequested();
}
