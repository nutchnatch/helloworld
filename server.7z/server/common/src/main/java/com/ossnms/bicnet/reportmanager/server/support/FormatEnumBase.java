package com.ossnms.bicnet.reportmanager.server.support;

import org.supercsv.cellprocessor.CellProcessorAdaptor;
import org.supercsv.exception.SuperCsvCellProcessorException;
import org.supercsv.util.CsvContext;

import com.ossnms.bicnet.bcb.model.EnumBase;

/**
 * Cell Processor for {@link org.supercsv.io.CsvBeanWriter} that formats BCB EnumBase class
 */
public class FormatEnumBase extends CellProcessorAdaptor {

    @Override public Object execute(Object value, CsvContext context) {
        validateInputNotNull(value, context);

        if (!(value instanceof EnumBase)) {
            throw new SuperCsvCellProcessorException(EnumBase.class, value, context, this);
        }

        String result = ((EnumBase) value).guiLabel();
        return next.execute(result, context);
    }
}
