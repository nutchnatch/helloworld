package com.ossnms.bicnet.reportmanager.server.events;

public class ExportEvent implements Event{
}
