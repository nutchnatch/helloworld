package com.ossnms.bicnet.reportmanager.server.runtime;

public enum BatchStatus {
    STARTING, STARTED, STOPPING, FAILED, FINISHED, CANCELED
}
