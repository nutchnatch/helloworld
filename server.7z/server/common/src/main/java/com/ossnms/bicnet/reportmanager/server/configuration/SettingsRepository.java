package com.ossnms.bicnet.reportmanager.server.configuration;

import com.ossnms.bicnet.reportmanager.api.SystemSettings;

import java.nio.file.Path;

public interface SettingsRepository {
    Integer inventoryRetentionNumber();
    
    Integer configurationRetentionNumber();
    
    Integer outageRetentionNumber();

    SystemSettings getDto();

    void persistDto(SystemSettings settings);

    Path getInventoryExportPath();

    Path getConfigurationExportPath();
    
    Path getOutageExportPath();
}