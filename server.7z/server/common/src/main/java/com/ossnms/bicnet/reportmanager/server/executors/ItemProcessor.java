package com.ossnms.bicnet.reportmanager.server.executors;

import com.ossnms.bicnet.bcb.model.BcbException;

/**
 * ItemProcessor is used in chunk processing
 * to operate on an input item and produce
 * an output item.
 */
public interface ItemProcessor<I, O> {

    /**
     * The processItem method is part of a chunk
     * step. It accepts an input item from an
     * item reader and returns an item that gets
     * passed onto the item writer. Returning null
     * indicates that the item should not be continued
     * to be processed.  This effectively enables processItem
     * to filter out unwanted input items.
     *
     * @param item specifies the input item to process.
     * @return output item to write.
     */
    O processItem(I item) throws BcbException;
}
