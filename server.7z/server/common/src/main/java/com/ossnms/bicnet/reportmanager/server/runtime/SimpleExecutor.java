package com.ossnms.bicnet.reportmanager.server.runtime;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.dcn.messaging.input.IItemExecutor;

import java.util.List;

public class SimpleExecutor extends StepExecutor {

    private final IItemExecutor executor;
    public SimpleExecutor(IExecutionConfiguration configuration) {
        executor = configuration.getExecutor();
    }

    @Override
    public List<Object> process() throws BcbException {
        return executor.executeItem();
    }

    @Override
    public boolean accept(Configuration configuration) {
        return configuration instanceof IExecutionConfiguration;
    }
}
