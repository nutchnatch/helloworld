package com.ossnms.bicnet.reportmanager.server.runtime;

import com.ossnms.bicnet.reportmanager.server.executors.ItemProcessor;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;
import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;

public interface IStepConfiguration<I, O> extends Configuration {

    ItemReader<I> getReader();

    ItemProcessor<I, O> getProcessor();

    ItemWriter<O> getWriter();
}
