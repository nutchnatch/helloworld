package com.ossnms.bicnet.reportmanager.server.executors;

public interface IReader {
}
