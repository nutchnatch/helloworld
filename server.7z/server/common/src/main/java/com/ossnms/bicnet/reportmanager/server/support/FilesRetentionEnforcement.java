/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.support;

import com.ossnms.bicnet.reportmanager.server.files.PathFilter;
import com.ossnms.bicnet.reportmanager.server.files.FilesManager;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;

/**
 * Job listener that enforce export files retention after job execution
 */
public class FilesRetentionEnforcement implements JobListener {

    private final FilesManager filesManager;
    private final PathFilter filesFilter;

    public FilesRetentionEnforcement(FilesManager filesManager, PathFilter filesFilter) {
        this.filesManager = filesManager;
        this.filesFilter = filesFilter;
    }

    @Override public void beforeJob(JobExecution execution) {
    }

    @Override public void afterJob(JobExecution execution) {
        filesManager.enforceRetention(filesFilter);
    }
}
