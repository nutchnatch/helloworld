package com.ossnms.bicnet.reportmanager.server.runtime;

import com.ossnms.bicnet.reportmanager.dcn.messaging.input.IItemExecutor;

public interface IExecutionConfiguration extends Configuration{

    IItemExecutor getExecutor();
}
