/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportmanager.server.files;

import com.google.common.collect.Ordering;

import java.nio.file.Path;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

/**
 * PathFilter that ensures that there are no more than specified number of export results
 */
public class RetentionNumberOfGroupsFilter implements PathFilter {

    private final int retentionNumber;
    private static final Ordering<String> ORDERING = Ordering.natural().reverse();

    private static final Pattern FILE_NAME_PATTERN = Pattern.compile("(.+?)\\-([0-9-_.]+)\\.([^.]+)"); //name-date.ext
    private static final Integer DATE_GROUP = 2;

    /**
     * @param retentionNumber maximum number of file groups
     */
    public RetentionNumberOfGroupsFilter(int retentionNumber) {
        this.retentionNumber = retentionNumber;
    }

    /**
     * @param paths list of paths to filter
     * @return list of files that will not be retained
     */
    @Override public List<Path> apply(List<Path> paths) {
        Map<String, List<Path>> groups = paths.stream()
                .collect(groupingBy(new FileNamePattern(FILE_NAME_PATTERN, DATE_GROUP)));
        
        return groups.entrySet().stream()
                .sorted(comparing(Entry::getKey, ORDERING))
                .skip(retentionNumber)
                .map(Entry::getValue)
                .flatMap(Collection::stream)
                .collect(toList());
    }

    private static final class FileNamePattern implements Function<Path, String> {
        private final Pattern pattern;
        private final Integer group;

        private FileNamePattern(Pattern pattern, Integer group) {
            this.pattern = pattern;
            this.group = group;
        }

        @Override public String apply(Path file) {
            Path fileNamePath = file.getFileName();
            String fileName = fileNamePath == null ? "" : fileNamePath.toString();
            Matcher nameMatcher = pattern.matcher(fileName);
            return nameMatcher.find() 
                    ? nameMatcher.group(group) 
                    : fileName;
        }
    }
}
