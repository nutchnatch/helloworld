package com.ossnms.bicnet.reportmanager.server.runtime;

import com.ossnms.bicnet.reportmanager.server.executors.ItemProcessor;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;
import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;

/**
 * Basic BatchStep configuration container
 */
public class BatchStep<I, O> implements IStepConfiguration<I, O> {
    private final ItemReader<I> reader;
    private final ItemWriter<O> writer;
    private final ItemProcessor<I, O> processor;

    public BatchStep(
            final ItemReader<I> reader,
            final ItemWriter<O> writer) {
        this(reader, null, writer);
    }

    public BatchStep(
            final ItemReader<I> reader,
            final ItemProcessor<I, O> processor,
            final ItemWriter<O> writer) {
        this.reader = reader;
        this.writer = writer;
        this.processor = processor;
    }

    @Override public ItemReader<I> getReader() {
        return reader;
    }

    @Override public ItemProcessor<I,O> getProcessor() {
        return processor;
    }

    @Override public ItemWriter<O> getWriter() {
        return writer;
    }

}
