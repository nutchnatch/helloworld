package com.ossnms.bicnet.reportmanager.server.zip;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;

/**
 * ItemWriter that adds each file item to the zip archive
 */
public class ZipFiles implements ItemWriter<File> {

    public static final Logger LOGGER = LoggerFactory.getLogger(ZipFiles.class);
    private final File zipFile;
    private ZipOutputStream zipStream;

    /**
     * @param zipFile destination zip file
     */
    public ZipFiles(File zipFile) {
        this.zipFile = zipFile;
    }

    @Override public void writeItems(File file) throws BcbException {
        try {
            addFileToArchive(file);
        } catch (IOException e) {
            throw new BcbException("Cannot add file to archive", e);
        }
    }

    private void addFileToArchive(File file) throws IOException {
        ZipEntry zipEntry = new ZipEntry(file.getName());
        LOGGER.debug("New entry {}", zipEntry.getName());
        zipStream.putNextEntry(zipEntry);
        FileInputStream fileStream = new FileInputStream(file);
        IOUtils.copy(fileStream, zipStream);
        IOUtils.closeQuietly(fileStream);
    }

    @Override public void open() throws BcbException {
        try {
            zipStream = new ZipOutputStream(new FileOutputStream(zipFile));
            LOGGER.debug("Start archive {}", zipFile.getName());
        } catch (FileNotFoundException e) {
            throw new BcbException("Cannot open file", e);
        }
    }

    @Override public void close() throws BcbException {
        IOUtils.closeQuietly(zipStream);
        LOGGER.debug("Done {}", zipFile.getName());
    }
}
