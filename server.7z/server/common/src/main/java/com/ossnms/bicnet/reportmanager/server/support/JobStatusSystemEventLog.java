package com.ossnms.bicnet.reportmanager.server.support;


import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import com.ossnms.bicnet.reportmanager.server.logging.Logger;
import com.ossnms.bicnet.reportmanager.server.runtime.BatchStatus;
import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;
import org.apache.commons.lang3.StringUtils;

import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ExecutionReason;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ExecutionStatus;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ExecutionStatusCanceled;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ExecutionStatusFailed;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ExecutionStatusFinished;
import static com.ossnms.bicnet.reportmanager.server.logging.Messages.ExecutionStatusStarted;
import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * JobListener that logs report status to System Event Log
 */
public class JobStatusSystemEventLog implements JobListener {

    private final ISessionContext context;
    private final Logger logger;
    private final String steps;

    public JobStatusSystemEventLog(ISessionContext sessionContext, Logger logger, String steps) {
        context = sessionContext;
        this.logger = logger;
        this.steps = steps;
    }

    public JobStatusSystemEventLog(ISessionContext sessionContext, Logger logger) {
        this(sessionContext, logger, "");
    }

    @Override public void beforeJob(JobExecution jobExecution) {
        logSystemEvent(jobExecution);
    }

    @Override public void afterJob(JobExecution jobExecution) {
        logSystemEvent(jobExecution);
    }

    private void logSystemEvent(JobExecution jobExecution) {
        String reportId = jobExecution.getJobName();
        BatchStatus status = jobExecution.getBatchStatus();
        String finishStatus = jobExecution.getExitStatus();
        logger.systemEventLog(
                context,
                ExecutionStatus.format(messageOf(status), reportId, steps),
                reportId,
                severityOf(status));
    }

    private String details(String finishStatus) {
        return isEmpty(finishStatus) ? 
                StringUtils.EMPTY : 
                ExecutionReason.format(finishStatus);
    }

    private LogSeverity severityOf(BatchStatus status) {
        switch (status) {
            case FAILED:
                return LogSeverity.ERROR;
            default:
                return LogSeverity.MESSAGE;
        }
    }

    private String messageOf(BatchStatus status) {
        switch (status) {
            case STARTING:
                return ExecutionStatusStarted.format();
            case STARTED:
                return ExecutionStatusStarted.format();
            case STOPPING:
                return ExecutionStatusCanceled.format();
            case FAILED:
                return ExecutionStatusFailed.format();
            case FINISHED:
                return ExecutionStatusFinished.format();
            case CANCELED:
                return ExecutionStatusCanceled.format();
            default:
                return "";
        }
    }
}
