package com.ossnms.bicnet.reportmanager.server.events;

import com.ossnms.bicnet.reportmanager.server.events.EventHandler;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;

public class ExportEventHandler<E> extends EventHandler<E>{

    private List<Integer> numbers = new ArrayList<Integer>();

    @Override
    protected void handleEvent(@Nonnull E event) {
        int i = 0;
        numbers.add(90 + i);
    }
}