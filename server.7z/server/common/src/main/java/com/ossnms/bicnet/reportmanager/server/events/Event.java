package com.ossnms.bicnet.reportmanager.server.events;

public interface Event {
}
