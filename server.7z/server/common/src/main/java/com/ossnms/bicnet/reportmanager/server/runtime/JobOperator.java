package com.ossnms.bicnet.reportmanager.server.runtime;


import com.ossnms.bicnet.bcb.model.BcbException;
import java.util.List;

/**
 * JobOperator provide the interface for operating on batch jobs.
 */
public interface JobOperator {

    /**
     * Creates a new job instance and starts the first execution of that
     * instance.
     *
     * @param jobName specifies the name of bean that implements {@link JobConfiguration} interface
     * @return executionId for the job execution.
     */
    long start(String jobName) throws BcbException;

    /**
     * Starts the execution of specified job
     *
     * @param jobConfiguration specifies the name of bean that implements {@link JobConfiguration} interface
     * @return executionId for the job execution.
     */
    long start(JobConfiguration jobConfiguration) throws BcbException;

    /**
     * Request a running job execution to stop. This
     * method notifies the job execution to stop
     * and then returns. The job execution normally
     * stops and does so asynchronously.
     *
     * @param executionId specifies the job execution to stop.
     */
    void stop(long executionId);

    /**
     * Return all job executions belonging to the specified job configuration.
     *
     * @param jobName job configuration name
     * @return list of job executions
     */
    List<JobExecution> getJobExecutions(String jobName);

    /**
     * Creates job configuration instance
     *
     * @param <T>     specific type of job configuration
     * @throws BcbException if no job for such type and class can be found
     */
    <T extends JobConfiguration> T configuration(Class<T> jobClass) throws BcbException;
}
