package com.ossnms.bicnet.reportmanager.server.executors;

import com.ossnms.bicnet.bcb.model.BcbException;

/**
 * ItemReader defines the batch artifact that reads
 * items for chunk processing.
 */
public interface ItemReader<Item> {

    /**
     * The readItem method returns the next item
     * for chunk processing.
     * It returns null to indicate no more items, which
     * also means the current chunk will be committed and
     * the step will end.
     *
     * @return next item or null
     */
    Item readItem() throws BcbException;

    /**
     * The open method prepares the reader to read items.
     *
     * @throws BcbException is thrown for any errors.
     */
    default void open() throws BcbException {
    }

    /**
     * The close method marks the end of use of the
     * ItemReader.
     *
     * @throws BcbException is thrown for any errors.
     */
    default void close() throws BcbException {
    }
}
