package com.ossnms.bicnet.reportmanager.server.runtime;

import java.util.Date;

public interface JobExecution {
    /**
     * Get unique id for this JobExecution.
     *
     * @return execution id
     */
    Long getExecutionId();

    /**
     * Get job name.
     *
     * @return job configuration name
     */
    String getJobName();

    /**
     * Get status of this execution.
     *
     * @return status value.
     */
    BatchStatus getBatchStatus();

    /**
     * Get time execution started.
     *
     * @return date (time)
     */
    Date getStartTime();

    /**
     * Get time execution entered termination status
     *
     * @return date (time)
     */
    Date getEndTime();

    /**
     * Get exit status message 
     * @return execution finish message
     */
    String getExitStatus();
}
