package com.ossnms.bicnet.reportmanager.server.events;

import javax.annotation.Nullable;

/**
 * Emits events represented by objects of type {@code T}
 * Emission is triggered by calling {@link #push(T)}.
 */
public interface MessageSource<T> {

    void push(@Nullable T message);
}
