package com.ossnms.bicnet.reportmanager.server.listener;


import com.ossnms.bicnet.reportmanager.server.runtime.JobExecution;

/**
 * JobListener intercepts job execution.
 */
public interface JobListener {
    /**
     * The beforeJob method receives control
     * before the job execution begins.
     */
    void beforeJob(JobExecution jobExecution);

    /**
     * The afterJob method receives control
     * after the job execution ends.
     */
    void afterJob(JobExecution jobExecution);
}
