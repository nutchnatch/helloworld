package com.ossnms.bicnet.reportmanager.server.runtime;


import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.listener.JobListener;
import javax.xml.bind.JAXBException;
import java.util.List;

public interface JobConfiguration {

    String getJobName();

    List<Configuration> getSteps();

    List<JobListener> getJobListeners();

    @Deprecated //should be transformed to a step
    default void resultPostProcess(List<Object> objects) {
    }

    @Deprecated //should be transformed to a step
    default void marshall() throws JAXBException, BcbException {
    }
}
