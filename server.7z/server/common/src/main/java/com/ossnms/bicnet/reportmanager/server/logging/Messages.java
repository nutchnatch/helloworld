package com.ossnms.bicnet.reportmanager.server.logging;

import org.apache.commons.lang3.ArrayUtils;

import java.text.MessageFormat;
import java.util.ResourceBundle;

public enum Messages {

    ExecutionStatus("ExecutionStatus"),
    ExecutionStatusStarted("ExecutionStatus.Started"),
    ExecutionStatusCanceled("ExecutionStatus.Canceled"),
    ExecutionStatusFailed("ExecutionStatus.Failed"),
    ExecutionStatusFinished("ExecutionStatus.Finished"),
    ExecutionReason("ExecutionReason"),
    ExecutionReasonTimeout("ExecutionReason.Timeout"),
    ExecutionReasonException("ExecutionReason.Exception"),
    StartedManually("StartedManually"),
    ScheduleStatusChanged("ScheduleStatus.Changed"),
    ScheduleStatusDisabled("ScheduleStatus.Disabled"),
    ACTIVATION("ScheduleAttributes.ACTIVATION"),
    START_TIME("ScheduleAttributes.START_TIME"),
    PERIODIC("ScheduleAttributes.PERIODIC"),
    WEEKLY("ScheduleAttributes.WEEKLY"),
    MONTHLY("ScheduleAttributes.MONTHLY"),
    OCCURENCES_UNTIL("ScheduleAttributes.OCCURENCES_UNTIL"),
    
    CRITERIA_ACTIVATION("AlarmMessagingCriteriaAttributes.ACTIVATION"),
    CRITERIA_ALARMNUMBER("AlarmMessagingCriteriaAttributes.ALARMNUMBER"),
    CRITERIA_SEVERITY("AlarmMessagingCriteriaAttributes.SEVERITY");


    private static final String BASE_NAME = Messages.class.getPackage().getName() + ".messages";
    private static final ResourceBundle PROPERTIES = ResourceBundle.getBundle(BASE_NAME);

    private final String name;

    Messages(String name) {
        this.name = name;
    }

    public String format(Object... args) {
        String pattern = PROPERTIES.getString(name);
        if (ArrayUtils.isEmpty(args)) {
            return pattern;
        }
        return MessageFormat.format(pattern, args);
    }
}
