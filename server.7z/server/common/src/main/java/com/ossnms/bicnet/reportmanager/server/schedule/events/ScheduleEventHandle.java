package com.ossnms.bicnet.reportmanager.server.schedule.events;

import com.google.common.base.Optional;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.ScheduleExecution;
import com.ossnms.bicnet.reportmanager.server.runtime.JobOperator;

public interface ScheduleEventHandle {

    Optional<Long> accept(ScheduleExecution execution, JobOperator jobOperator) throws BcbException;
}
