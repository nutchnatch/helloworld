package com.ossnms.bicnet.reportmanager.server.events;

import javax.annotation.Nullable;
import rx.Observable;
import rx.subjects.PublishSubject;
import rx.subjects.Subject;

/**
 * Provides {@link Observable} that emits objects of type {@code T}.
 * Emission is triggered by calling {@link EventSourceImpl#push(T)}.
 */
public class EventSourceImpl<T> implements MessageSource<T> {

    private final Subject<T, T> subject;
    private final Observable<T> observable;

    protected EventSourceImpl(){
        subject = PublishSubject.<T>create().toSerialized();
        observable = subject.asObservable().onBackpressureBuffer();
    }

    /**
     * Subscribes to an observable. Items emitted will be forwarded
     * through to any subscribers of this instance of {@code MessageSource}.
     * @param observable An instance of {@link Observable}.
     */
    protected void chain(Observable<? extends T> observable){
        observable.subscribe(subject);
    }

    public Observable<T> observe(){
        return observable;
    }

    @Override
    public void push(@Nullable T message) {
        subject.onNext(message);
    }
}
