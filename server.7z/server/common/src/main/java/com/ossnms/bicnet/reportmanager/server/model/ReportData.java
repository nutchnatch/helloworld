package com.ossnms.bicnet.reportmanager.server.model;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;

public interface ReportData {
    ReportDataDto getReportData(ISessionContext sessionContext, String reportId) throws BcbException;

    void notifyClient(ISessionContext sessionContext, String reportId) throws BcbException;
}
