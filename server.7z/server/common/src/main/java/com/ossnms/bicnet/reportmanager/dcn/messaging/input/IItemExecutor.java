package com.ossnms.bicnet.reportmanager.dcn.messaging.input;

import com.ossnms.bicnet.bcb.model.BcbException;

import java.util.List;

public interface IItemExecutor {

    List<Object> executeItem() throws BcbException;
    String getName();
}
