package com.ossnms.bicnet.reportmanager.dcn.messaging.input;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.IReaderBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.schedulers.Schedulers;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public abstract class ItemExecution implements IItemExecutor {
    private static final Logger LOGGER = LoggerFactory.getLogger(ItemExecution.class);

    private <T> Observable<T> getItemObservable(Observable<IReaderBuilder> searchReader) {
        return searchReader.flatMap(this::readObject);
    }

    private <T> Observable<T> readObject(IReaderBuilder readerBuilder) {
        try {
            return processItem(readerBuilder.readObject());
        } catch (BcbException | ExecutionException | InterruptedException e) {
            LOGGER.error("Error requesting data from reader", e);
            return Observable.empty();
        }
    }

    protected <T> List<T> processReaders(Iterable<IReaderBuilder> exportableItems) {
        Observable<IReaderBuilder> searchReader = getStepReaders(exportableItems);
        Observable<T> returned = getItemObservable(searchReader);
        return getItemsToBeExported(returned);
    }

    private Observable<IReaderBuilder> getStepReaders(Iterable<IReaderBuilder> exportableItems) {
        return getReaders(exportableItems)
                .doOnSubscribe(() -> LOGGER.debug("Getting Readers."));
    }

    private Observable<IReaderBuilder> getReaders(Iterable<IReaderBuilder> exportableItems) {
        return fetchData(buildReaders(exportableItems));
    }

    private <T> List<T> getItemsToBeExported(final Observable<T> returnedItems) {
        return returnedItems.toList()
                .doOnCompleted(() -> LOGGER.debug("Got Items to be Exported. {}", returnedItems))
                .toBlocking().single();
    }

    protected abstract Collection<IReaderBuilder> buildReaders(Iterable<IReaderBuilder> exportableItems);

    private static <T> Observable<T> processItem(final Future<T> item) {
        return Observable.from(item).subscribeOn(Schedulers.io())
                .doOnSubscribe(() -> LOGGER.debug("Processing future result."))
                .doOnCompleted(() -> LOGGER.debug("Item processing completed."));
    }

    private static <T> Observable<T> fetchData(final Collection<T> builders) {
        return Observable.from(builders).subscribeOn(Schedulers.io());
    }
}
