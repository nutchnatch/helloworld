package com.ossnms.bicnet.reportmanager.server.executors;

public class Item {

    private Object item;

    public Item(Object item){
        this.item = item;
    }

    public Object getItem() {
        return item;
    }
}
