package com.ossnms.bicnet.reportmanager.server.executors;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.runtime.IExportReadExecution;

import java.io.Serializable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public interface IReaderBuilder<T> extends IReader, Serializable {

    Future<T> readObject() throws BcbException, ExecutionException, InterruptedException;

    void setExecution(IExportReadExecution execution);

    String getName();

}
