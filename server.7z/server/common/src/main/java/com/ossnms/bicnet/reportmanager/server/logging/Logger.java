package com.ossnms.bicnet.reportmanager.server.logging;

import static com.ossnms.bicnet.reportmanager.util.Constants.BICNET_COMPONENT_TYPE;
import static org.apache.commons.lang3.StringUtils.defaultIfBlank;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.ossnms.bicnet.reportmanager.server.util.BiCNet;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.logMgmt.CommandLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogMgrFacade;
import com.ossnms.bicnet.bcb.facade.logMgmt.SystemEventLogRecordItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.logMgmt.ICommandLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.IDescriptionFacet;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordSourceFacet;
import com.ossnms.bicnet.bcb.model.logMgmt.ISystemEventLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.IUserNameFacet;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;

/**
 * Helper bean to log events to {@link ILogMgrFacade}
 */
@Stateless
public class Logger {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(Logger.class);

    private ILogMgrFacade logManager;

    public Logger() {
    }

    @Inject public Logger(@BiCNet ILogMgrFacade logManager) {
        this.logManager = logManager;
    }

    /**
     * Create a record in System Event Log
     * @param sessionContext session context
     * @param description description of event 
     * @param affectedObject affected object (may be null)
     * @param severity log severity
     */
    public void systemEventLog(ISessionContext sessionContext, String description, String affectedObject, LogSeverity severity) {
        try {
            ISystemEventLogRecord sysEventLogRecord = new SystemEventLogRecordItem();
            sysEventLogRecord.setSeverity(severity);
            populateDescriptionFacet(sysEventLogRecord, description);
            populateSourceFacet(sysEventLogRecord, affectedObject);
            populateUserFacet(sysEventLogRecord, sessionContext);
            logManager.createSystemEventLogRecord(sessionContext, sysEventLogRecord);
        } catch (BcbException e) {
            LOGGER.error("Failed to create system event log record for {}", description, e);
        }
    }

    /**
     * Create a record in ExportCommand Log
     * @param sessionContext session context
     * @param description description of event 
     * @param affectedObject affected object (may be null)
     */
    public void commandLog(ISessionContext sessionContext, String description, String affectedObject) {
        try {
            ICommandLogRecord commandLogRecord = new CommandLogRecordItem();
            populateDescriptionFacet(commandLogRecord, description);
            populateSourceFacet(commandLogRecord, affectedObject);
            populateUserFacet(commandLogRecord, sessionContext);
            logManager.createCommandLogRecord(sessionContext, commandLogRecord);
        } catch (BcbException e) {
            LOGGER.error("Failed to create command log record for {}", description, e);
        }
    }

    private void populateDescriptionFacet(IDescriptionFacet record, String description) {
        record.setDescription(description);
    }

    private void populateSourceFacet(ILogRecordSourceFacet record, String affectedObject) {
        record.setAffectedObject(defaultIfBlank(affectedObject, BICNET_COMPONENT_TYPE.guiLabel()));
        record.setComponent(BICNET_COMPONENT_TYPE);
    }

    private void populateUserFacet(IUserNameFacet record, ISessionContext sessionContext) {
        if (sessionContext != null) {
            record.setUserName(sessionContext.getUserName());
        }
    }

}
