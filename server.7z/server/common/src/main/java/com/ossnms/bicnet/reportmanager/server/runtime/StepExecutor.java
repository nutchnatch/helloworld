package com.ossnms.bicnet.reportmanager.server.runtime;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.BcbException;

public abstract class StepExecutor implements IExecutor {

    private boolean canceled;

    public static final Logger LOGGER = LoggerFactory.getLogger(StepExecutor.class);

    @Override public void cancelRequested() {
        canceled = true;
    }

    boolean isCanceled() {
        return canceled;
    }
}
