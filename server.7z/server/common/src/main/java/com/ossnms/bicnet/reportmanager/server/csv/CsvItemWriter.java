package com.ossnms.bicnet.reportmanager.server.csv;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.ItemWriter;

/**
 * Csv ItemWriter that uses supercsv {@link CsvBeanWriter}
 */
public class CsvItemWriter<Item> implements ItemWriter<Item> {

    private final String[] header;
    private final File resource;
    private final CellProcessor[] cellProcessors;
    private final String[] mappings;
    private final CsvPreference preference;
    private ICsvBeanWriter beanWriter;
    private final Logger logger = LoggerFactory.getLogger(getClass());

    public CsvItemWriter(String[] header, String[] mappings, CellProcessor[] cellProcessors, File resource, CsvPreference preference) {
        this.header = ArrayUtils.clone(header);
        this.mappings = ArrayUtils.clone(mappings);
        this.resource = resource;
        this.cellProcessors = ArrayUtils.clone(cellProcessors);
        this.preference = preference;
    }

    public void open() throws BcbException {
        try {
            beanWriter = new CsvBeanWriter(new FileWriter(resource), preference);
            beanWriter.writeHeader(header);
        } catch (IOException e) {
            throw new BcbException("Failed to open file " + resource, e);
        }
    }

    @Override public void writeItems(Item item) throws BcbException {
        try {
            beanWriter.write(item, mappings, cellProcessors);
        } catch (IOException e) {
            logger.error("Failed to write file {}", resource, e);
            throw new BcbException("Failed to write file " + resource, e);
        }
    }

    public void close() throws BcbException {
        try {
            beanWriter.close();
        } catch (IOException e) {
            throw new BcbException("Failed to close writer", e);
        }
    }
}
