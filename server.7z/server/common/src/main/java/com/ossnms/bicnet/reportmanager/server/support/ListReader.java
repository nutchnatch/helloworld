package com.ossnms.bicnet.reportmanager.server.support;

import java.util.Iterator;
import java.util.List;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportmanager.server.executors.ItemReader;

/**
 * ItemReader api for list of predefined items
 */
public class ListReader<Item> implements ItemReader<Item> {
    private final List<Item> items;
    private Iterator<Item> iterator;

    public ListReader(List<Item> items) {
        this.items = items;
    }

    @Override public Item readItem() throws BcbException {
        return iterator.hasNext() ? iterator.next() : null;
    }

    @Override public void open() throws BcbException {
        iterator = items.iterator();
    }
}
