package com.ossnms.bicnet.reportmanager.server.files;


import static java.text.MessageFormat.format;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FilesManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(FilesManager.class);
    private final Path componentPath;

    public FilesManager(Path componentPath) {
        this.componentPath = componentPath;
    }

    /**
     * Builds a path for report file
     *
     * @param name      name of report file
     * @param date      date of report
     * @return report file path
     */
    public File resolveReportFile(String name, String extension, Date date) {
        String dateString = new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss.S").format(date);
        String fileName = format("{0}-{1}.{2}", name, dateString, extension);
        Path filePath = componentPath.resolve(fileName);

        silentlyCreateFile(filePath);
        return filePath.toFile();
    }

    private static void silentlyCreateFile(Path path) {
        try {
            Files.createDirectories(path.getParent());
            Files.createFile(path);
        } catch (IOException e) {
            LOGGER.warn("Failed to create file {}", path, e);
        }
    }

    /**
     * Removes files from component folder according to {@link PathFilter}
     * @param filter files apply to remove files
     */
    public void enforceRetention(PathFilter filter) {
        for (Path file : filter.apply(filesIn(componentPath))) {
            try {
                Files.deleteIfExists(file);
            } catch (IOException e) {
                LOGGER.warn("Failed to delete file {}", file, e);
            }
        }
    }

    private List<Path> filesIn(Path directory) {
        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(directory)) {
            for (Path path : directoryStream) {
                files.add(path);
            }
        } catch (IOException ex) {
            LOGGER.warn("Cannot read directory {}", directory, ex);
        }
        return files;
    }
}
