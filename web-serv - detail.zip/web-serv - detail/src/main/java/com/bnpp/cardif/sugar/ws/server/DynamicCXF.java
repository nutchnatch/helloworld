package com.bnpp.cardif.sugar.ws.server;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.jws.WebService;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContainerInitializer;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;
import javax.servlet.annotation.HandlesTypes;
import javax.servlet.annotation.WebServlet;
import javax.xml.ws.Endpoint;

import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.apache.cxf.transport.servlet.CXFNonSpringServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This listener will add dynamically a Servlet if cxf is found on the
 * classpath. The Servlet will enable all the JAXWS endpoints of the list.
 *
 */
@HandlesTypes(WebService.class)
public class DynamicCXF implements ServletContainerInitializer {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(DynamicCXF.class);

    private static List<Class<?>> JAXWS_ENDPOINT = new ArrayList<>();

    @WebServlet("/services/*")
    public static class Servlet extends CXFNonSpringServlet {

        private static final long serialVersionUID = 1L;

        @Override
        public void loadBus(ServletConfig servletConfig) {
            LOGGER.info("Loading BUS.");

            super.loadBus(servletConfig);

            Bus bus = this.getBus();
            BusFactory.setDefaultBus(bus);

            for (Class<?> endpoint : JAXWS_ENDPOINT) {
                if (endpoint.isInterface()) {
                    LOGGER.info("Skipping class " + endpoint);
                    continue;
                }

                LOGGER.info("Procesing class " + endpoint);

                WebService annot = endpoint.getAnnotation(WebService.class);
                if (annot == null || annot.serviceName() == null || annot.serviceName().equals("")) {
                    LOGGER.error("Impossible to publish the endpoint (no service name) : " + endpoint.getName());
                    throw new IllegalArgumentException(
                            "Impossible to publish the endpoint (no service name) : " + endpoint.getName());
                }
                String path = annot.serviceName();
                path = path.substring(path.indexOf("/") + 1);
                try {
                    LOGGER.info("Publishing to path " + path);
                    Endpoint.publish("/" + path, endpoint.newInstance());
                }
                catch (Exception e) {
                    LOGGER.error("Error publishing endpoint.", e);
                    throw new IllegalArgumentException("Impossible to publish the endpoint : " + endpoint.getName(), e);
                }
            }

        }
    }

    @Override
    public void onStartup(Set<Class<?>> c, ServletContext ctx) throws ServletException {
        LOGGER.info("Adding web services classes: " + c);

        JAXWS_ENDPOINT.addAll(c);

        URL url = Thread.currentThread().getContextClassLoader()
                .getResource("org/apache/cxf/transport/servlet/CXFNonSpringServlet.class");

        LOGGER.info("Adding Servlet " + url);

        if (url == null) {
            return;
        }

        final ServletRegistration.Dynamic dn = ctx.addServlet("DynamicCXFServlet", Servlet.class);
        dn.setAsyncSupported(true);
    }
}