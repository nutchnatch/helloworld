package com.bnpp.cardif.sugar.ws.server;

import java.util.Date;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.exception.v1.AbstractBaseFaultType.Reasons;
import com.bnpparibas.assurance.ea.internal.schema.mco.exception.v1.FunctionalBaseFaultType;
import com.bnpparibas.assurance.ea.internal.schema.mco.exception.v1.TechnicalBaseFaultType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

/**
 * Builder for SOAP {@link Exception} either for {@link SugarTechnicalException}
 * or {@link SugarFunctionalException}
 * 
 * @author Christopher Laszczuk
 *
 */
public class FaultMessageBuilder {
    private static final String SUGAR_ACTOR = "Sugar";
    private static final String ERROR_SEVERITY = "error";

    private FaultMessageBuilder() {
    }

    /**
     * Builds a SOAP technical fault
     * 
     * @param e
     *            The exception
     * @return The fault corresponding to the supplied {@link Exception}
     */
    public static TechFaultMessage build(SugarTechnicalException e) {
        TechnicalBaseFaultType type = buildType(e);
        return new TechFaultMessage(e.getMessage(), type, e);
    }
    
    public static TechFaultMessage build(TechnicalException e) {
        TechnicalBaseFaultType type = buildType(e);
        return new TechFaultMessage(e.getMessage(), type, e);
    }

    private static TechnicalBaseFaultType buildType(SugarTechnicalException e) {
        TechnicalBaseFaultType type = new TechnicalBaseFaultType();
        type.setCode(e.getCode());
        type.setSeverity(ERROR_SEVERITY);
        type.setTimestamp(new Date());
        type.setActor(SUGAR_ACTOR);
        type.setDescription(e.getMessage());
        String exceptionString = e.toString();
        int stringLength = exceptionString.length();
        if (stringLength > 4990) {
            stringLength = 4990;
        }
        type.setDetail(exceptionString.substring(0, stringLength));
        type.setLang("en");
        Reasons reason = new Reasons();
        type.setReasons(reason);
        return type;
    }
    
    private static TechnicalBaseFaultType buildType(TechnicalException e) {
        TechnicalBaseFaultType type = new TechnicalBaseFaultType();
        type.setCode(e.getCode());
        type.setSeverity(ERROR_SEVERITY);
        type.setTimestamp(new Date());
        type.setActor(SUGAR_ACTOR);
        type.setDescription(e.getMessage());
        String exceptionString = e.toString();
        int stringLength = exceptionString.length();
        if (stringLength > 4990) {
            stringLength = 4990;
        }
        type.setDetail(exceptionString.substring(0, stringLength));
        type.setLang("en");
        Reasons reason = new Reasons();
        type.setReasons(reason);
        return type;
    }

    /**
     * Builds a SOAP functional fault
     * 
     * @param e
     *            The exception
     * @return The fault corresponding to the supplied {@link Exception}
     */
    public static FuncFaultMessage build(SugarFunctionalException e) {
        FunctionalBaseFaultType type = buildType(e);
        return new FuncFaultMessage(e.getMessage(), type, e);
    }
    
    public static FuncFaultMessage build(FunctionalException e) {
        FunctionalBaseFaultType type = buildType(e);
        return new FuncFaultMessage(e.getMessage(), type, e);
    }

    private static FunctionalBaseFaultType buildType(SugarFunctionalException e) {
        FunctionalBaseFaultType type = new FunctionalBaseFaultType();
        type.setCode(e.getCode());
        type.setSeverity(ERROR_SEVERITY);
        type.setTimestamp(new Date());
        type.setActor(SUGAR_ACTOR);
        type.setDescription(e.getMessage());
        String exceptionString = e.toString();
        int stringLength = exceptionString.length();
        if (stringLength > 4990) {
            stringLength = 4990;
        }
        type.setDetail(exceptionString.substring(0, stringLength));
        type.setLang("en");
        Reasons reason = new Reasons();
        type.setReasons(reason);
        return type;
    }
    
    private static FunctionalBaseFaultType buildType(FunctionalException e) {
        FunctionalBaseFaultType type = new FunctionalBaseFaultType();
        type.setCode(e.getCode());
        type.setSeverity(ERROR_SEVERITY);
        type.setTimestamp(new Date());
        type.setActor(SUGAR_ACTOR);
        type.setDescription(e.getMessage());
        String exceptionString = e.toString();
        int stringLength = exceptionString.length();
        if (stringLength > 4990) {
            stringLength = 4990;
        }
        type.setDetail(exceptionString.substring(0, stringLength));
        type.setLang("en");
        Reasons reason = new Reasons();
        type.setReasons(reason);
        return type;
    }
}
