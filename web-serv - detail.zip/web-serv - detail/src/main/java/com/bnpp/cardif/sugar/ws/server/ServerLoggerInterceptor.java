package com.bnpp.cardif.sugar.ws.server;

import java.util.Date;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StopWatch;

import com.bnpp.cardif.sugar.domain.tracker.LoggerInterceptor;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.ReindexRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.StoreRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateRequest;

public class ServerLoggerInterceptor extends LoggerInterceptor {
    public Object doBasicLogging(ProceedingJoinPoint pjp) throws Throwable {
        {
            Signature signature = pjp.getSignature();
            getObjectArgId(pjp.getArgs());
            StopWatch stopWatch = null;
            Date startDate = new Date();
            if (isPerfLoggingEnabled()) {
                stopWatch = new StopWatch(signature.toShortString());
                stopWatch.start();
            }

            interceptorLogger.trace(METHOD_ENTRY_PHRASE, signature.toShortString());
            Object returnedValue = null;
            String errorCode = "";
            boolean success = true;
            try {
                returnedValue = pjp.proceed();
            }
            catch (FuncFaultMessage e) {
                errorCode = e.getFaultInfo().getCode();
                success = false;
                throw e;
            }
            catch (TechFaultMessage e) {
                errorCode = e.getFaultInfo().getCode();
                success = false;
                throw e;
            }
            catch (Exception e) {
                success = false;
                throw e;
            }
            finally {
                interceptorLogger.trace(METHOD_OUTPUT_PHRASE, signature.toShortString());
                if (isPerfLoggingEnabled()) {
                    if (stopWatch != null) {
                        stopWatch.stop();

                        AuthenticatedUser authenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext()
                                .getAuthentication().getPrincipal();

                        logAction(pjp, stopWatch, startDate, authenticatedUser, success, errorCode,
                                getObjectArgId(pjp.getArgs()));
                    }
                }
            }
            return returnedValue;
        }
    }

    /**
     * Returns list of Document of Folder Id separate by tab
     * 
     * @param args
     * @return
     */
    private static String getObjectArgId(Object[] args) {
        StringBuilder ids = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            Object arg = args[i];

            /** Document requests **/
            if (arg instanceof StoreRequest) {
                for (Document doc : ((StoreRequest) arg).getDocument()) {
                    ids.append(doc.getId() + "\t");
                }
            }
            else if (arg instanceof GetRequest) {
                for (Id id : ((GetRequest) arg).getId()) {
                    ids.append(id + "\t");
                }
            }
            else if (arg instanceof ReindexRequest) {
                for (Document doc : ((ReindexRequest) arg).getDocument()) {
                    ids.append(doc.getId() + "\t");
                }
            }
            else if (arg instanceof DeleteRequest) {
                for (Id id : ((DeleteRequest) arg).getId()) {
                    ids.append(id + "\t");
                }
            }

            /** Folder requests **/
            else if (arg instanceof CreateRequest) {
                for (Folder folder : ((CreateRequest) arg).getFolder()) {
                    ids.append(folder.getFolderId() + "\t");
                }
            }
            else if (arg instanceof com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetRequest) {
                for (FolderId folderId : ((com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetRequest) arg)
                        .getFolderId()) {
                    ids.append(folderId + "\t");
                }
            }
            else if (arg instanceof UpdateRequest) {
                for (Folder folder : ((UpdateRequest) arg).getFolder()) {
                    ids.append(folder.getFolderId() + "\t");
                }
            }
        }
        return ids.toString();
    }
}
