package com.ossnms.dcn_manager.exceptions;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Exception thrown by commands whenever the command is creating an object
 * targeting the same host name as another existing object.
 */
public class DuplicatedHostException extends DcnManagerException {

	private static final long serialVersionUID = -9049277992680856893L;

	/** @see CommandException#CommandException() */
	public DuplicatedHostException() { }

    /** @see CommandException#CommandException(String) */
	public DuplicatedHostException(String message)
	{
		super(message);
	}

    /** @see CommandException#CommandException(Throwable) */
	public DuplicatedHostException(Throwable cause)
	{
		super(cause);
	}

    /** @see CommandException#CommandException(String, Throwable) */
	public DuplicatedHostException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see CommandException#CommandException(String, Throwable, boolean, boolean) */
	public DuplicatedHostException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/** @see CommandException#CommandException(String, Object[]) */
    public DuplicatedHostException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }
}
