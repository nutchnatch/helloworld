package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.container.RootContainerId;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Load the Default Container assignment setted in the Global Settings.
 */
class DefaultContainerAssignment<C extends CallContext> {

    private final SettingsRepository settingsRepository;
    private final ContainerRepository containerRepository;
    private final ContainerCreationBase<C> containerCreationBase;

    DefaultContainerAssignment(
            @Nonnull final SettingsRepository settingsRepository,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final ContainerCreationBase<C>  containerCreationBase) {
        this.settingsRepository = settingsRepository;
        this.containerRepository = containerRepository;
        this.containerCreationBase = containerCreationBase;
    }

    /**
     * Gets the Default Container from repository if exists or create a default if is not present in the repository.
     *
     * @return The default container.
     * @throws RepositoryException
     */
    public ContainerInfo get() throws RepositoryException {
        final String defaultContainerName = settingsRepository.getSettings().getDefaultContainerName();

        final Optional<ContainerInfo> defaultContainer = containerRepository.queryByName(defaultContainerName);

        if (defaultContainer.isPresent()) {
            return defaultContainer.get();
        } else {
            final int parent = RootContainerId.ID.get();
            try {
                return containerCreationBase.tryCreateContainer(new ContainerCreationDescriptor(parent, defaultContainerName));
            } catch (DuplicatedObjectNameException e) {
                throw new RepositoryException(e);
            }
        }
    }
}
