package com.ossnms.dcn_manager.composables.configuration;

import static org.apache.commons.lang3.StringUtils.trim;
import static org.apache.commons.lang3.StringUtils.upperCase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum HardwareConfigurationType {

    DEV(21), SMALL(10), MED(50), LARGE(100);
    
    private static final Logger LOGGER = LoggerFactory.getLogger(HardwareConfigurationType.class);
    
    private int value;
    
    private HardwareConfigurationType(int value) {
        this.setValue(value);
    }
    
    public static HardwareConfigurationType from(String type) {
        try {            
            return HardwareConfigurationType.valueOf(upperCase(trim(type)));
        } catch (Exception e) {
            LOGGER.error("HW configuration type not found. SMALL was selected by default.", e);
        }

        return HardwareConfigurationType.SMALL;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
