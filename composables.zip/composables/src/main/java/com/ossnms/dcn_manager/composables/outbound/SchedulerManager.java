package com.ossnms.dcn_manager.composables.outbound;

public interface SchedulerManager {

}
