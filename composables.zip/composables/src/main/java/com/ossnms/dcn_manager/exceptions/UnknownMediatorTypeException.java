package com.ossnms.dcn_manager.exceptions;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Exception thrown whenever the given name does not correspond to
 * an existing mediator type.
 */
public class UnknownMediatorTypeException extends DcnManagerException {

    private static final long serialVersionUID = 1973541508095747104L;

    /** @see DcnManagerException#DcnManagerException() */
	public UnknownMediatorTypeException() { }

    /** @see DcnManagerException#DcnManagerException(String) */
	public UnknownMediatorTypeException(String message)
	{
		super(message);
	}

    /** @see DcnManagerException#DcnManagerException(Throwable) */
	public UnknownMediatorTypeException(Throwable cause)
	{
		super(cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable) */
	public UnknownMediatorTypeException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable, boolean, boolean) */
	public UnknownMediatorTypeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

    /** @see DcnManagerException#DcnManagerException(String, Object[]) */
    public UnknownMediatorTypeException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String, Throwable, Object[]) */
    public UnknownMediatorTypeException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }
}
