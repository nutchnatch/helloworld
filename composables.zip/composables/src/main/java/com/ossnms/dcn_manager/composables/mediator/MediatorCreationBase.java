package com.ossnms.dcn_manager.composables.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedHostException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

public class MediatorCreationBase<C extends CallContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorCreationBase.class);

    private final MediatorEntityRepository mediatorEntityRepository;
    private final MediatorInstanceEntityRepository mediatorInstancesRepository;
    private final StaticConfiguration configuration;
    private final MediatorNotifications notifications;
    private final MediatorSchedulingConfiguration mediatorScheduling;
    private final LoggerManager<C> loggerManager;
    private final C context;

    public MediatorCreationBase(@Nonnull C context,
            @Nonnull MediatorEntityRepository mediatorEntityRepository,
            @Nonnull MediatorInstanceEntityRepository mediatorInstancesRepository,
            @Nonnull MediatorNotifications notifications,
            @Nonnull StaticConfiguration configuration,
            @Nonnull MediatorSchedulingConfiguration mediatorScheduling,
            @Nonnull LoggerManager<C> loggerManager) {
        this.context = context;
        this.mediatorEntityRepository = mediatorEntityRepository;
        this.mediatorInstancesRepository = mediatorInstancesRepository;
        this.notifications = notifications;
        this.configuration = configuration;
        this.mediatorScheduling = mediatorScheduling;
        this.loggerManager = loggerManager;
    }

    public MediatorEntity tryCreateMediator(@Nonnull MediatorCreateDescriptor mediatorCreation)
            throws UnknownMediatorTypeException, RepositoryException, DuplicatedObjectNameException, DuplicatedHostException {

        validateUniqueName(mediatorCreation.getInfoInitialData().getName());

        validateMediatorType(mediatorCreation.getType());

        for (final MediatorInstanceCreateDescriptor instanceCreateDescriptor : mediatorCreation.getInstanceCreateDescriptors()) {
            validateUniqueHost(mediatorCreation.getType(), instanceCreateDescriptor.getInitialData().getHost());
        }

        final MediatorEntity entity = mediatorEntityRepository.create(mediatorCreation);

        mediatorInstancesRepository.queryAll(entity.getInfo().getId())
            .forEach(instance -> mediatorScheduling.setMaxOngoingMediatorJobCount(instance.getPhysicalInfo().getId(),
                    entity.getInfo().isConcurrentActivationsLimited() ? entity.getInfo().getConcurrentActivationsLimit() : Integer.MAX_VALUE));
        
        notifications.notifyCreate(entity);

        loggerManager.createCommandLog(context, new LoggerItemMediator(
                entity.getInfo().getName(),
                "Mediator object created"));

        LOGGER.info("Created Mediator '{}' with ID {} of type {}.",
                entity.getInfo().getName(), entity.getInfo().getId(), entity.getInfo().getTypeName());

        return entity;
    }

    private void validateMediatorType(@Nonnull String typeName)
            throws UnknownMediatorTypeException {

        if (!configuration.getMediatorTypes().containsKey(typeName)) {
            throw new UnknownMediatorTypeException(tr(Message.UNKNOWN_MEDIATOR_TYPE, typeName));
        }
    }

    private void validateUniqueName(@Nonnull String newName)
            throws DuplicatedObjectNameException, RepositoryException {

        final boolean nameExists = mediatorEntityRepository.getMediatorInfoRepository().query(newName).isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(tr(Message.DUPLICATED_MEDIATOR_NAME, newName));
        }
    }

    private void validateUniqueHost(@Nonnull String mediatorType, @Nonnull String newHostName)
            throws DuplicatedHostException, RepositoryException {

        if (configuration.getMediatorTypes().get(mediatorType).allowManyOnSameHost()) {
            // do not check anything if many mediators are allowed on the same host.
            return;
        }

        final Optional<MediatorInfoData> existingMediator =
                mediatorEntityRepository.getMediatorInfoRepository().queryByHost(mediatorType, newHostName);
        final boolean nameExists = existingMediator.isPresent();

        if (nameExists) {
            throw new DuplicatedHostException(tr(Message.DUPLICATED_MEDIATOR_HOST,
                    mediatorType, newHostName, existingMediator.get().getName()));
        }
    }
}
