package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;

import static com.google.common.collect.Iterables.size;

/**
 * Common validator for Containers.
 */
public class ContainerValidator extends ValidatorBase {

    public ContainerValidator(ContainerRepository containerRepository, SystemRepository systemRepository) {
        super(containerRepository, systemRepository);
    }

    /**
     * Validate the container name
     *
     * @param newName The new name to be checked.
     * @throws DuplicatedObjectNameException If the name is duplicated between Containers and Systems.
     * @throws RepositoryException
     */
    @Override
    public void validateNewName(final String newName) throws DuplicatedObjectNameException, RepositoryException {
        validateEmptyName(newName, Message.CONTAINER_NAME_EMPTY);
        validateContainerUniqueName(newName);
        validateSystemUniqueName(newName);
    }

    public boolean isLastNeAssignment(NeAssignmentData neAssignmentData) throws RepositoryException {
        final Iterable<NeAssignmentData> systemAssignmentDatas = getContainerRepository().queryAllByNE(neAssignmentData.getNeId());

        return size(systemAssignmentDatas) == LAST_ASSIGNMENT;
    }

    public boolean isLastSystemAssignment(SystemAssignmentData systemAssignmentData) throws RepositoryException {
        final Iterable<SystemAssignmentData> systemAssignmentDatas = getContainerRepository().queryAllBySystem(systemAssignmentData.getSystemContainerId());

        return size(systemAssignmentDatas) == LAST_ASSIGNMENT;
    }
}
