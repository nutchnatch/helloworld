package com.ossnms.dcn_manager.composables.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static com.google.common.base.Preconditions.checkState;
import static com.google.common.base.Strings.isNullOrEmpty;
import static com.ossnms.dcn_manager.i18n.Message.CHANNEL_ALREADY_EXISTS;
import static com.ossnms.dcn_manager.i18n.T.tr;

public class ChannelCreationBase<C extends CallContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelCreationBase.class);

    private final ChannelEntityRepository repository;
    private final ChannelNotifications notifications;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;
    private final ChannelSchedulingConfiguration channelScheduling;
    private final MediatorEntityRepository mediatorRepository;
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;
    private final LoggerManager<C> loggerManager;
    private final C context;

    public ChannelCreationBase(@Nonnull C context,
            @Nonnull ChannelEntityRepository repository,
            @Nonnull ChannelNotifications notifications,
            @Nonnull ChannelPhysicalConnectionRepository channelInstanceRepository,
            @Nonnull ChannelSchedulingConfiguration channelScheduling,
            @Nonnull MediatorEntityRepository mediatorRepository,
            @Nonnull MediatorInstanceEntityRepository mediatorInstanceRepository,
            @Nonnull LoggerManager<C> loggerManager) {
        this.context = context;
        this.repository = repository;
        this.notifications = notifications;
        this.channelInstanceRepository = channelInstanceRepository;
        this.channelScheduling = channelScheduling;
        this.mediatorRepository = mediatorRepository;
        this.mediatorInstanceRepository = mediatorInstanceRepository;
        this.loggerManager = loggerManager;
    }

    public ChannelEntity tryCreateChannel(@Nonnull ChannelCreateDescriptor createEvent)
            throws RepositoryException, DuplicatedObjectNameException, UnknownMediatorIdException {

        checkState(!isNullOrEmpty(createEvent.getPreferencesInitialData().getName()), "Channels must have names.");

        throwOnDuplicatedName(createEvent);

        final ChannelEntity entity = createEntity(createEvent);

        final ChannelUserPreferencesData preferences = entity.getUserPreferences();
        final int maximumConcurrentJobs =
                preferences.isConcurrentActivationsLimited() ? preferences.getConcurrentActivationsLimit() : Integer.MAX_VALUE;
        StreamSupport.stream(mediatorInstanceRepository.queryAll(entity.getInfo().getMediatorId()).spliterator(), false)
            .map(instance -> createChannelInstance(instance, preferences.getId()))
            .forEach(channelInstance -> channelScheduling.setMaxOngoingChannelJobCount(channelInstance.getId(), maximumConcurrentJobs));

        notifications.notifyCreate(entity);

        logCreation(entity);

        return entity;
    }

    private void logCreation(final ChannelEntity entity) {
        loggerManager.createCommandLog(context, new LoggerItemChannel(
                entity.getUserPreferences().getName(), "Channel object created"));

        LOGGER.info("Created Channel '{}' with ID {} of type {}.",
                entity.getUserPreferences().getName(), entity.getInfo().getId(), entity.getInfo().getType());
    }

    private ChannelEntity createEntity(ChannelCreateDescriptor createEvent)
            throws RepositoryException, UnknownMediatorIdException {
        final Optional<MediatorEntity> mediator = mediatorRepository.query(createEvent.getMediatorId());
        if (!mediator.isPresent()) {
            throw new UnknownMediatorIdException("Unknown mediator {}", createEvent.getMediatorId());
        }
        return repository.create(createEvent);
    }

    private ChannelPhysicalConnectionData createChannelInstance(MediatorInstance parentMediatorInstance, int logicalChannelId) {
        return channelInstanceRepository.insert(
                new ChannelConnectionInitialData().setActive(parentMediatorInstance.getConnection().isActive()),
                logicalChannelId,
                parentMediatorInstance.getConnection().getId());
    }

    private void throwOnDuplicatedName(ChannelCreateDescriptor createEvent)
            throws DuplicatedObjectNameException, RepositoryException {
        final String newChannelName = createEvent.getPreferencesInitialData().getName();

        final boolean nameExists = repository.getChannelUserPreferencesRepository().query(newChannelName).isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(tr(CHANNEL_ALREADY_EXISTS, newChannelName));
        }
    }
}
