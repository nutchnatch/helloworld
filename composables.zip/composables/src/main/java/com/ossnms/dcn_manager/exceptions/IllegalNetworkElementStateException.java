package com.ossnms.dcn_manager.exceptions;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Exception thrown by commands whenever the command has no meaning for the current
 * NE state.
 */
public class IllegalNetworkElementStateException extends DcnManagerException {

	private static final long serialVersionUID = -9049277992680856893L;

	/** @see CommandException#CommandException() */
	public IllegalNetworkElementStateException() { }

    /** @see CommandException#CommandException(String) */
	public IllegalNetworkElementStateException(String message)
	{
		super(message);
	}

    /** @see CommandException#CommandException(Throwable) */
	public IllegalNetworkElementStateException(Throwable cause)
	{
		super(cause);
	}

    /** @see CommandException#CommandException(String, Throwable) */
	public IllegalNetworkElementStateException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see CommandException#CommandException(String, Throwable, boolean, boolean) */
	public IllegalNetworkElementStateException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/** @see CommandException#CommandException(String, Object[]) */
    public IllegalNetworkElementStateException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }
}
