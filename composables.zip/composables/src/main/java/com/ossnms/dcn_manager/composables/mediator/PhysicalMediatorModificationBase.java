package com.ossnms.dcn_manager.composables.mediator;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;

import javax.annotation.Nonnull;

/**
 * Base class for commands that modify physical mediator information.
 * Provides methods for these commands, such as finding mediators in the repository.
 */
public class PhysicalMediatorModificationBase {

    private final MediatorInstanceEntityRepository repository;

    public PhysicalMediatorModificationBase(@Nonnull MediatorInstanceEntityRepository repository) {
        this.repository = repository;
    }

    /**
     * Tries to find the communications state of the target physical mediator instance in the repository.
     *
     * @return An instance of a mediator.
     * @throws UnknownMediatorIdException If the mediator can not be found.
     * @throws RepositoryException If some error occurred while working with the repository.
     */
    public MediatorPhysicalConnectionData findMediatorConnectionState(int mediatorId) throws UnknownMediatorIdException, RepositoryException {
        return repository.getMediatorPhysicalConnectionRepository().query(mediatorId)
                .orElseThrow(() -> new UnknownMediatorIdException("Physical mediator {} does not exist.", mediatorId));
    }

    public MediatorInstanceEntityRepository getMediatorRepository() {
        return repository;
    }

}
