package com.ossnms.dcn_manager.exceptions;

/**
 * Thrown when it was not possible to update an NE business object because
 * the update request includes duplicated routes.
 */
public class DuplicatedRouteException extends DataUpdateException {

    private static final long serialVersionUID = -4062129733975571048L;

    /** @see DcnManagerException#DcnManagerException() */
    public DuplicatedRouteException() {

    }

    /** @see DcnManagerException#DcnManagerException(String) */
    public DuplicatedRouteException(String message) {
        super(message);
    }

    /** @see DcnManagerException#DcnManagerException(Throwable) */
    public DuplicatedRouteException(Throwable cause) {
        super(cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable) */
    public DuplicatedRouteException(String message, Throwable cause) {
        super(message, cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,boolean,boolean) */
    public DuplicatedRouteException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /** @see DcnManagerException#DcnManagerException(String,Object[]) */
    public DuplicatedRouteException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,Object[]) */
    public DuplicatedRouteException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }

}
