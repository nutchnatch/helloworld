package com.ossnms.dcn_manager.composables.container;

import com.google.common.collect.Sets;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import static com.google.common.collect.Iterables.tryFind;

public class ContainersNeAssignmentUpdater<C extends CallContext> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ContainersNeAssignmentUpdater.class);

    private final ContainerRepository containerRepository;

    private final DefaultContainerAssignment defaultContainerAssignment;
    private final NeAssignmentOperations operations;

    public ContainersNeAssignmentUpdater(
            SettingsRepository settingsRepository,
            ContainerRepository containerRepository,
            SystemRepository systemRepository,
            ContainerNotifications containerNotifications,
            LoggerManager<C> loggerManager,
            C context) {
        this.containerRepository = containerRepository;

        ContainerCreationBase<C> containerCreation = new ContainerCreationBase<>(context, containerRepository, systemRepository,
                containerNotifications, loggerManager);

        this.defaultContainerAssignment = new DefaultContainerAssignment<>(settingsRepository, containerRepository,
                containerCreation);
        this.operations = new NeAssignmentOperations<>(containerRepository, containerNotifications, loggerManager, context);
    }

    /**
     * Sync and store the NE x Container associations.
     *
     * @param changedAssignments All assignments to be sync.
     * @param neInfoData The NE to be sync the associations.
     * @throws RepositoryException
     */
    public void store(@Nonnull final Set<NeAssignmentData> changedAssignments,
            @Nonnull final NeUserPreferencesData neInfoData) throws RepositoryException {

        final Set<NeAssignmentData> currentAssignments = Sets
                .newHashSet(containerRepository.queryAllByNE(neInfoData.getId()));

        update(changedAssignments, neInfoData, currentAssignments);
        add(changedAssignments, neInfoData, currentAssignments);
        remove(changedAssignments, neInfoData, currentAssignments);
    }

    /**
     * Duplicate the NE assignments.
     *
     * @param target The NE to receive the assignments.
     * @param fromId The NE id to be the origin of assignements.
     */
    public void duplicate(@Nonnull final NeUserPreferencesData target, final int fromId) {
        final Set<NeAssignmentData> currentAssignments = Sets.newHashSet(containerRepository.queryAllByNE(fromId));

        currentAssignments.forEach(assignment -> {
            NeAssignmentData newAssignment = new NeAssignmentData(assignment.getContainerInfo(), target.getId(),
                    assignment.getAssignmentType());
            try {
                operations.create(target, newAssignment);
            } catch (RepositoryException e) {
                LOGGER.error("Error to add assignment for NE=" + target.getId(), e);
            }
        });
    }

    /**
     * Assign the NE for a Default container.
     *
     * @param neInfoData NE to be assignment.
     * @throws RepositoryException
     */
    public void defaultNeAssignment(final NeUserPreferencesData neInfoData) throws RepositoryException {
        final ContainerInfo defaultContainer = defaultContainerAssignment.get();

        NeAssignmentData assignment = new NeAssignmentData(defaultContainer, neInfoData.getId(),
                AssignmentType.PRIMARY);

        store(Collections.singleton(assignment), neInfoData);
    }

    private void remove(@Nonnull Set<NeAssignmentData> changedAssignments, NeUserPreferencesData neInfoData,
            Set<NeAssignmentData> currentAssignments) {
        final Set<NeAssignmentData> removedAssignments = Sets.difference(currentAssignments, changedAssignments);

        removedAssignments.forEach(assignment -> {
            try {
                operations.delete(neInfoData, assignment);
            } catch (RepositoryException e) {
                LOGGER.error("Error to remove assignment for NE=" + neInfoData.getId(), e);
            }
        });
    }

    private void add(@Nonnull Set<NeAssignmentData> changedAssignments, NeUserPreferencesData neInfoData,
            Set<NeAssignmentData> currentAssignments) {
        final Set<NeAssignmentData> addedAssignments = Sets.difference(changedAssignments, currentAssignments);

        addedAssignments.forEach(assignment -> {
            try {
                operations.create(neInfoData, assignment);
            } catch (RepositoryException e) {
                LOGGER.error("Error to add assignment for NE=" + neInfoData.getId(), e);
            }
        });
    }

    private void update(@Nonnull Set<NeAssignmentData> changedAssignments, NeUserPreferencesData neInfoData,
            Set<NeAssignmentData> currentAssignments) {
        currentAssignments.stream().filter(changedAssignments::contains)
                .map(current -> {
                    NeAssignmentData found = tryFind(changedAssignments, current::equals).orNull();
                    if (null != found && found.getAssignmentType() != current.getAssignmentType()) {
                        return Optional.of(found);
                    }
                    return Optional.<NeAssignmentData>empty();
                })
                .filter(Optional::isPresent).map(Optional::get)
                .forEach(changedAssignmentType -> {
                    try {
                        operations.update(neInfoData, changedAssignmentType);
                    } catch (RepositoryException e) {
                        LOGGER.error("Error to update assignment for NE=" + neInfoData.getId(), e);
                    }
                });
    }
}
