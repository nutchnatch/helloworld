package com.ossnms.dcn_manager.composables.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NePropertiesUpdater.PreprocessedChanges;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNeTypeException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;

/**
 * <p>Receives a set of NE properties that have to be set/updated in the NE entity,
 * in the event that the NE entity has not been found yet. Works as a wrapper over
 * {@link NePropertiesUpdater}.</p>
 * <p>After validating these and recalculating related dynamic properties, the final set
 * must be propagated to other components as a change notification.</p>
 * <p>If the NE is online, its mediator must be notified as well. This must be done
 * when applicable by the user code.</p>
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 * @see NePropertiesUpdater
 */
public class UpdateNePropertiesBase<C extends CallContext> extends NeModificationBase {

    private final NetworkElementInteractionManager neActivationManager;
    private final NePropertiesUpdater<C> propertiesUpdater;

    /**
     * Creates a new object.
     *
     * @param configuration     DCN Manager static configuration.
     * @param propertiesUpdater Delegate object for calculating and applying any
     *                          modifications to NE entities.
     */
    public UpdateNePropertiesBase(
            @Nonnull StaticConfiguration configuration,
            @Nonnull NetworkElementInteractionManager neActivationManager,
            @Nonnull NePropertiesUpdater<C> propertiesUpdater) {
        super(propertiesUpdater.getRepository(), configuration);
        this.neActivationManager = neActivationManager;
        this.propertiesUpdater = propertiesUpdater;
    }

    /**
     * Applies a property update to an NE.
     *
     * @param neId              Target NE identifier.
     * @param updatedProperties Updated properties. Will be modified to reflect the properties that have actually changed.
     * @return The updated NE entity, if applicable.
     * @throws RepositoryException              Should an error occur while working with the repository.
     * @throws UnknownNetworkElementIdException If the target NE identifier is unknown.
     * @throws UnknownNeTypeException           Should the target NE refer to an unknown NE Type.
     * @throws InvalidMutationException         If an invalid property copy is attempted.
     * @throws DuplicatedRouteException         If duplicated routes were found and the callback decided that
     *                                          such a situation represents an error.
     */
    public Optional<NeEntity> applyUpdate(int neId, @Nonnull Map<String, String> updatedProperties)
            throws DcnManagerException {
        final NeEntity ne = findNe(neId);
        final NeType neType = findNeType(ne);
        final Iterable<NeGatewayRouteData> routes = getNeRepository().getNeGatewayRoutesRepository().queryRoutes(neId);

        return propertiesUpdater.applyUpdate(neType, ne, routes, updatedProperties);
    }

    /**
     * Runs a pre-processing step on the new NE properties. Produces a set of information that allows users
     * to determine most changes being requested. Does not attempt to commit any changes. An initial set of
     * validations is run.
     *
     * @param ne                    Target NE.
     * @param existingGatewayRoutes Current NE gateway routes. Used for calculating changes and updates to
     *                              the set of NE gateway routes.
     * @param updatedProperties     Updated properties. Will be modified to reflect the properties that have actually changed.
     * @return An instance of {@link PreprocessedChanges} with all changes requested if the properties could
     * be parsed and initial validations passed.
     * @throws InvalidMutationException         If an invalid property copy is attempted.
     * @throws RepositoryException              If a repository error occurs.
     * @throws DuplicatedRouteException         If duplicated routes were found and the callback decided that
     *                                          such a situation represents an error.
     * @throws UnknownNetworkElementIdException If the target NE identifier is unknown.
     * @throws UnknownNeTypeException           Should the target NE refer to an unknown NE Type.
     */
    public Optional<PreprocessedChanges> prepareUpdate(@Nonnull NeEntity ne, @Nonnull Iterable<NeGatewayRouteData> existingGatewayRoutes,
                                                       @Nonnull Map<String, String> updatedProperties)
            throws DuplicatedRouteException, InvalidMutationException, RepositoryException,
            UnknownNetworkElementIdException, UnknownNeTypeException, DuplicatedObjectNameException {
        final NeType neType = findNeType(ne);
        return propertiesUpdater.prepareUpdate(neType, ne, existingGatewayRoutes, updatedProperties);
    }

    /**
     * Attempt to commit the changes requested by an instance of {@link PreprocessedChanges} obtained by a
     * call to {@link #prepareUpdate(NeEntity, Iterable, Map)}. Final validations are run.
     *
     * @param update Updates to be applied.
     * @return An instance of the NE entity with the new properties if the update was successful.
     * @throws RepositoryException              If a repository error occurs.
     * @throws DuplicatedRouteException         If duplicated routes were found and the callback decided that
     *                                          such a situation represents an error.
     * @throws UnknownNetworkElementIdException If the target NE identifier is unknown.
     */
    public Optional<NeEntity> processUpdate(@Nonnull PreprocessedChanges update)
            throws DcnManagerException {
        return propertiesUpdater.processUpdate(update);
    }

    /**
     * Sends a set of changed property values to the mediator, scheduled according to the implementation of
     * {@link NetworkElementInteractionManager}.
     *
     * @param ne             The target NE.
     * @param neInstance     The target physical NE connection.
     * @param newPreferences New NE preferences, as set by the original property map.
     */
    public void updateNeProperties(@Nonnull NeEntity ne, @Nonnull NePhysicalConnectionData neInstance,
                                   @Nonnull NeUserPreferencesMutationDescriptor newPreferences) {
        neActivationManager.onNePropertiesUpdated(ne, neInstance, newPreferences);
    }
}
