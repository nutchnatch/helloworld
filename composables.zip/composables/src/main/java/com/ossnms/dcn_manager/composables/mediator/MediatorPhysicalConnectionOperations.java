package com.ossnms.dcn_manager.composables.mediator;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;

import static org.slf4j.LoggerFactory.getLogger;

public class MediatorPhysicalConnectionOperations extends MediatorModificationBase {

    private static final Logger LOGGER = getLogger(MediatorPhysicalConnectionOperations.class);

    /**
     * Holds a reference to the object responsible for implementing the mediator activation policy
     */
    private final MediatorInteractionManager activationManager;

    /**
     * Holds the reference to the component's event dispatcher
     */
    private final MediatorNotifications eventDispatcher;

    /**
     * Holds the reference to the repository of physical mediator instances
     */
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;

    public MediatorPhysicalConnectionOperations(MediatorEntityRepository repository,
                                                @Nonnull MediatorInteractionManager activationManager,
                                                @Nonnull MediatorNotifications eventDispatcher,
                                                @Nonnull MediatorInstanceEntityRepository mediatorInstanceRepository) {
        super(repository);
        this.activationManager = activationManager;
        this.eventDispatcher = eventDispatcher;
        this.mediatorInstanceRepository = mediatorInstanceRepository;
    }

    /**
     * Feeds the mediator connectivity state machine with a starting up stimulus on the given mediator link
     *
     * @param data The mediator link to startup
     */
    public void triggerMediatorPhysicalConnectionStartingUp(MediatorPhysicalConnectionData data) {
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation = prepareStartingUp(data);
        if (mutation.isPresent()) {
            execute(mutation.get());
        } else {
            LOGGER.warn("Could not activate physical mediator instance with id {} already activated.", data.getId());
        }
    }

    public Optional<MediatorPhysicalConnectionMutationDescriptor> prepareStartingUp(MediatorPhysicalConnectionData data) {
        return new MediatorPhysicalConnectionBehavior(data).setStartingUp(eventDispatcher, activationManager);
    }

    public Optional<MediatorPhysicalConnectionMutationDescriptor> prepareShuttingDown(MediatorPhysicalConnectionData data) {
        return new MediatorPhysicalConnectionBehavior(data).setShuttingDown(eventDispatcher, activationManager);
    }

    public void execute(final MediatorPhysicalConnectionMutationDescriptor mutation) {
        try {
            final Optional<MediatorPhysicalConnectionData> result =
                    mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().tryUpdate(mutation);
            if (!result.isPresent()) {
                LOGGER.warn("Concurrent modification on mediator instance connection {}.", mutation);
            }
        } catch (final RepositoryException e) {
            LOGGER.error("Error executing operation on physical mediator instance with mutation {}: {}", mutation, Throwables.getStackTraceAsString(e));
        }
    }

}
