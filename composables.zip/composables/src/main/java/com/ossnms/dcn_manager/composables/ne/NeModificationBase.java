package com.ossnms.dcn_manager.composables.ne;

import com.ossnms.dcn_manager.composables.shared.PropertiesModificationBase;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNeTypeException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Base class for modifying NE information.
 * Provides methods for this purpose, such as finding NEs in the repository.
 */
public class NeModificationBase
        extends PropertiesModificationBase<NeType, NePropertySource, NePropertySetters<?>> {

    private final NeEntityRepository repository;
    private final StaticConfiguration configuration;

    public NeModificationBase(
            @Nonnull NeEntityRepository repository,
            @Nonnull StaticConfiguration configuration) {
        super(new NeProperties());
        this.repository = repository;
        this.configuration = configuration;
    }

    /**
     * Tries to find the target NE in the repository.
     *
     * @return An instance of a NE.
     * @throws RepositoryException If some error occurred while working with the repository.
     * @throws UnknownNetworkElementIdException If the NE can not be found.
     */
    public NeEntity findNe(int neId) throws RepositoryException, UnknownNetworkElementIdException {
        final Optional<NeEntity> ne = getNeRepository().queryNe(neId);
        if (!ne.isPresent()) {
            throw new UnknownNetworkElementIdException("NE {} does not exist.", neId);
        }
        return ne.get();
    }

    /**
     * Tries to find the NE proxy type configuration.
     *
     * @param ne An instance of an NE.
     * @return An instance of the corresponding NE Type.
     * @throws UnknownNeTypeException If the NE references an unknown NE Type.
     */
    protected NeType findNeType(NeEntity ne) throws UnknownNeTypeException {
        final String typeName = ne.getInfo().getProxyType();
        final NeType neType = getConfiguration().getNeTypes().get(typeName);
        if (null == neType) {
            throw new UnknownNeTypeException("NE with ID {} references unknown type '{}'.", ne.getInfo().getNeId(), typeName);
        }
        return neType;
    }

    protected NeEntityRepository getNeRepository() {
        return repository;
    }

    protected StaticConfiguration getConfiguration() {
        return configuration;
    }

}
