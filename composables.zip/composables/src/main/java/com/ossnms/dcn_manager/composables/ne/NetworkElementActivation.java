package com.ossnms.dcn_manager.composables.ne;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeInfoBehavior;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import java.util.Optional;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * Shared methods for performing tasks related to network element activation.
 * The activation state of a NE represents whether that NE is required to be active or not, for
 * network management purposes.
 */
public class NetworkElementActivation {

    private static final Logger LOGGER = getLogger(NetworkElementActivation.class);

    private final NetworkElementNotifications eventDispatcher;
    private final NeEntityRepository neRepository;
    private final NetworkElementInteractionManager activationManager;
    private final NePhysicalConnectionRepository neInstanceRepository;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;

    /**
     * Creates a new object.
     *
     * @param eventDispatcher The component's out-bound event dispatcher
     * @param neRepository The NE repository to be used
     * @param activationManager The NE activation manager instance
     * @param neInstanceRepository The physical NE connection repository to be used
     * @param channelInstanceRepository The physical Channel connection repository to be used
     */
    public NetworkElementActivation(NetworkElementNotifications eventDispatcher,
            NeEntityRepository neRepository, NetworkElementInteractionManager activationManager,
            NePhysicalConnectionRepository neInstanceRepository,
            ChannelPhysicalConnectionRepository channelInstanceRepository) {
        this.eventDispatcher = eventDispatcher;
        this.neRepository = neRepository;
        this.activationManager = activationManager;
        this.neInstanceRepository = neInstanceRepository;
        this.channelInstanceRepository = channelInstanceRepository;
    }

    /**
     * Given a Network Element, switch its Required Activation state to Active. This
     * means that we must remember that the operator desires this NE to remain
     * connected to the management system.
     *
     * @param neInfo Network Element information.
     * @return False if the operation can't be completed,
     *  whether because the NE is already Required Active
     *  or because there was a concurrent
     *  modification to the NE information domain object.
     * @throws RepositoryException Should a generic error occur within the repository.
     */
    public boolean changeRequiredStateToActive(NeInfoData neInfo)
            throws RepositoryException {
        // Is this a valid state transition?
        final Optional<NeInfoMutationDescriptor> mutation =
            new NeInfoBehavior(neInfo, eventDispatcher)
                .activationRequired();
        if (!mutation.isPresent()) {
            return false;
        }

        // Mark NE according to the performed mutation
        // Because commands may be executed concurrently, update operations may fail (notice the
        // compound action find-update). In this use case, though, retry is not required.
        // Instead, we want to report an exception because concurrent NE activation/deactivation
        // requests should not have been issued in the first place.
        final Optional<NeInfoData> modifiedState = neRepository.getNeInfoRepository().tryUpdate(mutation.get());
        return modifiedState.isPresent();

    }

    /**
     * <p>Given a Network Element, switch its Actual Activation state to Start Up. This
     * will trigger the active physical connection to the NE and allow communications
     * between the management system and the equipment.</p>
     *
     * <p>Note that only the active instance connection will be initiated. Standby
     * instance connections will be started one at a time after previous NEs complete
     * initialization.</p>
     *
     * @param neId Network Element identifier.
     * @throws RepositoryException Should a generic error occur within the repository.
     * @see com.ossnms.dcn_manager.events.ne.NeInitializedEventHandler
     * @return True if the change was performed.
     */
    public boolean changeActualStateToStartUp(int neId)
            throws RepositoryException {

        for (final NePhysicalConnectionData physicalConnectionData : neInstanceRepository.queryAll(neId)) {

            if (physicalConnectionData.isActive()) {
                return changeActualStateToStartUp(physicalConnectionData);
            }
        }

        return false;
    }

    /**
     * <p>Given a physical NE connection, switch its Actual Activation state to Start Up.
     * This will trigger the actual connection to the NE.</p>
     *
     * @param neInstance Physical Network Element instance connection data.
     * @throws RepositoryException Should a generic error occur within the repository.
     * @return True if the change was performed.
     */
    public boolean changeActualStateToStartUp(NePhysicalConnectionData neInstance)
            throws RepositoryException {

        final Optional<ChannelPhysicalConnectionData> channelInstance =
                channelInstanceRepository.query(neInstance.getChannelInstanceId());
        if (!channelInstance.isPresent()) {
            LOGGER.error("Channel instance {} not found for NE instance {} on NE {}.", neInstance.getChannelInstanceId(),
                    neInstance.getId(), neInstance.getLogicalNeId());
            return false;
        }

        if (channelInstance.get().isStateActive()) {
            final Optional<NePhysicalConnectionMutationDescriptor> descriptor =
                    new NePhysicalConnectionBehavior(neInstance, eventDispatcher)
                        .startUp(activationManager, channelInstance.get().getMediatorInstanceId());
            if (!descriptor.isPresent()) {
                LOGGER.warn("Not activating NE instance {} for NE {}.", neInstance.getId(), neInstance.getLogicalNeId());
                return neInstance.isUndergoingActivation();
            }

            final Optional<NePhysicalConnectionData> updated = neInstanceRepository.tryUpdate(descriptor.get());
            if (!updated.isPresent()) {
                LOGGER.warn("Concurrent state change of NE instance {} for NE {} detected.", neInstance.getId(), neInstance.getLogicalNeId());
                return false;
            }
        }

        return true;
    }
}
