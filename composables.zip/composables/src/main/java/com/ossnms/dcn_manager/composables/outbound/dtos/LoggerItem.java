package com.ossnms.dcn_manager.composables.outbound.dtos;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.builder.EqualsBuilder;

import com.google.common.base.Joiner;
import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;

/**
 * Template for LoggerItems.
 *
 * Used to send data to system log facility.
 */
public abstract class LoggerItem {

    protected static final MessageSeverity DEFAULT_SEVERITY = MessageSeverity.MESSAGE;

    private final String message;
    private final MessageSeverity severity;

    /**
     * Creates a Immutable #LoggerItem object initializing all attributes.
     *
     * @param message
     * @param userName
     * @param severity
     */
    public LoggerItem(@Nonnull final String message, @Nonnull final MessageSeverity severity) {
        super();
        this.message = message.trim();
        this.severity = severity;
    }

    /**
     * Creates a Immutable #LoggerItem object for Channels with the default Severity {@link #DEFAULT_SEVERITY}.
     *
     * @param message
     * @param userName
     */
    public LoggerItem(@Nonnull final String message) {
        super();
        this.message = message.trim();
        this.severity = DEFAULT_SEVERITY;
    }

    /**
     * @return The Message to be logged.
     */
    @Nonnull
    public String getMessage() {
        return message;
    }

    /**
     * @return The Log Severity. Default value {@link #DEFAULT_SEVERITY}
     */
    @Nonnull
    public MessageSeverity getSeverity() {
        return severity;
    }

    /**
     * @return The Affected Object name.
     */
    @Nonnull
    public abstract String getAffectedObject();

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return Objects.hashCode(message, severity, getMessage());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final LoggerItem other = (LoggerItem) obj;

        return new EqualsBuilder()
            .append(message, other.message)
            .append(severity, other.severity)
            .isEquals();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return Joiner.on("").join(
                    MoreObjects.toStringHelper(this)
                        .omitNullValues()
                        .add("Message", message)
                        .add("Severity", severity)
                        .toString(),
                    super.toString());
    }
}
