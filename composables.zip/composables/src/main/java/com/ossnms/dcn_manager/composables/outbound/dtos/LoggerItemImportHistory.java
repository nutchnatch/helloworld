package com.ossnms.dcn_manager.composables.outbound.dtos;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.builder.EqualsBuilder;

import com.google.common.base.Joiner;
import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import com.google.common.collect.ComparisonChain;

/**
 * Immutable {@link LoggerItemImportHistory} implementation to log Import/Export EM/NE configuration activities.
 */
public class LoggerItemImportHistory extends LoggerItem implements Comparable<LoggerItemImportHistory> {
    private final String affectedObject;
    private final int executionId;

    /**
     * Creates a Immutable {@link LoggerItemImportHistory} instance initializing all attributes.
     *
     * @param affectedObject
     * @param message
     * @param severity
     * @param executionId
     */
    public LoggerItemImportHistory(@Nonnull final String affectedObject, @Nonnull final String message,
                                   @Nonnull final MessageSeverity severity, final int executionId) {
        super(message, severity);
        this.affectedObject = affectedObject;
        this.executionId = executionId;
    }

    /**
     * @return Current job execution id.
     */
    public int getExecutionId() {
        return executionId;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Nonnull
    public String getAffectedObject() {
        return affectedObject;
    }

    /**
     * Compares with {@link #getExecutionId()}
     */
    @Override
    public int compareTo(@Nonnull LoggerItemImportHistory input) {
        return ComparisonChain
                .start()
                .compare(this.executionId, input.getExecutionId())
                .result();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return Objects.hashCode(executionId, affectedObject, getMessage());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        final LoggerItemImportHistory other = (LoggerItemImportHistory) obj;

        return new EqualsBuilder()
            .append(executionId, other.executionId)
            .append(affectedObject, other.affectedObject)
            .append(getMessage(), other.getMessage())
            .isEquals();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return Joiner.on("").join(
                    MoreObjects.toStringHelper(this)
                        .omitNullValues()
                        .add("ExecutionId", executionId)
                        .add("AffectedObject", affectedObject)
                        .toString(),
                    super.toString());
    }
}
