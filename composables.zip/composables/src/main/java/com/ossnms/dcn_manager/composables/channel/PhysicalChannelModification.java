package com.ossnms.dcn_manager.composables.channel;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static java.lang.Integer.MAX_VALUE;

public class PhysicalChannelModification {

    private final NePhysicalConnectionRepository physicalNeRepository;
    private final NeEntityRepository neEntityRepository;
    private final NetworkElementNotifications neNotifications;

    private final ChannelNotifications channelNotifications;
    private final ChannelEntityRepository channelEntityRepository;
    private final ChannelPhysicalConnectionRepository channelPhysicalRepository;
    private final ChannelSchedulingConfiguration channelScheduling;

    private static final Logger LOGGER = LoggerFactory.getLogger(PhysicalChannelModification.class);

    public PhysicalChannelModification(
            @Nonnull NePhysicalConnectionRepository physicalNeRepository,
            @Nonnull NeEntityRepository neEntityRepository,
            @Nonnull NetworkElementNotifications neNotifications,
            @Nonnull ChannelNotifications channelNotifications,
            @Nonnull ChannelEntityRepository channelEntityRepository, 
            @Nonnull ChannelPhysicalConnectionRepository channelPhysicalRepository,
            @Nonnull ChannelSchedulingConfiguration channelScheduling) {
        this.physicalNeRepository = physicalNeRepository;
        this.neEntityRepository = neEntityRepository;
        this.neNotifications = neNotifications;
        this.channelNotifications = channelNotifications;
        this.channelEntityRepository = channelEntityRepository;
        this.channelPhysicalRepository = channelPhysicalRepository;
        this.channelScheduling = channelScheduling;
    }

    public void create(int logicalChannelId, boolean connectionType, int mediatorInstanceId) {
        ChannelPhysicalConnectionData connection = channelPhysicalRepository.insert(
                new ChannelConnectionInitialData().setActive(connectionType), logicalChannelId, mediatorInstanceId);

        channelNotifications.notifyCreateInstance(connection);

        channelScheduling.setMaxOngoingChannelJobCount(connection.getId(), concurrentActivations(logicalChannelId).orElse(MAX_VALUE));

        tryGetNeInfoData(logicalChannelId).forEach(ne -> createPhysicalNE(ne.getNeId(), connectionType, connection.getId()));
    }

    public void remove(int logicalChannelId, int physicalChannelId) {
        //cleanup NE connections
        tryGetNePhysicalData(physicalChannelId).forEach(ne -> removePhysicalNE(ne.getLogicalNeId(), ne.getId()));

        //remove channel connection
        channelPhysicalRepository.remove(physicalChannelId);

        //remove scaled slot for 
        channelScheduling.onChannelRemoved(physicalChannelId);

        // tell the world that this channel instance was deleted.
        channelNotifications.notifyDeleteInstance(logicalChannelId, physicalChannelId);
    }

    public void move(ChannelPhysicalConnectionData channel, int mediatorInstanceId) {
        try {
            channelPhysicalRepository.tryUpdate(new ChannelPhysicalConnectionMutationDescriptor(channel).setMediatorId(mediatorInstanceId));
        } catch (RepositoryException e) {
            LOGGER.error("Error getting repository.", e);
        }
    }

    private void createPhysicalNE(Integer neId, boolean connectionType, int channelInstanceId) {
        NePhysicalConnectionData ne = physicalNeRepository.insert(
                new NePhysicalConnectionInitialData().setActive(connectionType),
                neId, channelInstanceId);

        neNotifications.notifyCreateInstance(ne);
    }

    private void removePhysicalNE(int logicalNeId, int physicalNeId) {
        physicalNeRepository.remove(physicalNeId);

        // tell the world that this NE instance was deleted.
        neNotifications.notifyDeleteInstance(logicalNeId, physicalNeId);
    }

    private Stream<NeInfoData> tryGetNeInfoData(int channelId) {
        try {
            return stream(neEntityRepository.getNeInfoRepository().queryAll(channelId));
        } catch (RepositoryException e) {
            LOGGER.error("Failed to load NE information from repository: {}", e);
            return Stream.empty();
        }
    }

    private Stream<NePhysicalConnectionData> tryGetNePhysicalData(int channelId) {
        try {
            return stream(physicalNeRepository.queryAll()).filter(ne -> ne.getChannelInstanceId() == channelId);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to load physical NE instances from repository: {}", e);
            return Stream.empty();
        }
    }

    private Optional<Integer> concurrentActivations(int logicalChannelId) {
        try {
            return channelEntityRepository.queryChannel(logicalChannelId)
                    .map(ChannelEntity::getUserPreferences)
                    .filter(ChannelUserPreferencesData::isConcurrentActivationsLimited)
                    .map(ChannelUserPreferencesData::getConcurrentActivationsLimit);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to load Channel[id={}] from entity repository", logicalChannelId, e);
            return Optional.empty();
        }
    }

    private static <T> Stream<T> stream(Iterable<T> iterable) {
        return StreamSupport.stream(iterable.spliterator(), false);
    }
}
