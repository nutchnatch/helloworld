package com.ossnms.dcn_manager.exceptions;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Exception thrown by commands whenever the command is creating an object
 * with the same identifier name as another existing object.
 */
public class DuplicatedObjectNameException extends DcnManagerException {

	private static final long serialVersionUID = -9049277992680856893L;

	/** @see CommandException#CommandException() */
	public DuplicatedObjectNameException() { }

    /** @see CommandException#CommandException(String) */
	public DuplicatedObjectNameException(String message)
	{
		super(message);
	}

    /** @see CommandException#CommandException(Throwable) */
	public DuplicatedObjectNameException(Throwable cause)
	{
		super(cause);
	}

    /** @see CommandException#CommandException(String, Throwable) */
	public DuplicatedObjectNameException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see CommandException#CommandException(String, Throwable, boolean, boolean) */
	public DuplicatedObjectNameException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/** @see CommandException#CommandException(String, Object[]) */
    public DuplicatedObjectNameException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }
}
