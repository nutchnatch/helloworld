package com.ossnms.dcn_manager.composables.ne;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nonnull;
import java.io.Serializable;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.StreamSupport;

import static com.google.common.base.Predicates.not;
import static com.google.common.base.Predicates.notNull;
import static com.google.common.collect.Iterables.filter;

/**
 * <p>Merges a collection of existing NE Gateway Routes with a collection of
 * NE Gateway Route mutation descriptors. Determines which descriptors are
 * updates and which represent new routes. The result is a list of routes
 * that need to be added and a list of routes that need to be updated.</p>
 *
 * <p>Does not validateNewName whether all routes belong to the same NE.</p>
 *
 * <p>Takes care of route sorting as well, according to the sorting method
 * selected.</p>
 */
public class NeGatewayRouteMerging {

    /**
     * <p>Route pair.</p>
     *
     * <p>
     * A route pair contains a route mutation as its value, which not only contains new data
     * for storing but will also receive any priority modifications that may result from reordering.
     * The other pair element, its key, will be the original route data when available.
     * </p>
     */
    protected static final class RoutePair
        extends MutablePair<Optional<NeGatewayRouteData>, NeGatewayRouteMutationDescriptor> {

        private static final long serialVersionUID = 2387181686467662756L;

        protected RoutePair(NeGatewayRouteData routeData, NeGatewayRouteMutationDescriptor routeMutationDescriptor) {
            super(Optional.of(routeData), routeMutationDescriptor);
        }

        protected RoutePair(NeGatewayRouteMutationDescriptor routeMutationDescriptor) {
            super(Optional.empty(), routeMutationDescriptor);
        }

        private static final Predicate<RoutePair> HAS_KEY =
                input -> input.getKey().isPresent();

        private static final Function<RoutePair, NeGatewayRouteMutationDescriptor> GET_MUTATION =
                Pair::getValue;

    }

    /**
     * Route sorting mode.
     */
    public enum SortMode {
        /**
         * Sort according to the Auto Priority rules.
         * @see AutoPriorityComparator
         */
        AUTO_PRIORITY_ORDER(new AutoPriorityComparator()),
        /**
         * Sort according to Last In, Last Out order.
         * @see LiloComparator
         */
        LILO_ORDER(new LiloComparator());

        private final Comparator<RoutePair> comparator;

        SortMode(Comparator<RoutePair> comparator) {
            this.comparator = comparator;
        }

        protected Comparator<RoutePair> getComparator() {
            return comparator;
        }
    }

    /**
     * <p>Sort according to Last In, Last Out order.</p>
     *
     * <p>
     * New routes will always have lower priority than existing routes.
     * Relative ordering within new and existing route groups will be done
     * according to their existing priority values.
     * </p>
     *
     * <p>
     * Note: this comparator imposes orderings that are inconsistent with equals.
     * </p>
     */
    private static final class LiloComparator implements Comparator<RoutePair>, Serializable {
        private static final long serialVersionUID = 2758423541786444906L;

        @Override
        public int compare(@Nonnull RoutePair p1, @Nonnull RoutePair p2) {
            final Optional<NeGatewayRouteData> key1 = p1.getKey();
            final Optional<NeGatewayRouteData> key2 = p2.getKey();

            if (key1.isPresent() == key2.isPresent()) {
                return key1.isPresent()
                        ? key1.get().getPriority() - key2.get().getPriority()
                        : p1.getValue().getPriority().orElse(0) - p2.getValue().getPriority().orElse(0);
            } else if (key1.isPresent() && !key2.isPresent()) {
                return -1;
            } else {
                return 1;
            }
        }

    }

    /**
     * <p>
     * Compares two route pairs according to the Auto Priority rules.
     * Values defined in mutation descriptors associated with each pair take precedence
     * over the value defined in the existing instance.
     * </p>
     * <p>
     * In the absence of a cost value, the value 1 is assumed.
     * </p>
     * <p>
     * In the absence of an indicator of usage, it is assumed that the route is not in use.
     * </p>
     *
     * <p><img src="doc-files/autoprioritycomparator-flow.png"/></p>
     */
    /*
        @startuml doc-files/autoprioritycomparator-flow.png

        title Sorting routes according to //auto priority//

        start

        if (Cost A equals Cost B?) then (yes)

            if (A is in use?) then (yes)

                :Priority = A;

            elseif (B is in use?) then (yes)

                :Priority = B;

            else

                :Equal priority;

            endif

        elseif (Cost A < Cost B) then (yes)

            :Priority = A;

        else

            :Priority = B;

        endif

        stop
        @enduml
     */
    private static final class AutoPriorityComparator implements Comparator<RoutePair>, Serializable {
        private static final long serialVersionUID = 7656908889655790849L;

        private static final int DEFAULT_COST = 1;
        private static final Boolean DEFAULT_USAGE = Boolean.TRUE;

        @Override
        public int compare(RoutePair p1, RoutePair p2) {
            final int cost1 = getCost(p1);
            final int cost2 = getCost(p2);
            if (cost1 == cost2) {
                return isUsed(p2).compareTo(isUsed(p1));
            } else {
                return cost1 - cost2;
            }
        }

        private int getCost(RoutePair pair) {
            return pair.getValue().getCost().orElse(pair.getKey().isPresent() ? pair.getKey().get().getCost() : DEFAULT_COST);
        }

        private Boolean isUsed(RoutePair pair) {
            return pair.getValue().getUsed().orElse(pair.getKey().isPresent() ? pair.getKey().get().isUsed() : DEFAULT_USAGE);
        }
    }

    private final List<RoutePair> routePairs;

    /**
     * Creates a new object.
     *
     * @param mode Sort mode for the final results. If absent no sorting will be done.
     * @param existingRoutes Routes already saved in the target NE.
     * @param newOrUpdatedRoutes Route data to be added or modified.
     */
    public NeGatewayRouteMerging(@Nonnull Optional<SortMode> mode,
            @Nonnull Iterable<NeGatewayRouteData> existingRoutes,
            @Nonnull Iterable<NeGatewayRouteMutationDescriptor> newOrUpdatedRoutes) {

        routePairs = build(existingRoutes, newOrUpdatedRoutes);

        if (mode.isPresent()) {
            Collections.sort(routePairs, mode.get().getComparator());
        }

        updatePriorities(routePairs);
    }

    /**
     * @return A collection of route mutation descriptors representing existing routes
     *  that must be updated.
     */
    public Iterable<NeGatewayRouteMutationDescriptor> routesToUpdate() {
        return FluentIterable.from(routePairs)
                .filter(RoutePair.HAS_KEY)
                .transform(RoutePair.GET_MUTATION);
    }

    /**
     * @return A collection of route mutation descriptors representing new routes
     *  that must be created.
     */
    public Iterable<NeGatewayRouteMutationDescriptor> routesToCreate() {
        return FluentIterable.from(routePairs)
                .filter(not(RoutePair.HAS_KEY))
                .transform(RoutePair.GET_MUTATION);
    }

    /**
     * @return A collection of route keys from the new routes that must be created.
     */
    public Set<String> routeKeysToCreate() {
        return FluentIterable.from(routesToCreate())
                .transform(input -> input.getKey().orElse(input.getTarget().getKey()))
                .toSet();
    }

    /**
     * @return The current list of route pairs.
     */
    protected List<RoutePair> getRoutePairs() {
        return routePairs;
    }

    private void updatePriorities(List<RoutePair> pairs) {
        int currentPosition = 1;
        for (final RoutePair pair : pairs) {
            final NeGatewayRouteMutationDescriptor mutation = pair.getValue();
            final int currentPriority = mutation.getPriority().orElse(pair.getKey().isPresent() ? pair.getKey().get().getPriority() : 0);
            if (currentPriority != currentPosition) {
                mutation.setPriority(currentPosition);
            }
            ++currentPosition;
        }
    }

    private List<RoutePair> build(@Nonnull Iterable<NeGatewayRouteData> existingRoutes,
            @Nonnull Iterable<NeGatewayRouteMutationDescriptor> newOrUpdatedRoutes) {

        final List<RoutePair> routes = new LinkedList<>();

        for (final NeGatewayRouteData route : filter(existingRoutes, notNull())) {
            final Optional<NeGatewayRouteMutationDescriptor> mutationProvided =
                    StreamSupport.stream(newOrUpdatedRoutes.spliterator(), false)
                            .filter(input -> input != null && Objects.equals(input.getTarget().getKey(), route.getKey())).findFirst();
            routes.add(new RoutePair(route, mutationProvided.orElse(new NeGatewayRouteMutationDescriptor(route))));
        }

        for (final NeGatewayRouteMutationDescriptor routeMutation : filter(newOrUpdatedRoutes, notNull())) {
            final Optional<NeGatewayRouteData> existingRoute =
                    StreamSupport.stream(existingRoutes.spliterator(), false)
                            .filter(input -> input != null && Objects.equals(input.getKey(), routeMutation.getTarget().getKey())).findFirst();
            if (!existingRoute.isPresent()) {
                routes.add(new RoutePair(routeMutation));
            }
        }

        return routes;
    }

}
