package com.ossnms.dcn_manager.composables.outbound.exception;

import com.ossnms.dcn_manager.core.outbound.exception.OutboundException;

public class LicenseException extends OutboundException {

    private static final long serialVersionUID = 730856848033778199L;

    /**
     * @see Exception#Exception()
     */
    public LicenseException() {

    }

    /**
     * @see Exception#Exception(String)
     */
    public LicenseException(String message) {
        super(message);
    }

    /**
     * @see Exception#Exception(Throwable)
     */
    public LicenseException(Throwable cause) {
        super(cause);
    }

    /**
     * @see Exception#Exception(String,Throwable)
     */
    public LicenseException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @see Exception#Exception(String,Throwable,boolean,boolean)
     */
    public LicenseException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

}
