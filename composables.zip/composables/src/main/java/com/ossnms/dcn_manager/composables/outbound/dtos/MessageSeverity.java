package com.ossnms.dcn_manager.composables.outbound.dtos;

/**
 *  Message severity for LoggerItems.
 */
public enum MessageSeverity {    
    MESSAGE("message"), WARNING("warning"), ERROR("error"), INFO("info");
    
    private final String name;
    
    private MessageSeverity(final String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
}