package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;

import static com.google.common.base.Preconditions.checkState;
import static com.google.common.base.Strings.isNullOrEmpty;
import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Base validation for Containers and Systems.
 */
abstract class ValidatorBase {
    static final int LAST_ASSIGNMENT = 1;

    private final ContainerRepository containerRepository;
    private final SystemRepository systemRepository;

    ValidatorBase(ContainerRepository containerRepository, SystemRepository systemRepository) {
        this.containerRepository = containerRepository;
        this.systemRepository = systemRepository;
    }

    public abstract void validateNewName(final String newName) throws DuplicatedObjectNameException, RepositoryException;

    /*
     * The container name must be unique between containers.
     */
    public void validateContainerUniqueName(@Nonnull final String newName)
            throws DuplicatedObjectNameException, RepositoryException {

        final boolean nameExists = containerRepository.queryByName(newName).isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(tr(Message.DUPLICATED_CONTAINER_NAME, newName));
        }
    }

    /*
     * The System container name must be unique between System containers.
     */
    void validateSystemUniqueName(@Nonnull final String newName)
            throws DuplicatedObjectNameException, RepositoryException {

        final boolean nameExists = systemRepository.queryByName(newName).isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(tr(Message.DUPLICATED_SYSTEM_NAME, newName));
        }
    }

    void validateEmptyName(String newName, Message message) {
        checkState(!isNullOrEmpty(newName), tr(message));
    }

    ContainerRepository getContainerRepository() {
        return containerRepository;
    }

    SystemRepository getSystemRepository() {
        return systemRepository;
    }
}
