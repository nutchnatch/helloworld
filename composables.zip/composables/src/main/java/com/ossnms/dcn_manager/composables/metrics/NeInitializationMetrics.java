package com.ossnms.dcn_manager.composables.metrics;

import com.codahale.metrics.Histogram;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.RatioGauge;
import com.codahale.metrics.UniformReservoir;

import javax.annotation.Nonnull;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import static java.time.temporal.ChronoUnit.SECONDS;

/**
 * <p>Groups a set of metrics related to the performance of the NE initialization cycle.
 * Specifically, the length of time spent between the Initializing and Initialized NE states.</p>
 *
 * <p>This amount of time is measured in seconds and is presented as min, mean, max, standard deviation
 * and quantiles like the median or 95th percentile.</p>
 *
 * @see Histogram
 */
public class NeInitializationMetrics implements NeInitializationMetricsMBean {

	static final int DEFAULT_STANDALONE_THRESHOLD = 20; // seconds
	static final int DEFAULT_RNE_THRESHOLD = 120; // seconds

	public static final String NE_INITIALIZATION = "ne-initialization";

	private static final String NE_INITIALIZATION_STANDALONE_HISTOGRAM = "ne-initialization.standalone.histogram";
	private static final String NE_INITIALIZATION_RNE_HISTOGRAM = "ne-initialization.rne.histogram";

	static final String NE_INITIALIZATION_STANDALONE_OPM = "ne-initialization.standalone.opm";
	static final String NE_INITIALIZATION_RNE_OPM = "ne-initialization.rne.opm";

	private Histogram standalone;
	private Histogram rne;

	private final AtomicLong standaloneCount;
	private final AtomicInteger standaloneThreshold;
	private final AtomicLong standaloneUnderThreshold;
	private final AtomicLong rneCount;
	private final AtomicInteger rneThreshold;
	private final AtomicLong rneUnderThreshold;

	private final MetricRegistry metricsRegistry;

	/**
	 * Constructs a new instance.
	 * @param registry The component metrics registry. Will be used to register
	 *                 metrics related to the performance of the NE initialization cycle.
	 */
	public NeInitializationMetrics(@Nonnull MetricRegistry registry) {

		metricsRegistry = registry;

		standalone = new Histogram(new UniformReservoir());
		standaloneCount = new AtomicLong();
		standaloneThreshold = new AtomicInteger(DEFAULT_STANDALONE_THRESHOLD);
		standaloneUnderThreshold = new AtomicLong();

		rne = new Histogram(new UniformReservoir());
		rneCount = new AtomicLong();
		rneThreshold = new AtomicInteger(DEFAULT_RNE_THRESHOLD);
		rneUnderThreshold = new AtomicLong();

		registry.register(NE_INITIALIZATION_STANDALONE_HISTOGRAM, standalone);
		registry.register(NE_INITIALIZATION_STANDALONE_OPM, new StandaloneOpmRatioGauge());

		registry.register(NE_INITIALIZATION_RNE_HISTOGRAM, rne);
		registry.register(NE_INITIALIZATION_RNE_OPM, new RneOpmRatioGauge());
	}

	/**
	 * {@inheritDoc}
	 *
	 * Composite counters, such as histograms, are not cleared but rather replaced to simplify concurrency control.
	 * The JVM memory model implies that this means that some threads may still act upon the removed object instance
	 * however this is not a matter of concern.
	 */
	@Override
	public void clear() {
		standaloneCount.set(0);
		standaloneUnderThreshold.set(0);
		rneCount.set(0);
		rneUnderThreshold.set(0);

		metricsRegistry.remove(NE_INITIALIZATION_STANDALONE_HISTOGRAM);
		metricsRegistry.remove(NE_INITIALIZATION_RNE_HISTOGRAM);

		standalone = new Histogram(new UniformReservoir());
		rne = new Histogram(new UniformReservoir());

		metricsRegistry.register(NE_INITIALIZATION_STANDALONE_HISTOGRAM, standalone);
		metricsRegistry.register(NE_INITIALIZATION_RNE_HISTOGRAM, rne);
	}

	/**
	 * Publishes the duration of one initialization cycle for a standalone network element.
	 * @param initializationDuration Initialization cycle duration.
	 */
	public void publish(@Nonnull Duration initializationDuration) {

		final long duration = initializationDuration.get(SECONDS);

		standalone.update(duration);
		standaloneCount.incrementAndGet();

		if (duration <= standaloneThreshold.get()) {
			standaloneUnderThreshold.incrementAndGet();
		}
	}

	/**
	 * Publishes the duration of one initialization cycle for an RNE, i.e., a network element
	 * that is accessible through a GNE.
	 * @param initializationDuration Initialization cycle duration.
	 */
	public void publishRne(@Nonnull Duration initializationDuration) {

		final long duration = initializationDuration.get(SECONDS);

		rne.update(duration);
		rneCount.incrementAndGet();

		if (duration <= rneThreshold.get()) {
			rneUnderThreshold.incrementAndGet();
		}

	}

	@Override
	public int getStandaloneThresholdInSeconds() {
		return standaloneThreshold.get();
	}

	@Override
	public int getRneThresholdInSeconds() {
		return rneThreshold.get();
	}

	@Override
	public void setStandaloneThresholdInSeconds(int newThreshold) {
		standaloneThreshold.set(newThreshold);
		standaloneCount.set(0);
		standaloneUnderThreshold.set(0);
	}

	@Override
	public void setRneThresholdInSeconds(int newThreshold) {
		rneThreshold.set(newThreshold);
		rneCount.set(0);
		rneUnderThreshold.set(0);
	}

	private class StandaloneOpmRatioGauge extends RatioGauge {
		@Override
		protected Ratio getRatio() {
			return Ratio.of(standaloneUnderThreshold.get(), standaloneCount.get());
		}
	}

	private class RneOpmRatioGauge extends RatioGauge {
		@Override
		protected Ratio getRatio() {
			return Ratio.of(rneUnderThreshold.get(), rneCount.get());
		}
	}

}
