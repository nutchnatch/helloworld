package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.Message.SYSTEM_CREATED;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Optional.empty;
import static java.util.Optional.of;

/**
 * Creates and stores a new System, if the creation request is valid.
 * Otherwise an exception will be thrown.
 */
public class SystemCreationBase<C extends CallContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemCreationBase.class);

    private final C context;
    private final SystemRepository repository;
    private final SystemNotifications notifications;
    private final LoggerManager<C> loggerManager;
    private final SystemValidator validator;

    public SystemCreationBase(
            @Nonnull C context,
            @Nonnull SystemRepository systemRepository,
            @Nonnull SystemNotifications notifications,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull SystemValidator validator) {

        this.context = context;
        repository = systemRepository;
        this.notifications = notifications;
        this.loggerManager = loggerManager;
        this.validator = validator;
    }

    public Optional<SystemInfo> tryCreateSystem(@Nonnull final SystemCreationDescriptor creationDescriptor) {
        
        final Optional<SystemInfo> systemInfo = validate(creationDescriptor).flatMap(this::createSystem);

        systemInfo.ifPresent(notifications::notifyCreate);
        systemInfo.ifPresent(this::logCreation);

        return systemInfo;
    }

    private Optional<SystemCreationDescriptor> validate(SystemCreationDescriptor descriptor) {
        try {
            validator.validateNewName(descriptor.getName());
            return of(descriptor);
        } catch (DuplicatedObjectNameException | RepositoryException e) {
            return empty();
        }
    }

    private Optional<SystemInfo> createSystem(final SystemCreationDescriptor creation) {
        try {
            return of(repository.create(creation));
        } catch (RepositoryException e) {
            LOGGER.error("Failed to create system container {}", creation, e);
            return empty();
        }
    }

    private void logCreation(SystemInfo entity) {
        loggerManager.createCommandLog(context, new LoggerItemContainer(entity.getName(), tr(SYSTEM_CREATED)));
        LOGGER.info("Created System '{}' with ID {}.", entity.getName(), entity.getId());
    }
}
