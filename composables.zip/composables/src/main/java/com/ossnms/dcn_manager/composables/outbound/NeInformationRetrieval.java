package com.ossnms.dcn_manager.composables.outbound;

import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.outbound.exception.OutboundException;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;

/**
 * Exposes methods that allow to update our internal model
 * by retrieving or receiving information from other components.
 */
public interface NeInformationRetrieval {

    /**
     * Retrieves NE information from the mediator and updates
     * all relevant internal NE domain entities with it.
     *
     * @param physicalNeId Physical NE connection identifier.
     * @param mediatorInstance Physical Mediator instance connection identifier. Used to
     * determine actual physical mediator being interrogated for a logical NE.
     * @return An NE entity, already updated with information retrieved from the mediator.
     * @throws DataUpdateException When it was not possible to store or update information.
     * @throws OutboundException When it was not possible to retrieve information.
     * @throws UnknownNetworkElementIdException When an update was requested for an NE that
     *  has since been removed.
     * @throws UnknownChannelIdException When an update was requested for an NE that belongs
     *  to a Channel that has since been removed.
     */
    NeEntity updateNeDataFromMediator(int physicalNeId)
        throws DataUpdateException, OutboundException, UnknownNetworkElementIdException, UnknownChannelIdException;

}
