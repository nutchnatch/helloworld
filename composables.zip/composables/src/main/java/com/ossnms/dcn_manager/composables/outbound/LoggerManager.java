package com.ossnms.dcn_manager.composables.outbound;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemImportHistory;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;

/**
 * Record the system activities.
 * 
 * @param <C> Current Context
 */
public interface LoggerManager<C extends CallContext> {

    /**
     * Logger for System Events.
     * 
     * @param context
     * @param loggerMessage
     */
    void createSystemEventLog(C context, LoggerItem... loggerItems);

    /**
     * Logger for Commands.
     * 
     * @param context
     * @param loggerMessage
     */
    void createCommandLog(C context, LoggerItem... loggerItems);

    /**
     * Logger for NE Resources changes.
     * 
     * @param context
     * @param loggerMessage
     */
    void createNetworkResourceLog(C context, LoggerItemNe... loggerItems);
    
    /**
     * Logger for NE Network Events.
     * 
     * @param context
     * @param loggerMessage
     */
    void createNetworkEventLog(C context, LoggerItemNe... loggerItems);

    /**
     * Logger for Import Configuration history.
     * 
     * @param context
     * @param loggerMessage
     */
    void createImportHistoryLog(C context, LoggerItemImportHistory... loggerItems);
}
