package com.ossnms.dcn_manager.composables.outbound.dtos;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.builder.EqualsBuilder;

import com.google.common.base.Joiner;
import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;

/**
 * Provides common behavior for logger items that contain an affected object name.
 */
abstract class LoggerItemWithAffectedObject extends LoggerItem {

    private final String affectedObjectName;

    protected LoggerItemWithAffectedObject(String affectedObjectName, String message, MessageSeverity severity) {
        super(message, severity);
        this.affectedObjectName = affectedObjectName.trim();
    }

    protected LoggerItemWithAffectedObject(String affectedObjectName, String message) {
        super(message);
        this.affectedObjectName = affectedObjectName.trim();
    }


   protected abstract String getAffectedObjectPrefix();

   /**
    * {@inheritDoc}
    */
   @Override
   @Nonnull
   public String getAffectedObject() {
       final Joiner joiner = Joiner.on(": ");
       return joiner.join(getAffectedObjectPrefix(), affectedObjectName);
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public int hashCode() {
       return Objects.hashCode(affectedObjectName, getMessage());
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public boolean equals(Object obj) {
       if (this == obj) {
           return true;
       }

       if (obj == null || !getClass().isAssignableFrom(obj.getClass())) {
           return false;
       }

       final LoggerItemWithAffectedObject other = (LoggerItemWithAffectedObject) obj;

       return new EqualsBuilder()
           .append(affectedObjectName, other.affectedObjectName)
           .append(getMessage(), other.getMessage())
           .isEquals();
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public String toString() {
       return Joiner.on("").join(
                   MoreObjects.toStringHelper(this)
                       .omitNullValues()
                       .add("affectedObject", affectedObjectName)
                       .toString(),
                   super.toString());
   }

}
