package com.ossnms.dcn_manager.exceptions;

/**
 * Exception thrown whenever the given identifier does not correspond to
 * an existing system container.
 */
public class NonPrimaryContainerSettedException extends DcnManagerException {

	private static final long serialVersionUID = 3916671200572975916L;

    /** @see DcnManagerException#DcnManagerException() */
	public NonPrimaryContainerSettedException() { }

    /** @see DcnManagerException#DcnManagerException(String) */
	public NonPrimaryContainerSettedException(String message)
	{
		super(message);
	}

    /** @see DcnManagerException#DcnManagerException(Throwable) */
	public NonPrimaryContainerSettedException(Throwable cause)
	{
		super(cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable) */
	public NonPrimaryContainerSettedException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable, boolean, boolean) */
	public NonPrimaryContainerSettedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

    /** @see DcnManagerException#DcnManagerException(String, Object[]) */
    public NonPrimaryContainerSettedException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String, Throwable, Object[]) */
    public NonPrimaryContainerSettedException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }
}
