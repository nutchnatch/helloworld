package com.ossnms.dcn_manager.composables.metrics;

/**
 * JMX MBean interface that exposes operations and constant values related
 * to metrics about NE initialization OPM and statistics.
 */
public interface NeInitializationMetricsMBean {

	/**
	 * Clears current JMX counter values.
	 */
	void clear();

	/**
	 * @return The current OPM threshold value, in seconds, for determining the
	 * service level related to initialization of NEs not behind a GNE.
	 */
	int getStandaloneThresholdInSeconds();

	/**
	 * @return The current OPM threshold value, in seconds, for determining the
	 * service level related to initialization of NEs behind a GNE.
	 */
	int getRneThresholdInSeconds();

	/**
	 * Changes the current OPM threshold for determining the
	 * service level related to initialization of NEs not
	 * behind a GNE.
	 *
	 * Because the threshold is being changed, the OPM ratio will be reset
	 * as well.
	 *
	 * @param newThreshold    New OPM threshold value, in seconds.
	 */
	void setStandaloneThresholdInSeconds(int newThreshold);

	/**
	 * Changes the current OPM threshold for determining the
	 * service level related to initialization of NEs behind a GNE.
	 *
	 * Because the threshold is being changed, the OPM ratio will be reset
	 * as well.
	 *
	 * @param newThreshold    New OPM threshold value, in seconds.
	 */
	void setRneThresholdInSeconds(int newThreshold);

}
