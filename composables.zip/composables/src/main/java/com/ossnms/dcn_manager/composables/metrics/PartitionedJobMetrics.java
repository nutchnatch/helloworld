package com.ossnms.dcn_manager.composables.metrics;

import com.ossnms.dcn_manager.core.policies.PartitionedJobsInfo;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Stream;


public class PartitionedJobMetrics implements PartitionedJobMetricsMXBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(PartitionedJobMetrics.class);

    private final PartitionedJobsInfo delegate;

    private final String name;

    public PartitionedJobMetrics(PartitionedJobsInfo mediationInteractionManager, String name) {
        this.delegate = mediationInteractionManager;
        this.name = name;
    }


    @Override
    public int getOngoingJobCount() {
        return delegate.getOngoingJobCount();
    }

    @Override
    public int getOngoingJobCount(int partitionId) {
        return delegate.getOngoingJobCount(partitionId);
    }

    @Override
    public int getPendingJobCount() {
        return delegate.getPendingJobCount();
    }

    @Override
    public int getMaxOngoingJobCount(int partitionId) {
        return delegate.getMaxOngoingJobCount(partitionId);
    }

    @Override
    public int getPendingJobCount(int partitionId) {
        return delegate.getPendingJobCount(partitionId);
    }

    @Override
    public String dumpOngoingAsString() {
        final Stream<PolicyJob<?>> onGoingJobs = delegate.getOngoingJobs();
        return new JobMetricsOutputFormatter(onGoingJobs, name, ONGOING).getAsString();
    }

    @Override
    public String dumpOngoingAsString(int partitionId) {
        final Stream<PolicyJob<?>> ongoingJobs = delegate.getOngoingJobs(partitionId);
        return new JobMetricsOutputFormatter(ongoingJobs, name, ONGOING, String.valueOf(partitionId)).getAsString();
    }

    @Override
    public void dumpOngoingToLog() {
        final Stream<PolicyJob<?>> onGoingJobs = delegate.getOngoingJobs();
        new JobMetricsOutputFormatter(onGoingJobs, name, ONGOING).dumpTo(LOGGER::warn);
    }

    @Override
    public void dumpOngoingToLog(int partitionId) {
        final Stream<PolicyJob<?>> ongoingJobs = delegate.getOngoingJobs(partitionId);
        new JobMetricsOutputFormatter(ongoingJobs, name, ONGOING, String.valueOf(partitionId)).dumpTo(LOGGER::warn);
    }

    @Override
    public String dumpPendingAsString() {
        final Stream<PolicyJob<?>> pendingJobs = delegate.getPendingJobs();
        return new JobMetricsOutputFormatter(pendingJobs, name, PENDING).getAsString();
    }

    @Override
    public String dumpPendingAsString(int partitionId) {
        final Stream<PolicyJob<?>> pendingJobs = delegate.getPendingJobs(partitionId);
        return new JobMetricsOutputFormatter(pendingJobs, name, PENDING, String.valueOf(partitionId)).getAsString();
    }

    @Override
    public void dumpPendingToLog() {
        final Stream<PolicyJob<?>> pendingJobs = delegate.getPendingJobs();
        new JobMetricsOutputFormatter(pendingJobs, name, PENDING).dumpTo(LOGGER::warn);
    }

    @Override
    public void dumpPendingToLog(int partitionId) {
        final Stream<PolicyJob<?>> pendingJobs = delegate.getPendingJobs(partitionId);
        new JobMetricsOutputFormatter(pendingJobs, name, PENDING, String.valueOf(partitionId)).dumpTo(LOGGER::warn);
    }

}
