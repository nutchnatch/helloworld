package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.i18n.Message.CONTAINER_CREATED;
import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Creates and stores a new Container, if the creation request is valid.
 * Otherwise an exception will be thrown.
 */
public class ContainerCreationBase<C extends CallContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContainerCreationBase.class);

    private final C context;
    private final ContainerRepository repository;
    private final ContainerNotifications notifications;
    private final LoggerManager<C> loggerManager;
    private final ContainerValidator validator;

    public ContainerCreationBase(
            @Nonnull C context,
            @Nonnull ContainerRepository repository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull ContainerNotifications notifications,
            @Nonnull LoggerManager<C> loggerManager) {

        this.context = context;
        this.repository = repository;
        this.notifications = notifications;
        this.loggerManager = loggerManager;
        this.validator = new ContainerValidator(repository, systemRepository);
    }

    public ContainerInfo tryCreateContainer(@Nonnull final ContainerCreationDescriptor creation) throws DuplicatedObjectNameException, RepositoryException {

        validator.validateNewName(creation.getName());

        final ContainerInfo entity = createContainer(creation);

        loggerManager.createCommandLog(context, new LoggerItemContainer(entity.getName(), tr(CONTAINER_CREATED)));

        LOGGER.info("Created Container '{}' with ID {}.", entity.getName(), entity.getId());

        return entity;
    }

    private ContainerInfo createContainer(final ContainerCreationDescriptor creation) throws RepositoryException {
        final ContainerInfo entity = repository.create(creation);

        notifications.notifyCreate(entity);
        return entity;
    }
}
