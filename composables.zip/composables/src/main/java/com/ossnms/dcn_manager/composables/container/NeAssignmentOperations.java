package com.ossnms.dcn_manager.composables.container;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Delegate the NE assignment CRUD operations.
 */
public class NeAssignmentOperations<C extends CallContext> {
    private static final Logger LOGGER = LoggerFactory.getLogger(NeAssignmentOperations.class);

    private final ContainerRepository containerRepository;
    private final ContainerNotifications notifications;
    private final LoggerManager<C> loggerManager;
    private final C context;

    public NeAssignmentOperations(ContainerRepository containerRepository, ContainerNotifications containerNotifications,
            LoggerManager<C> loggerManager, C context) {
        this.containerRepository = containerRepository;
        this.notifications = containerNotifications;
        this.loggerManager = loggerManager;
        this.context = context;
    }

    /**
     * Create a New Assignment.
     *
     * @param neInfoData The NE to be associated.
     * @param assignment The new assignment to be save.
     */
    public void create(@Nonnull final NeUserPreferencesData neInfoData, @Nonnull final NeAssignmentData assignment)
            throws RepositoryException {
        containerRepository.addNeAssignment(assignment);
        LOGGER.info("Notifying entry of NE {} in container {}", neInfoData.getId(),
                assignment.getContainerInfo().getId());

        notifications.notifyChanges(
                new ContainerNeAssignmentAddedEvent(assignment.getContainerInfo().getId(), neInfoData.getId(),
                        assignment.getAssignmentType()));

        createCommandLog(Message.CONTAINER_ADDED_ASSIGNMENT, neInfoData, assignment);
    }

    /**
     * Update a existing assignment.
     *
     * @param neInfoData            The associated NE.
     * @param changedAssignmentType The assignment to be updated.
     */
    public void update(@Nonnull final NeUserPreferencesData neInfoData,
            @Nonnull final NeAssignmentData changedAssignmentType) throws RepositoryException {
        if (containerRepository.tryUpdateNeAssignment(changedAssignmentType)) {
            LOGGER.info("Notifying update info of NE {} in container {}", neInfoData.getId(),
                    changedAssignmentType.getContainerInfo().getId());

            notifications.notifyChanges(
                    new ContainerNeAssignmentUpdatedEvent(changedAssignmentType.getContainerInfo().getId(),
                            neInfoData.getId(), changedAssignmentType.getAssignmentType()));

            createCommandLog(Message.CONTAINER_UPDATED_ASSIGNMENT, neInfoData, changedAssignmentType);
        }
    }

    /**
     * Remove a existing assignment.
     *
     * @param neInfoData The associated NE
     * @param assignment The assignment to be removed.
     */
    public void delete(@Nonnull final NeUserPreferencesData neInfoData, @Nonnull final NeAssignmentData assignment)
            throws RepositoryException {
        if (containerRepository.tryRemoveNeAssignment(assignment)) {
            LOGGER.info("Notifying removal of NE {} from container {}", neInfoData.getId(),
                    assignment.getContainerInfo().getId());

            notifications.notifyChanges(
                    new ContainerNeAssignmentRemovedEvent(assignment.getContainerInfo().getId(), neInfoData.getId()));

            createCommandLog(Message.CONTAINER_REMOVED_ASSIGNMENT, neInfoData, assignment);
        }
    }

    private void createCommandLog(Message message, NeUserPreferencesData neInfoData, NeAssignmentData assignment) {
        loggerManager.createCommandLog(context, new LoggerItemContainer(assignment.getContainerInfo().getName(),
                tr(message, "NE", neInfoData.getName())));
    }
}
