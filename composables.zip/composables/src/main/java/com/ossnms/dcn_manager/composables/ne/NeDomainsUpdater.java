package com.ossnms.dcn_manager.composables.ne;

import com.google.common.base.Throwables;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.ossnms.dcn_manager.core.entities.domain.DomainCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.events.domain.DomainChildrenChanged;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationAdded;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationDeleted;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static com.google.common.collect.Iterables.isEmpty;

/**
 * Handles domain membership changes for NEs.
 */
public class NeDomainsUpdater {

    private static final int RETRIES = 3;

    private static final Logger LOGGER = LoggerFactory.getLogger(NeDomainsUpdater.class);

    private final DomainRepository domainRepository;
    private final DomainNotifications domainNotifications;
    private final SettingsRepository settingsRepository;

    /**
     * Creates a new object.
     *
     * @param domainRepository Domain repository instance.
     * @param domainNotifications Outgoing domain notifications manager instance.
     */
    public NeDomainsUpdater(@Nonnull DomainRepository domainRepository, @Nonnull DomainNotifications domainNotifications, @Nonnull SettingsRepository settingsRepository) {
        this.domainRepository = domainRepository;
        this.domainNotifications = domainNotifications;
        this.settingsRepository = settingsRepository;
    }

    /**
     * <p>Stores transitive membership in domains for a NE.</p>
     *
     * @see #storeTransitiveDomains(int, ImmutableSet)
     * @param neId Identifier of the target NE.
     * @param neRoutes Currently known gateway routes for the target NE.
     * @return All NE domains, including any new associations.
     */
    public Iterable<DomainInfoData> storeTransitiveDomains(int neId, @Nonnull Iterable<NeGatewayRouteData> neRoutes) throws RepositoryException {

        return storeTransitiveDomains(neId, extractDomainNamesFromRoutes(neRoutes));
    }

    /**
     * <p>Stores transitive membership in domains for a NE.</p>
     *
     * <p>Will perform the following actions as necessary:</p><ul>
     * <li>Associate the NE with new domains;</li>
     * <li>Remove the NE from old domains;</li>
     * <li>Delete domains without any NEs.</li>
     * </ul>
     *
     * @param neId Target NE identifier.
     * @param domainNames Full set of transitive domain names known for the NE. Includes names added and
     *  names that already existed. Does not include names removed.
     * @return All NE domains, including any new associations.
     */
    public Iterable<DomainInfoData> storeTransitiveDomains(int neId, @Nonnull Set<String> domainNames) throws RepositoryException {
        final Iterable<DomainInfoData> existingDomains = domainRepository.queryTransitiveDomainsForNE(neId);
        LOGGER.info("Storing transitive domains for NE {}: {}, existing are {}.", neId, domainNames, Iterables.transform(existingDomains, DomainInfoData::getName));
        return storeDomains(neId, domainNames, existingDomains,
                domainRepository::tryAddTransitiveNE, domainRepository::tryRemoveTransitiveNE);
    }

    /**
     * <p>Stores natural membership in domains for a NE.</p>
     *
     * <p>Will perform the following actions as necessary:</p><ul>
     * <li>Associate the NE with new domains;</li>
     * <li>Remove the NE from old domains;</li>
     * <li>Delete domains without any NEs.</li>
     * </ul>
     *
     * @param neId Target NE identifier.
     * @param domainNames Full set of natural domain names known for the NE. Includes names added and
     *  names that already existed. Does not include names removed.
     * @return All NE domains, including any new associations.
     */
    public Iterable<DomainInfoData> storeNaturalDomains(int neId, @Nonnull Set<String> domainNames) throws RepositoryException {
        final Iterable<DomainInfoData> existingDomains = domainRepository.queryNaturalDomainsForNE(neId);
        LOGGER.info("Storing natural domains for NE {}: {}, existing are {}.", neId, domainNames, Iterables.transform(existingDomains, DomainInfoData::getName));
        return storeDomains(neId, domainNames, existingDomains,
                domainRepository::tryAddNaturalNE, domainRepository::tryRemoveNaturalNE);
    }

    private Iterable<DomainInfoData> storeDomains(int neId, @Nonnull Set<String> domainNames,
            @Nonnull Iterable<DomainInfoData> existingDomains, @Nonnull AddNeToDomainFunction addFunction,
            @Nonnull RemoveNeFromDomainFunction removeFunction) throws RepositoryException {

        /*
         * You will notice that this domain management method is one big query-then-act operation in what
         * concerns the emission of notifications to the outside world.
         *
         * This should be OK as long as concurrency is limited to the domains themselves, i.e., as long as
         * there are no concurrent domain updates for the same NE.
         */

        final List<DomainInfoData> changedDomains = new LinkedList<>();

        final Set<DomainInfoData> domainsBeforeUpdate = Sets.newHashSet(domainRepository.queryAllForNE(neId));

        final SetView<String> currentNotExisting = Sets.difference(domainNames,
                FluentIterable.from(existingDomains).transform(DomainInfoData::getName).toSet());

        for (final DomainInfoData info : existingDomains) {
            if (!domainNames.contains(info.getName())) {
                LOGGER.info("Removing NE {} from domain {}", neId, info);
                // if we can't remove the NE from the domain, it only means that the association (or the domain) no longer exist.
                if (removeFunction.tryRemoveNE(info.getId(), neId)) {
                    changedDomains.add(info);
                }
            }
        }

        for (final String name : currentNotExisting) {
            final Optional<DomainInfoData> domain = storeDomain(neId, name, addFunction);
            if (domain.isPresent()) {
                changedDomains.add(domain.get());
            }
        }

        final Set<DomainInfoData> domainsAfterUpdate = Sets.newHashSet(domainRepository.queryAllForNE(neId));

        changedDomains.forEach(info ->
            domainNotifications.notifyChanges(
                    new DomainChildrenChanged(info,
                            ImmutableList.copyOf(domainRepository.queryChildrenNEs(info.getId()))))
        );

        final Set<DomainInfoData> addedDomains = Sets.difference(domainsAfterUpdate, domainsBeforeUpdate);
        addedDomains.forEach(info -> {
            LOGGER.info("Notifying entry of NE {} in domain {}", neId, info);
            domainNotifications.notifyChanges(new DomainParticipationAdded(info.getId(), neId));
        });

        final Set<DomainInfoData> removedDomains = Sets.difference(domainsBeforeUpdate, domainsAfterUpdate);
        removedDomains.forEach(info -> {
            LOGGER.info("Notifying removal of NE {} from domain {}", neId, info);
            domainNotifications.notifyChanges(new DomainParticipationDeleted(info.getId(), neId));
            tryDeleteDomainIfEmpty(info);
        });

        return changedDomains;
    }

    /**
     * @param routes NE Gateway routes.
     * @return A set of domain names associated with the gateway routes.
     */
    public ImmutableSet<String> extractDomainNamesFromRoutes(@Nonnull Iterable<NeGatewayRouteData> routes) {
        return FluentIterable.from(routes)
            .transform(NeGatewayRouteData.GET_DOMAIN_NAME::apply)
            .filter(Optional::isPresent).transform(Optional::get)
            .toSet();
    }

    /**
     * <p>Attempts to delete a domain if it no longer holds any NEs. This method will be unable to delete the domain
     * if it contains any children or the {@link DomainRepository#delete(DomainDeletionDescriptor)} method fails.</p>
     *
     * <p>A reason for failure is a race condition where another thread adds an NE to the domain just
     * before we delete it but after we verified that it had no children. In this case the domain will not be deleted.</p>
     *
     * <p>Repository errors will not be propagated.</p>
     *
     * @param domainInfo Domain to be deleted.
     * @return True if the domain was removed successfully.
     */
    public boolean tryDeleteDomainIfEmpty(@Nonnull DomainInfoData domainInfo) {

        if (isEmpty(domainRepository.queryChildrenNEs(domainInfo.getId()))) {
            try {
                LOGGER.info("Deleting empty domain {}.", domainInfo);
                domainRepository.delete(new DomainDeletionDescriptor(domainInfo.getId()));
                domainNotifications.notifyDelete(domainInfo);
                return true;
            } catch (final RepositoryException e) {
                LOGGER.warn("Failed to remove domain with id {}. Ignoring: {}", domainInfo.getId(), Throwables.getStackTraceAsString(e));
            }
        }

        return false;
    }

    /**
     * Stores an association between an NE and a Domain. Will create the domain if necessary.
     *
     * @param neId NE child.
     * @param domainName Target domain name.
     * @param addFunction Actual function that creates a new membership of the NE within the domain.
     * @return An instance of the domain business object if the association could be established.
     */
    private Optional<DomainInfoData> storeDomain(int neId, String domainName, AddNeToDomainFunction addFunction) {
        try {
            boolean added;
            Optional<DomainInfoData> domain;
            int retries = 1;

            /*
             * The read-modify operation is subject to race conditions that may cause modifications to fail.
             *
             * Therefore we must be able to detect those races and attempt to recover by repeating all operations
             * that fail because of data changes.
             *
             * Possible races and their causes:
             *
             *  - Can't create the new domain: query didn't find anything but create failed. Someone
             *    created the new domain already. Repeat to pick up the new domain.
             *  - Can't add the NE to the domain: add failed. Someone deleted the domain in between.
             *    Repeat to recreate the domain.
             */
            do {
                domain = domainRepository.queryByName(domainName);
                if (!domain.isPresent()) {
                    LOGGER.info("Creating domain '{}'", domainName);
                    domain = domainRepository.tryCreate(new DomainCreationDescriptor(domainName, isDiscoverAllNetworkEnabled()));
                    if (domain.isPresent()) {
                        domainNotifications.notifyCreate(domain.get());
                    }
                }
                LOGGER.info("Associating NE {} with domain {} (attempt {})", neId, domain, retries);
                added = domain.isPresent() && addFunction.tryAddNE(domain.get().getId(), neId);
            } while (!added && retries++ < RETRIES);
            return domain;
        } catch (final RepositoryException e) {
            LOGGER.warn("Error storing domain. Continuing.", e.getMessage());
            return Optional.empty();
        }
    }

    @FunctionalInterface
    private interface AddNeToDomainFunction {
        boolean tryAddNE(int domainId, int neId) throws RepositoryException;
    }

    @FunctionalInterface
    private interface RemoveNeFromDomainFunction {
        boolean tryRemoveNE(int domainId, int neId) throws RepositoryException;
    }

    private boolean isDiscoverAllNetworkEnabled() {
        return settingsRepository.getSettings().getDiscoveryPolicy() == DiscoveryPolicy.DISCOVER_ALL_NETWORK;
    }

}
