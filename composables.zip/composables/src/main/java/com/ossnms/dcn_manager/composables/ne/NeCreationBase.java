package com.ossnms.dcn_manager.composables.ne;

import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.DataCreationException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkState;
import static com.google.common.base.Strings.isNullOrEmpty;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.apache.commons.lang3.StringUtils.EMPTY;

public class NeCreationBase<C extends CallContext> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeCreationBase.class);

    private final C context;
    private final NeEntityRepository repository;
    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NetworkElementNotifications notifications;
    private final ChannelEntityRepository channelRepository;
    private final SystemRepository systemRepository;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;
    private final LoggerManager<C> loggerManager;

    public NeCreationBase(C context,
            @Nonnull NeEntityRepository repository,
            @Nonnull NePhysicalConnectionRepository neInstanceRepository,
            @Nonnull NetworkElementNotifications notifications,
            @Nonnull ChannelEntityRepository channelRepository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull ChannelPhysicalConnectionRepository channelInstanceRepository,
            @Nonnull LoggerManager<C> logger) {
        this.context = context;
        this.repository = repository;
        this.neInstanceRepository = neInstanceRepository;
        this.notifications = notifications;
        this.channelRepository = channelRepository;
        this.systemRepository = systemRepository;
        this.channelInstanceRepository = channelInstanceRepository;
        this.loggerManager = logger;
    }

    public NeEntity tryCreateNe(@Nonnull NeCreateDescriptor createDescriptor)
            throws UnknownChannelIdException, DuplicatedRouteException, RepositoryException, DataCreationException, DuplicatedObjectNameException {

        checkState(!isNullOrEmpty(createDescriptor.getPreferences().getName()), "Network Elements must have a name!");

        validateUniqueNameBetweenNEs(createDescriptor);

        validateUniqueNetworkNameBetweenNEs(createDescriptor);
        
        validateUniqueNameBetweenSystems(createDescriptor);

        validateParentChannelIdentifier(createDescriptor);

        validateRoutes(createDescriptor);

        validateDirectAddress(createDescriptor);

        final NeEntity neEntity = createNe(createDescriptor);

        notifications.notifyCreate(neEntity);

        logCreation(neEntity);

        return neEntity;
    }

    private void validateUniqueNameBetweenNEs(NeCreateDescriptor createDescriptor)
            throws DuplicatedObjectNameException, RepositoryException {

        final String newName = createDescriptor.getPreferences().getName();

        final boolean nameExists = repository.getNeUserPreferencesRepository()
                .query(newName)
                .isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(tr(Message.NE_DUPLICATED_NAME, newName));
        }
    }

    
    private void validateUniqueNetworkNameBetweenNEs(NeCreateDescriptor createDescriptor)
            throws DuplicatedObjectNameException, RepositoryException {

        final Optional<String> newNeighbourhoodId = createDescriptor.getOperation().getNeighbourhoodId();

        if(newNeighbourhoodId.isPresent()) {
            final boolean nameExists = repository.getNeOperationRepository()
                    .queryByNeighbourhoodId(newNeighbourhoodId.get())
                    .isPresent();

            if (nameExists) {
                throw new DuplicatedObjectNameException(tr(Message.DUPLICATED_NETWORK_ID_NAME, newNeighbourhoodId.get()));
            }
            
        }
    }

    private void validateUniqueNameBetweenSystems(NeCreateDescriptor createDescriptor)
            throws DuplicatedObjectNameException, RepositoryException {

        final String newName = createDescriptor.getPreferences().getName();

        final boolean nameExists = systemRepository.queryByName(newName).isPresent();

        if (nameExists) {
            throw new DuplicatedObjectNameException(tr(Message.DUPLICATED_SYSTEM_NAME, newName));
        }
    }

    private void validateParentChannelIdentifier(NeCreateDescriptor createDescriptor)
            throws RepositoryException, UnknownChannelIdException {

        final Optional<ChannelEntity> channel = channelRepository.queryChannel(createDescriptor.getChannelId());
        if (!channel.isPresent()) {
            throw new UnknownChannelIdException("Unknown channel creating NE {}", createDescriptor);
        }
    }

    private void validateDirectAddress(NeCreateDescriptor createDescriptor)
            throws DuplicatedRouteException, RepositoryException {

        final Optional<String> directRouteKey = createDescriptor.getPreferences().getDirectRouteAdapter().getKey();
        if (directRouteKey.isPresent()) {
            final Set<Pair<String, Integer>> existingKeys = repository.getNeGatewayRoutesRepository()
                    .tryFindRouteKeys(ImmutableSet.of(directRouteKey.get()));
            if (!existingKeys.isEmpty()) {
                final String duplicatedNeName = repository
                        .queryNeName(existingKeys.stream().findFirst().map(Pair::getRight).orElse(0)).orElse(EMPTY);

                throw new DuplicatedRouteException(tr(Message.DUPLICATED_DIRECT_ROUTE_INFO,
                        createDescriptor.getPreferences().getName(), duplicatedNeName));
            }
        }
    }

    private void validateRoutes(NeCreateDescriptor createDescriptor)
            throws DuplicatedRouteException, RepositoryException {

        final Collection<NeGatewayRouteBuilder> newGatewayRoutes = createDescriptor.getGatewayRoutes();
        final Set<String> newRouteKeys = newGatewayRoutes.stream().map(NeGatewayRouteBuilder.GET_ROUTE_KEY).collect(Collectors.toSet());
        final Set<Pair<String, Integer>> existingKeys = repository.getNeGatewayRoutesRepository()
                .tryFindRouteKeys(newRouteKeys);
        if (!existingKeys.isEmpty() || newRouteKeys.size() != newGatewayRoutes.size()) {
             /*
             * Either the new route keys have been found in existing NEs or there are
             * duplicated keys within the new routes (when the size of both collections
             * is not the same).
             */
            final Optional<String> duplicatedNeName = repository
                    .queryNeName(existingKeys.stream().findFirst().map(Pair::getRight).orElse(0));

            if (duplicatedNeName.isPresent()) {
                throw new DuplicatedRouteException(tr(Message.DUPLICATED_ROUTES_INFO,
                        createDescriptor.getPreferences().getName(), duplicatedNeName.get()));
            }

            throw new DuplicatedRouteException(tr(Message.DUPLICATED_ROUTES));
        }
    }

    private NeEntity createNe(final NeCreateDescriptor creation) throws DataCreationException {
        final NeEntity newNe;

        try {
            newNe = repository.create(creation);
        } catch (final RepositoryException e) {
            throw new DataCreationException("Could not create NE.", e);
        }

        channelInstanceRepository.queryAll(newNe.getInfo().getChannelId())
            .forEach(channelInstance -> neInstanceRepository.insert(
                    new NePhysicalConnectionInitialData().setActive(channelInstance.isActive()),
                    newNe.getInfo().getId(),
                    channelInstance.getId())
                );

        return newNe;
    }

    private void logCreation(NeEntity entity) {
        final int neId = entity.getInfo().getNeId();

        loggerManager.createCommandLog(context, new LoggerItemNe(
                entity.getPreferences().getName(), "NE object created", neId));

        LOGGER.info("Created NE '{}' with ID {} of type {}: {}",
                entity.getPreferences().getName(), neId, entity.getInfo().getProxyType(), entity);
    }
}
