package com.ossnms.dcn_manager.composables.outbound.dtos;

import static com.ossnms.dcn_manager.i18n.T.tr;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.i18n.Message;

/**
 * Immutable {@link LoggerItemContainer} implementation for Container activities.
 */
public final class LoggerItemContainer extends LoggerItemWithAffectedObject {

    /**
     * Creates a Immutable {@link LoggerItemContainer} instance for Containers with the default Severity {@link #DEFAULT_SEVERITY}.
     *
     * @param affectedObject
     * @param message
     */
    public LoggerItemContainer(@Nonnull final String affectedObject, @Nonnull final String message) {
        super(affectedObject, message);
    }

    /**
     * Creates a Immutable {@link LoggerItemContainer} instance for Containers.
     *
     * @param affectedObject
     * @param message
     * @param severity
     */
    public LoggerItemContainer(@Nonnull final String affectedObject, @Nonnull final String message, @Nonnull final MessageSeverity severity) {
        super(affectedObject, message, severity);
    }

    @Override
    protected String getAffectedObjectPrefix() {
        return tr(Message.CONTAINER);
    }

}
