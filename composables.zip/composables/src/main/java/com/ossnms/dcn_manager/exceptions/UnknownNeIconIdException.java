package com.ossnms.dcn_manager.exceptions;

/**
 * Exception thrown whenever the given name does not correspond to
 * an existing Icon Id.
 */
public class UnknownNeIconIdException extends DcnManagerException {

	private static final long serialVersionUID = -3335360723792801582L;

    /** @see DcnManagerException#DcnManagerException() */
	public UnknownNeIconIdException() { }

    /** @see DcnManagerException#DcnManagerException(String) */
	public UnknownNeIconIdException(String message)
	{
		super(message);
	}

    /** @see DcnManagerException#DcnManagerException(Throwable) */
	public UnknownNeIconIdException(Throwable cause)
	{
		super(cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable) */
	public UnknownNeIconIdException(String message, Throwable cause)
	{
		super(message, cause);
	}

    /** @see DcnManagerException#DcnManagerException(String, Throwable, boolean, boolean) */
	public UnknownNeIconIdException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

    /** @see DcnManagerException#DcnManagerException(String, Object[]) */
    public UnknownNeIconIdException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String, Throwable, Object[]) */
    public UnknownNeIconIdException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }
}
