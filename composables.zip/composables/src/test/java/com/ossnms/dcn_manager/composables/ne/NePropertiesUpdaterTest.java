package com.ossnms.dcn_manager.composables.ne;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableBiMap.Builder;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NePropertiesUpdater.OnDuplicateRoutes;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.domain.DomainCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.domain.DomainChildrenChanged;
import com.ossnms.dcn_manager.core.events.ne.NeConnectionDescriptionChangedEvent;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.properties.ne.NeProperty;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.UnitOfWorkImplBaseStub;
import com.ossnms.dcn_manager.core.test.UowMutationAnswer;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static com.google.common.base.Strings.isNullOrEmpty;
import static com.google.common.collect.Iterables.getOnlyElement;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class NePropertiesUpdaterTest {

    private static final int ID = 1, VERSION = 1;

    private CallContext context;
    private LoggerManager<CallContext> loggerManager;
    private NetworkElementNotifications entityNotifications;
    private Types<NeType> neTypes;
    private NeEntityRepository repo;
    private NeUserPreferencesRepository preferencesRepo;
    private NeOperationRepository neOperationRepository;
    private NeGatewayRoutesRepository routesRepo;
    private DomainRepository domainRepository;
    private DomainNotifications domainNotifications;
    private SettingsRepository settingsRepository;
    private SystemRepository systemRepository;
    private GlobalSettings globalSettings;

    private NeType type;

    private NeEntity entity;
    private NeInfoData state;
    private NeUserPreferencesData prefs;
    private NeOperationData operationData;

    private OnDuplicateRoutes duplicationHandler;

    private final Collection<NeGatewayRouteData> defaultRoute = Collections.singletonList(new NeGatewayRouteBuilder()
            .setKey("stuff1")
            .setCost(10)
            .setPriority(1)
            .setProperty("routeStuff", "stuff1")
            .build(ID, VERSION));

    @Before
    public void setUp() throws RepositoryException {

        context = mock(CallContext.class);
        loggerManager = mock(LoggerManager.class);
        entityNotifications = mock(NetworkElementNotifications.class);
        neTypes = mock(Types.class);
        repo = mock(NeEntityRepository.class);
        preferencesRepo = mock(NeUserPreferencesRepository.class);
        neOperationRepository = mock(NeOperationRepository.class);
        routesRepo = mock(NeGatewayRoutesRepository.class);
        domainRepository = mock(DomainRepository.class);
        domainNotifications = mock(DomainNotifications.class);
        settingsRepository = mock(SettingsRepository.class);
        globalSettings = GlobalSettings.build().setDiscoveryPolicy(DiscoveryPolicy.DISCOVERY_BY_DOMAIN).toGlobalSettings(ID,VERSION);
        systemRepository = mock(SystemRepository.class);

        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());

        duplicationHandler = mock(OnDuplicateRoutes.class);

        type = MockFactory.mockNeType();

        state = new NeInfoBuilder()
                .setProxyType("neType")
                .build(ID, 1, VERSION);
        prefs = new NeUserPreferencesBuilder()
                .setName("neName")
                .build(ID, VERSION);

        operationData = new NeOperationBuilder()
                .setNeighbourhoodId(Optional.of("TARGET NE ID TL1"))
                .build(ID, VERSION);

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                operationData,
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        when(type.getProtocol()).thenReturn("TL1");

        when(type.getIdentificationControlMap()).thenReturn(mockNeControlMap(WellKnownNePropertyNames.NEIGHBOURHOOD_ID, "TL1_NE_TARGET_ID"));
        when(type.getAdditionalTypeInfoControlMap()).thenReturn(mockNeControlMap(WellKnownNePropertyNames.ADDITIONAL_TYPE_INFO, "TL1_NE_TYPE"));


        when(neTypes.get("neType")).thenReturn(type);

        when(routesRepo.updateRoute(isA(UowContext.class), anyInt(), isA(NeGatewayRouteMutationDescriptor.class)))
                .then(invocation -> ((NeGatewayRouteMutationDescriptor) invocation.getArguments()[2]).apply());
        when(routesRepo.createRoute(isA(UowContext.class), anyInt(), isA(NeGatewayRouteMutationDescriptor.class)))
                .then(invocation -> ((NeGatewayRouteMutationDescriptor) invocation.getArguments()[2]).apply());

        when(repo.queryNe(anyInt())).thenReturn(Optional.empty());
        when(repo.getNeUserPreferencesRepository()).thenReturn(preferencesRepo);
        when(repo.getNeOperationRepository()).thenReturn(neOperationRepository);
        when(repo.getNeGatewayRoutesRepository()).thenReturn(routesRepo);
        when(repo.unitOfWork(any())).then(invocation -> new UnitOfWorkImplBaseStub<>(invocation.getArguments()[0]));

        when(domainRepository.queryTransitiveDomainsForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryNaturalDomainsForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.emptyList());

        when(neOperationRepository.queryByNeighbourhoodId(anyString())).thenReturn(Optional.empty());
        
        when(neOperationRepository.tryUpdate(isA(UowContext.class), isA(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());
        
        when(settingsRepository.getSettings()).thenReturn(globalSettings);

    }

    @Test
    public void testNameChange() throws DcnManagerException {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));
        when(preferencesRepo.query("New Name")).thenReturn(Optional.empty());
        runPropertyChange(true, new HashMap<>(ImmutableMap.of(NeProperty.ID_NAME.getName(), "New Name")), Collections.emptyList());

        verify(loggerManager).createCommandLog(context, new LoggerItemNe("New Name", "NE neName was renamed to New Name", ID));
        verify(loggerManager).createCommandLog(context, new LoggerItemNe("New Name", "NE properties changed", ID));

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(preferencesRepo).tryUpdate(isA(UowContext.class), mutationRepo.capture());

        assertThat(mutationRepo.getValue().getName().get(), is("New Name"));

    }

    @Test(expected = InvalidMutationException.class)
    public void testPropertyChangeInvalidMutationError() throws DcnManagerException {

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(NeProperty.ID_NAME.getName(), "")), Collections.emptyList()); // empty names are not allowed

    }

    @Test
    public void testGatewayRouteAdded_withDuplicateOnGatewayRoutes_doesNotAdd() throws DcnManagerException {
        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));
        when(repo.queryNeName(anyInt())).thenReturn(Optional.of("ne_name"));
        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of(new ImmutablePair<>("newStuff", ID + 1)));

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "2",
                "routeUse_000", "false",
                "routeStuff_000", "newStuff")
        ), defaultRoute);

        final ArgumentCaptor<NeGatewayRouteMutationDescriptor> updateCaptor = ArgumentCaptor.forClass(NeGatewayRouteMutationDescriptor.class);
        verify(routesRepo, never()).createRoute(isA(UowContext.class), eq(ID), isA(NeGatewayRouteMutationDescriptor.class));
        verify(routesRepo).updateRoute(isA(UowContext.class), eq(ID), updateCaptor.capture());

        verify(duplicationHandler).respondToDuplicatedRoutes(any(Iterable.class), anyString(), anyString());

        // on a simple add we'll have a no-op update over existing data.
        final NeGatewayRouteMutationDescriptor updateMutation = updateCaptor.getValue();
        final NeGatewayRouteData onlyRoute = getOnlyElement(defaultRoute);
        assertThat(updateMutation.getTarget(), is(onlyRoute));
        assertThat(updateMutation.apply(), is(onlyRoute));
    }

    @Test
    public void testGatewayRouteProperties_sameAsExisting_doesNothing() throws DcnManagerException {
        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of(new ImmutablePair<>("newStuff", ID + 1)));

        buildBase().applyUpdate(type, entity, defaultRoute,
            new HashMap<>(ImmutableMap.of(
                "routeCost_000", "10",
                "routePrio_000", "1",
                "routeUse_000", "false",
                "routeStuff_000", "stuff1")
        ));

        verify(routesRepo, never()).createRoute(isA(UowContext.class), eq(ID), any(NeGatewayRouteMutationDescriptor.class));
        verify(routesRepo, never()).updateRoute(isA(UowContext.class), eq(ID), any(NeGatewayRouteMutationDescriptor.class));

        verify(duplicationHandler, never()).respondToDuplicatedRoutes(any(Iterable.class), anyString(), anyString());

        verify(loggerManager, never()).createCommandLog(eq(context), isA(LoggerItemNe.class));

        verify(preferencesRepo, never()).tryUpdate(isA(UowContext.class), any(NeUserPreferencesMutationDescriptor.class));
        verify(entityNotifications, never()).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));
    }

    @Test(expected = DuplicatedRouteException.class)
    public void testGatewayRouteAdded_withDuplicateOnGatewayRoutes_propagatesCallbackException() throws DcnManagerException {
        configureFullGatewayRoutePropertySet();
        when(repo.queryNeName(anyInt())).thenReturn(Optional.of("ne_name"));
        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of(new ImmutablePair<>("newStuff", ID + 1)));

        doThrow(new DuplicatedRouteException()).when(duplicationHandler).respondToDuplicatedRoutes(any(Iterable.class), anyString(), anyString());

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "2",
                "routeUse_000", "false",
                "routeStuff_000", "newStuff")
        ), defaultRoute);
    }

    @Test
    public void testGatewayRouteAdded_withDuplicateOnDirectRoute_adds() throws DcnManagerException {
        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAttributes()).thenReturn(ImmutableMap.of("directAddress", attribute("directAddress")));
        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.directAddress}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "2",
                "routeUse_000", "false",
                "routeStuff_000", "newStuff",
                "directAddress", "stuff1")
        ), defaultRoute);

        verifyZeroInteractions(duplicationHandler);

        final ArgumentCaptor<NeGatewayRouteMutationDescriptor> createCaptor = ArgumentCaptor.forClass(NeGatewayRouteMutationDescriptor.class);
        final ArgumentCaptor<NeGatewayRouteMutationDescriptor> updateCaptor = ArgumentCaptor.forClass(NeGatewayRouteMutationDescriptor.class);
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> prefsCaptor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        verify(preferencesRepo).tryUpdate(isA(UowContext.class), prefsCaptor.capture());
        verify(routesRepo).createRoute(isA(UowContext.class), eq(ID), createCaptor.capture());
        verify(routesRepo).updateRoute(isA(UowContext.class), eq(ID), updateCaptor.capture());

        // on a simple add we'll have a no-op update over existing data.
        final NeGatewayRouteMutationDescriptor updateMutation = updateCaptor.getValue();
        final NeGatewayRouteData onlyRoute = getOnlyElement(defaultRoute);
        assertThat(updateMutation.getTarget(), is(onlyRoute));
        assertThat(updateMutation.apply(), is(onlyRoute));

        final NeGatewayRouteData route = createCaptor.getValue().getResult();
        assertThat(route.getPriority(), is(2));
        assertThat(route.getCost(), is(50));
        assertThat(route.isUsed(), is(false));
        assertThat(route.getAllOpaqueProperties().get("routeStuff"), is("newStuff"));

        assertThat(prefsCaptor.getValue().getDirectRouteAdapter().getKey(), hasValue("stuff1"));

    }

    @Test
    public void testGatewayRouteAdded() throws DcnManagerException {
        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "2",
                "routeUse_000", "false",
                "routeStuff_000", "newStuff")
        ), defaultRoute);

        final ArgumentCaptor<NeGatewayRouteMutationDescriptor> createCaptor = ArgumentCaptor.forClass(NeGatewayRouteMutationDescriptor.class);
        final ArgumentCaptor<NeGatewayRouteMutationDescriptor> updateCaptor = ArgumentCaptor.forClass(NeGatewayRouteMutationDescriptor.class);
        verify(routesRepo).createRoute(isA(UowContext.class), eq(ID), createCaptor.capture());
        verify(routesRepo).updateRoute(isA(UowContext.class), eq(ID), updateCaptor.capture());

        // on a simple add we'll have a no-op update over existing data.
        final NeGatewayRouteMutationDescriptor updateMutation = updateCaptor.getValue();
        final NeGatewayRouteData onlyRoute = getOnlyElement(defaultRoute);
        assertThat(updateMutation.getTarget(), is(onlyRoute));
        assertThat(updateMutation.apply(), is(onlyRoute));

        final NeGatewayRouteData route = createCaptor.getValue().getResult();
        assertThat(route.getPriority(), is(2));
        assertThat(route.getCost(), is(50));
        assertThat(route.isUsed(), is(false));
        assertThat(route.getAllOpaqueProperties().get("routeStuff"), is("newStuff"));
    }

    @Test
    public void testGatewayRouteUpdated() throws DcnManagerException {
        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "1",
                "routeUse_000", "false",
                "routeStuff_000", "stuff1")
        ), defaultRoute);

        final ArgumentCaptor<NeGatewayRouteMutationDescriptor> updateCaptor = ArgumentCaptor.forClass(NeGatewayRouteMutationDescriptor.class);
        verify(routesRepo, never()).createRoute(isA(UowContext.class), eq(ID), isA(NeGatewayRouteMutationDescriptor.class));
        verify(routesRepo).updateRoute(isA(UowContext.class), eq(ID), updateCaptor.capture());

        final NeGatewayRouteData route = updateCaptor.getValue().getResult();
        assertThat(route.getPriority(), is(1));
        assertThat(route.getCost(), is(50));
        assertThat(route.isUsed(), is(false));
        assertThat(route.getAllOpaqueProperties().get("routeStuff"), is("stuff1"));
    }

    @Test
    public void testTransientDomainNameAdded() throws DcnManagerException {
        final DomainInfoData domain1 = new DomainInfoData(100, 0, "domain1");

        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(domainRepository.tryCreate(eq(new DomainCreationDescriptor("domain1")))).thenReturn(Optional.of(domain1));
        when(domainRepository.tryAddTransitiveNE(anyInt(), anyInt())).thenReturn(true);

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "1",
                "routeUse_000", "false",
                "routeStuff_000", "stuff1",
                "routeDomain_000", "domain1")
        ), defaultRoute);

        verify(domainRepository).tryCreate(eq(new DomainCreationDescriptor("domain1")));
        verify(domainRepository).tryAddTransitiveNE(domain1.getId(), ID);
        verify(domainNotifications).notifyCreate(domain1);
        verify(domainNotifications).notifyChanges(isA(DomainChildrenChanged.class));
    }

    @Test
    public void testTransientDomainNameChanged() throws DcnManagerException {
        final DomainInfoData currentDomain = new DomainInfoData(99, 0, "currentDomain");
        final DomainInfoData domain1 = new DomainInfoData(100, 0, "domain1");

        final List<NeGatewayRouteData> originalRoute = Collections.singletonList(new NeGatewayRouteBuilder()
                .setKey("stuff1")
                .setCost(10)
                .setPriority(1)
                .setDomain(Optional.of("currentDomain"))
                .setProperty("routeStuff", "stuff1")
                .build(ID, VERSION));

        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryTransitiveDomainsForNE(ID)).thenReturn(Collections.singleton(currentDomain));
        when(domainRepository.queryByName("domain1")).thenReturn(Optional.empty()); // query before deciding to create
        when(domainRepository.queryByName("currentDomain")).thenReturn(Optional.of(currentDomain));
        when(domainRepository.tryCreate(eq(new DomainCreationDescriptor("domain1")))).thenReturn(Optional.of(domain1));
        when(domainRepository.tryAddTransitiveNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.tryRemoveTransitiveNE(anyInt(), anyInt())).thenReturn(true);

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "1",
                "routeUse_000", "false",
                "routeStuff_000", "stuff1",
                "routeDomain_000", "domain1")
        ), originalRoute);

        verify(domainRepository).tryCreate(eq(new DomainCreationDescriptor("domain1")));
        verify(domainRepository).tryAddTransitiveNE(domain1.getId(), ID);
        verify(domainRepository).tryRemoveTransitiveNE(currentDomain.getId(), ID);
        verify(domainNotifications).notifyCreate(domain1);
        verify(domainNotifications, times(2)).notifyChanges(isA(DomainChildrenChanged.class));
    }

    @Test
    public void testTransientDomainNameRemoved() throws DcnManagerException {
        final DomainInfoData currentDomain = new DomainInfoData(99, 0, "currentDomain");

        final List<NeGatewayRouteData> originalRoute = Collections.singletonList(new NeGatewayRouteBuilder()
                .setKey("stuff1")
                .setCost(10)
                .setPriority(1)
                .setDomain(Optional.of("currentDomain"))
                .setProperty("routeStuff", "stuff1")
                .build(ID, VERSION));

        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryTransitiveDomainsForNE(ID)).thenReturn(Collections.singleton(currentDomain));
        when(domainRepository.queryByName("currentDomain")).thenReturn(Optional.of(currentDomain));
        when(domainRepository.tryAddTransitiveNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.tryRemoveTransitiveNE(anyInt(), anyInt())).thenReturn(true);

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "1",
                "routeUse_000", "false",
                "routeStuff_000", "stuff1",
                "routeDomain_000", "")
        ), originalRoute);

        verify(domainRepository).tryRemoveTransitiveNE(currentDomain.getId(), ID);
        verify(domainNotifications).notifyChanges(isA(DomainChildrenChanged.class));
    }

    @Test
    public void testTransientDomainNameWasNotIncluded() throws DcnManagerException {
        final DomainInfoData currentDomain = new DomainInfoData(99, 0, "currentDomain");

        final List<NeGatewayRouteData> originalRoute = Collections.singletonList(new NeGatewayRouteBuilder()
                .setKey("stuff1")
                .setCost(10)
                .setPriority(1)
                .setDomain(Optional.of("currentDomain"))
                .setProperty("routeStuff", "stuff1")
                .build(ID, VERSION));

        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        when(domainRepository.queryChildrenNEs(currentDomain.getId())).thenReturn(Collections.singleton(ID));
        when(domainRepository.queryTransitiveDomainsForNE(ID)).thenReturn(Collections.singleton(currentDomain));
        when(domainRepository.queryByName("currentDomain")).thenReturn(Optional.of(currentDomain));

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(
                "routeCost_000", "50",
                "routePrio_000", "1",
                "routeUse_000", "false",
                "routeStuff_000", "stuff1")
        ), originalRoute);

        verify(domainRepository, never()).tryAddTransitiveNE(anyInt(), anyInt());
        verify(domainRepository, never()).tryRemoveTransitiveNE(anyInt(), anyInt());
        verify(domainNotifications, never()).notifyChanges(isA(DomainChildrenChanged.class));
    }

    @Test
    public void testDomainName_fixingDomainAssociations() throws DcnManagerException {
        configureFullGatewayRoutePropertySet();

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(routesRepo.tryFindRouteKeys(any(Set.class))).thenReturn(ImmutableSet.of());

        /*
         * Test scenario: NE had a domain participation which was not removed for some reason,
         * property update brings no routes, there are no routes in the repository.
         *
         * Result: NE domain participation must be removed.
         *
         * Note: this may happen when the entire route list is updated from the clients' NE property page.
         */

        when(domainRepository.queryTransitiveDomainsForNE(ID)).thenReturn(Collections.singleton(new DomainInfoData(200, VERSION, "domain1")));
        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(ImmutableList.of(100)); // sibling NE in the domain
        when(domainRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(domainRepository.tryRemoveTransitiveNE(200, ID)).thenReturn(true);

        runPropertyChange(false, new HashMap<>(ImmutableMap.of("blah", "blah")), Collections.emptyList());

        verify(domainRepository).tryRemoveTransitiveNE(200, ID);
        verify(domainNotifications).notifyChanges(isA(DomainChildrenChanged.class));
    }

    @Test
    public void testDirectRouteChange() throws DcnManagerException {

        final String port = "port";
        final String ip_address = "ip_address";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        runPropertyChange(false, new HashMap<>(ImmutableMap.of(port, "123", ip_address, "ip")), Collections.emptyList());

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(preferencesRepo).tryUpdate(isA(UowContext.class), mutationRepo.capture());

        final NeUserPreferencesData result = mutationRepo.getValue().getResult();
        assertThat(result.getDirectRoute().getOpaqueProperty(port).get(), is("123"));
        assertThat(result.getDirectRoute().getOpaqueProperty(ip_address).get(), is("ip"));
        assertThat(result.getDirectRoute().getKey(), is("ip:123"));
    }

    @Test
    public void testDirectRouteChange_sameProperties() throws DcnManagerException {

        final String port = "port";
        final String ip_address = "ip_address";

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        final NeUserPreferencesBuilder preferencesBuilder = new NeUserPreferencesBuilder().setName("name");
        preferencesBuilder.getDirectRouteAdapter()
                .setProperties(ImmutableMap.of(port, "123", ip_address, "ip"));

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                preferencesBuilder.build(ID, VERSION));

        final Map<String, String> routeProperties = new HashMap<>();
        routeProperties.put(port, "123");
        routeProperties.put(ip_address, "ip");

        buildBase().applyUpdate(type, entity, Collections.emptyList(), routeProperties);

        verify(preferencesRepo, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
    }

    public void runPropertyChange(boolean online) throws DcnManagerException {
        final Map<String, String> mutatedProperties = runPropertyChange(online, ImmutableMap.of("A", "vA", "B", "vB", "C", "CHANGE"), Collections.emptyList());

        assertThat(mutatedProperties.size(), is(1));
        assertThat(mutatedProperties, hasEntry("C", "CHANGE"));

        verify(loggerManager).createCommandLog(context, new LoggerItemNe("ne", "NE properties changed", ID));
    }

    public Map<String, String> runPropertyChange(boolean online, Map<String, String> properties, Iterable<NeGatewayRouteData> gatewayRoutes)
            throws DcnManagerException {

        when(preferencesRepo.tryUpdate(isA(UowContext.class), isA(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());

        buildBase().applyUpdate(type, entity, gatewayRoutes, properties);

        verify(loggerManager, atLeastOnce()).createCommandLog(eq(context), isA(LoggerItemNe.class));

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationNotif = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        verify(preferencesRepo).tryUpdate(isA(UowContext.class), mutationRepo.capture());
        verify(entityNotifications).notifyChanges(mutationNotif.capture());

        final NeUserPreferencesMutationDescriptor repoDescriptor = mutationRepo.getValue();
        final NeUserPreferencesMutationDescriptor notifDescriptor = mutationNotif.getValue();

        assertThat(repoDescriptor, is(notifDescriptor));

        return repoDescriptor.getProperties();
    }

    @Test
    public void testUnstructuredPropertyChange() throws DcnManagerException {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("A", "vA-2"));
        final NeUserPreferencesData prefs = new NeUserPreferencesBuilder()
                .setName("ne")
                .setProperty("A", "vA")
                .build(ID, VERSION);

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        final Map<String, String> changedProperties = runPropertyChange(true, properties, Collections.emptyList());

        assertThat(changedProperties, hasEntry("A", "vA-2"));
    }

    @Test
    public void testDefaultPropertyMissing() throws Exception {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of("B", "vB"));

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("A", "vA"));
        final NeUserPreferencesData prefs = new NeUserPreferencesBuilder()
                .setName("ne")
                .setProperty("A", "vA")
                .build(ID, VERSION);

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        final Map<String, String> changedProperties = runPropertyChange(true, properties, Collections.emptyList());

        assertThat(changedProperties, hasEntry("B", "vB"));
    }

    @Test
    public void testDefaultPropertyPresent_onNe() throws DcnManagerException {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of("B", "vB"));

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("A", "vA"));

        final NeUserPreferencesBuilder prefsBuilder = new NeUserPreferencesBuilder()
                .setName("ne")
                .setProperty("A", "vA")
                .setProperty("B", "vB");

        final NeUserPreferencesData prefs = prefsBuilder
                .build(ID, VERSION);

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        final NePropertiesUpdater<CallContext> cmd = buildBase();

        cmd.applyUpdate(type, entity, Collections.emptyList(), properties);

        verify(preferencesRepo, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, entityNotifications);
    }

    @Test
    public void testDefaultPropertyPresent_onDirectRoute() throws DcnManagerException {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of("B", "vB"));

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("A", "vA"));

        final NeUserPreferencesBuilder prefsBuilder = new NeUserPreferencesBuilder()
                .setName("ne")
                .setProperty("A", "vA");
        prefsBuilder.getDirectRouteAdapter().setProperty("B", "vB");

        final NeUserPreferencesData prefs = prefsBuilder
                .build(ID, VERSION);

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        final NePropertiesUpdater<CallContext> cmd = buildBase();

        cmd.applyUpdate(type, entity, Collections.emptyList(), properties);

        verify(preferencesRepo, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, entityNotifications);
    }

    @Test
    public void testSameProperties() throws DcnManagerException {

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("A", "vA", "B", "vB", "C", "vC"));

        final NeUserPreferencesBuilder prefsBuilder = new NeUserPreferencesBuilder()
                .setName("ne")
                .setProperty("A", "vA")
                .setProperty("B", "vB");
        prefsBuilder.getDirectRouteAdapter().setProperty("C", "vC");

        final NeUserPreferencesData prefs = prefsBuilder
                .build(ID, VERSION);

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        final NePropertiesUpdater<CallContext> cmd = buildBase();

        cmd.applyUpdate(type, entity, Collections.emptyList(), properties);

        verify(preferencesRepo, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, entityNotifications);
    }

    @Test
    public void testEmptyChangedProperties() throws DcnManagerException {

        final NePropertiesUpdater<CallContext> cmd = buildBase();

        cmd.applyUpdate(type, entity, Collections.emptyList(), Collections.emptyMap());

        verify(preferencesRepo, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, entityNotifications);
    }

    @Test
    public void testGlobalIdChange() throws DcnManagerException {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("TL1_NE_TARGET_ID", "TL1_ID_NAME_1"));

        runPropertyChange(false, properties, Collections.emptyList());

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(preferencesRepo).tryUpdate(isA(UowContext.class), mutationRepo.capture());

        final Optional<String> newGlobalId = mutationRepo.getValue().getGlobalId();
        assertThat(newGlobalId, is(present()));
        assertThat(newGlobalId.get(), is("bVRMMV9JRF9OQU1FXzEgICAgICAgICAE"));
    }

    @Test
    public void testGlobalIdNotChanged() throws DcnManagerException {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("TL1_NE_TARGET_ID", "TL1_ID_NAME_1"));

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                new NeUserPreferencesBuilder().setName("name").setGlobalId(Optional.of("bVRMMV9JRF9OQU1FXzEgICAgICAgICAE")).build(ID, VERSION));

        runPropertyChange(false, properties, Collections.emptyList());

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(preferencesRepo).tryUpdate(isA(UowContext.class), mutationRepo.capture());

        final Optional<String> newGlobalId = mutationRepo.getValue().getGlobalId();
        assertThat(newGlobalId, is(absent()));
    }

    @Test
    public void testConnectionDescriptionSentUponChange() throws DcnManagerException {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("some", "value"));

        when(repo.queryNe(ID)).thenReturn(Optional.of(entity));

        runPropertyChange(false, properties, Collections.emptyList());

        verify(entityNotifications).notifyChanges(isA(NeConnectionDescriptionChangedEvent.class));
    }

    @Test
    public void testNeighbourhoodIdChange() throws DcnManagerException {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));
        when(neOperationRepository.queryByNeighbourhoodId("NEWTID")).thenReturn(Optional.empty());

        runPropertyChange(true, new HashMap<>(ImmutableMap.of(NeProperty.NEIGHBOURHOOD_ID.getName(), "NEWTID")), Collections.emptyList());

        final ArgumentCaptor<NeOperationMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);
        verify(neOperationRepository).tryUpdate(isA(UowContext.class), mutationRepo.capture());
        
        final Optional<String> newNeighbourhoodId = mutationRepo.getValue().getNeighbourhoodId();
        assertThat(newNeighbourhoodId.get(), is("NEWTID"));

    }

    
    @Test(expected = DuplicatedObjectNameException.class)
    public void testDuplicatedNeighbourhoodIdViaTL1Id() throws DcnManagerException {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));


        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("TL1_NE_TARGET_ID", "DUPLICATED-TL1-ID"));
        Optional<NeOperationData> neOperationData = Optional.of(new NeOperationBuilder().setNeighbourhoodId(Optional.of("DUPLICATED-TL1-ID")).build(ID, VERSION));

        Optional<NeOperationData> neOperationDataOther = Optional.of(new NeOperationBuilder().setNeighbourhoodId(Optional.of("DUPLICATED-TL1-ID")).build(2, VERSION));

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                neOperationData.get(),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                new NeUserPreferencesBuilder().setName("name").build(ID, VERSION));

        when(neOperationRepository.queryByNeighbourhoodId("DUPLICATED-TL1-ID")).thenReturn(neOperationDataOther);

        runPropertyChange(false, properties, Collections.emptyList());

        final ArgumentCaptor<NeOperationMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);
        verify(neOperationRepository).tryUpdate(isA(UowContext.class), mutationRepo.capture());

        final Optional<String> newNeighbourhoodId = mutationRepo.getValue().getNeighbourhoodId();
        assertThat(newNeighbourhoodId, is(absent()));
    }


    @Test(expected = DuplicatedObjectNameException.class)
    public void testDuplicatedNeighbourhoodIdViaNetworkName() throws DcnManagerException {

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.of("${Route.ip_address}:${Route.port}"));

        when(type.getProtocol()).thenReturn("SNMP");

        when(type.getIdentificationControlMap()).thenReturn(mockNeControlMap(WellKnownNePropertyNames.NEIGHBOURHOOD_ID, "SYSNAME"));
        when(type.getAdditionalTypeInfoControlMap()).thenReturn( mockNeControlMap("", ""));

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("SYSNAME", "NETWORK NAME"));
        Optional<NeOperationData> neOperationData = Optional.of(new NeOperationBuilder().setNeighbourhoodId(Optional.of("NETWORK NAME")).build(ID, VERSION));

        Optional<NeOperationData> neOperationDataOther = Optional.of(new NeOperationBuilder().setNeighbourhoodId(Optional.of("NETWORK NAME")).build(2, VERSION));

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                neOperationData.get(),
                state,
                new NeSynchronizationBuilder().build(ID, VERSION),
                new NeUserPreferencesBuilder().setName("name").build(ID, VERSION));

        
        when(neOperationRepository.queryByRealName("NETWORK NAME")).thenReturn(neOperationDataOther);
        when(neOperationRepository.queryByNeighbourhoodId("NETWORK NAME")).thenReturn(neOperationDataOther);

        runPropertyChange(false, properties, Collections.emptyList());

        final ArgumentCaptor<NeOperationMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);
        verify(neOperationRepository).tryUpdate(isA(UowContext.class), mutationRepo.capture());

        final Optional<String> newNeighbourhoodId = mutationRepo.getValue().getNeighbourhoodId();
        assertThat(newNeighbourhoodId, is(absent()));
    }


    private NePropertiesUpdater<CallContext> buildBase() {
        return new NePropertiesUpdater<>(context, repo, systemRepository, loggerManager, entityNotifications,
                new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository), duplicationHandler);
    }

    private Attribute attribute(String name, RouteMapping mapping) {
        final Attribute attr = attribute(name);
        attr.setMapsTo(mapping);
        return attr;
    }

    private Attribute attribute(String name) {
        final Attribute attr = new Attribute();
        attr.setName(name);
        return attr;
    }

    private void configureFullGatewayRoutePropertySet() {
        when(type.getGatewayRouteAttributes())
                .thenReturn(ImmutableMap.of(
                        "routeCost", attribute("routeCost", RouteMapping.COST),
                        "routePrio", attribute("routePrio", RouteMapping.PRIORITY),
                        "routeUse", attribute("routeUse", RouteMapping.USAGE),
                        "routeDomain", attribute("routeDomain", RouteMapping.DOMAIN_NAME),
                        "routeStuff", attribute("routeStuff"))
                );
        when(type.getGatewayRouteAddressKeySource())
                .thenReturn(Optional.of("${route.routeStuff}"));
    }

   
    private BiMap<String, String> mockNeControlMap(String wellKnownPropertyName, String sourceProp) {
        final Builder<String, String> builder = ImmutableBiMap.builder();
        if (!isNullOrEmpty(wellKnownPropertyName) && !isNullOrEmpty(sourceProp)) {
            builder.put(wellKnownPropertyName, sourceProp);
        }
        return builder.build();
    }

}