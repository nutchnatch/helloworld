package com.ossnms.dcn_manager.composables.outbound.dtos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

public class LoggerItemNeTest {

    private static final String OBJECT2 = "object2";
    private static final String MESSAGE2 = "message2";
    private static final String MESSAGE = "message";
    private static final String OBJECT1 = "object1";

    @Test
    public void testCreate() {
        final LoggerItemNe itemNe = new LoggerItemNe(OBJECT1, MESSAGE, 1, MessageSeverity.INFO);

        assertNotNull(itemNe);
        assertThat(itemNe.getAffectedObject(), is("NE: object1"));
        assertThat(itemNe.getMessage(), is(MESSAGE));
        assertThat(itemNe.getAffectedObjectId(), is(1));
        assertThat(itemNe.getSeverity(), is(MessageSeverity.INFO));
    }

    @Test
    public void testCreateWithDefaultSeverity() {
        final LoggerItemNe itemNe = new LoggerItemNe(OBJECT1, MESSAGE, 1);

        assertNotNull(itemNe);
        assertThat(itemNe.getAffectedObject(), is("NE: object1"));
        assertThat(itemNe.getMessage(), is(MESSAGE));
        assertThat(itemNe.getAffectedObjectId(), is(1));
        assertThat(itemNe.getSeverity(), is(LoggerItem.DEFAULT_SEVERITY));
    }

    @Test
    public void testHashCodeEquals() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        final LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT1, MESSAGE, 1);

        assertThat(itemNe1.hashCode(), is(itemNe2.hashCode()));
    }

    @Test
    public void testHashCodeDifferentAffectedObjectId() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        final LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT1, MESSAGE, 2);

        assertThat(itemNe1.hashCode(), not(is(itemNe2.hashCode())));
    }

    @Test
    public void testHashCodeDiferentMessage() {
        LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT1, MESSAGE2, 1);

        assertThat(itemNe1.hashCode(), not(equalTo(itemNe2.hashCode())));

        itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        itemNe2 = new LoggerItemNe(OBJECT2, MESSAGE, 1);

        assertThat(itemNe1.hashCode(), not(equalTo(itemNe2.hashCode())));
    }

    @Test
    public void testHashCodeDiferentAffectedObject() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        final LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT2, MESSAGE, 1);

        assertThat(itemNe1.hashCode(), not(equalTo(itemNe2.hashCode())));
    }

    @Test
    public void testEquals() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        final LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT1, MESSAGE, 1);

        assertEquals(itemNe1, itemNe2);
    }

    @Test
    public void testNotEqualsAffectedId() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        final LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT1, MESSAGE, 2);

        assertThat(itemNe1, not(equalTo(itemNe2)));
    }

    @Test
    public void testNotEqualsAffected() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        final LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT2, MESSAGE, 2);

        assertThat(itemNe1, not(equalTo(itemNe2)));
    }

    @Test
    public void testNotEqualsMessage() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        final LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT1, MESSAGE2, 2);

        assertThat(itemNe1, not(equalTo(itemNe2)));
    }

    @Test
    public void testNotEqualsNull() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);

        assertThat(itemNe1, not(equalTo(null)));
    }

    @Test
    public void testNotEqualsOtherObjectType() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);

        assertThat(itemNe1, not(equalTo(new Object())));
    }

    @Test
    public void testCompareEquals() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);
        final LoggerItemNe itemNe2 = new LoggerItemNe(OBJECT2, MESSAGE, 2);

        assertTrue(itemNe1.compareTo(itemNe2) == -1);
        assertTrue(itemNe1.compareTo(itemNe1) == 0);
        assertTrue(itemNe2.compareTo(itemNe1) == 1);
    }

    @Test
    public void testToString() {
        final LoggerItemNe itemNe1 = new LoggerItemNe(OBJECT1, MESSAGE, 1);

        assertThat(itemNe1.toString(), CoreMatchers.containsString(OBJECT1));
        assertThat(itemNe1.toString(), CoreMatchers.containsString(MESSAGE));
        assertThat(itemNe1.toString(), CoreMatchers.containsString("1"));
    }
}
