package com.ossnms.dcn_manager.composables.ne;

import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeStartingUpEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class NetworkElementActivationTest {

    private NetworkElementNotifications eventDispatcher;
    private NeInfoRepository neInfoRepository;
    private NetworkElementInteractionManager activationManager;
    private NePhysicalConnectionRepository neInstanceRepository;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;

    private NetworkElementActivation activation;

    @Before
    public void setUp() throws Exception {
        eventDispatcher = mock(NetworkElementNotifications.class);
        final NeEntityRepository neRepository = mock(NeEntityRepository.class);
        neInfoRepository = mock(NeInfoRepository.class);
        activationManager = mock(NetworkElementInteractionManager.class);
        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);

        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);

        activation = new NetworkElementActivation(eventDispatcher, neRepository, activationManager,
                neInstanceRepository, channelInstanceRepository);
    }

    @Test
    public void testChangeRequiredStateToActive() throws Exception {

        when(neInfoRepository.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        final boolean result = activation.changeRequiredStateToActive(
                new NeInfoBuilder()
                    .setRequiredActivationState(RequiredActivationState.INACTIVE)
                    .setProxyType("type")
                    .build(1, 10, 0)
            );

        assertThat(result, is(true));
    }

    @Test
    public void testChangeRequiredStateToActive_fromActive_returnsFalse() throws Exception {

        when(neInfoRepository.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        final boolean result = activation.changeRequiredStateToActive(
                new NeInfoBuilder()
                        .setRequiredActivationState(RequiredActivationState.ACTIVE)
                        .setProxyType("type")
                        .build(1, 10, 0)
        );

        assertThat(result, is(false));
    }

    @Test
    public void testChangeRequiredStateToActive_updateFails_returnsFalse() throws Exception {

        when(neInfoRepository.tryUpdate(isA(NeInfoMutationDescriptor.class))).thenReturn(Optional.empty());

        final boolean result = activation.changeRequiredStateToActive(
                new NeInfoBuilder()
                        .setRequiredActivationState(RequiredActivationState.INACTIVE)
                        .setProxyType("type")
                        .build(1, 10, 0)
        );

        assertThat(result, is(false));
    }

    @Test
    public void testChangeActualStateToStartUp_noActiveNeInstances_returnsFalse() throws Exception {

        when(neInstanceRepository.queryAll(anyInt())).thenReturn(Collections.emptySet());

        final boolean result = activation.changeActualStateToStartUp(1);

        assertThat(result, is(false));
        verifyZeroInteractions(activationManager, eventDispatcher);
    }

    @Test
    public void testChangeActualStateToStartUp_withActiveNeInstances_returnsTrue() throws Exception {

        when(neInstanceRepository.queryAll(anyInt())).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder()
                        .setActive(true)
                        .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                        .build(1, 1, 10, 0)
        ));

        when(channelInstanceRepository.query(10)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(ActualActivationState.ACTIVE)
                        .build(10, 1, 1, 0)
        ));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        final boolean result = activation.changeActualStateToStartUp(1);

        assertThat(result, is(true));

        verify(activationManager).scheduleActivation(isA(Activate.class));
        verify(eventDispatcher).notifyChanges(isA(NeStartingUpEvent.class));
    }

    @Test
    public void testChangeActualStateToStartUp_unknownChannelInstance_returnsFalse() throws Exception {

        when(channelInstanceRepository.query(anyInt())).thenReturn(Optional.empty());

        final boolean result = activation.changeActualStateToStartUp(
                new NePhysicalConnectionBuilder().build(1, 1, 1, 0));

        assertThat(result, is(false));
        verifyZeroInteractions(activationManager, eventDispatcher);
    }

    @Test
    public void testChangeActualStateToStartUp_notActiveChannelInstance_returnsTrue() throws Exception {

        when(channelInstanceRepository.query(10)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                    .setActivation(ActualActivationState.INACTIVE)
                    .build(10, 1, 1, 0)
        ));

        final boolean result = activation.changeActualStateToStartUp(
                new NePhysicalConnectionBuilder().build(1, 1, 10, 0));

        assertThat(result, is(true));
        verifyZeroInteractions(activationManager, eventDispatcher);
    }

    @Test
    public void testChangeActualStateToStartUp_returnsTrue() throws Exception {

        when(channelInstanceRepository.query(10)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(ActualActivationState.ACTIVE)
                        .build(10, 1, 1, 0)
        ));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        final boolean result = activation.changeActualStateToStartUp(
                new NePhysicalConnectionBuilder()
                        .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                        .build(1, 1, 10, 0));

        assertThat(result, is(true));

        verify(activationManager).scheduleActivation(isA(Activate.class));
        verify(eventDispatcher).notifyChanges(isA(NeStartingUpEvent.class));
    }

    @Test
    public void testChangeActualStateToStartUp_onAlreadyActivatingInstance_returnsTrue() throws Exception {

        when(channelInstanceRepository.query(10)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(ActualActivationState.ACTIVE)
                        .build(10, 1, 1, 0)
        ));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        final boolean result = activation.changeActualStateToStartUp(
                new NePhysicalConnectionBuilder()
                        .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.CONNECTING)
                        .build(1, 1, 10, 0));

        assertThat(result, is(true));
        verifyZeroInteractions(activationManager, eventDispatcher);
    }

    @Test
    public void testChangeActualStateToStartUp_updateFails_returnsFalse() throws Exception {

        when(channelInstanceRepository.query(10)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(ActualActivationState.ACTIVE)
                        .build(10, 1, 1, 0)
        ));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
                .thenReturn(Optional.empty());

        final boolean result = activation.changeActualStateToStartUp(
                new NePhysicalConnectionBuilder()
                        .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                        .build(1, 1, 10, 0));

        assertThat(result, is(false));
        verifyZeroInteractions(activationManager, eventDispatcher);
    }
}