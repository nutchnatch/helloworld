package com.ossnms.dcn_manager.composables.configuration;

import static org.junit.Assert.assertThat;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import com.ossnms.dcn_manager.composables.configuration.HardwareConfigurationType;

public class ConfigurationTypeTest {
    
    @Test
    public void testFrom_dev() {
        assertThat(HardwareConfigurationType.from("dev"), CoreMatchers.is(HardwareConfigurationType.DEV));
    }
    
    @Test
    public void testFrom_small() {
        assertThat(HardwareConfigurationType.from("small"), CoreMatchers.is(HardwareConfigurationType.SMALL));
    }
    
    @Test
    public void testFrom_null() {
        assertThat(HardwareConfigurationType.from(null), CoreMatchers.is(HardwareConfigurationType.SMALL));
    }
    
    @Test
    public void testFrom_notExists() {
        assertThat(HardwareConfigurationType.from("none"), CoreMatchers.is(HardwareConfigurationType.SMALL));
    }
}
