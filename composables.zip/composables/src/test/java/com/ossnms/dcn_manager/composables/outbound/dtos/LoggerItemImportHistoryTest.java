package com.ossnms.dcn_manager.composables.outbound.dtos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemImportHistory;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;

public class LoggerItemImportHistoryTest {

    private static final String MESSAGE2 = "message2";
    private static final String OBJECT2 = "object2";
    private static final String MESSAGE = "message";
    private static final String OBJECT1 = "object1";

    @Test
    public void testCreate() {
        final LoggerItemImportHistory item = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);

        assertNotNull(item);
        assertThat(item.getAffectedObject(), is(OBJECT1));
        assertThat(item.getMessage(), is(MESSAGE));
        assertThat(item.getExecutionId(), is(1));
        assertThat(item.getSeverity(), is(MessageSeverity.INFO));
    }

    @Test
    public void testHashCodeEquals() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);
        final LoggerItemImportHistory item2 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);

        assertThat(item1.hashCode(), is(item2.hashCode()));
    }

    @Test
    public void testHashCodeDiferentMessage() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);
        final LoggerItemImportHistory item2 = new LoggerItemImportHistory(OBJECT1, MESSAGE2, MessageSeverity.INFO, 1);

        assertThat(item1.hashCode(), not(equalTo(item2.hashCode())));
    }
    
    @Test
    public void testHashCodeDiferentAffectedObjects() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);
        final LoggerItemImportHistory item2 = new LoggerItemImportHistory(OBJECT2, MESSAGE, MessageSeverity.INFO, 1);

        assertThat(item1.hashCode(), not(equalTo(item2.hashCode())));
    }

    @Test
    public void testHashCodeDiferentAffectedObject() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);
        final LoggerItemImportHistory item2 = new LoggerItemImportHistory(OBJECT2, MESSAGE, MessageSeverity.INFO, 1);

        assertThat(item1.hashCode(), not(equalTo(item2.hashCode())));
    }
    
    @Test
    public void testEquals() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);
        final LoggerItemImportHistory item2 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.WARNING, 1);

        assertEquals(item1, item2);
    }
    
    @Test
    public void testNotEqualsAffected() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);
        final LoggerItemImportHistory item2 = new LoggerItemImportHistory(OBJECT2, MESSAGE, MessageSeverity.INFO, 2);

        assertThat(item1, not(equalTo(item2)));
    }
    
    @Test
    public void testNotEqualsNull() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);

        assertThat(item1, not(equalTo(null)));
    }
    
    @Test
    public void testNotEqualsOtherObjectType() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);

        assertThat(item1, not(equalTo(new Object())));
    }
    
    @Test
    public void testNotEqualsMessage() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);
        final LoggerItemImportHistory item2 = new LoggerItemImportHistory(OBJECT1, MESSAGE2, MessageSeverity.INFO, 2);

        assertThat(item1, not(equalTo(item2)));
    }
    
    @Test
    public void testCompareEquals() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);
        final LoggerItemImportHistory item2 = new LoggerItemImportHistory(OBJECT2, MESSAGE, MessageSeverity.INFO, 2);
       
        assertTrue(item1.compareTo(item2) == -1);
        assertTrue(item1.compareTo(item1) == 0);
        assertTrue(item2.compareTo(item1) == 1);
    }
    
    @Test
    public void testToString() {
        final LoggerItemImportHistory item1 = new LoggerItemImportHistory(OBJECT1, MESSAGE, MessageSeverity.INFO, 1);        

        assertThat(item1.toString(), CoreMatchers.containsString(OBJECT1));
        assertThat(item1.toString(), CoreMatchers.containsString(MESSAGE));
        assertThat(item1.toString(), CoreMatchers.containsString("1"));
    }
}
