package com.ossnms.dcn_manager.composables.ne;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.Comparator;

import org.junit.Test;

import com.ossnms.dcn_manager.composables.ne.NeGatewayRouteMerging.RoutePair;
import com.ossnms.dcn_manager.composables.ne.NeGatewayRouteMerging.SortMode;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;

public class NeGatewayRouteLiloSortTest {

    private static final int NE_ID = 12;
    private static final int VERSION = 5;

    private final Comparator<RoutePair> comparator = SortMode.LILO_ORDER.getComparator();

    @Test
    public void testIndividualOrdering() {

        final NeGatewayRouteData routeData1 = new NeGatewayRouteBuilder().setKey("a").setPriority(1).build(NE_ID, VERSION);
        final NeGatewayRouteData routeData2 = new NeGatewayRouteBuilder().setKey("a").setPriority(2).build(NE_ID, VERSION);

        int order;

        order = comparator.compare(
            new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1)),
            new RoutePair(new NeGatewayRouteMutationDescriptor(routeData1))
        );

        assertThat(order, is(-1));

        order = comparator.compare(
            new RoutePair(new NeGatewayRouteMutationDescriptor(routeData1)),
            new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1))
        );

        assertThat(order, is(1));

        order = comparator.compare(
            new RoutePair(new NeGatewayRouteMutationDescriptor(routeData1).setPriority(1)),
            new RoutePair(new NeGatewayRouteMutationDescriptor(routeData1).setPriority(2))
        );

        assertThat(order, is(-1));

        order = comparator.compare(
            new RoutePair(new NeGatewayRouteMutationDescriptor(routeData1).setPriority(2)),
            new RoutePair(new NeGatewayRouteMutationDescriptor(routeData1).setPriority(1))
        );

        assertThat(order, is(1));

        order = comparator.compare(
            new RoutePair(new NeGatewayRouteMutationDescriptor(routeData1).setPriority(1)),
            new RoutePair(new NeGatewayRouteMutationDescriptor(routeData1).setPriority(1))
        );

        assertThat(order, is(0));

        order = comparator.compare(
            new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1)),
            new RoutePair(routeData2, new NeGatewayRouteMutationDescriptor(routeData2))
        );

        assertThat(order, is(-1));

        order = comparator.compare(
            new RoutePair(routeData2, new NeGatewayRouteMutationDescriptor(routeData2)),
            new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1))
        );

        assertThat(order, is(1));

        order = comparator.compare(
            new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1)),
            new RoutePair(routeData1, new NeGatewayRouteMutationDescriptor(routeData1))
        );

        assertThat(order, is(0));

    }

}
