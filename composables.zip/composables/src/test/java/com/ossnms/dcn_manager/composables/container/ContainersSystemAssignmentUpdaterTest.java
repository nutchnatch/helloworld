package com.ossnms.dcn_manager.composables.container;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContainersSystemAssignmentUpdaterTest {

    private static final int CONTAINER_ID_1 = 1;
    private static final int CONTAINER_ID_2 = 2;
    private static final int CONTAINER_ID_3 = 3;
    private static final int CONTAINER_ID_4 = 4;
    private static final int CONTAINER_ID_5 = 5;
    private static final int SYSTEM_ID = 1;
    private static final int VERSION = 100;

    @Mock private SettingsRepository settingsRepository;
    @Mock private ContainerRepository containerRepository;
    @Mock private SystemRepository systemRepository;
    @Mock private ContainerNotifications containerNotifications;
    @Mock private LoggerManager<CallContext> loggerManager;
    @Mock private CallContext context;

    private ContainersSystemAssignmentUpdater updater;
    private SystemInfo systemInfo;

    @Before public void setUp() throws Exception {
        updater = new ContainersSystemAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications,
                loggerManager, context);
        systemInfo = new SystemInfo(SYSTEM_ID, VERSION, "systemName");

        when(containerRepository.queryByName(anyString())).thenReturn(Optional.of(new ContainerInfo(1,1,"c")));
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(1,1));
    }

    @Test public void storeForSystemAssignment() throws Exception {
        final SystemAssignmentData current1 = new SystemAssignmentData(new ContainerInfo(CONTAINER_ID_1, VERSION, "c1"),
                SYSTEM_ID, AssignmentType.PRIMARY);
        final SystemAssignmentData current2 = new SystemAssignmentData(new ContainerInfo(CONTAINER_ID_2, VERSION, "c2"),
                SYSTEM_ID, AssignmentType.LOGICAL);
        final SystemAssignmentData current3 = new SystemAssignmentData(new ContainerInfo(CONTAINER_ID_3, VERSION, "c3"),
                SYSTEM_ID, AssignmentType.LOGICAL);

        final SystemAssignmentData changed1 = new SystemAssignmentData(new ContainerInfo(CONTAINER_ID_1, VERSION, "c1"),
                SYSTEM_ID, AssignmentType.LOGICAL);
        final SystemAssignmentData changed4 = new SystemAssignmentData(new ContainerInfo(CONTAINER_ID_4, VERSION, "c4"),
                SYSTEM_ID, AssignmentType.PRIMARY);
        final SystemAssignmentData changed5 = new SystemAssignmentData(new ContainerInfo(CONTAINER_ID_5, VERSION, "c5"),
                SYSTEM_ID, AssignmentType.LOGICAL);

        Iterable<SystemAssignmentData> currentAssignments = ImmutableList.of(current1, current2, current3);
        Set<SystemAssignmentData> changedAssignments = ImmutableSet.of(changed1, changed4, changed5);

        when(containerRepository.queryAllBySystem(SYSTEM_ID)).thenReturn(currentAssignments);
        when(containerRepository.tryRemoveSystemAssignment(current2)).thenReturn(true);
        when(containerRepository.tryRemoveSystemAssignment(current3)).thenReturn(false);
        when(containerRepository.tryUpdateSystemAssignment(current1)).thenReturn(true);

        updater.store(changedAssignments, systemInfo);

        verify(containerNotifications, atLeastOnce()).notifyChanges(
                new ContainerSystemAssignmentAddedEvent(CONTAINER_ID_4, SYSTEM_ID, AssignmentType.PRIMARY));
        verify(containerNotifications, atLeastOnce()).notifyChanges(
                new ContainerSystemAssignmentAddedEvent(CONTAINER_ID_5, SYSTEM_ID, AssignmentType.LOGICAL));

        verify(containerNotifications, atLeastOnce())
                .notifyChanges(new ContainerSystemAssignmentRemovedEvent(CONTAINER_ID_2, SYSTEM_ID));
        verify(containerNotifications, never())
                .notifyChanges(new ContainerSystemAssignmentRemovedEvent(CONTAINER_ID_3, SYSTEM_ID));

        verify(containerNotifications, atLeastOnce()).notifyChanges(
                new ContainerSystemAssignmentUpdatedEvent(CONTAINER_ID_1, SYSTEM_ID, AssignmentType.LOGICAL));

        verify(loggerManager, atLeastOnce()).createCommandLog(any(CallContext.class), any(LoggerItemContainer.class));

        verify(containerRepository, atLeastOnce()).tryUpdateSystemAssignment(changed1);

        verify(containerRepository, atLeastOnce()).addSystemAssignment(changed4);
        verify(containerRepository, atLeastOnce()).addSystemAssignment(changed5);

        verify(containerRepository, atLeastOnce()).tryRemoveSystemAssignment(current2);
        verify(containerRepository, atLeastOnce()).tryRemoveSystemAssignment(current3);

        verify(containerRepository, never()).tryUpdateSystemAssignment(current2);
        verify(containerRepository, never()).tryUpdateSystemAssignment(current3);
        verify(containerRepository, never()).tryUpdateSystemAssignment(changed4);
        verify(containerRepository, never()).tryUpdateSystemAssignment(changed4);

        verify(containerRepository, never()).addSystemAssignment(current1);
        verify(containerRepository, never()).addSystemAssignment(current2);
        verify(containerRepository, never()).addSystemAssignment(current3);

        verify(containerRepository, never()).tryRemoveSystemAssignment(current1);
        verify(containerRepository, never()).tryRemoveSystemAssignment(changed4);
        verify(containerRepository, never()).tryRemoveSystemAssignment(changed5);
    }

    @Test public void storeForSystemAssignmentNewSingleObject() throws Exception {
        final SystemAssignmentData changed1 = new SystemAssignmentData(new ContainerInfo(CONTAINER_ID_1, VERSION, "c1"),
                SYSTEM_ID, AssignmentType.PRIMARY);

        Iterable<SystemAssignmentData> currentAssignments = Collections.emptyList();
        Set<SystemAssignmentData> changedAssignments = ImmutableSet.of(changed1);

        when(containerRepository.queryAllBySystem(SYSTEM_ID)).thenReturn(currentAssignments);

        updater.store(changedAssignments, systemInfo);

        verify(containerRepository, atLeastOnce()).addSystemAssignment(changed1);
        verify(containerRepository, never()).tryUpdateSystemAssignment(changed1);
        verify(containerRepository, never()).tryRemoveSystemAssignment(changed1);
    }
}