package com.ossnms.dcn_manager.composables.metrics;

import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import com.ossnms.dcn_manager.core.utils.Consumer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.function.Function;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.composables.metrics.JobMetricsOutputFormatter.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;


@RunWith(MockitoJUnitRunner.class)
public class JobMetricsOutputFormatterTest {


    @Test
    public void dumpTo() throws Exception {
        final PolicyJob<?> job1 = mock(PolicyJob.class);
        final PolicyJob<?> job2 = mock(PolicyJob.class);
        final PolicyJob<?> job3 = mock(PolicyJob.class);

        final Stream<PolicyJob<?>> jobs = Stream.of(job1, job2, job3);

        final Consumer<String> consumer = mock(Consumer.class);
        new JobMetricsOutputFormatter(jobs, "jobIdentifier", "jobState", "partitionID")
                .dumpTo(consumer);

        //1-time for the first line log; 3 times one for each job; 1-time for the last line
        Mockito.verify(consumer, times(5)).accept(anyString());
    }

    @Test
    public void getAsString() throws Exception {

        final PolicyJob<?> job1 = mock(PolicyJob.class);
        final PolicyJob<?> job2 = mock(PolicyJob.class);
        final PolicyJob<?> job3 = mock(PolicyJob.class);

        Mockito.when(job1.toString()).thenReturn("Job1");
        Mockito.when(job2.toString()).thenReturn("Job2");
        Mockito.when(job3.toString()).thenReturn("Job3");

        final Stream<PolicyJob<?>> jobs = Stream.of(job1, job2, job3);

        final String jobIdentifier = "System";
        final String jobState = "Ongoing";
        final String partitionID = "1";

        final JobMetricsOutputFormatter jobMetricsOutputFormatter = new JobMetricsOutputFormatter(jobs, jobIdentifier, jobState, partitionID);
        final String jobsDump = jobMetricsOutputFormatter
                .getAsString();

        final String[] split = jobsDump.split("\n");
        assertNotNull(split);
        assertThat(split.length, is(5));

        assertThat(split[0], is(String.format(JOBS_START, jobIdentifier, jobState,
                String.format(PARTITION_ID_FORMAT,partitionID),
                jobMetricsOutputFormatter.getDumpId())));

        assertThat(split[1], is(String.format(JOBS_PREFIX, jobIdentifier, jobState,
                jobMetricsOutputFormatter.getDumpId(), job1.toString())));

        assertThat(split[2], is(String.format(JOBS_PREFIX, jobIdentifier, jobState,
                jobMetricsOutputFormatter.getDumpId(), job2.toString())));

        assertThat(split[3], is(String.format(JOBS_PREFIX, jobIdentifier, jobState,
                jobMetricsOutputFormatter.getDumpId(), job3.toString())));

        assertThat(split[4], is(String.format(JOBS_END, jobIdentifier, jobState,
                String.format(PARTITION_ID_FORMAT,partitionID),
                jobMetricsOutputFormatter.getDumpId())));
    }


    @Test
    public void getAsStringUsingFormatter() throws Exception {

        final PolicyJob<?> job1 = mock(PolicyJob.class);
        final PolicyJob<?> job2 = mock(PolicyJob.class);
        final PolicyJob<?> job3 = mock(PolicyJob.class);

        Mockito.when(job1.toString()).thenReturn("Job1");
        Mockito.when(job2.toString()).thenReturn("Job2");
        Mockito.when(job3.toString()).thenReturn("Job3");

        final Stream<PolicyJob<?>> jobs = Stream.of(job1, job2, job3);

        final String jobIdentifier = "System";
        final String jobState = "Ongoing";
        final String partitionID = "1";
        final Function<PolicyJob<?>, String> jobFormatter = (job -> job.toString() + " using Formatter");

        final JobMetricsOutputFormatter jobMetricsOutputFormatter =
                new JobMetricsOutputFormatter(jobs, jobIdentifier, jobState, partitionID);

        final String jobsDump = jobMetricsOutputFormatter
                .getAsString(jobFormatter);

        final String[] split = jobsDump.split("\n");
        assertNotNull(split);
        assertThat(split.length, is(5));

        assertThat(split[0], is(String.format(JOBS_START, jobIdentifier, jobState,
                String.format(PARTITION_ID_FORMAT,partitionID),
                jobMetricsOutputFormatter.getDumpId())));

        assertThat(split[1], is(String.format(JOBS_PREFIX, jobIdentifier, jobState,
                jobMetricsOutputFormatter.getDumpId(), jobFormatter.apply(job1))));

        assertThat(split[2], is(String.format(JOBS_PREFIX, jobIdentifier, jobState,
                jobMetricsOutputFormatter.getDumpId(), jobFormatter.apply(job2))));

        assertThat(split[3], is(String.format(JOBS_PREFIX, jobIdentifier, jobState,
                jobMetricsOutputFormatter.getDumpId(), jobFormatter.apply(job3))));

        assertThat(split[4], is(String.format(JOBS_END, jobIdentifier, jobState,
                String.format(PARTITION_ID_FORMAT,partitionID),
                jobMetricsOutputFormatter.getDumpId())));
    }

}