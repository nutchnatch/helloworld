package com.ossnms.dcn_manager.composables.ne;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.ne.NeGatewayRouteMerging.RoutePair;
import com.ossnms.dcn_manager.composables.ne.NeGatewayRouteMerging.SortMode;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import org.junit.Test;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.google.common.collect.Iterables.getOnlyElement;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.junit.Assert.assertThat;

public class NeGatewayRouteMergingTest {

    private static final int NE_ID = 0;
    private static final int VERSION = 0;

    @Test
    public void testPairCreation_noMutation() {

        final NeGatewayRouteMerging working = new NeGatewayRouteMerging(Optional.of(SortMode.LILO_ORDER),
            Collections.singleton(new NeGatewayRouteBuilder().setKey("a").build(NE_ID, VERSION)),
            Collections.<NeGatewayRouteMutationDescriptor>emptyList());

        final RoutePair onlyPair = getOnlyElement(working.getRoutePairs());
        assertThat(onlyPair.getKey(), is(present()));
        assertThat(onlyPair.getValue(), isA(NeGatewayRouteMutationDescriptor.class));
        assertThat(onlyPair.getValue().getPriority().get(), is(1));

        assertThat(working.routesToCreate(), is(emptyIterableOf(NeGatewayRouteMutationDescriptor.class)));
        assertThat(working.routesToUpdate(), hasItem(isA(NeGatewayRouteMutationDescriptor.class)));
    }

    @Test
    public void testPairCreation_withMutation() {

        final NeGatewayRouteData route = new NeGatewayRouteBuilder().setKey("a").build(NE_ID, VERSION);
        final NeGatewayRouteMutationDescriptor mutation = new NeGatewayRouteMutationDescriptor(route);

        final NeGatewayRouteMerging working = new NeGatewayRouteMerging(Optional.of(SortMode.LILO_ORDER),
            Collections.singleton(route),
            Collections.singleton(mutation));

        final RoutePair onlyPair = getOnlyElement(working.getRoutePairs());
        assertThat(onlyPair.getKey(), is(present()));
        assertThat(onlyPair.getKey().get(), is(route));
        assertThat(onlyPair.getValue(), is(mutation));
        assertThat(onlyPair.getValue().getPriority().get(), is(1));

        assertThat(working.routesToCreate(), is(emptyIterableOf(NeGatewayRouteMutationDescriptor.class)));
        assertThat(working.routesToUpdate(), hasItem(mutation));
    }

    @Test
    public void testPairCreation_allNew() {

        final NeGatewayRouteMerging working = new NeGatewayRouteMerging(Optional.of(SortMode.LILO_ORDER),
            Collections.<NeGatewayRouteData>emptyList(),
            Collections.singleton(new NeGatewayRouteMutationDescriptor(new NeGatewayRouteBuilder().setKey("a").build(NE_ID, VERSION))));

        final RoutePair onlyPair = getOnlyElement(working.getRoutePairs());
        assertThat(onlyPair.getKey(), is(absent()));
        assertThat(onlyPair.getValue(), isA(NeGatewayRouteMutationDescriptor.class));
        assertThat(onlyPair.getValue().getPriority().get(), is(1));

        assertThat(working.routesToCreate(), hasItem(isA(NeGatewayRouteMutationDescriptor.class)));
        assertThat(working.routesToUpdate(), is(emptyIterableOf(NeGatewayRouteMutationDescriptor.class)));
    }

    @Test
    public void testPairCreation_withNewAndExisting() {

        final NeGatewayRouteData existing = new NeGatewayRouteBuilder().setKey("a").build(NE_ID, VERSION);
        final NeGatewayRouteMutationDescriptor creating = new NeGatewayRouteMutationDescriptor(
                new NeGatewayRouteBuilder().setKey("b").build(NE_ID, VERSION));

        final NeGatewayRouteMerging working = new NeGatewayRouteMerging(Optional.of(SortMode.LILO_ORDER),
            Collections.singleton(existing),
            Collections.singleton(creating));

        final List<RoutePair> pairs = working.getRoutePairs();
        assertThat(pairs, hasSize(2));
        assertThat(pairs.get(0).getKey().get(), is(existing));
        assertThat(pairs.get(0).getValue(), isA(NeGatewayRouteMutationDescriptor.class));
        assertThat(pairs.get(0).getValue().getPriority().get(), is(1));
        assertThat(pairs.get(1).getKey(), is(absent()));
        assertThat(pairs.get(1).getValue(), is(creating));
        assertThat(pairs.get(1).getValue().getPriority().get(), is(2));

        assertThat(working.routesToCreate(), hasItem(creating));
        assertThat(working.routesToUpdate(), hasItem(isA(NeGatewayRouteMutationDescriptor.class)));
    }

    @Test
    public void testPairCreation_withNewUpdateAndExisting() {

        final NeGatewayRouteData existing = new NeGatewayRouteBuilder().setKey("a").setPriority(1).build(NE_ID, VERSION);
        final NeGatewayRouteMutationDescriptor updating = new NeGatewayRouteMutationDescriptor(existing);
        final NeGatewayRouteMutationDescriptor creating = new NeGatewayRouteMutationDescriptor(
                new NeGatewayRouteBuilder().setKey("b").setPriority(1).build(NE_ID, VERSION));

        final NeGatewayRouteMerging working = new NeGatewayRouteMerging(Optional.of(SortMode.LILO_ORDER),
            Collections.singleton(existing),
            ImmutableList.of(creating, updating));

        final List<RoutePair> pairs = working.getRoutePairs();
        assertThat(pairs, hasSize(2));
        assertThat(pairs.get(0).getKey().get(), is(existing));
        assertThat(pairs.get(0).getValue(), is(updating));
        assertThat(pairs.get(0).getValue().getPriority(), is(absent())); // no priority change
        assertThat(pairs.get(1).getKey(), is(absent()));
        assertThat(pairs.get(1).getValue(), is(creating));
        assertThat(pairs.get(1).getValue().getPriority().get(), is(2));

        assertThat(working.routesToCreate(), hasItem(creating));
        assertThat(working.routesToUpdate(), hasItem(updating));
    }
}
