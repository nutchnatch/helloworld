package com.ossnms.dcn_manager.composables.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNeTypeException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class UpdateNePropertiesBaseTest {

    private static final int ID = 1, VERSION = 1;

    private StaticConfiguration staticConfig;
    private Types<NeType> neTypes;
    private NeEntityRepository repo;
    private NeEntityRepository.NeGatewayRoutesRepository routesRepo;
    private NeEntityRepository.NeUserPreferencesRepository prefsRepo;
    private NePropertiesUpdater<CallContext> updater;
    private NetworkElementInteractionManager neInteraction;

    private NeType type;
    private NeEntity entity;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {

        neTypes = mock(Types.class);
        staticConfig = mock(StaticConfiguration.class);
        repo = mock(NeEntityRepository.class);
        routesRepo = mock(NeEntityRepository.NeGatewayRoutesRepository.class);
        prefsRepo = mock(NeEntityRepository.NeUserPreferencesRepository.class);
        updater = mock(NePropertiesUpdater.class);
        neInteraction = mock(NetworkElementInteractionManager.class);

        type = MockFactory.mockNeType();

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                new NeInfoBuilder().setProxyType("neType").build(ID, 1, VERSION),
                new NeSynchronizationData.NeSynchronizationBuilder().build(ID, VERSION),
                new NeUserPreferencesBuilder().setName("neName").build(ID, VERSION));

        when(updater.getRepository()).thenReturn(repo);

        when(neTypes.get("neType")).thenReturn(type);

        when(routesRepo.queryRoutes(ID)).thenReturn(Collections.<NeGatewayRouteData>emptyList());

        when(repo.queryNe(ID)).thenReturn(Optional.of(entity));
        when(repo.getNeGatewayRoutesRepository()).thenReturn(routesRepo);
        when(repo.getNeUserPreferencesRepository()).thenReturn(prefsRepo);

        when(staticConfig.getNeTypes()).thenReturn(neTypes);
    }

    @Test
    public void testPropertyUpdate() throws Exception {

        final NePhysicalConnectionData instance =
                new NePhysicalConnectionData.NePhysicalConnectionBuilder().build(1, 1, 1, 1);
        final NeUserPreferencesMutationDescriptor descriptor =
                new NeUserPreferencesMutationDescriptor(new NeUserPreferencesBuilder().setName("n").build(1, 1));

        buildBase().updateNeProperties(entity, instance, descriptor);

        verify(neInteraction).onNePropertiesUpdated(entity, instance, descriptor);
    }

    @Test
    public void testChange() throws DcnManagerException {

        final Map<String, String> emptyMap = Collections.<String, String>emptyMap();

        buildBase().applyUpdate(ID, emptyMap);

        verify(updater).applyUpdate(type, entity, Collections.<NeGatewayRouteData>emptyList(), emptyMap);
    }

    @Test(expected=RepositoryException.class)
    public void testRepositoryErrorOnNe() throws DcnManagerException {

        when(repo.queryNe(anyInt())).thenThrow(new RepositoryException());

        buildBase().applyUpdate(ID, Collections.<String, String>emptyMap());
    }

    @Test(expected=UnknownNetworkElementIdException.class)
    public void testInvalidNeId() throws DcnManagerException {

        when(repo.queryNe(anyInt())).thenReturn(Optional.<NeEntity>empty());

        final UpdateNePropertiesBase<CallContext> cmd =
                new UpdateNePropertiesBase<>(staticConfig, neInteraction, updater);

        cmd.applyUpdate(-1, Collections.<String, String>emptyMap());
    }

    @Test(expected=UnknownNeTypeException.class)
    public void testInvalidNeType() throws DcnManagerException {

        final NeInfoData state = new NeInfoBuilder()
            .setProxyType("badType")
            .build(ID, 1, VERSION);

        entity = new NeEntity(null, null, state, null, null);
        when(repo.queryNe(ID)).thenReturn(Optional.of(entity));

        final UpdateNePropertiesBase<CallContext> cmd = buildBase();

        cmd.applyUpdate(ID, Collections.<String, String>emptyMap());
    }

    private UpdateNePropertiesBase<CallContext> buildBase() {
        return new UpdateNePropertiesBase<>(staticConfig, neInteraction, updater);
    }

}
