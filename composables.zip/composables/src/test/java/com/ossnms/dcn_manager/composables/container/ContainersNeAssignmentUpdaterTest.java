package com.ossnms.dcn_manager.composables.container;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContainersNeAssignmentUpdaterTest {

    private static final int CONTAINER_ID_1 = 1;
    private static final int CONTAINER_ID_2 = 2;
    private static final int CONTAINER_ID_3 = 3;
    private static final int CONTAINER_ID_4 = 4;
    private static final int CONTAINER_ID_5 = 5;
    private static final int NE_ID = 1;
    private static final int VERSION = 100;

    @Mock private SettingsRepository settingsRepository;
    @Mock private ContainerRepository containerRepository;
    @Mock private SystemRepository systemRepository;
    @Mock private ContainerNotifications containerNotifications;
    @Mock private LoggerManager<CallContext> loggerManager;
    @Mock private CallContext context;

    private ContainersNeAssignmentUpdater<CallContext> updater;
    private NeUserPreferencesData nePrefs;

    @Before public void setUp() throws Exception {
        updater = new ContainersNeAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications,
                loggerManager, context);
        nePrefs = new NeUserPreferencesData.NeUserPreferencesBuilder().setName("neName").build(NE_ID, VERSION);

        when(containerRepository.queryByName(anyString())).thenReturn(Optional.of(new ContainerInfo(1,1,"c")));
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(1,1));
    }

    @Test public void storeForNeAssignment() throws Exception {
        final NeAssignmentData current1 = new NeAssignmentData(new ContainerInfo(CONTAINER_ID_1, VERSION, "c1"), NE_ID,
                AssignmentType.PRIMARY);
        final NeAssignmentData current2 = new NeAssignmentData(new ContainerInfo(CONTAINER_ID_2, VERSION, "c2"), NE_ID,
                AssignmentType.LOGICAL);
        final NeAssignmentData current3 = new NeAssignmentData(new ContainerInfo(CONTAINER_ID_3, VERSION, "c3"), NE_ID,
                AssignmentType.LOGICAL);

        final NeAssignmentData changed1 = new NeAssignmentData(new ContainerInfo(CONTAINER_ID_1, VERSION, "c1"), NE_ID,
                AssignmentType.LOGICAL);
        final NeAssignmentData changed4 = new NeAssignmentData(new ContainerInfo(CONTAINER_ID_4, VERSION, "c4"), NE_ID,
                AssignmentType.PRIMARY);
        final NeAssignmentData changed5 = new NeAssignmentData(new ContainerInfo(CONTAINER_ID_5, VERSION, "c5"), NE_ID,
                AssignmentType.LOGICAL);

        Iterable<NeAssignmentData> currentAssignments = ImmutableList.of(current1, current2, current3);
        Set<NeAssignmentData> changedAssignments = ImmutableSet.of(changed1, changed4, changed5);

        when(containerRepository.queryAllByNE(NE_ID)).thenReturn(currentAssignments);
        when(containerRepository.tryRemoveNeAssignment(current2)).thenReturn(true);
        when(containerRepository.tryRemoveNeAssignment(current3)).thenReturn(false);
        when(containerRepository.tryUpdateNeAssignment(current1)).thenReturn(true);

        updater.store(changedAssignments, nePrefs);

        verify(containerNotifications, atLeastOnce())
                .notifyChanges(new ContainerNeAssignmentAddedEvent(CONTAINER_ID_4, NE_ID, AssignmentType.PRIMARY));
        verify(containerNotifications, atLeastOnce())
                .notifyChanges(new ContainerNeAssignmentAddedEvent(CONTAINER_ID_5, NE_ID, AssignmentType.LOGICAL));

        verify(containerNotifications, atLeastOnce())
                .notifyChanges(new ContainerNeAssignmentRemovedEvent(CONTAINER_ID_2, NE_ID));
        verify(containerNotifications, never())
                .notifyChanges(new ContainerNeAssignmentRemovedEvent(CONTAINER_ID_3, NE_ID));

        verify(containerNotifications, atLeastOnce())
                .notifyChanges(new ContainerNeAssignmentUpdatedEvent(CONTAINER_ID_1, NE_ID, AssignmentType.LOGICAL));

        verify(loggerManager, atLeastOnce()).createCommandLog(any(CallContext.class), any(LoggerItemContainer.class));

        verify(containerRepository, atLeastOnce()).tryUpdateNeAssignment(changed1);

        verify(containerRepository, atLeastOnce()).addNeAssignment(changed4);
        verify(containerRepository, atLeastOnce()).addNeAssignment(changed5);

        verify(containerRepository, atLeastOnce()).tryRemoveNeAssignment(current2);
        verify(containerRepository, atLeastOnce()).tryRemoveNeAssignment(current3);

        verify(containerRepository, never()).tryUpdateNeAssignment(current2);
        verify(containerRepository, never()).tryUpdateNeAssignment(current3);
        verify(containerRepository, never()).tryUpdateNeAssignment(changed4);
        verify(containerRepository, never()).tryUpdateNeAssignment(changed4);

        verify(containerRepository, never()).addNeAssignment(current1);
        verify(containerRepository, never()).addNeAssignment(current2);
        verify(containerRepository, never()).addNeAssignment(current3);

        verify(containerRepository, never()).tryRemoveNeAssignment(current1);
        verify(containerRepository, never()).tryRemoveNeAssignment(changed4);
        verify(containerRepository, never()).tryRemoveNeAssignment(changed5);
    }

    @Test public void storeForNeAssignmentNewSingleObject() throws Exception {
        final NeAssignmentData changed1 = new NeAssignmentData(new ContainerInfo(CONTAINER_ID_1, VERSION, "c1"), NE_ID,
                AssignmentType.PRIMARY);

        Iterable<NeAssignmentData> currentAssignments = Collections.emptyList();
        Set<NeAssignmentData> changedAssignments = ImmutableSet.of(changed1);

        when(containerRepository.queryAllByNE(NE_ID)).thenReturn(currentAssignments);

        updater.store(changedAssignments, nePrefs);

        verify(containerRepository, atLeastOnce()).addNeAssignment(changed1);
        verify(containerRepository, never()).tryUpdateNeAssignment(changed1);
        verify(containerRepository, never()).tryRemoveNeAssignment(changed1);
    }
}