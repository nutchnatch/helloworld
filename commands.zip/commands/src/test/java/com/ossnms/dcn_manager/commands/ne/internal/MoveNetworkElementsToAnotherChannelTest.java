package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class MoveNetworkElementsToAnotherChannelTest {

    private static final int NE_ID = 1;
    private static final int NE_INSTANCE_ID = 10;
    private static final int NEW_CHANNEL_ID = 2;
    private static final int NEW_CHANNEL_INSTANCE_ID = 20;
    private static final int MEDIATOR_INSTANCE_ID = 200;
    private static final int OLD_CHANNEL_ID = 3;
    private static final int OLD_CHANNEL_INSTANCE_ID = 30;
    private static final int VERSION = 0;
    private static final String NE_NAME = "neName";
    private static final String NE_TYPE = "type-name";
    private static final String OLD_CHANNEL_NAME = "oldChannel";
    private static final String NEW_CHANNEL_NAME = "newChannel";
    private static final String CHANNEL_TYPE = "channel-type";

    private CallContext context;
    private LoggerManager<CallContext> loggerManager;
    private NePhysicalConnectionRepository neInstanceRepository;
    private NetworkElementNotifications notifications;
    private NeInfoRepository neInfoRepository;
    private NeUserPreferencesRepository nePreferencesRepository;
    private ChannelUserPreferencesRepository channelPreferencesRepository;
    private ChannelInfoRepository channelInfoRepository;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;
    private NeEntityRepository neEntityRepository;
    private ChannelEntityRepository channelEntityRepository;

    private NetworkElementManagers neManagers;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        loggerManager = mock(LoggerManager.class);
        notifications = mock(NetworkElementNotifications.class);
        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        neInfoRepository = mock(NeInfoRepository.class);
        nePreferencesRepository = mock(NeUserPreferencesRepository.class);
        channelPreferencesRepository = mock(ChannelUserPreferencesRepository.class);
        channelInfoRepository = mock(ChannelInfoRepository.class);
        neEntityRepository = mock(NeEntityRepository.class);
        channelEntityRepository = mock(ChannelEntityRepository.class);
        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);

        when(neEntityRepository.getNeInfoRepository()).thenReturn(neInfoRepository);
        when(neEntityRepository.getNeUserPreferencesRepository()).thenReturn(nePreferencesRepository);
        when(channelEntityRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelEntityRepository.getChannelUserPreferencesRepository()).thenReturn(channelPreferencesRepository);

        when(channelInstanceRepository.queryAll(NEW_CHANNEL_ID)).thenReturn(Collections.singleton(
            new ChannelPhysicalConnectionBuilder().build(NEW_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NEW_CHANNEL_ID, VERSION)
        ));

        neManagers = new NetworkElementManagers(neEntityRepository, neInstanceRepository, null, notifications, null);
    }

    @Test
    public void move_successful() throws Exception {
        final ArgumentCaptor<NeInfoMutationDescriptor> mutationCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);

        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
            new NePhysicalConnectionBuilder().build(NE_INSTANCE_ID, NE_ID, OLD_CHANNEL_INSTANCE_ID, VERSION)
        ));

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(OLD_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(OLD_CHANNEL_NAME).build(OLD_CHANNEL_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        when(neInfoRepository.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
            channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                .call();

        verify(neInfoRepository).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(neInstanceRepository).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));

        verify(notifications).notifyChanges(mutationCaptor.capture());
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemNe.class));

        assertThat(mutationCaptor.getValue().getChannelId(), hasValue(NEW_CHANNEL_ID));
    }

    @Test
    public void move_partiallySuccessful_throws() throws Exception {
        final ArgumentCaptor<NeInfoMutationDescriptor> mutationCaptor = ArgumentCaptor.forClass(NeInfoMutationDescriptor.class);

        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));
        when(neInstanceRepository.queryAll(NE_ID)).thenReturn(Collections.singleton(
                new NePhysicalConnectionBuilder().build(NE_INSTANCE_ID, NE_ID, OLD_CHANNEL_INSTANCE_ID, VERSION)
            ));

        when(neInfoRepository.query(NE_ID + 1)).thenReturn(Optional.empty());
        when(nePreferencesRepository.query(NE_ID + 1)).thenReturn(Optional.empty());

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(OLD_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(OLD_CHANNEL_NAME).build(OLD_CHANNEL_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        when(neInfoRepository.tryUpdate(isA(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        try {
            new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
                channelInstanceRepository, loggerManager, ImmutableList.of(NE_ID + 1, NE_ID), NEW_CHANNEL_ID)
                    .call();
            fail("Should have thrown with partial success.");
        } catch (final CommandException e) {
            // good.
        }

        verify(neInstanceRepository).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));

        verify(notifications).notifyChanges(mutationCaptor.capture());
        verify(loggerManager, times(2)).createCommandLog(eq(context), isA(LoggerItemNe.class));

        assertThat(mutationCaptor.getValue().getChannelId(), hasValue(NEW_CHANNEL_ID));
        assertThat(mutationCaptor.getValue().getTarget().getId(), is(NE_ID));
    }

    @Test
    public void moveToSameChannel_isIgnored() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(OLD_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(OLD_CHANNEL_NAME).build(OLD_CHANNEL_ID, VERSION)));

        new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
            channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), OLD_CHANNEL_ID)
                .call();

        verify(neInfoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verifyZeroInteractions(notifications, loggerManager, neInstanceRepository, channelInstanceRepository);
    }

    @Test
    public void neRequiredToBeActive_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setRequiredActivationState(RequiredActivationState.ACTIVE).setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        try {
            new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
                channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                    .call();
        } catch (final CommandException e) {
            // good.
        }

        verify(neInfoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications, neInstanceRepository, channelInstanceRepository);
    }

    @Test
    public void differentChannelTypes_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(OLD_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(OLD_CHANNEL_NAME).build(OLD_CHANNEL_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType("wrong type").build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        try {
            new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
                channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                    .call();
            fail("Should have thrown an exception.");
        } catch (final CommandException e) {
            // good.
        }

        verify(neInfoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications, neInstanceRepository, channelInstanceRepository);
    }

    @Test
    public void move_failsWithConcurrentModification_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(OLD_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(OLD_CHANNEL_NAME).build(OLD_CHANNEL_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        when(neInfoRepository.tryUpdate(isA(NeInfoMutationDescriptor.class))).thenReturn(Optional.empty());

        try {
            new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
                channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                    .call();
        } catch (final CommandException e) {
            // good.
        }

        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications, neInstanceRepository, channelInstanceRepository);
    }

    @Test
    public void oldChannelInfo_notFound_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.empty());
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(OLD_CHANNEL_NAME).build(OLD_CHANNEL_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        try {
            new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
                channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                    .call();
        } catch (final CommandException e) {
            // good.
        }

        verify(neInfoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications, neInstanceRepository, channelInstanceRepository);
    }

    @Test
    public void oldChannelPreferences_notFound_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(OLD_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.empty());

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        try {
            new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
                channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                    .call();
        } catch (final CommandException e) {
            // good.
        }

        verify(neInfoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications, neInstanceRepository, channelInstanceRepository);
    }

    @Test(expected=UnknownChannelIdException.class)
    public void newChannelInfo_notFound_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(OLD_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(OLD_CHANNEL_NAME).build(OLD_CHANNEL_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.empty());
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
            channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                .call();
    }

    @Test(expected=UnknownChannelIdException.class)
    public void newChannelPreferences_notFound_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(OLD_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(OLD_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(OLD_CHANNEL_NAME).build(OLD_CHANNEL_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.empty());

        new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
            channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                .call();
    }

    @Test
    public void neInfo_notFound_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.empty());
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        try {
            new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
                channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                    .call();
        } catch (final CommandException e) {
            // good.
        }

        verify(neInfoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications, neInstanceRepository, channelInstanceRepository);
    }

    @Test
    public void nePreferences_notFound_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.empty());

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        try {
            new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
                channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                    .call();
        } catch (final CommandException e) {
            // good.
        }

        verify(neInfoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(loggerManager).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications, neInstanceRepository, channelInstanceRepository);
    }

    @Test(expected=RepositoryException.class)
    public void neInfo_repoError_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenThrow(new RepositoryException());
        when(nePreferencesRepository.query(NE_ID)).thenReturn(Optional.of(new NeUserPreferencesBuilder().setName(NE_NAME).build(NE_ID, VERSION)));

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
            channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                .call();
    }

    @Test(expected=RepositoryException.class)
    public void nePreferences_repoError_fails() throws Exception {
        when(neInfoRepository.query(NE_ID)).thenReturn(Optional.of(new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, OLD_CHANNEL_ID, VERSION)));
        when(nePreferencesRepository.query(NE_ID)).thenThrow(new RepositoryException());

        when(channelInfoRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelInfoBuilder().setType(CHANNEL_TYPE).build(NEW_CHANNEL_ID, VERSION, 0)));
        when(channelPreferencesRepository.query(NEW_CHANNEL_ID)).thenReturn(Optional.of(new ChannelUserPreferencesBuilder().setName(NEW_CHANNEL_NAME).build(NEW_CHANNEL_ID, VERSION)));

        new MoveNetworkElementsToAnotherChannel<>(context, neManagers, channelEntityRepository,
            channelInstanceRepository, loggerManager, Collections.singletonList(NE_ID), NEW_CHANNEL_ID)
                .call();
    }
}
