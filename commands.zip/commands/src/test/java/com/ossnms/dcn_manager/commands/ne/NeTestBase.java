package com.ossnms.dcn_manager.commands.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;

import java.util.Collections;

import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public abstract class NeTestBase {

    protected CallContext context;
    protected StaticConfiguration staticConfig;
    protected Types<NeType> neTypes;
    protected DomainRepository domainRepo;
    protected DomainNotifications domainNotifications;
    protected SettingsRepository settingsRepository;
    protected GlobalSettings globalSettings;

    protected NetworkElementNotifications notif;
    protected LoggerManager<CallContext> loggerManager;

    protected NeEntityRepository neRepo;
    protected NeEntityRepository.NeGatewayRoutesRepository routesRepo;
    protected NeEntityRepository.NeConnectionRepository connectionRepo;
    protected NeEntityRepository.NeInfoRepository infoRepo;
    protected NeEntityRepository.NeOperationRepository operationRepo;
    protected NeEntityRepository.NeUserPreferencesRepository preferencesRepo;
    protected NeEntityRepository.NeSynchronizationRepository synchronizationRepo;

    protected NePhysicalConnectionRepository neInstanceRepo;

    @Before
    @SuppressWarnings({"unchecked","rawtypes"})
    public void setUp() throws RepositoryException {
        context = mock(CallContext.class);
        neTypes = mock(Types.class);
        staticConfig = mock(StaticConfiguration.class);
        domainRepo = mock(DomainRepository.class);
        domainNotifications = mock(DomainNotifications.class);
        settingsRepository = mock(SettingsRepository.class);
        globalSettings = GlobalSettings.build().setDiscoveryPolicy(DiscoveryPolicy.DISCOVERY_BY_DOMAIN).toGlobalSettings(1,1);
        notif = mock(NetworkElementNotifications.class);
        loggerManager = mock(LoggerManager.class);

        neRepo = mock(NeEntityRepository.class);
        routesRepo = mock(NeEntityRepository.NeGatewayRoutesRepository.class);
        connectionRepo = mock(NeEntityRepository.NeConnectionRepository.class);
        infoRepo = mock(NeEntityRepository.NeInfoRepository.class);
        operationRepo = mock(NeEntityRepository.NeOperationRepository.class);
        preferencesRepo = mock(NeEntityRepository.NeUserPreferencesRepository.class);
        synchronizationRepo = mock(NeEntityRepository.NeSynchronizationRepository.class);

        neInstanceRepo = mock(NePhysicalConnectionRepository.class);

        when(routesRepo.queryRoutes(anyInt())).thenReturn(Collections.<NeGatewayRouteData>emptyList());
        when(routesRepo.updateRoutes(anyInt(), any(Iterable.class)))
                .then(invocation -> invocation.getArguments()[1]);
        when(routesRepo.createRoutes(anyInt(), any(Iterable.class)))
                .then(invocation -> invocation.getArguments()[1]);
        when(routesRepo.updateRoute(isA(UowContext.class), anyInt(), isA(NeGatewayRouteMutationDescriptor.class)))
                .then(invocation -> ((NeGatewayRouteMutationDescriptor) invocation.getArguments()[2]).apply());
        when(routesRepo.createRoute(isA(UowContext.class), anyInt(), isA(NeGatewayRouteMutationDescriptor.class)))
                .then(invocation -> ((NeGatewayRouteMutationDescriptor) invocation.getArguments()[2]).apply());

        when(neRepo.getNeGatewayRoutesRepository()).thenReturn(routesRepo);
        when(neRepo.getNeUserPreferencesRepository()).thenReturn(preferencesRepo);
        when(neRepo.getNeConnectionRepository()).thenReturn(connectionRepo);
        when(neRepo.getNeInfoRepository()).thenReturn(infoRepo);
        when(neRepo.getNeOperationRepository()).thenReturn(operationRepo);
        when(neRepo.getNeSynchronizationRepository()).thenReturn(synchronizationRepo);

        when(staticConfig.getNeTypes()).thenReturn(neTypes);
        
        when(settingsRepository.getSettings()).thenReturn(globalSettings);

    }

}
