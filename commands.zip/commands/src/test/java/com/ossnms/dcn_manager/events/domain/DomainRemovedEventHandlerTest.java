package com.ossnms.dcn_manager.events.domain;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.domain.DomainDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.events.domain.DomainChildrenChanged;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationDeleted;
import com.ossnms.dcn_manager.core.events.domain.DomainRemoved;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class DomainRemovedEventHandlerTest {

    private static final int NE_ID = 1;
    private static final int VERSION = 1;

    private CallContext context;
    private DomainRepository domainRepository;
    private DomainNotifications domainNotifications;
    private SettingsRepository settingsRepository;

    private final DomainInfoData daInfo = new DomainInfoData(1, 0, "DA");

    @Before
    public void setUp() throws RepositoryException {
        context = mock(CallContext.class);

        domainRepository = mock(DomainRepository.class);
        domainNotifications = mock(DomainNotifications.class);
        settingsRepository = mock(SettingsRepository.class);

        final GlobalSettings globalSettings = GlobalSettings.build().setDiscoveryPolicy(DiscoveryPolicy.DISCOVERY_BY_DOMAIN).toGlobalSettings(NE_ID, VERSION);

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.emptyList());
        when(settingsRepository.getSettings()).thenReturn(globalSettings);
    }

    @Test
    public void domainRemoved() throws Exception {

        when(domainRepository.queryNaturalDomainsForNE(NE_ID)).thenReturn(ImmutableList.of(daInfo));
        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.singletonList(NE_ID));

        when(domainRepository.queryAllForNE(NE_ID))
                .thenReturn(ImmutableList.of(daInfo))
                .thenReturn(ImmutableList.of());

        when(domainRepository.queryByName("DA")).thenReturn(Optional.of(daInfo));

        when(domainRepository.tryRemoveNaturalNE(anyInt(), anyInt())).thenReturn(true);

        new DomainRemovedEventHandler<>(context, new DomainManagers(domainRepository, domainNotifications), settingsRepository)
                .handleEvent(new DomainRemoved(NE_ID, daInfo.getId(), "DA"));

        verify(domainRepository).tryRemoveNaturalNE(daInfo.getId(), NE_ID);

        verify(domainNotifications).notifyChanges(isA(DomainChildrenChanged.class));

        verify(domainNotifications).notifyChanges(new DomainParticipationDeleted(daInfo.getId(), NE_ID));
    }

    @Test
    public void domainRemoved_noLongerExists_doesNothing() throws Exception {

        when(domainRepository.queryNaturalDomainsForNE(NE_ID)).thenReturn(ImmutableList.of());

        new DomainRemovedEventHandler<>(context, new DomainManagers(domainRepository, domainNotifications), settingsRepository)
                .handleEvent(new DomainRemoved(NE_ID, daInfo.getId(), "DA"));

        verify(domainRepository, never()).delete(eq(new DomainDeletionDescriptor(daInfo.getId())));
        verify(domainRepository, never()).tryRemoveNaturalNE(daInfo.getId(), NE_ID);

        verifyZeroInteractions(domainNotifications);
    }

}