package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class NeConnectionEventHandlerBaseTest {

    private static final int NE_ID = 42;

    private CallContext context;
    private NeEntityRepository repository;
    private NeEntityRepository.NeConnectionRepository connectionRepo;
    private NetworkElementNotifications notifications;
    private NeEvent event;
    private NeConnectionData entity;

    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        repository = mock(NeEntityRepository.class);
        connectionRepo = mock(NeEntityRepository.NeConnectionRepository.class);
        notifications = mock(NetworkElementNotifications.class);
        event = mock(NeEvent.class);

        when(repository.getNeConnectionRepository()).thenReturn(connectionRepo);

        entity = new NeConnectionBuilder().build(NE_ID, 1);

        when(event.getNeId()).thenReturn(NE_ID);
    }

    @Test
    public void event_neNotFound() throws RepositoryException {

        when(connectionRepo.query(anyInt())).thenReturn(Optional.<NeConnectionData>empty());

        new Handler(context, repository, notifications, null).call(event);

        verify(connectionRepo, never()).tryUpdate(any(NeConnectionMutationDescriptor.class));
        verifyZeroInteractions(notifications);
    }

    @Test
    public void event_noChange() throws RepositoryException {

        when(connectionRepo.query(anyInt())).thenReturn(Optional.of(entity));

        new Handler(context, repository, notifications, Optional.<NeConnectionMutationDescriptor>empty()).call(event);

        verify(connectionRepo, never()).tryUpdate(any(NeConnectionMutationDescriptor.class));
        verifyZeroInteractions(notifications);
    }

    @Test
    public void event_change() throws RepositoryException {
        final NeConnectionMutationDescriptor mutationDescriptor = new NeConnectionMutationDescriptor(entity);

        when(connectionRepo.query(anyInt())).thenReturn(Optional.of(entity));
        when(connectionRepo.tryUpdate(isA(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        new Handler(context, repository, notifications, Optional.of(mutationDescriptor)).call(event);

        verify(connectionRepo).tryUpdate(mutationDescriptor);
    }

    private static final class Handler extends NeConnectionEventHandlerBase<CallContext, NeEvent> {

        private final Optional<NeConnectionMutationDescriptor> mutation;

        protected Handler(CallContext context,
                          NeEntityRepository repository,
                          NetworkElementNotifications notifications,
                          Optional<NeConnectionMutationDescriptor> mutation) {
            super(context, repository, notifications);
            this.mutation = mutation;
        }

        @Override
        protected Optional<NeConnectionMutationDescriptor> triggerMutation(
                NeConnectionBehavior behavior, NeEvent event) {
            return mutation;
        }

    }
}
