package com.ossnms.dcn_manager.commands.channel;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownChannelPropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelTypeException;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

public class GetChannelPropertiesTest extends ChannelTestBase {

    private ChannelType type;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();
        type = MockFactory.mockEmType();
    }

    @Test
    public void testGetProperties() throws Exception {
        when(repo.queryChannel(1)).thenReturn(Optional.of(buildEntity()));
        when(channelTypes.get(anyString())).thenReturn(type);

        final Optional<Map<String, String>> props = new GetChannelProperties<>(context, repo, staticConfig, 1).call();
        assertThat(props, is(present()));
        assertThat(props.get(), allOf(
                hasEntry("Custom", "Value"),
                hasEntry(WellKnownChannelPropertyNames.ID_NAME, "name"),
                hasEntry(WellKnownChannelPropertyNames.RECONNECT_INTERVAL, "345")));
    }

    @Test
    public void testGetProperties_channelDoesNotExist_returnsAbsent() throws Exception {
        when(repo.queryChannel(anyInt())).thenReturn(Optional.empty());

        final Optional<Map<String, String>> props = new GetChannelProperties<>(context, repo, staticConfig, 1).call();
        assertThat(props, is(absent()));
    }

    @Test(expected=CommandException.class)
    public void testGetProperties_repositoryError_throws() throws Exception {
        when(repo.queryChannel(anyInt())).thenThrow(new RepositoryException());
        new GetChannelProperties<>(context, repo, staticConfig, 1).call();
    }

    @Test(expected=UnknownChannelTypeException.class)
    public void testGetProperties_unknownType_throws() throws Exception {
        when(repo.queryChannel(1)).thenReturn(Optional.of(buildEntity()));
        when(channelTypes.get(anyString())).thenReturn(null);
        new GetChannelProperties<>(context, repo, staticConfig, 1).call();
    }

    private ChannelEntity buildEntity() {
        return new ChannelEntity(
            new ChannelInfoBuilder().setType("type").build(1, 1, 1),
            new ChannelConnectionBuilder().build(1, 1),
            new ChannelUserPreferencesBuilder().setName("name").setProperty("Custom", "Value").setReconnectInterval(345).build(1, 1));
    }
}
