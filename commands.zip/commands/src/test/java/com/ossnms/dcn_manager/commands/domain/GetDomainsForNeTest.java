package com.ossnms.dcn_manager.commands.domain;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.commands.domain.GetDomainsForNe;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class GetDomainsForNeTest {

    private DomainRepository repo;

    @Before
    public void setUp() {
        repo = mock(DomainRepository.class);
    }

    @Test
    public void testSingleResult() throws RepositoryException {
        final DomainInfoData domain = new DomainInfoData(1, 1, "name");
        final List<DomainInfoData> domainList = Collections.singletonList(domain);

        when(repo.queryAllForNE(23)).thenReturn(domainList);

        final Iterable<DomainInfoData> result = new GetDomainsForNe<>(null, repo, 23).call();

        assertThat(result, is((Iterable<DomainInfoData>) domainList));
    }

    @Test
    public void testEmptyResult() throws RepositoryException {
        final List<DomainInfoData> domainList = Collections.emptyList();

        when(repo.queryAllForNE(23)).thenReturn(domainList);

        final Iterable<DomainInfoData> result = new GetDomainsForNe<>(null, repo, 23).call();

        assertThat(result, is((Iterable<DomainInfoData>) domainList));
    }

}
