package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeRestartRequestEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

public class PhysicalNeRestartRequestEventHandlerTest {

    private static final int NE_ID = 1;
    private static final int CHANNEL_ID = 2;
    private static final int ACTIVE_NE_INSTANCE_ID = 10;
    private static final int ACTIVE_CHANNEL_INSTANCE_ID = 20;
    private static final int MEDIATOR_INSTANCE_ID = 3000;

    private NetworkElementInteractionManager activationManager;
    private NePhysicalConnectionRepository neInstanceRepository;
    private NetworkElementNotifications notifications;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;

    private PhysicalNeRestartRequestEventHandler<CallContext> handler;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        final NeEntityRepository neRepository = mock(NeEntityRepository.class);
        final MessageSource<NeEvent> neEvents = mock(MessageSource.class);
        final CallContext context = mock(CallContext.class);

        notifications = mock(NetworkElementNotifications.class);
        activationManager = mock(NetworkElementInteractionManager.class);
        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);

        final NetworkElementManagers neManagers = new NetworkElementManagers(neRepository, neInstanceRepository, activationManager, notifications, neEvents);

        handler = new PhysicalNeRestartRequestEventHandler<>(context, neManagers, channelInstanceRepository);
    }

    @Test
    public void testRestart() throws Exception {

        final ChannelPhysicalConnectionData channel = new ChannelPhysicalConnectionBuilder()
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(ACTIVE_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neInstanceRepository.query(ACTIVE_NE_INSTANCE_ID)).thenReturn(Optional.of(activated));

        when(channelInstanceRepository.query(ACTIVE_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channel));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.handleEvent(new PhysicalNeRestartRequestEvent(NE_ID, ACTIVE_NE_INSTANCE_ID));

        verify(activationManager).scheduleDeactivation(new Deactivate(NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, ACTIVE_NE_INSTANCE_ID, true));
        verify(notifications).notifyChanges(isA(NeShuttingDownEvent.class));
    }

    @Test
    public void testRestart_neRepoErrorUpdating_propagatesAndDoesNothing() throws Exception {

        final ChannelPhysicalConnectionData channel = new ChannelPhysicalConnectionBuilder()
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(ACTIVE_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neInstanceRepository.query(ACTIVE_NE_INSTANCE_ID)).thenReturn(Optional.of(activated));

        when(channelInstanceRepository.query(ACTIVE_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channel));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).thenThrow(new RepositoryException());

        try {
            handler.handleEvent(new PhysicalNeRestartRequestEvent(NE_ID, ACTIVE_NE_INSTANCE_ID));
            fail("Did not propagate error.");
        } catch (RepositoryException e) {
            // good
        }

        verify(activationManager, never()).scheduleDeactivation(new Deactivate(NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, ACTIVE_NE_INSTANCE_ID, true));
        verify(notifications, never()).notifyChanges(isA(NeShuttingDownEvent.class));
    }

    @Test
    public void testRestart_neRepoConcurrentUpdate_doesNothing() throws Exception {

        final ChannelPhysicalConnectionData channel = new ChannelPhysicalConnectionBuilder()
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(ACTIVE_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0);

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neInstanceRepository.query(ACTIVE_NE_INSTANCE_ID)).thenReturn(Optional.of(activated));

        when(channelInstanceRepository.query(ACTIVE_CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channel));

        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).thenReturn(Optional.empty());

        handler.handleEvent(new PhysicalNeRestartRequestEvent(NE_ID, ACTIVE_NE_INSTANCE_ID));

        verify(activationManager, never()).scheduleDeactivation(new Deactivate(NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, ACTIVE_NE_INSTANCE_ID, true));
        verify(notifications, never()).notifyChanges(isA(NeShuttingDownEvent.class));
    }

    @Test
    public void testRestart_unknownNeInstance_propagatesAndDoesNothing() throws Exception {

        when(neInstanceRepository.query(ACTIVE_NE_INSTANCE_ID)).thenReturn(Optional.empty());

        try {
            handler.handleEvent(new PhysicalNeRestartRequestEvent(NE_ID, ACTIVE_NE_INSTANCE_ID));
            fail("Error not reported.");
        } catch (UnknownNetworkElementIdException e) {
            // good.
        }

        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verifyZeroInteractions(activationManager, notifications);
    }

    @Test(expected = RepositoryException.class)
    public void testRestart_neRepoErrorReading_propagates() throws Exception {

        when(neInstanceRepository.query(ACTIVE_NE_INSTANCE_ID)).thenThrow(new RepositoryException());

        handler.handleEvent(new PhysicalNeRestartRequestEvent(NE_ID, ACTIVE_NE_INSTANCE_ID));
    }

    @Test
    public void testRestart_unknownChannelInstance_propagatesAndDoesNothing() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neInstanceRepository.query(ACTIVE_NE_INSTANCE_ID)).thenReturn(Optional.of(activated));

        when(channelInstanceRepository.query(ACTIVE_CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        try {
            handler.handleEvent(new PhysicalNeRestartRequestEvent(NE_ID, ACTIVE_NE_INSTANCE_ID));
            fail("Error not reported.");
        } catch (UnknownChannelIdException e) {
            // good.
        }

        verify(neInstanceRepository, never()).tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class));
        verifyZeroInteractions(activationManager, notifications);
    }

    @Test(expected = RepositoryException.class)
    public void testRestart_channelRepoErrorReading_propagates() throws Exception {

        final NePhysicalConnectionData activated = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZED)
                .setActive(true)
                .build(ACTIVE_NE_INSTANCE_ID, NE_ID, ACTIVE_CHANNEL_INSTANCE_ID, 0);

        when(neInstanceRepository.query(ACTIVE_NE_INSTANCE_ID)).thenReturn(Optional.of(activated));

        when(channelInstanceRepository.query(ACTIVE_CHANNEL_INSTANCE_ID)).thenThrow(new RepositoryException());

        handler.handleEvent(new PhysicalNeRestartRequestEvent(NE_ID, ACTIVE_NE_INSTANCE_ID));
    }
}
