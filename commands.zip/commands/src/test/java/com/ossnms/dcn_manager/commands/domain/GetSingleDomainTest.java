package com.ossnms.dcn_manager.commands.domain;

import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GetSingleDomainTest {

    private DomainRepository repo;

    @Before
    public void setUp() {
        repo = mock(DomainRepository.class);
    }

    @Test
    public void testSingleResult() throws RepositoryException {
        final DomainInfoData domain = new DomainInfoData(1, 1, "name");
        final Optional<DomainInfoData> domainFound = Optional.of(domain);

        when(repo.query(23)).thenReturn(domainFound);

        final Optional<DomainInfoData> result = new GetSingleDomain<>(null, repo, 23).call();

        assertThat(result, is(domainFound));
    }

    @Test
    public void testEmptyResult() throws RepositoryException {

        when(repo.query(23)).thenReturn(Optional.empty());

        final Optional<DomainInfoData> result = new GetSingleDomain<>(null, repo, 23).call();

        assertThat(result, is(absent()));
    }

}
