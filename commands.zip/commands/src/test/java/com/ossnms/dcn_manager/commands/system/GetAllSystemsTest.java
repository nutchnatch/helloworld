package com.ossnms.dcn_manager.commands.system;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.Test;

import com.ossnms.dcn_manager.commands.system.GetAllSystems;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class GetAllSystemsTest extends SystemTestBase {

    @Test
    public void testGetSystems() throws RepositoryException {
        final Iterable<SystemInfo> results = Collections.emptyList();
        when(repo.queryAll()).thenReturn(results);

        final Iterable<SystemInfo> iterable = new GetAllSystems<>(null, repo).call();

        assertThat(iterable, is(results));
    }

    @Test(expected=RepositoryException.class)
    public void testGetSystems_withRepositoryError() throws RepositoryException {

        when(repo.queryAll()).thenThrow(new RepositoryException());

        new GetAllSystems<>(null, repo).call();
    }

}
