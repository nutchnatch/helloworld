package com.ossnms.dcn_manager.commands.mediator;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class GetMediatorTest extends MediatorTestBase {

    @Test
    public void testGetMediator() throws Exception {
        final MediatorEntity repoEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, 1));

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(repoEntity));

        final MediatorEntity result = new GetMediator<>(null, repo, MEDIATOR_ID).call();

        assertThat(result, is(repoEntity));
    }

    @Test(expected=UnknownMediatorIdException.class)
    public void testGetMediator_unknownId() throws Exception {

        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.empty());

        new GetMediator<>(null, repo, MEDIATOR_ID).call();
    }

    @Test(expected=RepositoryException.class)
    public void testGetMediators_withRepositoryError() throws Exception {

        when(repo.query(MEDIATOR_ID)).thenThrow(new RepositoryException());

        new GetMediator<>(null, repo, MEDIATOR_ID).call();
    }

}
