package com.ossnms.dcn_manager.commands.ne;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CreateNetworkElementTest extends NeTestBase {

    private static final int NE_ID = 2;
    private static final int LOGICAL_CHANNEL_ID = 1;
    private static final String NE_NAME = "new_name";

    private ChannelEntityRepository channelRepository;
    private SystemRepository systemRepository;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;
    private NeType type;

    private final ChannelEntity channelEntity = new ChannelEntity(
        new ChannelInfoBuilder().setType("channelType").build(LOGICAL_CHANNEL_ID, 1, 1),
        new ChannelConnectionBuilder().build(LOGICAL_CHANNEL_ID, 1),
        new ChannelUserPreferencesBuilder().setName("channelName").build(LOGICAL_CHANNEL_ID, 1));

    private final ChannelPhysicalConnectionData channelInstance = new ChannelPhysicalConnectionBuilder()
            .setActive(true)
            .build(4, 6, LOGICAL_CHANNEL_ID, 0);

    private NetworkElementManagers neManagers;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        type = MockFactory.mockNeType();

        channelRepository = mock(ChannelEntityRepository.class);
        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);
        systemRepository = mock(SystemRepository.class);

        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(channelInstanceRepository.queryAll(LOGICAL_CHANNEL_ID)).thenReturn(Collections.singleton(channelInstance));

        when(type.getName()).thenReturn("TYPE");

        neManagers = new NetworkElementManagers(neRepo, neInstanceRepo, null, notif, null);
    }

    private void buildSibling(final String siblingName) throws RepositoryException {
        when(preferencesRepo.query(anyString())).thenReturn(Optional.empty());
        when(preferencesRepo.query(siblingName)).thenReturn(
            Optional.of(new NeUserPreferencesBuilder().setName(siblingName).build(62345, 1)));
    }

    private NeCreateDescriptor buildCreateDescriptor() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, type);
        createDescriptor.getPreferences().setName(NE_NAME);
        return createDescriptor;
    }

    @Test
    public void testCreation() throws DcnManagerException {
        final NeInfoData state = new NeInfoBuilder()
            .setProxyType("pt")
            .build(NE_ID, LOGICAL_CHANNEL_ID, 1);
        final NeUserPreferencesData prefs = new NeUserPreferencesBuilder()
            .setName("name")
            .build(NE_ID, 1);
        final NeEntity entity = new NeEntity(null, null, state, null, prefs);

        buildSibling("other");
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.of(channelEntity));
        when(neRepo.create(any(NeCreateDescriptor.class))).thenReturn(entity);

        final NeCreateDescriptor createDescriptor = buildCreateDescriptor();
        createDescriptor.getPreferences().getDirectRouteAdapter().setKey("newDirectRouteKey");
        createDescriptor.putGatewayRoutes(ImmutableList.of(
                new NeGatewayRouteBuilder().setKey("newGatewayRouteKey")
            ));

        final NeEntity ne = new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager, createDescriptor).call();

        assertNotNull(ne);
        assertThat(ne, is(entity));

        verify(loggerManager).createCommandLog(any(CallContext.class), any(LoggerItem[].class));

        final ArgumentCaptor<NeCreateDescriptor> create = ArgumentCaptor.forClass(NeCreateDescriptor.class);
        verify(neRepo).create(create.capture());

        final NeCreateDescriptor descriptor = create.getValue();
        assertThat(descriptor.getTypeName(), is("TYPE"));
        assertThat(descriptor.getChannelId(), is(LOGICAL_CHANNEL_ID));

        verify(neInstanceRepo).insert(isA(NePhysicalConnectionInitialData.class), eq(state.getId()), eq(channelInstance.getId()));

    }

    @Test(expected=IllegalStateException.class)
    public void testEmptyName() throws DcnManagerException {

        new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager,
                new NeCreateDescriptor(1, type))
            .call();
    }

    @Test(expected=DuplicatedObjectNameException.class)
    public void testDuplicatedName() throws DcnManagerException {

        buildSibling(NE_NAME);

        new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager, buildCreateDescriptor()).call();
    }

    @Test(expected=DuplicatedRouteException.class)
    public void testDuplicatedRoute_byKey() throws Exception {

        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.of(channelEntity));
        when(neRepo.queryNeName(anyInt())).thenReturn(Optional.of("name"));
        when(routesRepo.tryFindRouteKeys(eq(ImmutableSet.of("existingRouteKey")))).thenReturn(
                ImmutableSet.of(new ImmutablePair<>("existingRouteKey", 1)));

        buildSibling("other");

        final NeCreateDescriptor createDescriptor = buildCreateDescriptor();
        createDescriptor.putGatewayRoutes(ImmutableList.of(
                new NeGatewayRouteBuilder().setKey("existingRouteKey")
            ));
        new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager, createDescriptor).call();

    }

    @Test(expected=DuplicatedRouteException.class)
    public void testDuplicatedRoute_inDirectRoute() throws Exception {

        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.of(channelEntity));
        when(neRepo.queryNeName(anyInt())).thenReturn(Optional.of("name"));
        when(routesRepo.tryFindRouteKeys(eq(ImmutableSet.of("existingRouteKey")))).thenReturn(
                ImmutableSet.of(new ImmutablePair<>("existingRouteKey", 1)));

        buildSibling("other");

        final NeCreateDescriptor createDescriptor = buildCreateDescriptor();
        createDescriptor.getPreferences().getDirectRouteAdapter().setKey("existingRouteKey");
        new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager, createDescriptor).call();

    }

    @Test(expected=DuplicatedRouteException.class)
    public void testDuplicatedRoute_withinBuilderList() throws Exception {

        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.of(channelEntity));
        when(neRepo.queryNeName(anyInt())).thenReturn(Optional.of("name"));
        buildSibling("other");

        final NeCreateDescriptor createDescriptor = buildCreateDescriptor();
        createDescriptor.putGatewayRoutes(ImmutableList.of(
                new NeGatewayRouteBuilder().setKey("existingRouteKey"),
                new NeGatewayRouteBuilder().setKey("existingRouteKey")
            ));
        new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager, createDescriptor).call();

    }

    @Test(expected=UnknownChannelIdException.class)
    public void testUnknownType() throws DcnManagerException {

        buildSibling("other");
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());

        new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager, buildCreateDescriptor()).call();
    }

    @Test(expected=CommandException.class)
    public void testTypeValidationError() throws DcnManagerException {

        buildSibling("other");
        when(channelRepository.queryChannel(anyInt())).thenThrow(new RepositoryException());

        new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager, buildCreateDescriptor()).call();
    }

    @Test(expected=CommandException.class)
    public void testCreationError() throws DcnManagerException {

        buildSibling("other");
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.of(channelEntity));
        when(neRepo.create(any(NeCreateDescriptor.class))).thenThrow(new RepositoryException());

        new CreateNetworkElement<>(context, neManagers, channelRepository, systemRepository,  channelInstanceRepository, loggerManager, buildCreateDescriptor()).call();
    }

}
