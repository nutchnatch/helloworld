package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MediatorActivatingEventHandlerTest {

    private static final int MEDIATOR_ID = 42;
    private static final int VERSION = 1;

    private MediatorActivatingEventHandler<CallContext> handler;
    private CallContext context;
    private MediatorEntityRepository entityRepository;
    private MediatorInstanceEntityRepository physicalRepository;
    private MediatorConnectionRepository connectionStateRepository;
    private MediatorNotifications notifications;
    private MediatorInteractionManager activationManager;
    private MessageSource<MediatorEvent> mediatorEvents;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        entityRepository = mock(MediatorEntityRepository.class);
        physicalRepository = mock(MediatorInstanceEntityRepository.class);
        connectionStateRepository = mock(MediatorConnectionRepository.class);
        notifications = mock(MediatorNotifications.class);
        activationManager = mock(MediatorInteractionManager.class);
        mediatorEvents = mock(MessageSource.class);

        when(entityRepository.getMediatorConnectionRepository()).thenReturn(connectionStateRepository);

        handler = new MediatorActivatingEventHandler<>(context,
                new MediatorManagers(entityRepository, physicalRepository, notifications, activationManager, mediatorEvents));
    }

    @Test
    public void event_onDeactivatingMediator() throws RepositoryException {
        final MediatorConnectionData state = new MediatorConnectionBuilder()
            .setActualActivationState(ActualActivationState.INACTIVE)
            .setAdditionalInfo("")
            .build(MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(state));

        handler.call(new MediatorActivatingEvent(MEDIATOR_ID));

        final ArgumentCaptor<MediatorConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(MediatorConnectionMutationDescriptor.class);
        verify(connectionStateRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(MEDIATOR_ID));
        assertThat(captor.getValue().getActiveState().get(), is(ActualActivationState.ACTIVATING));
    }

    @Test
    public void event_mediatorNotFound() throws RepositoryException {
        when(connectionStateRepository.query(MEDIATOR_ID)).thenReturn(Optional.empty());

        handler.call(new MediatorActivatingEvent(MEDIATOR_ID));

        verify(connectionStateRepository, never()).tryUpdate(any(MediatorConnectionMutationDescriptor.class));
    }

    @Test
    public void event_onActiveMediator() throws RepositoryException {
        final MediatorConnectionData state = new MediatorConnectionBuilder()
            .setActualActivationState(ActualActivationState.ACTIVE)
            .setAdditionalInfo("")
            .build(MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(state));

        handler.call(new MediatorActivatingEvent(MEDIATOR_ID));

        verify(connectionStateRepository, never()).tryUpdate(any(MediatorConnectionMutationDescriptor.class));
    }

}
