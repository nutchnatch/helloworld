package com.ossnms.dcn_manager.commands.channel;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class DeleteChannelTest extends ChannelTestBase {

    private static final int MEDIATOR_ID = 5;
    private static final int CHANNEL_ID = 1;
    private static final int CHANNEL_INSTANCE_ID = 2;

    private NeEntityRepository neRepository;
    private NeInfoRepository neInfoRepository;

    private ChannelManagers channelManagers;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        neRepository = mock(NeEntityRepository.class);
        neInfoRepository = mock(NeInfoRepository.class);

        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);

        channelManagers = new ChannelManagers(repo, channelPhysicalConnectionRepository, notif, null, null);
    }

    @Test
    public void testDelete() throws Exception {
        final ChannelEntity channel = createChannel(false);
        final ArgumentCaptor<ChannelDeleteDescriptor> deleteDescriptorCaptor = ArgumentCaptor.forClass(ChannelDeleteDescriptor.class);

        when(repo.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(channel));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.singleton(createChannelInstance()));

        setupChildNe(2);

        new DeleteChannel<>(context, channelManagers, channelScheduling, neRepository, loggerManager, 1).call();

        verify(repo).delete(deleteDescriptorCaptor.capture());
        verify(notif).notifyDelete(channel);
        verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
        verify(channelPhysicalConnectionRepository).remove(CHANNEL_INSTANCE_ID);
        verify(channelScheduling).onChannelRemoved(CHANNEL_INSTANCE_ID);

        assertThat(deleteDescriptorCaptor.getValue().getId(), is(1));
    }

    private void setupChildNe(final int channelId) throws RepositoryException {
        when(neInfoRepository.queryAll(anyInt())).thenReturn(
            Collections.emptyList());
        when(neInfoRepository.queryAll(channelId)).thenReturn(
            Collections.singleton(new NeInfoBuilder().setProxyType("pt").build(1, channelId, 1)));
    }

    private ChannelEntity createChannel(boolean activationRequired) {
        return createChannel(activationRequired, ActualActivationState.INACTIVE);
    }

    private ChannelEntity createChannel(boolean activationRequired, ActualActivationState activation) {
        return new ChannelEntity(
            new ChannelInfoBuilder().setType("channelType").setActivationRequired(activationRequired).build(CHANNEL_ID, 1, MEDIATOR_ID),
            new ChannelConnectionBuilder().setActivation(activation).build(CHANNEL_ID, 1),
            new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, 1));
    }

    private ChannelPhysicalConnectionData createChannelInstance() {
        return new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, 1, CHANNEL_ID, 0);
    }

    @Test(expected=IllegalChannelStateException.class)
    public void testDeleteChannelWithChildNEs() throws Exception {
        final ChannelEntity channel = createChannel(false);

        when(repo.queryChannel(1)).thenReturn(Optional.of(channel));

        setupChildNe(1);

        new DeleteChannel<>(context, channelManagers, channelScheduling, neRepository, loggerManager, 1).call();
    }

    @Test(expected=IllegalChannelStateException.class)
    public void testDeleteActiveChannel() throws Exception {
        final ChannelEntity channel = createChannel(true);

        when(repo.queryChannel(1)).thenReturn(Optional.of(channel));

        new DeleteChannel<>(context, channelManagers, channelScheduling, neRepository, loggerManager, 1).call();
    }

    @Test(expected=IllegalChannelStateException.class)
    public void testDeleteConnectedChannel() throws Exception {
        final ChannelEntity channel = createChannel(false, ActualActivationState.ACTIVE);

        when(repo.queryChannel(1)).thenReturn(Optional.of(channel));

        new DeleteChannel<>(context, channelManagers, channelScheduling, neRepository, loggerManager, 1).call();
    }

    @Test(expected=CommandException.class)
    public void testDeleteWithRepositoryError() throws Exception {
        final ChannelEntity channel = createChannel(false);

        when(repo.queryChannel(1)).thenReturn(Optional.of(channel));

        setupChildNe(2);

        doThrow(new RepositoryException()).when(repo).delete(any(ChannelDeleteDescriptor.class));

        new DeleteChannel<>(context, channelManagers, channelScheduling, neRepository, loggerManager, 1).call();
    }

    @Test(expected=UnknownChannelIdException.class)
    public void testDeleteUnknownChannel() throws Exception {

        when(repo.queryChannel(anyInt())).thenReturn(Optional.empty());

        doThrow(new RepositoryException()).when(repo).delete(any(ChannelDeleteDescriptor.class));

        new DeleteChannel<>(context, channelManagers, channelScheduling, neRepository, loggerManager, 1).call();
    }

}
