package com.ossnms.dcn_manager.commands.system;

import static org.mockito.Mockito.mock;

import org.junit.Before;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public abstract class SystemTestBase {

    protected CallContext context;
    protected StaticConfiguration staticConfig;
    protected SystemRepository repo;
    protected LoggerManager<CallContext> loggerManager;

    protected static final int SYSTEM_ID = 1;
    protected static final int VERSION = 1;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws RepositoryException {
        context = mock(CallContext.class);
        staticConfig = mock(StaticConfiguration.class);
        repo = mock(SystemRepository.class);
        loggerManager = mock(LoggerManager.class);
    }

    protected SystemInfo newInfo() {
        return new SystemInfo(SYSTEM_ID, VERSION, "name");
    }

}
