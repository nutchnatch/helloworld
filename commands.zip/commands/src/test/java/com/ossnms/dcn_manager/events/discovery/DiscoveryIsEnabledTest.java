package com.ossnms.dcn_manager.events.discovery;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DiscoveryIsEnabledTest {

    private SettingsRepository settingsRepository;
    private NeDiscoveredEvent discovered;

    @Before
    public void setUp() {
        settingsRepository = mock(SettingsRepository.class);

        final NeType type = MockFactory.mockNeType();
        discovered = new NeDiscoveredEvent(new NeCreateDescriptor(2, type), ImmutableMap.<String, String>of(), Optional.of("name"), 1);
    }

    @Test
    public void discoverAllNetwork_isEnabled() {
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setDiscoveryPolicy(DiscoveryPolicy.DISCOVER_ALL_NETWORK).toGlobalSettings(1,1));

        final Boolean result = new DiscoveryIsEnabled(settingsRepository).call(discovered);
        assertThat(result, is(true));
    }

    @Test
    public void discoveryByDomain_isEnabled() {
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setDiscoveryPolicy(DiscoveryPolicy.DISCOVERY_BY_DOMAIN).toGlobalSettings(1,1));

        final Boolean result = new DiscoveryIsEnabled(settingsRepository).call(discovered);
        assertThat(result, is(true));
    }

    @Test
    public void nodiscovery_isDisabled() {
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setDiscoveryPolicy(DiscoveryPolicy.NO_DISCOVERY).toGlobalSettings(1,1));

        final Boolean result = new DiscoveryIsEnabled(settingsRepository).call(discovered);
        assertThat(result, is(false));
    }

}
