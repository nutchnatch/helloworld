package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelCreatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelConnectionRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ChannelCreatingEventHandlerTest {

    private static final int CHANNEL_ID = 42;
    private static final int VERSION = 1;

    private ChannelCreatingEventHandler<CallContext> handler;
    private CallContext context;
    private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    private ChannelEntityRepository entityRepository;
    private ChannelConnectionRepository connectionStateRepository;
    private ChannelNotifications notifications;
    private ChannelInteractionManager activationManager;
    private MessageSource<ChannelEvent> channelEvents;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);
        entityRepository = mock(ChannelEntityRepository.class);
        connectionStateRepository = mock(ChannelConnectionRepository.class);
        notifications = mock(ChannelNotifications.class);
        activationManager = mock(ChannelInteractionManager.class);
        channelEvents = mock(MessageSource.class);

        when(entityRepository.getChannelConnectionRepository()).thenReturn(connectionStateRepository);

        handler = new ChannelCreatingEventHandler<>(context,
                new ChannelManagers(entityRepository, channelPhysicalConnectionRepository, notifications, activationManager, channelEvents));
    }

    @Test
    public void event_onStartingUpChannel() throws RepositoryException {
        /*
         * STARTING UP is not supported at all for logical channels.
         */
        verifyNoActionOnState(ActualActivationState.STARTINGUP);
    }

    @Test
    public void event_channelNotFound() throws RepositoryException {
        when(connectionStateRepository.query(CHANNEL_ID)).thenReturn(Optional.empty());

        handler.call(new ChannelCreatingEvent(CHANNEL_ID));

        verify(connectionStateRepository, never()).tryUpdate(any(ChannelConnectionMutationDescriptor.class));
    }

    @Test
    public void event_onShuttingDownChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.SHUTTINGDOWN);
    }

    @Test
    public void event_onActiveChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.ACTIVE);
    }

    @Test
    public void event_onInactiveChannel() throws RepositoryException {
        final ChannelConnectionData state = new ChannelConnectionBuilder()
            .setActivation(ActualActivationState.INACTIVE)
            .setAdditionalInfo("")
            .build(CHANNEL_ID, VERSION);
        when(connectionStateRepository.query(CHANNEL_ID)).thenReturn(Optional.of(state));

        handler.call(new ChannelCreatingEvent(CHANNEL_ID));

        final ArgumentCaptor<ChannelConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(ChannelConnectionMutationDescriptor.class);
        verify(connectionStateRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(CHANNEL_ID));
        assertThat(captor.getValue().getActualActivationState().get(), is(ActualActivationState.CREATING));
    }

    @Test
    public void event_onDeactivatingChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.DEACTIVATING);
    }

    private void verifyNoActionOnState(ActualActivationState activationState) throws RepositoryException {
        final ChannelConnectionData state = new ChannelConnectionBuilder()
            .setActivation(activationState)
            .setAdditionalInfo("")
            .build(CHANNEL_ID, VERSION);
        when(connectionStateRepository.query(CHANNEL_ID)).thenReturn(Optional.of(state));

        handler.call(new ChannelCreatingEvent(CHANNEL_ID));

        verify(connectionStateRepository, never()).tryUpdate(any(ChannelConnectionMutationDescriptor.class));
    }

}
