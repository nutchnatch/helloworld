package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class PhysicalMediatorDeactivatedEventHandlerTest extends MediatorFinalStatusEventHandlerTestBase {

    private PhysicalMediatorDeactivatedEventHandler<CallContext> handler;
    private CallContext context;
    private MediatorInstanceEntityRepository instanceEntityRepository;
    private MediatorEntityRepository entityRepository;
    private MediatorPhysicalConnectionRepository connectionStateRepository;
    private MediatorNotifications notifications;
    private MediatorInteractionManager activationManager;
    private MessageSource<MediatorEvent> mediatorEvents;

    @SuppressWarnings("unchecked")
    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        context = mock(CallContext.class);
        instanceEntityRepository = mock(MediatorInstanceEntityRepository.class);
        entityRepository = mock(MediatorEntityRepository.class);
        connectionStateRepository = mock(MediatorPhysicalConnectionRepository.class);
        notifications = mock(MediatorNotifications.class);
        activationManager = mock(MediatorInteractionManager.class);
        mediatorEvents = mock(MessageSource.class);

        when(instanceEntityRepository.getMediatorPhysicalConnectionRepository()).thenReturn(connectionStateRepository);
        when(connectionStateRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler = new PhysicalMediatorDeactivatedEventHandler<>(context,
                new MediatorManagers(entityRepository, instanceEntityRepository, notifications, activationManager, mediatorEvents),
                new ChannelManagers(channelRepository, channelPhysicalConnectionRepository, channelNotifications, channelActivationManager, channelEvents)
        );
    }

    @Test
    public void event_onDeactivatingMediator_inactiveInstance_doesNotPropagate() throws RepositoryException {

        verifyDeactivatingMediator(false);

        verify(notifications).notifyChanges(new MediatorDeactivatedEvent(MEDIATOR_ID,
                new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, false)));
        verify(mediatorEvents, never()).push(new MediatorDeactivatedEvent(MEDIATOR_ID,
                new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, false)));
    }

    @Test
    public void event_onDeactivatingMediator_activeInstance_propagates() throws RepositoryException {

        verifyDeactivatingMediator(true);

        verify(notifications).notifyChanges(new MediatorDeactivatedEvent(MEDIATOR_ID,
                new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, true)));
        verify(mediatorEvents).push(new MediatorDeactivatedEvent(MEDIATOR_ID,
                new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, true)));
    }

    private void verifyDeactivatingMediator(boolean active) throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.DEACTIVATING)
            .setAdditionalInfo("")
            .setActive(active)
            .build(INSTANCE_ID, MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(INSTANCE_ID)).thenReturn(Optional.of(state));

        handler.call(new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, active));

        final ArgumentCaptor<MediatorPhysicalConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(MediatorPhysicalConnectionMutationDescriptor.class);
        verify(connectionStateRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(INSTANCE_ID));
        assertThat(captor.getValue().getActiveState().get(), is(ActualActivationState.INACTIVE));

        verify(channelEvents).push(new PhysicalChannelDeactivatedEvent(ACTIVE_CHANNEL_ID, CHANNEL_ID, false));
        verify(channelEvents, never()).push(new PhysicalChannelDeactivatedEvent(INACTIVE_CHANNEL_ID, CHANNEL_ID, false));
        verify(channelEvents, never()).push(new PhysicalChannelDeactivatedEvent(FOREIGN_CHANNEL_ID, CHANNEL_ID, false));
    }

    @Test
    public void event_mediatorNotFound() throws RepositoryException {
        when(connectionStateRepository.query(INSTANCE_ID)).thenReturn(Optional.empty());

        handler.call(new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, false));

        verify(connectionStateRepository, never()).tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class));
        verifyZeroInteractions(channelEvents);
    }

    @Test
    public void event_onInactiveMediator() throws RepositoryException {
        final MediatorPhysicalConnectionData state = new MediatorPhysicalConnectionBuilder()
            .setActualActivationState(ActualActivationState.INACTIVE)
            .setAdditionalInfo("")
            .build(INSTANCE_ID, MEDIATOR_ID, VERSION);
        when(connectionStateRepository.query(INSTANCE_ID)).thenReturn(Optional.of(state));

        handler.call(new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, false));

        verify(connectionStateRepository, never()).tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class));
        verifyZeroInteractions(channelEvents);
    }

}
