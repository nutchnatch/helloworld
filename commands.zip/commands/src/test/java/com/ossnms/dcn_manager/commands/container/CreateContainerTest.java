package com.ossnms.dcn_manager.commands.container;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CreateContainerTest {

    private static final int CONTAINER_ID = 56;

    private ContainerRepository repository;
    private SystemRepository systemRepository;
    private ContainerNotifications notifications;
    private LoggerManager<CallContext> loggerManager;
    private CallContext context;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {
        repository = mock(ContainerRepository.class);
        notifications = mock(ContainerNotifications.class);
        loggerManager = mock(LoggerManager.class);
        context = mock(CallContext.class);
        systemRepository = mock(SystemRepository.class);

        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());
    }

    @Test
    public void create() throws Exception {

        when(repository.queryByName(anyString())).thenReturn(Optional.empty());

        when(repository.create(any(ContainerCreationDescriptor.class))).then(new Answer<ContainerInfo>() {
            @Override
            public ContainerInfo answer(InvocationOnMock invocation) {
                final ContainerCreationDescriptor desc = (ContainerCreationDescriptor) invocation.getArguments()[0];
                return new ContainerInfo(CONTAINER_ID, 1, desc.getName());
            }
        });

        final ContainerCreationDescriptor creationDescriptor = new ContainerCreationDescriptor("name");
        final ContainerInfo containerInfo = new CreateContainer<>(context, repository, systemRepository, notifications, loggerManager, creationDescriptor)
            .call();

        assertThat(containerInfo, is(notNullValue()));
        assertThat(containerInfo.getName(), is(creationDescriptor.getName()));
        assertThat(containerInfo.getId(), is(CONTAINER_ID));

        verify(notifications).notifyCreate(containerInfo);
        verify(loggerManager).createCommandLog(any(CallContext.class), any(LoggerItem[].class));
    }

    @Test(expected=RepositoryException.class)
    public void create_repositoryError_throws() throws Exception {
        when(repository.queryByName(anyString())).thenThrow(new RepositoryException());
        when(repository.create(any(ContainerCreationDescriptor.class))).thenThrow(new RepositoryException());

        final ContainerCreationDescriptor creationDescriptor = new ContainerCreationDescriptor("name");
        new CreateContainer<>(context, repository, systemRepository, notifications, loggerManager, creationDescriptor).call();
    }

    @Test(expected=IllegalArgumentException.class)
    public void create_empty_name_throws() throws Exception {
        final ContainerCreationDescriptor creationDescriptor = new ContainerCreationDescriptor("");

        new CreateContainer<>(context, repository, systemRepository, notifications, loggerManager, creationDescriptor).call();
    }

    @Test(expected=DuplicatedObjectNameException.class)
    public void create_duplicated_container_name_throws() throws Exception {
        when(repository.queryByName(anyString())).thenReturn(Optional.of(new ContainerInfo(1, 1, "exists")));

        final ContainerCreationDescriptor creationDescriptor = new ContainerCreationDescriptor("exists");
        new CreateContainer<>(context, repository, systemRepository, notifications, loggerManager, creationDescriptor).call();
    }
}
