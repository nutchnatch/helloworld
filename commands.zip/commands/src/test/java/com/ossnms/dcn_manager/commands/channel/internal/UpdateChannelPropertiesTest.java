package com.ossnms.dcn_manager.commands.channel.internal;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.commands.channel.ChannelTestBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownChannelPropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.core.outbound.ChannelConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperty;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelTypeException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class UpdateChannelPropertiesTest extends ChannelTestBase {

    private static final String CHANNEL_NAME = "Channel name";
    private static final int ID = 1;
    private static final int VERSION = 1;
    private static final int CHANNEL_INSTANCE_ID = 1000;
    private static final int MEDIATOR_INSTANCE_ID = 2000;

    private SettingsRepository settingsRepo;
    private GlobalSettings settings;
    private ChannelConnectionManager connectionManager;

    private ChannelType type;

    private ChannelEntity entity;
    private ChannelInfoData state;
    private ChannelUserPreferencesData prefs;
    private ChannelConnectionData connState;

    private ChannelManagers channelManagers;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        settings = GlobalSettings.build()
                        .setMediatorRetries(42)
                        .setNeRetries(24)
                        .setRetryInterval(12)
                        .setScaledStartupLimit(98)
                        .setDiscoveryPolicy(DiscoveryPolicy.NO_DISCOVERY)
                        .setEnableScheduledStartup(false)
                        .toGlobalSettings(1,1);

        connectionManager = mock(ChannelConnectionManager.class);
        settingsRepo = mock(SettingsRepository.class);

        type = MockFactory.mockEmType();

        state = new ChannelInfoData(ID, VERSION, 20, new ChannelInfoInitialData().setType("channelType"));
        prefs = new ChannelUserPreferencesData(ID, VERSION, new ChannelUserPreferencesInitialData().setName("channelName"));
        connState = new ChannelConnectionData(ID, VERSION, new ChannelConnectionInitialData());

        entity = new ChannelEntity(state, connState, prefs);

        channelManagers = new ChannelManagers(repo, channelPhysicalConnectionRepository, notif, null, null);

        when(channelTypes.get("channelType")).thenReturn(type);
        when(repo.queryChannel(ID)).thenReturn(Optional.of(entity));
        when(infoRepo.query(ID)).thenReturn(Optional.of(state));
        when(connectionRepo.query(ID)).thenReturn(Optional.of(connState));
        when(userPrefsRepo.query(ID)).thenReturn(Optional.of(prefs));
        when(settingsRepo.getSettings()).thenReturn(settings);
        when(userPrefsRepo.query("New Name")).thenReturn(Optional.empty());
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testNameChange() throws DcnManagerException, ConnectException {
        runPropertyChange(true, ImmutableMap.of(ChannelProperty.ID_NAME.getName(), "New Name"));

        final ArgumentCaptor<Map> properties = ArgumentCaptor.forClass(Map.class);
        verify(connectionManager).updateChannelProperties(eq(ID), properties.capture());

        verify(loggerManager).createCommandLog(context, new LoggerItemChannel(CHANNEL_NAME, "Channel " +  CHANNEL_NAME + " was renamed to New Name"));
        verify(loggerManager).createCommandLog(context, new LoggerItemChannel("New Name", "Channel properties changed"));

        final Map<String, String> mutatedProperties = properties.getValue();
        assertThat(mutatedProperties, allOf(
                hasEntry(ChannelProperty.ID_NAME.getName(), "New Name"),
                hasEntry(SettingsProperties.RETRY_MEDIATOR.getName(), "42"),
                hasEntry(SettingsProperties.RETRY_NE.getName(), "24"),
                hasEntry(SettingsProperties.RETRY_INTERVAL.getName(), "12")
            ));

    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Test
    public void testPropertyChangeOnline() throws DcnManagerException, ConnectException {

        runPropertyChange(true);

        final ArgumentCaptor<Map> properties = ArgumentCaptor.forClass(Map.class);
        verify(connectionManager).updateChannelProperties(eq(ID), properties.capture());
        final Map<String, String> mutatedProperties = properties.getValue();
        assertThat(mutatedProperties, allOf(
                hasEntry("C", "CHANGE"),
                hasEntry(SettingsProperties.RETRY_MEDIATOR.getName(), "42"),
                hasEntry(SettingsProperties.RETRY_NE.getName(), "24"),
                hasEntry(SettingsProperties.RETRY_INTERVAL.getName(), "12")
            ));
    }

    @Test
    public void testPropertyChangeOffline() throws DcnManagerException {
        runPropertyChange(false);
        verifyZeroInteractions(connectionManager);
    }

    @Test
    public void testChannelSchedulingChange_limited() throws Exception {

        runPropertyChange(false, ImmutableMap.of(
                WellKnownChannelPropertyNames.CONCURRENT_ACTIVATIONS_LIMITED, "true",
                WellKnownChannelPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, "123"));

        verify(channelScheduling).setMaxOngoingChannelJobCount(CHANNEL_INSTANCE_ID, 123);
    }

    @Test
    public void testChannelSchedulingChange_unlimited() throws Exception {

        runPropertyChange(false, ImmutableMap.of(
                WellKnownChannelPropertyNames.CONCURRENT_ACTIVATIONS_LIMITED, "false"));

        verify(channelScheduling).setMaxOngoingChannelJobCount(CHANNEL_INSTANCE_ID, Integer.MAX_VALUE);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testPropertyChangeOnlineConnectionManagerError() throws DcnManagerException, ConnectException {

        doThrow(new ConnectException()).when(connectionManager).updateChannelProperties(eq(ID), any(Map.class));

        testPropertyChangeOnline();

        verify(loggerManager).createCommandLog(context, new LoggerItemChannel(CHANNEL_NAME,
                "Channel was active but updating the properties failed ID=" + ID));
    }

    @Test(expected=InvalidMutationException.class)
    public void testPropertyChangeInvalidMutationError() throws DcnManagerException {

        runPropertyChange(false, ImmutableMap.of(ChannelProperty.ID_NAME.getName(), "")); // empty names are not allowed

    }

    private void runPropertyChange(boolean online) throws DcnManagerException {
        final Map<String, String> mutatedProperties = runPropertyChange(online, ImmutableMap.of("A", "vA", "B", "vB", "C", "CHANGE"));

        assertThat(mutatedProperties.size(), is(1));
        assertThat(mutatedProperties, hasEntry("C", "CHANGE"));

        verify(loggerManager).createCommandLog(context, new LoggerItemChannel(CHANNEL_NAME, "Channel properties changed"));
    }

    private Map<String, String> runPropertyChange(boolean online, Map<String, String> properties)
            throws DcnManagerException {

        final ChannelPhysicalConnectionData phyConnState = new ChannelPhysicalConnectionBuilder()
            .setActivation(online ? ActualActivationState.ACTIVE : ActualActivationState.INACTIVE)
            .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, ID, VERSION);

        final ChannelConnectionData connState = new ChannelConnectionBuilder()
            .setActivation(online ? ActualActivationState.ACTIVE : ActualActivationState.INACTIVE)
            .build(ID, VERSION);

        final ChannelUserPreferencesData prefs = new ChannelUserPreferencesBuilder()
            .setReconnectInterval(600)
            .setName(CHANNEL_NAME)
            .setConcurrentActivationsLimited(true)
            .setConcurrentActivationsLimit(99)
            .setProperties(ImmutableMap.of("A", "vA", "B", "vB"))
            .build(ID, VERSION);

        entity = new ChannelEntity(state, null, prefs);
        when(repo.queryChannel(1)).thenReturn(Optional.of(entity));

        when(connectionRepo.query(ID)).thenReturn(Optional.of(connState));

        when(channelPhysicalConnectionRepository.queryAll(ID)).thenReturn(Collections.singleton(phyConnState));

        buildCommand(properties).call();

        final ArgumentCaptor<ChannelUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(ChannelUserPreferencesMutationDescriptor.class);
        final ArgumentCaptor<ChannelUserPreferencesMutationDescriptor> mutationNotif = ArgumentCaptor.forClass(ChannelUserPreferencesMutationDescriptor.class);

        verify(userPrefsRepo).tryUpdate(mutationRepo.capture());
        verify(notif).notifyChanges(mutationNotif.capture(), any(String.class));

        final ChannelUserPreferencesMutationDescriptor repoDescriptor = mutationRepo.getValue();
        final ChannelUserPreferencesMutationDescriptor notifDescriptor = mutationNotif.getValue();

        assertThat(repoDescriptor, is(notifDescriptor));
        final Map<String, String> mutatedProperties = repoDescriptor.getProperties();

        return mutatedProperties;
    }

    @Test
    public void testSameProperties() throws DcnManagerException {

        final ImmutableMap<String, String> properties = ImmutableMap.of("A", "vA", "B", "vB");
        final ChannelUserPreferencesData prefs = new ChannelUserPreferencesBuilder()
            .setReconnectInterval(600)
            .setName(CHANNEL_NAME)
            .setProperties(ImmutableMap.of("A", "vA", "B", "vB"))
            .build(ID, VERSION);

        entity = new ChannelEntity(state, null, prefs);
        when(repo.queryChannel(1)).thenReturn(Optional.of(entity));

        final UpdateChannelProperties<CallContext> cmd = buildCommand(properties);

        cmd.call();

        verify(userPrefsRepo, never()).tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, notif, connectionManager);
    }

    @Test
    public void testEmptyChangedProperties() throws DcnManagerException {

        final UpdateChannelProperties<CallContext> cmd = buildCommand(Collections.<String, String>emptyMap());

        cmd.call();

        verify(userPrefsRepo, never()).tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, notif, connectionManager);
    }

    @Test(expected=RepositoryException.class)
    public void testRepositoryErrorOnChannel() throws DcnManagerException {

        when(repo.queryChannel(anyInt())).thenThrow(new RepositoryException());

        buildCommand(Collections.<String, String>emptyMap()).call();
    }

    @Test(expected=UnknownChannelIdException.class)
    public void testInvalidChannelId() throws DcnManagerException {

        when(repo.queryChannel(anyInt())).thenReturn(Optional.<ChannelEntity>empty());

        final UpdateChannelProperties<CallContext> cmd = new UpdateChannelProperties<>(context,
                channelManagers, connectionManager, channelScheduling, staticConfig, settingsRepo, loggerManager,
                -1, Collections.<String, String>emptyMap());

        cmd.call();
    }

    @Test(expected=UnknownChannelTypeException.class)
    public void testInvalidChannelType() throws DcnManagerException {

        state = new ChannelInfoBuilder().setType("badType").build(ID, VERSION, 1);
        entity = new ChannelEntity(state, null, prefs);

        when(repo.queryChannel(1)).thenReturn(Optional.of(entity));

        final UpdateChannelProperties<CallContext> cmd = buildCommand(Collections.<String, String>emptyMap());

        cmd.call();
    }

    private UpdateChannelProperties<CallContext> buildCommand(Map<String, String> properties) {
        final UpdateChannelProperties<CallContext> cmd = new UpdateChannelProperties<>(context,
                channelManagers, connectionManager, channelScheduling, staticConfig, settingsRepo, loggerManager,
                ID, properties);
        return cmd;
    }

}
