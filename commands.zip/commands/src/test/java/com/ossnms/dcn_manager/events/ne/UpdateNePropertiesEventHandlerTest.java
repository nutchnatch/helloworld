package com.ossnms.dcn_manager.events.ne;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.commands.ne.NeTestBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.NePropertiesChangedEvent;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.properties.ne.NeProperty;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.UnitOfWorkImplBaseStub;
import com.ossnms.dcn_manager.core.test.UowMutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class UpdateNePropertiesEventHandlerTest extends NeTestBase {

    private static final int ID = 1, VERSION = 1;
    private static final int PHYSICAL_ID = 10;
    private static final int PHYSICAL_CHANNEL_ID = 20;

    private NeType type;

    private NeEntity entity;
    private NeInfoData state;
    private NeUserPreferencesData prefs;
    private SystemRepository systemRepository;
    private DomainNotifications domainNotifications;

    private NetworkElementInteractionManager neInteraction;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        type = MockFactory.mockNeType();

        domainNotifications = mock(DomainNotifications.class);

        neInteraction = mock(NetworkElementInteractionManager.class);

        systemRepository = mock(SystemRepository.class);

        state = new NeInfoData.NeInfoBuilder()
            .setProxyType("neType")
            .build(ID, 1, VERSION);
        prefs = new NeUserPreferencesBuilder()
            .setName("neName")
            .build(ID, VERSION);

        entity = new NeEntity(null, null, state, null, prefs);

        when(type.getProtocol()).thenReturn("TL1");
        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.<String>empty());
        when(neTypes.get("neType")).thenReturn(type);
        when(systemRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(routesRepo.queryRoutes(ID)).thenReturn(Collections.<NeGatewayRouteData>emptyList());

        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));
        when(neRepo.unitOfWork(any())).then(invocation -> new UnitOfWorkImplBaseStub<>(invocation.getArguments()[0]));

        when(operationRepo.tryUpdate(isA(UowContext.class), any(NeOperationMutationDescriptor.class))).then(new UowMutationAnswer<>());

        when(domainRepo.queryAllForNE(anyInt())).thenReturn(Collections.<DomainInfoData>emptyList());
        when(domainRepo.queryTransitiveDomainsForNE(anyInt())).thenReturn(Collections.<DomainInfoData>emptyList());
        when(domainRepo.queryNaturalDomainsForNE(anyInt())).thenReturn(Collections.<DomainInfoData>emptyList());
    }

    @Test
    public void testPropertyChangeInvalidMutationError() throws DcnManagerException {

        runPropertyChange(false, ImmutableMap.of(NeProperty.RECONNECT_INTERVAL.getName(), "blah blah")); // should be an integer

        // does not throw on error

        verify(preferencesRepo, never()).tryUpdate(isA(UowContext.class), any(NeUserPreferencesMutationDescriptor.class));
        verify(notif, never()).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void testPrivatePropertiesIgnored() throws DcnManagerException {

        runPropertyChange(false, ImmutableMap.of(NeProperty.ID_NAME.getName(), "")); // NE ID Name is a private property

        // does not throw, just ignores

        verify(preferencesRepo, never()).tryUpdate(isA(UowContext.class), any(NeUserPreferencesMutationDescriptor.class));
        verify(notif, never()).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testPropertyChangeOnline() throws DcnManagerException, ConnectException {

        verifyPropertyChange(true);

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> properties = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(preferencesRepo).tryUpdate(isA(UowContext.class), properties.capture());
        final Map<String, String> mutatedProperties = properties.getValue().getProperties();
        assertThat(mutatedProperties, allOf(
                hasEntry("C", "CHANGE")
            ));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testPropertyChangeOffline() throws DcnManagerException, ConnectException {

        verifyPropertyChange(false);

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> properties = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(preferencesRepo).tryUpdate(isA(UowContext.class), properties.capture());
        final Map<String, String> mutatedProperties = properties.getValue().getProperties();
        assertThat(mutatedProperties, allOf(
                hasEntry("C", "CHANGE")
        ));
    }

    private void verifyPropertyChange(boolean online) throws DcnManagerException {
        final Map<String, String> mutatedProperties = verifyPropertyChange(
            online,
            new HashMap<>(ImmutableMap.of("A", "vA", "B", "vB", "C", "CHANGE")));

        assertThat(mutatedProperties.size(), is(1));
        assertThat(mutatedProperties, hasEntry("C", "CHANGE"));
    }

    @SuppressWarnings("unchecked")
    private Map<String, String> verifyPropertyChange(boolean online, Map<String, String> properties)
            throws DcnManagerException {

        when(preferencesRepo.tryUpdate(isA(UowContext.class), any(NeUserPreferencesMutationDescriptor.class))).then(new UowMutationAnswer<>());

        runPropertyChange(online, properties);

        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationRepo = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationNotif = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        verify(preferencesRepo).tryUpdate(isA(UowContext.class), mutationRepo.capture());
        verify(loggerManager).createCommandLog(context, new LoggerItemNe("ne", "NE properties changed", ID));
        verify(notif).notifyChanges(mutationNotif.capture());

        verify(neInteraction, times(online ? 1 : 0)).onNePropertiesUpdated(
                isA(NeEntity.class), isA(NePhysicalConnectionData.class),
                isA(NeUserPreferencesMutationDescriptor.class));

        final NeUserPreferencesMutationDescriptor repoDescriptor = mutationRepo.getValue();
        final NeUserPreferencesMutationDescriptor notifDescriptor = mutationNotif.getValue();

        assertThat(repoDescriptor, is(notifDescriptor));

        return repoDescriptor.getProperties();
    }

    private void runPropertyChange(boolean online, Map<String, String> properties)
            throws RepositoryException {
        final NeConnectionData connState = new NeConnectionData.NeConnectionBuilder()
            .setActivationState(online ? ActualActivationState.INITIALIZED : ActualActivationState.DISCONNECTED)
            .build(ID, VERSION);
        final NePhysicalConnectionData phyState = new NePhysicalConnectionData.NePhysicalConnectionBuilder()
            .setActivationState(online ? ActualActivationState.INITIALIZED : ActualActivationState.DISCONNECTED)
            .build(PHYSICAL_ID, ID, PHYSICAL_CHANNEL_ID, VERSION);

        final NeUserPreferencesData prefs = new NeUserPreferencesBuilder()
                    .setName("ne")
                    .setProperty("A", "vA")
                    .setProperty("B", "vB")
                    .build(ID, VERSION);

        entity = new NeEntity(
                connState,
                new NeOperationBuilder().build(ID, VERSION),
                state,
                new NeSynchronizationData.NeSynchronizationBuilder().build(ID, VERSION),
                prefs);

        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));
        when(neInstanceRepo.queryAll(ID)).thenReturn(Collections.singleton(phyState));

        buildCommand()
            .call(new NePropertiesChangedEvent(ID, ImmutableMap.copyOf(properties)));
    }

    @Test
    public void testSameProperties() throws DcnManagerException {

        final Map<String, String> properties = new HashMap<>(ImmutableMap.of("A", "vA", "B", "vB"));
        final NeUserPreferencesData prefs = new NeUserPreferencesBuilder()
                    .setName("ne")
                    .setProperty("A", "vA")
                    .setProperty("B", "vB")
                    .build(ID, VERSION);

        entity = new NeEntity(null, null, state, null, prefs);
        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));

        buildCommand()
            .call(new NePropertiesChangedEvent(ID, ImmutableMap.copyOf(properties)));

        verify(preferencesRepo, never()).tryUpdate(isA(UowContext.class), any(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, notif);
    }

    @Test
    public void testEmptyChangedProperties() throws DcnManagerException {

        buildCommand()
            .call(new NePropertiesChangedEvent(ID, ImmutableMap.<String, String>of()));

        verify(preferencesRepo, never()).tryUpdate(isA(UowContext.class), any(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(loggerManager, notif);
    }

    @Test
    public void testRepositoryErrorOnNe() throws DcnManagerException {

        when(neRepo.queryNe(anyInt())).thenThrow(new RepositoryException());

        buildCommand()
            .call(new NePropertiesChangedEvent(ID, ImmutableMap.<String, String>of()));

        // does not throw on error
    }

    @Test
    public void testInvalidNeId() throws DcnManagerException {

        when(neRepo.queryNe(anyInt())).thenReturn(Optional.<NeEntity>empty());

        buildCommand()
            .call(new NePropertiesChangedEvent(-1, ImmutableMap.<String, String>of()));

        // does not throw on error
    }

    @Test
    public void testInvalidNeType() throws DcnManagerException {

        state = new NeInfoData.NeInfoBuilder()
            .setProxyType("badType")
            .build(ID, 1, VERSION);

        entity = new NeEntity(null, null, state, null, prefs);
        when(neRepo.queryNe(ID)).thenReturn(Optional.of(entity));

        buildCommand()
            .call(new NePropertiesChangedEvent(ID, ImmutableMap.<String, String>of()));

        // does not throw on error
    }

    private UpdateNePropertiesEventHandler<CallContext> buildCommand() {
        final UpdateNePropertiesEventHandler<CallContext> handler
            = new UpdateNePropertiesEventHandler<>(context,
                new NetworkElementManagers(neRepo, neInstanceRepo, neInteraction, notif, null),
                staticConfig, loggerManager, domainRepo, domainNotifications, systemRepository, settingsRepository);
        return handler;
    }

}
