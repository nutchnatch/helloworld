package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeConnectionDescriptionChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializedEvent;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.OutboundException;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class NeInitializedEventHandlerTest {

    private static final int NE_ID = 1;
    private static final int NE_INSTANCE_ID = 1000;

    private NeInformationRetrieval informationRetrieval;
    private NeEntityRepository repository;
    private NeConnectionRepository connectionRepo;
    private NetworkElementNotifications notifications;
    private Alarms alarms;
    private CallContext context;

    @Before
    public void setUp() throws DcnManagerException {
        final NeGatewayRoutesRepository routesRepo = mock(NeGatewayRoutesRepository.class);

        informationRetrieval = mock(NeInformationRetrieval.class);
        repository = mock(NeEntityRepository.class);
        connectionRepo = mock(NeConnectionRepository.class);
        notifications = mock(NetworkElementNotifications.class);
        alarms = mock(Alarms.class);
        context = mock(CallContext.class);

        final NeType type = MockFactory.mockNeType();
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(1, type);
        createDescriptor.getConnection().setActivationState(ActualActivationState.CONNECTED);
        createDescriptor.getPreferences().setName("type_name_99");
        final NeEntity entity = NeEntity.build(NE_ID, 0, createDescriptor);

        when(informationRetrieval.updateNeDataFromMediator(anyInt())).thenReturn(entity);

        when(repository.getNeGatewayRoutesRepository()).thenReturn(routesRepo);
        when(repository.getNeConnectionRepository()).thenReturn(connectionRepo);
        when(routesRepo.queryRoutes(anyInt())).thenReturn(Collections.emptyList());
        when(connectionRepo.tryUpdate(any(NeConnectionMutationDescriptor.class))).then(new MutationAnswer<>());
    }

    @Test
    public void initializedEvent() throws DcnManagerException {
        final ArgumentCaptor<NeConnectionMutationDescriptor> connectionCaptor = ArgumentCaptor.forClass(NeConnectionMutationDescriptor.class);
        final NeInitializedEvent event = new NeInitializedEvent(NE_ID,
                new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(connectionRepo.query(anyInt())).thenReturn(Optional.of(
                new NeConnectionBuilder()
                    .setActivationState(ActualActivationState.INITIALIZING)
                    .build(NE_ID, 1)));

        new NeInitializedEventHandler<>(context, repository, notifications, informationRetrieval, alarms)
            .handleEvent(event);

        verify(informationRetrieval).updateNeDataFromMediator(NE_INSTANCE_ID);
        verify(connectionRepo).tryUpdate(connectionCaptor.capture());
        assertThat(connectionCaptor.getValue().getActivationState().get(), is(ActualActivationState.INITIALIZED));

        verify(notifications).notifyChanges(new NeInitializedEvent(NE_ID));
        verify(notifications).notifyChanges(isA(NeConnectionDescriptionChangedEvent.class));

        verifyZeroInteractions(alarms);
    }

    @Test
    public void initializedEvent_withSynchronizationCountersDifferences_propagates() throws DcnManagerException {

        final NeSynchronizationData differences = new NeSynchronizationBuilder()
                .build(NE_ID, 0);

        final NeInitializedEvent event = new NeInitializedEvent(NE_ID,
                new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, true), differences);

        when(connectionRepo.query(anyInt())).thenReturn(Optional.of(
                new NeConnectionBuilder()
                        .setActivationState(ActualActivationState.INITIALIZING)
                        .build(NE_ID, 1)));

        new NeInitializedEventHandler<>(context, repository, notifications, informationRetrieval, alarms)
                .handleEvent(event);

        final ArgumentCaptor<NeConnectionMutationDescriptor> connectionCaptor = ArgumentCaptor.forClass(NeConnectionMutationDescriptor.class);

        verify(informationRetrieval).updateNeDataFromMediator(NE_INSTANCE_ID);

        verify(connectionRepo).tryUpdate(connectionCaptor.capture());
        assertThat(connectionCaptor.getValue().getActivationState().get(), is(ActualActivationState.INITIALIZED));

        verify(notifications).notifyChanges(new NeInitializedEvent(NE_ID, differences));
        verify(notifications).notifyChanges(isA(NeConnectionDescriptionChangedEvent.class));

        verifyZeroInteractions(alarms);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void initializedEvent_errorUpdatingData_setsFailed() throws DcnManagerException {
        final ArgumentCaptor<NeConnectionMutationDescriptor> connectionCaptor = ArgumentCaptor.forClass(NeConnectionMutationDescriptor.class);
        final NeInitializedEvent event = new NeInitializedEvent(NE_ID,
                new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(connectionRepo.query(anyInt())).thenReturn(Optional.of(
                new NeConnectionBuilder()
                    .setActivationState(ActualActivationState.INITIALIZING)
                    .build(NE_ID, 1)));

        doThrow(new OutboundException()).when(informationRetrieval).updateNeDataFromMediator(anyInt());

        new NeInitializedEventHandler<>(context, repository, notifications, informationRetrieval, alarms)
            .handleEvent(event);

        verify(informationRetrieval).updateNeDataFromMediator(NE_INSTANCE_ID);
        verify(connectionRepo).tryUpdate(connectionCaptor.capture());
        assertThat(connectionCaptor.getValue().getActivationState().get(), is(ActualActivationState.FAILED));

        verify(alarms).raiseConnectionLost(eq(NE_ID), any(Optional.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void initializedEvent_concurrencyErrorUpdatingData_finiteRetries_thenSetsFailed() throws DcnManagerException {
        final ArgumentCaptor<NeConnectionMutationDescriptor> connectionCaptor = ArgumentCaptor.forClass(NeConnectionMutationDescriptor.class);
        final NeInitializedEvent event = new NeInitializedEvent(NE_ID,
                new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(connectionRepo.query(anyInt())).thenReturn(Optional.of(
                new NeConnectionBuilder()
                        .setActivationState(ActualActivationState.INITIALIZING)
                        .build(NE_ID, 1)));

        doThrow(new DataUpdateException()).when(informationRetrieval).updateNeDataFromMediator(anyInt());

        new NeInitializedEventHandler<>(context, repository, notifications, informationRetrieval, alarms)
                .handleEvent(event);

        verify(informationRetrieval, atLeast(3)).updateNeDataFromMediator(NE_INSTANCE_ID);

        verify(connectionRepo).tryUpdate(connectionCaptor.capture());
        assertThat(connectionCaptor.getValue().getActivationState().get(), is(ActualActivationState.FAILED));

        verify(alarms).raiseConnectionLost(eq(NE_ID), any(Optional.class));
    }

    @Test
    public void initializedEvent_alreadyInitialized_noOp() throws DcnManagerException {
        final NeInitializedEvent event = new NeInitializedEvent(NE_ID,
                new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, true));

        when(connectionRepo.query(anyInt())).thenReturn(Optional.of(
                new NeConnectionBuilder()
                    .setActivationState(ActualActivationState.INITIALIZED)
                    .build(NE_ID, 1)));

        new NeInitializedEventHandler<>(context, repository, notifications, informationRetrieval, alarms)
            .handleEvent(event);

        verify(informationRetrieval).updateNeDataFromMediator(NE_INSTANCE_ID);
        verify(connectionRepo, never()).tryUpdate(any(NeConnectionMutationDescriptor.class));

        verifyZeroInteractions(alarms);
    }

    @Test
    public void initializedEvent_badNeId_noOp() throws DcnManagerException {
        final NeInitializedEvent event = new NeInitializedEvent(NE_ID);

        when(connectionRepo.query(anyInt())).thenReturn(Optional.empty());

        new NeInitializedEventHandler<>(context, repository, notifications, informationRetrieval, alarms)
            .handleEvent(event);

        verify(informationRetrieval, never()).updateNeDataFromMediator(NE_ID);
        verify(connectionRepo, never()).tryUpdate(any(NeConnectionMutationDescriptor.class));

        verifyZeroInteractions(alarms);
    }

}
