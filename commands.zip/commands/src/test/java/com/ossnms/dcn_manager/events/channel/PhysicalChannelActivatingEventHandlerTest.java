package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatingEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PhysicalChannelActivatingEventHandlerTest {

    private static final int CHANNEL_ID = 42;
    private static final int VERSION = 1;
    private static final int CHANNEL_INSTANCE_ID = 4200;
    private static final int MEDIATOR_INSTANCE_ID = 1000;

    private PhysicalChannelActivatingEventHandler<CallContext> handler;
    private CallContext context;
    private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    private ChannelEntityRepository entityRepository;
    private ChannelNotifications notifications;
    private ChannelInteractionManager activationManager;
    private MessageSource<ChannelEvent> channelEvents;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);
        entityRepository = mock(ChannelEntityRepository.class);
        notifications = mock(ChannelNotifications.class);
        activationManager = mock(ChannelInteractionManager.class);
        channelEvents = mock(MessageSource.class);

        handler = new PhysicalChannelActivatingEventHandler<>(context,
                new ChannelManagers(entityRepository, channelPhysicalConnectionRepository, notifications, activationManager, channelEvents));
    }

    @Test
    public void event_onInactiveChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.INACTIVE);
    }

    @Test
    public void event_onStartingUpChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.STARTINGUP);
    }

    @Test
    public void event_onFailedChannel() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
            .setActivation(ActualActivationState.FAILED)
            .setAdditionalInfo("")
            .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalChannelActivatingEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        final ArgumentCaptor<ChannelPhysicalConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(ChannelPhysicalConnectionMutationDescriptor.class);
        verify(channelPhysicalConnectionRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(CHANNEL_INSTANCE_ID));
        assertThat(captor.getValue().getActualActivationState().get(), is(ActualActivationState.ACTIVATING));
    }

    @Test
    public void event_channelNotFound() throws RepositoryException {
        when(channelPhysicalConnectionRepository.query(CHANNEL_ID)).thenReturn(Optional.empty());

        handler.call(new PhysicalChannelActivatingEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        verify(channelPhysicalConnectionRepository, never()).tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void event_onActiveChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.ACTIVE);
    }

    private void verifyNoActionOnState(ActualActivationState activationState) throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
            .setActivation(activationState)
            .setAdditionalInfo("")
            .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));

        handler.call(new PhysicalChannelActivatingEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        verify(channelPhysicalConnectionRepository, never()).tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class));
    }

}
