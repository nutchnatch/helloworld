package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicInitializationVerificationEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.CollQueryAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;

import java.time.Instant;
import java.util.Optional;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class NeInitializationTimeoutVerificationEventHandlerTest {

    private NePhysicalConnectionRepository neInstanceRepository;
    private NeUserPreferencesRepository nePreferencesRepository;
    private MessageSource<NeEvent> neEvents;

    private NeInitializationTimeoutVerificationEventHandler<CallContext> handler;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws Exception {

        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        nePreferencesRepository = mock(NeUserPreferencesRepository.class);
        neEvents = mock(MessageSource.class);

        final NeEntityRepository repo = mock(NeEntityRepository.class);
        when(repo.getNeUserPreferencesRepository()).thenReturn(nePreferencesRepository);

        final NetworkElementManagers managers = new NetworkElementManagers(repo, neInstanceRepository, null, null, neEvents);

        final CallContext ctx = mock(CallContext.class);

        handler = new NeInitializationTimeoutVerificationEventHandler<>(ctx, managers);
    }

    @Test
    public void timeoutElapsed_emitsFailureEvent() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MIN))
                        .setActivationState(ActualActivationState.INITIALIZING)
                        .build(1, 1, 1, 0)
        ));

        when(nePreferencesRepository.query(1)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder()
                        .setReconnectInterval(1)
                        .setName("ne")
                        .build(1, 0)
        ));

        handler.call(new PeriodicInitializationVerificationEvent());

        verify(neEvents).push(new PhysicalNeActivationFailedEvent(1, 1, false, Message.NE_INIT_TIMEOUT.toString()));
    }

    @Test
    public void noNetworkElements_doesNothing() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>());

        handler.call(new PeriodicInitializationVerificationEvent());

        verifyZeroInteractions(neEvents);
    }

    @Test
    public void noInitializingNetworkElements_doesNothing() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.DISCONNECTED)
                        .build(1, 1, 1, 0),
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.CONNECTED)
                        .build(2, 2, 1, 0),
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.FAILED)
                        .build(3, 3, 1, 0),
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.STARTUP)
                        .build(4, 4, 1, 0),
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.SHUTDOWN)
                        .build(5, 5, 1, 0),
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.CONNECTING)
                        .build(6, 6, 1, 0),
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.DISCONNECTING)
                        .build(7, 7, 1, 0),
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.INITIALIZED)
                        .build(8, 8, 1, 0)
        ));

        handler.call(new PeriodicInitializationVerificationEvent());

        verifyZeroInteractions(neEvents);
    }

    @Test
    public void noTimeoutConfigured_doesNothing() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MIN))
                        .setActivationState(ActualActivationState.INITIALIZING)
                        .build(1, 1, 1, 0)
        ));

        when(nePreferencesRepository.query(1)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder()
                        .setReconnectInterval(0)
                        .setName("ne")
                        .build(1, 0)
        ));

        handler.call(new PeriodicInitializationVerificationEvent());

        verifyZeroInteractions(neEvents);
    }

    @Test
    public void timeoutNotElapsed_doesNothing() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MAX))
                        .setActivationState(ActualActivationState.INITIALIZING)
                        .build(1, 1, 1, 0)
        ));

        when(nePreferencesRepository.query(1)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder()
                        .setReconnectInterval(1)
                        .setName("ne")
                        .build(1, 0)
        ));

        handler.call(new PeriodicInitializationVerificationEvent());

        verifyZeroInteractions(neEvents);
    }

    @Test
    public void preferencesRepoError_doesNothing() throws Exception {

        when(neInstanceRepository.query(any())).then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                        .setInitStartTime(Optional.of(Instant.MIN))
                        .setActivationState(ActualActivationState.INITIALIZING)
                        .build(1, 1, 1, 0)
        ));

        when(nePreferencesRepository.query(1)).thenThrow(new RepositoryException());

        handler.call(new PeriodicInitializationVerificationEvent());

        verifyZeroInteractions(neEvents);
    }
}