package com.ossnms.dcn_manager.commands.ne.internal;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.NeAccessControlManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.exception.AccessControlException;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesInitialData;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Optional;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class WriteAccessReleaseTest {
    
    private static final Integer NE_ID = 1;
    private static final String NE_NAME = "ne_name";
    
    private CallContext context;
    private LoggerManager<CallContext> loggerManager;
    private NeEntityRepository repository;
    private NeEntityRepository.NeUserPreferencesRepository userPreferencesRepository;
    private NeAccessControlManager<CallContext> accessControlManager;
    
    private NeUserPreferencesData neUserData;
    private WriteAccessRelease<CallContext> writeAccessRelease;
    
    @Before
    @SuppressWarnings("unchecked")
    public void setup() throws RepositoryException {
        context = mock(CallContext.class);
        loggerManager= mock(LoggerManager.class);
        repository = mock(NeEntityRepository.class);
        accessControlManager = mock(NeAccessControlManager.class);
        userPreferencesRepository = mock(NeEntityRepository.NeUserPreferencesRepository.class);
        
        neUserData = new NeUserPreferencesData(NE_ID, 1, new NeUserPreferencesInitialData().setName(NE_NAME));
        
        when(repository.getNeUserPreferencesRepository()).thenReturn(userPreferencesRepository);
        when(userPreferencesRepository.query(NE_ID)).thenReturn(Optional.of(neUserData));
        
        writeAccessRelease = new WriteAccessRelease<CallContext>(context, accessControlManager, repository, loggerManager, NE_ID);
    }
    
    @Test
    public void testCall() throws RepositoryException, AccessControlException, CommandException {
        writeAccessRelease.call();
        
        verify(userPreferencesRepository, times(1)).query(NE_ID);
        verify(accessControlManager, times(1)).releaseWriteAccess(context, NE_ID);
        verify(loggerManager, times(1)).createCommandLog(Mockito.any(CallContext.class), Mockito.any(LoggerItemNe.class));
    }
    
    @Test(expected=RepositoryException.class)
    public void testCall_error_repository() throws RepositoryException, AccessControlException, CommandException {
        doThrow(RepositoryException.class).when(userPreferencesRepository).query(NE_ID);
        
        writeAccessRelease.call();
        
        verify(userPreferencesRepository, times(0)).query(NE_ID);
        verify(accessControlManager, Mockito.never()).releaseWriteAccess(context, NE_ID);
        verify(loggerManager, Mockito.never()).createCommandLog(Mockito.any(CallContext.class), Mockito.any(LoggerItemNe.class));
    }
    
    @Test(expected=CommandException.class)
    public void testCall_error_not_found_Ne() throws RepositoryException, AccessControlException, CommandException {
        when(userPreferencesRepository.query(NE_ID)).thenReturn(Optional.<NeUserPreferencesData>empty());
        
        writeAccessRelease.call();
        
        verify(userPreferencesRepository, times(1)).query(NE_ID);
        verify(accessControlManager, Mockito.never()).requestWriteAccess(context, NE_ID);
        verify(loggerManager, Mockito.never()).createCommandLog(Mockito.any(CallContext.class), Mockito.any(LoggerItemNe.class));
    }
    
    @Test
    public void testCall_error__setToActiveMode() throws RepositoryException, AccessControlException, CommandException {
        doThrow(AccessControlException.class).when(accessControlManager).releaseWriteAccess(context, NE_ID);
        
        writeAccessRelease.call();
        
        verify(userPreferencesRepository, times(1)).query(NE_ID);
        verify(accessControlManager, times(1)).releaseWriteAccess(context, NE_ID);
        verify(loggerManager, times(1)).createCommandLog(Mockito.any(CallContext.class), Mockito.any(LoggerItemNe.class));
    }
}
