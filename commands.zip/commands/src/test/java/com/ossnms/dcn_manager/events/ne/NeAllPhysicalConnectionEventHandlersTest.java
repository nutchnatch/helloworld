package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.metrics.NeInitializationMetrics;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeStartingUpEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.*;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeSynchronizationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.isA;
import static org.mockito.Mockito.*;

public class NeAllPhysicalConnectionEventHandlersTest {

    private static final int CHANNEL_ID = 2;
    private static final int NE_ID = 1;
    private static final int NE_INSTANCE_ID = 1000;
    private static final int CHANNEL_INSTANCE_ID = 2000;
    private static final int MEDIATOR_INSTANCE_ID = 3000;

    private CallContext ctx;
    private NetworkElementInteractionManager activationManager;
    private NePhysicalConnectionRepository neInstanceRepository;
    private NePhysicalConnectionBehavior behavior;
    private NetworkElementNotifications notifications;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;
    private NeSynchronizationRepository synchronizationRepository;
    private NeEntityRepository.NeUserPreferencesRepository preferencesRepository;

    private NetworkElementManagers neManagers;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws DcnManagerException {
        final NeEntityRepository neRepository = mock(NeEntityRepository.class);
        final MessageSource<NeEvent> neEvents = mock(MessageSource.class);

        ctx = mock(CallContext.class);
        behavior = mock(NePhysicalConnectionBehavior.class);
        notifications = mock(NetworkElementNotifications.class);
        activationManager = mock(NetworkElementInteractionManager.class);
        neInstanceRepository = mock(NePhysicalConnectionRepository.class);
        channelInstanceRepository = mock(ChannelPhysicalConnectionRepository.class);
        synchronizationRepository = mock(NeSynchronizationRepository.class);
        preferencesRepository = mock(NeEntityRepository.NeUserPreferencesRepository.class);

        when(neRepository.getNeSynchronizationRepository()).thenReturn(synchronizationRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);
        
        neManagers = new NetworkElementManagers(neRepository, neInstanceRepository, activationManager, notifications, neEvents);
    }

    @Test
    public void activationFailed() {
        final PhysicalNeActivationFailedEvent event = new PhysicalNeActivationFailedEvent(NE_INSTANCE_ID, NE_ID, false);

        new PhysicalNeActivationFailedEventHandler<>(ctx, neManagers)
            .produceMutation(event, behavior, neManagers);

        verify(behavior).setFailed(event.getDetailedDescription(), activationManager);
    }

    @Test
    public void synchronizationLostEvent() throws Exception {
        final PhysicalNeSynchronizationLostEvent event = new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, false);

        NePhysicalConnectionData physicalConnection = new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);
        NePhysicalConnectionMutationDescriptor mutation = new NePhysicalConnectionMutationDescriptor(physicalConnection);
        
        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                physicalConnection));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0)));
        when(synchronizationRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.empty());
        when(behavior.resynchronize(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(mutation));
        
        new PhysicalNeSynchronizationLostEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .produceMutation(event, behavior, neManagers);

        verify(behavior).resynchronize(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID);
    }

    @Test
    public void synchronizationLostEventWithCounters_hasDifferences() throws Exception {
        final PhysicalNeSynchronizationLostEvent event = new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, false,
                new NeSynchronizationBuilder().setAll(Optional.of(10L)).setAlarms(Optional.of(20L)).setPacket(Optional.of(30L)).build(NE_ID, 0));

        NePhysicalConnectionData physicalConnection = new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);
        NePhysicalConnectionMutationDescriptor mutation = new NePhysicalConnectionMutationDescriptor(physicalConnection);
        
        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                physicalConnection));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0)));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(new NeSynchronizationBuilder().setAll(Optional.of(10L)).setAlarms(Optional.of(1L)).setPacket(Optional.of(1L)).build(NE_ID, 0)));
        when(behavior.resynchronize(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(mutation));
        
        Optional<NePhysicalConnectionMutationDescriptor> producedMutation = new PhysicalNeSynchronizationLostEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .produceMutation(event, behavior, neManagers);

        verify(behavior).resynchronize(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID);
        assertThat(producedMutation.get().getActivationMode(), is(Optional.of(ActualActivationMode.CONNECT_RECOVER)));
    }


    @Test
    public void synchronizationLostEventWithCounters_hasNoDifferences() throws Exception {
        final PhysicalNeSynchronizationLostEvent event = new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, false,
                new NeSynchronizationBuilder().setAll(Optional.of(10L)).setAlarms(Optional.of(20L)).setPacket(Optional.of(30L)).build(NE_ID, 0));

        NePhysicalConnectionData physicalConnection = new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);
        NePhysicalConnectionMutationDescriptor mutation = new NePhysicalConnectionMutationDescriptor(physicalConnection);
        
        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                physicalConnection));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0)));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(new NeSynchronizationBuilder().setAll(Optional.of(10L)).setAlarms(Optional.of(20L)).setPacket(Optional.of(30L)).build(NE_ID, 0)));
        when(behavior.resynchronize(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(mutation));
        
        Optional<NePhysicalConnectionMutationDescriptor> producedMutation = new PhysicalNeSynchronizationLostEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .produceMutation(event, behavior, neManagers);

        verify(behavior).resynchronize(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID);
        assertThat(producedMutation.get().getActivationMode(), is(Optional.of(ActualActivationMode.CONNECT_RECOVER)));
    }


    @Test
    public void synchronizationLostEventWithCounters_allDifferent() throws Exception {
        final PhysicalNeSynchronizationLostEvent event = new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, false,
                new NeSynchronizationBuilder().setAll(Optional.of(10L)).setAlarms(Optional.of(20L)).setPacket(Optional.of(30L)).build(NE_ID, 0));

        NePhysicalConnectionData physicalConnection = new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);
        NePhysicalConnectionMutationDescriptor mutation = new NePhysicalConnectionMutationDescriptor(physicalConnection);
        
        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                physicalConnection));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0)));
        when(synchronizationRepository.query(NE_ID)).thenReturn(Optional.of(new NeSynchronizationBuilder().setAll(Optional.of(1L)).setAlarms(Optional.of(1L)).setPacket(Optional.of(1L)).build(NE_ID, 0)));
        when(behavior.resynchronize(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(mutation));
        
        Optional<NePhysicalConnectionMutationDescriptor> producedMutation = new PhysicalNeSynchronizationLostEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .produceMutation(event, behavior, neManagers);

        verify(behavior).resynchronize(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID);
        assertThat(producedMutation.get().getActivationMode(), not(is(Optional.of(ActualActivationMode.CONNECT_RECOVER))));
    }


    @Test
    public void synchronizationLostEvent_neNotFound_doesNothing() throws Exception {
        final PhysicalNeSynchronizationLostEvent event = new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.empty());

        new PhysicalNeSynchronizationLostEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .produceMutation(event, behavior, neManagers);

        verifyZeroInteractions(behavior);
    }

    @Test
    public void synchronizationLostEvent_channelNotFound_doesNothing() throws Exception {
        final PhysicalNeSynchronizationLostEvent event = new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0)));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        new PhysicalNeSynchronizationLostEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .produceMutation(event, behavior, neManagers);

        verifyZeroInteractions(behavior);
    }

    @Test
    public void synchronizationLostEvent_neInstanceInfoRepoError_doesNothing() throws Exception {
        final PhysicalNeSynchronizationLostEvent event = new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenThrow(new RepositoryException());

        new PhysicalNeSynchronizationLostEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .produceMutation(event, behavior, neManagers);

        verifyZeroInteractions(behavior);
    }

    @Test
    public void synchronizationLostEvent_channelInstanceInfoRepoError_doesNothing() throws Exception {
        final PhysicalNeSynchronizationLostEvent event = new PhysicalNeSynchronizationLostEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0)));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenThrow(new RepositoryException());

        new PhysicalNeSynchronizationLostEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .produceMutation(event, behavior, neManagers);

        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectedEvent() throws Exception {
        final PhysicalNeConnectedEvent event = new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(new NePhysicalConnectionBuilder().build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0)));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0)));

        new PhysicalNeConnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
            .produceMutation(event, behavior, neManagers);

        verify(behavior).setConnected(activationManager, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID);
    }

    @Test
    public void connectedEvent_neNotFound_doesNothing() throws Exception {
        final PhysicalNeConnectedEvent event = new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.empty());

        new PhysicalNeConnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
        .produceMutation(event, behavior, neManagers);

        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectedEvent_channelNotFound_doesNothing() throws Exception {
        final PhysicalNeConnectedEvent event = new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(new NePhysicalConnectionBuilder().build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0)));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        new PhysicalNeConnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
            .produceMutation(event, behavior, neManagers);

        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectedEvent_neInstanceInfoRepoError_doesNothing() throws Exception {
        final PhysicalNeConnectedEvent event = new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenThrow(new RepositoryException());

        new PhysicalNeConnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
            .produceMutation(event, behavior, neManagers);

        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectedEvent_channelInstanceInfoRepoError_doesNothing() throws Exception {
        final PhysicalNeConnectedEvent event = new PhysicalNeConnectedEvent(NE_INSTANCE_ID, NE_ID, false);

        when(neInstanceRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(new NePhysicalConnectionBuilder().build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0)));
        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenThrow(new RepositoryException());

        new PhysicalNeConnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
            .produceMutation(event, behavior, neManagers);

        verifyZeroInteractions(behavior);
    }

    @Test
    public void connectingEvent() {
        final PhysicalNeConnectingEvent event = new PhysicalNeConnectingEvent(NE_INSTANCE_ID, NE_ID, false);

        new PhysicalNeConnectingEventHandler<>(ctx, neManagers)
            .produceMutation(event, behavior, neManagers);

        verify(behavior).setConnecting();
    }

    @Test
    public void disconnectedEvent() {
        final PhysicalNeDisconnectedEvent event = new PhysicalNeDisconnectedEvent(NE_INSTANCE_ID, NE_ID, false);

        new PhysicalNeDisconnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
            .produceMutation(event, behavior, neManagers);

        verify(behavior).setDisconnected(activationManager);
    }

    @Test
    public void disconnectedEvent_restartNotRequested_doesNothingAfterProcessing() throws RepositoryException {

        final NePhysicalConnectionData disconnected = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActive(true)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);

        new PhysicalNeDisconnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .onMutationApplied(disconnected, behavior, neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));
        verify(notifications, never()).notifyChanges(isA(NeStartingUpEvent.class));
    }

    @Test
    public void disconnectedEvent_restartAfterProcessing() throws RepositoryException {

        final ChannelPhysicalConnectionData channel = new ChannelPhysicalConnectionBuilder()
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0);

        final NePhysicalConnectionData disconnected = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActivationMode(ActualActivationMode.RESTART)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channel));
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        new PhysicalNeDisconnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .onMutationApplied(disconnected, behavior, neManagers);

        verify(activationManager).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, false));
        verify(notifications).notifyChanges(isA(NeStartingUpEvent.class));
    }

    @Test
    public void disconnectedEvent_restartAfterProcessing_channelNotFound_doesNothing() throws RepositoryException {

        final NePhysicalConnectionData disconnected = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActivationMode(ActualActivationMode.RESTART)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        new PhysicalNeDisconnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .onMutationApplied(disconnected, behavior, neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, false));
        verify(notifications, never()).notifyChanges(isA(NeStartingUpEvent.class));
    }

    @Test
    public void disconnectedEvent_restartAfterProcessing_channelRepoError_doesNothing() throws RepositoryException {

        final NePhysicalConnectionData disconnected = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActivationMode(ActualActivationMode.RESTART)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenThrow(new RepositoryException());

        new PhysicalNeDisconnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .onMutationApplied(disconnected, behavior, neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, false));
        verify(notifications, never()).notifyChanges(isA(NeStartingUpEvent.class));
    }

    @Test
    public void disconnectedEvent_restartAfterProcessing_neRepoError_doesNothing() throws RepositoryException {

        final ChannelPhysicalConnectionData channel = new ChannelPhysicalConnectionBuilder()
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0);

        final NePhysicalConnectionData disconnected = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActivationMode(ActualActivationMode.RESTART)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channel));
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).thenThrow(new RepositoryException());

        new PhysicalNeDisconnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .onMutationApplied(disconnected, behavior, neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, false));
        verify(notifications, never()).notifyChanges(isA(NeStartingUpEvent.class));
    }

    @Test
    public void disconnectedEvent_restartAfterProcessing_neNotUpdated_doesNothing() throws RepositoryException {

        final ChannelPhysicalConnectionData channel = new ChannelPhysicalConnectionBuilder()
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0);

        final NePhysicalConnectionData disconnected = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActivationMode(ActualActivationMode.RESTART)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);

        when(channelInstanceRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channel));
        when(neInstanceRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class))).thenReturn(Optional.empty());

        new PhysicalNeDisconnectedEventHandler<>(ctx, neManagers, channelInstanceRepository)
                .onMutationApplied(disconnected, behavior, neManagers);

        verify(activationManager, never()).scheduleActivation(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, false));
        verify(notifications, never()).notifyChanges(isA(NeStartingUpEvent.class));
    }

    @Test
    public void disconnectingEvent() {
        final PhysicalNeDisconnectingEvent event = new PhysicalNeDisconnectingEvent(NE_INSTANCE_ID, NE_ID, false);

        final PhysicalNeDisconnectingEventHandler<CallContext> handler = new PhysicalNeDisconnectingEventHandler<>(ctx, neManagers);

        handler.produceMutation(event, behavior, neManagers);
        verify(behavior).setDisconnecting(activationManager);

        NeEvent forwardingEvent;

        forwardingEvent = handler.produceForwardingEvent(event,
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.CONNECTED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0));
        assertThat(forwardingEvent, is(instanceOf(NeActivationFailedEvent.class)));

        forwardingEvent = handler.produceForwardingEvent(event,
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0));
        assertThat(forwardingEvent, is(instanceOf(NeActivationFailedEvent.class)));

        forwardingEvent = handler.produceForwardingEvent(event,
                new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.SHUTDOWN).build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0));
        assertThat(forwardingEvent, is(instanceOf(NeDisconnectingEvent.class)));
    }

    @Test
    public void initializingEvent() {
        final PhysicalNeInitializingEvent event = new PhysicalNeInitializingEvent(NE_INSTANCE_ID, NE_ID, false);

        new PhysicalNeInitializingEventHandler<>(ctx, neManagers)
            .produceMutation(event, behavior, neManagers);

        verify(behavior).setInitializing();
    }

    @Test
    public void initializedEvent() throws RepositoryException {
        final PhysicalNeInitializedEvent event = new PhysicalNeInitializedEvent(NE_INSTANCE_ID, NE_ID, false);
        final NeInitializationMetrics metrics = mock(NeInitializationMetrics.class);

        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.empty());

        new PhysicalNeInitializedEventHandler<>(ctx, neManagers, channelInstanceRepository, metrics)
            .produceMutation(event, behavior, neManagers);

        verify(behavior).setInitialized(activationManager);
    }

}
