package com.ossnms.dcn_manager.commands.container;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.Test;

import com.ossnms.dcn_manager.commands.container.GetAllContainers;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class GetAllContainersTest extends ContainerTestBase {

    @Test
    public void testGetContainers() throws RepositoryException {
        final Iterable<ContainerInfo> results = Collections.emptyList();
        when(repo.queryAll()).thenReturn(results);

        final Iterable<ContainerInfo> iterable = new GetAllContainers<>(null, repo).call();

        assertThat(iterable, is(results));
    }

    @Test(expected=RepositoryException.class)
    public void testGetContainers_withRepositoryError() throws RepositoryException {

        when(repo.queryAll()).thenThrow(new RepositoryException());

        new GetAllContainers<>(null, repo).call();
    }

}
