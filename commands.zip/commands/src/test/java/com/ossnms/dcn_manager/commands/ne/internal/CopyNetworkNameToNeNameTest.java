package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class CopyNetworkNameToNeNameTest {

    private static final int ID = 1, VERSION = 1;
    private static final int CHANNEL_INSTANCE_ID = 2000;
    private static final int NE_INSTANCE_ID = 1000;
    
    private NeOperationRepository operationRepository;
    private NeUserPreferencesRepository preferencesRepository;
    private NetworkElementNotifications notifications;
    private LoggerManager<CallContext> logger;
    private CallContext context;
    private NeEntityRepository neRepo;
    private NetworkElementManagers neManagers;
    private NeConnectionManager neConnectionManager;
    private NePhysicalConnectionRepository neInstanceRepo;
    private NeInfoData state;
    private NeUserPreferencesData prefs;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {
        operationRepository = mock(NeOperationRepository.class);
        preferencesRepository = mock(NeUserPreferencesRepository.class);
        notifications = mock(NetworkElementNotifications.class);
        neConnectionManager = mock(NeConnectionManager.class);
        neInstanceRepo = mock(NePhysicalConnectionRepository.class);
        logger = mock(LoggerManager.class);

        state = new NeInfoBuilder()
                .setProxyType("neType")
                .build(ID, 1, VERSION);
        prefs = new NeUserPreferencesBuilder()
                .setName("neName")
                .build(ID, VERSION);
        
        neRepo = mock(NeEntityRepository.class);
        when(neRepo.getNeOperationRepository()).thenReturn(operationRepository);
        when(neRepo.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);

        neManagers = new NetworkElementManagers(neRepo, neInstanceRepo, null, notifications, null);

        context = mock(CallContext.class);
    }

    @Test
    public void call_emptyNeIdentifierList_doesNothing() throws Exception {
        final CopyNetworkNameToNeName<CallContext> command =
                new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, Collections.emptyList());

        command.call();

        verifyZeroInteractions(operationRepository, preferencesRepository, notifications, logger);
    }

    @Test
    public void call_repoErrorOnOperation_fails() throws Exception {

        when(operationRepository.query(anyInt())).thenThrow(new RepositoryException());

        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(1));
        try {
            command.call();
            fail("Should have thrown an exception on repo error.");
        } catch (final CommandException e) {
            // good. :)
        }

        verify(logger).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(preferencesRepository, notifications);
    }

    @Test
    public void call_operationNotFound_ignores() throws Exception {

        when(operationRepository.query(anyInt())).thenReturn(Optional.empty());

        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(1));
        command.call();

        verifyZeroInteractions(preferencesRepository, notifications, logger);
    }

    @Test
    public void call_noNetworkName_doesNotModify() throws Exception {

        when(operationRepository.query(anyInt())).thenReturn(Optional.of(new NeOperationBuilder().build(1, 1)));

        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(1));
        command.call();

        verifyZeroInteractions(preferencesRepository, notifications, logger);
    }

    @Test
    public void call_repoErrorOnPreferences_fails() throws Exception {
        when(operationRepository.query(anyInt())).thenReturn(Optional.of(
                new NeOperationBuilder().setRealNeName(Optional.of("netName")).build(1, 1)));
        when(neRepo.queryNe(anyInt())).thenThrow(new RepositoryException());

        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(1));
        try {
            command.call();
            fail("Should have thrown an exception on repo error.");
        } catch (final CommandException e) {
            // good. :)
        }

        verify(logger).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications);
        verify(preferencesRepository, never()).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void call_preferencesNotFound_ignores() throws Exception {
        final NeEntity entity = new NeEntity(new NeConnectionBuilder().build(ID, VERSION), new NeOperationBuilder().build(ID, VERSION),
                state, new NeSynchronizationBuilder().build(ID, VERSION), null);        
        when(neRepo.queryNe(anyInt())).thenReturn(Optional.of(entity));
        when(operationRepository.query(anyInt())).thenReturn(Optional.of(
                new NeOperationBuilder().setRealNeName(Optional.of("netName")).build(1, 1)));
        
        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(1));
        command.call();

        verifyZeroInteractions(notifications, logger);
        verify(preferencesRepository, never()).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));
    }
    
    @Test
    public void call_networkNameSameAsNeName_doesNotModify() throws Exception {
        final NeEntity entity = new NeEntity(new NeConnectionBuilder().build(ID, VERSION), new NeOperationBuilder().build(ID, VERSION),
                state, new NeSynchronizationBuilder().build(ID, VERSION), null);        
        when(neRepo.queryNe(anyInt())).thenReturn(Optional.of(entity));
        when(operationRepository.query(anyInt())).thenReturn(Optional.of(
                new NeOperationBuilder().setRealNeName(Optional.of("netName")).build(1, 1)));
        when(preferencesRepository.query(anyInt())).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName("netName").build(1, 1)));

        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(1));
        
        command.call();

        verifyZeroInteractions(notifications, logger);
        verify(preferencesRepository, never()).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void call_concurrentModificationError_fails() throws Exception {
        final NeEntity entity = new NeEntity(new NeConnectionBuilder().build(ID, VERSION), new NeOperationBuilder().build(ID, VERSION),
                state, new NeSynchronizationBuilder().build(ID, VERSION), prefs);        
        when(neRepo.queryNe(anyInt())).thenReturn(Optional.of(entity));
        
        when(operationRepository.query(anyInt())).thenReturn(Optional.of(
                new NeOperationBuilder().setRealNeName(Optional.of("netName")).build(1, 1)));
        when(preferencesRepository.query(anyInt())).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName("operatorName").build(1, 1)));
        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class)))
                .thenReturn(Optional.empty());

        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(1));

        try {
            command.call();
            fail("Should have thrown an exception on concurrent modification.");
        } catch (final CommandException e) {
            // good. :)
        }

        verify(logger).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications);
    }

    @Test
    public void call_copySuccessful() throws Exception {
        final NeEntity entity = new NeEntity(new NeConnectionBuilder().build(ID, VERSION), new NeOperationBuilder().build(ID, VERSION),
                state, new NeSynchronizationBuilder().build(ID, VERSION), prefs);        
        when(neRepo.queryNe(anyInt())).thenReturn(Optional.of(entity));
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationCaptor =
                ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        when(operationRepository.query(anyInt())).thenReturn(Optional.of(
                new NeOperationBuilder().setRealNeName(Optional.of("netName")).build(1, 1)));
        when(preferencesRepository.query(anyInt())).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName("operatorName").build(1, 1)));

        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class)))
                .then(new MutationAnswer<>());

        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(1));

        
        final NePhysicalConnectionData neInstance = new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, ID, CHANNEL_INSTANCE_ID, 0);
        when(neInstanceRepo.queryAll(ID)).thenReturn(Collections.singleton(neInstance));
        
        command.call();

        verify(logger).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verify(notifications).notifyChanges(mutationCaptor.capture());

        assertThat(mutationCaptor.getValue().getName(), hasValue("netName"));
    }

    @Test
    public void call_partialFailure_updatesSomeAndFails() throws Exception {
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> mutationCaptor =
                ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        final NeEntity entity = new NeEntity(new NeConnectionBuilder().build(ID, VERSION), new NeOperationBuilder().build(ID, VERSION),
                state, new NeSynchronizationBuilder().build(ID, VERSION), prefs);        
        when(neRepo.queryNe(anyInt())).thenReturn(Optional.of(entity));
        
        when(operationRepository.query(2)).thenThrow(new RepositoryException());

        when(operationRepository.query(1)).thenReturn(Optional.of(
                new NeOperationBuilder().setRealNeName(Optional.of("netName")).build(1, 1)));
        when(preferencesRepository.query(1)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName("operatorName").build(1, 1)));

        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class)))
                .then(new MutationAnswer<>());

        final CopyNetworkNameToNeName<CallContext> command =
            new CopyNetworkNameToNeName<>(context, neManagers, neConnectionManager, neRepo, notifications, logger, ImmutableList.of(2, 1));

        final NePhysicalConnectionData neInstance = new NePhysicalConnectionBuilder().setActivationState(ActualActivationState.INITIALIZED).build(NE_INSTANCE_ID, ID, CHANNEL_INSTANCE_ID, 0);
        when(neInstanceRepo.queryAll(ID)).thenReturn(Collections.singleton(neInstance));
        
        try {
            command.call();
            fail("Should have thrown an exception on partial failure.");
        } catch (final CommandException e) {
            // good. :)
        }

        verify(logger, times(2)).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verify(notifications).notifyChanges(mutationCaptor.capture());

        final NeUserPreferencesMutationDescriptor mutation = mutationCaptor.getValue();
        assertThat(mutation.getTarget().getId(), is(1));
        assertThat(mutation.getName(), hasValue("netName"));
    }
}
