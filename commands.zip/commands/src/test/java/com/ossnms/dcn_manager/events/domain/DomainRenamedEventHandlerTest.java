package com.ossnms.dcn_manager.events.domain;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.domain.DomainRenamed;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class DomainRenamedEventHandlerTest {

    private static final int DOMAIN_ID = 1;

    private DomainRepository repository;
    private DomainNotifications notifications;
    private DomainRenamedEventHandler<CallContext> handler;
    private NeGatewayRoutesRepository routesRepository;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws Exception {
        final CallContext ctx = mock(CallContext.class);

        repository = mock(DomainRepository.class);
        notifications = mock(DomainNotifications.class);
        routesRepository = mock(NeGatewayRoutesRepository.class);

        handler = new DomainRenamedEventHandler<>(ctx, new DomainManagers(repository, notifications), routesRepository);
    }

    @Test
    public void rename() throws Exception {

        when(repository.query(DOMAIN_ID)).thenReturn(Optional.of(
                new DomainInfoData(DOMAIN_ID, 0, "original")
        ));

        when(repository.tryUpdate(isA(DomainInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        final DomainRenamed event = new DomainRenamed(DOMAIN_ID, "new");

        handler.call(event);

        verify(notifications).notifyChanges(event);
        verify(routesRepository).renameRouteDomains("original", "new");
    }

    @Test
    public void rename_sameName_ignores() throws Exception {

        when(repository.query(DOMAIN_ID)).thenReturn(Optional.of(
                new DomainInfoData(DOMAIN_ID, 0, "original")
        ));

        final DomainRenamed event = new DomainRenamed(DOMAIN_ID, "original");

        handler.call(event);

        verify(notifications, never()).notifyChanges(event);
        verifyZeroInteractions(routesRepository);
    }

    @Test
    public void rename_domainNotFound_ignores() throws Exception {

        when(repository.query(DOMAIN_ID)).thenReturn(Optional.empty());

        handler.call(new DomainRenamed(DOMAIN_ID, "new"));

        verify(notifications, never()).notifyChanges(isA(DomainRenamed.class));
        verifyZeroInteractions(routesRepository);
    }

    @Test
    public void rename_concurrentUpdate_ignores() throws Exception {

        when(repository.query(DOMAIN_ID)).thenReturn(Optional.of(
                new DomainInfoData(DOMAIN_ID, 0, "original")
        ));

        when(repository.tryUpdate(isA(DomainInfoMutationDescriptor.class))).thenReturn(Optional.empty());

        final DomainRenamed event = new DomainRenamed(DOMAIN_ID, "new");

        handler.call(event);

        verify(notifications, never()).notifyChanges(event);
        verifyZeroInteractions(routesRepository);
    }

    @Test(expected = RepositoryException.class)
    public void rename_queryError_propagates() throws Exception {

        when(repository.query(DOMAIN_ID)).thenThrow(new RepositoryException());

        handler.handleEvent(new DomainRenamed(DOMAIN_ID, "new"));
    }

    @Test(expected = RepositoryException.class)
    public void rename_updateError_propagates() throws Exception {

        when(repository.query(DOMAIN_ID)).thenReturn(Optional.of(
                new DomainInfoData(DOMAIN_ID, 0, "original")
        ));

        when(repository.tryUpdate(isA(DomainInfoMutationDescriptor.class))).thenThrow(new RepositoryException());

        handler.handleEvent(new DomainRenamed(DOMAIN_ID, "new"));
    }
}