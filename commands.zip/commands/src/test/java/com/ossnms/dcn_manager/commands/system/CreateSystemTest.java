package com.ossnms.dcn_manager.commands.system;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CreateSystemTest {

    private static final int SYSTEM_ID = 56;

    private NeUserPreferencesRepository neUserPreferencesRepository;
    private SystemRepository repository;
    private ContainerRepository containerRepository;
    private SystemNotifications notifications;
    private LoggerManager<CallContext> loggerManager;
    private CallContext context;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {
        neUserPreferencesRepository = mock(NeUserPreferencesRepository.class);
        repository = mock(SystemRepository.class);
        notifications = mock(SystemNotifications.class);
        loggerManager = mock(LoggerManager.class);
        context = mock(CallContext.class);
        containerRepository = mock(ContainerRepository.class);

        when(repository.queryByName(anyString())).thenReturn(Optional.empty());
        when(containerRepository.queryByName(anyString())).thenReturn(Optional.empty());
        when(neUserPreferencesRepository.query(anyString())).thenReturn(Optional.empty());
    }

    @Test
    public void create() throws Exception {

        when(repository.create(any(SystemCreationDescriptor.class))).then(invocation -> {
            final SystemCreationDescriptor desc = (SystemCreationDescriptor) invocation.getArguments()[0];
            return new SystemInfo(SYSTEM_ID, 1, desc.getName());
        });

        final SystemCreationDescriptor creationDescriptor = new SystemCreationDescriptor("name");
        final SystemInfo systemInfo = new CreateSystem<>(context, repository, containerRepository, neUserPreferencesRepository, notifications, loggerManager, creationDescriptor)
            .call();

        assertThat(systemInfo, is(notNullValue()));
        assertThat(systemInfo.getName(), is(creationDescriptor.getName()));
        assertThat(systemInfo.getId(), is(SYSTEM_ID));

        verify(notifications).notifyCreate(systemInfo);
        verify(loggerManager).createCommandLog(any(CallContext.class), any(LoggerItem[].class));
    }

    @Test(expected=CommandException.class)
    public void create_repositoryError_throws() throws Exception {

        when(repository.create(any(SystemCreationDescriptor.class))).thenThrow(new RepositoryException());

        final SystemCreationDescriptor creationDescriptor = new SystemCreationDescriptor("name");
        new CreateSystem<>(context, repository, containerRepository, neUserPreferencesRepository, notifications, loggerManager, creationDescriptor).call();
    }

    @Test(expected=IllegalArgumentException.class)
    public void create_empty_name_throws() throws Exception {
        final SystemCreationDescriptor creationDescriptor = new SystemCreationDescriptor("");

        new CreateSystem<>(context, repository, containerRepository, neUserPreferencesRepository, notifications, loggerManager, creationDescriptor).call();
    }

    @Test(expected=CommandException.class)
    public void create_duplicated_system_name_throws() throws Exception {
        when(repository.queryByName("exists")).thenReturn(Optional.of(new SystemInfo(1, 1, "exists")));
        when(repository.queryByName("exists_1")).thenReturn(Optional.empty());

        final SystemCreationDescriptor creationDescriptor = new SystemCreationDescriptor("exists");
        new CreateSystem<>(context, repository, containerRepository, neUserPreferencesRepository, notifications, loggerManager, creationDescriptor).call();
    }

    @Test(expected=CommandException.class)
    public void create_duplicated_ne_name_throws() throws Exception {
        NeUserPreferencesData exists = new NeUserPreferencesBuilder().setName("exists").build(1, 2);
        when(neUserPreferencesRepository.query(anyString())).thenReturn(Optional.of(exists));

        final SystemCreationDescriptor creationDescriptor = new SystemCreationDescriptor("exists");
        new CreateSystem<>(context, repository, containerRepository, neUserPreferencesRepository, notifications, loggerManager, creationDescriptor).call();
    }
}
