package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorStartingUpEvent;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicActivationVerificationEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import org.junit.Before;
import org.junit.Test;

import java.time.Instant;
import java.util.Collections;

import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class MediatorActivationVerificationEventHandlerTest {

    private static final int MEDIATOR_ID = 10;
    private static final int MEDIATOR_INSTANCE_ID = 1010;

    private CallContext context;

    private MediatorEntityRepository entityRepository;
    private MediatorInstanceEntityRepository physicalRepository;
    private MediatorPhysicalConnectionRepository physicalConnectionRepository;
    private MediatorNotifications notifications;
    private MediatorInteractionManager activationManager;
    private MessageSource<MediatorEvent> mediatorEvents;

    private LoggerManager<CallContext> loggerManager;

    private SettingsRepository settingsRepository;

    private MediatorActivationVerificationEventHandler<CallContext> handler;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        context = mock(CallContext.class);

        physicalRepository = mock(MediatorInstanceEntityRepository.class);
        physicalConnectionRepository = mock(MediatorPhysicalConnectionRepository.class);
        entityRepository = mock(MediatorEntityRepository.class);
        notifications = mock(MediatorNotifications.class);
        activationManager = mock(MediatorInteractionManager.class);
        mediatorEvents = mock(MessageSource.class);

        loggerManager = mock(LoggerManager.class);

        settingsRepository = mock(SettingsRepository.class);

        when(physicalRepository.getMediatorPhysicalConnectionRepository()).thenReturn(physicalConnectionRepository);

        final MediatorManagers mediatorManagers = new MediatorManagers(entityRepository, physicalRepository, notifications, activationManager, mediatorEvents);

        handler = new MediatorActivationVerificationEventHandler<>(context, mediatorManagers, settingsRepository, loggerManager);
    }

    private MediatorEntity buildEntity() {
        return new MediatorEntity(
                new MediatorInfoBuilder().setTypeName("type").setName("name").setActivationRequired(true).build(MEDIATOR_ID, 0),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, 0)
            );
    }

    @Test
    public void noMediators_doNothing() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.emptyList());

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verifyZeroInteractions(activationManager, notifications);
    }

    @Test
    public void mediatorActivationNotRequired_doNothing() throws Exception {

        final MediatorEntity notRequiredMediator = new MediatorEntity(
                new MediatorInfoBuilder().setTypeName("type").setName("name").setActivationRequired(false).build(MEDIATOR_ID, 0),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, 0)
            );

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(notRequiredMediator));

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verifyZeroInteractions(activationManager, notifications);

    }

    @Test
    public void noPhysicalConnections_doNothing() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(buildEntity()));
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.emptyList());

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verifyZeroInteractions(activationManager, notifications);

    }

    @Test
    public void noFailedPhysicalConnections_doNothing() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(buildEntity()));
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(
                new MediatorPhysicalConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 0)
            ));

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verifyZeroInteractions(activationManager, notifications);

    }

    @Test
    public void failedPhysicalConnections_timeNotElapsed_doNothing() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(buildEntity()));
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(
                new MediatorPhysicalConnectionBuilder()
                    .setActualActivationState(ActualActivationState.FAILED)
                    .setActivationAttemptsCounter(1)
                    .setLastFailureTimestamp(Instant.now())
                    .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 0)
            ));

        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setMediatorRetries(0).setRetryInterval(1).toGlobalSettings(1, 0));

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verifyZeroInteractions(activationManager, notifications);

    }

    @Test
    public void failedPhysicalConnections_retriesExceeded_doNothing() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(buildEntity()));
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(
                new MediatorPhysicalConnectionBuilder()
                    .setActualActivationState(ActualActivationState.FAILED)
                    .setActivationAttemptsCounter(10)
                    .setLastFailureTimestamp(Instant.MIN)
                    .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 0)
            ));

        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setMediatorRetries(3).setRetryInterval(1).toGlobalSettings(1, 0));

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verifyZeroInteractions(activationManager, notifications);

    }

    @Test
    public void failedPhysicalConnections_timeElapsed_retriesNotExceeded_retriesLimited_schedulesActivation() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(buildEntity()));
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(
                new MediatorPhysicalConnectionBuilder()
                    .setActive(true)
                    .setActualActivationState(ActualActivationState.FAILED)
                    .setActivationAttemptsCounter(1)
                    .setLastFailureTimestamp(Instant.MIN)
                    .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 0)
            ));
        when(physicalConnectionRepository.tryUpdate(isA(MediatorPhysicalConnectionMutationDescriptor.class)))
            .then(new MutationAnswer<>());

        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setMediatorRetries(3).setRetryInterval(1).toGlobalSettings(1, 0));

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verify(activationManager).scheduleActivation(isA(ActivateMediatorEvent.class));
        verify(notifications).notifyChanges(isA(MediatorStartingUpEvent.class));
        verify(loggerManager).createSystemEventLog(eq(context), isA(LoggerItemMediator.class));
    }

    @Test
    public void failedPhysicalConnections_timeElapsed_retriesNotExceeded_infinteRetries_schedulesActivation() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(buildEntity()));
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(
                new MediatorPhysicalConnectionBuilder()
                    .setActive(true)
                    .setActualActivationState(ActualActivationState.FAILED)
                    .setActivationAttemptsCounter(1)
                    .setLastFailureTimestamp(Instant.MIN)
                    .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 0)
            ));
        when(physicalConnectionRepository.tryUpdate(isA(MediatorPhysicalConnectionMutationDescriptor.class)))
            .then(new MutationAnswer<>());

        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setMediatorRetries(0).setRetryInterval(1).toGlobalSettings(1, 0));

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verify(activationManager).scheduleActivation(isA(ActivateMediatorEvent.class));
        verify(notifications).notifyChanges(isA(MediatorStartingUpEvent.class));
        verify(loggerManager).createSystemEventLog(eq(context), isA(LoggerItemMediator.class));
    }

    @Test
    public void failedStandbyPhysicalConnection_standbyNotAllowed_doesNothing() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(buildEntity()));
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(
                new MediatorPhysicalConnectionBuilder()
                        .setActive(false)
                        .setActualActivationState(ActualActivationState.FAILED)
                        .setActivationAttemptsCounter(1)
                        .setLastFailureTimestamp(Instant.MIN)
                        .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 0)
        ));
        when(physicalConnectionRepository.tryUpdate(isA(MediatorPhysicalConnectionMutationDescriptor.class)))
                .then(new MutationAnswer<>());

        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setMediatorRetries(0).setRetryInterval(1).toGlobalSettings(1, 0));

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(false);

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verifyZeroInteractions(activationManager);
        verify(notifications, never()).notifyChanges(isA(MediatorStartingUpEvent.class));
        verify(loggerManager, never()).createSystemEventLog(eq(context), isA(LoggerItemMediator.class));
    }

    @Test
    public void failedStandbyPhysicalConnection_standbAllowed_schedulesActivation() throws Exception {

        when(entityRepository.queryAll()).thenReturn(Collections.singleton(buildEntity()));
        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(
                new MediatorPhysicalConnectionBuilder()
                        .setActive(false)
                        .setActualActivationState(ActualActivationState.FAILED)
                        .setActivationAttemptsCounter(1)
                        .setLastFailureTimestamp(Instant.MIN)
                        .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 0)
        ));
        when(physicalConnectionRepository.tryUpdate(isA(MediatorPhysicalConnectionMutationDescriptor.class)))
                .then(new MutationAnswer<>());

        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().setMediatorRetries(0).setRetryInterval(1).toGlobalSettings(1, 0));

        when(settingsRepository.areStandbyConnectionsAllowed()).thenReturn(true);

        handler.handleEvent(new PeriodicActivationVerificationEvent());

        verify(activationManager).scheduleActivation(isA(ActivateMediatorEvent.class));
        verify(notifications).notifyChanges(isA(MediatorStartingUpEvent.class));
        verify(loggerManager).createSystemEventLog(eq(context), isA(LoggerItemMediator.class));
    }
}
