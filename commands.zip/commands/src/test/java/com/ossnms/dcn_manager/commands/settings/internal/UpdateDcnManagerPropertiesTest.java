package com.ossnms.dcn_manager.commands.settings.internal;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettingsMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.core.events.settings.NativeNeNamingSettingChangeEvent;
import com.ossnms.dcn_manager.core.outbound.GlobalSettingsNotifications;
import com.ossnms.dcn_manager.core.policies.SystemSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UpdateDcnManagerPropertiesTest {

    @Mock private SettingsRepository settingsRepository;
    @Mock private GlobalSettingsNotifications notifications;
    @Mock private SystemSchedulingConfiguration systemScheduling;
    @Mock private LoggerManager<CallContext> loggerManager;
    @Mock private CallContext callContext;

    @Before
    public void setUp() throws Exception {
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(1, 1));
    }

    @Test(expected=CommandException.class)
    public void invalidPropertyName_throwsException() throws CommandException, DataUpdateException {
        new UpdateDcnManagerProperties<>(callContext, settingsRepository, notifications, systemScheduling, loggerManager,
                ImmutableMap.of("XX", "25")).call();
    }

    @Test(expected=CommandException.class)
    public void invalidPropertyValue_throwsException() throws CommandException, DataUpdateException {
        new UpdateDcnManagerProperties<>(callContext, settingsRepository, notifications, systemScheduling, loggerManager,
                ImmutableMap.of(SettingsProperties.RETRY_MEDIATOR.getName(), "XX")).call();
    }

    @Test(expected=DataUpdateException.class)
    public void concurrentModification_throwsException() throws CommandException, DataUpdateException, RepositoryException {
        when(settingsRepository.tryUpdateSettings(isA(GlobalSettingsMutationDescriptor.class)))
            .thenReturn(Optional.empty());

        new UpdateDcnManagerProperties<>(callContext, settingsRepository, notifications, systemScheduling, loggerManager,
                ImmutableMap.of(SettingsProperties.RETRY_MEDIATOR.getName(), "24")).call();
    }

    @Test
    public void validRequest_commitsMutation() throws CommandException, RepositoryException, DataUpdateException {
        when(settingsRepository.tryUpdateSettings(isA(GlobalSettingsMutationDescriptor.class))).then(new MutationAnswer<>());

        new UpdateDcnManagerProperties<>(callContext, settingsRepository, notifications, systemScheduling, loggerManager,
                ImmutableMap.of(SettingsProperties.RETRY_MEDIATOR.getName(), "24", SettingsProperties.ENABLE_NATIVE_NE_NAMING.getName(), "true")
            ).call();

        final ArgumentCaptor<GlobalSettingsMutationDescriptor> descCaptor = ArgumentCaptor.forClass(GlobalSettingsMutationDescriptor.class);
        verify(settingsRepository).tryUpdateSettings(descCaptor.capture());

        verify(systemScheduling).setMaxOngoingSystemJobCount(anyInt());

        assertThat(descCaptor.getValue().getMediatorRetries().get(), is(24));

        final ArgumentCaptor<NativeNeNamingSettingChangeEvent> eventCaptor = ArgumentCaptor.forClass(NativeNeNamingSettingChangeEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        assertThat(eventCaptor.getValue().getShowNativeNeNaming(), is(true));

        verify(loggerManager, times(2)).createCommandLog(any(CallContext.class), any(LoggerItem.class));
    }

    @Test
    public void validRequest_withoutNativeNeNamingChange() throws CommandException, RepositoryException, DataUpdateException {
        when(settingsRepository.tryUpdateSettings(isA(GlobalSettingsMutationDescriptor.class))).then(new MutationAnswer<>());

        new UpdateDcnManagerProperties<>(callContext, settingsRepository, notifications, systemScheduling, loggerManager,
                ImmutableMap.of(SettingsProperties.RETRY_MEDIATOR.getName(), "24")).call();

        final ArgumentCaptor<GlobalSettingsMutationDescriptor> descCaptor = ArgumentCaptor.forClass(GlobalSettingsMutationDescriptor.class);
        verify(settingsRepository).tryUpdateSettings(descCaptor.capture());

        verify(systemScheduling).setMaxOngoingSystemJobCount(anyInt());

        assertThat(descCaptor.getValue().getMediatorRetries().get(), is(24));

        verify(notifications, never()).notifyChanges(any(NativeNeNamingSettingChangeEvent.class));
    }
}
