package com.ossnms.dcn_manager.events.channel;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelCreatedEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.CollQueryAnswer;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

public class PhysicalChannelCreatedEventHandlerTest {

    private static final int MEDIATOR_ID = 53;
    private static final int CHANNEL_ID = 42;
    private static final int VERSION = 1;
    protected static final int ACTIVE_NE_ID = 99;
    protected static final int INACTIVE_NE_ID = 88;
    protected static final int FOREIGN_NE_ID = 77;
    private static final int CHANNEL_INSTANCE_ID = 4200;
    private static final int MEDIATOR_INSTANCE_ID = 5300;
    private static final int ACTIVE_NE_INSTANCE_ID = 9900;
    private static final int INACTIVE_NE_INSTANCE_ID = 8800;
    private static final int FOREIGN_NE_INSTANCE_ID = 7700;

    private PhysicalChannelCreatedEventHandler<CallContext> handler;
    private CallContext context;
    private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    private ChannelEntityRepository entityRepository;
    private ChannelNotifications notifications;
    private ChannelInteractionManager activationManager;
    private NeEntityRepository neRepository;
    private NeInfoRepository neInfoRepository;
    private NePhysicalConnectionRepository neInstancesRepository;
    private NetworkElementNotifications neNotifications;
    private MessageSource<NeEvent> neMessages;
    private MessageSource<ChannelEvent> channelEvents;
    private NetworkElementInteractionManager neActivationManager;
    private MediatorInstanceEntityRepository mediatorInstanceRepository;
    private MediatorPhysicalConnectionRepository mediatorPhysicalConnectionRepository;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        context = mock(CallContext.class);
        channelPhysicalConnectionRepository = mock(ChannelPhysicalConnectionRepository.class);
        entityRepository = mock(ChannelEntityRepository.class);
        notifications = mock(ChannelNotifications.class);
        activationManager = mock(ChannelInteractionManager.class);
        neActivationManager = mock(NetworkElementInteractionManager.class);
        neNotifications = mock(NetworkElementNotifications.class);
        neMessages = mock(MessageSource.class);
        channelEvents = mock(MessageSource.class);
        neRepository = mock(NeEntityRepository.class);
        neInfoRepository = mock(NeInfoRepository.class);
        neInstancesRepository = mock(NePhysicalConnectionRepository.class);
        mediatorInstanceRepository = mock(MediatorInstanceEntityRepository.class);
        mediatorPhysicalConnectionRepository = mock(MediatorPhysicalConnectionRepository.class);

        when(neRepository.queryActivationRequiredIs(CHANNEL_ID, RequiredActivationState.ACTIVE))
            .thenReturn(ImmutableList.of(
                new NeInfoBuilder().setProxyType("type").setRequiredActivationState(RequiredActivationState.ACTIVE).build(ACTIVE_NE_ID, CHANNEL_ID, VERSION)
            )
        );
        when(neInstancesRepository.query(isA(QNePhysicalConnectionData.class)))
            .then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                    .setActive(true)
                    .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                    .build(ACTIVE_NE_INSTANCE_ID, ACTIVE_NE_ID, CHANNEL_INSTANCE_ID, VERSION),
                new NePhysicalConnectionBuilder()
                    .setActive(false)
                    .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                    .build(INACTIVE_NE_INSTANCE_ID, INACTIVE_NE_ID, CHANNEL_INSTANCE_ID, VERSION),
                new NePhysicalConnectionBuilder()
                    .setActive(true)
                    .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                    .build(FOREIGN_NE_INSTANCE_ID, FOREIGN_NE_ID, CHANNEL_INSTANCE_ID, VERSION)
            )
        );
        when(neInstancesRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
            .then(new MutationAnswer<>());

        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);

        when(neRepository.queryActivationRequiredIs(anyInt(), any(RequiredActivationState.class)))
            .thenReturn(ImmutableList.of(
                new NeInfoBuilder().setProxyType("type").build(ACTIVE_NE_ID, CHANNEL_ID, VERSION)));

        when(mediatorInstanceRepository.getMediatorPhysicalConnectionRepository()).thenReturn(mediatorPhysicalConnectionRepository);

        handler = new PhysicalChannelCreatedEventHandler<>(context,
                new ChannelManagers(entityRepository, channelPhysicalConnectionRepository, notifications, activationManager, channelEvents),
                new NetworkElementManagers(neRepository, neInstancesRepository, neActivationManager, neNotifications, neMessages),
                new MediatorManagers(null, mediatorInstanceRepository, null, null, null));
    }

    @Test
    public void event_onCreatingChannel() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
            .setActivation(ActualActivationState.CREATING)
            .setAdditionalInfo("")
            .setActive(true)
            .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.singleton(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        final ArgumentCaptor<ChannelPhysicalConnectionMutationDescriptor> captor =
                ArgumentCaptor.forClass(ChannelPhysicalConnectionMutationDescriptor.class);
        verify(channelPhysicalConnectionRepository).tryUpdate(captor.capture());

        assertThat(captor.getValue().getTarget().getId(), is(CHANNEL_INSTANCE_ID));
        assertThat(captor.getValue().getActualActivationState().get(), is(ActualActivationState.ACTIVE));
    }

    @Test
    public void event_onCreatingChannel_activeChannelInstance_cascadesToStandbyDisconnectedChannels() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        final ChannelPhysicalConnectionData standbyState = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(CHANNEL_INSTANCE_ID + 1, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(state, standbyState));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        final MediatorPhysicalConnectionData standbyMediatorState =
            new MediatorPhysicalConnectionBuilder()
                .setActive(false)
                .setActualActivationState(com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState.ACTIVE)
                .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(standbyMediatorState));

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verify(activationManager).scheduleActivation(new RequiredChannelStateEvent.Activate(CHANNEL_ID, MEDIATOR_INSTANCE_ID, Collections.singleton(CHANNEL_INSTANCE_ID + 1)));
        verify(activationManager, never()).scheduleActivation(new RequiredChannelStateEvent.Activate(CHANNEL_ID, MEDIATOR_INSTANCE_ID, Collections.singleton(CHANNEL_INSTANCE_ID)));
    }

    @Test
    public void event_onCreatingChannel_activeChannelInstance_inactiveMediatorInstance_doesNotCascadeToStandbyDisconnectedChannels() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        final ChannelPhysicalConnectionData standbyState = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(CHANNEL_INSTANCE_ID + 1, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(state, standbyState));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        final MediatorPhysicalConnectionData standbyMediatorState =
                new MediatorPhysicalConnectionBuilder()
                        .setActive(false)
                        .setActualActivationState(com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState.INACTIVE)
                        .build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION);
        when(mediatorPhysicalConnectionRepository.query(MEDIATOR_INSTANCE_ID)).thenReturn(Optional.of(standbyMediatorState));

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verify(activationManager, never()).scheduleActivation(new RequiredChannelStateEvent.Activate(CHANNEL_ID, MEDIATOR_INSTANCE_ID, Collections.singleton(CHANNEL_INSTANCE_ID + 1)));
        verify(activationManager, never()).scheduleActivation(new RequiredChannelStateEvent.Activate(CHANNEL_ID, MEDIATOR_INSTANCE_ID, Collections.singleton(CHANNEL_INSTANCE_ID)));
    }

    @Test
    public void event_onCreatingChannel_standbyChannelInstance_doesNotCascadeToSiblingDisconnectedChannels() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(false)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        final ChannelPhysicalConnectionData standbyState = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(true)
                .build(CHANNEL_INSTANCE_ID + 1, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(state, standbyState));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verify(activationManager, never()).scheduleActivation(any(RequiredChannelStateEvent.Activate.class));
    }

    @Test
    public void event_onCreatingChannel_activeChannelInstance_repoErrorCascadingToChannels_ignores() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        final ChannelPhysicalConnectionData standbyState = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(CHANNEL_INSTANCE_ID + 1, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(state, standbyState));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class)))
                .then(new MutationAnswer<>()).thenThrow(new RepositoryException());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verify(activationManager, never()).scheduleActivation(any(RequiredChannelStateEvent.Activate.class));
    }

    @Test
    public void event_onCreatingChannel_activeChannelInstance_concurrentModificationCascadingToChannels_ignores() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        final ChannelPhysicalConnectionData standbyState = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.INACTIVE)
                .setAdditionalInfo("")
                .setActive(false)
                .build(CHANNEL_INSTANCE_ID + 1, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(ImmutableList.of(state, standbyState));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class)))
                .then(new MutationAnswer<>()).thenReturn(Optional.empty());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verify(activationManager, never()).scheduleActivation(any(RequiredChannelStateEvent.Activate.class));
    }

    @Test
    public void event_onCreatingChannel_activeChannelInstance_cascadesToActiveDisconnectedNEs() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.singleton(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verify(neActivationManager).scheduleActivation(new Activate(ACTIVE_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, ACTIVE_NE_INSTANCE_ID, true));
        verify(neActivationManager, never()).scheduleActivation(new Activate(INACTIVE_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, INACTIVE_NE_INSTANCE_ID, false));
        verify(neActivationManager, never()).scheduleActivation(new Activate(FOREIGN_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, FOREIGN_NE_INSTANCE_ID, true));
    }

    @Test
    public void event_onCreatingChannel_inactiveChannelInstance_doesNotCascadeToActiveDisconnectedStandbyNEs() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(false)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        verify(neActivationManager, never()).scheduleActivation(new Activate(ACTIVE_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, ACTIVE_NE_INSTANCE_ID, true));
        verify(neActivationManager, never()).scheduleActivation(new Activate(INACTIVE_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, INACTIVE_NE_INSTANCE_ID, false));
        verify(neActivationManager, never()).scheduleActivation(new Activate(FOREIGN_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, FOREIGN_NE_INSTANCE_ID, true));
    }

    @Test
    public void event_onCreatingChannel_inactiveChannelInstance_cascadeToActiveConnectedStandbyNEs() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(false)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(neInstancesRepository.query(isA(QNePhysicalConnectionData.class)))
            .then(new CollQueryAnswer<>(
                new NePhysicalConnectionBuilder()
                    .setActive(true)
                    .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.INITIALIZED)
                    .build(ACTIVE_NE_INSTANCE_ID, ACTIVE_NE_ID, CHANNEL_INSTANCE_ID, VERSION),
                new NePhysicalConnectionBuilder()
                    .setActive(false)
                    .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                    .build(INACTIVE_NE_INSTANCE_ID, ACTIVE_NE_ID, CHANNEL_INSTANCE_ID, VERSION),
                new NePhysicalConnectionBuilder()
                    .setActive(true)
                    .setActivationState(com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState.DISCONNECTED)
                    .build(FOREIGN_NE_INSTANCE_ID, FOREIGN_NE_ID, CHANNEL_INSTANCE_ID, VERSION)
            )
        );

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        verify(neActivationManager, never()).scheduleActivation(new Activate(ACTIVE_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, ACTIVE_NE_INSTANCE_ID, true));
        verify(neActivationManager).scheduleActivation(new Activate(ACTIVE_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, INACTIVE_NE_INSTANCE_ID, false));
        verify(neActivationManager, never()).scheduleActivation(new Activate(FOREIGN_NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, FOREIGN_NE_INSTANCE_ID, true));
    }

    @Test
    public void event_onCreatingChannel_cascadesToNEs_neConnectionUpdateFailure_isIgnored() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .setActive(true)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(neInstancesRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
                .thenReturn(Optional.empty());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verifyZeroInteractions(neActivationManager);
    }

    @Test
    public void event_onCreatingChannel_cascadesToNEs_neConnectionRepositoryException_isIgnored() throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(ActualActivationState.CREATING)
                .setAdditionalInfo("")
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));
        when(channelPhysicalConnectionRepository.tryUpdate(isA(ChannelPhysicalConnectionMutationDescriptor.class))).then(new MutationAnswer<>());

        when(neInstancesRepository.tryUpdate(isA(NePhysicalConnectionMutationDescriptor.class)))
                .thenThrow(new RepositoryException());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verifyZeroInteractions(neActivationManager);
    }

    @Test
    public void event_channelConnectionNotFound() throws RepositoryException {
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true));

        verify(channelPhysicalConnectionRepository, never()).tryUpdate(any(ChannelPhysicalConnectionMutationDescriptor.class));
    }

    @Test
    public void event_onActiveChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.ACTIVE);
    }

    @Test
    public void event_onActivatingChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.ACTIVATING);
    }

    @Test
    public void event_onDeactivatingChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.DEACTIVATING);
    }

    @Test
    public void event_onStartingUpChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.STARTINGUP);
    }

    @Test
    public void event_onShuttingdownChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.SHUTTINGDOWN);
    }

    @Test
    public void event_onFailedChannel() throws RepositoryException {
        verifyNoActionOnState(ActualActivationState.FAILED);
    }

    private void verifyNoActionOnState(ActualActivationState activationState) throws RepositoryException {
        final ChannelPhysicalConnectionData state = new ChannelPhysicalConnectionBuilder()
                .setActivation(activationState)
                .setAdditionalInfo("")
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);
        when(channelPhysicalConnectionRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(state));

        handler.call(new PhysicalChannelCreatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, false));

        verify(channelPhysicalConnectionRepository, never()).tryUpdate(any(ChannelPhysicalConnectionMutationDescriptor.class));
        verifyZeroInteractions(neActivationManager);
    }

}
