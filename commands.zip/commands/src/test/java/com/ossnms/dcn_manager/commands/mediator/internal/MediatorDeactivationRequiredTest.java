package com.ossnms.dcn_manager.commands.mediator.internal;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.mediator.MediatorTestBase;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.IllegalMediatorStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.iterableWithSize;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class MediatorDeactivationRequiredTest extends MediatorTestBase {

    private static final int MEDIATOR_INSTANCE_ID = 20;

	private MediatorInfoData mediatorState;
	private MediatorManagers mediatorManagers;

	private ChannelEntityRepository channelRepository;

	@Override
    @Before
	public void setUp() throws RepositoryException
    {
		super.setUp();
		channelRepository = mock(ChannelEntityRepository.class);
        mediatorState = newInfo(false);

        when(physicalDataRepository.queryAll()).thenReturn(ImmutableList.of(
                new MediatorPhysicalDataBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION),
                new MediatorPhysicalDataBuilder().build(9987, 8856, VERSION)
            ));

        when(physicalConnectionRepository.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActualActivationState(ActualActivationState.ACTIVE).build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, VERSION)));

		when(physicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class)))
		.thenAnswer(new MutationAnswer<>());

		mediatorManagers = new MediatorManagers(repo, physicalMediatorRepository, notif, mediatorActivationManager, mediatorEvents);
    }

	@Test(expected=UnknownMediatorIdException.class)
	public void deactivate_withNonExistingMediatorId_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
    	when(repo.query(MEDIATOR_ID)).thenReturn(Optional.<MediatorEntity>empty());

    	// Execute command (Act)
		new MediatorDeactivationRequired<>(context, MEDIATOR_ID, mediatorManagers, channelRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test(expected=IllegalMediatorStateException.class)
	public void deactivate_onADeactivatedMediator_throwsException() throws Exception
	{
		// Set up repository and mediator entity stubs (Arrange)
        final MediatorEntity mediatorEntity = new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));
		when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));
		when(channelRepository.queryActivationRequiredIs(MEDIATOR_ID, true)).thenReturn(Collections.<ChannelInfoData>emptySet());
		
    	// Execute command (Act)
		new MediatorDeactivationRequired<>(context, MEDIATOR_ID, mediatorManagers, channelRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test(expected=IllegalMediatorStateException.class)
	public void deactivate_onAConcurrentlyDeactivatedMediator_throwsException() throws Exception
	{
		// Set up repository stub (Arrange)
        final MediatorEntity mediatorEntity = new MediatorEntity(
                newInfo(true),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));
        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));
        when(channelRepository.queryActivationRequiredIs(MEDIATOR_ID, true)).thenReturn(Collections.<ChannelInfoData>emptySet());

        when(infoRepo.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
			.thenReturn(Optional.<MediatorInfoData>empty());

    	// Execute command (Act)
		new MediatorDeactivationRequired<>(context, MEDIATOR_ID, mediatorManagers, channelRepository, loggerManager).call();

		// Does not get here because tested behavior should throw exception (Assert)
	}

	@Test
	public void deactivate_onAnActivatedMediator_deactivatesItAndTriggersConnectionClosure() throws Exception
	{
		// Set up repository and mediator entity stubs (Arrange)
        final MediatorEntity mediatorEntity = new MediatorEntity(
                newInfo(true),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));
        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));
        when(channelRepository.queryActivationRequiredIs(MEDIATOR_ID, true)).thenReturn(Collections.<ChannelInfoData>emptySet());

		when(infoRepo.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
			.thenAnswer(new MutationAnswer<>());

    	// Execute command (Act)
		new MediatorDeactivationRequired<>(context, MEDIATOR_ID, mediatorManagers, channelRepository, loggerManager).call();

		// Verify mediator state and interaction with mocked connection scheduler and mocked event dispatcher (Assert)
		final ArgumentCaptor<MediatorInfoMutationDescriptor> argsCaptor = ArgumentCaptor.forClass(MediatorInfoMutationDescriptor.class);
		verify(infoRepo).tryUpdate(argsCaptor.capture());

		assertThat(argsCaptor.getValue().getActivationRequired().get(), is(false));

        final ArgumentCaptor<DeactivateMediatorEvent> activationCaptor = ArgumentCaptor.forClass(DeactivateMediatorEvent.class);
        final ArgumentCaptor<DeactivateMediatorEvent> notificationCaptor = ArgumentCaptor.forClass(DeactivateMediatorEvent.class);

        verify(mediatorActivationManager).scheduleDeactivation(activationCaptor.capture());
        verify(notif).notifyChanges(notificationCaptor.capture());

        assertThat(activationCaptor.getValue().getMediatorId(), is(MEDIATOR_ID));
        assertThat(activationCaptor.getValue().getMediatorInstanceIdentifiers(), is(iterableWithSize(1)));
        assertThat(activationCaptor.getValue().getMediatorInstanceIdentifiers(), hasItem(MEDIATOR_INSTANCE_ID));

        assertThat(notificationCaptor.getValue().getMediatorId(), is(MEDIATOR_ID));
        assertThat(notificationCaptor.getValue().getMediatorInstanceIdentifiers(), is(iterableWithSize(1)));
        assertThat(notificationCaptor.getValue().getMediatorInstanceIdentifiers(), hasItem(MEDIATOR_INSTANCE_ID));

		verify(loggerManager).createCommandLog(eq(context), any(LoggerItem[].class));
	}

    @Test(expected=RepositoryException.class)
    public void deactivate_whenRepositoryThrowsException_throwsRepositoryException() throws Exception
    {
        // Set up repository stub (Arrange)
        when(repo.query(MEDIATOR_ID)).thenThrow(new RepositoryException());

        // Execute command (Act)
        new MediatorDeactivationRequired<>(context, MEDIATOR_ID, mediatorManagers, channelRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

    @Test(expected=IllegalChannelStateException.class)
    public void deactivate_withActiveChannels_throwsIllegalChannelStateException() throws Exception
    {
        // Set up repository stub (Arrange)
        final MediatorEntity mediatorEntity = new MediatorEntity(
                newInfo(true),
                new MediatorConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(MEDIATOR_ID, VERSION));
        when(repo.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorEntity));
        when(channelRepository.queryActivationRequiredIs(MEDIATOR_ID, true))
            .thenReturn(Collections.singleton(new ChannelInfoBuilder().setType("type").setActivationRequired(true).build(98, VERSION, MEDIATOR_ID)));

        // Execute command (Act)
        new MediatorDeactivationRequired<>(context, MEDIATOR_ID, mediatorManagers, channelRepository, loggerManager).call();

        // Does not get here because tested behavior should throw exception (Assert)
    }

}
