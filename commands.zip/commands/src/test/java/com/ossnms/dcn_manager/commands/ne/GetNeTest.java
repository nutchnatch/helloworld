package com.ossnms.dcn_manager.commands.ne;

import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class GetNeTest extends NeTestBase {

    @Test
    public void testFind() throws Exception {
        final NeEntity entity1 = new NeEntity(null, null, null, null, null);
        final Optional<NeEntity> value = Optional.of(entity1);

        when(neRepo.queryNe(23)).thenReturn(value);

        final Optional<NeEntity> ne = new GetNe<>(context, neRepo, 23).call();
        assertThat(ne, is(value));
    }

    @Test
    public void testAbsent() throws Exception {

        when(neRepo.queryNe(23)).thenReturn(Optional.empty());

        final Optional<NeEntity> ne = new GetNe<>(context, neRepo, 23).call();
        assertThat(ne.isPresent(), is(false));
    }

    @Test(expected=CommandException.class)
    public void testFindError() throws Exception {

        when(neRepo.queryNe(23)).thenThrow(new RepositoryException());

        new GetNe<>(context, neRepo, 23).call();
    }

}
