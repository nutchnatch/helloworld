package com.ossnms.dcn_manager.commands.channel;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Collections;

import static org.hamcrest.Matchers.emptyCollectionOf;
import static org.hamcrest.Matchers.hasItems;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GetRegisteredChannelsTest extends ChannelTestBase {

    private MediatorType mediatorType;
    private Types<MediatorType> mediatorTypes;

    @Override
    @Before
    public void setUp() throws RepositoryException {
        super.setUp();

        mediatorType = mock(MediatorType.class);
        mediatorTypes = mock(Types.class);

        when(staticConfig.getMediatorTypes()).thenReturn(mediatorTypes);
    }

    @Test
    public void testCall() throws UnknownMediatorTypeException {
        final ChannelType type1 = mock(ChannelType.class);
        final ChannelType type2 = mock(ChannelType.class);
        final Collection<ChannelType> types = ImmutableList.of(type1, type2);

        when(mediatorType.getSupportedChannelTypes()).thenReturn(types);
        when(mediatorTypes.get(anyString())).thenReturn(mediatorType);

        final Collection<ChannelType> result = new GetRegisteredEMs<CallContext>(context, staticConfig, "mediatorType").call();

        assertThat(result, hasItems(type1, type2));
    }

    @Test
    public void testCallWithoutTypes() throws UnknownMediatorTypeException {

        when(mediatorType.getSupportedChannelTypes()).thenReturn(Collections.<ChannelType>emptyList());
        when(mediatorTypes.get(anyString())).thenReturn(mediatorType);

        final Collection<ChannelType> result = new GetRegisteredEMs<CallContext>(context, staticConfig, "mediatorType").call();

        assertThat(result, emptyCollectionOf(ChannelType.class));
    }

    @Test(expected=UnknownMediatorTypeException.class)
    public void testCallWithUnknownMediator() throws UnknownMediatorTypeException {

        when(mediatorTypes.get(anyString())).thenReturn(null);

        new GetRegisteredEMs<CallContext>(context, staticConfig, "mediatorType").call();
    }

}
