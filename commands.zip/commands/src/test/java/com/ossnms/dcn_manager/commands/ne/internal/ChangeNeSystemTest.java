package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class ChangeNeSystemTest {

    private static final int CONTAINER_ID = 98;
    private static final int VERSION = 0;
    private static final int NE_ID = 1;

    private NeUserPreferencesRepository preferencesRepository;
    private NetworkElementNotifications notifications;
    private LoggerManager<CallContext> logger;
    private CallContext context;
    private NeEntityRepository neRepo;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        preferencesRepository = mock(NeUserPreferencesRepository.class);
        notifications = mock(NetworkElementNotifications.class);
        logger = mock(LoggerManager.class);

        neRepo = mock(NeEntityRepository.class);
        when(neRepo.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);

        context = mock(CallContext.class);
    }

    @Test
    public void call_emptyIdentifierMap_doesNothing() throws Exception {
        final ChangeNeSystem<CallContext> command =
                new ChangeNeSystem<>(context, neRepo, notifications, logger, Collections.emptyMap());

        command.call();

        verifyZeroInteractions(preferencesRepository, notifications, logger);
    }

    @Test
    public void call_repoErrorOnQuery_throws() throws Exception {

        when(preferencesRepository.query(anyInt())).thenThrow(new RepositoryException());

        final ChangeNeSystem<CallContext> command =
                new ChangeNeSystem<>(context, neRepo, notifications, logger,
                        ImmutableMap.of(NE_ID, Optional.empty()));
        try {
            command.call();
            fail("Should have thrown an exception on repo error.");
        } catch (final CommandException e) {
            // good. :)
        }

        verify(logger).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verify(preferencesRepository, never()).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));
        verifyZeroInteractions(notifications);
    }

    @Test
    public void call_neNotFound_ignores() throws Exception {

        when(preferencesRepository.query(anyInt())).thenReturn(Optional.empty());

        final ChangeNeSystem<CallContext> command =
                new ChangeNeSystem<>(context, neRepo, notifications, logger,
                        ImmutableMap.of(NE_ID, Optional.empty()));
        command.call();

        verifyZeroInteractions(notifications, logger);
        verify(preferencesRepository, never()).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void call_concurrentModificationError_fails() throws Exception {

        when(preferencesRepository.query(anyInt())).thenReturn(
                Optional.of(new NeUserPreferencesBuilder().setName("a").build(NE_ID, VERSION)));
        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class)))
                .thenReturn(Optional.empty());

        final ChangeNeSystem<CallContext> command =
                new ChangeNeSystem<>(context, neRepo, notifications, logger,
                        ImmutableMap.of(NE_ID, Optional.empty()));
        try {
            command.call();
            fail("Should have thrown an exception on concurrent update.");
        } catch (final CommandException e) {
            // good. :)
        }

        verify(logger).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verifyZeroInteractions(notifications);
    }

    @Test
    public void call_partialFailure_updatesSomeAndFails() throws Exception {
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor =
                ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        when(preferencesRepository.query(anyInt()))
            .thenReturn(Optional.of(new NeUserPreferencesBuilder().setName("a").build(NE_ID, VERSION)))
            .thenThrow(new RepositoryException());
        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class)))
                .then(new MutationAnswer<>());

        final ChangeNeSystem<CallContext> command =
                new ChangeNeSystem<>(context, neRepo, notifications, logger,
                        ImmutableMap.of(NE_ID, Optional.of(CONTAINER_ID), 56, Optional.empty()));
        try {
            command.call();
            fail("Should have thrown an exception on partial failure.");
        } catch (final CommandException e) {
            // good. :)
        }

        verify(logger, times(2)).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verify(notifications).notifyChanges(captor.capture());
        assertThat(captor.getValue().getContainerId(), hasValue(CONTAINER_ID));
        assertThat(captor.getValue().getResult().getId(), is(NE_ID));
    }

    @Test
    public void call_succeeds() throws Exception {
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> captor =
                ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        when(preferencesRepository.query(anyInt())).thenReturn(
                Optional.of(new NeUserPreferencesBuilder().setName("a").build(NE_ID, VERSION)));
        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class)))
                .then(new MutationAnswer<>());

        final ChangeNeSystem<CallContext> command =
                new ChangeNeSystem<>(context, neRepo, notifications, logger,
                        ImmutableMap.of(NE_ID, Optional.of(CONTAINER_ID)));
        command.call();

        verify(logger).createCommandLog(eq(context), isA(LoggerItemNe.class));
        verify(notifications).notifyChanges(captor.capture());
        assertThat(captor.getValue().getContainerId(), hasValue(CONTAINER_ID));
    }
}
