package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.events.ne.NeOperationInfoChangedEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static java.util.Collections.emptyMap;

/**
 * Handles updates to NE operational information received from the outside.
 * Will also notify mediation in case of updated NE name
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class UpdateNeOperationInfoEventHandler<C extends CallContext> extends EventHandler<C, NeOperationInfoChangedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateNeOperationInfoEventHandler.class);
    private final NeOperationRepository operationRepository;
    private final NetworkElementNotifications notifications;
    private final AppProperties appProperties;
    private final NeUserPreferencesRepository preferencesRepository;
    private final NeConnectionManager neConnectionManager;
    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NeEntityRepository neRepository;

    /**
     * Creates a new event handler instance.
     *
     * @param context              Call context information.
     * @param neRepository         Instance of the repository that allows us to update the internal model from the outside information.
     * @param notifications        Instance of adapter for notifications
     * @param appProperties        Installation time configuration settings.
     * @param neConnectionManager  Instance of connection manager that provides mediation calls
     * @param neInstanceRepository Repository of NE physical connection information
     */
    public UpdateNeOperationInfoEventHandler(
            @Nonnull C context,
            @Nonnull NeEntityRepository neRepository,
            @Nonnull NetworkElementNotifications notifications,
            @Nonnull AppProperties appProperties,
            @Nonnull NeConnectionManager neConnectionManager,
            @Nonnull NePhysicalConnectionRepository neInstanceRepository) {
        super(context);
        this.appProperties = appProperties;
        operationRepository = neRepository.getNeOperationRepository();
        preferencesRepository = neRepository.getNeUserPreferencesRepository();
        this.neRepository = neRepository;
        this.notifications = notifications;
        this.neConnectionManager = neConnectionManager;
        this.neInstanceRepository = neInstanceRepository;
    }

    @Override
    protected void handleEvent(@Nonnull NeOperationInfoChangedEvent event)
            throws UnknownNetworkElementIdException, DataUpdateException {

        try {

            queryAndUpdateNeOperation(event);

            if (appProperties.isAutoCopyNeNameEnabled()) {
                queryAndUpdateNePreferences(event);
            }

        } catch (final RepositoryException exception) {
            throw new DataUpdateException(exception);
        }
    }

    private void queryAndUpdateNePreferences(NeOperationInfoChangedEvent event)
            throws RepositoryException, DataUpdateException, UnknownNetworkElementIdException {
        final Optional<NeUserPreferencesData> nePreferences = preferencesRepository.query(event.getNeId());

        if (nePreferences.isPresent()) {

            updateNePreferences(nePreferences.get(), event);

        } else {
            throw new UnknownNetworkElementIdException("NE {} not found.", event.getNeId());
        }
    }

    private void queryAndUpdateNeOperation(NeOperationInfoChangedEvent event)
            throws RepositoryException, DataUpdateException, UnknownNetworkElementIdException {
        final Optional<NeOperationData> neOperation = operationRepository.query(event.getNeId());

        if (neOperation.isPresent()) {

            updateNeOperation(neOperation.get(), event);

        } else {
            throw new UnknownNetworkElementIdException("NE {} not found.", event.getNeId());
        }
    }

    private void updateNePreferences(NeUserPreferencesData neUserPreferencesData, NeOperationInfoChangedEvent event)
            throws RepositoryException, DataUpdateException {

        final String networkName = event.getRealNeName().orElse("");

        if (networkName.isEmpty()) {
            return;
        }

        final NeUserPreferencesMutationDescriptor preferencesMutation =
                new NeUserPreferencesMutationDescriptor(neUserPreferencesData)
                        .setName(networkName)
                        .whenApplied(mutation -> {
                            notifications.notifyChanges(mutation);
                            notifyMediator(event.getNeId(), mutation);
                        });
        if (!preferencesRepository.tryUpdate(preferencesMutation).isPresent()) {
            throw new DataUpdateException("Could not update NE Preferences Data to {}", preferencesMutation);
        }
    }

    private void notifyMediator(int neId, NeUserPreferencesMutationDescriptor mutation) {
        neEntity(neId).ifPresent(neEntity ->
                neInstanceRepository.queryAll(neId).forEach(connectionData ->
                        updateNeProperties(mutation, neEntity, connectionData)));
    }

    private void updateNeProperties(NeUserPreferencesMutationDescriptor mutation, NeEntity neEntity, NePhysicalConnectionData connectionData) {
        try {
            neConnectionManager.updateNeProperties(neEntity, connectionData, mutation, emptyMap());
        } catch (ConnectException e) {
            LOGGER.error("Failed to update NE properties on mediation", e);
        }
    }

    private Optional<NeEntity> neEntity(int neId) {
        try {
            return neRepository.queryNe(neId);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch ne entity from repository", e);
            return Optional.empty();
        }
    }

    private void updateNeOperation(NeOperationData neOperation, NeOperationInfoChangedEvent event)
            throws DataUpdateException, RepositoryException {
        final NeOperationMutationDescriptor operation = buildOperationMutation(neOperation);

        if (event.getRealNeName().isPresent()) {
            operation.setRealNeName(event.getRealNeName().get());
        }
        if (event.getNeighbourhoodId().isPresent()) {
            operation.setNeighbourhoodId(event.getNeighbourhoodId().get());
        }
        event.getLocation().ifPresent(operation::setLocation);

        updateOperationNeConfiguration(event, operation);

        updateOperationSoftwareVersions(event, operation);

        updateOperationTpGroups(event, operation);

        updateOperationNeTypes(event, operation);

        updateOperationNeTypeDescription(event, operation);

        if (!operationRepository.tryUpdate(operation).isPresent()) {
            throw new DataUpdateException("Could not update NE Operational Data to {}", operation);
        }
    }

    private void updateOperationNeConfiguration(NeOperationInfoChangedEvent event,
                                                final NeOperationMutationDescriptor operation) {
        if (event.getGatewayMode().isPresent()) {
            operation.setGatewayMode(event.getGatewayMode().get());
        }
        if (event.getEventForwardingActive().isPresent()) {
            operation.setEventForwardingActive(event.getEventForwardingActive().get());
        }
        if (event.getOperationalMode().isPresent()) {
            operation.setOperationalMode(event.getOperationalMode().get());
        }
        if (event.getWriteAccess().isPresent()) {
            operation.setWriteAccess(event.getWriteAccess().get());
        }
        if (event.getCommissioning().isPresent()) {
            operation.setCommissioning(event.getCommissioning().get());
        }
    }

    private NeOperationMutationDescriptor buildOperationMutation(NeOperationData neOperation) {
        return new NeOperationMutationDescriptor(neOperation)
                .whenApplied(notifications::notifyChanges);
    }

    private void updateOperationSoftwareVersions(NeOperationInfoChangedEvent event,
                                                 final NeOperationMutationDescriptor operation) {
        if (event.getMainRelease().isPresent()) {
            operation.setMainRelease(event.getMainRelease().get());
        }
        if (event.getMaintenanceRelease().isPresent()) {
            operation.setMaintenanceRelease(event.getMaintenanceRelease().get());
        }
    }

    private void updateOperationTpGroups(NeOperationInfoChangedEvent event,
                                         final NeOperationMutationDescriptor operation) {
        if (event.getTpGroupMask().isPresent()) {
            operation.setTpGroupMask(event.getTpGroupMask().get());
        }
        if (event.getTpGroupMode().isPresent()) {
            final TpGroupSettings groupSettings = event.getTpGroupMode().get();
            operation.setTpGroupMode(
                    groupSettings.isAlwaysCompatible(),
                    groupSettings.isMultipleGroupMembership(),
                    groupSettings.isSubgroupsMustBeEqual(),
                    groupSettings.isMultipleSubgroupMembership());
        }
    }

    private void updateOperationNeTypeDescription(NeOperationInfoChangedEvent event,
                                                  final NeOperationMutationDescriptor operation) {
        if (event.getNeSubTypeDescription().isPresent()) {
            operation.setNeSubTypeDescription(event.getNeSubTypeDescription().get());
        }
    }

    private void updateOperationNeTypes(NeOperationInfoChangedEvent event,
                                        final NeOperationMutationDescriptor operation) {
        if (event.getFamily().isPresent()) {
            operation.setFamily(event.getFamily().get());
        }
        if (event.getNeSubType().isPresent()) {
            operation.setNeSubType(event.getNeSubType().get());
        }
        if (event.getNeType().isPresent()) {
            operation.setNeType(event.getNeType().get());
        }
        if (event.getNeSpecificType().isPresent()) {
            operation.setNeSpecificType(event.getNeSpecificType().get());
        }
    }

}
