package com.ossnms.dcn_manager.events.base;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;

/**
 * Parameter object that holds references to all manager/publisher objects
 * that are commonly used together when handling Domain events.
 */
public final class DomainManagers {

    private final DomainRepository domainRepository;
    private final DomainNotifications domainNotifications;

    /**
     * Creates a new object.
     * @param domainRepository Domain repository.
     * @param domainNotifications Domain notification publisher.
     */
    public DomainManagers(
            @Nonnull DomainRepository domainRepository,
            @Nonnull DomainNotifications domainNotifications) {
        this.domainRepository = domainRepository;
        this.domainNotifications = domainNotifications;
    }

    /**
     * @return The Domain repository.
     */
    public DomainRepository getDomainRepository() {
        return domainRepository;
    }

    /**
     * @return The Domain notification publisher.
     */
    public DomainNotifications getDomainNotifications() {
        return domainNotifications;
    }

}
