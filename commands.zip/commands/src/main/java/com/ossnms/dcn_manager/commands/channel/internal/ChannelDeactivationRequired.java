package com.ossnms.dcn_manager.commands.channel.internal;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.channel.ChannelModificationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelInfoBehavior;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Optional;

import static com.google.common.collect.Iterables.isEmpty;
import static com.google.common.collect.Iterables.transform;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Command that requires the deactivation of a given channel. As with all other commands, instances are
 * immutable and all dependencies are injected through the constructor. Instances are not to be reused,
 * that is, for each incoming external stimulus an new instance is specifically created to deal with it.</p>
 *
 * <p> The activation state of a channel represents whether that channel is required to be active or not, for
 * network management purposes. Whenever a channel deactivation is required, it is set to the DeactivationRequired
 * state and the channel connection termination sequence is triggered (a.k.a. actual channel deactivation).
 * Although this sequence is not completely materialized in this command, due to the sequence's asynchronous nature,
 * it is described herein for clarity and depicted in the following figure. Note that the exact types and method names
 * may differ from the actual implementation: the diagram merely intends to provide an overview of the use-case. </p>
 *
 * <p> <figure>
 * <img src="doc-files/channel_deactivation_required-sequence.png">
 * <figcaption>Sequence diagram of the channel deactivation required use case</figcaption>
 * </figure> </p>
 *
 * As depicted, the command is responsible for the following sequence of actions
 * <ul>
 * 		<li> Fetch the data of the channel info domain object (steps 2 and 3) </li>
 * 		<li> Instantiate the behavioral dimension of the channel info domain object (steps 2 and 3) </li>
 * 		<li> Verify if all NEs reachable from through the channel are also in the DeactivationRequired state (steps 4 and 5) </li>
 * 		<li> Require deactivation of the obtained channel (steps 6 and 7) </li>
 * 		<li> Given the resulting state mutation, apply it to the entity (at the repository) (step 8) </li>
 * 		<li> When the mutation is successfully applied:
 * 			<ul>
 * 				<li> Create the corresponding event (step 9) </li>
 * 				<li> Schedule the channel's deactivation (step 10)</li>
 * 				<li> Dispatch the created event (send it out-bound) (step 11)</li>
 * 			 </ul>
 * 		</li>
 * </ul>
 *
 * <p>Notice that the depicted sequence assumes correct execution. If any error occurs, an exception is thrown.
 * In particular, if any of the command's pre-conditions fails. This decision is due to the observation that,
 * if any of those conditions fail, then there is a logical error on the application. We are therefore better
 * off reporting that error as soon as it is detected. </p>
 *
 * The command's pre-conditions are:
 * <ul>
 * 		<li> The target channel exists </li>
 * 		<li> The target channel is not in the DeactivationRequired state</li>
 * 		<li> All NEs reachable through the target channel are in the DeactivationRequired state. </li>
 * </ul>
 *
 * <p> A design decision that must be underlined is that the last pre-condition is expressed (and implemented)
 * as a pre-condition to the channel deactivation use-case, instead of being implemented on the corresponding
 * domain object. This decision is due to the fact that, trying to deactivate a channel that enables access
 * to activated NEs, is considered a usage error, and therefore it must be prevented at the use-case level.
 * From a domain perspective, it is plausible to admit that it could trigger the deactivation of the NEs. </p>
 *
 * @param <C>
 *            The concrete call context type
 */
/*
 * @startuml doc-files/channel_deactivation_required-sequence.png
 *
 * !definelong CALL_START(from,to,inMsg)
 * from -> to : inMsg
 * activate to
 * !enddefinelong
 *
 * !definelong CALL_END(from,to,outMsg)
 * from <-- to : outMsg
 * deactivate to
 * !enddefinelong
 *
 * !definelong CALL(from,to,inMsg,outMsg)
 * CALL_START(from,to,inMsg)
 * CALL_END(from,to,outMsg)
 * !enddefinelong
 *
 * !define CALL_ASYNC(from,to,msg) from ->> to : msg
 *
 * !definelong TRIGGER_CALL(from,to,inMsg)
 * from --\\ to : inMsg
 * activate to
 * !enddefinelong
 *
 * hide footbox
 * autonumber
 * boundary Connector
 *
 * participant ChannelDeactivationRequired << command >>
 * participant ChannelRepository << abstraction >>
 * participant "channelInfo: ChannelInfoBehavior" as ChannelInfo << domain object >>
 * participant "channelConnection: ChannelConnectionBehavior" as ChannelConnection << domain object >>
 * participant ChannelActivationManager << domain policy >>
 * participant EventDispatcher << abstraction >>
 *
 * activate Connector
 *
 * CALL_START(Connector,ChannelDeactivationRequired,call)
 * CALL(ChannelDeactivationRequired,ChannelRepository,findChannelInfo(channelId),channelInfo)
 * CALL(ChannelDeactivationRequired,ChannelRepository,verifyNEsState(channelId),ok)
 *
 * CALL(ChannelDeactivationRequired,ChannelConnection,shutdown(),mutation)
 * CALL_START(ChannelDeactivationRequired,ChannelRepository,tryUpdateChannelConnection(mutation))
 *
 * note right of ChannelConnection
 * The execution of the following sequence is not
 * actually performed on the ChannelInfo domain object
 * instance, although it's specified by it.
 * endnote
 *
 * TRIGGER_CALL(ChannelRepository,ChannelConnection,on sucess: mutation.applied())
 *
 * CALL_START(ChannelConnection, ChannelConnection, createEvent(mutation)\nshutdownEvent)
 * CALL_ASYNC(ChannelConnection,ChannelActivationManager,scheduleChannelDeactivation(shutdownEvent))
 * ref over ChannelActivationManager
 * Asynchronous continuation of the
 * channel deactivation use case
 * endref
 * CALL_ASYNC(ChannelConnection,EventDispatcher,notifyChanges(shutdownEvent))
 * ref over EventDispatcher
 * Event dispatching workflow
 * endref
 * deactivate ChannelConnection
 *
 * CALL_END(ChannelRepository,ChannelConnection, )
 * CALL_END(ChannelDeactivationRequired,ChannelRepository, )
 *
 * CALL(ChannelDeactivationRequired,ChannelInfo,deactivationRequired(),mutation)
 * CALL_START(ChannelDeactivationRequired,ChannelRepository,tryUpdateChannelInfo(mutation))
 *
 * note right of ChannelInfo
 * The execution of the following sequence is not
 * actually performed on the ChannelInfo domain object
 * instance, although it's specified by it.
 * endnote
 *
 * TRIGGER_CALL(ChannelRepository,ChannelInfo,on sucess: mutation.applied())
 *
 * CALL_START(ChannelInfo, ChannelInfo, createEvent(mutation)\ndeactivationRequiredEvent)
 * CALL_ASYNC(ChannelInfo,EventDispatcher,notifyChanges(deactivationRequiredEvent))
 * ref over EventDispatcher
 * Event dispatching workflow
 * endref
 * deactivate ChannelInfo
 *
 * CALL_END(ChannelRepository,ChannelInfo, )
 * CALL_END(ChannelDeactivationRequired,ChannelRepository, )
 *
 * CALL_END(Connector,ChannelDeactivationRequired, )
 *
 * deactivate Connector
 * deactivate ChannelActivationManager
 * @enduml
 */
public class ChannelDeactivationRequired<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(ChannelDeactivationRequired.class);

	/**
	 * Holds the target channel identifier.
	 */
	private final int channelId;

    /**
     * Holds a reference to a helper class with common methods.
     */
    private final ChannelModificationBase delegate;

	/**
	 * Holds a reference to the object responsible for triggering the actual channel connection
	 */
	private final ChannelInteractionManager connectionManager;

	/**
	 * Holds the reference to the component's event dispatcher
	 */
	private final ChannelNotifications eventDispatcher;

    /**
     * Holds the reference to the component responsible for logging operator actions
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds a reference to the repository containing Mediator data
     */
    private final MediatorEntityRepository mediatorRepository;

    /**
     * Holds a reference to the repository of NE entities.
     */
    private final NeEntityRepository neRepository;

    /**
     * Holds a reference to the repository of physical channel entity connection information.
     */
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;


	/**
	 * Instantiates the command with the given parameters
	 *
	 * @param context The call context
	 * @param channelId The channel identifier
     * @param channelManagers Channel management parameter object
     * @param mediatorRepository The mediator repository to be used
	 */
	public ChannelDeactivationRequired(@Nonnull final C context, final int channelId,
	        @Nonnull ChannelManagers channelManagers,
			@Nonnull final NeEntityRepository neRepository,
			@Nonnull final MediatorEntityRepository mediatorRepository,
			@Nonnull final LoggerManager<C> loggerManager) {
		super(context);
        this.channelId = channelId;
		this.connectionManager = channelManagers.getChannelActivationManager();
		this.eventDispatcher = channelManagers.getChannelNotifications();
		this.channelInstanceRepository = channelManagers.getChannelInstanceConnections();
        this.neRepository = neRepository;
        this.loggerManager = loggerManager;
        this.mediatorRepository = mediatorRepository;
        this.delegate = new ChannelModificationBase(channelManagers.getChannelRepository());
	}

	/**
	 * {@inheritDoc}
	 * @throws UnknownChannelIdException  Should the channel not exist.
     * @throws RepositoryException When an error occurs while working with the data source.
	 * @throws IllegalNetworkElementStateException If there are NEs underneath the Channel that are still required active.
	 * @throws IllegalChannelStateException If the channel is already inactive.
	 * @throws UnknownMediatorIdException
	 */
	@Override
	public final Void call() throws UnknownMediatorIdException, UnknownChannelIdException, RepositoryException, IllegalNetworkElementStateException, IllegalChannelStateException
	{
		// Get the channel info data instance, if one exists, and instantiate it's behavioral dimension
	    final ChannelEntity channelEntity = delegate.findChannel(channelId);

    	// Ensure that all NEs associated to the channel are already in the deactivation required state
		// This is a pre-condition for the execution of the command
        verifyNEsState(channelEntity.getConnectionState());


    	final MediatorInfoData mediatorInfoData = findMediator(channelEntity.getInfo());

        if (mediatorInfoData.isActivationRequired()) {
            final Iterable<ChannelPhysicalConnectionData> channelInstances =
                    channelInstanceRepository.queryAll(channelId);
            if (isEmpty(channelInstances)) {
                throw new UnknownChannelIdException();
            }
            channelInstances
                .forEach(data -> changeInstanceActualStateToShutdown(data, channelEntity.getInfo().getMediatorId()));
        }

    	changeRequiredStateToInactive(channelEntity.getInfo());

		loggerManager.createCommandLog(getContext(), new LoggerItemChannel(
                delegate.tryFindChannelName(channelId).orElse(String.valueOf(channelId)),
		        tr(Message.CHANNEL_DEACTIVATION)));

		return null;
	}

    private MediatorInfoData findMediator(final ChannelInfoData channelInfoData) throws UnknownMediatorIdException, RepositoryException {

        final Optional<MediatorInfoData> mediatorInfoData = mediatorRepository.getMediatorInfoRepository().query(channelInfoData.getMediatorId());
        if (!mediatorInfoData.isPresent()) {
            throw new UnknownMediatorIdException(tr(Message.MEDIATOR_DOES_NOT_EXIST, channelInfoData.getMediatorId()));
        }
        return mediatorInfoData.get();
    }

    private void changeInstanceActualStateToShutdown(ChannelPhysicalConnectionData data, int mediatorId) {
        try {
            final Optional<ChannelPhysicalConnectionMutationDescriptor> mutation =
                    new ChannelPhysicalConnectionBehavior(data, eventDispatcher)
                        .shutdown(connectionManager, new Deactivate(channelId, mediatorId, Collections.singleton(data.getId())));
            if (mutation.isPresent()) {
                final Optional<ChannelPhysicalConnectionData> result =
                        channelInstanceRepository.tryUpdate(mutation.get());
                if (!result.isPresent()) {
                    LOGGER.warn("Concurrent modification on channel instance connection {}.", mutation.get());
                }
            } else {
                LOGGER.warn("Could not deactivate physical channel instance with id {} already inactive.", data.getId());
            }
        } catch (final RepositoryException e) {
            LOGGER.error("Error deactivating physical channel instance {}: {}", data, Throwables.getStackTraceAsString(e));
        }
    }

    private void changeRequiredStateToInactive(final ChannelInfoData channelInfo)
            throws IllegalChannelStateException, RepositoryException {
        // Is this a valid Required State transition?
        final Optional<ChannelInfoMutationDescriptor> mutationDesc =
                new ChannelInfoBehavior(channelInfo)
                    .deactivationRequired(eventDispatcher,
                            transform(channelInstanceRepository.queryAll(channelInfo.getId()), ChannelPhysicalConnectionData::getId));
        if (!mutationDesc.isPresent()) {
            throw new IllegalChannelStateException(tr(Message.CHANNEL_ALREADY_INACTIVE));
        }
        // Could we persist the new Required State?
        // Because commands may be executed concurrently, update operations may fail (notice the
        // compound action queryChannel-updateChannelState). In this use case, though, retry is not required.
        // Instead, we want to report an exception because concurrent channel activation/deactivation requests should not
        // have been issued in the first place
        final Optional<ChannelInfoData> modifiedChannel = delegate.getChannelRepository().getChannelInfoRepository()
                .tryUpdate(mutationDesc.get());
        if(!modifiedChannel.isPresent()) {
            throw new IllegalChannelStateException(tr(Message.CHANNEL_ALREADY_INACTIVE));
        }
    }
/*
    private void changeActualStateToShutDown(final ChannelConnectionData connectionData, final int mediatorId)
            throws IllegalChannelStateException, RepositoryException {
        // Is this a valid Actual State transition?
        final Optional<ChannelConnectionMutationDescriptor> connectionMutation =
            new ChannelConnectionBehavior(connectionData, eventDispatcher)
                .shutdown(connectionManager, new Deactivate(channelId, mediatorId,
                    transform(channelInstanceRepository.queryAll(connectionData.getId), ChannelPhysicalConnectionData::getId)));
        if (!connectionMutation.isPresent()) {
            return; // channel already shut down
        }
        // Could we persist the new Actual State?
        // Because commands may be executed concurrently, update operations may fail (notice the
        // compound action queryChannel-updateChannelState). In this use case, though, retry is not required.
        // Instead, we want to report an exception because concurrent channel activation/deactivation requests should not
        // have been issued in the first place
        final Optional<ChannelConnectionData> updatedData = delegate.getChannelRepository()
                .getChannelConnectionRepository().tryUpdate(connectionMutation.get());
        if (!updatedData.isPresent()) {
            throw new IllegalChannelStateException(tr(Message.CHANNEL_ALREADY_INACTIVE));
        }
    }
*/
    /**
     * Helper method that verifies if all the channel's NEs are in the expected state
     * @throws RepositoryException When an error occurs while working with the data source.
     * @throws IllegalNetworkElementStateException If there are NEs underneath the Channel that are still required active.
     */
    private void verifyNEsState(ChannelConnectionData channelConnectionData) throws IllegalNetworkElementStateException, RepositoryException {
        boolean noConnection = !channelConnectionData.isActive() || channelConnectionData.isFailed();
        if (!noConnection && !isEmpty(neRepository.queryActivationRequiredIs(channelId, RequiredActivationState.ACTIVE))) {
            throw new IllegalNetworkElementStateException(tr(Message.NE_STILL_ACTIVE));
        }
    }

}
