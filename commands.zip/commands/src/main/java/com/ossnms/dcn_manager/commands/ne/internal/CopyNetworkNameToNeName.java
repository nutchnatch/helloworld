package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Copies known network names into the NE name of each NE.</p>
 *
 * <p>Unknown NE identifiers and NEs without network names or with network names that are equal to the NE
 * names will be silently ignored.</p>
 * <p>Should an operation fail due to a database error on a given NE, it will be skipped and execution
 * will continue with the next NE on the collection.</p>
 * <p>Successful changes and failures are reported to the Command Log.</p>
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class CopyNetworkNameToNeName<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(CopyNetworkNameToNeName.class);

    private final Iterable<Integer> neIdentifiers;

    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NeOperationRepository operationRepository;
    private final NeEntityRepository neRepository;
    private final NetworkElementNotifications notifications;
    private final NeConnectionManager neConnectionManager;
    private final LoggerManager<C> logger;
    private final NeUserPreferencesRepository preferencesRepository;

    public CopyNetworkNameToNeName(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull NeConnectionManager connectionManager,
            @Nonnull NeEntityRepository neRepository,
            @Nonnull NetworkElementNotifications notifications,
            @Nonnull LoggerManager<C> logger,
            @Nonnull Iterable<Integer> neIdentifiers) {
        super(context);
        operationRepository = neRepository.getNeOperationRepository();
        preferencesRepository = neRepository.getNeUserPreferencesRepository();
        this.neRepository = neRepository;
        this.notifications = notifications;
        this.logger = logger;
        this.neIdentifiers = neIdentifiers;
        neConnectionManager = connectionManager;
        neInstanceRepository = neManagers.getNeInstanceRepository();
    }

    @Override
    public Void call() throws CommandException {
        boolean allNamesCopiedOk = true;

        for (final Integer neId : neIdentifiers) {
            final OperationResult copyResult = copyNetworkNameToNeName(neId);
            allNamesCopiedOk &= copyResult == OperationResult.SUCCESS;
        }

        if (!allNamesCopiedOk) {
            throw new CommandException(tr(Message.SOME_NETWORK_NAME_COPIES_FAILED));
        }

        return null;
    }
    
    private OperationResult copyNetworkNameToNeName(final Integer neId) {
        OperationResult result = OperationResult.SUCCESS;
        try {
            final Optional<NeOperationData> operation = operationRepository.query(neId);
            if (operation.isPresent() && operation.get().getRealNeName().isPresent()) {
                final Optional<NeEntity> neEntity = neRepository.queryNe(neId);
                final Optional<NeUserPreferencesData> preferences = Optional.ofNullable(neEntity.get().getPreferences());
                if (preferences.isPresent() && !Objects.equals(preferences.get().getName(), operation.get().getRealNeName().get())) {
                    final NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(preferences.get());
                    mutation.setName(operation.get().getRealNeName().get());
                    mutation.whenApplied(in -> {
                        try {
                            notifications.notifyChanges(in);
                            Optional<NeEntity> neEntityUpdated = neRepository.queryNe(neId);
                            neInstanceRepository.queryAll(neId)
                            .forEach(physicalConnection -> sendPropertiesToMediator(
                                    neEntityUpdated.get(), in, physicalConnection));
                            logResult(neId, preferences.get().getName(), OperationResult.SUCCESS,
                                    operation.get().getRealNeName().get());
                        } catch (final RepositoryException exception) {
                            LOGGER.error("Could not copy network name for NE {}: {} {}", neId,
                                    exception.getMessage(), Throwables.getStackTraceAsString(exception));
                            logResult(neId, "NE="+ neId, OperationResult.FAILURE);
                        }                   
                    });
                    final Optional<NeUserPreferencesData> updatedPreferences = preferencesRepository.tryUpdate(mutation);
                    if (!updatedPreferences.isPresent()) {
                        result = OperationResult.FAILURE;
                        LOGGER.warn("Could not copy network name for NE {}, '{}': concurrent modification detected.",
                                neId, preferences.get().getName());
                        logResult(neId, preferences.get().getName(), result);
                    }
                }
            }
        } catch (final RepositoryException exception) {
            LOGGER.error("Could not copy network name for NE {}: {} {}", neId,
                    exception.getMessage(), Throwables.getStackTraceAsString(exception));
            result = OperationResult.FAILURE;
            logResult(neId, "NE="+ neId, result);
        }
        return result;
    }

    
    private void sendPropertiesToMediator(NeEntity ne, NeUserPreferencesMutationDescriptor newPreferences, NePhysicalConnectionData connection) {
        if (!connection.isActiveState()) {
            return;
        }
        try {
            neConnectionManager.updateNeProperties(ne, connection, newPreferences, Collections.emptyMap());
        } catch (final ConnectException e) {
            LOGGER.warn("CopyNetworkNameToNeName: NE instance was connected but updating the NE name property on the mediation failed: {}",
                    connection);
            if (connection.isActive()) {
                logResult(ne.getInfo().getId(), "NE="+newPreferences.getResult().getName(), OperationResult.FAILURE);
            }
        }
    }
    
    
    private void logResult(int neId, String neName, OperationResult outcome, Object... messageParameters) {
        final String messageText =
            tr(outcome == OperationResult.SUCCESS ? Message.NETWORK_NAME_COPIED : Message.NETWORK_NAME_COPY_FAILED, messageParameters);
        final LoggerItem logItem = new LoggerItemNe(neName, messageText, neId,
            outcome == OperationResult.SUCCESS ? MessageSeverity.INFO : MessageSeverity.WARNING);
        logger.createCommandLog(getContext(), logItem);
    }

    private enum OperationResult {
        SUCCESS, FAILURE
    }
}
