package com.ossnms.dcn_manager.events.discovery;

import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.functions.Func1;

import java.util.Optional;

final class ChannelSupportsDiscovery
        implements Func1<Pair<Optional<ChannelInfoData>, NeDiscoveredEvent>, Boolean> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelSupportsDiscovery.class);

    private final StaticConfiguration configuration;

    public ChannelSupportsDiscovery(StaticConfiguration configuration) {
        this.configuration = configuration;
    }

    @Override
    public Boolean call(Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> data) {
        final ChannelInfoData channelInfo = data.getLeft().get();
        final ChannelType channelType = configuration.getChannelTypes().get(channelInfo.getType());
        if (channelType.supportsDiscovery()) {
            return true;
        } else {
            final NeDiscoveredEvent event = data.getRight();
            LOGGER.info("NE is from a Channel type that does not support discovery. Channel type {} with ChannelId={} NeId={} RealNeName={}",
                    channelInfo.getType(), channelInfo.getId(),
                    event.getIdReceived(), event.getNameReceived());
            return false;
        }
    }
}