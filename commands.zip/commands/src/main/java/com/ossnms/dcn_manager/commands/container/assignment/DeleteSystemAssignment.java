package com.ossnms.dcn_manager.commands.container.assignment;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainerValidator;
import com.ossnms.dcn_manager.composables.container.ContainersSystemAssignmentUpdater;
import com.ossnms.dcn_manager.composables.container.SystemAssignmentOperations;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Delete a System Assignment.
 */
public class DeleteSystemAssignment<C extends CallContext> extends Command<C, Void> {

    private final SystemInfo systemInfo;
    private final SystemAssignmentData assignment;
    private final SystemAssignmentOperations<C> operationsBase;
    private final ContainerRepository containerRepository;
    private final ContainerValidator validator;
    private final ContainersSystemAssignmentUpdater<C> updater;
    private final SettingsRepository settingsRepository;
    private final C context;
    private final LoggerManager<C> loggerManager;

    public DeleteSystemAssignment(
            @Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final SystemRepository systemRepository,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final SystemInfo systemInfo,
            @Nonnull final SystemAssignmentData assignment,
            @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.systemInfo = systemInfo;
        this.assignment = assignment;
        this.containerRepository = containerRepository;
        this.settingsRepository = settingsRepository;
        this.context = context;
        this.loggerManager = loggerManager;

        this.updater = new ContainersSystemAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications,
                loggerManager, context);
        this.validator = new ContainerValidator(containerRepository, systemRepository);
        this.operationsBase = new SystemAssignmentOperations<>(containerRepository, containerNotifications,
                loggerManager, context);
    }

    @Override public Void call() throws CommandException {
        try {
            final boolean lastSystemAssignment = validator.isLastSystemAssignment(assignment);

            if (lastSystemAssignment) {
                defaultIsTheLastAssignment();
            } else {
                if (assignment.getAssignmentType() == AssignmentType.PRIMARY) {
                    tryReassignPrimaryContainer();
                }
                operationsBase.delete(systemInfo, assignment);
            }
        } catch (RepositoryException e) {
            throw new CommandException(e);
        }
        return null;
    }

    private void defaultIsTheLastAssignment() throws RepositoryException {
        if (!settingsRepository.getSettings().getDefaultContainerName().equals(assignment.getContainerInfo().getName())) {
            updater.defaultSystemAssignment(systemInfo);
            operationsBase.delete(systemInfo, assignment);
        } else {
            loggerManager.createSystemEventLog(context,
                    new LoggerItemContainer(assignment.getContainerInfo().getName(), tr(Message.CANNOT_DELETE_DEFAULT_ASSOCIATION)));
        }
    }

    private void tryReassignPrimaryContainer() {
        final Iterable<SystemAssignmentData> systemAssignmentDatas = containerRepository.queryAllBySystem(assignment.getSystemContainerId());

        StreamSupport.stream(systemAssignmentDatas.spliterator(), false)
                .filter(a -> a.getAssignmentType() != AssignmentType.PRIMARY).findFirst().ifPresent(newPrimary -> {
            try {
                operationsBase.update(systemInfo,
                        new SystemAssignmentData(newPrimary.getContainerInfo(), newPrimary.getSystemContainerId(),
                                AssignmentType.PRIMARY));
            } catch (RepositoryException e) {
                Throwables.propagate(e);
            }
        });
    }
}
