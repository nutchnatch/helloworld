package com.ossnms.dcn_manager.commands.ne.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.NeAccessControlManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.exception.AccessControlException;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Template with common behavior for Network Element Access and Control Commands.
 * 
 * @see NeAccessControlManager
 *  
 * @param <C> Current context
 */
abstract class AccessControlCommandTemplate<C extends CallContext> extends Command<C, Void>{
    private static final Logger LOGGER = LoggerFactory.getLogger(AccessControlCommandTemplate.class);

    private final LoggerManager<C> loggerManager;
    private final NeEntityRepository repository;
    private final NeAccessControlManager<C> accessControlManager;
    private final Integer neId;

    public AccessControlCommandTemplate(@Nonnull final C context,
            @Nonnull final NeAccessControlManager<C> accessControlManager,
            @Nonnull final NeEntityRepository repository, @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull Integer neId) {
        super(context);
        this.repository = repository;
        this.loggerManager = loggerManager;
        this.accessControlManager = accessControlManager;
        this.neId = neId;
    }
    
    public abstract String getCommandLogSuccessMessage();        
    public abstract String getCommandLogErrorMessage();
    public abstract void callAccessControlCommand() throws AccessControlException;

    @Override
    public Void call() throws CommandException, RepositoryException {

        final Optional<NeUserPreferencesData> ne = repository.getNeUserPreferencesRepository().query(neId);
        if (!ne.isPresent()) {
            throw new CommandException("NE={} not present in DCN.", neId);
        }

        final String neName = ne.get().getName();
        String message = getCommandLogSuccessMessage();

        try {
            callAccessControlCommand();
        } catch (final AccessControlException e) {
            message = getCommandLogErrorMessage();
            LOGGER.error(message + " for NE=" + neName, e);
        }

        loggerManager.createCommandLog(getContext(), new LoggerItemNe(neName, message, neId));
        
        return null;
    }

    public NeAccessControlManager<C> getAccessControlManager() {
        return accessControlManager;
    }

    public Integer getNeId() {
        return neId;
    }
}
