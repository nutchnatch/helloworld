package com.ossnms.dcn_manager.commands.ne.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static org.slf4j.LoggerFactory.getLogger;


public class ActivateNeOnStandby<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(ActivateNeOnStandby.class);

    /**
     * Holds the reference to the repository of NE instances
     */
    private final NeEntityRepository neEntityRepository;

    /**
	 * Holds a reference to the object responsible for implementing the NE activation policy
	 */
	private final NetworkElementInteractionManager neActivationManager;

	/**
	 * Holds the reference to the component's event dispatcher
	 */
	private final NetworkElementNotifications neNotifications;

	/**
	 * Holds the target channel identifier.
	 */
    private final int neId;

    /**
     * Holds the reference to the component responsible for logging operator commands
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds the reference to the repository of physical NE connection instances
     */
    private final NePhysicalConnectionRepository nePhysicalConnectionRepository;
    
    /**
     * Holds the reference to the settings repository
     */
    private final SettingsRepository settingsRepository;
    
    /**
     * Holds the reference to the channel repository
     */
    private final ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    

    /**
	 * Instantiates the command with the given parameters
	 *
	 * @param context The call context
	 * @param neId The NE identifier
	 * @param neManagers object that holds references to all manager/publisher objects that are commonly used together when handling NE events.
	 * @param loggerManager reference to the component responsible for logging operator commands
	 */
	public ActivateNeOnStandby(@Nonnull C context, int neId,
            @Nonnull NetworkElementManagers networkElementManagers,
            @Nonnull ChannelManagers channelManagers,
			@Nonnull LoggerManager<C> loggerManager,
			@Nonnull SettingsRepository settingsRepository) {
		super(context);
        this.neId = neId;
		this.neActivationManager = networkElementManagers.getNeActivationManager();
        this.nePhysicalConnectionRepository = networkElementManagers.getNeInstanceRepository();
		this.neNotifications = networkElementManagers.getNeNotifications();
        this.loggerManager = loggerManager;
        this.settingsRepository = settingsRepository;
		this.neEntityRepository = networkElementManagers.getNeRepository();
		this.channelPhysicalConnectionRepository = channelManagers.getChannelInstanceConnections();
	}

	/**
	 * {@inheritDoc}
	 * @throws RepositoryException When an error occurs while working with the data source.
	 * @throws UnknownNetworkElementIdException When an activation is being requested with an invalid NE ID.
	 * @throws IllegalNetworkElementStateException If the NE is already activated.
	 */
	@Override
	public final Void call() throws UnknownNetworkElementIdException, RepositoryException, IllegalNetworkElementStateException, CommandException	{

		String networkElementName = "NE";
		
		Optional<NeUserPreferencesData> neOptional = neEntityRepository.getNeUserPreferencesRepository().query(neId);
		if(neOptional.isPresent()) {
			networkElementName = neOptional.get().getName();
		}

		LOGGER.debug("Activate NE on standby mode, NE ID={}, name={} ", neId, networkElementName );
		
		if(settingsRepository.areStandbyConnectionsAllowed()) {
			StreamSupport.stream(nePhysicalConnectionRepository.queryAll(neId).spliterator(), false).
	    		filter(data ->  ! data.isActive() && ! data.isActiveState()).
	    		forEach(this::activateNetworkElementInstance);

			loggerManager.createCommandLog(getContext(), new LoggerItemNe(networkElementName, "Activate NE on hot standby mode.", neId));
		}
		else {
			loggerManager.createCommandLog(getContext(), new LoggerItemChannel(networkElementName, "Skipping NE activation on hot standby mode. Server is not assigned."));
			LOGGER.warn("Activate NE {} on hot standby mode command issued but hot standby mediation connections won't be established since server is not assigned.", networkElementName);
		}
		return null;
	}
	
    private void activateNetworkElementInstance(NePhysicalConnectionData connection) {
    	
    	int mediatorInstanceId = 0;

    	try {
        	Optional<ChannelPhysicalConnectionData> channelPhysicalConnection = channelPhysicalConnectionRepository.query(connection.getChannelInstanceId());
        	
        	if(channelPhysicalConnection.isPresent()) {
        		mediatorInstanceId = channelPhysicalConnection.get().getMediatorInstanceId();
        	}
        	else {
        		LOGGER.info("Transition to STARTING UP of Physical NE Connection {} was not possible.", connection);
        		return;
        	}
    	} 
    	catch (final RepositoryException exception) {
        	LOGGER.error("NE activation on {} failed: {} {}", connection,
                    exception.getMessage(), getStackTraceAsString(exception));
        }
    	
        final Optional<NePhysicalConnectionMutationDescriptor> neMutation =
            new NePhysicalConnectionBehavior(connection, neNotifications)
                .startUp(neActivationManager,mediatorInstanceId);
        if (neMutation.isPresent()) {
            try {
                final Optional<NePhysicalConnectionData> neUpdatedConnection =
                		nePhysicalConnectionRepository.tryUpdate(neMutation.get());
                if (!neUpdatedConnection.isPresent()) {
                	LOGGER.info("Activation of Physical Connection of NE {} was not possible.", connection);
                }
            } catch (final RepositoryException exception) {
            	LOGGER.error("NE activation on {} failed: {} {}", connection,
                        exception.getMessage(), getStackTraceAsString(exception));
            }
        } else {
        	LOGGER.info("Transition to STARTING UP of Physical NE Connection {} was not possible.", connection);
        }
    }


}
