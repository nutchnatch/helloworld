package com.ossnms.dcn_manager.commands.channel;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * Retrieves all existing channels from the repository.
 *
 * <img src="doc-files/getallchannels-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getallchannels-sequence.png
 * GetChannel --> ChannelEntityRepository : queryAll()
 * activate ChannelEntityRepository
 * ChannelEntityRepository --> GetChannel : channels
 * deactivate ChannelEntityRepository
 * @enduml
 */
public class GetAllChannels<C extends CallContext> extends Command<C, Iterable<ChannelEntity>> {

    private final ChannelEntityRepository repository;

    public GetAllChannels(@Nonnull C context, @Nonnull ChannelEntityRepository repository) {
        super(context);
        this.repository = repository;
    }

    @Override
    public Iterable<ChannelEntity> call() throws CommandException {
        try {
            return repository.queryAll();
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
    }

}
