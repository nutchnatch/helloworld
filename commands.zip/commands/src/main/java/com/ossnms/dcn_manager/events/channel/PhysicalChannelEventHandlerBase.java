package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

abstract class PhysicalChannelEventHandlerBase<C extends CallContext, P extends PhysicalChannelStateEvent, L extends ActualChannelStateEvent>
        extends EventHandler<C, P> {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final ChannelManagers channelManagers;

    public PhysicalChannelEventHandlerBase(@Nonnull C context,
            @Nonnull ChannelManagers channelManagers) {
        super(context);
        this.channelManagers = channelManagers;
    }

    @Override
    protected final void handleEvent(P event) throws DcnManagerException {
        final ChannelPhysicalConnectionData channelConnectionState = findChannelPhysicalConnectionState(event.getChannelId());
        final ChannelPhysicalConnectionBehavior state = new ChannelPhysicalConnectionBehavior(channelConnectionState, channelManagers.getChannelNotifications());
        final Optional<ChannelPhysicalConnectionMutationDescriptor> mutation = produceMutation(event, state, channelManagers);
        if (mutation.isPresent()) { // state changes to the same state are no-ops
            final Optional<ChannelPhysicalConnectionData> updatedConnection =
                    channelManagers.getChannelInstanceConnections().tryUpdate(mutation.get());
            if (updatedConnection.isPresent()) {
                if (channelConnectionState.isActive()) { // forward event to the logical entity if this is the active instance.
                    channelManagers.getChannelEvents().push(
                            produceForwardingEvent(event, channelConnectionState));
                }
                onMutationApplied(updatedConnection.get(), state, channelManagers);
            } else {
                logger.error("Concurrent modification of Physical Channel {} state. Not applied: {}", channelConnectionState.getId(), mutation.get());
            }
        } else {
            logger.warn("Dropping event because Physical Channel {} is already in state {}.",
                    channelConnectionState.getId(), channelConnectionState.getActualActivationState());
        }
    }

    /**
     * Tries to find the physical communications state of the target channel in the repository.
     *
     * @return An instance of a physical channel communications state.
     * @throws UnknownChannelIdException If the channel can not be found.
     * @throws RepositoryException If some error occurred while working with the repository.
     */
    public ChannelPhysicalConnectionData findChannelPhysicalConnectionState(int instanceId) throws UnknownChannelIdException, RepositoryException {
        final Optional<ChannelPhysicalConnectionData> state = channelManagers.getChannelInstanceConnections().query(instanceId);
        if (!state.isPresent()) {
            throw new UnknownChannelIdException(tr(Message.CHANNEL_DOES_NOT_EXIST, instanceId));
        }
        return state.get();
    }

    protected Logger getLogger() {
        return logger;
    }

    protected abstract Optional<ChannelPhysicalConnectionMutationDescriptor> produceMutation(
            P event, ChannelPhysicalConnectionBehavior state, ChannelManagers channelManagers);

    protected abstract L produceForwardingEvent(P event, ChannelPhysicalConnectionData channelConnectionState);


    /**
     * Extension point to allow implementing classes to run extra behavior after the entity state has been updated.
     * @param updatedPhysicalConnection Physical connection data as updated by the state change.
     * @param state Physical connection behavioral dimension.
     * @param channelManagers Parameter object with all channel entity managers.
     */
    protected void onMutationApplied(ChannelPhysicalConnectionData updatedPhysicalConnection,
            ChannelPhysicalConnectionBehavior state, ChannelManagers channelManagers) {

    }

}
