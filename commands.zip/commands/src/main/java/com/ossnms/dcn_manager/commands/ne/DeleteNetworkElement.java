package com.ossnms.dcn_manager.commands.ne;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeDomainsUpdater;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.domain.DomainChildrenChanged;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationDeleted;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Deletes an existing Network Element.
 * Exceptions will be thrown upon execution if the Network Element can not be deleted.
 *
 * <img src="doc-files/deletenecmd-activity.png">
 * <img src="doc-files/deletenecmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/deletenecmd-activity.png
 * start
 * if (NE is active?) then (fail)
 * else
 *   :Remove NE from its domains;
 *   :Delete NE from repository;
 *   :Produce deletion notifications;
 *   :Produce log entries;
 * endif
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/deletenecmd-sequence.png
 * DeleteNetworkElement --> NeEntityRepository : findMediator(mediatorId)
 * activate NeEntityRepository
 * NeEntityRepository --> DeleteNetworkElement : ne
 * deactivate NeEntityRepository
 * alt If Network Element deletion is allowed
 * DeleteNetworkElement --> DomainRepository : removeNe(ne)
 * DeleteNetworkElement --> NetworkElementRepository : delete(ne)
 * DeleteNetworkElement --> Notifications : notifyDelete(ne)
 * DeleteNetworkElement --> LoggerManager : createCommandLog(...)
 * end
 * @enduml
 */
public class DeleteNetworkElement<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteNetworkElement.class);

    private final DomainRepository domainRepository;
    private final LoggerManager<C> loggerManager;
    private final NeEntityRepository neRepository;
    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NetworkElementNotifications notifications;
    private final DomainNotifications domainNotifications;
    private final SettingsRepository settingsRepository;
    
    private final int neId;


    public DeleteNetworkElement(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull DomainRepository domainRepository,
            @Nonnull DomainNotifications domainNotifications,
            @Nonnull SettingsRepository settingsRepository,
            @Nonnull LoggerManager<C> loggerManager,
            int neId) {
        super(context);
        neRepository = neManagers.getNeRepository();
        notifications = neManagers.getNeNotifications();
        neInstanceRepository = neManagers.getNeInstanceRepository();
        this.domainRepository = domainRepository;
        this.domainNotifications = domainNotifications;
        this.loggerManager = loggerManager;
        this.settingsRepository = settingsRepository;
        this.neId = neId;
    }

    @Override
    public Void call() throws RepositoryException, IllegalNetworkElementStateException {
        final Optional<NeEntity> ne = neRepository.queryNe(neId);
        if (!ne.isPresent()) {
            return null;
        }

        final NeEntity neEntity = ne.get();

        throwOnNetworkElementDeletionForbidden(neEntity);

        delete(neEntity.getInfo());

        logAndNotify(neEntity);

        return null;
    }

    private void logAndNotify(NeEntity neEntity) {
        notifications.notifyDelete(neEntity);

        LOGGER.info("Delete NE: NE Id={} Name={} was deleted.",
                neId, neEntity.getPreferences().getName());

        loggerManager.createCommandLog(getContext(),
                new LoggerItemNe(neEntity.getPreferences().getName(), "NE object deleted", neId));
    }

    private void delete(NeInfoData neInfo) throws RepositoryException {

        final NeDomainsUpdater domainsUpdater = new NeDomainsUpdater(domainRepository, domainNotifications, settingsRepository);

        for (final DomainInfoData domainInfo : domainRepository.queryAllForNE(neId)) {
            // if we can't remove the NE from the domain, it only means that the association (or the domain) no longer exist.
            final boolean removedTransitiveDomainMembership = domainRepository.tryRemoveTransitiveNE(domainInfo.getId(), neId);
            final boolean removedNaturalDomainMembership = domainRepository.tryRemoveNaturalNE(domainInfo.getId(), neId);
            if ((removedTransitiveDomainMembership || removedNaturalDomainMembership) && !domainsUpdater.tryDeleteDomainIfEmpty(domainInfo)) {
                final Iterable<Integer> childrenNEs = domainRepository.queryChildrenNEs(domainInfo.getId());
                final DomainChildrenChanged event = new DomainChildrenChanged(domainInfo,
                        ImmutableList.copyOf(childrenNEs));
                domainNotifications.notifyChanges(event);
                domainNotifications.notifyChanges(new DomainParticipationDeleted(domainInfo.getId(), neId));
            }
        }

        neRepository.delete(new NeDeleteDescriptor(neInfo.getId()));

        neInstanceRepository.queryAll(neInfo.getId())
            .forEach(neInstance -> neInstanceRepository.remove(neInstance.getId()));
    }

    private void throwOnNetworkElementDeletionForbidden(NeEntity ne) throws IllegalNetworkElementStateException {

        if (ne.getInfo().isActive()) {
            throw new IllegalNetworkElementStateException("NE {} with ID {} is still required to be active.",
                    ne.getPreferences().getName(), ne.getInfo().getId());
        }

        if (ne.getConnection().getActivationState() != ActualActivationState.DISCONNECTED) {
            throw new IllegalNetworkElementStateException("NE {} with ID {} is still active/connected.",
                    ne.getPreferences().getName(), ne.getInfo().getId());
        }

    }

}
