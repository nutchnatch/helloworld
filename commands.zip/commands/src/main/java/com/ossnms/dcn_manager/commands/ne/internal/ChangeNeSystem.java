package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Changes, or removes, the association of an NE to a DCN Container.</p>
 *
 * <p><img src="doc-files/change-ne-container.png" /></p>
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/change-ne-container.png
 *
 * participant ChangeNeContainer << command >>
 * participant NeUserPreferencesRepository << abstraction >>
 * participant "mutation: NeUserPreferencesMutationDescriptor" as NeUserPreferencesMutationDescriptor << domain object >>
 * participant NetworkElementNotifications << abstraction >>
 * participant LoggerManager << abstraction >>
 *
 * ChangeNeContainer -> NeUserPreferencesRepository: query(id)
 * activate NeUserPreferencesRepository
 * NeUserPreferencesRepository -> ChangeNeContainer: userPreferences
 * deactivate NeUserPreferencesRepository
 *
 * ChangeNeContainer -> ChangeNeContainer: changeContainerId(userPreferences): mutation
 *
 * ChangeNeContainer -> NeUserPreferencesRepository: tryUpdate(mutation)
 * activate NeUserPreferencesRepository
 *
 * NeUserPreferencesRepository -> NeUserPreferencesMutationDescriptor: applied()
 * activate NeUserPreferencesMutationDescriptor
 * NeUserPreferencesMutationDescriptor -> NetworkElementNotifications: notifyChanges(mutation)
 * NeUserPreferencesMutationDescriptor -> LoggerManager: createCommandLog()
 * deactivate NeUserPreferencesMutationDescriptor
 *
 * NeUserPreferencesRepository -> ChangeNeContainer: mutatedPreferences
 * deactivate NeUserPreferencesRepository
 *
 * @enduml
 */
public class ChangeNeSystem<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(ChangeNeSystem.class);

    private final Map<Integer, Optional<Integer>> associations;

    private final NeUserPreferencesRepository preferencesRepository;
    private final NetworkElementNotifications notifications;
    private final LoggerManager<C> logger;

    public ChangeNeSystem(@Nonnull C context,
                          @Nonnull NeEntityRepository repository,
                          @Nonnull NetworkElementNotifications notifications,
                          @Nonnull LoggerManager<C> logger,
                          @Nonnull Map<Integer, Optional<Integer>> associations) {
        super(context);
        preferencesRepository = repository.getNeUserPreferencesRepository();
        this.notifications = notifications;
        this.logger = logger;
        this.associations = associations;
    }

    @Override
    public Void call() throws CommandException {
        boolean allAssociationsChanged = true;

        for (final Entry<Integer, Optional<Integer>> association : associations.entrySet()) {
            final boolean result = associateNeWithSystem(association.getKey(), association.getValue());
            allAssociationsChanged &= result;
        }

        if (!allAssociationsChanged) {
            throw new CommandException(tr(Message.SOME_NETWORK_NAME_COPIES_FAILED));
        }

        return null;
    }

    private boolean associateNeWithSystem(final Integer neId, final Optional<Integer> systemId) {
        boolean result = false;
        try {
            final Optional<NeUserPreferencesData> preferences = preferencesRepository.query(neId);
            if (preferences.isPresent()) {
                final NeUserPreferencesMutationDescriptor mutation =
                    new NeUserPreferencesMutationDescriptor(preferences.get())
                        .setContainerId(systemId)
                        .whenApplied(in -> {
                            notifications.notifyChanges(in);
                            logResult(neId, in.getResult().getName(), true);
                        });
                final Optional<NeUserPreferencesData> updated = preferencesRepository.tryUpdate(mutation);
                if (updated.isPresent()) {
                    result = true;
                } else {
                    LOGGER.warn("Could not change NE {} container to {}: concurrent modification detected.",
                            neId, systemId);
                    logResult(neId, preferences.get().getName(), result);
                }
            } else {
                result = true; // we want to ignore unknown NE identifiers.
            }
        } catch (final RepositoryException exception) {
            LOGGER.error("Could not change NE {} container: {} {}", neId,
                    exception.getMessage(), Throwables.getStackTraceAsString(exception));
            logResult(neId, "NE="+ neId, result);
        }
        return result;
    }

    private void logResult(int neId, String neName, boolean operationSucceeded, Object... messageParameters) {
        final String messageText =
            tr(operationSucceeded ? Message.CONTAINER_CHANGED : Message.CONTAINER_CHANGE_FAILED, messageParameters);
        final LoggerItem logItem = new LoggerItemNe(neName, messageText, neId,
            operationSucceeded ? MessageSeverity.INFO : MessageSeverity.WARNING);
        logger.createCommandLog(getContext(), logItem);
    }

}
