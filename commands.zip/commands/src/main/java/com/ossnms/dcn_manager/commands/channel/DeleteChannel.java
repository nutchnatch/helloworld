package com.ossnms.dcn_manager.commands.channel;

import static com.google.common.collect.Iterables.isEmpty;

import javax.annotation.Nonnull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.channel.ChannelModificationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;

/**
 * Deletes an existing Channel.
 * Exceptions will be thrown upon execution if the channel can not be deleted.
 *
 * <img src="doc-files/deletechannelcmd-activity.png">
 * <img src="doc-files/deletechannelcmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/deletechannelcmd-activity.png
 * start
 * if (Channel is active? //OR//\nChannel has NEs? //OR//\nChannel has Domains?) then (fail)
 * else
 *   :Delete Channel from repository;
 *   :Produce deletion notifications;
 *   :Produce log entries;
 * endif
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/deletechannelcmd-sequence.png
 * activate ChannelRepository
 * DeleteChannel --> ChannelRepository : findChannel(channelId)
 * ChannelRepository --> DeleteChannel : channel
 * deactivate ChannelRepository
 * alt If channel deletion is allowed
 * DeleteChannel --> ChannelRepository : delete(channel)
 * DeleteChannel --> ChannelPhysicalConnectionRepository : delete(channel)
 * DeleteChannel --> Notifications : notifyDelete(channel)
 * DeleteChannel --> LoggerManager : createCommandLog(...)
 * @enduml
 */
public class DeleteChannel<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteChannel.class);

    private final NeEntityRepository neRepository;
    private final ChannelNotifications notifications;
    private final ChannelModificationBase base;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;
    private final ChannelSchedulingConfiguration channelScheduling;
    private final LoggerManager<C> loggerManager;
    private final int channelId;

    public DeleteChannel(@Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull ChannelSchedulingConfiguration channelScheduling,
            @Nonnull NeEntityRepository neRepository,
            @Nonnull LoggerManager<C> loggerManager,
            int channelId) {
        super(context);
        this.channelScheduling = channelScheduling;
        this.neRepository = neRepository;
        this.channelId = channelId;
        this.channelInstanceRepository = channelManagers.getChannelInstanceConnections();
        this.base = new ChannelModificationBase(channelManagers.getChannelRepository());
        this.notifications = channelManagers.getChannelNotifications();
        this.loggerManager = loggerManager;
    }

    @Override
    public Void call() throws CommandException, IllegalChannelStateException, UnknownChannelIdException {
        ChannelEntity channel;
        try {
            channel = base.findChannel(channelId);

            throwOnChannelDeletionForbidden(channel);

            deleteChannel(channel);

            deleteChannelInstances(channel);

            logAndNotify(channel);

            return null;
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
    }

    private void logAndNotify(ChannelEntity channel) {
        notifications.notifyDelete(channel);

        LOGGER.info("Delete Channel: Channel Id={} Name={} was deleted.",
                channelId, channel.getUserPreferences().getName());

        loggerManager.createCommandLog(getContext(),
                new LoggerItemChannel(channel.getUserPreferences().getName(), "Channel object deleted"));
    }

    private void deleteChannel(ChannelEntity channel) throws RepositoryException {
       base.getChannelRepository().delete(new ChannelDeleteDescriptor(channel.getInfo().getId()));
    }

    private void deleteChannelInstances(ChannelEntity channel) {
        channelInstanceRepository.queryAll(channel.getInfo().getId())
            .forEach(channelInstance -> {
                channelInstanceRepository.remove(channelInstance.getId());
                channelScheduling.onChannelRemoved(channelInstance.getId());
            });
    }

    private void throwOnChannelDeletionForbidden(ChannelEntity channel) throws IllegalChannelStateException, RepositoryException {

        if (channel.getInfo().isActivationRequired()) {
            throw new IllegalChannelStateException("Channel {} with ID {} is still required to be active.",
                    channel.getUserPreferences().getName(), channelId);
        }

        if (channel.getConnectionState().isActive()) {
            throw new IllegalChannelStateException("Channel {} with ID {} is still connected.",
                    channel.getUserPreferences().getName(), channelId);
        }

        final boolean channelHasNEs =
                !isEmpty(neRepository.getNeInfoRepository().queryAll(channelId));
        if (channelHasNEs) {
            throw new IllegalChannelStateException("Channel {} with ID {} still has children Network Elements.",
                    channel.getUserPreferences().getName(), channelId);
        }
    }

}
