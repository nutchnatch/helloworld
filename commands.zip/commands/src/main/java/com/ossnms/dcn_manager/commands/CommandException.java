package com.ossnms.dcn_manager.commands;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Abstract base class for all exceptions thrown by Commands when errors occur.
 * @see DcnManagerException
 */
public class CommandException extends DcnManagerException {

    private static final long serialVersionUID = -6861855525183480441L;

    /** @see DcnManagerException#DcnManagerException() */
    public CommandException() {

    }

    /** @see DcnManagerException#DcnManagerException(String) */
    public CommandException(String message) {
        super(message);
    }

    /** @see DcnManagerException#DcnManagerException(Throwable) */
    public CommandException(Throwable cause) {
        super(cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable) */
    public CommandException(String message, Throwable cause) {
        super(message, cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,boolean,boolean) */
    public CommandException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /** @see DcnManagerException#DcnManagerException(String,Object[]) */
    public CommandException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,Object[]) */
    public CommandException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }

}
