package com.ossnms.dcn_manager.commands.domain;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Retrieves a domain, identified by its ID.
 *
 * <img src="doc-files/getsingledomain-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getsingledomain-sequence.png
 * GetSingleDomain --> DomainRepository : query(domainId)
 * activate DomainRepository
 * DomainRepository --> GetSingleDomain : domains
 * deactivate DomainRepository
 * @enduml
 */
public class GetSingleDomain<C extends CallContext> extends Command<C, Optional<DomainInfoData>> {

    private final DomainRepository domainRepository;
    private final int domainId;

    /**
     * Creates a new command instance.
     *
     * @param context Call context, to be passed on to outbound interfaces.
     * @param domainRepository Domain repository instance.
     * @param domainId Domain identifier.
     */
    public GetSingleDomain(C context, @Nonnull DomainRepository domainRepository, int domainId) {
        super(context);
        this.domainRepository = domainRepository;
        this.domainId = domainId;
    }

    @Override
    public Optional<DomainInfoData> call() throws RepositoryException {
        return domainRepository.query(domainId);
    }

}
