package com.ossnms.dcn_manager.events;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicActivationVerificationEvent;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicInitializationVerificationEvent;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.events.base.*;
import com.ossnms.dcn_manager.events.mediator.MediatorActivationVerificationEventHandler;
import com.ossnms.dcn_manager.events.ne.NeInitializationRetriesEventHandler;
import com.ossnms.dcn_manager.events.ne.NeInitializationTimeoutVerificationEventHandler;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.slf4j.Logger;
import rx.Observable;

import javax.annotation.Nonnull;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * Subscribes to an inbound event stream, dispatching each periodic (timed) event
 * to its appropriate handler.
 *
 * @param <C> Context instance type, propagated to handlers that need one.
 */
public class PeriodicEventsDispatcher<C extends CallContext> extends EventDispatcher<C> {

    private final MediatorManagers mediatorManagers;
    private final NetworkElementManagers neManagers;
    private final ChannelManagers channelManagers;
    private final SettingsRepository settingsRepository;

    /**
     * Constructs a new instance with all necessary dependencies.
     */
    public PeriodicEventsDispatcher(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull SettingsRepository settingsRepository,
            @Nonnull StaticConfiguration configuration,
            @Nonnull LoggerManager<C> loggerManager) {
        super(context, configuration, loggerManager);
        this.mediatorManagers = mediatorManagers;
        this.neManagers = neManagers;
        this.channelManagers = channelManagers;
        this.settingsRepository = settingsRepository;
    }

    private static final Logger LOGGER = getLogger(PeriodicEventsDispatcher.class);

    @Override
    public void initialize(Observable<? extends Event> eventSource) {

        LOGGER.debug("Initializing Periodic Events dispatcher.");

        subscribe(eventSource, PeriodicActivationVerificationEvent.class,
            new MediatorActivationVerificationEventHandler<>(getContext(), mediatorManagers,
                    settingsRepository, getLoggerManager()));

        subscribe(eventSource, PeriodicInitializationVerificationEvent.class,
            new HandlePeriodicInitializationEvents(getContext()));
    }

    private final class HandlePeriodicInitializationEvents
            extends EventHandler<C, PeriodicInitializationVerificationEvent> {

        private final NeInitializationTimeoutVerificationEventHandler<C> initTimeoutHandler;
        private final NeInitializationRetriesEventHandler<C> initRetryHandler;

        protected HandlePeriodicInitializationEvents(@Nonnull C context) {
            super(context);
            initTimeoutHandler = new NeInitializationTimeoutVerificationEventHandler<>(getContext(), neManagers);
            initRetryHandler = new NeInitializationRetriesEventHandler<>(getContext(), neManagers, channelManagers, settingsRepository);
        }

        @Override
        protected void handleEvent(@Nonnull PeriodicInitializationVerificationEvent event) throws DcnManagerException {

            initRetryHandler.call(event);

            initTimeoutHandler.call(event);

        }
    }

}
