package com.ossnms.dcn_manager.commands.channel;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static org.slf4j.LoggerFactory.getLogger;


public class DeactivateStandbyChannel<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(DeactivateStandbyChannel.class);
    
    /**
     * Holds the reference to the repository of channel instances
     */
    private final ChannelEntityRepository channelEntityRepository;

    /**
	 * Holds a reference to the object responsible for implementing the channel activation policy
	 */
	private final ChannelInteractionManager channelActivationManager;

	/**
	 * Holds the reference to the component's event dispatcher
	 */
	private final ChannelNotifications channelNotifications;

	/**
	 * Holds the target channel identifier.
	 */
    private final int channelId;

    /**
     * Holds the reference to the component responsible for logging operator commands
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds the reference to the repository of physical channel connection instances
     */
    private final ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;
    
    /**
	 * Instantiates the command with the given parameters
	 *
	 * @param context The call context
	 * @param channelId The channel identifier
	 * @param channelManagers object that holds references to all manager/publisher objects that are commonly used together when handling Channel events.
	 * @param loggerManager reference to the component responsible for logging operator commands
	 */
	public DeactivateStandbyChannel(@Nonnull C context, int channelId,
            @Nonnull ChannelManagers channelManagers,
			@Nonnull LoggerManager<C> loggerManager) {
		super(context);
        this.channelId = channelId;
		this.channelActivationManager = channelManagers.getChannelActivationManager();
        this.channelPhysicalConnectionRepository = channelManagers.getChannelInstanceConnections();
		this.channelNotifications = channelManagers.getChannelNotifications();
        this.loggerManager = loggerManager;
		this.channelEntityRepository = channelManagers.getChannelRepository();
	}

	/**
	 * {@inheritDoc}
	 * @throws RepositoryException When an error occurs while working with the data source.
	 * @throws UnknownChannelIdException When an activation is being requested with an invalid channel ID.
	 * @throws IllegalChannelStateException If the channel is already activated.
	 */
	@Override
	public final Void call() throws UnknownChannelIdException, RepositoryException, IllegalChannelStateException, CommandException	{

		String channelName = "Channel";
		
		Optional<ChannelUserPreferencesData> channelOptional = channelEntityRepository.getChannelUserPreferencesRepository().query(channelId);
		if(channelOptional.isPresent()) {
			channelName = channelOptional.get().getName();
		}

		LOGGER.debug("Deactivate channel on standby mode, channel ID={}, name={} ", channelId, channelName );
		
		StreamSupport.stream(channelPhysicalConnectionRepository.queryAll(channelId).spliterator(), false).
    		filter(data ->  ! data.isActive() && data.isStateActive()).
    		filter(this::noActiveNEs).
    		forEach(this::deactivateChannelInstance);

		loggerManager.createCommandLog(getContext(), new LoggerItemChannel(channelName, "Deactivate channel on hot standby mode."));

		return null;
	}
	
    private void deactivateChannelInstance(ChannelPhysicalConnectionData connection) {
        final Optional<ChannelPhysicalConnectionMutationDescriptor> channelMutation =
            new ChannelPhysicalConnectionBehavior(connection, channelNotifications)
            	.shutdown(channelActivationManager,
            			new Deactivate(connection.getLogicalChannelId(), connection.getMediatorInstanceId(), Collections.singleton(connection.getId())));
            
        if (channelMutation.isPresent()) {
            try {
                final Optional<ChannelPhysicalConnectionData> channelUpdatedConnection =
                		channelPhysicalConnectionRepository.tryUpdate(channelMutation.get());
                if (!channelUpdatedConnection.isPresent()) {
                	LOGGER.info("Deactivation of Physical Channel Connection {} was not possible.", connection);
                }
            } catch (final RepositoryException exception) {
            	LOGGER.error("Channel deactivation on {} failed: {} {}", connection,
                        exception.getMessage(), getStackTraceAsString(exception));
            }
        } else {
        	LOGGER.info("Transition to SHUTDOWN of Physical Channel Connection {} was not possible.", connection);
        }
    }

    private boolean noActiveNEs(ChannelPhysicalConnectionData data) {
    	return true;
    }
}
