package com.ossnms.dcn_manager.commands.container;

import com.google.common.collect.ImmutableSet.Builder;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainersSystemAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Optional.empty;
import static java.util.stream.Collectors.toSet;

public class MoveSystemsToContainer<C extends CallContext> extends Command<C, Void> {
    private static final Logger LOGGER = LoggerFactory.getLogger(MoveSystemsToContainer.class);

    private final ContainersSystemAssignmentUpdater updater;
    private final Collection<ISystemContainerId> systems;
    private final ContainerRepository containerRepository;
    @Nonnull private final Collection<IGenericContainerId> containers;
    private final SystemRepository systemRepository;
    private final IGenericContainerId primaryContainer;

    public MoveSystemsToContainer(@Nonnull final C context,
                                  @Nonnull final ContainerRepository containerRepository,
                                  @Nonnull final Collection<ISystemContainerId> systems,
                                  @Nonnull final IGenericContainerId primaryContainer,
                                  @Nonnull final Collection<IGenericContainerId> containers,
                                  @Nonnull final ContainerNotifications containerNotifications,
                                  @Nonnull final LoggerManager<C> loggerManager,
                                  @Nonnull final SystemRepository systemRepository,
                                  @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.systems = systems;
        this.primaryContainer = primaryContainer;
        this.containerRepository = containerRepository;
        this.containers = new Builder<IGenericContainerId>().addAll(containers).add(primaryContainer).build();
        this.systemRepository = systemRepository;
        updater = new ContainersSystemAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications,
                loggerManager, context);
    }

    @Override public Void call() throws CommandException {
        boolean allMoved = true;
        for (ISystemContainerId systemId : systems) {
            allMoved &= fetchSystem(systemId)
                    .map(system -> associateWithContainers(system, primaryContainer, containers))
                    .orElse(false);
        }

        if (!allMoved) {
            throw new CommandException(tr(Message.SOME_SYSTEM_CHANGES_FAILED));
        }

        return null;
    }

    private Boolean associateWithContainers(SystemInfo system, IGenericContainerId primaryContainer, Collection<IGenericContainerId> containers) {
        try {
            Set<SystemAssignmentData> assignments = containers.stream()
                    .map(containerId -> createAssignment(system, containerId, containerId.equals(primaryContainer)))
                    .flatMap(assignment -> assignment.map(Stream::of).orElseGet(Stream::empty))
                    .collect(toSet());
            updater.store(assignments, system);
            return true;
        } catch (RepositoryException e) {
            LOGGER.error("Failed to add container assignments for {}", system, e);
        }
        return false;

    }

    private Optional<SystemAssignmentData> createAssignment(SystemInfo system, IGenericContainerId containerId, boolean primary) {
        return fetchContainer(containerId).map(containerInfo ->
                new SystemAssignmentData(containerInfo, system.getId(), AssignmentType.fromFlag(primary)));
    }


    private Optional<ContainerInfo> fetchContainer(IGenericContainerId containerId) {
        try {
            return containerRepository.query(containerId.getId());
        } catch (RepositoryException e) {
            return empty();
        }
    }

    private Optional<SystemInfo> fetchSystem(ISystemContainerId systemContainerId) {
        try {
            return systemRepository.query(systemContainerId.getId());
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch system {}", systemContainerId, e);
            return empty();
        }
    }
}
