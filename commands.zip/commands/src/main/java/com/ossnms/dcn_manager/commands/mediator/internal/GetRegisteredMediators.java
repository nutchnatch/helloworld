package com.ossnms.dcn_manager.commands.mediator.internal;

import java.util.Collection;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;

public class GetRegisteredMediators<C extends CallContext> extends Command<C, Collection<MediatorType>> {

    private final StaticConfiguration emneConfiguration;

    public GetRegisteredMediators(@Nonnull C context, @Nonnull StaticConfiguration emneConfiguration) {
        super(context);
        this.emneConfiguration = emneConfiguration;
    }

    @Override
    public Collection<MediatorType> call() {
        return emneConfiguration.getMediatorTypes().values();
    }
}
