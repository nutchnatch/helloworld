/**
 * Package that contains the definition of EM/NE commands which are to be used exclusively by 
 * the component's user interface.
 */
package com.ossnms.dcn_manager.commands.channel.internal;