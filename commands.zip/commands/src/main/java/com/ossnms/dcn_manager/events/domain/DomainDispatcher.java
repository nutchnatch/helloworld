package com.ossnms.dcn_manager.events.domain;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.domain.DomainAdded;
import com.ossnms.dcn_manager.core.events.domain.DomainRemoved;
import com.ossnms.dcn_manager.core.events.domain.DomainRenamed;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.EventDispatcher;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.annotation.Nonnull;

/**
 * Subscribes to an inbound event stream, dispatching each event to its appropriate handler.
 *
 * @param <C> Context instance type, propagated to handlers that need one.
 */
public class DomainDispatcher<C extends CallContext> extends EventDispatcher<C> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DomainDispatcher.class);

    private final DomainManagers domainManagers;
    @Nonnull
    private final NetworkElementManagers networkElementManagers;
    private final SettingsRepository settingsRepository;

    public DomainDispatcher(
            @Nonnull C context,
            @Nonnull DomainManagers domainManagers,
            @Nonnull NetworkElementManagers networkElementManagers,
            @Nonnull StaticConfiguration configuration,
            @Nonnull SettingsRepository settingsRepository,
            @Nonnull LoggerManager<C> loggerManager) {
        super(context, configuration, loggerManager);
        this.domainManagers = domainManagers;
        this.networkElementManagers = networkElementManagers;
        this.settingsRepository = settingsRepository;
    }

    @Override
    public void initialize(Observable<? extends Event> eventSource) {

        LOGGER.debug("Initializing network domain event dispatcher.");

        subscribe(eventSource, DomainRenamed.class,
                new DomainRenamedEventHandler<>(getContext(), domainManagers,
                        networkElementManagers.getNeRepository().getNeGatewayRoutesRepository()));

        subscribe(eventSource, DomainRemoved.class,
                new DomainRemovedEventHandler<>(getContext(), domainManagers, settingsRepository));

        subscribe(eventSource, DomainAdded.class,
                new DomainAddedEventHandler<>(getContext(), domainManagers, settingsRepository));

    }
}
