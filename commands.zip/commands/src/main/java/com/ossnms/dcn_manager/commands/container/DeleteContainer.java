package com.ossnms.dcn_manager.commands.container;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.core.entities.container.RootContainerId;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownContainerIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Deletes an existing Container Container.
 * Exceptions will be thrown upon execution if the container can not be deleted.
 *
 * <img src="doc-files/deletecontainercmd-activity.png">
 * <img src="doc-files/deletecontainercmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/deletecontainercmd-activity.png
 * start
 *   :Delete Container from repository;
 *   :Produce deletion notifications;
 *   :Produce log entries;
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/deletecontainercmd-sequence.png
 * DeleteContainer --> ContainerRepository : findContainer(containerId)
 * activate ContainerRepository
 * ContainerRepository --> DeleteContainer : container
 * deactivate ContainerRepository
 * DeleteContainer --> ContainerRepository : delete(container)
 * DeleteContainer --> Notifications : notifyDelete(container)
 * DeleteContainer --> LoggerManager : createCommandLog(...)
 * end
 * @enduml
 */
public class DeleteContainer<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteContainer.class);

    private final ContainerNotifications notifications;
    private final LoggerManager<C> loggerManager;
    private final int containerId;
    private final ContainerRepository containerRepository;

    public DeleteContainer(@Nonnull C context, @Nonnull ContainerRepository containerRepository,
                    @Nonnull ContainerNotifications notifications, @Nonnull LoggerManager<C> loggerManager,
                    int containerId) {
        super(context);
        this.containerRepository = containerRepository;
        this.notifications = notifications;
        this.loggerManager = loggerManager;
        this.containerId = containerId;
    }

    @Override
    public Void call() throws UnknownContainerIdException, CommandException {
        try {
            if (containerId == RootContainerId.ID.get()) {
                throw new RepositoryException("Root container deletion is nor allowed");
            }
            final Optional<ContainerInfo> container = containerRepository.query(containerId);
            if (container.isPresent()) {
                containerRepository.delete(new ContainerDeletionDescriptor(containerId));
                logAndNotify(container.get());
            } else {
                LOGGER.info("Trying to delete unknown container with ID {}", containerId);
            }
            return null;
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
    }

    private void logAndNotify(ContainerInfo container) {
        notifications.notifyDelete(container);

        LOGGER.info("Delete Container: Container Id={} Name={} was deleted.",
                containerId, container.getName());

        loggerManager.createCommandLog(getContext(),
                new LoggerItemContainer(container.getName(), tr(Message.CONTAINER_DELETED)));
    }

}
