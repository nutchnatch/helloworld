package com.ossnms.dcn_manager.events.discovery;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.ossnms.dcn_manager.commands.ne.internal.NetworkElementActivationRequired;
import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NeCreationBase;
import com.ossnms.dcn_manager.composables.ne.NeDomainsUpdater;
import com.ossnms.dcn_manager.composables.ne.NePropertiesUpdater;
import com.ossnms.dcn_manager.composables.ne.NePropertiesUpdater.PreprocessedChanges;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNeDataTransferPropertyNames;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.properties.ne.NeDirectRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeGatewayRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeOperationalProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.properties.ne.NePropertyUtils;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DataCreationException;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.identification.ne.GlobalNeIdV4;
import com.ossnms.dcn_manager.identification.ne.NeIdentification;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.google.common.collect.Iterables.tryFind;
import static com.google.common.collect.Maps.filterKeys;
import static com.ossnms.dcn_manager.core.properties.ne.NePropertyUtils.applyDefaultProperties;
import static org.slf4j.LoggerFactory.getLogger;

public class NeDiscoveredEventHandler<C extends CallContext>
        extends EventHandler<C, Pair<Optional<ChannelInfoData>, NeDiscoveredEvent>> {

    private static final Logger LOGGER = getLogger(NeDiscoveredEventHandler.class);

    private final NeEntityRepository neRepository;
    private final NeProperties neProperties;
    private final NeDirectRouteProperties routeProperties;
    private final NeDomainsUpdater domainUpdater;
    private final ContainersNeAssignmentUpdater<C> containerUpdater;
    private final NeIdentification neIdentification;

    private final DomainRepository domainRepository;

    private final NeCreationBase<C> networkElementCreation;
    private final NePropertiesUpdater<C> nePropertiesUpdater;
    private final NePhysicalConnectionRepository physicalConnectionRepository;
    private final NetworkElementInteractionManager neActivationManager;
    private final AppProperties appProperties;
    private final NetworkElementNotifications neNotifications;
    private final NeOperationalProperties neOperationalProperties;
    private final NetworkElementManagers neManagers;
    private final ChannelEntityRepository channelRepository;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;
    private final LoggerManager<C> loggerManager;
    
    public NeDiscoveredEventHandler(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull NeIdentification neIdentification,
            @Nonnull DomainManagers domainManagers,
            @Nonnull ContainerRepository containerRepository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull ContainerNotifications containerNotifications,
            @Nonnull SettingsRepository settingsRepository,
            @Nonnull AppProperties appProperties,
            @Nonnull ChannelEntityRepository channelRepository,
            @Nonnull ChannelPhysicalConnectionRepository channelInstanceRepository,
            @Nonnull LoggerManager<C> loggerManager) {
        super(context);
        this.appProperties = appProperties;
        domainRepository = domainManagers.getDomainRepository();
        domainUpdater = new NeDomainsUpdater(domainRepository, domainManagers.getDomainNotifications(), settingsRepository);
        containerUpdater = new ContainersNeAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications, loggerManager, context);
        this.neManagers = neManagers;
        this.neIdentification = neIdentification;
        neRepository = neManagers.getNeRepository();
        physicalConnectionRepository = neManagers.getNeInstanceRepository();
        neActivationManager = neManagers.getNeActivationManager();
        neNotifications = neManagers.getNeNotifications();
        this.channelRepository = channelRepository;
        this.channelInstanceRepository = channelInstanceRepository;
        this.loggerManager = loggerManager;

        neOperationalProperties = new NeOperationalProperties();
        neProperties = new NeProperties();
        routeProperties = new NeDirectRouteProperties();
        networkElementCreation = new NeCreationBase<>(context, neManagers.getNeRepository(), neManagers.getNeInstanceRepository(),
                neNotifications, channelRepository, systemRepository, channelInstanceRepository, loggerManager);
        nePropertiesUpdater = new NePropertiesUpdater<>(getContext(), neRepository, systemRepository, loggerManager, neNotifications,
                new NeDomainsUpdater(domainRepository, domainManagers.getDomainNotifications(), settingsRepository));
    }

    @Override
    protected void handleEvent(@Nonnull Pair<Optional<ChannelInfoData>, NeDiscoveredEvent> pair) throws DcnManagerException {
        final NeDiscoveredEvent event = pair.getRight();
        final Map<String, String> properties = event.getProperties();
        final NeCreateDescriptor createDescriptor = event.getCreateDescriptor();
        final NeType neType = createDescriptor.getType();

        /*
         * Apply properties to the NE Creation Descriptor so we are sure that the descriptor
         * contains all information necessary to identify any existing NE. We want to avoid
         * accessing the property map directly during the identification procedure.
         */
        applyDefaultProperties(createDescriptor, neProperties, routeProperties);

        NePropertyUtils.applyAdditionalControlProperties(createDescriptor, neOperationalProperties,  properties);

        neProperties.setProperties(neType, createDescriptor.getPreferences(), properties);
        routeProperties.set(neType, createDescriptor, createDescriptor.getPreferences(), properties);
        neOperationalProperties.setProperties(neType, createDescriptor.getOperation(), properties);

        final Collection<NeGatewayRouteBuilder> gatewayRoutes = new NeGatewayRouteProperties(createDescriptor.getType())
                .parseProperties(properties, createDescriptor);
        createDescriptor.putGatewayRoutes(gatewayRoutes);

        final Optional<NeEntity> existingNe = neIdentification.tryIdentifyNe(createDescriptor);
        final Optional<NeEntity> targetNe;
        
        Set<DomainInfoData> domainsBeforeUpdate = Sets.newHashSet();
        
        if (existingNe.isPresent()) {
            domainsBeforeUpdate = Sets.newHashSet(domainRepository.queryAllForNE(existingNe.get().getInfo().getId()));
            targetNe = updateExistingNe(existingNe.get(), createDescriptor, event, properties);
        } else {
            targetNe = addNewNe(event);
        }
       
        if (targetNe.isPresent()) {

            final Set<DomainInfoData> domainsAfterUpdate = Sets.newHashSet(domainRepository.queryAllForNE(targetNe.get().getInfo().getNeId()));

            //Activate newly discovered NEs automatically if at least one added network domain participated by the discovered NE allows it.
            if ( isDiscoveryPermittedInDomains(Sets.difference(domainsAfterUpdate, domainsBeforeUpdate))) {
                tryActivateNetworkElement(targetNe.get().getInfo());
            }
        }
    
    }

    private Optional<NeEntity> updateExistingNe(
            NeEntity existingNe, NeCreateDescriptor createDescriptor, NeDiscoveredEvent event, Map<String, String> originalProperties)
                throws DcnManagerException {
        final Map<String, String> properties =
                copyPropertiesWithUpdateAllowed(createDescriptor.getType(), originalProperties);
        final Optional<String> networkName = or(event.getNameReceived(), 
                        createDescriptor.getOperation().getRealNeName(),
                        createDescriptor.getOperation().getNeighbourhoodId(),
                        Optional.ofNullable(createDescriptor.getPreferences().getName()));
        final Boolean autoCopyNeName =
                appProperties.isAutoCopyNeNameEnabled() && networkName.isPresent() && isNameDifferent(existingNe, networkName.get());
        final Iterable<NeGatewayRouteData> existingRoutes =
                neRepository.getNeGatewayRoutesRepository().queryRoutes(existingNe.getInfo().getNeId());
        final Optional<PreprocessedChanges> preprocessedChanges =
                nePropertiesUpdater.prepareUpdate(createDescriptor.getType(), existingNe, existingRoutes, properties);
        final Optional<NeEntity> targetNe;
        if (preprocessedChanges.isPresent()) {
            if (autoCopyNeName) {
                LOGGER.debug("Attempting tp update discovered NE name to {} on NE {}, {}.",
                        networkName, existingNe.getInfo().getNeId(), existingNe.getPreferences().getName());
                preprocessedChanges.get().getPreferencesMutationDescriptor().setName(networkName.get());
            }
            targetNe = nePropertiesUpdater.processUpdate(preprocessedChanges.get());
            if (targetNe.isPresent()) {
                sendUpdatedPropertiesToOnlineMediators(
                        preprocessedChanges.get().getPreferencesMutationDescriptor(), targetNe.get());
            }
        } else if (autoCopyNeName) {
            targetNe = tryToCopyNetworkNameToNeName(existingNe, networkName.get());
        } else {
            targetNe = Optional.empty();
        }
        return targetNe;
    }

    private <T> Optional<T> or(Optional<T>... optionals) {
        return Stream.of(optionals).filter(Optional::isPresent).map(Optional::get).findFirst();
    }

    // These properties will never be updated upon discovery of an existing NE, no matter its type.
    private static final Set<String> PROPERTIES_NOT_UPDATABLE = ImmutableSet.of(
            // Do not overwrite login credentials, as not all NEs have the same credentials.
            WellKnownNePropertyNames.USER_NAME,
            WellKnownNePropertyNames.USER_PASSWORD,
            WellKnownNePropertyNames.SNMP_USE_TL1_AUTHENTICATION,
            WellKnownNePropertyNames.SNMP_USER_NAME,
            WellKnownNePropertyNames.SNMP_PRIVACY_PASSWORD,
            WellKnownNePropertyNames.SNMP_AUTHENTICATION_PASSWORD,
            WellKnownNePropertyNames.SNMP_AUTHENTICATION_PROTOCOL,
            WellKnownNePropertyNames.SNMP_PRIVACY_PROTOCOL,
            WellKnownNePropertyNames.NE_POLLING_INTERVAL,
            WellKnownNePropertyNames.NE_TELEGRAM_TIMEOUT,
            WellKnownNePropertyNames.SNMP_TELEGRAM_TIMEOUT,
            WellKnownNePropertyNames.SNMP_TELEGRAM_RETRIES,


            // Allow the operator to access directly a RNE that also happens to have a direct connection available.
            WellKnownNePropertyNames.USES_GNE,

            // Do not overwrite (S)FTP login credentials.
            WellKnownNeDataTransferPropertyNames.USERNAME,
            WellKnownNeDataTransferPropertyNames.PASSWORD,
            WellKnownNeDataTransferPropertyNames.IP_ADDRESS,
            WellKnownNeDataTransferPropertyNames.UPLOADPATH,
            WellKnownNeDataTransferPropertyNames.IS_SCP
    );

    private Map<String, String> copyPropertiesWithUpdateAllowed(NeType type, Map<String, String> properties) {
        return new HashMap<>(filterKeys(properties, key -> isPropertyNameToProcess(type, key)));
    }

    private boolean isPropertyNameToProcess(NeType type, String key) {
        final String mappedPropertyName = type.mapIncomingPropertyName(key);
        return !PROPERTIES_NOT_UPDATABLE.contains(mappedPropertyName) &&
               !type.getPropertyNamesToIgnoreOnDiscoveryUpdates().contains(mappedPropertyName);
    }

    private Optional<NeEntity> tryToCopyNetworkNameToNeName(NeEntity existingNe, String networkName) {
        LOGGER.debug("Attempting to update discovered NE name to {} on NE {}, {}.", networkName,
                existingNe.getInfo().getNeId(), existingNe.getPreferences().getName());

        final NeUserPreferencesMutationDescriptor preferencesMutationDescriptor = new NeUserPreferencesMutationDescriptor(
                existingNe.getPreferences()).setName(networkName).whenApplied(neNotifications::notifyChanges);
        try {
            final Optional<NeUserPreferencesData> updatedPreferences = neRepository.getNeUserPreferencesRepository()
                    .tryUpdate(preferencesMutationDescriptor);
            if (updatedPreferences.isPresent()) {
                final Optional<NeEntity> targetNe = neRepository.queryNe(existingNe.getInfo().getNeId());
                if (targetNe.isPresent()) {
                    sendUpdatedPropertiesToOnlineMediators(preferencesMutationDescriptor, targetNe.get());
                }
                return targetNe;
            } else {
                LOGGER.warn(
                        "Could not copy the network name to the ID name on discovery of NE {}: concurrent modification.",
                        preferencesMutationDescriptor);
            }
        } catch (RepositoryException e) {
            LOGGER.error("Could not copy the network name to the ID name on discovery of NE {}: {}",
                    preferencesMutationDescriptor, getStackTraceAsString(e));
        }

        return Optional.empty();
    }

    private boolean isNameDifferent(NeEntity existingNe, String networkName) {
        return networkName != null && !networkName.equals(existingNe.getPreferences().getName());
    }

    private void sendUpdatedPropertiesToOnlineMediators(
            NeUserPreferencesMutationDescriptor preferencesChanges, NeEntity targetNe) {
        StreamSupport.stream(
                    physicalConnectionRepository.queryAll(targetNe.getInfo().getNeId()).spliterator(),
                    false)
                .filter(NePhysicalConnectionData::isConnected)
                .forEach(neInstance -> neActivationManager.onNePropertiesUpdated(
                        targetNe, neInstance, preferencesChanges
                ));
    }

    private void tryActivateNetworkElement(NeInfoData neInfo) {
        
        try {
            new NetworkElementActivationRequired<>(getContext(), neInfo.getId(),
                    neManagers, channelRepository, channelInstanceRepository, loggerManager)
                .call();
        } catch (final  DcnManagerException e) {
            LOGGER.error("Failed to activate NE {}: {}", neInfo.getId(), getStackTraceAsString(e));
        }

    }

    private boolean isDiscoveryPermittedInDomains(@Nonnull Iterable<DomainInfoData> domains) {
        return tryFind(domains, DomainInfoData::isAutomaticNeActivationPermitted).isPresent();
    }

    private Optional<NeEntity> addNewNe(NeDiscoveredEvent event)
            throws RepositoryException, DuplicatedRouteException,
                   UnknownChannelIdException, DataCreationException, DuplicatedObjectNameException {

        final NeCreateDescriptor createDescriptor = event.getCreateDescriptor();

        // Find a candidate for the "NE ID Name".
        final String neName = or(event.getNameReceived(), 
                createDescriptor.getOperation().getRealNeName(), 
                createDescriptor.getOperation().getNeighbourhoodId())
                .orElse(createDescriptor.getTypeName());

        // Complete the creation descriptor.
        createDescriptor
            .getPreferences()
                .setName(uniqueNeName(neName))
                // Calculate the new NE Global Identifier.
                .setGlobalId(new GlobalNeIdV4().generate(createDescriptor.getType(), createDescriptor));

        final NeEntity entity = networkElementCreation.tryCreateNe(createDescriptor);

        domainUpdater.storeTransitiveDomains(entity.getInfo().getId(),
                createDescriptor.getGatewayRoutes().stream()
                        .map(NeGatewayRouteBuilder.GET_DOMAIN)
                        .filter(Optional::isPresent).map(Optional::get)
                        .collect(Collectors.toSet()));

        containerUpdater.defaultNeAssignment(entity.getPreferences());

        return Optional.of(entity);
    }

    private String uniqueNeName(String proposedName) throws RepositoryException {
        final StringBuilder currentName = new StringBuilder(proposedName);
        while (nameExists(currentName.toString())) {
            currentName.append("_1");
        }
        return currentName.toString();
    }

    private boolean nameExists(String currentName) throws RepositoryException {
        return neRepository.getNeUserPreferencesRepository()
                .query(currentName)
                .isPresent();
    }

}

