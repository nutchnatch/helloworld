package com.ossnms.dcn_manager.commands.container;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.INFO;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.WARNING;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Collections.emptySet;
import static java.util.Optional.of;

public class MoveNesToSystem<C extends CallContext> extends Command<C, Void> {
    private static final Logger LOGGER = LoggerFactory.getLogger(MoveNesToSystem.class);

    private final ContainersNeAssignmentUpdater<C> updater;
    private final Collection<INEId> nes;
    private final ISystemContainerId systemId;
    @Nonnull private final NeEntityRepository neRepository;
    private final NetworkElementNotifications notifications;
    private final LoggerManager<C> loggerManager;

    public MoveNesToSystem(@Nonnull final C context,
                           @Nonnull final Collection<INEId> nes,
                           @Nonnull final ISystemContainerId systemId,
                           @Nonnull final ContainerRepository containerRepository,
                           @Nonnull final SystemRepository systemRepository,
                           @Nonnull final NeEntityRepository neRepository,
                           @Nonnull final ContainerNotifications containerNotifications,
                           @Nonnull final LoggerManager<C> loggerManager,
                           @Nonnull final NetworkElementNotifications notifications,
                           @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.nes = nes;
        this.systemId = systemId;
        this.neRepository = neRepository;
        this.notifications = notifications;
        this.loggerManager = loggerManager;

        updater = new ContainersNeAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications,
                loggerManager, context);
    }

    @Override public Void call() throws CommandException {
        boolean successfullyMoved = true;

        for (INEId ne : nes) {
            successfullyMoved &= moveNeToSystem(ne, systemId);
        }

        if (!successfullyMoved) {
            throw new CommandException(tr(Message.SOME_NE_MOVES_FAILED));
        }

        return null;
    }

    private Boolean moveNeToSystem(INEId id, ISystemContainerId systemId) {
        return fetchNePreferences(id)
                .flatMap(preference -> moveToSystem(preference, systemId))
                .map(this::removeContainerAssociations)
                .orElse(false);
    }

    private boolean removeContainerAssociations(NeUserPreferencesData nePreferences) {
        try {
            updater.store(emptySet(), nePreferences);
            return true;
        } catch (RepositoryException e) {
            LOGGER.error("Failed to remove container assignments for {}", nePreferences, e);
            return false;
        }
    }

    private Optional<NeUserPreferencesData> moveToSystem(NeUserPreferencesData preference, ISystemContainerId systemId) {
        NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(preference)
                .setContainerId(of(systemId.getId()))
                .whenApplied(descriptor -> {
                    notifications.notifyChanges(descriptor);
                    loggerManager.createCommandLog(getContext(),
                            new LoggerItemNe(descriptor.getResult().getName(), tr(Message.SYSTEM_CHANGED), descriptor.getResult().getId(), INFO));
                });
        return updateNe(mutation);
    }

    private Optional<NeUserPreferencesData> updateNe(NeUserPreferencesMutationDescriptor descriptor) {
        try {
            return neRepository.getNeUserPreferencesRepository().tryUpdate(descriptor);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to perform update of {}", descriptor, e);
            loggerManager.createCommandLog(getContext(),
                    new LoggerItemNe(descriptor.getResult().getName(), tr(Message.SYSTEM_CHANGE_FAILED), descriptor.getResult().getId(), WARNING));
            return Optional.empty();
        }
    }

    private Optional<NeUserPreferencesData> fetchNePreferences(INEId id) {
        try {
            return neRepository.getNeUserPreferencesRepository().query(id.getId());
        } catch (RepositoryException e) {
            return Optional.empty();
        }
    }
}
