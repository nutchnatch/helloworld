package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatingEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class PhysicalChannelDeactivatingEventHandler<C extends CallContext> extends
        PhysicalChannelEventHandlerBase<C, PhysicalChannelDeactivatingEvent, ChannelDeactivatingEvent> {

    public PhysicalChannelDeactivatingEventHandler(@Nonnull C context, @Nonnull ChannelManagers channelManagers) {
        super(context, channelManagers);
    }

    @Override
    protected Optional<ChannelPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalChannelDeactivatingEvent event, ChannelPhysicalConnectionBehavior state,
            ChannelManagers channelManagers) {
        return state.setDeactivating();
    }

    @Override
    protected ChannelDeactivatingEvent produceForwardingEvent(PhysicalChannelDeactivatingEvent event,
            ChannelPhysicalConnectionData channelConnectionState) {
        return new ChannelDeactivatingEvent(event.getLogicalChannelId(), event);
    }

}
