package com.ossnms.dcn_manager.events.discovery;

import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;

import rx.functions.Func1;

final class DiscoveryIsEnabled implements Func1<NeDiscoveredEvent, Boolean> {

    private final SettingsRepository settingsRepository;

    public DiscoveryIsEnabled(SettingsRepository settingsRepository) {
        this.settingsRepository = settingsRepository;
    }

    @Override
    public Boolean call(NeDiscoveredEvent event) {
        return settingsRepository.getSettings().getDiscoveryPolicy() != DiscoveryPolicy.NO_DISCOVERY;
    }

}