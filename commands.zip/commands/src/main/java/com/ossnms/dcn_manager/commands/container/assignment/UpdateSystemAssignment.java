package com.ossnms.dcn_manager.commands.container.assignment;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.SystemAssignmentOperations;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;

/**
 * Update a System Assignment.
 */
public class UpdateSystemAssignment<C extends CallContext> extends Command<C, Void> {

    private final SystemInfo systemInfo;
    private final SystemAssignmentData assignment;
    private final SystemAssignmentOperations<C> operationsBase;

    public UpdateSystemAssignment(
            @Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final SystemInfo systemInfo,
            @Nonnull final SystemAssignmentData assignment) {
        super(context);
        this.systemInfo = systemInfo;
        this.assignment = assignment;
        this.operationsBase = new SystemAssignmentOperations<>(containerRepository, containerNotifications,
                loggerManager, context);
    }

    @Override public Void call() throws CommandException {
        try {
            operationsBase.update(systemInfo, assignment);
        } catch (RepositoryException e) {
            throw new CommandException(e);
        }
        return null;
    }
}
