package com.ossnms.dcn_manager.commands.ne;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * Retrieves all existing NEs from the repository.
 *
 * <img src="doc-files/getallnes-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getallnes-sequence.png
 * GetAllNEs --> NeEntityRepository : findAll()
 * activate NeEntityRepository
 * NeEntityRepository --> GetAllNEs : nes
 * deactivate NeEntityRepository
 * @enduml
 */
public class GetAllNEs<C extends CallContext> extends Command<C, Iterable<NeEntity>> {

    private final NeEntityRepository repository;

    /**
     * Creates a new command instance.
     *
     * @param context Call context, to be passed on to outbound interfaces.
     * @param repository NE repository instance.
     */
    public GetAllNEs(@Nonnull C context, @Nonnull NeEntityRepository repository) {
        super(context);
        this.repository = repository;
    }

    @Override
    public Iterable<NeEntity> call() throws CommandException {
        try {
            return repository.queryAll();
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
    }

}
