package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.NeInfoDataChangedEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownNeIconIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Handles events that request the NE Icon Id to be updated for a given NE.
 */
public class UpdateNeInfoDataEventHandler<C extends CallContext> extends EventHandler<C, NeInfoDataChangedEvent> {

    private final NeInfoRepository neRepository;
    private final NetworkElementNotifications notifications;

    /**
     * Creates a new Object
     * @param context Call context
     * @param neRepository Network element entity repository
     * @param notifications Network element notification publisher
     */
    protected UpdateNeInfoDataEventHandler(@Nonnull C context, @Nonnull NeEntityRepository neRepository,
                                           @Nonnull NetworkElementNotifications notifications) {
        super(context);
        this.neRepository = neRepository.getNeInfoRepository();
        this.notifications = notifications;
    }

    @Override
    protected void handleEvent(@Nonnull NeInfoDataChangedEvent event) throws UnknownNeIconIdException,
            UnknownNetworkElementIdException, DataUpdateException, RepositoryException {

        final String iconId = event.getIconId();
        if(null == iconId){
            throw new UnknownNeIconIdException("Unknown icon id");
        }
        final Optional<NeInfoData> foundNe = neRepository.query(event.getNeId());
        if(!foundNe.isPresent()){
            throw new UnknownNetworkElementIdException("Unknown NE ID {}", event.getNeId());
        }

        updateIconId(event.getIconId(), foundNe);
    }

    private void updateIconId(final String iconId, final Optional<NeInfoData> foundNe) throws RepositoryException, DataUpdateException {
        final NeInfoMutationDescriptor mutation = new NeInfoMutationDescriptor(foundNe.get())
                .setIconId(iconId)
                .whenApplied(notifications::notifyChanges);
        if(!neRepository.tryUpdate(mutation).isPresent()){
            throw new DataUpdateException("Could not update NE Info to {}", mutation);
        }
    }
}
