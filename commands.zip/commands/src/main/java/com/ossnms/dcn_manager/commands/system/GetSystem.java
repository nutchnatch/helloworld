package com.ossnms.dcn_manager.commands.system;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownSystemIdException;

import javax.annotation.Nonnull;

/**
 * Retrieves an existing system from the repository.
 *
 * <img src="doc-files/getsystem-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getsystem-sequence.png
 * GetSystem --> SystemRepository : query(systemId)
 * activate SystemRepository
 * SystemRepository --> GetSystem : system
 * deactivate SystemRepository
 * @enduml
 */
public class GetSystem<C extends CallContext> extends Command<C, SystemInfo> {

    private final SystemRepository repository;
    private final int systemId;

    public GetSystem(@Nonnull C context, @Nonnull SystemRepository repository, int systemId) {
        super(context);
        this.repository = repository;
        this.systemId = systemId;
    }

    @Override
    public SystemInfo call() throws RepositoryException, UnknownSystemIdException {
        return repository.query(systemId)
                .orElseThrow(() -> new UnknownSystemIdException("Unknown system ID {}", systemId));
    }

}
