/**
 * Package that contains the definition of all EM/NE in-bound events. 
 */
package com.ossnms.dcn_manager.events;