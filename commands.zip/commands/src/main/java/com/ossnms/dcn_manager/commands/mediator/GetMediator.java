package com.ossnms.dcn_manager.commands.mediator;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Retrieves an existing mediator from the repository.
 *
 * <img src="doc-files/getmediator-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getmediator-sequence.png
 * GetMediator --> MediatorRepository : query(mediatorId)
 * activate MediatorRepository
 * MediatorRepository --> GetMediator : mediator
 * deactivate MediatorRepository
 * @enduml
 */
public class GetMediator<C extends CallContext> extends Command<C, MediatorEntity> {

    private final MediatorEntityRepository repository;
    private final int mediatorId;

    public GetMediator(@Nonnull C context, @Nonnull MediatorEntityRepository repository, int mediatorId) {
        super(context);
        this.repository = repository;
        this.mediatorId = mediatorId;
    }

    @Override
    public MediatorEntity call() throws RepositoryException, UnknownMediatorIdException {
        final Optional<MediatorEntity> entity = repository.query(mediatorId);
        if (!entity.isPresent()) {
            throw new UnknownMediatorIdException("Unknwon mediator ID {}", mediatorId);
        }
        return entity.get();
    }

}
