package com.ossnms.dcn_manager.events.mediator;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.google.common.collect.Iterables.transform;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import javax.annotation.Nonnull;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * <p>This event handler is not only responsible for updating the physical connection state of the mediator instance.
 * It also must:</p>
 *
 * <ul>
 *     <li>Trigger activation of child Channel physical instances.</li>
 *     <li>Trigger activation of the other standby Mediator instances.</li>
 * </ul>
 */
public class PhysicalMediatorActivatedEventHandler<C extends CallContext> extends
        PhysicalMediatorEventHandlerBase<C, PhysicalMediatorActivatedEvent, MediatorActivatedEvent> {

    private final ChannelPhysicalConnectionRepository channelInstanceConnections;
    private final ChannelInfoRepository channelInfoRepository;
    private final ChannelInteractionManager channelActivationManager;
    private final ChannelNotifications channelNotifications;
    private final SettingsRepository settingsRepository;
    private final StaticConfiguration configuration;

    public PhysicalMediatorActivatedEventHandler(@Nonnull C context,
                                                 @Nonnull MediatorManagers mediatorManagers,
                                                 @Nonnull ChannelManagers channelManagers,
                                                 @Nonnull SettingsRepository settingsRepository,
                                                 @Nonnull StaticConfiguration configuration) {
        super(context, mediatorManagers);
        this.channelInstanceConnections = channelManagers.getChannelInstanceConnections();
        this.channelInfoRepository = channelManagers.getChannelRepository().getChannelInfoRepository();
        this.channelActivationManager = channelManagers.getChannelActivationManager();
        this.channelNotifications = channelManagers.getChannelNotifications();
        this.settingsRepository = settingsRepository;
        this.configuration = configuration;
    }

    @Override
    protected Optional<MediatorPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalMediatorActivatedEvent event, MediatorPhysicalConnectionBehavior state, MediatorManagers mediatorManagers) {
        return state.setActive(mediatorManagers.getMediatorNotifications(), mediatorManagers.getMediatorActivationManager());
    }

    @Override
    protected MediatorActivatedEvent produceForwardingEvent(PhysicalMediatorActivatedEvent event, MediatorPhysicalConnectionData mediatorConnectionState) {
        return new MediatorActivatedEvent(mediatorConnectionState.getLogicalMediatorId(), event);
    }

    @Override
    protected void onMutationApplied(MediatorPhysicalConnectionData updatedPhysicalConnection,
            MediatorPhysicalConnectionBehavior state, MediatorManagers mediatorManagers) {

        getChildChannelsRequiredActive(updatedPhysicalConnection.getLogicalMediatorId(), updatedPhysicalConnection.getId())
            .forEach(channelInstance -> activateChannelInstance(updatedPhysicalConnection.getLogicalMediatorId(), channelInstance));

        if (updatedPhysicalConnection.isActive() && settingsRepository.areStandbyConnectionsAllowed()
                && mediatorTypeAllowsHotStandby(mediatorManagers, updatedPhysicalConnection.getLogicalMediatorId())) {
            getInactiveStandbyMediatorInstances(mediatorManagers, updatedPhysicalConnection.getLogicalMediatorId(), updatedPhysicalConnection.getId())
                    .forEach(mediatorInstance -> activateMediatorInstance(mediatorManagers, mediatorInstance));
        }
    }

    private void activateMediatorInstance(
            MediatorManagers mediatorManagers, MediatorPhysicalConnectionData connection) {
        final Optional<MediatorPhysicalConnectionMutationDescriptor> connectionMutation =
            new MediatorPhysicalConnectionBehavior(connection)
                .setStartingUp(mediatorManagers.getMediatorNotifications(), mediatorManagers.getMediatorActivationManager());
        if (connectionMutation.isPresent()) {
            try {
                final Optional<MediatorPhysicalConnectionData> updatedConnection =
                    mediatorManagers.getMediatorInstanceRepository()
                        .getMediatorPhysicalConnectionRepository()
                        .tryUpdate(connectionMutation.get());
                if (!updatedConnection.isPresent()) {
                    getLogger().warn("Concurrent activation attempt of {} detected.", connection);
                }
            } catch (RepositoryException e) {
                getLogger().warn("Failed to store automatic activation of {}: {}", connection,
                        getStackTraceAsString(e));
            }
        }
    }

    
    protected boolean mediatorTypeAllowsHotStandby(MediatorManagers mediatorManagers, int logicalMediatorId ) {
        Optional<MediatorEntity> mediator;
        try {
            mediator = mediatorManagers.getMediatorRepository().query(logicalMediatorId);
            if(mediator.isPresent()) {
                
                final MediatorType mediatorType = configuration.getMediatorTypes().get(mediator.get().getInfo().getTypeName());
                return mediatorType.supportsHotStandby();
            }

        } catch (RepositoryException e) {
            getLogger().error("Failed to check if mediator type allows hot standby connection establishment. {}", getStackTraceAsString(e));
        }
        
        return false;
        
    }
    
    private Stream<MediatorPhysicalConnectionData> getInactiveStandbyMediatorInstances(
            MediatorManagers mediatorManagers, int logicalMediatorId, int activeMediatorInstanceId) {
        return StreamSupport.stream(
                    mediatorManagers
                            .getMediatorInstanceRepository()
                            .getMediatorPhysicalConnectionRepository()
                            .queryAll(logicalMediatorId).spliterator(),
                    false)
                .filter(i -> !i.isActive())
                .filter(i -> i.getId() != activeMediatorInstanceId);
    }

    private void activateChannelInstance(int mediatorId, ChannelPhysicalConnectionData connection) {
        final Optional<ChannelPhysicalConnectionMutationDescriptor> channelMutation =
            new ChannelPhysicalConnectionBehavior(connection, channelNotifications)
                .startUp(channelActivationManager,
                    new Activate(connection.getLogicalChannelId(), mediatorId, Collections.singleton(connection.getId())));
        if (channelMutation.isPresent()) {
            try {
                final Optional<ChannelPhysicalConnectionData> channelUpdatedConnection =
                        channelInstanceConnections.tryUpdate(channelMutation.get());
                if (!channelUpdatedConnection.isPresent()) {
                    getLogger().info("Automatic activation of Physical Channel Connection {} was not possible.", connection);
                }
            } catch (final RepositoryException exception) {
                getLogger().error("Automatic channel activation on {} failed: {} {}", connection,
                        exception.getMessage(), getStackTraceAsString(exception));
            }
        } else {
            getLogger().info("Automatic transition to STARTING UP of Physical Channel Connection {} was not possible.", connection);
        }
    }

    private List<ChannelPhysicalConnectionData> getChildChannelsRequiredActive(int mediatorId, int mediatorInstanceId) {
        final ImmutableList<Integer> childRequiredActiveChannelIds = ImmutableList.copyOf(
            transform(getChildChannelsRequiredActive(mediatorId), ChannelInfoData::getId));
        final QChannelPhysicalConnectionData conn = QChannelPhysicalConnectionData.channelPhysicalConnectionData;
        return channelInstanceConnections.query(conn)
            .where(conn.logicalChannelId.in(childRequiredActiveChannelIds)
                    .and(conn.mediatorInstanceId.eq(mediatorInstanceId)))
            .list(conn);
    }

    private Collection<ChannelInfoData> getChildChannelsRequiredActive(int mediatorId) {
        try {
            return channelInfoRepository.queryActivationRequiredIs(mediatorId, ChannelInfoData.ACTIVATION_REQUIRED);
        } catch (final RepositoryException e) {
            getLogger().error("Failed to get child channels required active for mediator {} : {}", mediatorId,
                    getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

}
