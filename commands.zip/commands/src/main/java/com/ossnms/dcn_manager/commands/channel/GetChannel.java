package com.ossnms.dcn_manager.commands.channel;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Retrieves an existing channel from the repository.
 *
 * <img src="doc-files/getchannel-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getchannel-sequence.png
 * GetChannel --> ChannelEntityRepository : queryChannel(channelId)
 * activate ChannelEntityRepository
 * ChannelEntityRepository --> GetChannel : channel
 * deactivate ChannelEntityRepository
 * @enduml
 */
public class GetChannel<C extends CallContext> extends Command<C, Optional<ChannelEntity>> {

    private final ChannelEntityRepository repository;
    private final int channelId;

    public GetChannel(@Nonnull C context, @Nonnull ChannelEntityRepository repository, int channelId) {
        super(context);
        this.repository = repository;
        this.channelId = channelId;
    }

    @Override
    public Optional<ChannelEntity> call() throws CommandException {
        try {
            return repository.queryChannel(channelId);
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
    }

}
