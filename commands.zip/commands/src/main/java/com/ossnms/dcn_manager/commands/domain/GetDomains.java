package com.ossnms.dcn_manager.commands.domain;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * Retrieves all domains.
 *
 * <img src="doc-files/getdomains-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getdomains-sequence.png
 * GetDomainsTest --> DomainRepository : queryAll()
 * activate DomainRepository
 * DomainRepository --> GetDomainsTest : domains
 * deactivate DomainRepository
 * @enduml
 */
public class GetDomains<C extends CallContext> extends Command<C, Iterable<DomainInfoData>> {

    private final DomainRepository domainRepository;

    /**
     * Creates a new command instance.
     *
     * @param context Call context, to be passed on to outbound interfaces.
     * @param repository Domain repository instance.
     */
    public GetDomains(C context, @Nonnull DomainRepository domainRepository) {
        super(context);
        this.domainRepository = domainRepository;
    }

    @Override
    public Iterable<DomainInfoData> call() throws RepositoryException {
        return domainRepository.queryAll();
    }

}
