package com.ossnms.dcn_manager.commands.channel;

import java.util.Collection;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;

/**
 * <p>Obtains the list of all Channel types supported by a specific type of Mediator.</p>
 *
 * <p> <img src="doc-files/getregisteredchannels-sequence.png"/></p>
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getregisteredchannels-sequence.png
 * GetRegisteredEMs -> StaticConfiguration : get mediator type
 * activate StaticConfiguration
 * StaticConfiguration --> GetRegisteredEMs : MediatorType
 * deactivate StaticConfiguration
 * GetRegisteredEMs -> MediatorType : getSupportedChannelTypes()
 * activate MediatorType
 * GetRegisteredEMs <-- MediatorType : channel types
 * deactivate MediatorType
 * @enduml
 */
public class GetRegisteredEMs<C extends CallContext> extends Command<C, Collection<ChannelType>> {

    private final StaticConfiguration emneConfiguration;
    private final String mediatorTypeName;

    public GetRegisteredEMs(@Nonnull C context,
            @Nonnull StaticConfiguration emneConfiguration,
            @Nonnull String mediatorTypeName) {
        super(context);
        this.emneConfiguration = emneConfiguration;
        this.mediatorTypeName = mediatorTypeName;
    }

    @Override
    public Collection<ChannelType> call() throws UnknownMediatorTypeException {
        final MediatorType mediatorType = emneConfiguration.getMediatorTypes().get(mediatorTypeName);
        if (null == mediatorType) {
            throw new UnknownMediatorTypeException("Unknown mediator type {}", mediatorTypeName);
        }

        return mediatorType.getSupportedChannelTypes();
    }

}
