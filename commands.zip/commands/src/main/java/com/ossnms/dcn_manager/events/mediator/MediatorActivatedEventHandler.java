package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.MediatorModificationBase;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

public class MediatorActivatedEventHandler<C extends CallContext> extends
        EventHandler<C, MediatorActivatedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorActivatedEventHandler.class);

    private final MediatorModificationBase base;
    private final MediatorManagers mediatorManagers;

    public MediatorActivatedEventHandler(@Nonnull C context,
            @Nonnull MediatorManagers mediatorManagers) {
        super(context);
        this.mediatorManagers = mediatorManagers;
        this.base = new MediatorModificationBase(mediatorManagers.getMediatorRepository());
    }

    @Override
    protected void handleEvent(MediatorActivatedEvent event) throws DcnManagerException {
        final MediatorConnectionData mediatorConnectionState = base.findMediatorConnectionState(event.getMediatorId());
        final MediatorConnectionBehavior state = new MediatorConnectionBehavior(mediatorConnectionState);
        final Optional<MediatorConnectionMutationDescriptor> mutation = state.setActive(
                mediatorManagers.getMediatorNotifications());
        if (mutation.isPresent()) { // state changes to the same state are no-ops
            final Optional<MediatorConnectionData> updatedConnectionData = base.getMediatorRepository()
                    .getMediatorConnectionRepository().tryUpdate(mutation.get());
            if (!updatedConnectionData.isPresent()) {
                LOGGER.warn("Could not store Mediator state change on {} with {}.", event, mutation.get());
            }
        } else {
            LOGGER.warn("Dropping event because Mediator {} is in state {}.",
                    mediatorConnectionState.getId(), mediatorConnectionState.getActualActivationState());
        }
    }

}
