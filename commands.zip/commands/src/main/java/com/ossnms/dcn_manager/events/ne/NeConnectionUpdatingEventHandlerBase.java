package com.ossnms.dcn_manager.events.ne;

import java.util.Optional;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.events.ne.NeConnectionDescriptionChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.OutboundException;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;

/**
 * Used to share code and behavior between event handlers that need to update the
 * current NE data by obtaining a fresh set of information from the mediator.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 * @param <T> The specific type of the NE event being processed.
 */
abstract class NeConnectionUpdatingEventHandlerBase<C extends CallContext, T extends NeEvent>
    extends NeConnectionEventHandlerBase<C, T> {

    private final NeInformationRetrieval informationRetrieval;
    private final NetworkElementNotifications notifications;
    private final NeGatewayRoutesRepository routeRepository;

    protected NeConnectionUpdatingEventHandlerBase(@Nonnull C context,
                                                   @Nonnull NeEntityRepository repository,
                                                   @Nonnull NetworkElementNotifications notifications,
                                                   @Nonnull NeInformationRetrieval informationRetrieval) {
        super(context, repository, notifications);
        this.routeRepository = repository.getNeGatewayRoutesRepository();
        this.notifications = notifications;
        this.informationRetrieval = informationRetrieval;
    }

    protected void updateDataFromMediator(int logicalNeId, int physicalNeId)
            throws DataUpdateException, OutboundException, UnknownNetworkElementIdException,
                   RepositoryException, UnknownChannelIdException {
        final NeEntity neEntity = informationRetrieval.updateNeDataFromMediator(physicalNeId);
        updateConnectionDescription(logicalNeId, neEntity.getPreferences(), neEntity.getConnection().isConnected());
    }

    protected void updateConnectionDescription(int logicalNeId, NeUserPreferencesData neUserPreferencesData, boolean isConnected) throws RepositoryException {
        final Iterable<NeGatewayRouteData> neRoutes = routeRepository.queryRoutes(logicalNeId);
        final Optional<String> routeDescription = new NeProperties().buildCurrentRouteDescription(isConnected, neUserPreferencesData, neRoutes);
        if (routeDescription.isPresent()) {
            notifications.notifyChanges(
                    new NeConnectionDescriptionChangedEvent(logicalNeId)
                        .setRouteDescription(routeDescription));
        }
    }

}