package com.ossnms.dcn_manager.commands.mediator.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.MediatorModificationBase;
import com.ossnms.dcn_manager.composables.mediator.MediatorPhysicalConnectionOperations;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.entities.mediator.behavior.MediatorInfoBehavior;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.IllegalMediatorStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.StreamSupport;

/**
 * <p>Command that requires the activation of a given mediator. As with all other commands, instances are
 * immutable and all dependencies are injected through the constructor. Instances are not to be reused,
 * that is, for each incoming external stimulus an new instance is specifically created to deal with it.</p>
 *
 * <p>The activation state of a mediator represents whether that mediator is required to be active or not, for
 * network management purposes. Whenever a mediator activation is required, it is set to the ActivationRequired
 * state and the mediator connection establishment sequence is triggered (a.k.a. actual mediator activation).
 * Although this sequence is not completely materialized in this command, due to the sequence's asynchronous nature,
 * it is described herein for clarity and depicted in the following figure. Note that the exact types and method names
 * may differ from the actual implementation: the diagram merely intends to provide an overview of the use-case. </p>
 *
 * <p> <figure>
 * <img src="doc-files/mediator_activation_required-sequence.png">
 * <figcaption>Sequence diagram of the mediator activation required use case</figcaption>
 * </figure> </p>
 *
 * As depicted, the command is responsible for the following sequence of actions
 * <ul>
 * 		<li> Fetch the mediator state domain object (steps 2 and 3) </li>
 * 		<li> Require activation of the obtained mediator (steps 4 and 5) </li>
 * 		<li> Given the resulting state mutation, apply it to the entity (at the repository) (step 6) </li>
 * 		<li> When the mutation is successfully applied: </li>
 * 			<ul>
 * 				<li> Create the corresponding event (step 8) </li>
 * 				<li> Schedule the mediator's activation (step 9)</li>
 * 				<li> Dispatch the created event (send it out-bound) (step 10)</li>
 * 			 </ul>
 * </ul>
 *
 * <p> Notice that the depicted sequence assumes correct execution. If any error occurs, an exception is thrown.
 * In particular, if any of the command's pre-conditions fails. This decision is due to the observation that,
 * if any of those conditions fail, then there is a logical error on the application. We are therefore better
 * off reporting that error as soon as it is detected. </p>
 *
 * The command's pre-conditions are:
 * <ul>
 * 		<li> The target mediator exists </li>
 * 		<li> The target mediator is not in the ActivationRequired state</li>
 * </ul>
 *
 * @param <C>
 *            The concrete call context type
 */

/*
 * @startuml doc-files/mediator_activation_required-sequence.png

 * !definelong CALL_START(from,to,inMsg)
 * from -> to : inMsg
 * activate to
 * !enddefinelong

 * !definelong CALL_END(from,to,outMsg)
 * from <-- to : outMsg
 * deactivate to
 * !enddefinelong

 * !definelong CALL(from,to,inMsg,outMsg)
 * CALL_START(from,to,inMsg)
 * CALL_END(from,to,outMsg)
 * !enddefinelong

 * !define CALL_ASYNC(from,to,msg) from ->> to : msg

 * !definelong TRIGGER_CALL(from,to,inMsg)
 * from --\\ to : inMsg
 * activate to
 * !enddefinelong

 * hide footbox
 * autonumber
 * boundary Connector

 * participant MediatorActivationRequired << command >>
 * participant MediatorRepository << abstraction >>
 * participant "mediatorInfo: MediatorInfoBehavior" as MediatorInfo << domain object >>
 * participant MediatorInteractionManager << domain policy >>
 * participant EventDispatcher << abstraction >>

 * activate Connector
 * CALL_START(Connector,MediatorActivationRequired,call)
 * CALL(MediatorActivationRequired,MediatorRepository,findMediatorInfo :mediatorId,:mediatorInfo)
 * CALL(MediatorActivationRequired,MediatorInfo,activationRequired, :mutation)
 * CALL_START(MediatorActivationRequired,MediatorRepository,tryUpdateMediatorInfo :mutation)

 * note right of MediatorInfo
 * The execution of the following sequence is not
 * actually performed on the MediatorInfo domain object
 * instance, although it's specified by it.
 * endnote

 * TRIGGER_CALL(MediatorRepository,MediatorInfo,on sucess => mutation.applied)
 * CALL_START(MediatorInfo,MediatorInfo, createEvent :mutation\nactivationRequiredEvent)
 * CALL_ASYNC(MediatorInfo,MediatorInteractionManager,scheduleMediatorActivation :activationRequiredEvent)
 * ref over MediatorInteractionManager
 * Asynchronous continuation of the
 * mediator activation use case
 * endref

 * CALL_ASYNC(MediatorInfo,EventDispatcher,notifyChanges :activationRequiredEvent)
 * ref over EventDispatcher
 * Event dispatching workflow
 * endref
 * deactivate MediatorInfo

 * CALL_END(MediatorRepository,MediatorInfo, )
 * CALL_END(MediatorActivationRequired,MediatorRepository, )
 * CALL_END(Connector,MediatorActivationRequired, )
 * deactivate Connector
 * deactivate MediatorInteractionManager
 * @enduml
 */
public class MediatorActivationRequired<C extends CallContext> extends Command<C, Void> {

    /**
     * Holds a reference to a helper class with common methods.
     */
    private final MediatorModificationBase delegate;

	/**
	 * Holds the reference to the component's event dispatcher
	 */
	private final MediatorNotifications eventDispatcher;

	/**
	 * Holds the target mediator identifier.
	 */
    private final int mediatorId;

    /**
     * Holds the reference to the component responsible for logging operator commands
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds the reference to the repository of physical mediator instances
     */
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;

    
    /**
     * Composable to physical connection operations
     */
    private final MediatorPhysicalConnectionOperations physicalMediatorConnectionOperations;
    
	/**
	 * Instantiates the command with the given parameters
	 *
	 * @param context The call context
	 * @param mediatorId The mediator identifier
	 * @param mediatorManagers All manager classes that allow interaction with mediators
	 * @param loggerManager Outbound logging connector
	 */
	public MediatorActivationRequired(@Nonnull C context, int mediatorId,
            @Nonnull MediatorManagers mediatorManagers,
			@Nonnull LoggerManager<C> loggerManager)
	{
		super(context);
        this.mediatorId = mediatorId;
        this.mediatorInstanceRepository = mediatorManagers.getMediatorInstanceRepository();
		this.eventDispatcher = mediatorManagers.getMediatorNotifications();
        this.loggerManager = loggerManager;
		this.delegate = new MediatorModificationBase(mediatorManagers.getMediatorRepository());
		this.physicalMediatorConnectionOperations = new MediatorPhysicalConnectionOperations(
                mediatorManagers.getMediatorRepository(), mediatorManagers.getMediatorActivationManager(),
                eventDispatcher, mediatorInstanceRepository);
	}

	/**
	 * {@inheritDoc}
	 * @throws RepositoryException When an error occurs while working with the data source.
	 * @throws UnknownMediatorIdException When an activation is being requested with an invalid mediator ID.
	 * @throws IllegalMediatorStateException If the mediator is already activated.
	 */
	@Override
	public final Void call() throws UnknownMediatorIdException, RepositoryException, IllegalMediatorStateException	{

        final Optional<MediatorPhysicalConnectionData> activeConnection =
            StreamSupport.stream(
                    mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().queryAll(mediatorId).spliterator(),
                    false)
                .filter(MediatorPhysicalConnectionData::isActive)
                .findFirst();

        if (activeConnection.isPresent()) {
            changeRequiredStateToActivated(activeConnection.get().getId());
            physicalMediatorConnectionOperations.triggerMediatorPhysicalConnectionStartingUp(activeConnection.get());
        } else {
            throw new UnknownMediatorIdException("No active mediator instances were found.");
        }

		return null;
	}

	
	private void changeRequiredStateToActivated(int activeInstanceId)
            throws UnknownMediatorIdException, RepositoryException, IllegalMediatorStateException {
    	// Get the mediator info data instance, if one exists, and instantiate it's behavioral dimension
        final MediatorEntity mediatorEntity = delegate.findMediator(mediatorId);
        final MediatorInfoBehavior mediator =  new MediatorInfoBehavior(mediatorEntity.getInfo());

		// Is this a valid state transition?
		final Optional<MediatorInfoMutationDescriptor> mutationDesc =
	        mediator.activationRequired(eventDispatcher, activeInstanceId);
		if (!mutationDesc.isPresent()) {
			throw new IllegalMediatorStateException("Trying to activate an already activated mediator");
		}

		// Mark mediator according to the performed mutation
		// Because commands may be executed concurrently, update operations may fail (notice the
		// compound action findMediatorState-updateMediatorState). In this use case, though, retry is not required.
		// Instead, we want to report an exception because concurrent mediator activation/deactivation requests should not
		// have been issued in the first place
		final Optional<MediatorInfoData> modifiedMediator = delegate.getMediatorRepository()
		        .getMediatorInfoRepository().tryUpdate(mutationDesc.get());

		if (!modifiedMediator.isPresent()) {
			throw new IllegalMediatorStateException("Trying to activate an already activated mediator");
		}

		loggerManager.createCommandLog(getContext(), new LoggerItemMediator(
                mediatorEntity.getInfo().getName(),
                "Mediator activated"));
		
	}

}
