package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelCreatedEvent;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.events.base.ChannelManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class ChannelCreatedEventHandler<C extends CallContext> extends
        SimpleChannelEventHandlerBase<C, ChannelCreatedEvent> {

    private final ChannelInteractionManager activationManager;

    public ChannelCreatedEventHandler(@Nonnull C context,
            @Nonnull ChannelManagers channelManagers) {
        super(context, channelManagers);
        activationManager = channelManagers.getChannelActivationManager();
    }

    @Override
    protected Optional<ChannelConnectionMutationDescriptor> produceMutation(ChannelConnectionBehavior state) {
        return state.setCreated(activationManager);
    }

}
