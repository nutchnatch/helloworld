package com.ossnms.dcn_manager.commands.container.assignment;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownContainerIdException;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;

import static com.google.common.collect.Sets.newHashSet;
import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Create a new single assignment. Used for new object creation.
 * @param <C> context
 */
public class CreateSingleNeAssignment<C extends CallContext> extends Command<C, Void> {
    private final ContainersNeAssignmentUpdater<C> updater;
    private final NeUserPreferencesData neInfoData;
    private final ContainerRepository containerRepository;
    private final int containerId;

    public CreateSingleNeAssignment(
            @Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final SystemRepository systemRepository,
            @Nonnull final NeUserPreferencesData neInfoData, final int containerId,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.neInfoData = neInfoData;
        this.containerId = containerId;
        this.containerRepository = containerRepository;
        updater = new ContainersNeAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository,
                containerNotifications,
                loggerManager, context);
    }

    @Override public Void call() throws CommandException, UnknownContainerIdException {
        try {
            updater.store(
                    newHashSet(new NeAssignmentData(fetchContainer(), neInfoData.getId(), AssignmentType.PRIMARY)),
                    neInfoData);
        } catch (RepositoryException e) {
            throw new CommandException(e);
        }
        return null;
    }

    private ContainerInfo fetchContainer() throws UnknownContainerIdException, RepositoryException {
        return containerRepository.query(containerId)
                .orElseThrow(() -> new UnknownContainerIdException(tr(Message.CONTAINER_DOES_NOT_EXIST, containerId)));
    }

}
