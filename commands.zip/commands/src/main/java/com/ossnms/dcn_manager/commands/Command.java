package com.ossnms.dcn_manager.commands;

import java.util.concurrent.Callable;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * Base class for commands. Commands are invoked with at least one constructor parameter
 * (the context C) and return one value.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 * @param <T> The command return type.
 *
 * @see Callable
 */
public abstract class Command<C extends CallContext, T> implements Callable<T> {

    private final C context;

    protected Command(@Nonnull C context) {
        this.context = context;
    }

    @Nonnull
    protected C getContext() {
        return context;
    }

    /**
     * Executes whatever logic is associated with this command.
     */
    @Override
    public abstract T call() throws DcnManagerException;
}
