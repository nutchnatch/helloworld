package com.ossnms.dcn_manager.commands.system;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * Retrieves all existing systems from the repository.
 *
 * <img src="doc-files/getallsystems-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getallsystems-sequence.png
 * GetSystem --> SystemRepository : queryAll()
 * activate SystemRepository
 * SystemRepository --> GetSystems : systems
 * deactivate SystemRepository
 * @enduml
 */
public class GetAllSystems<C extends CallContext> extends Command<C, Iterable<SystemInfo>> {

    private final SystemRepository repository;

    public GetAllSystems(@Nonnull C context, @Nonnull SystemRepository repository) {
        super(context);
        this.repository = repository;
    }

    @Override
    public Iterable<SystemInfo> call() throws RepositoryException {
        return repository.queryAll();
    }

}
