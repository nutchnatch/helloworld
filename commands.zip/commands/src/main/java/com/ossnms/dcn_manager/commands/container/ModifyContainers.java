package com.ossnms.dcn_manager.commands.container;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainerValidator;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemContainer;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Applies modifications to one or more DCN Containers.
 */
public class ModifyContainers<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(ModifyContainers.class);

    private final ContainerRepository containerRepository;
    private final LoggerManager<C> loggerManager;
    private final Iterable<ContainerInfoMutationDescriptor> changesRequested;
    private final ContainerNotifications containerNotifications;
    private final ContainerValidator validator;

    /**
     * Creates a new instance.
     *
     * @param context                Call context.
     * @param containerRepository    Container repository instance.
     * @param containerNotifications Connector responsible for propagating notifications
     *                               about container modifications to the outside world.
     * @param loggerManager          System logger manager, for recording action outcomes.
     * @param changes                Collection of changes that should be applied to existing DCN containers.
     */
    public ModifyContainers(
            @Nonnull C context,
            @Nonnull ContainerRepository containerRepository,
            @Nonnull SystemRepository systemRepository,
            @Nonnull ContainerNotifications containerNotifications,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull Iterable<ContainerInfoMutationDescriptor> changes) {
        super(context);
        this.containerRepository = containerRepository;
        this.containerNotifications = containerNotifications;
        this.loggerManager = loggerManager;
        this.changesRequested = changes;
        this.validator = new ContainerValidator(containerRepository, systemRepository);
    }

    @Override public Void call() throws CommandException {
        boolean allChangesOk = true;

        for (final ContainerInfoMutationDescriptor descriptor : changesRequested) {
            validateNewName(descriptor);

            final boolean result = modifyContainer(descriptor);
            allChangesOk &= result;
        }

        if (!allChangesOk) {
            throw new CommandException(tr(Message.SOME_CONTAINER_CHANGES_FAILED));
        }

        return null;
    }

    private void validateNewName(ContainerInfoMutationDescriptor descriptor) throws CommandException {
        if (descriptor.getName().isPresent()) {
            try {
                validator.validateNewName(descriptor.getName().get());
            } catch (final DuplicatedObjectNameException | RepositoryException e) {
                throw new CommandException(e);
            }
        }
    }

    private boolean modifyContainer(final ContainerInfoMutationDescriptor descriptor) {
        try {
            descriptor.whenApplied(in -> {
                containerNotifications.notifyChanges(in);
                logResult(in.getTarget().getName(), true);
            });

            final Optional<ContainerInfo> updatedContainer = containerRepository.tryUpdate(descriptor);

            if (updatedContainer.isPresent()) {
                return true;
            } else {
                LOGGER.warn("Failed to update DCN container with {}: concurrent modification.", descriptor);
                logResult(descriptor.getTarget().getName(), false);
            }
        } catch (final RepositoryException exception) {
            LOGGER.warn("Error while updating DCN container with {}: {}", descriptor,
                    Throwables.getStackTraceAsString(exception));
            logResult(descriptor.getTarget().getName(), false);
        }
        return false;
    }

    private void logResult(String containerName, boolean operationSucceeded, Object... messageParameters) {
        final String messageText = tr(operationSucceeded ? Message.CONTAINER_CHANGED : Message.CONTAINER_CHANGE_FAILED,
                messageParameters);
        final LoggerItem logItem = new LoggerItemContainer(containerName, messageText,
                operationSucceeded ? MessageSeverity.INFO : MessageSeverity.WARNING);
        loggerManager.createCommandLog(getContext(), logItem);
    }

}
