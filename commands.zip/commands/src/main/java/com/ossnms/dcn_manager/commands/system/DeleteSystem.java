package com.ossnms.dcn_manager.commands.system;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemSystem;
import com.ossnms.dcn_manager.core.entities.container.system.SystemDeletionDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownSystemIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Deletes an existing System Container.
 * Exceptions will be thrown upon execution if the system can not be deleted.
 *
 * <img src="doc-files/deletesystemcmd-activity.png">
 * <img src="doc-files/deletesystemcmd-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/deletesystemcmd-activity.png
 * start
 *   :Delete System from repository;
 *   :Produce deletion notifications;
 *   :Produce log entries;
 * stop
 * @enduml
 */
/*
 * @startuml doc-files/deletesystemcmd-sequence.png
 * DeleteSystem --> SystemRepository : findSystem(systemId)
 * activate SystemRepository
 * SystemRepository --> DeleteSystem : system
 * deactivate SystemRepository
 * DeleteSystem --> SystemRepository : delete(system)
 * DeleteSystem --> Notifications : notifyDelete(system)
 * DeleteSystem --> LoggerManager : createCommandLog(...)
 * end
 * @enduml
 */
public class DeleteSystem<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = LoggerFactory.getLogger(DeleteSystem.class);

    private final SystemNotifications notifications;
    private final LoggerManager<C> loggerManager;
    private final int systemId;
    private final SystemRepository systemRepository;

    public DeleteSystem(@Nonnull C context, @Nonnull SystemRepository systemRepository,
                    @Nonnull SystemNotifications notifications, @Nonnull LoggerManager<C> loggerManager,
                    int systemId) {
        super(context);
        this.systemRepository = systemRepository;
        this.notifications = notifications;
        this.loggerManager = loggerManager;
        this.systemId = systemId;
    }

    @Override
    public Void call() throws UnknownSystemIdException, CommandException {
        try {
            final Optional<SystemInfo> system = systemRepository.query(systemId);
            if (system.isPresent()) {
                systemRepository.delete(new SystemDeletionDescriptor(systemId));
                logAndNotify(system.get());
            } else {
                LOGGER.info("Trying to delete unknown system with ID {}", systemId);
            }
            return null;
        } catch (final RepositoryException e) {
            throw new CommandException(e);
        }
    }

    private void logAndNotify(SystemInfo system) {
        notifications.notifyDelete(system);

        LOGGER.info("Delete System: System Id={} Name={} was deleted.",
                systemId, system.getName());

        loggerManager.createCommandLog(getContext(),
                new LoggerItemSystem(system.getName(), tr(Message.SYSTEM_DELETED)));
    }

}
