package com.ossnms.dcn_manager.commands.ne.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.ne.NetworkElementActivation;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Command that requires the activation of a given NE. As with all other commands, instances are
 * immutable and all dependencies are injected through the constructor. Instances are not to be reused,
 * that is, for each incoming external stimulus an new instance is specifically created to deal with it.</p>
 *
 * <p>The activation state of a NE represents whether that NE is required to be active or not, for
 * network management purposes. Whenever a NE activation is required, it is set to the ActivationRequired
 * state and the NE connection establishment sequence is triggered (a.k.a. actual NE activation).
 * Although this sequence is not completely materialized in this command, due to the sequence's asynchronous nature,
 * it is described herein for clarity and depicted in the following figure. Note that the exact types and method names
 * may differ from the actual implementation: the diagram merely intends to provide an overview of the use-case. </p>
 *
 * <p> <figure>
 * <img src="doc-files/ne_activation_required-sequence.png">
 * <figcaption>Simplified sequence diagram of the NE activation required use case</figcaption>
 * </figure> </p>
 *
 * <p>As depicted, the command is responsible for the following sequence of actions:</p>
 * <ul>
 * 		<li> Fetch the NE state domain object (steps 2 and 3) </li>
 * 		<li> Require activation of the obtained NE (steps 4 and 5) </li>
 * 		<li> Given the resulting state mutation, apply it to the entity (at the repository) (step 6) </li>
 * 		<li> When the mutation is successfully applied: </li>
 * 			<ul>
 * 				<li> Create the corresponding event (step 8) </li>
 * 				<li> Schedule the NE's activation (step 9)</li>
 * 				<li> Dispatch the created event (send it out-bound) (step 10)</li>
 * 			 </ul>
 * </ul>
 *
 * <p> Notice that the depicted sequence assumes correct execution. If any error occurs, an exception is thrown.
 * In particular, if any of the command's pre-conditions fails. This decision is due to the observation that,
 * if any of those conditions fail, then there is a logical error on the application. We are therefore better
 * off reporting that error as soon as it is detected. </p>
 *
 * <p>The command's pre-conditions are:</p>
 * <ul>
 * 		<li> The target NE exists </li>
 * 		<li> The target NE is not in the ActivationRequired state</li>
 * </ul>
 *
 * @see <a href="https://confluence.intra.coriant.com/display/TMRD/NE+%28de%29activation+races">Confluence page on NE (de)activation races</a>
 *
 * @param <C>
 *            The concrete call context type
 */

/*
 * @startuml doc-files/ne_activation_required-sequence.png
 *
 * !definelong CALL_START(from,to,inMsg)
 * from -> to : inMsg
 * activate to
 * !enddefinelong
 *
 * !definelong CALL_END(from,to,outMsg)
 * from <-- to : outMsg
 * deactivate to
 * !enddefinelong
 *
 * !definelong CALL(from,to,inMsg,outMsg)
 * CALL_START(from,to,inMsg)
 * CALL_END(from,to,outMsg)
 * !enddefinelong
 *
 * !define CALL_ASYNC(from,to,msg) from ->> to : msg
 *
 * !definelong TRIGGER_CALL(from,to,inMsg)
 * from --\\ to : inMsg
 * activate to
 * !enddefinelong
 *
 * hide footbox
 * autonumber
 * boundary Connector
 *
 * participant NetworkElementActivationRequired << command >>
 * participant NetworkElementRepository << abstraction >>
 * participant "ne: NetworkElementInfoBehavior" as NetworkElementInfo << domain object >>
 * participant "ne: NePhysicalConnectionBehavior" as NeInfoPhysicalConnection << domain object >>
 * participant NetworkElementActivationManager << domain policy >>
 * participant EventDispatcher << abstraction >>
 *
 * activate Connector
 *
 * CALL_START(Connector,NetworkElementActivationRequired,call)
 * CALL(NetworkElementActivationRequired,NetworkElementRepository,findNetworkElement(neId),ne)
 * CALL(NetworkElementActivationRequired,NeInfoPhysicalConnection,startUp(),actualMutation)
 * CALL_START(NetworkElementActivationRequired,NetworkElementRepository,tryUpdateActualActivationState(actualMutation))
 *
 * note right of NetworkElementInfo
 * The execution of the following sequence is not
 * actually performed on the NetworkElementInfo domain object
 * instance, although it's specified by it.
 * endnote
 *
 * TRIGGER_CALL(NetworkElementRepository,NetworkElementInfo,on sucess: mutation.applied())
 *
 * CALL_START(NetworkElementInfo, NetworkElementInfo, createEvent(mutation)\nactivationRequiredEvent)
 * CALL_ASYNC(NetworkElementInfo,NetworkElementActivationManager,scheduleNetworkElementActivation(activationRequiredEvent))
 * ref over NetworkElementActivationManager
 * Asynchronous continuation of the
 * NE activation use case
 * endref
 * CALL_ASYNC(NetworkElementInfo,EventDispatcher,notifyChanges(activationRequiredEvent))
 * ref over EventDispatcher
 * Event dispatching workflow
 * endref
 * deactivate NetworkElementInfo
 *
 * CALL_END(NetworkElementRepository,NetworkElementInfo, )
 * CALL_END(NetworkElementActivationRequired,NetworkElementRepository, )
 *
 * CALL(NetworkElementActivationRequired,NetworkElementInfo,activationRequired(),requiredMutation)
 * CALL(NetworkElementActivationRequired,NetworkElementRepository,tryUpdateRequiredActivationState(requiredMutation),requiredMutation)
 *
 * CALL_END(Connector,NetworkElementActivationRequired, )
 *
 * deactivate Connector
 * deactivate NetworkElementActivationManager
 *
 * @enduml
 */
public class NetworkElementActivationRequired<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(NetworkElementActivationRequired.class);

    private static final int ACTIVATION_RETRIES = 2;

    /**
     * Holds a reference to the object responsible for implementing the actual NE activation
     */
    private final NetworkElementActivation activation;

	/**
	 * Holds the target NE identifier.
	 */
    private final int neId;

    /**
     * Holds the reference to the component responsible for logging operator commands
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds a reference to the repository that stores NE data.
     */
    private final NeEntityRepository neRepository;

    /**
     * Holds a reference to the repository that stores Channel data.
     * It will be used to obtain the NEs' parent channel connection state.
     */
    private final ChannelEntityRepository channelRepository;

	/**
	 * Instantiates the command with the given parameters
	 *
	 * @param context The call context
	 * @param neId The NE identifier
	 * @param neManagers The NE management classes to be used
	 * @param channelRepository The Channel repository to be used
	 */
	public NetworkElementActivationRequired(@Nonnull C context, int neId,
	        @Nonnull NetworkElementManagers neManagers,
			@Nonnull ChannelEntityRepository channelRepository,
			@Nonnull ChannelPhysicalConnectionRepository channelInstanceRepository,
			@Nonnull LoggerManager<C> loggerManager)
	{
		super(context);
        this.neId = neId;
        this.neRepository = neManagers.getNeRepository();
        this.channelRepository = channelRepository;
        this.loggerManager = loggerManager;
        this.activation = new NetworkElementActivation(neManagers.getNeNotifications(), neRepository, neManagers.getNeActivationManager(),
                neManagers.getNeInstanceRepository(), channelInstanceRepository);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public final Void call()
            throws RepositoryException, UnknownNetworkElementIdException,
                   IllegalNetworkElementStateException, UnknownChannelIdException {

        int retries = ACTIVATION_RETRIES;

        do {

            final NeInfoData neInfo = findNe();
            final ChannelConnectionData channelConnection = findChannelConnection(neInfo.getChannelId());

            boolean canChangeRequiredState =
                    !channelConnection.isActive() ||
                    activation.changeActualStateToStartUp(neId);

            if (canChangeRequiredState) {

                // Ensure that the first synchronization after a manual activation requests all data from the mediator.
                clearSynchronisationCounters();

                if (activation.changeRequiredStateToActive(neInfo)) {

                    loggerManager.createCommandLog(getContext(), new LoggerItemNe(
                            neRepository.queryNeName(neId).orElse(String.valueOf(neId)),
                            tr(Message.NE_ACTIVATION),
                            neId));

                    return null;

                }
            }

            LOGGER.warn("Retrying NE {} activation ({}).", neId, retries);

        } while (--retries > 0);

        throw new IllegalNetworkElementStateException(tr(Message.NE_ALREADY_ACTIVE));

	}

    private boolean clearSynchronisationCounters() {

        try {
            final NeEntityRepository.NeSynchronizationRepository synchronizationRepository =
                    neRepository.getNeSynchronizationRepository();
            final Optional<NeSynchronizationData> currentCounters =
                    synchronizationRepository.query(neId);
            if (currentCounters.isPresent()) {
                final NeSynchronizationMutationDescriptor counterChanges =
                        new NeSynchronizationMutationDescriptor(currentCounters.get())
                            .clearCounters();
                if (synchronizationRepository.tryUpdate(counterChanges).isPresent()) {
                    return true;
                } else {
                    LOGGER.warn("Failed to clear NE {} counters: concurrent modification.", neId);
                }
            }
        } catch (RepositoryException e) {
            LOGGER.warn("Failed to clear NE {} counters: {}", neId, getStackTraceAsString(e));
        }

        return false;
    }

	private NeInfoData findNe() throws UnknownNetworkElementIdException, RepositoryException {
        final Optional<NeInfoData> neInfo = neRepository.getNeInfoRepository().query(neId);
        if (!neInfo.isPresent()) {
            throw new UnknownNetworkElementIdException(tr(Message.NE_DOES_NOT_EXIST, neId));
        }
        return neInfo.get();
	}

	private ChannelConnectionData findChannelConnection(int channelId) throws RepositoryException, UnknownChannelIdException {
        final Optional<ChannelConnectionData> channelConnection = channelRepository.getChannelConnectionRepository().query(channelId);
        if (!channelConnection.isPresent()) {
            throw new UnknownChannelIdException(tr(Message.CHANNEL_DOES_NOT_EXIST, channelId));
        }
	    return channelConnection.get();
	}

}
