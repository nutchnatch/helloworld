package com.ossnms.dcn_manager.events.mediator;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.EventDispatcher;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.annotation.Nonnull;

/**
 * Subscribes to an inbound event stream, dispatching each event to its appropriate handler.
 *
 * @param <C> Context instance type, propagated to handlers that need one.
 */
public class MediatorDispatcher<C extends CallContext> extends EventDispatcher<C> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorDispatcher.class);

    private final MediatorManagers mediatorManagers;
    private final ChannelManagers channelManagers;
    private final SettingsRepository settingsRepository;
    private final StaticConfiguration configuration;

    public MediatorDispatcher(@Nonnull C context,
                              @Nonnull StaticConfiguration configuration,
                              @Nonnull LoggerManager<C> loggerManager,
                              @Nonnull MediatorManagers mediatorManagers,
                              @Nonnull ChannelManagers channelManagers,
                              @Nonnull SettingsRepository settingsRepository) {
        super(context, configuration, loggerManager);
        this.mediatorManagers = mediatorManagers;
        this.channelManagers = channelManagers;
        this.settingsRepository = settingsRepository;
        this.configuration = configuration;
    }

    @Override
    public final void initialize(Observable<? extends Event> eventSource) {

        LOGGER.debug("Initializing Mediator event dispatcher.");

        subscribe(eventSource, PhysicalMediatorActivatingEvent.class,
                new PhysicalMediatorActivatingEventHandler<>(getContext(), mediatorManagers));

        subscribe(eventSource, PhysicalMediatorActivatedEvent.class,
                new PhysicalMediatorActivatedEventHandler<>(getContext(), mediatorManagers, channelManagers, settingsRepository, configuration));

        subscribe(eventSource, PhysicalMediatorDeactivatingEvent.class,
                new PhysicalMediatorDeactivatingEventHandler<>(getContext(), mediatorManagers));

        subscribe(eventSource, PhysicalMediatorDeactivatedEvent.class,
                new PhysicalMediatorDeactivatedEventHandler<>(getContext(), mediatorManagers, channelManagers));

        subscribe(eventSource, PhysicalMediatorActivationFailedEvent.class,
                new PhysicalMediatorActivationFailureEventHandler<>(getContext(), mediatorManagers, channelManagers));

        subscribe(eventSource, MediatorActivatingEvent.class,
                new MediatorActivatingEventHandler<>(getContext(), mediatorManagers));

        subscribe(eventSource, MediatorActivatedEvent.class,
                new MediatorActivatedEventHandler<>(getContext(), mediatorManagers));

        subscribe(eventSource, MediatorDeactivatingEvent.class,
                new MediatorDeactivatingEventHandler<>(getContext(), mediatorManagers));

        subscribe(eventSource, MediatorDeactivatedEvent.class,
                new MediatorDeactivatedEventHandler<>(getContext(), mediatorManagers));

        subscribe(eventSource, MediatorActivationFailedEvent.class,
                new MediatorActivationFailureEventHandler<>(getContext(), mediatorManagers));

    }

}
