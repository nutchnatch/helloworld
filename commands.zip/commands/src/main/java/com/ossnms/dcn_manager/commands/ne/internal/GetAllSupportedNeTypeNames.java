package com.ossnms.dcn_manager.commands.ne.internal;

import static com.google.common.base.Predicates.notNull;

import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Nonnull;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;

/**
 * Provides an iterable over all NE Type names.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class GetAllSupportedNeTypeNames<C extends CallContext> extends Command<C, Iterable<String>> {

    private final StaticConfiguration configuration;

    /**
     * Creates a new command instance.
     *
     * @param context Call context, to be passed on to outbound interfaces.
     * @param configuration Configuration repository instance.
     */
    public GetAllSupportedNeTypeNames(C context, @Nonnull StaticConfiguration configuration) {
        super(context);
        this.configuration = configuration;
    }

    @Override
    public Iterable<String> call() {
        return FluentIterable.from(configuration.getNeTypes().entrySet())
                .transform(new Function<Map.Entry<String, NeType>, String>() {
                    @Override
                    public String apply(Entry<String, NeType> input) {
                        return null != input ? input.getValue().getName() : null;
                    }
                })
                .filter(notNull());
    }

}
