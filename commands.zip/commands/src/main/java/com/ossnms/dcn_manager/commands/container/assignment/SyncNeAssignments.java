package com.ossnms.dcn_manager.commands.container.assignment;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.NonPrimaryContainerSettedException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Set;

/**
 * Update the Assignment NE X Container.
 */
public class SyncNeAssignments<C extends CallContext> extends Command<C, Void> {
    private static final int MAX_PRIMARY_CONTAINER_ALLOWED = 1;

    private final NeUserPreferencesData neInfoData;
    private final Set<NeAssignmentData> assignments;
    private final ContainersNeAssignmentUpdater<C> updater;

    public SyncNeAssignments(
            @Nonnull final C context,
            @Nonnull final ContainerRepository containerRepository,
            @Nonnull final SystemRepository systemRepository,
            @Nonnull final NeUserPreferencesData neInfoData,
            @Nonnull final Set<NeAssignmentData> assignments,
            @Nonnull final ContainerNotifications containerNotifications,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.neInfoData = neInfoData;
        this.assignments = assignments;

        this.updater = new ContainersNeAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository,
                containerNotifications, loggerManager, context);
    }

    @Override public Void call() throws RepositoryException, NonPrimaryContainerSettedException {

        final long primaryContainers = assignments.stream()
                .filter(neAssignmentData -> neAssignmentData.getAssignmentType() == AssignmentType.PRIMARY).count();

        if (primaryContainers != MAX_PRIMARY_CONTAINER_ALLOWED) {
            throw new NonPrimaryContainerSettedException("The NE={} assignments must have only one Primary Container",
                    neInfoData.getName());
        }

        updater.store(assignments, neInfoData);

        return null;
    }
}
