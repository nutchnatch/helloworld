package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.channel.ChannelModificationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.EventHandler;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

abstract class SimpleChannelEventHandlerBase<C extends CallContext, E extends ActualChannelStateEvent> extends
        EventHandler<C, E> {

    private final ChannelModificationBase base;
    private final ChannelNotifications notifications;

    protected SimpleChannelEventHandlerBase(@Nonnull C context, @Nonnull ChannelManagers channelManagers) {
        super(context);
        this.notifications = channelManagers.getChannelNotifications();
        this.base = new ChannelModificationBase(channelManagers.getChannelRepository());
    }

    @Override
    protected final void handleEvent(E event) throws DcnManagerException {
        final ChannelConnectionData channelConnectionState = base.findChannelConnectionState(event.getChannelId());
        final ChannelConnectionBehavior state = new ChannelConnectionBehavior(channelConnectionState, notifications);
        final Optional<ChannelConnectionMutationDescriptor> stateMutation = produceMutation(state);
        if (stateMutation.isPresent()) { // state changes to the same state are no-ops
            base.getChannelRepository().getChannelConnectionRepository().tryUpdate(stateMutation.get());
        } else {
            LoggerFactory.getLogger(getClass())
                .warn("Dropping event because Channel {} is already in state {}.",
                    channelConnectionState.getId(), channelConnectionState.getActualActivationState());
        }
    }

    protected abstract Optional<ChannelConnectionMutationDescriptor> produceMutation(@Nonnull ChannelConnectionBehavior state);

}
