package com.ossnms.dcn_manager.commands.mediator;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.mediator.MediatorPhysicalConnectionOperations;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.IllegalMediatorStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static org.slf4j.LoggerFactory.getLogger;

public class ActivateStandbyMediator<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(ActivateStandbyMediator.class);

    /**
     * Holds the reference to the repository of mediator instances
     */
    private final MediatorEntityRepository mediatorEntityRepository;

    /**
     * Holds the target mediator identifier.
     */
    private final int mediatorId;

    /**
     * Holds the reference to the component responsible for logging operator commands
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds the reference to the repository of physical mediator instances
     */
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;

    /**
     * Composable to physical connection operations
     */
    private final MediatorPhysicalConnectionOperations mediatorPhysicalConnectionOperations;

    /**
     * Holds the reference to the settings repository
     */

    private final SettingsRepository settingsRepository;
    
    /**
     * Provides access to mediator type static configuration
     */
    private final StaticConfiguration configuration;

    /**
     * Instantiates the command with the given parameters
     *
     * @param context          The call context
     * @param mediatorId       The mediator identifier
     * @param mediatorManagers object that holds references to all manager/publisher objects that are commonly used together when handling Mediator events.
     * @param loggerManager    reference to the component responsible for logging operator commands
     */
    public ActivateStandbyMediator(@Nonnull C context, int mediatorId, @Nonnull MediatorManagers mediatorManagers,
            @Nonnull LoggerManager<C> loggerManager, @Nonnull SettingsRepository settingsRepository, @Nonnull StaticConfiguration config) {
        super(context);
        this.mediatorId = mediatorId;
        this.mediatorInstanceRepository = mediatorManagers.getMediatorInstanceRepository();
        this.loggerManager = loggerManager;
        this.settingsRepository = settingsRepository;
        this.configuration = config;
        mediatorEntityRepository = mediatorManagers.getMediatorRepository();
        mediatorPhysicalConnectionOperations = new MediatorPhysicalConnectionOperations(
                mediatorManagers.getMediatorRepository(), mediatorManagers.getMediatorActivationManager(),
                mediatorManagers.getMediatorNotifications(), mediatorInstanceRepository);
    }

    /**
     * {@inheritDoc}
     *
     * @throws RepositoryException           When an error occurs while working with the data source.
     * @throws UnknownMediatorIdException    When an activation is being requested with an invalid mediator ID.
     * @throws IllegalMediatorStateException If the mediator is already activated.
     */
    @Override public final Void call()
            throws UnknownMediatorIdException, RepositoryException, IllegalMediatorStateException, CommandException {

        String mediatorName = "Mediator";
        boolean mediatorTypeSupportsHotStandby = false;
        MediatorType mediatorType = null;
        
        Optional<MediatorInfoData> mediatorOptional = mediatorEntityRepository.getMediatorInfoRepository()
                .query(mediatorId);
        if (mediatorOptional.isPresent()) {
            mediatorName = mediatorOptional.get().getName();
            mediatorType = configuration.getMediatorTypes().get(mediatorOptional.get().getTypeName());
            if(mediatorType != null) {
                mediatorTypeSupportsHotStandby = mediatorType.supportsHotStandby();    
            }
        }

        LOGGER.debug("Activate mediator on standby mode requested, med ID={}, name={} ", mediatorId, mediatorName);
        if(!mediatorTypeSupportsHotStandby) {
            LOGGER.warn("Activate mediator {} on hot standby mode command issued but hot standby mediation connections are not supported for the mediator type.",
                    mediatorName);
            return null;
        }
        
        if (settingsRepository.areStandbyConnectionsAllowed()) {
            StreamSupport
                    .stream(mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().queryAll(mediatorId)
                            .spliterator(), false).
                    filter(data -> !data.isActive()).
                    map(mediatorPhysicalConnectionOperations::prepareStartingUp).
                    filter(Optional::isPresent).map(Optional::get).
                    forEach(mediatorPhysicalConnectionOperations::execute);

            loggerManager.createCommandLog(getContext(),
                    new LoggerItemMediator(mediatorName, "Activate mediator on hot standby mode."));
        } else {
            loggerManager.createCommandLog(getContext(), new LoggerItemMediator(mediatorName,
                    "Skipping mediator activation on hot standby mode. Server is not assigned."));
            LOGGER.warn(
                    "Activate mediator {} on hot standby mode command issued but hot standby mediation connections won't be established since server is not assigned.",
                    mediatorName);
        }
        return null;
    }
}
