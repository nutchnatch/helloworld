package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelCreatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelCreatingEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class PhysicalChannelCreatingEventHandler<C extends CallContext> extends
        PhysicalChannelEventHandlerBase<C, PhysicalChannelCreatingEvent, ChannelCreatingEvent> {

    public PhysicalChannelCreatingEventHandler(@Nonnull C context, @Nonnull ChannelManagers channelManagers) {
        super(context, channelManagers);
    }

    @Override
    protected Optional<ChannelPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalChannelCreatingEvent event, ChannelPhysicalConnectionBehavior state,
            ChannelManagers channelManagers) {
        return state.setCreating();
    }

    @Override
    protected ChannelCreatingEvent produceForwardingEvent(PhysicalChannelCreatingEvent event,
            ChannelPhysicalConnectionData channelConnectionState) {
        return new ChannelCreatingEvent(event.getLogicalChannelId(), event);
    }
}
