package com.ossnms.dcn_manager.commands.channel;

import javax.annotation.Nonnull;

import com.google.common.base.Function;
import com.google.common.collect.FluentIterable;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;

/**
 * <p>Obtains the list of all Channel types supported by all Mediator types.</p>
 *
 * <p> <img src="doc-files/getallregisteredchannels-sequence.png"/></p>
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getallregisteredchannels-sequence.png
 * GetAllRegisteredChannels -> StaticConfiguration : get mediator types
 * activate StaticConfiguration
 * StaticConfiguration --> GetAllRegisteredChannels : MediatorTypes
 * deactivate StaticConfiguration
 * group For all Mediator Types
 * GetAllRegisteredChannels -> MediatorType : getSupportedChannelTypes()
 * activate MediatorType
 * GetAllRegisteredChannels <-- MediatorType : channel types
 * deactivate MediatorType
 * end
 * @enduml
 */
public class GetAllRegisteredChannels<C extends CallContext> extends Command<C, Iterable<ChannelType>> {

    private final StaticConfiguration emneConfiguration;

    public GetAllRegisteredChannels(@Nonnull C context,
                                    @Nonnull StaticConfiguration emneConfiguration) {
        super(context);
        this.emneConfiguration = emneConfiguration;
    }

    @Override
    public Iterable<ChannelType> call() {
        return FluentIterable.from(emneConfiguration.getMediatorTypes().values())
            .transformAndConcat(new Function<MediatorType, Iterable<ChannelType>>() {
                @Override
                public Iterable<ChannelType> apply(@Nonnull MediatorType input) {
                    return input.getSupportedChannelTypes();
                }
            });
    }

}
