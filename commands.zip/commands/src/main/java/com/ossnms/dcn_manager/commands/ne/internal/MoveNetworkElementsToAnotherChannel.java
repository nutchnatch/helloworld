package com.ossnms.dcn_manager.commands.ne.internal;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.IllegalNetworkElementStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.core.utils.Optionals.forPresent;
import static com.ossnms.dcn_manager.core.utils.Streams.stream;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Optional.ofNullable;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Moves a number of Network Elements from their current channels to a different channel.</p>
 * <p>
 * <p>Rules:</p><ul>
 * <li>Moves requested to the same channel are ignored.</li>
 * <li>Channels must be of the same type and NEs must not be "required active".</li>
 * </ul>
 * <p>
 * <p>Successful moves are reported to the Command Log. Most moving errors are reported as well.</p>
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class MoveNetworkElementsToAnotherChannel<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(MoveNetworkElementsToAnotherChannel.class);

    private final LoggerManager<C> loggerManager;
    private final NetworkElementNotifications notifications;
    private final NeInfoRepository neInfoRepository;
    private final NeUserPreferencesRepository nePreferencesRepository;
    private final NePhysicalConnectionRepository neInstanceRepository;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;
    private final ChannelUserPreferencesRepository channelPreferencesRepository;
    private final ChannelInfoRepository channelInfoRepository;

    private final Iterable<Integer> neIdentifiers;
    private final int newChannelId;


    /**
     * Creates a new instance.
     *
     * @param context                   Command execution context.
     * @param neManagers                NE management objects.
     * @param channelRepository         Channel entity repository.
     * @param channelInstanceRepository Physical Channel connections repository.
     * @param loggerManager             Outbound audit logging connector.
     * @param neIdentifiers             Identifiers of the NEs that should be moved.
     * @param newChannelId              Identifier of the target Channel.
     */
    public MoveNetworkElementsToAnotherChannel(
            @Nonnull C context,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull ChannelEntityRepository channelRepository,
            @Nonnull ChannelPhysicalConnectionRepository channelInstanceRepository,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull Iterable<Integer> neIdentifiers,
            int newChannelId) {
        super(context);
        this.channelInstanceRepository = channelInstanceRepository;
        this.neIdentifiers = neIdentifiers;
        this.newChannelId = newChannelId;
        this.notifications = neManagers.getNeNotifications();
        this.nePreferencesRepository = neManagers.getNeRepository().getNeUserPreferencesRepository();
        this.neInfoRepository = neManagers.getNeRepository().getNeInfoRepository();
        this.neInstanceRepository = neManagers.getNeInstanceRepository();
        this.channelInfoRepository = channelRepository.getChannelInfoRepository();
        this.channelPreferencesRepository = channelRepository.getChannelUserPreferencesRepository();
        this.loggerManager = loggerManager;
    }

    /**
     * Attempts to move every NE from its Channel to another.
     *
     * @return Nothing.
     * @throws UnknownChannelIdException When the identifier provided for the new Channel does not exist.
     * @throws RepositoryException       When a generic data source error occurs while reading Channel or NE info.
     * @throws CommandException          If at least one NE move operation failed.
     */
    @Override
    public Void call() throws UnknownChannelIdException, RepositoryException, CommandException {

        boolean allNesMovedOk = true;

        /*
         * Validate new Channel existence.
         */

        final Optional<ChannelInfoData> newChannelInfo = channelInfoRepository.query(newChannelId);
        final Optional<ChannelUserPreferencesData> newChannelPreferences = channelPreferencesRepository.query(newChannelId);
        if (!newChannelInfo.isPresent() || !newChannelPreferences.isPresent()) {
            throw new UnknownChannelIdException(tr(Message.CHANNEL_DOES_NOT_EXIST, newChannelId));
        }

        /*
         * Process every NE identifier.
         */

        for (final Integer neId : neIdentifiers) {

            final boolean movedOk = tryValidateAndMoveNE(newChannelInfo.get(), newChannelPreferences.get(), neId);
            allNesMovedOk &= movedOk;

        }

        if (!allNesMovedOk) {
            throw new CommandException(tr(Message.SOME_NE_MOVES_FAILED));
        }

        return null;
    }

    private boolean tryValidateAndMoveNE(final ChannelInfoData newChannelInfo, final ChannelUserPreferencesData newChannelPreferences, final Integer neId)
            throws RepositoryException {

        /*
         * Validate NE existence.
         */

        final Optional<NeInfoData> neInfo = neInfoRepository.query(neId);
        final Optional<NeUserPreferencesData> nePreferences = nePreferencesRepository.query(neId);
        if (!neInfo.isPresent() || !nePreferences.isPresent()) {
            LOGGER.error("NE with ID {} was not found!", neId);
            auditError(neId, "NE=" + neId, tr(Message.NE_DOES_NOT_EXIST, neId));
            return false;
        }

        /*
         * Try to associate the NE with the new channel.
         */

        try {

            tryMoveNeToAnotherChannel(neInfo.get(), nePreferences.get().getName(),
                    newChannelInfo, newChannelPreferences);

            return true;

        } catch (IllegalNetworkElementStateException | IllegalChannelStateException
                | RepositoryException | UnknownNetworkElementIdException
                | UnknownChannelIdException | DataUpdateException exception) {
            LOGGER.error("Could not move NE {}/{} to {}/{}: {} {}",
                    neId, nePreferences.get().getName(),
                    newChannelId, newChannelPreferences.getName(),
                    exception.getMessage(), Throwables.getStackTraceAsString(exception));
            auditError(neId, nePreferences.get().getName(), tr(Message.NE_MOVE_FAILED, exception.getMessage()));
            return false;
        }
    }

    private void auditError(final int neId, final String neName, final String message) {

        loggerManager.createCommandLog(getContext(),
                new LoggerItemNe(neName, message, neId, MessageSeverity.ERROR));

    }

    /**
     * Validates command prerequisites and actually moves the NE from one Channel to another.
     *
     * @return Nothing.
     * @throws UnknownNetworkElementIdException    When the NE identifier provided does not exist.
     * @throws UnknownChannelIdException           When the identifier provided for the original Channel does not exist.
     * @throws RepositoryException                 When a generic data source error occurs.
     * @throws DataUpdateException                 If the update could not be committed due to concurrency issues.
     * @throws IllegalChannelStateException        If source and target channels are not compatible.
     * @throws IllegalNetworkElementStateException If the NE is not disconnected.
     */
    private boolean tryMoveNeToAnotherChannel(
            final NeInfoData neInfo,
            final String neName,
            final ChannelInfoData newChannelInfo,
            final ChannelUserPreferencesData newChannelPreferences)
            throws RepositoryException, UnknownNetworkElementIdException,
            IllegalNetworkElementStateException, UnknownChannelIdException,
            IllegalChannelStateException, DataUpdateException {

        /*
         * Check whether the move is valid.
         */

        final int oldChannelId = neInfo.getChannelId();
        if (oldChannelId == newChannelId) {
            LOGGER.info("Ignoring NE {} move request within the same Channel {}.", neInfo.getId(), newChannelId);
            return true; // nothing to do
        }

        if (neInfo.isActive()) {
            throw new IllegalNetworkElementStateException(tr(Message.NE_ACTIVATION_REQUIRED, neName));
        }

        /*
         * Validate original Channel existence.
         */

        final Optional<ChannelInfoData> oldChannelInfo = channelInfoRepository.query(oldChannelId);
        final Optional<ChannelUserPreferencesData> oldChannelPreferences = channelPreferencesRepository.query(oldChannelId);
        if (!oldChannelInfo.isPresent() || !oldChannelPreferences.isPresent()) {
            throw new UnknownChannelIdException(tr(Message.CHANNEL_DOES_NOT_EXIST, oldChannelId));
        }

        /*
         * Validate Channel compatibility.
         */

        if (!oldChannelInfo.get().getType().equals(newChannelInfo.getType())) {
            LOGGER.error("Incompatible channels: origin {}/{}/{} vs destination {}/{}/{}",
                    oldChannelId, oldChannelPreferences.get().getName(), oldChannelInfo.get().getType(),
                    newChannelId, newChannelPreferences.getName(), newChannelInfo.getType());
            throw new IllegalChannelStateException(tr(Message.CHANNEL_TYPE_INCOMPATIBLE));
        }

        /*
         * Move!
         */

        commitMoveOperation(neInfo, neName, oldChannelPreferences.get().getName(), newChannelPreferences.getName());

        return true;
    }

    private void commitMoveOperation(final NeInfoData neInfo,
                                     final String neName, final String oldChannelName, final String newChannelName)
            throws RepositoryException, DataUpdateException {

        /*
         * Store the new channel association.
         */

        final NeInfoMutationDescriptor mutation = new NeInfoMutationDescriptor(neInfo)
                .setChannelId(newChannelId)
                .whenApplied(in -> {
                    notifications.notifyChanges(in);
                    loggerManager.createCommandLog(getContext(),
                            new LoggerItemNe(neName,
                                    tr(Message.NE_MOVED, neName, oldChannelName, newChannelName),
                                    neInfo.getId()));
                });

        final Optional<NeInfoData> updated = neInfoRepository.tryUpdate(mutation);
        if (!updated.isPresent()) {
            throw new DataUpdateException();
        }

        Map<Boolean, NePhysicalConnectionData> nes = stream(neInstanceRepository.queryAll(neInfo.getId()))
                .collect(toMap(NePhysicalConnectionData::isActive, identity()));

        Map<Boolean, ChannelPhysicalConnectionData> channels = stream(channelInstanceRepository.queryAll(newChannelId))
                .collect(toMap(ChannelPhysicalConnectionData::isActive, identity()));

        Stream.of(true, false).forEach(connectionType ->
                forPresent(ofNullable(channels.get(connectionType)), ofNullable(nes.get(connectionType)),
                        //update active and standby connections
                        (channel, ne) -> move(ne, channel.getId()),

                        //from channel without standby to one with
                        //need to create new physical ne connections for standby
                        channel -> create(neInfo.getNeId(), channel.isActive(), channel.getId()),

                        //from channel with standby to one without
                        //need to remove standby ne connection
                        ne -> remove(ne.getLogicalNeId(), ne.getId()),

                        //both channels without standby
                        () -> { /*no action*/ }));
    }

    private void move(NePhysicalConnectionData ne, int channelInstanceId) {
        try {
            neInstanceRepository.tryUpdate(new NePhysicalConnectionMutationDescriptor(ne).setChannelId(channelInstanceId));
        } catch (RepositoryException e) {
            LOGGER.error("Error getting repository.", e);
        }
    }

    private void remove(int logicalNeId, int instanceId) {
        neInstanceRepository.remove(instanceId);
        notifications.notifyDeleteInstance(logicalNeId, instanceId);
    }

    private void create(int neId, boolean active, int channelId) {
        NePhysicalConnectionData neConnection = neInstanceRepository.insert(
                new NePhysicalConnectionInitialData().setActive(active), neId, channelId);
        notifications.notifyCreateInstance(neConnection);
    }

}
