package com.ossnms.dcn_manager.commands.channel.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.channel.PhysicalChannelModification;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.ERROR;
import static com.ossnms.dcn_manager.core.utils.Optionals.forPresent;
import static com.ossnms.dcn_manager.core.utils.Streams.stream;
import static com.ossnms.dcn_manager.i18n.Message.CHANNEL_DEACTIVATION;
import static com.ossnms.dcn_manager.i18n.Message.CHANNEL_DOES_NOT_EXIST;
import static com.ossnms.dcn_manager.i18n.Message.CHANNEL_MOVED;
import static com.ossnms.dcn_manager.i18n.Message.MEDIATOR_DOES_NOT_EXIST;
import static com.ossnms.dcn_manager.i18n.Message.MEDIATOR_TYPE_INCOMPATIBILITY;
import static com.ossnms.dcn_manager.i18n.Message.SOME_CHANNEL_MOVES_FAILED;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Optional.empty;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Moves a number of Channels from their current Mediator to a different Mediator.</p>
 * <p>
 * <p>Rules:</p><ul>
 * <li>Moves requested to the same Mediator are ignored.</li>
 * <li>Mediators must be of the same type and Channels must not be "required active".</li>
 * </ul>
 * <p>
 * <p>Successful moves are reported to the Command Log. Most moving errors are reported as well.</p>
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class MoveChannelsToAnotherMediator<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(MoveChannelsToAnotherMediator.class);

    private final LoggerManager<C> loggerManager;
    private final ChannelNotifications channelNotifications;
    private final ChannelInfoRepository channelInfoRepository;
    private final ChannelUserPreferencesRepository channelUserPreferencesRepository;
    private final ChannelPhysicalConnectionRepository channelPhysicalRepository;
    private final MediatorPhysicalConnectionRepository mediatorPhysicalRepository;
    private final MediatorInfoRepository mediatorInfoRepository;

    private final Iterable<Integer> channelIdentifiers;
    private final int destinationId;
    private final PhysicalChannelModification physicalChannelModification;

    /**
     * @param context                     session context.
     * @param channelManagers             channel manager.
     * @param mediatorEntityRepository    mediation entity repository.
     * @param mediatorPhysicalRepository  mediator physical connection repository.
     * @param loggerManager               logger manager
     * @param channelIdentifiers          channels to be modified.
     * @param destinationId               destination mediator.
     * @param physicalChannelModification
     */
    public MoveChannelsToAnotherMediator(
            @Nonnull C context,
            @Nonnull ChannelManagers channelManagers,
            @Nonnull MediatorEntityRepository mediatorEntityRepository,
            @Nonnull MediatorInstanceEntityRepository mediatorPhysicalRepository,
            @Nonnull LoggerManager<C> loggerManager,
            @Nonnull Iterable<Integer> channelIdentifiers,
            int destinationId,
            @Nonnull PhysicalChannelModification physicalChannelModification) {
        super(context);
        this.mediatorPhysicalRepository = mediatorPhysicalRepository.getMediatorPhysicalConnectionRepository();
        this.channelIdentifiers = channelIdentifiers;
        this.destinationId = destinationId;
        channelNotifications = channelManagers.getChannelNotifications();
        channelUserPreferencesRepository = channelManagers.getChannelRepository().getChannelUserPreferencesRepository();
        channelInfoRepository = channelManagers.getChannelRepository().getChannelInfoRepository();
        channelPhysicalRepository = channelManagers.getChannelInstanceConnections();
        mediatorInfoRepository = mediatorEntityRepository.getMediatorInfoRepository();
        this.loggerManager = loggerManager;
        this.physicalChannelModification = physicalChannelModification;
    }

    /**
     * Attempts to move every Channel from its Mediator to another.
     *
     * @throws UnknownMediatorIdException When the identifier provided for the new Mediator does not exist.
     * @throws RepositoryException        When a generic data source error occurs while reading Mediator or Channel info.
     * @throws CommandException           If at least one Channel move operation failed.
     */
    @Override
    public Void call() throws DcnManagerException {

        MediatorInfoData destination = mediatorInfoRepository.query(destinationId)
                .orElseThrow(() -> new UnknownMediatorIdException(tr(MEDIATOR_DOES_NOT_EXIST, destinationId)));

        boolean allMovedOk = stream(channelIdentifiers)
                .map(channelId -> tryToValidateAndMoveChannel(channelId, destination))
                .peek(error -> error.ifPresent(this::commandLog))
                .map(Optional::isPresent) // hasError?
                .reduce(true, (result, hasError) -> result && !hasError);

        if (!allMovedOk) {
            throw new CommandException(tr(SOME_CHANNEL_MOVES_FAILED));
        }
        return null;
    }

    private Optional<LoggerItem> tryToValidateAndMoveChannel(Integer channelId, MediatorInfoData destination) {

        Optional<ChannelInfoData> channelInfoData = resolveChannelInfo(channelId);
        if (!channelInfoData.isPresent()) {
            return of(new LoggerItemChannel("id=" + channelId, tr(CHANNEL_DOES_NOT_EXIST, channelId), ERROR));
        }
        ChannelInfoData channelInfo = channelInfoData.get();


        Optional<ChannelUserPreferencesData> channelPreferences = resolveChannelPreferences(channelId);
        if (!channelPreferences.isPresent()) {
            return of(new LoggerItemChannel("id=" + channelId, tr(CHANNEL_DOES_NOT_EXIST, channelId, ERROR)));
        }
        String channelName = channelPreferences.get().getName();


        if (channelInfo.isActivationRequired()) {
            return of(new LoggerItemChannel(channelName, tr(CHANNEL_DEACTIVATION, channelId), ERROR));
        }


        Optional<MediatorInfoData> mediatorInfoData = resolveMediator(channelInfo.getMediatorId());
        if (!mediatorInfoData.isPresent()) {
            return of(new LoggerItemMediator("id=" + channelInfo.getMediatorId(), tr(MEDIATOR_DOES_NOT_EXIST, channelInfo.getMediatorId()), ERROR));
        }
        MediatorInfoData source = mediatorInfoData.get();


        if (!source.getTypeName().equals(destination.getTypeName())) {
            LOGGER.error("Incompatible mediators: origin {}/{} vs destination {}/{}",
                    source.getName(), source.getTypeName(), destination.getName(), destination.getTypeName());
            return of(new LoggerItemMediator(destination.getName(), tr(MEDIATOR_TYPE_INCOMPATIBILITY), ERROR));
        }


        if (source.getId() == destinationId) {
            LOGGER.info("Ignored Channel {} move request within the same Mediator {}.", channelInfo.getId(), destinationId);
            return empty();
        }


        movePhysicalChannels(channelId, destinationId);
        moveLogicalChannel(channelInfo, new LoggerItemChannel(channelName, tr(CHANNEL_MOVED, channelName, source.getName(), destination.getName())));

        return empty();
    }

    private Optional<MediatorInfoData> resolveMediator(int mediatorId) {
        try {
            return mediatorInfoRepository.query(mediatorId);
        } catch (RepositoryException e) {
            return empty();
        }
    }

    private Optional<ChannelUserPreferencesData> resolveChannelPreferences(Integer channelId) {
        try {
            return channelUserPreferencesRepository.query(channelId);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access channel repository", e);
            return empty();

        }
    }

    private Optional<ChannelInfoData> resolveChannelInfo(Integer channelId) {
        try {
            return channelInfoRepository.query(channelId);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access channel repository", e);
            return empty();
        }
    }

    private void moveLogicalChannel(ChannelInfoData channelInfo, LoggerItemChannel channelMoved) {
        try {
            channelInfoRepository.tryUpdate(new ChannelInfoMutationDescriptor(channelInfo)
                    .setMediatorId(destinationId)
                    .whenApplied(descriptor -> {
                        channelNotifications.notifyChanges(descriptor);
                        commandLog(channelMoved);
                    }));
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access channel repository", e);
        }
    }

    private void movePhysicalChannels(int channelId, int mediatorId) {
        Map<Boolean, ChannelPhysicalConnectionData> channels =
                stream(channelPhysicalRepository.queryAll(channelId))
                        .collect(toMap(ChannelPhysicalConnectionData::isActive, identity()));

        Map<Boolean, MediatorPhysicalConnectionData> mediators =
                stream(mediatorPhysicalRepository.queryAll(mediatorId))
                        .collect(toMap(MediatorPhysicalConnectionData::isActive, identity()));

        Stream.of(true, false).forEach(connectionType ->
                forPresent(ofNullable(mediators.get(connectionType)), ofNullable(channels.get(connectionType)),
                        //update active and standby connections
                        (mediator, channel) -> physicalChannelModification.move(channel, mediator.getId()),

                        //from mediator without standby to one with
                        //need to create new physical channel connections for standby
                        mediator -> physicalChannelModification.create(channelId, mediator.isActive(), mediator.getId()),

                        //from mediator with standby to one without
                        //need to remove standby channel connection
                        channel -> physicalChannelModification.remove(channel.getLogicalChannelId(), channel.getId()),

                        //both mediators without standby
                        () -> { /*no action*/ }));
    }

    private void commandLog(LoggerItem message) {
        loggerManager.createCommandLog(getContext(), message);
    }
}
