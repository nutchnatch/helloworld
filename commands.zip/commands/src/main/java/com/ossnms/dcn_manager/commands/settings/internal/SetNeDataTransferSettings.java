package com.ossnms.dcn_manager.commands.settings.internal;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDataTransferSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.DataTransferSettingsAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.utils.Consumer;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * Processes sets the Ne data transfer settings.
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
public class SetNeDataTransferSettings<C extends CallContext> extends Command<C, Void> {
    private static final Logger LOGGER = LoggerFactory.getLogger(SetNeDataTransferSettings.class);

    private final NePhysicalConnectionRepository neInstanceRepository;
    private final NeUserPreferencesRepository preferencesRepository;
    private final NeDataTransferSettings  neDataTransferSettings;
    private final NetworkElementNotifications notifications;
    private final NeConnectionManager neConnectionManager;
    private final NeInfoRepository neInfoRepository;
    private final NeEntityRepository neRepository;
    private final LoggerManager<C> logger;
    private final String neType;
    private final int neId;

    public SetNeDataTransferSettings(@Nonnull C context,
            @Nonnull int neId,
            @Nonnull String neType,
            @Nonnull NeEntityRepository neRepository,
            @Nonnull NetworkElementManagers neManagers,
            @Nonnull NeConnectionManager connectionManager,
            @Nonnull NetworkElementNotifications notifications,
            @Nonnull LoggerManager<C> logger,
            @Nonnull NeDataTransferSettings  neDataTransferSettings) {
        super(context);
        this.preferencesRepository = neRepository.getNeUserPreferencesRepository();
        this.neInstanceRepository = neManagers.getNeInstanceRepository();
        this.neInfoRepository = neRepository.getNeInfoRepository();
        this.neDataTransferSettings = neDataTransferSettings;
        this.neConnectionManager = connectionManager;
        this.notifications = notifications;
        this.neRepository = neRepository;
        this.logger = logger;
        this.neType = neType;
        this.neId = neId;
    }

    /**
     * Applies the changed property values to the Ne data transfer settings.
     * @throws CommandException When a concurrent update to the DCN Manager global settings is detected.
     */
    @Override
    public Void call() throws CommandException {
        try {
            final Optional<NeEntity> neEntity = neRepository.queryNe(neId);
            if (neEntity.isPresent()) {
                
                final NeInfoData infoData = neEntity.get().getInfo();
                final NeInfoMutationDescriptor infoMutation = new NeInfoMutationDescriptor(infoData)
                .setProxyType(neType)
                .whenApplied(new Consumer<NeInfoMutationDescriptor>() {
                    @Override
                    public void accept(NeInfoMutationDescriptor in) {
                        notifications.notifyChanges(in);
                    }
                });
                
                final NeUserPreferencesData preferences = neEntity.get().getPreferences();
                DataTransferSettingsAdapter change = new DataTransferSettingsAdapter(). mergeWith(neDataTransferSettings);
                final NeUserPreferencesMutationDescriptor prefsMutation = new NeUserPreferencesMutationDescriptor(preferences);
                prefsMutation.setDataTransferSettings(change);
                prefsMutation.whenApplied(new Consumer<NeUserPreferencesMutationDescriptor>() {
                            @Override
                            public void accept(NeUserPreferencesMutationDescriptor in) {
                                try {
                                    notifications.notifyChanges(in);
                                    Optional<NeEntity> neEntityUpdated = neRepository.queryNe(neId);
                                    neInstanceRepository.queryAll(neId)
                                    .forEach(physicalConnection -> sendPropertiesToMediator(
                                            neEntityUpdated.get(), new NeUserPreferencesMutationDescriptor(in.getResult()), physicalConnection));
                                    logResult(neId, in.getResult().getName(), true);
                                } catch (RepositoryException e) {
                                    LOGGER.error("Could not change NE {} Data Transfer Settings.", neId, e);
                                    logResult(neId, "NE="+neId, false);
                                }
                            }
                        });
                
                final Optional<NeInfoData> infoUpdated = neInfoRepository.tryUpdate(infoMutation);
                final Optional<NeUserPreferencesData> prefsUpdated = preferencesRepository.tryUpdate(prefsMutation);
                
                if (!prefsUpdated.isPresent() || !infoUpdated.isPresent()) {
                    throw new RepositoryException("Could not change NE {} Data Transfer Settings.", neId);
                }
            }
            // Ignore unknown NE identifiers.
        } catch (final RepositoryException e) {
            LOGGER.error("Could not change NE {} Data Transfer Settings.", neId, e);
            logResult(neId, "NE="+neId, false);
        }
        return null;
    }
    
    private void sendPropertiesToMediator(NeEntity ne, NeUserPreferencesMutationDescriptor newPreferences, NePhysicalConnectionData connection) {
        if (!connection.isActiveState()) {
            return;
        }
        try {
            neConnectionManager.updateNeProperties(ne, connection, newPreferences, Collections.emptyMap());
        } catch (final ConnectException e) {
            LOGGER.warn("SetNeDataTransferSettings: NE instance was connected but updating the Ne name property failed: {}",
                    connection);
            if (connection.isActive()) {
                logResult(ne.getInfo().getId(), "NE="+newPreferences.getResult().getName(), false);
            }
        }
    }
    
    private void logResult(int neId, String neName, boolean operationSucceeded, Object... messageParameters) {
        final String messageText =
            tr(operationSucceeded ? Message.NE_DATATRANSFER_PROPERTIES_CHANGED : Message.NE_DATATRANSFER_PROPERTIES_CHANGE_FAILED, messageParameters);
        final LoggerItem logItem = new LoggerItemNe(neName, messageText, neId,
            operationSucceeded ? MessageSeverity.INFO : MessageSeverity.WARNING);
        logger.createCommandLog(getContext(), logItem);
    }
    
}
