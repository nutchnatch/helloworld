package com.ossnms.dcn_manager.commands.mediator;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * Retrieves all existing mediators from the repository.
 *
 * <img src="doc-files/getallmediators-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getallmediators-sequence.png
 * GetMediators --> MediatorRepository : queryAll()
 * activate MediatorRepository
 * MediatorRepository --> GetMediators : mediators
 * deactivate MediatorRepository
 * @enduml
 */
public class GetAllMediators<C extends CallContext> extends Command<C, Iterable<MediatorEntity>> {

    private final MediatorEntityRepository repository;

    public GetAllMediators(@Nonnull C context, @Nonnull MediatorEntityRepository repository) {
        super(context);
        this.repository = repository;
    }

    @Override
    public Iterable<MediatorEntity> call() throws RepositoryException {
        return repository.queryAll();
    }

}
