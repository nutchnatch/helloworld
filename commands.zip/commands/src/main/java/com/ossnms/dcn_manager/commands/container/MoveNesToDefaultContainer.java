package com.ossnms.dcn_manager.commands.container;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.INFO;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.WARNING;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Optional.empty;
import static java.util.Optional.of;

public class MoveNesToDefaultContainer<C extends CallContext> extends Command<C, Void> {
    private static final Logger LOGGER = LoggerFactory.getLogger(MoveNesToDefaultContainer.class);

    private final ContainersNeAssignmentUpdater<C> updater;
    private final Collection<INEId> nes;
    private final NeEntityRepository neRepository;
    private final NetworkElementNotifications notifications;
    private final LoggerManager<C> loggerManager;

    public MoveNesToDefaultContainer(@Nonnull final C context,
                                     @Nonnull final Collection<INEId> nes,
                                     @Nonnull final ContainerRepository containerRepository,
                                     @Nonnull final SystemRepository systemRepository,
                                     @Nonnull final NeEntityRepository neRepository,
                                     @Nonnull final ContainerNotifications containerNotifications,
                                     @Nonnull final LoggerManager<C> loggerManager,
                                     @Nonnull final NetworkElementNotifications notifications,
                                     @Nonnull final SettingsRepository settingsRepository) {
        super(context);
        this.nes = nes;
        this.neRepository = neRepository;
        this.notifications = notifications;
        this.loggerManager = loggerManager;

        updater = new ContainersNeAssignmentUpdater<>(settingsRepository, containerRepository, systemRepository, containerNotifications,
                loggerManager, context);
    }

    @Override public Void call() throws CommandException {
        nes.forEach(this::moveNeToDefaultContainer);
        return null;
    }

    private void moveNeToDefaultContainer(INEId id) {
        fetchNePreferences(id)
                .map(this::removeFromSystem)
                .map(this::associateWithDefaultContainer);
    }

    private boolean associateWithDefaultContainer(NeUserPreferencesData nePreferences) {
        try {
            updater.defaultNeAssignment(nePreferences);
            return true;
        } catch (RepositoryException e) {
            LOGGER.error("Failed to add container assignments for {}", nePreferences, e);
        }
        return false;
    }

    private NeUserPreferencesData removeFromSystem(NeUserPreferencesData preference) {
        NeUserPreferencesMutationDescriptor mutation = new NeUserPreferencesMutationDescriptor(preference)
                .setContainerId(of(0))
                .whenApplied(descriptor -> {
                    notifications.notifyChanges(descriptor);
                    loggerManager.createCommandLog(getContext(),
                            new LoggerItemNe(descriptor.getResult().getName(), tr(Message.SYSTEM_CHANGED), descriptor.getResult().getId(), INFO));
                });
        return updateNe(mutation).orElse(preference);
    }

    private Optional<NeUserPreferencesData> updateNe(NeUserPreferencesMutationDescriptor descriptor) {
        try {
            return neRepository.getNeUserPreferencesRepository().tryUpdate(descriptor);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to perform update of {}", descriptor, e);
            loggerManager.createCommandLog(getContext(),
                    new LoggerItemNe(descriptor.getResult().getName(), tr(Message.SYSTEM_CHANGE_FAILED), descriptor.getResult().getId(), WARNING));
            return empty();
        }
    }

    private Optional<NeUserPreferencesData> fetchNePreferences(INEId id) {
        try {
            return neRepository.getNeUserPreferencesRepository().query(id.getId());
        } catch (RepositoryException e) {
            LOGGER.error("Failed to access ne repository", e);
            return empty();
        }
    }
}
