package com.ossnms.dcn_manager.events.channel;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatingEvent;
import com.ossnms.dcn_manager.events.base.ChannelManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class PhysicalChannelActivatingEventHandler<C extends CallContext> extends
        PhysicalChannelEventHandlerBase<C, PhysicalChannelActivatingEvent, ChannelActivatingEvent> {

    public PhysicalChannelActivatingEventHandler(@Nonnull C context, @Nonnull ChannelManagers channelManagers) {
        super(context, channelManagers);
    }

    @Override
    protected Optional<ChannelPhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalChannelActivatingEvent event, ChannelPhysicalConnectionBehavior state,
            ChannelManagers channelManagers) {
        return state.setActivating();
    }

    @Override
    protected ChannelActivatingEvent produceForwardingEvent(PhysicalChannelActivatingEvent event,
            ChannelPhysicalConnectionData channelConnectionState) {
        return new ChannelActivatingEvent(event.getLogicalChannelId(), event);
    }
}
