package com.ossnms.dcn_manager.events.discovery;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.events.NeDiscoveredEvent;

final class HasPropertiesPresent<C extends CallContext> extends DiscoveryFilterBase<C, NeDiscoveredEvent> {

    public HasPropertiesPresent(C context, LoggerManager<C> logManager) {
        super(context, logManager);
    }

    @Override
    public Boolean call(@Nonnull NeDiscoveredEvent event) {
        if (null != event.getProperties() && !event.getProperties().isEmpty()) {
            return true;
        } else {
            reportWarning(event, "New NE was found but properties are empty");
            return false;
        }
    }
}