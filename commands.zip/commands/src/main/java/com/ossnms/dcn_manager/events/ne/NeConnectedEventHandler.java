package com.ossnms.dcn_manager.events.ne;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.NeInformationRetrieval;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NeConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

public class NeConnectedEventHandler<C extends CallContext>
        extends NeConnectionUpdatingEventHandlerBase<C, NeConnectedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeConnectedEventHandler.class);

    private final ChannelInfoRepository channelInfoRepository;
    private final NeEntityRepository neRepository;
    private final NeInfoRepository neInfoRepository;
    private final Alarms alarms;


    public NeConnectedEventHandler(@Nonnull C context,
            @Nonnull NeEntityRepository neRepository,
            @Nonnull ChannelEntityRepository channelRepository,
            @Nonnull NetworkElementNotifications notifications,
            @Nonnull NeInformationRetrieval informationRetrieval,
            @Nonnull Alarms alarms) {
        super(context, neRepository, notifications, informationRetrieval);
        this.channelInfoRepository = channelRepository.getChannelInfoRepository();
        this.neRepository = neRepository;
        this.neInfoRepository = neRepository.getNeInfoRepository();
        this.alarms = alarms;
    }

    @Override
    protected Optional<NeConnectionMutationDescriptor> triggerMutation(NeConnectionBehavior behavior, NeConnectedEvent event) {

        event.getOriginatingPhysicalEvent().ifPresent(this::doUpdateConnectionDescription);

        try {
            final Optional<NeInfoData> neInfo = neInfoRepository.query(event.getNeId());
            if (neInfo.isPresent()) {
                final Optional<ChannelInfoData> channelInfo = channelInfoRepository.query(neInfo.get().getChannelId());
                if (channelInfo.isPresent()) {
                    return behavior.setConnected(alarms, channelInfo.get().getId(), channelInfo.get().getMediatorId());
                }
            }
            LOGGER.error("Could not find NE and Channel information for NE {}", event.getNeId());
        } catch (final RepositoryException e) {
            LOGGER.error("Retrieve NE and Channel information for NE {}: {} {}",
                    event.getNeId(), e.getMessage(), Throwables.getStackTraceAsString(e));
        }
        return Optional.empty();
    }

    private void doUpdateConnectionDescription(PhysicalNeStateEvent event) {
        try {
            NeUserPreferencesData userPrefs = neRepository.getNeUserPreferencesRepository().query(event.getLogicalNeId())
                    .orElseThrow(() -> new IllegalStateException("Unable to fetch user preferences info from neId =" + event.getNeId()));

            updateConnectionDescription(
                event.getLogicalNeId(), userPrefs, true /* we're processing a Connected event, so the NE must be connected. */);
        } catch (RuntimeException | RepositoryException e) {
            LOGGER.warn("Could not update NE connection description upon connection for NE {}, will retry upon initialization: {}",
                    event.getNeId(), e.getMessage());
        }
    }

}
