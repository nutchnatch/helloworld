package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeActivationFailedEvent;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

public class PhysicalNeActivationFailedEventHandler<C extends CallContext> extends
        PhysicalNeStatusEventHandlerBase<C, PhysicalNeActivationFailedEvent, NeActivationFailedEvent> {

    public PhysicalNeActivationFailedEventHandler(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers) {
        super(context, neManagers);
    }

    @Override
    protected Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalNeActivationFailedEvent event, NePhysicalConnectionBehavior state,
            NetworkElementManagers neManagers) {
        return state.setFailed(event.getDetailedDescription(), neManagers.getNeActivationManager());
    }

    @Override
    protected NeActivationFailedEvent produceForwardingEvent(PhysicalNeActivationFailedEvent event,
            NePhysicalConnectionData neConnectionState) {
        return new NeActivationFailedEvent(event.getLogicalNeId(), event, event.getDetailedDescription());
    }

}
