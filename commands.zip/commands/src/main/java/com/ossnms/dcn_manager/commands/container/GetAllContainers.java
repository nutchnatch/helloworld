package com.ossnms.dcn_manager.commands.container;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;

/**
 * Retrieves all existing containers from the repository.
 *
 * <img src="doc-files/getallcontainers-sequence.png">
 *
 * @param <C> The specific type of the context class, which will be passed around as necessary.
 */
/*
 * @startuml doc-files/getallcontainers-sequence.png
 * GetContainer --> ContainerRepository : queryAll()
 * activate ContainerRepository
 * ContainerRepository --> GetContainers : containers
 * deactivate ContainerRepository
 * @enduml
 */
public class GetAllContainers<C extends CallContext> extends Command<C, Iterable<ContainerInfo>> {

    private final ContainerRepository repository;

    public GetAllContainers(@Nonnull C context, @Nonnull ContainerRepository repository) {
        super(context);
        this.repository = repository;
    }

    @Override
    public Iterable<ContainerInfo> call() throws RepositoryException {
        return repository.queryAll();
    }

}
