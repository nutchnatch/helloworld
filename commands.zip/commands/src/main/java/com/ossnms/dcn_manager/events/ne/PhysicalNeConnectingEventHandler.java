package com.ossnms.dcn_manager.events.ne;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.ne.behavior.NePhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectingEvent;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Handles events requesting a physical NE connection to switch to the CONNECTING state.
 */
public class PhysicalNeConnectingEventHandler<C extends CallContext> extends
        PhysicalNeStatusEventHandlerBase<C, PhysicalNeConnectingEvent, NeConnectingEvent> {

    public PhysicalNeConnectingEventHandler(@Nonnull C context,
            @Nonnull NetworkElementManagers neManagers) {
        super(context, neManagers);
    }

    @Override
    protected Optional<NePhysicalConnectionMutationDescriptor> produceMutation(
            PhysicalNeConnectingEvent event, NePhysicalConnectionBehavior state,
            NetworkElementManagers neManagers) {
        return state.setConnecting();
    }

    @Override
    protected NeConnectingEvent produceForwardingEvent(PhysicalNeConnectingEvent event,
            NePhysicalConnectionData neConnectionState) {
        return new NeConnectingEvent(event.getLogicalNeId(), event);
    }

}
