package com.ossnms.dcn_manager.commands.channel.internal;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.channel.ChannelModificationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelInfoBehavior;
import com.ossnms.dcn_manager.core.entities.channel.behavior.ChannelPhysicalConnectionBehavior;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.Optional;

import static com.google.common.base.Predicates.and;
import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Iterables.isEmpty;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Command that requires the activation of a given channel. As with all other commands, instances are
 * immutable and all dependencies are injected through the constructor. Instances are not to be reused,
 * that is, for each incoming external stimulus an new instance is specifically created to deal with it.</p>
 *
 * <p>The activation state of a channel represents whether that channel is required to be active or not, for
 * network management purposes. Whenever a channel activation is required, it is set to the ActivationRequired
 * state and the channel connection establishment sequence is triggered (a.k.a. actual channel activation).
 * Although this sequence is not completely materialized in this command, due to the sequence's asynchronous nature,
 * it is described herein for clarity and depicted in the following figure. Note that the exact types and method names
 * may differ from the actual implementation: the diagram merely intends to provide an overview of the use-case. </p>
 *
 * <p> <figure>
 * <img src="doc-files/channel_activation_required-sequence.png">
 * <figcaption>Sequence diagram of the channel activation required use case</figcaption>
 * </figure> </p>
 *
 * As depicted, the command is responsible for the following sequence of actions
 * <ul>
 * 		<li> Fetch the channel state domain object (steps 2 and 3) </li>
 * 		<li> Require activation of the obtained channel (steps 4 and 5) </li>
 * 		<li> Given the resulting state mutation, apply it to the entity (at the repository) (step 6) </li>
 * 		<li> When the mutation is successfully applied: </li>
 * 			<ul>
 * 				<li> Create the corresponding event (step 8) </li>
 * 				<li> Schedule the channel's activation (step 9)</li>
 * 				<li> Dispatch the created event (send it out-bound) (step 10)</li>
 * 			 </ul>
 * </ul>
 *
 * <p> Notice that the depicted sequence assumes correct execution. If any error occurs, an exception is thrown.
 * In particular, if any of the command's pre-conditions fails. This decision is due to the observation that,
 * if any of those conditions fail, then there is a logical error on the application. We are therefore better
 * off reporting that error as soon as it is detected. </p>
 *
 * The command's pre-conditions are:
 * <ul>
 * 		<li> The target channel exists </li>
 * 		<li> The target channel is not in the ActivationRequired state</li>
 * </ul>
 *
 * @param <C>
 *            The concrete call context type
 */

/*
 * @startuml doc-files/channel_activation_required-sequence.png

 * !definelong CALL_START(from,to,inMsg)
 * from -> to : inMsg
 * activate to
 * !enddefinelong

 * !definelong CALL_END(from,to,outMsg)
 * from <-- to : outMsg
 * deactivate to
 * !enddefinelong

 * !definelong CALL(from,to,inMsg,outMsg)
 * CALL_START(from,to,inMsg)
 * CALL_END(from,to,outMsg)
 * !enddefinelong

 * !define CALL_ASYNC(from,to,msg) from ->> to : msg

 * !definelong TRIGGER_CALL(from,to,inMsg)
 * from --\\ to : inMsg
 * activate to
 * !enddefinelong

 * hide footbox
 * autonumber
 * boundary Connector

 * participant ChannelActivationRequired << command >>
 * participant ChannelRepository << abstraction >>
 * participant "channelInfo: ChannelInfoBehavior" as ChannelInfo << domain object >>
 * participant "channelConnection: ChannelConnectionBehavior" as ChannelConnection << domain object >>
 * participant ChannelActivationManager << domain policy >>
 * participant EventDispatcher << abstraction >>

 * activate Connector

 * CALL_START(Connector,ChannelActivationRequired,call)
 * CALL(ChannelActivationRequired,ChannelRepository,findChannelInfo(channelId),channelInfo)
 * CALL(ChannelActivationRequired,ChannelRepository,findChannelConnectionState(channelId),connectionData)
 * CALL(ChannelActivationRequired,ChannelConnection,startUp(),mutation)
 * CALL_START(ChannelActivationRequired,ChannelRepository,tryUpdateChannelConnection(mutation))

 * note right of ChannelConnection
 * The execution of the following sequence is not
 * actually performed on the ChannelConnection domain object
 * instance, although it's specified by it.
 * endnote

 * TRIGGER_CALL(ChannelRepository,ChannelConnection,on sucess: mutation.applied())

 * CALL_START(ChannelConnection, ChannelConnection, createEvent(mutation)\nstartUpEvent)
 * CALL_ASYNC(ChannelConnection,ChannelActivationManager,scheduleChannelActivation(startUpEvent))
 * ref over ChannelActivationManager
 * Asynchronous continuation of the
 * channel activation use case
 * endref
 * CALL_ASYNC(ChannelConnection,EventDispatcher,notifyChanges(startUpEvent))
 * ref over EventDispatcher
 * Event dispatching workflow
 * endref
 * deactivate ChannelConnection
 *
 * CALL_END(ChannelRepository,ChannelConnection, )
 * CALL_END(ChannelActivationRequired,ChannelRepository, )
 *
 * CALL(ChannelActivationRequired,ChannelInfo,activationRequired(),mutation)
 * CALL_START(ChannelActivationRequired,ChannelRepository,tryUpdateChannelInfo(mutation))

 * note right of ChannelInfo
 * The execution of the following sequence is not
 * actually performed on the ChannelInfo domain object
 * instance, although it's specified by it.
 * endnote

 * TRIGGER_CALL(ChannelRepository,ChannelInfo,on sucess: mutation.applied())

 * CALL_START(ChannelInfo, ChannelInfo, createEvent(mutation)\nactivationRequiredEvent)
 * CALL_ASYNC(ChannelInfo,EventDispatcher,notifyChanges(activationRequiredEvent))
 * deactivate ChannelInfo

 * CALL_END(ChannelRepository,ChannelInfo, )
 *
 * CALL_END(ChannelActivationRequired,ChannelRepository, )
 * CALL_END(Connector,ChannelActivationRequired, )

 * deactivate Connector
 * deactivate ChannelActivationManager
 * @enduml
 */
public class ChannelActivationRequired<C extends CallContext> extends Command<C, Void> {

    private static final Logger LOGGER = getLogger(ChannelActivationRequired.class);

    /**
     * Holds a reference to a helper class with common methods.
     */
    private final ChannelModificationBase delegate;

	/**
	 * Holds a reference to the object responsible for implementing the channel activation policy
	 */
	private final ChannelInteractionManager activationManager;

	/**
	 * Holds the reference to the component's event dispatcher
	 */
	private final ChannelNotifications eventDispatcher;

	/**
	 * Holds the target channel identifier.
	 */
    private final int channelId;

    /**
     * Holds the reference to the component responsible for logging operator commands
     */
    private final LoggerManager<C> loggerManager;

    /**
     * Holds a reference to the repository containing mediator data
     */
    private final MediatorEntityRepository mediatorRepository;

    /**
     * Holds a reference to the repository containing physical mediator instance connection data.
     */
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;

    /**
     * Holds a reference to the repository containing connection information to channel instances on physical mediators.
     */
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;

	/**
	 * Instantiates the command with the given parameters
	 *
	 * @param context The call context
	 * @param channelId The channel identifier
	 * @param channelManagers Channel management parameter object
     * @param mediatorRepository The mediator repository to be used
	 */
	public ChannelActivationRequired(@Nonnull C context,
	        int channelId,
	        @Nonnull ChannelManagers channelManagers,
			@Nonnull MediatorEntityRepository mediatorRepository,
			@Nonnull MediatorInstanceEntityRepository mediatorInstanceRepository,
			@Nonnull LoggerManager<C> loggerManager)
	{
		super(context);
        this.channelId = channelId;
        this.mediatorInstanceRepository = mediatorInstanceRepository;
		this.activationManager = channelManagers.getChannelActivationManager();
		this.channelInstanceRepository = channelManagers.getChannelInstanceConnections();
        this.mediatorRepository = mediatorRepository;
		this.eventDispatcher = channelManagers.getChannelNotifications();
        this.loggerManager = loggerManager;
		this.delegate = new ChannelModificationBase(channelManagers.getChannelRepository());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public final Void call() throws DcnManagerException
	{
	    final ChannelInfoData channelInfo = delegate.findRequiredChannelState(channelId);
	    final MediatorConnectionData mediatorConnection = findMediatorConnectionState(channelInfo);
	    final Iterable<ChannelPhysicalConnectionData> channelInstancesForActivation = findChannelInstancesForActivation(channelId);

        changeRequiredStateToActive(channelInfo, Collections.emptyList());

		loggerManager.createCommandLog(getContext(), new LoggerItemChannel(
                delegate.tryFindChannelName(channelId).orElse(String.valueOf(channelId)),
				tr(Message.CHANNEL_ACTIVATION)));

		if (mediatorConnection.getActualActivationState() == ActualActivationState.ACTIVE) {
		    // Schedule connection establishment only if the channel's parent mediator was active
		    channelInstancesForActivation.forEach(data -> changeInstanceActualStateToStartup(data, channelInfo.getMediatorId()));
		}

		return null;
	}

	private void changeInstanceActualStateToStartup(ChannelPhysicalConnectionData data, int mediatorId) {
	    try {
            final Optional<ChannelPhysicalConnectionMutationDescriptor> mutation =
                    new ChannelPhysicalConnectionBehavior(data, eventDispatcher)
                        .startUp(activationManager, new Activate(channelId, mediatorId, Collections.singleton(data.getId())));
            if (mutation.isPresent()) {
                final Optional<ChannelPhysicalConnectionData> result =
                        channelInstanceRepository.tryUpdate(mutation.get());
                if (!result.isPresent()) {
                    LOGGER.warn("Concurrent modification on channel instance connection id {}.", mutation.get().getTarget().getId());
                }
            } else {
                LOGGER.warn("Could not activate physical channel instance with id {} already active.", data.getId());
            }
	    } catch (final RepositoryException e) {
	        LOGGER.error("Error activating physical channel instance id {}: {}", data.getId(), Throwables.getStackTraceAsString(e));
	    }
	}

    private void changeRequiredStateToActive(ChannelInfoData channelInfo, Iterable<Integer> channelInstancesForActivation)
            throws IllegalChannelStateException, RepositoryException {
        // Is this a valid Required State transition?
        final Optional<ChannelInfoMutationDescriptor> mutationDesc =
		        new ChannelInfoBehavior(channelInfo)
		            .activationRequired(eventDispatcher, channelInstancesForActivation);
		if (!mutationDesc.isPresent()) {
			throw new IllegalChannelStateException(tr(Message.CHANNEL_ALREADY_ACTIVE));
		}
		// Could we persist the new Required State?
		final Optional<ChannelInfoData> modifiedChannel = delegate.getChannelRepository().getChannelInfoRepository()
	            .tryUpdate(mutationDesc.get());
		if(!modifiedChannel.isPresent()) {
		    throw new IllegalChannelStateException(tr(Message.CHANNEL_ALREADY_ACTIVE));
		}
    }

    private Iterable<ChannelPhysicalConnectionData> findChannelInstancesForActivation(int logicalChannelId) throws UnknownChannelIdException {
        final Iterable<ChannelPhysicalConnectionData> channels = channelInstanceRepository.queryAll(logicalChannelId);
        if (isEmpty(channels)) {
            throw new UnknownChannelIdException();
        }
        return filter(channels, and(ChannelPhysicalConnectionData::isActive, this::isMediatorInstanceActive));
    }

    private boolean isMediatorInstanceActive(ChannelPhysicalConnectionData channelInstance) {
        try {
            final Optional<MediatorPhysicalConnectionData> mediatorConnection =
                    mediatorInstanceRepository.getMediatorPhysicalConnectionRepository().query(channelInstance.getMediatorInstanceId());
            if (mediatorConnection.isPresent()) {
                return mediatorConnection.get().getActualActivationState() == ActualActivationState.ACTIVE;
            }
            LOGGER.error("Connection information for mediator instance {} does not exist!",
                    channelInstance.getMediatorInstanceId());
        } catch (final RepositoryException e) {
            LOGGER.error("Error looking up mediator instance {}: {}",
                    channelInstance.getMediatorInstanceId(), Throwables.getStackTraceAsString(e));
        }
        return false;
    }

    /**
     * Tries to find the communications state of the channels' parent mediator in the repository.
     *
     * @return An instance of the mediator connection state.
     * @throws UnknownMediatorIdException If the mediator can not be found.
     * @throws RepositoryException If some error occurred while working with the repository.
     */
    private MediatorConnectionData findMediatorConnectionState(ChannelInfoData info)
            throws RepositoryException, UnknownMediatorIdException {
        final Optional<MediatorConnectionData> state = mediatorRepository.getMediatorConnectionRepository().query(info.getMediatorId());
        if (!state.isPresent()) {
            throw new UnknownMediatorIdException(tr(Message.MEDIATOR_DOES_NOT_EXIST, info.getMediatorId()));
        }
        return state.get();
    }
}
