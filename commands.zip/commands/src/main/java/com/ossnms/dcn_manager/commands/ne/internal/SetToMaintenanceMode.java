package com.ossnms.dcn_manager.commands.ne.internal;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.NeAccessControlManager;
import com.ossnms.dcn_manager.composables.outbound.exception.AccessControlException;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;

public class SetToMaintenanceMode<C extends CallContext> extends AccessControlCommandTemplate<C> {
    
    public SetToMaintenanceMode(@Nonnull final C context, @Nonnull final NeAccessControlManager<C> accessControlManager,
            @Nonnull final NeEntityRepository repository, @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull Integer neId) {
        super(context, accessControlManager, repository, loggerManager, neId);                
    }

    @Override
    public String getCommandLogSuccessMessage() {
        return "NE set to maintenance mode";
    }

    @Override
    public String getCommandLogErrorMessage() {
        return getCommandLogSuccessMessage() + " failed";
    }

    @Override
    public void callAccessControlCommand() throws AccessControlException {
        getAccessControlManager().toMaitenanceMode(getContext(), getNeId());
    }
}
