package com.ossnms.bicnet.reportmanager.dto.export;

public interface IExportableReader extends IReportManagerExportItem {

    ExportableReaderType getExportableReaderIdentification();

    Iterable<IExportableReader> getReaders();
}
