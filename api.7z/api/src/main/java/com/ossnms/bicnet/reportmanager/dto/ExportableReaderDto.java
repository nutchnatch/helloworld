package com.ossnms.bicnet.reportmanager.dto;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;

import java.io.Serializable;

public class ExportableReaderDto implements Serializable, Cloneable {

    private Long id;
    private String exportableName;
    private int selection;
    private ExportableReaderType readerType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getExportableName() {
        return exportableName;
    }

    public void setExportableName(String exportableName) {
        this.exportableName = exportableName;
    }

    public int getSelection() {
        return selection;
    }

    public void setSelection(int activation) {
        this.selection = activation;
    }

    public ExportableReaderType getReaderType(){
        return readerType;
    }

    public void setReaderType(ExportableReaderType readerType) {
        this.readerType = readerType;
    }
}
