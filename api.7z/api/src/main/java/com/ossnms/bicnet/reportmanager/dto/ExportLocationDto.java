package com.ossnms.bicnet.reportmanager.dto;


import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import java.io.Serializable;

public class ExportLocationDto implements Serializable {

    private static final long serialVersionUID = 8425743309332750253L;

    private String exportId;
    private TransferSettings transferSettings;

    public String getExportId() {
        return exportId;
    }

    public void setExportId(String exportId) {
        this.exportId = exportId;
    }

    public TransferSettings getTransferSettings() {
        return transferSettings;
    }

    public void setTransferSettings(TransferSettings transferSettings) {
        this.transferSettings = transferSettings;
    }
}
