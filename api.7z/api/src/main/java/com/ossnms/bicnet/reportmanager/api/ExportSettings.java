package com.ossnms.bicnet.reportmanager.api;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import java.io.Serializable;

import static com.ossnms.bicnet.reportmanager.api.ImmutableExportSettings.of;

@Immutable 
public interface ExportSettings extends Serializable {

    ExportSettings DEFAULT = of(90, "/");

    @Parameter int retentionNumber();

    @Parameter String exportPath();
}
