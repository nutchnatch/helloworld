package com.ossnms.bicnet.reportmanager.dto;

public enum JobExecutionStatus {

    /**
     * Enum that contain the Status representing the Job states.
     * During Job execution lifecycle, state can pass through these Status
     */
    STARTING("Starting"), STARTED("Started"), STOPPING("Stopping"), FAILED("Failed"), FINISHED("Finished"), CANCELED("Canceled");

    JobExecutionStatus(String jobState){
        state = jobState;
    }

    private String state;
    public String toString() {
        return state;
    }
}
