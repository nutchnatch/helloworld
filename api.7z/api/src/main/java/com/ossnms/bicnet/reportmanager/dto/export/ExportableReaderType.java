package com.ossnms.bicnet.reportmanager.dto.export;


public enum ExportableReaderType {

    TOPOLOGICAL_SYMBOL,
    TOPOLOGICAL_CONTAINER,
    PHISICAL_TRAIL,

    MEDIATOR,
    CHANNEL,
    NE
}
