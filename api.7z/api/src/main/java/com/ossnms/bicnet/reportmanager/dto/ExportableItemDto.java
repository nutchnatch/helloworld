package com.ossnms.bicnet.reportmanager.dto;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;

import java.io.Serializable;

public class ExportableItemDto implements Serializable, Cloneable {

    private Long id;
    private String exportableName;
    private int selection;
    private Iterable<ExportableReaderDto> readers;
    private ExportableItemType exportableItemType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getExportableName() {
        return exportableName;
    }

    public void setExportableName(String exportableName) {
        this.exportableName = exportableName;
    }

    public int getSelection() {
        return selection;
    }

    public void setSelection(int activation) {
        this.selection = activation;
    }

    public Iterable<ExportableReaderDto> getReaders() {
        return readers;
    }

    public void setReaders(Iterable<ExportableReaderDto> readers) {
        this.readers = readers;
    }

    public ExportableItemType getExportableItemType() {
        return exportableItemType;
    }

    public void setExportableItemType(ExportableItemType exportableItemType) {
        this.exportableItemType = exportableItemType;
    }
}
