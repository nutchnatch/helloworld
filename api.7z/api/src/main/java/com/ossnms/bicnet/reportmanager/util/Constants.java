package com.ossnms.bicnet.reportmanager.util;

import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;

public final class Constants {

    /**
     * Report Manager Bicnet Component Type.
     */
    public static final BiCNetComponentType BICNET_COMPONENT_TYPE = BiCNetComponentType.REPORT_MANAGER;

    /**
     * Identifies action information to be delivered on the notifications.
     */
    public static final String ACTION_TYPE = "ACTION_TYPE";

    /**
     * Identifies the Inventory Manager for report operations
     */
    public static final String INVENTORY_EXPORT_REPORT = "Inventory Export";

    /**
     * Identifies the Outage Manager for report operations
     */
    public static final String ALARMS_OUTAGE_REPORT = "Alarms Outage Report";

    /**
     * Global configuration export
     */
    public static final String CONFIGURATION_EXPORT_REPORT = "Configuration Export";

    /**
     * Alarm Messaging export
     */
    public static final String ALARM_MESSAGING_REPORT = "Alarm Messaging";
    
    
    /**
     * DCN_MANAGEMENT step
     */
    public static final String DCN_MANAGEMENT = "DCN Management";

    /**
     * Mediators
     */
    public static final String MEDIATORS = "Mediators";

    /**
     * CHANNELS
     */
    public static final String CHANNELS = "Channels";

    /**
     * NETWORK_ELEMENTS
     */
    public static final String NETWORK_ELEMENTS = "Network Elements";

    /**
     * Container
     */
    public static String CONTAINER = "Container";

    /**
     * System
     */
    public static String SYSTEM = "System";

    /**
     * TOPO step
     */
    public static final String TOPO = "Topology Management";

    /**
     * Phisical Traili
     */
    public static final String PHISICAL_TRAILS = "Physical Trails";

    /**
     * Topological Container
     */
    public static final String TOPOLOGICAL_CONTAINERS = "Topological Containers";

    /**
     * Topological Symbol
     */
    public static final String TOPOLOGICAL_SYMBOLS = "Topological Symbols";

    
    public static final String ACTION_TYPE_REPORT_EXECUTION = "Report Execution";

    private Constants() {
    }
}
