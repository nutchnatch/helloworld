package com.ossnms.bicnet.reportmanager.facade;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;

import java.util.Collection;
import java.util.List;

/**
 * Interface with operations to be executes on a private context, between ReportManager Client and Server
 */
public interface IReportManagerPrivateFacade extends IFacade {

    /**
     * Execute an immediate (manual) export Operation for a given kind of Export.
     * @param sessionContext - Contains session context
     * @param reportId - Contains Identification for the specific kind of Export
     * @param transferSettings settings to identify export location
     * @throws BcbException - In case of errors, this Exception is thrown
     */
    void startInventoryReport(ISessionContext sessionContext, String reportId, TransferSettings transferSettings) throws BcbException;

    /**
     * Execute an immediate (manual) export Operation for a given kind of Export.
     * @param sessionContext - Contains session context
     * @param reportId - Contains Identification for the specific kind of Export
     * @param exportableItems configuration items selected to be exported
     * @param transferSettings settings to the final export operation
     * @throws BcbException - In case of errors, this Exception is thrown
     */
    void startConfigurationReport(ISessionContext sessionContext, String reportId, IExportableItem[] exportableItems,
                                  TransferSettings transferSettings) throws BcbException;

    /**
     * Starts immediate export operation for a given Export type
     * @param sessionContext - server session context
     * @param reportId - identifies the export type
     * @param recordFilter - filter to be applied before the export
     * @param nes - Network Element to be used on the filter for this export
     * @throws BcbException - when errors occur
     */
    void startAlarmOutageReport(ISessionContext sessionContext, String reportId, ILogRecordFilter recordFilter,
                                INEId[] nes) throws BcbException;

    /**
     * Configure the schedule export Operation to be run in a give time for a given kind of Export.
     * @param sessionContext - Contains session context
     * @param reportId - Contains Identification for the specific kind of Export
     * @param schedule - Contains the specific configuration for the Schedule
     * @param exportableItems - Items to be exported
     * @throws BcbException - In case of errors, this Exception is thrown
     */
    void scheduleConfigurationReport(ISessionContext sessionContext, String reportId, ISchedule schedule, IScheduleMarkable mark,
                                     IExportableItem[] exportableItems, ExportLocationDto exportLocationDto) throws BcbException;

    /**
     * Configure the schedule export Operation to be run in a give time for a given kind of Export.
     * @param sessionContext - Contains session context
     * @param reportId - Contains Identification for the specific kind of Export
     * @param schedule - Contains the specific configuration for the Schedule
     * @param exportLocationDto
     * @throws BcbException - In case of errors, this Exception is thrown
     */
    void scheduleInventoryReport(ISessionContext sessionContext, String reportId, ISchedule schedule, IScheduleMarkable mark, ExportLocationDto exportLocationDto) throws BcbException;

    /**
     * @param sessionContext Session Context
     * @param reportId - Contains Identification for the specific kind of Export
     * @param schedule - Contains the specific configuration for the Schedule
     * @param alarmSettingsDto - Settings to be saved
     * @throws BcbException
     */
    void scheduleOutageAlarm(ISessionContext sessionContext, String reportId, ISchedule schedule, IScheduleMarkable mark, OutageAlarmSettingsDto alarmSettingsDto) throws BcbException;

    /**
     * Provides report data for a given kind of export
     * @param sessionContext - Contains session context
     * @param reportId - Contains Identification for the specific kind of Export
     * @return - ReportDataDto containing configured export data and the results for the las execution
     * @throws BcbException - In case of errors, this Exception is thrown
     */
    ReportDataDto getReportData(ISessionContext sessionContext, String reportId) throws BcbException;

    /**
     * Fetches system settings object
     * @param sessionContext session context
     * @return system settings
     */
    SystemSettings getSystemSettings(ISessionContext sessionContext);

    /**
     * Persists system settings
     * @param sessionContext session context
     * @param settings system settings object
     * @param updateMessages collection of messages for command log
     */
    void updateSystemSettings(ISessionContext sessionContext, SystemSettings settings, Collection<String> updateMessages);

    List<DcnObject> getDcnList(ISessionContext sessionContext) throws BcbException;

    /**
     * Get All exportable Items persisted on Database
     * @return exportable items.
     */
    Iterable<ExportableItemDto> getExportableItems();

    Boolean createScheduleAlarmMessaging(ISessionContext sessionContext, String reportId, IScheduleMarkable mark) throws BcbException;
    
    Boolean createCriteriaAlarmMessaging(ISessionContext sessionContext, AlarmMessagingCriteriaSettings settings) throws BcbException;
    
    /**
     * Get the Export Location Data persisted on Database
     * @return Export Location Data
     */
    List<ExportLocationDto> getExportLocationData();

    /**
     * Get filter on Alarm List context wich can be added many filter conditions
     * @return ILogRecordFilter
     * @throws BcbException when exception ocuur getting filter
     */
    ILogRecordFilter getAlarmFilter() throws BcbException;

    /**
     * Get Outage Alarm saved Settings
     * @return OutageAlarmSettingsDto
     */
    OutageAlarmSettingsDto getOutageAlarmSettingsItems();

    AlarmMessagingCriteriaSettings getAlarmMessagingCriteriaSettings(ISessionContext sessionContext) throws BcbException;
}
