package com.ossnms.bicnet.reportmanager.servicelocator;


import java.io.InputStream;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.servicelocator.AbstractPropertyBasedCFServiceLocator;
import com.ossnms.bicnet.util.ApplicationProperties;

public final class ReportManagerServiceLocator extends AbstractPropertyBasedCFServiceLocator {

    private static final String CALLSTYLE_PROPERTIES = "/reportManager-callstyle.properties";

    private static final String SERVICE_PROPERTIES = "/reportManager-services.properties";

    /**
     * Holds singleton instance.
     */
    private static ReportManagerServiceLocator instance = new ReportManagerServiceLocator();

    /**
     * Singleton constructor.
     */
    private ReportManagerServiceLocator() {
        /*
          After this call, super class will call init() method that is override and implemented in this class.
         */
        super();
    }

    /**
     * Getter for ReportManagerCallStyleProperties.
     *
     * @param resourceName properties file name
     * @return {@link ApplicationProperties} for ReportManagerCallStyle.
     */
    private static ApplicationProperties getApplicationProperties(String resourceName) {
        InputStream in = ReportManagerServiceLocator.class.getResourceAsStream(resourceName);
        if (null == in) {
            in = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourceName);
        }
        return ApplicationProperties.getInstance(resourceName, in);
    }

    /**
     * Returns the Singleton HelloWorldServiceLocator instance.
     *
     * @return the Singleton Service Locator instance
     **/
    public static synchronized ReportManagerServiceLocator getInstance() {
        return instance;
    }

    /**
     * Initialize Service Locator by reading service and call style set-up from property files and registering public
     * and private Facade interfaces.
     **/
    @Override
    protected synchronized void init() {
        ApplicationProperties serviceProps = getApplicationProperties(SERVICE_PROPERTIES);
        ApplicationProperties callStyleProps = getApplicationProperties(CALLSTYLE_PROPERTIES);
        initFromProperties(serviceProps, callStyleProps);
    }

    @Override
    public Class<?> loadClass(String clazzName) throws ClassNotFoundException {
        return Class.forName(clazzName);
    }

    /**
     * Resolves private facade for ReportManager
     * @param iFace private facade interface
     * @return an object implementing private facade interface
     **/
    public <T> T getIPrivateFacade(@Nonnull final Class<T> iFace) {
        return getPrivateFacade(iFace);
    }
}
