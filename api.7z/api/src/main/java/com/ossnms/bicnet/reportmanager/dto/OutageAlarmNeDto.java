package com.ossnms.bicnet.reportmanager.dto;


import java.io.Serializable;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;
import org.immutables.value.Value.Style;

@Immutable @Style(of = "ne")
public interface OutageAlarmNeDto extends Comparable<OutageAlarmNeDto>, Serializable {

    @Parameter int getNeId();

    @Parameter String getNeName();
    
    // So it can be sorted by NE name
    default public int compareTo(OutageAlarmNeDto other) {
        return getNeName().compareTo(other.getNeName());
    }
}
