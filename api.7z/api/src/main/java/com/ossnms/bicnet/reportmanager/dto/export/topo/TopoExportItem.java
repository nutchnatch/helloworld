package com.ossnms.bicnet.reportmanager.dto.export.topo;


import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class TopoExportItem implements IExportableItem {

    private int selection;
    private Iterable<IExportableReader> readers;

    @Override
    public ExportableItemType getExportableElement() {
        return ExportableItemType.TOPOLOGICAL_MANAGEMENT;
    }

    @Override
    public int getSelection() {
        return selection;
    }

    @Override
    public void setSelection(int selection) {
        this.selection = selection;
    }

    @Override
    public Iterable<IExportableReader> getReaders() {
        return readers;
    }

    @Override
    public void setReaders(Iterable<IExportableReader> readers) {
        this.readers = readers;
    }

    @Override
    public String getName() {
        return Constants.TOPO;
    }

    @Override
    public Iterable<IReportManagerExportItem> getChildImportExportItems() {
        return StreamSupport.stream(readers.spliterator(), false)
                .map((Function<IExportableReader, IReportManagerExportItem>) iExportableReader -> iExportableReader).collect(Collectors.toList());
    }

    @Override
    public int getObjectId() {
        return 0;
    }

    @Override
    public void setObjectId(Integer id) {

    }
}
