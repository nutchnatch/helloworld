package com.ossnms.bicnet.reportmanager.dto;

import java.io.Serializable;
import java.util.List;

import org.immutables.value.Value.Immutable;

@Immutable
public interface OutageAlarmSettingsDto extends Serializable {

    boolean getWarning();

    boolean getMinor();

    boolean getMajor();

    boolean getCritical();

    boolean getIndeterminate();

    boolean getUnacknowledged();

    boolean getAcknowledged();

    boolean getCleared();

    boolean getRaised();

    Long getStartDate();

    Long getEndDate();

    Boolean getAutomaticTimeRange();

    List<OutageAlarmNeDto> getNes();

}
