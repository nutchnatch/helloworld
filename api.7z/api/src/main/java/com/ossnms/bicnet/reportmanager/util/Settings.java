/* Project BiCNet Common Function
 *  
 * Created by sco on Sep 29, 2004
 */
package com.ossnms.bicnet.reportmanager.util;

import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;

/**
 * This class is used for the definition of global constants and settings.
 */
public final class Settings {

	private static boolean advancedMode;

	private Settings() {
		//Hide constructor
	}

	/**
	 * Returns <code>true</code>, if the system property "enhanced.output" is set. If the argument "-Denhanced.output" is specified by the
	 * run configuration, some additional output are shown on the gui.
	 *
	 * @return <code>true</code>, if the property "enhanced.output" is set.
	 */
	public static boolean isAdvancedMode() {
		return advancedMode || System.getProperties().containsKey("rm.goodies");
	}

	public static void setAdvancedMode(boolean advancedMode) {
		Settings.advancedMode = advancedMode;
	}
}
