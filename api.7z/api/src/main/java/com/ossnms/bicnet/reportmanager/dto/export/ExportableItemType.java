package com.ossnms.bicnet.reportmanager.dto.export;


public enum ExportableItemType {

    TOPOLOGICAL_MANAGEMENT,
    DCN_MANAGEMENT
}
