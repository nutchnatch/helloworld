package com.ossnms.bicnet.reportmanager.dto;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;
import org.immutables.value.Value.Style;

import javax.annotation.Nonnull;
import java.io.Serializable;
import java.util.Optional;

import static java.util.Comparator.comparing;
import static java.util.Optional.empty;

public interface DcnObject extends Serializable, Comparable<DcnObject> {

    String type();

    String name();

    String address();

    String state();

    default Optional<Integer> neId() {
        return empty();
    }

    default Optional<String> neName() {
        return empty();
    }

    default Optional<Integer> systemId() {
        return empty();
    }

    default Optional<String> systemName() {
        return empty();
    }

    default Optional<Integer> channelId() {
        return empty();
    }

    default Optional<EnableSwitch> maintenanceState() {
        return empty();
    }

    default Optional<OperationalState> operationalState() {
        return empty();
    }

    default Optional<Alarm> alarm() {
        return empty();
    }

    @Override default int compareTo(@Nonnull DcnObject other) {
        return comparing(DcnObject::name).compare(this, other);
    }

    @Immutable @Style(of = "alarm") interface Alarm extends Serializable {
        @Parameter AlarmSeverity severity();

        @Parameter Boolean acknowledge();
    }

    @Immutable @Style(of = "ne") interface NE extends DcnObject {
        default String type() {
            return "NE";
        }

        @Parameter String name();

        @Parameter String address();

        @Parameter String state();

        Optional<Integer> neId();

        Optional<String> neName();

        Optional<Integer> systemId();

        Optional<String> systemName();

        Optional<Integer> channelId();

        Optional<EnableSwitch> maintenanceState();

        Optional<OperationalState> operationalState();

        Optional<Alarm> alarm();
    }

    @Immutable @Style(of = "channel") interface Channel extends DcnObject {
        default String type() {
            return "Channel";
        }

        @Parameter String name();

        @Parameter String address();

        @Parameter String state();
    }

    @Immutable @Style(of = "mediator") interface Mediator extends DcnObject {
        default String type() {
            return "Mediator";
        }

        @Parameter String name();

        @Parameter String address();

        @Parameter String state();
    }
}
