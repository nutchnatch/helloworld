package com.ossnms.bicnet.reportmanager.dto.export;

import java.io.Serializable;


public interface IReportManagerExportItem extends Serializable {

    String getName();

    int getSelection();

    void setSelection(int selection);

    Iterable<IReportManagerExportItem> getChildImportExportItems();

    default boolean isSelected() {
        return getSelection() == 1;
    }

    int getObjectId();

    void setObjectId(Integer id);
}
