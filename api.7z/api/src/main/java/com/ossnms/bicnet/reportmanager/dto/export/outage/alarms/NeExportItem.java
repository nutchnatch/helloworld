package com.ossnms.bicnet.reportmanager.dto.export.outage.alarms;

import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import org.apache.commons.lang3.builder.EqualsBuilder;

import java.util.Comparator;

public class NeExportItem implements IExportableItem {

    private static final long serialVersionUID = 1L;
    private int selection;
    private String name;
    private int neId;

    @Override
    public ExportableItemType getExportableElement() {
        return ExportableItemType.DCN_MANAGEMENT;
    }

    @Override
    public int getSelection() {
        return selection;
    }

    @Override
    public void setSelection(int selection) {
        this.selection = selection;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Iterable<IReportManagerExportItem> getChildImportExportItems() {
        return null;
    }

    @Override
    public int getObjectId() {
        return neId;
    }

    @Override
    public void setObjectId(Integer id) {
        neId = id;
    }

    @Override
    public void setReaders(Iterable<IExportableReader> readers) {
    }

    @Override
    public Iterable<IExportableReader> getReaders() {
        return null;
    }

}