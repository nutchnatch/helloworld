package com.ossnms.bicnet.reportmanager.dto;

import java.io.Serializable;

import com.ossnms.bicnet.bcb.model.platform.ISchedule;

/**
 * Contains data about Job execution and schedule configuration
 */
public class ReportDataDto implements Serializable, Cloneable {

    /**
     * Current execution configuration data
     */
    private final ReportExecutionDto currentExecution;

    /**
     * Contains the results about Last successful execution data
     */
    private final ReportExecutionDto lastSuccessfulExecution;

    /**
     * Current configured Schedule
     */
    private final ISchedule schedule;

    /**
     * Identifies the report type
     */
    private final String reportId;

    /**
     * Contains date for next configured execution
     */
    private final Long nextExecutionTime;

    public ReportDataDto(ReportExecutionDto currentExecution, ReportExecutionDto lastSuccessfulExecution, ISchedule schedule, String reportId, Long nextExecutionTime) {
        this.currentExecution = currentExecution;
        this.lastSuccessfulExecution = lastSuccessfulExecution;
        this.schedule = schedule;
        this.reportId = reportId;
        this.nextExecutionTime = nextExecutionTime;
    }

    public ReportExecutionDto getCurrentExecution() {
        return currentExecution;
    }

    public ReportExecutionDto getLastSuccessfulExecution() {
        return lastSuccessfulExecution;
    }

    public ISchedule getSchedule() {
        return schedule;
    }

    public Long getNextExecutionTime() {
        return nextExecutionTime;
    }

    public String getReportId() {
        return reportId;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}


