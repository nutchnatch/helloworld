package com.ossnms.bicnet.reportmanager.dto.export.dcn;


import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.stream.Collectors;

import static java.util.stream.StreamSupport.stream;

public class DcnExportItem implements IExportableItem {

    private int selection;
    private Iterable<IExportableReader> readers;

    @Override
    public ExportableItemType getExportableElement() {
        return ExportableItemType.DCN_MANAGEMENT;
    }

    @Override
    public int getSelection() {
        return selection;
    }

    @Override
    public void setSelection(int selection) {
        this.selection = selection;
    }

    @Override
    public void setReaders(Iterable<IExportableReader> readers) {
        this.readers = readers;
    }

    @Override
    public Iterable<IExportableReader> getReaders() {
        return readers;
    }

    @Override
    public String getName() {
        return Constants.DCN_MANAGEMENT;
    }

    @Override
    public Iterable<IReportManagerExportItem> getChildImportExportItems() {
        return stream(readers.spliterator(), false)
                .collect(Collectors.toList());
    }

    @Override
    public int getObjectId() {
        return 0;
    }

    @Override
    public void setObjectId(Integer id) {

    }
}
