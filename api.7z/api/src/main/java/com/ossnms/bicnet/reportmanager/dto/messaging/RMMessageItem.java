/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportmanager.dto.messaging;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IVisitor;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.model.platform.NotificationType;

import javax.annotation.Nonnull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A message item to be used in server-client notifications.
 */
public class RMMessageItem extends Notification implements Serializable {

	/** Generated default identifier. */
	private static final long serialVersionUID = -4405881767784841164L;

    /**
     * interface for implementing the visitor pattern.
     * This interface is intended to be implemented by a class, which needs to perform specific processing of Notifications
     */
    public interface IVisitor extends com.ossnms.bicnet.bcb.model.IVisitor{
        /**
         * performs specific processing of RMMessageItem instances.
         * @param arg the RMMessageItem object to be processed.
         * @return indicates whether the RMMessageItem has been processed
         */
        public boolean onHandlingRMMessageItem(@Nonnull RMMessageItem arg) throws BcbException;
    }

    /**
     * performs specific processing of RMMessageItem instances by delegating to the given visitor interface.
     * @param visitor the visitor interface implemenation
     * @return indicates whether the RMMessageItem has been processed
     */
    public boolean dispatch(com.ossnms.bicnet.bcb.model.IVisitor visitor) throws BcbException {
        if (visitor instanceof IVisitor) {
            return ((IVisitor) visitor).onHandlingRMMessageItem(this);
        }else{
            return super.dispatch(visitor);
        }
    }

    /**
	 * The possible operation status.
	 */
	public enum OperationStatus {
		/** When the message is for a successful operation. */
		SUCCESSFUL,
		/** When the message is for a failed operation. */
		FAILED,
		/** When the message is for a operation partially succeeded. */
		WITH_WARNINGS,
		/** When the message is for a time out operation. */
		TIMEOUT,
		/** When the message is for Import started */
		STARTED,
		/** When the message is for Import ended */
		ENDED,
		/** When there is already a operation of the same type running */
		OPERATION_RUNNING,
	}

	/**
	 * The supported operation types.
	 */
	public enum OperationType {
		EXPORT, EXPORT_LOAD, EXPORT_SCHEDULE
	}

	/** The message notification type */
	private NotificationType notificationType;

	/** The message operation status */
	private OperationStatus operationStatus;

	/** The message operation type */
	private OperationType operationType;

	/** The object associated with this message. */
	private Object object;

	/** The user to be notified. */
	private Long userId;

	/** the user needs to be notified */
	private boolean notificationNeeded;

	/**
	 * Constructor for broadcast notification messages.
	 * 
	 * @param notificationType
	 *            {@link com.ossnms.bicnet.bcb.model.platform.NotificationType}
	 * @param operationStatus
	 *            {@link OperationStatus}
	 * @param operationType
	 *            {@link OperationType}
	 * @param object
	 *            The object associated with this message
	 */
	public RMMessageItem(NotificationType notificationType, OperationStatus operationStatus, OperationType operationType, Object object) {
		this(notificationType, operationStatus, operationType, object, -1L);
	}

	/**
	 * Constructor for broadcast notification messages.
	 *
	 * @param notificationType
	 *            {@link com.ossnms.bicnet.bcb.model.platform.NotificationType}
	 * @param operationStatus
	 *            {@link OperationStatus}
	 * @param operationType
	 *            {@link OperationType}
	 * @param userId
	 *            The user identification to whom this message is sent
	 */
	public RMMessageItem(NotificationType notificationType, OperationStatus operationStatus, OperationType operationType, Long userId) {
		this(notificationType, operationStatus, operationType, null, userId);
	}

	/**
	 * Parameterized constructor.
	 *
	 * @param notificationType
	 *            {@link com.ossnms.bicnet.bcb.model.platform.NotificationType}
	 * @param operationStatus
	 *            {@link OperationStatus}
	 * @param operationType
	 *            {@link OperationType}
	 * @param object
	 *            The object associated with this message
	 * @param userId
	 *            The user identification to whom this message is sent
	 */
	public RMMessageItem(NotificationType notificationType, OperationStatus operationStatus, OperationType operationType, Object object,
                         Long userId) {
		this(notificationType, operationStatus, operationType, object, userId, true);
	}

	/**
	 * Parameterized constructor.
	 *
	 * @param notificationType
	 *            {@link com.ossnms.bicnet.bcb.model.platform.NotificationType}
	 * @param operationStatus
	 *            {@link OperationStatus}
	 * @param operationType
	 *            {@link OperationType}
	 * @param object
	 *            The object associated with this message
	 * @param userId
	 *            The user identification to whom this message is sent
	 * @param notificationNeeded
	 *            If user needs to be notified
	 */
	public RMMessageItem(NotificationType notificationType, OperationStatus operationStatus, OperationType operationType, Object object,
                         Long userId, boolean notificationNeeded) {
		this.notificationType = notificationType;
		this.operationStatus = operationStatus;
		this.operationType = operationType;
		this.object = object;
		this.userId = userId;
		this.notificationNeeded = notificationNeeded;
	}

	public NotificationType getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(NotificationType notificationType) {
		this.notificationType = notificationType;
	}

	public OperationStatus getOperationStatus() {
		return operationStatus;
	}

	public void setOperationStatus(OperationStatus operationStatus) {
		this.operationStatus = operationStatus;
	}

	public OperationType getOperationType() {
		return operationType;
	}

	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public boolean isNotificationNeeded() {
		return notificationNeeded;
	}

	@Override
	public String toString() {
		final StringBuffer sb = new StringBuffer("CSLMessageItem{");
		sb.append("notificationType=").append(notificationType);
		sb.append(", operationStatus=").append(operationStatus);
		sb.append(", operationType=").append(operationType);
		sb.append(", object=").append(object);
		sb.append(", userId=").append(userId);
		sb.append(", notificationNeeded=").append(notificationNeeded);
		sb.append('}');
		return sb.toString();
	}

    @Override
    public boolean equals(Object obj) {

        if(this == obj){
            return true;
        }
        if(obj == null){
            return false;
        }
        if(!getClass().equals(obj.getClass())){
            return false;
        }
        if(!super.equals(obj)){
            return false;
        }
        RMMessageItem other = (RMMessageItem)obj;
        if(!Objects.equals(this.getObject(), other.getObject())){
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + Objects.hashCode(this.getObject());
        return result;
    }
}
