package com.ossnms.bicnet.reportmanager.dto.export;

public interface IExportableItem extends IReportManagerExportItem {

    ExportableItemType getExportableElement();

    void setReaders(Iterable<IExportableReader> readers);

    Iterable<IExportableReader> getReaders();
}
