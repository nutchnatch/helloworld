package com.ossnms.bicnet.reportmanager.api;

import org.apache.commons.lang3.StringUtils;

public class ChangedAttributes {

    private final boolean isChanged;
    private final String description;

    public ChangedAttributes(boolean isChanged, String description){
        this.isChanged = isChanged;
        this.description = description;
    }

    public String getMessage(){
        return isChanged ? description : StringUtils.EMPTY;
    }
}
