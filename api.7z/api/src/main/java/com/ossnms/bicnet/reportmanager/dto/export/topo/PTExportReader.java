package com.ossnms.bicnet.reportmanager.dto.export.topo;


import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import com.ossnms.bicnet.reportmanager.util.Constants;
import org.apache.commons.collections.CollectionUtils;

public class PTExportReader implements IExportableReader {

    private int selection;

    @Override
    public ExportableReaderType getExportableReaderIdentification() {
        return ExportableReaderType.PHISICAL_TRAIL;
    }

    @Override
    public Iterable<IExportableReader> getReaders() {
        return CollectionUtils.EMPTY_COLLECTION;
    }

    @Override
    public int getSelection() {
        return selection;
    }

    @Override
    public void setSelection(int selection) {
        this.selection = selection;
    }

    @Override
    public String getName() {
        return Constants.PHISICAL_TRAILS;
    }

    @Override
    public Iterable<IReportManagerExportItem> getChildImportExportItems() {
        return CollectionUtils.EMPTY_COLLECTION;
    }

    @Override
    public int getObjectId() {
        return 0;
    }

    @Override
    public void setObjectId(Integer id) {

    }
}
