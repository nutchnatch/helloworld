package com.ossnms.bicnet.reportmanager.dto;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import org.immutables.value.Value.Default;
import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;
import org.immutables.value.Value.Style;

import java.io.Serializable;
import java.util.Collection;

import static java.util.Collections.emptyList;

@Immutable @Style(of = "alarmMessaging")
public interface AlarmMessagingCriteriaSettings extends Serializable {

    @Parameter ThresholdSettings threshold();

    @Parameter Collection<INEId> selectedNEs();

    @Default default Collection<OutageAlarmNeDto> allNEs() {
        return emptyList();
    }

    @Immutable @Style(of = "threshold")
    interface ThresholdSettings extends Serializable {

        @Parameter Boolean enabled();

        @Parameter Integer number();

        @Parameter Integer severity();
    }
}
