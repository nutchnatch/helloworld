package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.bnpp.cardif.sugar.rest.ui.model.AllowedChildren;
import com.bnpp.cardif.sugar.rest.ui.model.AssociatedTag;
import com.bnpp.cardif.sugar.rest.ui.model.DisplayNameItem;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TimeUnitConstance;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;

/**
 * 
 * @author 831743
 *
 */
public class EnvelopeTypeConverter {
    
    protected static final String ISSUER = "CARDIF";

    /**
     * private empty constructor
     */
    private EnvelopeTypeConverter() {
        // private constructor to avoid instance creation.
    }

    public static EnvelopeType convert(DocumentClass documentClass) {
        EnvelopeType result = null;
        if (documentClass != null) {
            result = new EnvelopeType();
            convertVersionData(documentClass, result);
            result.setName(documentClass.getLongLabel());
            result.setFirstLevel(documentClass.isFirstLevel());
            result.setActive(documentClass.isActive());
            convertLabelList(documentClass, result);
            convertTagList(documentClass, result);
            convertAllowedChildren(documentClass, result);
        }
        return result;
    }

    private static void convertAllowedChildren(DocumentClass documentClass, EnvelopeType result) {
        List<AllowedChildren> allowedChildren = new ArrayList<>();
        List<com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.MCODocumentClassType.AllowedChildren> childrenList = documentClass
                .getAllowedChildren();
        if (childrenList != null && !childrenList.isEmpty()) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.MCODocumentClassType.AllowedChildren children : childrenList) {
                AllowedChildren content = new AllowedChildren();
                ClassId classId = children.getClassId();
                if (classId != null) {
                    content.setId(classId.getValue());
                    content.setVersion(classId.getVersId());
                }
                content.setSymbolicName(children.getSymbolicName());
                allowedChildren.add(content);
            }
        }
        result.setAllowedChildren(allowedChildren);
    }

    private static void convertTagList(DocumentClass documentClass, EnvelopeType result) {
        List<MCOTagReference> backendTagList = documentClass.getTagReference();
        List<AssociatedTag> tagList = result.getTagList();
        if (tagList == null) {
            tagList = new ArrayList<>();
        }
        if (backendTagList != null) {
            for (MCOTagReference backendTag : backendTagList) {
                AssociatedTag associatedTag = new AssociatedTag();
                associatedTag.setSymbolicName(backendTag.getSymbolicName());
                associatedTag.setMandatory(backendTag.isMandatory());
                associatedTag.setMultivalued(backendTag.isMultivalued());
                tagList.add(associatedTag);
            }
        }
    }

    private static void convertLabelList(DocumentClass documentClass, EnvelopeType result) {
        List<MCOI18NLabel> backendLabelList = documentClass.getShortLabel();
        List<DisplayNameItem> labelList = result.getDisplayNameList();
        if (labelList == null) {
            labelList = new ArrayList<>();
        }
        if (backendLabelList != null) {
            for (MCOI18NLabel backendLabel : backendLabelList) {
                DisplayNameItem label = new DisplayNameItem();
                label.setLanguage(backendLabel.getLanguage());
                label.setValue(backendLabel.getValue());
                labelList.add(label);
            }
        }
    }

    private static void convertVersionData(DocumentClass documentClass, EnvelopeType result) {
        ClassId classId = documentClass.getClassId();
        if (classId != null) {
            result.setId(classId.getValue());
            result.setVersion(classId.getVersId());
        }
    }

    public static List<EnvelopeType> convert(List<DocumentClass> documentClassList) {

        List<EnvelopeType> result = new ArrayList<>();
        if (documentClassList != null) {
            for (DocumentClass documentClass : documentClassList) {
                EnvelopeType content = EnvelopeTypeConverter.convert(documentClass);
                result.add(content);
            }
        }
        return result;
    }
    
    public static DocumentClass convert(EnvelopeType envelopeType, String scope) {

        DocumentClass result = null;
        if (envelopeType != null) {
            result = new DocumentClass();
            ClassId classId = new ClassId(envelopeType.getId(), ISSUER, envelopeType.getVersion());
            result.setClassId(classId);
            result.setFirstLevel(envelopeType.getFirstLevel());
            result.setActive(envelopeType.getActive());
            result.setLongLabel(envelopeType.getName());
            result.setScope(scope);
            result.setRetentionDuration(new DurationType(new BigInteger("0"), TimeUnitConstance.MONTH.name()));
            setAllowedChildren(envelopeType, result);
            setLabelList(envelopeType, result);
            setTagList(envelopeType, result);
        }
        return result;
    }

    private static void setTagList(EnvelopeType envelopeType, DocumentClass result) {
        List<MCOTagReference> tagList = result.getTagReference();
        List<AssociatedTag> AssociatedTagList = envelopeType.getTagList();
        if (AssociatedTagList != null) {
            for (AssociatedTag associatedTag : AssociatedTagList) {
                MCOTagReference content = new MCOTagReference(associatedTag.getSymbolicName(),
                        associatedTag.getMandatory(), associatedTag.getMultivalued());
                tagList.add(content);
            }
        }
    }

    private static void setLabelList(EnvelopeType envelopeType, DocumentClass result) {
        List<MCOI18NLabel> labelList = result.getShortLabel();
        List<DisplayNameItem> displayNameList = envelopeType.getDisplayNameList();
        if (displayNameList != null) {
            for (DisplayNameItem displayNameItem : displayNameList) {
                MCOI18NLabel label = new MCOI18NLabel(displayNameItem.getValue(), displayNameItem.getLanguage());
                labelList.add(label);
            }
        }
    }

    private static void setAllowedChildren(EnvelopeType envelopeType, DocumentClass result) {
        List<com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.MCODocumentClassType.AllowedChildren> childrenList = result
                .getAllowedChildren();
        List<AllowedChildren> allowedChildrenList = envelopeType.getAllowedChildren();
        if (allowedChildrenList != null) {
            for (AllowedChildren allowedChildren : allowedChildrenList) {
                com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.MCODocumentClassType.AllowedChildren content = new com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.MCODocumentClassType.AllowedChildren();
                ClassId childClassId = new ClassId(allowedChildren.getId(), ISSUER, allowedChildren.getVersion());
                content.setClassId(childClassId);
                content.setSymbolicName(allowedChildren.getSymbolicName());
                childrenList.add(content);
            }
        }
    }

}
