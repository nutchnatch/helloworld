package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author 831743
 *
 */
@ApiModel(description = "Contains the result ordering parameters for document and enveloppe search.")
public class SearchOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("ascending")
    private boolean ascending;

    @JsonProperty("orderField")
    private OrderField orderField;

    @JsonProperty("tagName")
    private String tagName;

    /**
     * @return the isAscending
     */
    @ApiModelProperty(value = "The ordering is ascending")
    public boolean isAscending() {
        return ascending;
    }

    /**
     * @param isAscending
     *            the isAscending to set
     */
    public void setAscending(boolean ascending) {
        this.ascending = ascending;
    }

    /**
     * @return the orderField
     */
    @ApiModelProperty(value = "The field to be used for result ordering")
    public OrderField getOrderField() {
        return orderField;
    }

    /**
     * @param orderField
     *            the orderField to set
     */
    public void setOrderField(OrderField orderField) {
        this.orderField = orderField;
    }

    /**
     * @return the tagName
     */
    @ApiModelProperty(value = "The symbolic name of the tag field used for ordering")
    public String getTagName() {
        return tagName;
    }

    /**
     * @param tagName
     *            the tagName to set
     */
    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (ascending ? 1231 : 1237);
        result = prime * result + ((orderField == null) ? 0 : orderField.hashCode());
        result = prime * result + ((tagName == null) ? 0 : tagName.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof SearchOrder))
            return false;
        SearchOrder other = (SearchOrder) obj;
        if (ascending != other.ascending)
            return false;
        if (orderField != other.orderField)
            return false;
        if (tagName == null) {
            if (other.tagName != null)
                return false;
        }
        else if (!tagName.equals(other.tagName))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SearchOrder [ascending=");
        builder.append(ascending);
        builder.append(", orderField=");
        builder.append(orderField);
        builder.append(", tagName=");
        builder.append(tagName);
        builder.append("]");
        return builder.toString();
    }

}
