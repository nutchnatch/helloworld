package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AllowableTagValue
 */
public class AllowableTagValue implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("symbolicName")
    private String symbolicName = null;

    @JsonProperty("displayNameValues")
    private List<DisplayNameItem> displayNameValues = new ArrayList<>();

    public AllowableTagValue symbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
        return this;
    }

    /**
     * Symbolic name
     * 
     * @return symbolicName
     **/
    @ApiModelProperty(value = "Symbolic name")
    public String getSymbolicName() {
        return symbolicName;
    }

    public void setSymbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
    }

    public AllowableTagValue displayNameValues(List<DisplayNameItem> displayNameValues) {
        this.displayNameValues = displayNameValues;
        return this;
    }

    public AllowableTagValue addDisplayNameValuesItem(DisplayNameItem displayNameValuesItem) {
        if (this.displayNameValues == null) {
            this.displayNameValues = new ArrayList<>();
        }
        this.displayNameValues.add(displayNameValuesItem);
        return this;
    }

    /**
     * Possible display name values.
     * 
     * @return displayNameValues
     **/
    @ApiModelProperty(value = "Possible display name values.")

    @Valid

    public List<DisplayNameItem> getDisplayNameValues() {
        return displayNameValues;
    }

    public void setDisplayNameValues(List<DisplayNameItem> displayNameValues) {
        this.displayNameValues = displayNameValues;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((displayNameValues == null) ? 0 : displayNameValues.hashCode());
        result = prime * result + ((symbolicName == null) ? 0 : symbolicName.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof AllowableTagValue))
            return false;
        AllowableTagValue other = (AllowableTagValue) obj;
        if (displayNameValues == null) {
            if (other.displayNameValues != null)
                return false;
        }
        else if (!displayNameValues.equals(other.displayNameValues))
            return false;
        if (symbolicName == null) {
            if (other.symbolicName != null)
                return false;
        }
        else if (!symbolicName.equals(other.symbolicName))
            return false;
        return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AllowableTagValue [symbolicName=");
        builder.append(symbolicName);
        builder.append(", displayNameValues=");
        builder.append(displayNameValues);
        builder.append("]");
        return builder.toString();
    }

    
    
}
