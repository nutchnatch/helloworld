package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Contains a set of documents.
 */
@ApiModel(description = "Contains a set of documents.")
public class Envelope implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("envelopeStatus")
    private String envelopeStatus = null;

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("updatingDate")
    private ZonedDateTime updatingDate = null;

    @JsonProperty("confidentiality")
    private String confidentiality = null;

    @JsonProperty("envTypeId")
    private String envTypeId = null;

    @JsonProperty("envTypeVersion")
    private int envTypeVersion;

    @JsonProperty("direction")
    private String direction = null;

    @JsonProperty("validity")
    private String validity = null;

    @JsonProperty("listOfDocumentId")
    private List<DocumentIdentifier> listOfDocumentId = new ArrayList<>();

    @JsonProperty("tagList")
    private List<TagElement> tagList = new ArrayList<>();

    public Envelope id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Identification of the envelope.
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Identification of the envelope.")
    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Envelope envelopeStatus(String envelopeStatus) {
        this.envelopeStatus = envelopeStatus;
        return this;
    }

    /**
     * Status of the envelope.
     * 
     * @return envelopeStatus
     **/
    @ApiModelProperty(value = "Status of the envelope.")
    public String getEnvelopeStatus() {
        return envelopeStatus;
    }

    public void setEnvelopeStatus(String envelopeStatus) {
        this.envelopeStatus = envelopeStatus;
    }

    public Envelope creationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    /**
     * Date of creation of the envelope. On creation, this date will be filled
     * with the current date.
     * 
     * @return creationDate
     **/
    @ApiModelProperty(value = "Date of creation of the envelope. On creation, this date will be filled with the current date.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public Envelope updatingDate(ZonedDateTime updatingDate) {
        this.updatingDate = updatingDate;
        return this;
    }

    /**
     * When the envelope was updated.
     * 
     * @return updatingDate
     **/
    @ApiModelProperty(value = "When the envelope was updated.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getUpdatingDate() {
        return updatingDate;
    }

    public void setUpdatingDate(ZonedDateTime updatingDate) {
        this.updatingDate = updatingDate;
    }

    public Envelope confidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
        return this;
    }

    /**
     * Defines if the envelope is confidential. or not.
     * 
     * @return confidentiality
     **/
    @ApiModelProperty(value = "Defines if the envelope is confidential. or not.")
    public String getConfidentiality() {
        return confidentiality;
    }

    public void setConfidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
    }

    public Envelope envTypeId(String envTypeId) {
        this.envTypeId = envTypeId;
        return this;
    }

    /**
     * Identification of the envelope type. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * type.
     * 
     * @return envTypeId
     **/
    @ApiModelProperty(value = "Identification of the envelope type. On creation of a document, this field will be filled with an default value fetched from the document type.")
    public String getEnvTypeId() {
        return envTypeId;
    }

    public void setEnvTypeId(String envTypeId) {
        this.envTypeId = envTypeId;
    }

    public Envelope envTypeVersion(int envTypeVersion) {
        this.envTypeVersion = envTypeVersion;
        return this;
    }

    /**
     * Version of the envelope type. On creation of a document, this field will
     * be filled with an default value fetched from the document type.
     * 
     * @return envTypeId
     **/
    @ApiModelProperty(value = "Version of the envelope type. On creation of a document, this field will be filled with an default value fetched from the document type.")
    public int getEnvTypeVersion() {
        return envTypeVersion;
    }

    public void setEnvTypeVersion(int envTypeVersion) {
        this.envTypeVersion = envTypeVersion;
    }

    public Envelope direction(String direction) {
        this.direction = direction;
        return this;
    }

    /**
     * Identification of the document direction. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * direction
     * 
     * @return direction
     **/
    @ApiModelProperty(value = "Identification of the Envelope direction. On creation of a document, this field will be filled with an default value fetched from the document direction")
    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Envelope validity(String validity) {
        this.validity = validity;
        return this;
    }

    /**
     * Identification of the document validity. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * validity
     * 
     * @return validity
     **/
    @ApiModelProperty(value = "Identification of the Envelope validity. On creation of a document, this field will be filled with an default value fetched from the document validity")
    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public Envelope listOfDocumentId(List<DocumentIdentifier> listOfDocumentId) {
        this.listOfDocumentId = listOfDocumentId;
        return this;
    }

    public Envelope addListOfDocumentIdItem(DocumentIdentifier listOfDocumentIdItem) {
        if (this.listOfDocumentId == null) {
            this.listOfDocumentId = new ArrayList<>();
        }
        this.listOfDocumentId.add(listOfDocumentIdItem);
        return this;
    }

    /**
     * List document identification.
     * 
     * @return listOfDocumentId
     **/
    @ApiModelProperty(value = "List document identification.")
    public List<DocumentIdentifier> getListOfDocumentId() {
        return listOfDocumentId;
    }

    public void setListOfDocumentId(List<DocumentIdentifier> listOfDocumentId) {
        this.listOfDocumentId = listOfDocumentId;
    }

    public Envelope tagList(List<TagElement> tagList) {
        this.tagList = tagList;
        return this;
    }

    public Envelope addTagListItem(TagElement tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * Get tagList
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "List of Tags")
    @Valid
    public List<TagElement> getTagList() {
        return tagList;
    }

    public void setTagList(List<TagElement> tagList) {
        this.tagList = tagList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((confidentiality == null) ? 0 : confidentiality.hashCode());
        result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
        result = prime * result + ((direction == null) ? 0 : direction.hashCode());
        result = prime * result + ((envTypeId == null) ? 0 : envTypeId.hashCode());
        result = prime * result + envTypeVersion;
        result = prime * result + ((envelopeStatus == null) ? 0 : envelopeStatus.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((listOfDocumentId == null) ? 0 : listOfDocumentId.hashCode());
        result = prime * result + ((tagList == null) ? 0 : tagList.hashCode());
        result = prime * result + ((updatingDate == null) ? 0 : updatingDate.hashCode());
        result = prime * result + ((validity == null) ? 0 : validity.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Envelope))
            return false;
        Envelope other = (Envelope) obj;
        if (confidentiality == null) {
            if (other.confidentiality != null)
                return false;
        }
        else if (!confidentiality.equals(other.confidentiality))
            return false;
        if (creationDate == null) {
            if (other.creationDate != null)
                return false;
        }
        else if (!creationDate.equals(other.creationDate))
            return false;
        if (direction == null) {
            if (other.direction != null)
                return false;
        }
        else if (!direction.equals(other.direction))
            return false;
        if (envTypeId == null) {
            if (other.envTypeId != null)
                return false;
        }
        else if (!envTypeId.equals(other.envTypeId))
            return false;
        if (envTypeVersion != other.envTypeVersion)
            return false;
        if (envelopeStatus == null) {
            if (other.envelopeStatus != null)
                return false;
        }
        else if (!envelopeStatus.equals(other.envelopeStatus))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        }
        else if (!id.equals(other.id))
            return false;
        if (listOfDocumentId == null) {
            if (other.listOfDocumentId != null)
                return false;
        }
        else if (!listOfDocumentId.equals(other.listOfDocumentId))
            return false;
        if (tagList == null) {
            if (other.tagList != null)
                return false;
        }
        else if (!tagList.equals(other.tagList))
            return false;
        if (updatingDate == null) {
            if (other.updatingDate != null)
                return false;
        }
        else if (!updatingDate.equals(other.updatingDate))
            return false;
        if (validity == null) {
            if (other.validity != null)
                return false;
        }
        else if (!validity.equals(other.validity))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Envelope [id=");
        builder.append(id);
        builder.append(", envelopeStatus=");
        builder.append(envelopeStatus);
        builder.append(", creationDate=");
        builder.append(creationDate);
        builder.append(", updatingDate=");
        builder.append(updatingDate);
        builder.append(", confidentiality=");
        builder.append(confidentiality);
        builder.append(", envTypeId=");
        builder.append(envTypeId);
        builder.append(", envTypeVersion=");
        builder.append(envTypeVersion);
        builder.append(", direction=");
        builder.append(direction);
        builder.append(", validity=");
        builder.append(validity);
        builder.append(", listOfDocumentId=");
        builder.append(listOfDocumentId);
        builder.append(", tagList=");
        builder.append(tagList);
        builder.append("]");
        return builder.toString();
    }

}
