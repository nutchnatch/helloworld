package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class BasketReporting implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @JsonProperty("basketId")
    private String basketId = null;

    @JsonProperty("numberOfOpened")
    private long numberOfOpened = 0;

    @JsonProperty("numberOfClosed")
    private long numberOfClosed = 0;

    public BasketReporting basketId(String basketId) {
        this.basketId = basketId;
        return this;
    }

    /**
     * Identifies uniquely an ACL.
     * 
     * @return aclId
     **/
    @ApiModelProperty(required = true, value = "Identifier of the concerned basket.")
    @NotNull
    public String getBasketId() {
        return basketId;
    }

    public void setBasketId(String basketId) {
        this.basketId = basketId;
    }

    public BasketReporting numberOfOpened(long numberOfOpened) {
        this.numberOfOpened = numberOfOpened;
        return this;
    }

    /**
     * Identifies uniquely an ACL.
     * 
     * @return aclId
     **/
    @ApiModelProperty(required = true, value = "Number of opened tasks in the basket during the period.")
    @NotNull
    public long getNumberOfOpened() {
        return numberOfOpened;
    }

    public void setNumberOfOpened(long numberOfOpened) {
        this.numberOfOpened = numberOfOpened;
    }

    public BasketReporting numberOfClosed(long numberOfClosed) {
        this.numberOfClosed = numberOfClosed;
        return this;
    }

    /**
     * Identifies uniquely an ACL.
     * 
     * @return aclId
     **/
    @ApiModelProperty(required = true, value = "Number of closed tasks in the basket during the period.")
    @NotNull
    public long getNumberOfClosed() {
        return numberOfClosed;
    }

    public void setNumberOfClosed(long numberOfClosed) {
        this.numberOfClosed = numberOfClosed;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((basketId == null) ? 0 : basketId.hashCode());
        result = prime * result + (int) (numberOfClosed ^ (numberOfClosed >>> 32));
        result = prime * result + (int) (numberOfOpened ^ (numberOfOpened >>> 32));
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof BasketReporting))
            return false;
        BasketReporting other = (BasketReporting) obj;
        if (basketId == null) {
            if (other.basketId != null)
                return false;
        }
        else if (!basketId.equals(other.basketId))
            return false;
        if (numberOfClosed != other.numberOfClosed)
            return false;
        if (numberOfOpened != other.numberOfOpened)
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("BasketReporting [basketId=");
        builder.append(basketId);
        builder.append(", numberOfOpened=");
        builder.append(numberOfOpened);
        builder.append(", numberOfClosed=");
        builder.append(numberOfClosed);
        builder.append("]");
        return builder.toString();
    }

}
