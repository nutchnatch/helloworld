package com.bnpp.cardif.sugar.rest.ui.controller;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.DocumentFilesService;
import com.bnpp.cardif.sugar.frontend.services.DocumentService;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpp.cardif.sugar.rest.ui.api.EnvelopesApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.DocumentConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.DocumentFileConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.EnvelopeConverter;
import com.bnpp.cardif.sugar.rest.ui.model.Document;
import com.bnpp.cardif.sugar.rest.ui.model.Envelope;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeCreationResult;
import com.bnpp.cardif.sugar.rest.ui.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.ui.model.Paging;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.utils.CollectionUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class EnvelopesController extends FrontendController implements EnvelopesApi {

    private static final String ENVELOPE_ID = "envelopeId";

    private static final Logger LOGGER = LoggerFactory.getLogger(EnvelopesController.class);

    @Autowired
    DocumentService documentService;

    @Autowired
    DocumentTypeService documentTypeService;

    @Autowired
    DocumentFilesService documentFilesService;

    @RequestMapping(value = "/envelopes/{envelopeId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Envelope>> getEnvelopeById(
            @ApiParam(value = "Envelope ID.", required = true) @PathVariable(ENVELOPE_ID) String envelopeId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getEnvelopeById called");
        RestResponse<Envelope> restResponse = new RestResponse<>();
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc = documentService
                    .getDocumentWithChildByID(envelopeId);
            // transform service result into JSON response
            Envelope envelope = null;
            if (backendDoc != null) {
                envelope = EnvelopeConverter.convert(backendDoc, getScope(), securityToken.getToken());
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<Envelope> valueList = new ArrayList<>();
            valueList.add(envelope);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getEnvelopeById end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelopes", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Envelope>> getEnvelopes(
            @ApiParam(value = "Quick Search value. If this parameter is passed, the other criteria will be ignored.", required = false, defaultValue = "") @RequestParam(value = "quickSearch", required = false, defaultValue = "") String quickSearch,
            @ApiParam(value = "Creation Date Search criteria with operator and value, the | is used as separator. example : 'greater_than|2016-10-27'", required = false, defaultValue = "", example = "greater_than|2016-10-27") @RequestParam(value = "creationDate", required = false, defaultValue = "") String creationDateCriteria,
            @ApiParam(value = "Update Date Search criteria with operator and value, the | is used as separator. example : 'less_than|2017-10-27'", required = false, defaultValue = "", example = "less_than|2017-10-27") @RequestParam(value = "updateDate", required = false, defaultValue = "") String updateDateCriteria,
            @ApiParam(value = "Creator Search criteria with operator and value, the | is used as separator. example : 'equals_to|my name'", required = false, defaultValue = "", example = "equals_to|my name") @RequestParam(value = "creator", required = false, defaultValue = "") String creatorCriteria,
            @ApiParam(value = "Last Modifier Search criteria with operator and value, the | is used as separator. example : 'starts_with|my'", required = false, defaultValue = "", example = "starts_with|my") @RequestParam(value = "lastModifier", required = false, defaultValue = "") String lastModifierCriteria,
            @ApiParam(value = "Name Search criteria with operator and value, the | is used as separator. example : 'contains|doc'", required = false, defaultValue = "", example = "contains|doc") @RequestParam(value = "name", required = false, defaultValue = "") String nameCriteria,
            @ApiParam(value = "Validity Code Search criteria with operator and value, the | is used as separator. example : 'not_equals_to|VALID'", required = false, defaultValue = "", example = "not_equals_to|VALID") @RequestParam(value = "validity", required = false, defaultValue = "") String validityCriteria,
            @ApiParam(value = "Confidentiality Level Search criteria with operator and value, the | is used as separator. example : 'equals_to|confdential'", required = false, defaultValue = "", example = "equals_to|confdential") @RequestParam(value = "confidentiality", required = false, defaultValue = "") String confidentialityCriteria,
            @ApiParam(value = "Envelope Type ID List Search criteria", required = false, defaultValue = "") @RequestParam(value = "envelopeTypeIds", required = false, defaultValue = "") List<String> envelopeTypeIdsCriteria,
            @ApiParam(value = "Representation of a tag with name, type, operator and value the | is used as separator. example : 'tagName1|string|ends_with|value1, tagName2|string|not_equals_to|value2'", required = false, defaultValue = "", example = "tagName1|string|ends_with|value1, tagName2|string|not_equals_to|value2") @RequestParam(value = "tags", required = false) List<String> tags,
            @ApiParam(value = "Is using ascending Ordering of the result ?") @RequestParam(value = "orderAscending", required = false) Boolean orderAscending,
            @ApiParam(value = "Name of the field used for ordering", allowableValues = "name, validity_code, creator, last_modifier, creation_date, update_date, confidentiality,tag") @RequestParam(value = "orderField", required = false) String orderField,
            @ApiParam(value = "If orderField=tag then Name of the tag to be used for ordering") @RequestParam(value = "orderTagName", required = false) String orderTagName,
            @NotNull @Min(1) @ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue = "1") Integer pageNumber,
            @NotNull @Min(1) @Max(100) @ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue = "10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getEnvelopes called");
        RestResponse<Envelope> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputGetEnvelopes(pageNumber, pageSize, orderField);
            @SuppressWarnings("squid:S2259")
            long maximum = pageSize.longValue();
            @SuppressWarnings("squid:S2259")
            long start = (pageNumber.longValue() - 1) * maximum;

            List<Criterion> criterionList = this.generateCriterionListFromInput(creationDateCriteria,
                    updateDateCriteria, creatorCriteria, lastModifierCriteria, envelopeTypeIdsCriteria, nameCriteria,
                    validityCriteria, confidentialityCriteria, tags);
            OrderClause orderClause = this.generateOrderClauseFromInput(orderAscending, orderField, orderTagName);
            TokenType securityToken = TokenCreator.getTokenType();

            PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList = documentService
                    .findEnvelopes(start, maximum, quickSearch, criterionList, orderClause);
            // transform service result into JSON response
            List<Envelope> valueList;
            if (backendDocList != null) {
                valueList = EnvelopeConverter.convert(backendDocList.getItemList(), getScope(),
                        securityToken.getToken());
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
            fillPaging(pageNumber, pageSize, restResponse, backendDocList);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getEnvelopes end");
        return ResponseEntity.ok(restResponse);
    }

    private void fillPaging(Integer pageNumber, Integer pageSize, RestResponse<Envelope> restResponse,
            PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList) {

        Paging paging = new Paging();
        paging.setCurrentPage(pageNumber.longValue());
        long lpageSize = pageSize.longValue();
        paging.setPageSize(lpageSize);
        long totalItem = backendDocList.getItemNumber();
        paging.setTotalItems(totalItem);
        Long totalPages = (totalItem + lpageSize - 1) / lpageSize;
        paging.setTotalPages(totalPages);
        restResponse.setPaging(paging);
    }

    private void validateInputGetEnvelopes(Integer pageNumber, Integer pageSize, String orderField)
            throws InvalidInputException {
        List<String> missingInputs = new ArrayList<>();
        validatePagingInput(pageNumber, pageSize, missingInputs);
        if (!missingInputs.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + CollectionUtils.collectionToString(missingInputs));
        }
        this.validateOrderField(orderField);
    }

    @RequestMapping(value = "/envelopes/{envelopeId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<EnvelopeCreationResult>> updateEnvelope(
            @ApiParam(value = "Envelope ID.", required = true) @PathVariable(ENVELOPE_ID) String envelopeId,
            @ApiParam(value = "", required = true) @Valid @RequestBody Envelope envelope,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateDocument called");
        RestResponse<EnvelopeCreationResult> restResponse = new RestResponse<>();
        try {
            // validate input
            if (envelope == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + " envelope");
            }
            // create input parameters
            String scope = this.getScope();
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> inputDocumentlist = new ArrayList<>();
            com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document inputDoc = EnvelopeConverter
                    .convert(envelope, scope);
            if (inputDoc != null) {
                inputDocumentlist.add(inputDoc);
            }
            // call service
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList = documentService
                    .reindexDocument(inputDocumentlist);
            // transform service result into JSON response
            List<EnvelopeCreationResult> valueList;
            if (backendDocList != null) {
                valueList = EnvelopeConverter.convertToEnvelopeCreationResult(backendDocList);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateDocument end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelopes", produces = { "application/json; charset=UTF-8" }, consumes = {
            "multipart/form-data" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<EnvelopeCreationResult>> addEnvelope(
            @ApiParam(value = "The list of document File content (binary data)", required = true) @RequestPart("fileList") List<MultipartFile> fileList,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("addEnvelope called");
        RestResponse<EnvelopeCreationResult> restResponse = new RestResponse<>();
        try {
            // validate input
            if (fileList == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "fileList");
            }
            // create input parameters
            String scope = this.getScope();
            // first create document File
            DocumentClass defaultDocumentType = documentTypeService.getDefaultDocumentType();
            List<DocumentFile> inputDocFileList = DocumentFileConverter.convert(fileList, scope);
            com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document defaultEnvelope = EnvelopeConverter
                    .convert(fileList, scope);
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> defaultDocumentList = DocumentConverter
                    .convert(fileList, scope, defaultDocumentType);
            // create the envelope
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList = documentService
                    .createEnvelopeWithFile(inputDocFileList, defaultEnvelope, defaultDocumentList);
            // transform service result into JSON response
            List<EnvelopeCreationResult> valueList;
            if (backendDocList != null) {
                valueList = EnvelopeConverter.convertToEnvelopeCreationResult(backendDocList);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002.getCode(),
                        "Error, envelope creation should return the created envelope");
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (IOException e) {
            LOGGER.info("addEnvelope error : ", e);
            restResponse.setStatus(false);
            ErrorCause errorCause = new ErrorCause();
            errorCause.setCode(ErrorCode.TE003.getCode());
            errorCause.setErrorDate(ZonedDateTime.now());
            errorCause.setMessage("Technical error : " + e.getMessage());
            restResponse.setError(errorCause);
        }
        LOGGER.debug("addEnvelope end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelopes/{envelopeId}/documents", produces = {
            "application/json; charset=UTF-8" }, consumes = { "multipart/form-data" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<EnvelopeCreationResult>> addDocumentsToEnvelope(
            @ApiParam(value = "Envelope ID.", required = true) @PathVariable(ENVELOPE_ID) String envelopeId,
            @ApiParam(value = "The list of document File content (binary data)", required = true) @RequestPart("fileList") List<MultipartFile> fileList,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("addDocumentsToEnvelope called");
        RestResponse<EnvelopeCreationResult> restResponse = new RestResponse<>();
        try {
            // validate input
            if (fileList == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "fileList");
            }
            if (envelopeId == null || envelopeId.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + ENVELOPE_ID);
            }
            // create input parameters
            String scope = this.getScope();
            // first create document File
            DocumentClass defaultDocumentType = documentTypeService.getDefaultDocumentType();
            List<DocumentFile> inputDocFileList = DocumentFileConverter.convert(fileList, scope);
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> defaultDocumentList = DocumentConverter
                    .convert(fileList, scope, defaultDocumentType);
            // create the envelope
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList = documentService
                    .addFileToEnvelope(inputDocFileList, envelopeId, defaultDocumentList);
            // transform service result into JSON response
            List<EnvelopeCreationResult> valueList;
            if (backendDocList != null) {
                valueList = EnvelopeConverter.convertToEnvelopeCreationResult(backendDocList);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002.getCode(),
                        "Error, envelope creation should return the created envelope");
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (IOException e) {
            LOGGER.info("addDocumentsToEnvelope error : ", e);
            restResponse.setStatus(false);
            ErrorCause errorCause = new ErrorCause();
            errorCause.setCode(ErrorCode.TE003.getCode());
            errorCause.setErrorDate(ZonedDateTime.now());
            errorCause.setMessage("Technical error : " + e.getMessage());
            restResponse.setError(errorCause);
        }
        LOGGER.debug("addDocumentsToEnvelope end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelopes/{envelopeId}/documents", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Document>> getDocumentsFromEnvelope(
            @ApiParam(value = "Envelope ID.", required = true) @PathVariable(ENVELOPE_ID) String envelopeId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {
        
        LOGGER.debug("getDocumentsFromEnvelope called");
        RestResponse<Document> restResponse = new RestResponse<>();
        try {
            // validate input
            if (envelopeId == null || envelopeId.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + ENVELOPE_ID);
            }
            String scope = this.getScope();
            TokenType securityToken = TokenCreator.getTokenType();
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList = documentService.getDocumentsFromEnvelope(envelopeId);
            List<Document> valueList = DocumentConverter.convert(backendDocList, scope, securityToken.getToken());
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getDocumentsFromEnvelope end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelopes/{envelopeId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.DELETE)
    public ResponseEntity<RestResponse<String>> deleteEnvelope(
            @ApiParam(value = "Envelope ID.", required = true) @PathVariable(ENVELOPE_ID) String envelopeId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {
        
        LOGGER.debug("deleteEnvelope called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            // validate input
            if (envelopeId == null || envelopeId.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + ENVELOPE_ID);
            }
            documentService.deleteEnvelope(envelopeId);
            List<String> valueList = new ArrayList<>();
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("deleteEnvelope end");
        return ResponseEntity.ok(restResponse);
    }

}
