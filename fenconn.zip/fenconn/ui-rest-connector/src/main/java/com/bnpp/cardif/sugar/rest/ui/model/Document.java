package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Document
 */
public class Document implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("docFileID")
    private String docFileID = null;

    @JsonProperty("docViewURL")
    private String docViewURL = null;

    @JsonProperty("envelopeID")
    private String envelopeID = null;

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("language")
    private String language = null;

    @JsonProperty("retentionStartDate")
    private LocalDate retentionStartDate = null;

    @JsonProperty("retentionEndDate")
    private LocalDate retentionEndDate = null;

    @JsonProperty("confidentiality")
    private String confidentiality = null;

    @JsonProperty("docTypeId")
    private String docTypeId = null;

    @JsonProperty("docTypeVersion")
    private int docTypeVersion;

    @JsonProperty("direction")
    private String direction = null;

    @JsonProperty("validity")
    private String validity = null;

    @JsonProperty("tagList")
    private List<TagElement> tagList = new ArrayList<>();
    
    @JsonProperty("folderList")
    private List<Folder> folderList = new ArrayList<>();

    public Document id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Document identification
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Document identification")
    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Document name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Contains the name of the document.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Contains the name of the document.")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Document docFileID(String docFileID) {
        this.docFileID = docFileID;
        return this;
    }

    /**
     * Identification of the File already stored in the system.
     * 
     * @return docFileID
     **/
    @ApiModelProperty(required = true, value = "Identification of the File already stored in the system.")
    @NotNull
    public String getDocFileID() {
        return docFileID;
    }

    public void setDocFileID(String docFileID) {
        this.docFileID = docFileID;
    }

    public Document docViewURL(String docViewURL) {
        this.docViewURL = docViewURL;
        return this;
    }

    /**
     * URL to view the document file.
     * 
     * @return docViewURL
     **/
    @ApiModelProperty(required = true, value = "URL to view the document file.")
    @NotNull
    public String getDocViewURL() {
        return docViewURL;
    }

    public void setDocViewURL(String docViewURL) {
        this.docViewURL = docViewURL;
    }

    public Document envelopeID(String envelopeID) {
        this.envelopeID = envelopeID;
        return this;
    }

    /**
     * Identification of the envelope where the document will be stored.
     * 
     * @return envelopeID
     **/
    @ApiModelProperty(required = true, value = "Identification of the envelope where the document will be stored.")
    @NotNull
    public String getEnvelopeID() {
        return envelopeID;
    }

    public void setEnvelopeID(String envelopeID) {
        this.envelopeID = envelopeID;
    }

    public Document creationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    /**
     * When the document is created. On creation, this date will be filled with
     * the current date.
     * 
     * @return creationDate
     **/
    @ApiModelProperty(value = "When the document is created. On creation, this date will be filled with the current date.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public Document language(String language) {
        this.language = language;
        return this;
    }

    /**
     * Language for yhe document.
     * 
     * @return language
     **/
    @ApiModelProperty(value = "Language for the document.")
    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Document retentionStartDate(LocalDate retentionStartDate) {
        this.retentionStartDate = retentionStartDate;
        return this;
    }

    /**
     * Date from when document should be kept stored.
     * 
     * @return retentionStartDate
     **/
    @ApiModelProperty(value = "Date from when document should be kept stored.")
    @Valid
    public LocalDate getRetentionStartDate() {
        return retentionStartDate;
    }

    public void setRetentionStartDate(LocalDate retentionStartDate) {
        this.retentionStartDate = retentionStartDate;
    }

    public Document retentionEndDate(LocalDate retentionEndDate) {
        this.retentionEndDate = retentionEndDate;
        return this;
    }

    /**
     * Date until when document should be kept stored.
     * 
     * @return retentionEndDate
     **/
    @ApiModelProperty(value = "Date until when document should be kept stored.")
    @Valid
    public LocalDate getRetentionEndDate() {
        return retentionEndDate;
    }

    public void setRetentionEndDate(LocalDate retentionEndDate) {
        this.retentionEndDate = retentionEndDate;
    }

    public Document confidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
        return this;
    }

    /**
     * Defines if the document is confidential or not.
     * 
     * @return confidentiality
     **/
    @ApiModelProperty(value = "Defines if the document is confidential or not.")
    public String getConfidentiality() {
        return confidentiality;
    }

    public void setConfidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
    }

    public Document docTypeVersion(int docTypeVersion) {
        this.docTypeVersion = docTypeVersion;
        return this;
    }

    /**
     * Contains the version of the document type. On creation of a document,
     * this field will be filled with an default value fetched from the document
     * type.
     * 
     * @return docTypeVersion
     **/
    @ApiModelProperty(value = "Contains the version of the document type. On creation of a document, this field will be filled with an default value fetched from the document type.")
    public int getDocTypeVersion() {
        return docTypeVersion;
    }

    public void setDocTypeVersion(int docTypeVersion) {
        this.docTypeVersion = docTypeVersion;
    }

    public Document docTypeId(String docTypeId) {
        this.docTypeId = docTypeId;
        return this;
    }

    /**
     * Identification of the document type. On creation of a document, this
     * field will be filled with an default value fetched from the document type
     * 
     * @return docTypeId
     **/
    @ApiModelProperty(value = "Identification of the document type. On creation of a document, this field will be filled with an default value fetched from the document type")
    public String getDocTypeId() {
        return docTypeId;
    }

    public void setDocTypeId(String docTypeId) {
        this.docTypeId = docTypeId;
    }

    public Document direction(String direction) {
        this.direction = direction;
        return this;
    }

    /**
     * Identification of the document direction. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * direction
     * 
     * @return direction
     **/
    @ApiModelProperty(value = "Identification of the document direction. On creation of a document, this field will be filled with an default value fetched from the document direction")
    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Document validity(String validity) {
        this.validity = validity;
        return this;
    }

    /**
     * Identification of the document validity. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * validity
     * 
     * @return validity
     **/
    @ApiModelProperty(value = "Identification of the document validity. On creation of a document, this field will be filled with an default value fetched from the document validity")
    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public Document tagList(List<TagElement> tagList) {
        this.tagList = tagList;
        return this;
    }

    public Document addTagListItem(TagElement tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * Get tagList
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<TagElement> getTagList() {
        return tagList;
    }

    public void setTagList(List<TagElement> tagList) {
        this.tagList = tagList;
    }
    
    public Document folderList(List<Folder> folderList) {
        this.folderList = folderList;
        return this;
    }

    public Document addFolderListItem(Folder folderItem) {
        if (this.folderList == null) {
            this.folderList = new ArrayList<>();
        }
        this.folderList.add(folderItem);
        return this;
    }

    /**
     * Get folderList
     * 
     * @return folderList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<Folder> getFolderList() {
        return folderList;
    }

    public void setFolderList(List<Folder> folderList) {
        this.folderList = folderList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((confidentiality == null) ? 0 : confidentiality.hashCode());
        result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
        result = prime * result + ((direction == null) ? 0 : direction.hashCode());
        result = prime * result + ((docFileID == null) ? 0 : docFileID.hashCode());
        result = prime * result + ((docTypeId == null) ? 0 : docTypeId.hashCode());
        result = prime * result + docTypeVersion;
        result = prime * result + ((docViewURL == null) ? 0 : docViewURL.hashCode());
        result = prime * result + ((envelopeID == null) ? 0 : envelopeID.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((language == null) ? 0 : language.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((retentionEndDate == null) ? 0 : retentionEndDate.hashCode());
        result = prime * result + ((retentionStartDate == null) ? 0 : retentionStartDate.hashCode());
        result = prime * result + ((tagList == null) ? 0 : tagList.hashCode());
        result = prime * result + ((validity == null) ? 0 : validity.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Document))
            return false;
        Document other = (Document) obj;
        if (confidentiality == null) {
            if (other.confidentiality != null)
                return false;
        }
        else if (!confidentiality.equals(other.confidentiality))
            return false;
        if (creationDate == null) {
            if (other.creationDate != null)
                return false;
        }
        else if (!creationDate.equals(other.creationDate))
            return false;
        if (direction == null) {
            if (other.direction != null)
                return false;
        }
        else if (!direction.equals(other.direction))
            return false;
        if (docFileID == null) {
            if (other.docFileID != null)
                return false;
        }
        else if (!docFileID.equals(other.docFileID))
            return false;
        if (docTypeId == null) {
            if (other.docTypeId != null)
                return false;
        }
        else if (!docTypeId.equals(other.docTypeId))
            return false;
        if (docTypeVersion != other.docTypeVersion)
            return false;
        if (docViewURL == null) {
            if (other.docViewURL != null)
                return false;
        }
        else if (!docViewURL.equals(other.docViewURL))
            return false;
        if (envelopeID == null) {
            if (other.envelopeID != null)
                return false;
        }
        else if (!envelopeID.equals(other.envelopeID))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        }
        else if (!id.equals(other.id))
            return false;
        if (language == null) {
            if (other.language != null)
                return false;
        }
        else if (!language.equals(other.language))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        }
        else if (!name.equals(other.name))
            return false;
        if (retentionEndDate == null) {
            if (other.retentionEndDate != null)
                return false;
        }
        else if (!retentionEndDate.equals(other.retentionEndDate))
            return false;
        if (retentionStartDate == null) {
            if (other.retentionStartDate != null)
                return false;
        }
        else if (!retentionStartDate.equals(other.retentionStartDate))
            return false;
        if (tagList == null) {
            if (other.tagList != null)
                return false;
        }
        else if (!tagList.equals(other.tagList))
            return false;
        if (validity == null) {
            if (other.validity != null)
                return false;
        }
        else if (!validity.equals(other.validity))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Document [id=");
        builder.append(id);
        builder.append(", name=");
        builder.append(name);
        builder.append(", docFileID=");
        builder.append(docFileID);
        builder.append(", docViewURL=");
        builder.append(docViewURL);
        builder.append(", envelopeID=");
        builder.append(envelopeID);
        builder.append(", creationDate=");
        builder.append(creationDate);
        builder.append(", language=");
        builder.append(language);
        builder.append(", retentionStartDate=");
        builder.append(retentionStartDate);
        builder.append(", retentionEndDate=");
        builder.append(retentionEndDate);
        builder.append(", confidentiality=");
        builder.append(confidentiality);
        builder.append(", docTypeId=");
        builder.append(docTypeId);
        builder.append(", docTypeVersion=");
        builder.append(docTypeVersion);
        builder.append(", direction=");
        builder.append(direction);
        builder.append(", validity=");
        builder.append(validity);
        builder.append(", tagList=");
        builder.append(tagList);
        builder.append("]");
        return builder.toString();
    }

}
