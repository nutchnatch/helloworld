package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.rest.ui.model.DocumentAttachedToFoldersResult;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentIdentifier;
import com.bnpp.cardif.sugar.rest.ui.model.Folder;
import com.bnpp.cardif.sugar.rest.ui.model.FolderCreationResult;
import com.bnpp.cardif.sugar.rest.ui.model.TagElement;
import com.bnpp.cardif.sugar.utils.DateUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.MCOFolderType.ChildComponents;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

/**
 * 
 * @author 831743
 *
 */
public class FolderConverter {

    private static final Logger LOGGER = LoggerFactory.getLogger(FolderConverter.class);

    protected static final String ISSUER = "CARDIF";

    protected static final String SCHEME = "Sugar";

    /**
     * private empty constructor
     */
    private FolderConverter() {
        // private constructor to avoid instance creation.
    }

    /**
     * 
     * @param backendFolder
     * @return
     */
    public static Folder convert(com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder backendFolder,
            String scope, String token) {

        Folder result = null;
        if (backendFolder != null) {
            result = new Folder();
            // Id
            if (backendFolder.getFolderId() != null) {
                result.setId(backendFolder.getFolderId().getValue());
            }
            // data
            FolderDataType folderData = backendFolder.getData();
            convertFolderData(result, folderData);
            // Document IDs
            ChildComponents childData = backendFolder.getChildComponents();
            convertChildData(result, childData, scope, token);
            // tag list
            List<TagElement> tagList = new ArrayList<>();
            if (backendFolder.getTags() != null) {
                Tags folderTags = backendFolder.getTags();
                List<com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag> folderTagList = folderTags.getTag();
                if (folderTagList != null && !folderTagList.isEmpty()) {
                    tagList = TagConverter.convertElement(folderTagList);
                }
            }
            result.setTagList(tagList);
        }
        return result;
    }

    @SuppressWarnings({ "squid:S3776", "squid:S134" })
    private static void convertChildData(Folder result, ChildComponents childData, String scope, String token) {

        if (childData != null) {
            LOGGER.warn("Processing child Data : {}", childData);
            List<DocumentIdentifier> listOfDocumentId = new ArrayList<>();
            List<Document> documentList = childData.getDocument();
            if (documentList != null && !documentList.isEmpty()) {
                EnvelopeConverter.generateDocumentIdentifier(listOfDocumentId, documentList, scope, token);
            }
            else {
                // using the Ids
                List<Id> documentIdList = childData.getId();
                if (documentIdList != null) {
                    EnvelopeConverter.generateDocumentIdentifierFromIds(listOfDocumentId, documentIdList);
                }
            }
            result.setListOfDocumentId(listOfDocumentId);
        }
    }

    private static void convertFolderData(Folder result, FolderDataType folderData) {
        if (folderData != null) {
            if (folderData.getClassId() != null) {
                result.setFolderTypeId(folderData.getClassId().getValue());
                result.setFolderTypeVersion(folderData.getClassId().getVersId());
            }
            result.setName(folderData.getName());
            result.setOwner(folderData.getOwner());
            if (folderData.getStatusCode() != null) {
                result.setStatus(folderData.getStatusCode().value());
            }
            if (folderData.getCreatnDate() != null) {
                result.setCreationDate(DateUtils.asZonedDateTime(folderData.getCreatnDate()));
            }
            if (folderData.getUpdtDate() != null) {
                result.setLastUpdateDate(DateUtils.asZonedDateTime(folderData.getUpdtDate()));
            }
            if (folderData.getRetentionEndDate() != null) {
                result.setRetentionDate(DateUtils.asLocalDate(folderData.getRetentionEndDate()));
            }
        }
    }

    /**
     * Convert a list of backend folder into a List of JSON Folder
     * 
     * @param backendFolderList
     *            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder>
     * @return List<Folder>
     */
    public static List<Folder> convert(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> backendFolderList, String scope,
            String token) {

        List<Folder> result = new ArrayList<>();
        if (backendFolderList != null && !backendFolderList.isEmpty()) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder backendFolder : backendFolderList) {
                Folder content = FolderConverter.convert(backendFolder, scope, token);
                result.add(content);
            }
        }
        return result;
    }

    /**
     * Convert a list of JSON Folder into a List of backend folder
     * 
     * @param folderList
     * @param scope
     * @return List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder>
     */
    public static List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder>
            convert(List<Folder> folderList, String scope) {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> result = new ArrayList<>();
        if (folderList != null && !folderList.isEmpty()) {
            for (Folder folder : folderList) {
                com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder content = FolderConverter
                        .convert(folder, scope);
                result.add(content);
            }
        }
        return result;
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder convert(Folder folder,
            String scope) {

        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder result = null;
        if (folder != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder();
            result.setScope(scope);
            // Id
            if (folder.getId() != null) {
                FolderId folderId = new FolderId();
                folderId.setIssuer(ISSUER);
                folderId.setScheme(SCHEME);
                folderId.setValue(folder.getId());
                result.setFolderId(folderId);
            }
            // data
            FolderDataType folderData = convertFolderData(folder);
            result.setData(folderData);
            // Document IDs
            ChildComponents childData = convertChildData(folder);
            result.setChildComponents(childData);
            // tag list
            List<Tag> tagList = new ArrayList<>();
            if (folder.getTagList() != null) {
                for (TagElement tagElement : folder.getTagList()) {
                    Tag content = new Tag(tagElement.getTagValue(), tagElement.getTagName());
                    tagList.add(content);
                }
            }
            Tags tags = new Tags(tagList);
            result.setTags(tags);
        }
        return result;
    }

    private static ChildComponents convertChildData(Folder folder) {

        ChildComponents result = new ChildComponents();
        List<Id> idList = result.getId();
        List<DocumentIdentifier> docIdList = folder.getListOfDocumentId();
        if (docIdList != null) {
            for (DocumentIdentifier documentIdentifier : docIdList) {
                Id content = new Id(documentIdentifier.getId(), ISSUER, SCHEME);
                idList.add(content);
            }
        }
        return result;
    }

    private static FolderDataType convertFolderData(Folder folder) {

        FolderDataType result = new FolderDataType();
        if (folder.getFolderTypeId() != null && !folder.getFolderTypeId().isEmpty()) {
            ClassId classId = new ClassId();
            classId.setIssuer(ISSUER);
            classId.setValue(folder.getFolderTypeId());
            classId.setVersId(folder.getFolderTypeVersion());
            result.setClassId(classId);
        }
        result.setName(folder.getName());
        result.setOwner(folder.getOwner());
        if (folder.getStatus() != null) {
            result.setStatusCode(FolderStatusCodeType.fromValue(folder.getStatus()));
        }
        if (folder.getCreationDate() != null) {
            result.setCreatnDate(DateUtils.asDate(folder.getCreationDate()));
        }
        if (folder.getLastUpdateDate() != null) {
            result.setUpdtDate(DateUtils.asDate(folder.getLastUpdateDate()));
        }
        if (folder.getRetentionDate() != null) {
            result.setRetentionEndDate(DateUtils.asDate(folder.getRetentionDate()));
        }
        return result;
    }

    public static List<FolderCreationResult> convertToFolderCreationResult(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> backendFolderList) {

        List<FolderCreationResult> result = new ArrayList<>();
        if (backendFolderList != null) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder backendFolder : backendFolderList) {
                if (backendFolder.getFolderId() != null) {
                    FolderCreationResult content = new FolderCreationResult();
                    content.setFolderId(backendFolder.getFolderId().getValue());
                    result.add(content);
                }
            }
        }
        return result;
    }

    public static DocumentAttachedToFoldersResult convertToDocumentAttachedToFoldersResult(
            com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder backendFolder) {

        DocumentAttachedToFoldersResult result = null;
        if (backendFolder != null && backendFolder.getFolderId() != null) {
            result = new DocumentAttachedToFoldersResult();
            result.setFolderId(backendFolder.getFolderId().getValue());
            List<String> documentIdArray = new ArrayList<>();
            if (backendFolder.getChildComponents() != null) {
                List<Id> docIdList = backendFolder.getChildComponents().getId();
                if(docIdList != null) {
                    for (Id id : docIdList) {
                        documentIdArray.add(id.getValue());
                    }
                }
            }
            result.setDocumentIdArray(documentIdArray);
        }
        return result;
    }

}
