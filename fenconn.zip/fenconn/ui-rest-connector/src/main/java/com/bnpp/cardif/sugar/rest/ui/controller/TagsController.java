package com.bnpp.cardif.sugar.rest.ui.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.TagsService;
import com.bnpp.cardif.sugar.rest.ui.api.TagsApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.TagConverter;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class TagsController extends FrontendController implements TagsApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(TagsController.class);

    @Autowired
    TagsService tagsService;

    @RequestMapping(value = "/tags/{tag_name}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Tag>> tagsTagNameGet(
            @NotNull @ApiParam(value = "Name that identifies the tag uniquely.", required = true) @PathVariable("tag_name") String tagName,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("tagsTagNameGet called");
        RestResponse<Tag> restResponse = new RestResponse<>();
        try {
            List<String> symbolicNames = new ArrayList<>();
            symbolicNames.add(tagName);
            List<TagClass> result = tagsService.getTagListBySymbolicName(symbolicNames);
            // transform service result into JSON response
            List<Tag> valueList = TagConverter.convert(result);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }

        LOGGER.debug("tagsTagNameGet end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/tags", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Tag>> getAllTags(
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getAllTags called");
        RestResponse<Tag> restResponse = new RestResponse<>();
        try {
            List<TagClass> result = tagsService.getAllTagList();
            // transform service result into JSON response
            List<Tag> valueList = TagConverter.convert(result);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getAllTags end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/tags", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<Tag>> createTag(
            @ApiParam(value = "The Tag to create", required = true) @Valid @RequestBody Tag inputTag,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("createTag called");
        RestResponse<Tag> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputTag == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputTag");
            }
            TagClass input = TagConverter.convert(inputTag, getScope());
            // call service
            TagClass result = tagsService.createTag(input);
            // transform service result into JSON response
            Tag folderType = null;
            if (result != null) {
                folderType = TagConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<Tag> valueList = new ArrayList<>();
            valueList.add(folderType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("createTag end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/tags/{tagId}", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<Tag>> updateTag(
            @ApiParam(value = "Tag ID.", required = true) @PathVariable("tagId") String tagId,
            @ApiParam(value = "The Tag to update", required = true) @Valid @RequestBody Tag inputTag,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateTag called");
        RestResponse<Tag> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputTag == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "inputTag");
            }
            TagClass input = TagConverter.convert(inputTag, getScope());
            // call service
            TagClass result = tagsService.updateTag(input);
            // transform service result into JSON response
            Tag tag = null;
            if (result != null) {
                tag = TagConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<Tag> valueList = new ArrayList<>();
            valueList.add(tag);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateTag end");
        return ResponseEntity.ok(restResponse);
    }

}
