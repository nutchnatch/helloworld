package com.bnpp.cardif.sugar.rest.ui.api;

import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bnpp.cardif.sugar.rest.ui.model.CurrentUser;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;

@Path("/resources")
@Api(value = "resources")
@Produces({ "application/json; charset=UTF-8" })
public interface ResourcesApi {

    /**
     * Retrieve Current User Informations
     * 
     * @return ResponseEntity<RestResponse<CurrentUser>>
     */
    @ApiOperation(value = "Get Current User", notes = "Retrieve Current User Informations", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 400, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Response OK with paginated result (200)", response = RestResponse.class) })
    @RequestMapping(value = "/resources/user", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    ResponseEntity<RestResponse<CurrentUser>> getCurrentUser();

    @ApiOperation(value = "Logout Current User", notes = "Logout Current User invalidate the sesame token and the current session.", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 400, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Response OK with paginated result (200)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Response OK with paginated result (200)", response = RestResponse.class) })
    @RequestMapping(value = "/logout", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<String>> logout();

}
