package com.bnpp.cardif.sugar.rest.ui.controller;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.BusinessScopeService;
import com.bnpp.cardif.sugar.rest.ui.api.BusinessScopesApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.AclConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.BusinessScopeConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.DocumentFileConverter;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.BusinessScope;
import com.bnpp.cardif.sugar.rest.ui.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class BusinessScopesController extends FrontendController implements BusinessScopesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessScopesController.class);

    @Autowired
    BusinessScopeService businessScopeService;

    @Autowired
    AclService aclService;

    @RequestMapping(value = "/business-scopes", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<BusinessScope>> getBusinessScope(
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getBusinessScope called");
        RestResponse<BusinessScope> restResponse = new RestResponse<>();
        try {
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope = businessScopeService
                    .getBusinessScope();
            // transform service result into JSON response
            BusinessScope businessScope = null;
            if (backendBusinessScope != null) {
                businessScope = BusinessScopeConverter.convert(backendBusinessScope);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<BusinessScope> valueList = new ArrayList<>();
            valueList.add(businessScope);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getBusinessScope end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/business-scopes/{businessScopeId}", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<BusinessScope>> updateBusinessScope(
            @ApiParam(value = "BusinessScope ID", required = true) @PathVariable("businessScopeId") String businessScopeId,
            @ApiParam(value = "The BusinessScope to update", required = true) @Valid @RequestBody BusinessScope inputBusinessScope,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateBusinessScope called");
        RestResponse<BusinessScope> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputBusinessScope == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "businessScope");
            }
            // create input parameters
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope inputBS = BusinessScopeConverter
                    .convert(inputBusinessScope);
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope = businessScopeService
                    .updateBusinessScope(inputBS);
            // transform service result into JSON response
            BusinessScope businessScope = null;
            if (backendBusinessScope != null) {
                businessScope = BusinessScopeConverter.convert(backendBusinessScope);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<BusinessScope> valueList = new ArrayList<>();
            valueList.add(businessScope);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateBusinessScope end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/business-scopes/{businessScopeId}/rule-file", produces = {
            "application/json; charset=UTF-8" }, consumes = { "multipart/form-data" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<BusinessScope>> updateRuleFile(
            @ApiParam(value = "BusinessScope ID", required = true) @PathVariable("businessScopeId") String businessScopeId,
            @ApiParam(value = "The rule File content (binary data)", required = true) @RequestPart("file") MultipartFile file,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateRuleFile called");
        RestResponse<BusinessScope> restResponse = new RestResponse<>();
        try {
            // validate input
            if (file == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "file");
            }
            if (businessScopeId == null || businessScopeId.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "businessScopeId");
            }
            // create input parameters
            String scope = this.getScope();
            DocumentFile inputDocFile = DocumentFileConverter.convert(file, scope);
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope = businessScopeService
                    .updateRuleFile(inputDocFile);
            // transform service result into JSON response
            BusinessScope businessScope = null;
            if (backendBusinessScope != null) {
                businessScope = BusinessScopeConverter.convert(backendBusinessScope);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<BusinessScope> valueList = new ArrayList<>();
            valueList.add(businessScope);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (IOException e) {
            LOGGER.info("addEnvelope error : ", e);
            restResponse.setStatus(false);
            ErrorCause errorCause = new ErrorCause();
            errorCause.setCode(ErrorCode.TE003.getCode());
            errorCause.setErrorDate(ZonedDateTime.now());
            errorCause.setMessage("Technical error : " + e.getMessage());
            restResponse.setError(errorCause);
        }
        LOGGER.debug("updateRuleFile end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/business-scopes/{businessScopeId}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Acl>> getBusinessScopeAcl(
            @ApiParam(value = "BusinessScope ID", required = true) @PathVariable("businessScopeId") String businessScopeId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getBusinessScopeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();
        try {
            // validate input
            if (businessScopeId == null || businessScopeId.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "businessScopeId");
            }
            // call service
            AccessControlList instanceAcl = aclService.getDefaultAclByBuisnessScope();
            // transform service result into JSON response
            List<Acl> valueList = new ArrayList<>();
            if (instanceAcl != null) {
                Acl content = AclConverter.convert(instanceAcl, true);
                valueList.add(content);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getBusinessScopeAcl end");
        return ResponseEntity.ok(restResponse);
    }

}
