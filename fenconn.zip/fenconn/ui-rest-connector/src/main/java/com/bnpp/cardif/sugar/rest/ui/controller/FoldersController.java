package com.bnpp.cardif.sugar.rest.ui.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.FolderService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpp.cardif.sugar.rest.ui.api.FoldersApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.FolderConverter;
import com.bnpp.cardif.sugar.rest.ui.model.Document;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentAttachedToFoldersResult;
import com.bnpp.cardif.sugar.rest.ui.model.Folder;
import com.bnpp.cardif.sugar.rest.ui.model.FolderCreationResult;
import com.bnpp.cardif.sugar.rest.ui.model.Paging;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.utils.CollectionUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class FoldersController extends FrontendController implements FoldersApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(FoldersController.class);

    @Autowired
    FolderService folderService;

    @RequestMapping(value = "/folders/{folderId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Folder>> getFolderById(
            @ApiParam(value = "Folder ID", required = true) @PathVariable("folderId") String folderId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getFolderById called");
        RestResponse<Folder> restResponse = new RestResponse<>();
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder backendFolder = folderService
                    .getFolderByID(folderId);
            // transform service result into JSON response
            Folder folder = null;
            if (backendFolder != null) {
                folder = FolderConverter.convert(backendFolder, getScope(), securityToken.getToken());
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<Folder> valueList = new ArrayList<>();
            valueList.add(folder);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getFolderById end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folders", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Folder>> getFolders(
            @ApiParam(value = "Quick Search value. If this parameter is passed, the other criteria will be ignored.", required = false, defaultValue = "") @RequestParam(value = "quickSearch", required = false, defaultValue = "") String quickSearch,
            @ApiParam(value = "Creation Date Search criteria with operator and value, the | is used as separator. example : 'greater_than|2016-10-27'", required = false, defaultValue = "", example = "greater_than|2016-10-27") @RequestParam(value = "creationDate", required = false, defaultValue = "") String creationDateCriteria,
            @ApiParam(value = "Update Date Search criteria with operator and value, the | is used as separator. example : 'less_than|2017-10-27'", required = false, defaultValue = "", example = "less_than|2017-10-27") @RequestParam(value = "updateDate", required = false, defaultValue = "") String updateDateCriteria,
            @ApiParam(value = "Creator Search criteria with operator and value, the | is used as separator. example : 'equals_to|my name'", required = false, defaultValue = "", example = "equals_to|my name") @RequestParam(value = "creator", required = false, defaultValue = "") String creatorCriteria,
            @ApiParam(value = "Last Modifier Search criteria with operator and value, the | is used as separator. example : 'starts_with|my'", required = false, defaultValue = "", example = "starts_with|my") @RequestParam(value = "lastModifier", required = false, defaultValue = "") String lastModifierCriteria,
            @ApiParam(value = "Name Search criteria with operator and value, the | is used as separator. example : 'contains|doc'", required = false, defaultValue = "", example = "contains|doc") @RequestParam(value = "name", required = false, defaultValue = "") String nameCriteria,
            @ApiParam(value = "Representation of a tag with name, type, operator and value the | is used as separator. example : 'tagName1|string|ends_with|value1, tagName2|string|not_equals_to|value2'", required = false, defaultValue = "", example = "tagName1|string|ends_with|value1, tagName2|string|not_equals_to|value2") @RequestParam(value = "tags", required = false) List<String> tags,
            @ApiParam(value = "Is using ascending Ordering of the result ?") @RequestParam(value = "orderAscending", required = false) Boolean orderAscending,
            @ApiParam(value = "Name of the field used for ordering", allowableValues = "name, validity_code, creator, last_modifier, creation_date, update_date, confidentiality,tag") @RequestParam(value = "orderField", required = false) String orderField,
            @ApiParam(value = "If orderField=tag then Name of the tag to be used for ordering") @RequestParam(value = "orderTagName", required = false) String orderTagName,
            @NotNull @Min(1) @ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue = "1") Integer pageNumber,
            @NotNull @Min(1) @Max(100) @ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue = "10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getFolders called");
        RestResponse<Folder> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputFoldersGet(pageNumber, pageSize, orderField);
            @SuppressWarnings("squid:S2259")
            long maximum = pageSize.longValue();
            @SuppressWarnings("squid:S2259")
            long start = (pageNumber.longValue() - 1) * maximum;

            TokenType securityToken = TokenCreator.getTokenType();
            List<Criterion> criterionList = this.generateCriterionListFromInput(creationDateCriteria,
                    updateDateCriteria, creatorCriteria, lastModifierCriteria, null, nameCriteria, null, null, tags);
            OrderClause orderClause = this.generateOrderClauseFromInput(orderAscending, orderField, orderTagName);

            PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> backendFolderList = folderService
                    .findFolders(start, maximum, quickSearch, criterionList, orderClause, false);
            // transform service result into JSON response
            List<Folder> valueList;
            if (backendFolderList != null) {
                valueList = FolderConverter.convert(backendFolderList.getItemList(), getScope(),
                        securityToken.getToken());
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
            fillPaging(pageNumber, pageSize, restResponse, backendFolderList);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getFolders end");
        return ResponseEntity.ok(restResponse);

    }

    private void validateInputFoldersGet(Integer pageNumber, Integer pageSize, String orderField)
            throws InvalidInputException {
        List<String> missingInputs = new ArrayList<>();
        validatePagingInput(pageNumber, pageSize, missingInputs);
        if (!missingInputs.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + CollectionUtils.collectionToString(missingInputs));
        }
        this.validateOrderField(orderField);
    }

    private void fillPaging(Integer pageNumber, Integer pageSize, RestResponse<Folder> restResponse,
            PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> backendFolderList) {

        Paging paging = new Paging();
        paging.setCurrentPage(pageNumber.longValue());
        long lpageSize = pageSize.longValue();
        paging.setPageSize(lpageSize);
        long totalItem = backendFolderList.getItemNumber();
        paging.setTotalItems(totalItem);
        Long totalPages = (totalItem + lpageSize - 1) / lpageSize;
        paging.setTotalPages(totalPages);
        restResponse.setPaging(paging);
    }

    @RequestMapping(value = "/folders", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<FolderCreationResult>> addFolder(
            @ApiParam(value = "The folder to create", required = true) @Valid @RequestBody Folder folder,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("addFolder called");
        RestResponse<FolderCreationResult> restResponse = new RestResponse<>();
        try {
            // validate input
            if (folder == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "folder");
            }
            // create input parameters
            String scope = this.getScope();
            List<Folder> folderList = new ArrayList<>();
            folderList.add(folder);
            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> inputFolderList = FolderConverter
                    .convert(folderList, scope);
            // create the folder
            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> backendFolderList = folderService
                    .createFolders(inputFolderList);
            // transform service result into JSON response
            List<FolderCreationResult> valueList;
            if (backendFolderList != null) {
                valueList = FolderConverter.convertToFolderCreationResult(backendFolderList);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002.getCode(),
                        "Error, folder creation should return the created folder");
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("addFolder end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folders/{folderId}", produces = { "application/json",
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<FolderCreationResult>> updateFolder(
            @ApiParam(value = "Folder ID", required = true) @PathVariable("folderId") String folderId,
            @ApiParam(value = "The folder to update", required = true) @Valid @RequestBody Folder folder,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {
        
        
        LOGGER.debug("updateFolder called");
        RestResponse<FolderCreationResult> restResponse = new RestResponse<>();
        try {
            // validate input
            if (folder == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "folder");
            }
            // create input parameters
            String scope = this.getScope();
            List<Folder> folderList = new ArrayList<>();
            folderList.add(folder);
            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> inputFolderList = FolderConverter
                    .convert(folderList, scope);
            // update the folder
            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> backendFolderList = folderService
                    .updateFolders(inputFolderList);
            // transform service result into JSON response
            List<FolderCreationResult> valueList;
            if (backendFolderList != null) {
                valueList = FolderConverter.convertToFolderCreationResult(backendFolderList);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002.getCode(),
                        "Error, folder update should return the modified folder");
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateFolder end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folders/{folderId}/documents", produces = {
            "application/json; charset=UTF-8" }, consumes = { "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<DocumentAttachedToFoldersResult>> attachDocument(
            @ApiParam(value = "Folder ID.", required = true) @PathVariable("folderId") String folderId,
            @ApiParam(value = "List of document ID", required = true) @Valid @RequestBody List<String> documentIds,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {
        
        LOGGER.debug("attachDocument called");
        RestResponse<DocumentAttachedToFoldersResult> restResponse = new RestResponse<>();
        try {
            // validate input
            if (folderId == null || folderId.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "folderId");
            }
            if (documentIds == null || documentIds.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "documentIds");
            }
            // call service
            com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder backendFolder = folderService
                    .attachDocumentToFolder(folderId, documentIds);
            // transform service result into JSON response
            List<DocumentAttachedToFoldersResult> valueList = new ArrayList<>();
            if (backendFolder != null) {
                DocumentAttachedToFoldersResult result = FolderConverter.convertToDocumentAttachedToFoldersResult(backendFolder);
                valueList.add(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002.getCode(),
                        "Error, attachDocument should return a result");
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("attachDocument end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folders/{folderId}/documents", produces = {
            "application/json; charset=UTF-8" }, consumes = { "application/json; charset=UTF-8" }, method = RequestMethod.DELETE)
    public ResponseEntity<RestResponse<DocumentAttachedToFoldersResult>> detachDocumentFromFolder(
            @ApiParam(value = "Folder ID.", required = true) @PathVariable("folderId") String folderId,
            @ApiParam(value = "List of document ID", required = true) @Valid @RequestBody List<String> documentIds,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {
        
        LOGGER.debug("detachDocumentFromFolder called");
        RestResponse<DocumentAttachedToFoldersResult> restResponse = new RestResponse<>();
        try {
            // validate input
            if (folderId == null || folderId.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "folderId");
            }
            if (documentIds == null || documentIds.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "documentIds");
            }
            // call service
            com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder backendFolder = folderService
                    .detachDocumentFromFolder(folderId, documentIds);
            // transform service result into JSON response
            List<DocumentAttachedToFoldersResult> valueList = new ArrayList<>();
            if (backendFolder != null) {
                DocumentAttachedToFoldersResult result = FolderConverter.convertToDocumentAttachedToFoldersResult(backendFolder);
                valueList.add(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002.getCode(),
                        "Error, detachDocument should return a result");
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("detachDocumentFromFolder end");
        return ResponseEntity.ok(restResponse);
    }

}
