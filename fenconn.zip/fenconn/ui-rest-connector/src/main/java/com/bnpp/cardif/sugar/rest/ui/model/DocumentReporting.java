package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class DocumentReporting implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @JsonProperty("classId")
    private String classId = null;

    @JsonProperty("classVersion")
    private long classVersion = 0;

    @JsonProperty("numberOfDocuments")
    private long numberOfDocuments = 0;

    @JsonProperty("sizeOfFiles")
    private long sizeOfFiles = 0;

    public DocumentReporting classId(String classId) {
        this.classId = classId;
        return this;
    }

    /**
     * Identifier of the document class.
     * 
     * @return classId
     **/
    @ApiModelProperty(required = true, value = "Identifier of the document class.")
    @NotNull
    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public DocumentReporting classVersion(long classVersion) {
        this.classVersion = classVersion;
        return this;
    }

    /**
     * Version of the document class.
     * 
     * @return classVersion
     **/
    @ApiModelProperty(required = true, value = "Version of the document class.")
    @NotNull
    public long getClassVersion() {
        return classVersion;
    }

    public void setClassVersion(long classVersion) {
        this.classVersion = classVersion;
    }

    public DocumentReporting numberOfDocuments(long numberOfDocuments) {
        this.numberOfDocuments = numberOfDocuments;
        return this;
    }

    /**
     * Number of document of the related class.
     * 
     * @return numberOfDocuments
     **/
    @ApiModelProperty(required = true, value = "Number of document of the related class.")
    @NotNull
    public long getNumberOfDocuments() {
        return numberOfDocuments;
    }

    public void setNumberOfDocuments(long numberOfDocuments) {
        this.numberOfDocuments = numberOfDocuments;
    }

    public DocumentReporting sizeOfFiles(long sizeOfFiles) {
        this.sizeOfFiles = sizeOfFiles;
        return this;
    }

    /**
     * Size of the file of the related class.
     * 
     * @return sizeOfFiles
     **/
    @ApiModelProperty(required = true, value = "Size of the file of the related class.")
    @NotNull
    public long getSizeOfFiles() {
        return sizeOfFiles;
    }

    public void setSizeOfFiles(long sizeOfFiles) {
        this.sizeOfFiles = sizeOfFiles;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((classId == null) ? 0 : classId.hashCode());
        result = prime * result + (int) (classVersion ^ (classVersion >>> 32));
        result = prime * result + (int) (numberOfDocuments ^ (numberOfDocuments >>> 32));
        result = prime * result + (int) (sizeOfFiles ^ (sizeOfFiles >>> 32));
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof DocumentReporting))
            return false;
        DocumentReporting other = (DocumentReporting) obj;
        if (classId == null) {
            if (other.classId != null)
                return false;
        }
        else if (!classId.equals(other.classId))
            return false;
        if (classVersion != other.classVersion)
            return false;
        if (numberOfDocuments != other.numberOfDocuments)
            return false;
        if (sizeOfFiles != other.sizeOfFiles)
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DocumentReporting [classId=");
        builder.append(classId);
        builder.append(", classVersion=");
        builder.append(classVersion);
        builder.append(", numberOfDocuments=");
        builder.append(numberOfDocuments);
        builder.append(", sizeOfFiles=");
        builder.append(sizeOfFiles);
        builder.append("]");
        return builder.toString();
    }

}
