package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author 831743
 *
 */
@ApiModel(description = "Represents a configured tag with the respective value and the search operator.")
public class TagSearchElement implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("tag")
    private TagElement tag;

    @JsonProperty("tagOperator")
    private SearchOperator tagOperator;

    @JsonProperty("tagType")
    private TagType tagType;

    /**
     * @return the tag
     */
    @ApiModelProperty(value = "the Tag name and value to search")
    public TagElement getTag() {
        return tag;
    }

    /**
     * @param tag
     *            the tag to set
     */
    public void setTag(TagElement tag) {
        this.tag = tag;
    }

    /**
     * @return the tagOperator
     */
    @ApiModelProperty(value = "the search operator for this tag", example = "starts_with", allowableValues = "not_equals_to, equals_to, contains, less_than, greater_than, starts_with, ends_with")
    public SearchOperator getTagOperator() {
        return tagOperator;
    }

    /**
     * @param tagOperator
     *            the tagOperator to set
     */
    public void setTagOperator(SearchOperator tagOperator) {
        this.tagOperator = tagOperator;
    }

    /**
     * @return the tagType
     */
    @ApiModelProperty(value = "the Tag type to search", example = "string", allowableValues = "string, timestamp, boolean, integer")
    public TagType getTagType() {
        return tagType;
    }

    /**
     * @param tagType
     *            the tagType to set
     */
    public void setTagType(TagType tagType) {
        this.tagType = tagType;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((tag == null) ? 0 : tag.hashCode());
        result = prime * result + ((tagOperator == null) ? 0 : tagOperator.hashCode());
        result = prime * result + ((tagType == null) ? 0 : tagType.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof TagSearchElement))
            return false;
        TagSearchElement other = (TagSearchElement) obj;
        if (tag == null) {
            if (other.tag != null)
                return false;
        }
        else if (!tag.equals(other.tag))
            return false;
        if (tagOperator != other.tagOperator)
            return false;
        if (tagType != other.tagType)
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("TagSearchElement [tag=");
        builder.append(tag);
        builder.append(", tagOperator=");
        builder.append(tagOperator);
        builder.append(", tagType=");
        builder.append(tagType);
        builder.append("]");
        return builder.toString();
    }

}
