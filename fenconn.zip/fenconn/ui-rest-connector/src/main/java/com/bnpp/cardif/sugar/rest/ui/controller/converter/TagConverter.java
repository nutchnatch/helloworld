package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.util.ArrayList;
import java.util.List;

import com.bnpp.cardif.sugar.rest.ui.model.AllowableTagValue;
import com.bnpp.cardif.sugar.rest.ui.model.DisplayNameItem;
import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpp.cardif.sugar.rest.ui.model.TagElement;
import com.bnpp.cardif.sugar.rest.ui.model.TagType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOAllowedValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagValueType;

/**
 * 
 * @author 831743
 *
 */
public class TagConverter {

    protected static final String ISSUER = "CARDIF";

    /**
     * private empty constructor
     */
    private TagConverter() {
        // private constructor to avoid instance creation.
    }

    /**
     * Convert backend TagClass to JSON Tag
     * 
     * @param backendTag
     * @return Tag
     */
    public static Tag convert(TagClass backendTag) {
        Tag result = null;
        if (backendTag != null) {
            result = new Tag();
            if (backendTag.getClassId() != null) {
                result.setId(backendTag.getClassId().getValue());
            }
            result.setName(backendTag.getSymbolicName());
            result.setType(mapTagType(backendTag.getTagType()));
            result.setIsSearchable(backendTag.isIsSearchable());
            result.setPattern(backendTag.getPattern());
            // no tag value
            convertLabelList(backendTag, result);
            convertAllowedValueList(backendTag, result);
        }
        return result;
    }

    private static void convertAllowedValueList(TagClass backendTag, Tag result) {
        List<AllowableTagValue> choicelist = new ArrayList<>();
        List<MCOAllowedValue> allowedValueList = backendTag.getAllowedValue();
        if (allowedValueList != null) {
            for (MCOAllowedValue mcoAllowedValue : allowedValueList) {
                addAllowableTagValue(choicelist, mcoAllowedValue);
            }
        }
        result.setChoicelist(choicelist);
    }

    private static void convertLabelList(TagClass backendTag, Tag result) {
        List<DisplayNameItem> diplayNameItem = new ArrayList<>();
        List<MCOI18NLabel> labelList = backendTag.getLabel();
        if (labelList != null) {
            for (MCOI18NLabel mcoi18nLabel : labelList) {
                addDisplayNameItemFromLabel(diplayNameItem, mcoi18nLabel);
            }
        }
        result.setDiplayNameItem(diplayNameItem);
    }

    private static TagType mapTagType(TagValueType backendTagType) {
        TagType result = null;
        switch (backendTagType) {
        case BOOLEAN:
            result = TagType.BOOLEAN;
            break;
        case INT:
            result = TagType.INTEGER;
            break;
        case DATE:
            result = TagType.TIMESTAMP;
            break;
        case CHOICELIST:
            result = TagType.CHOICELIST;
            break;
        case STRING:
        default:
            result = TagType.STRING;
            break;
        }
        return result;
    }

    private static void addAllowableTagValue(List<AllowableTagValue> choicelist, MCOAllowedValue mcoAllowedValue) {
        AllowableTagValue tagValue = new AllowableTagValue();
        tagValue.setSymbolicName(mcoAllowedValue.getSymbolicName());
        List<DisplayNameItem> displayNameValues = new ArrayList<>();
        List<MCOI18NLabel> innerLabelList = mcoAllowedValue.getLabel();
        if (innerLabelList != null) {
            for (MCOI18NLabel mcoi18nLabel : innerLabelList) {
                addDisplayNameItemFromLabel(displayNameValues, mcoi18nLabel);
            }
        }
        tagValue.setDisplayNameValues(displayNameValues);
        choicelist.add(tagValue);
    }

    private static void addDisplayNameItemFromLabel(List<DisplayNameItem> diplayNameItem, MCOI18NLabel mcoi18nLabel) {
        DisplayNameItem item = new DisplayNameItem();
        item.setLanguage(mcoi18nLabel.getLanguage());
        item.setValue(mcoi18nLabel.getValue());
        diplayNameItem.add(item);
    }

    /**
     * Convert a list of backend TagClass to a list of JSON Tag
     * 
     * @param backendTagList
     * @return List<Tag>
     */
    public static List<Tag> convert(List<TagClass> backendTagList) {
        List<Tag> result = new ArrayList<>();
        for (TagClass backendTag : backendTagList) {
            Tag content = TagConverter.convert(backendTag);
            result.add(content);
        }
        return result;
    }

    /**
     * Convert backend
     * com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag to JSON
     * TagElement
     * 
     * @param backendTag
     * @return
     */
    public static TagElement convertElement(com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag backendTag) {
        TagElement result = null;
        if (backendTag != null) {
            result = new TagElement();
            result.setTagName(backendTag.getName());
            result.setTagValue(backendTag.getValue());
        }
        return result;
    }

    /**
     * Convert a list of backend
     * com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag to a list
     * of JSON TagElement
     * 
     * @param backendTagList
     * @return
     */
    public static List<TagElement>
            convertElement(List<com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag> backendTagList) {
        List<TagElement> result = new ArrayList<>();
        for (com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag backendTag : backendTagList) {
            TagElement content = TagConverter.convertElement(backendTag);
            result.add(content);
        }
        return result;
    }

    public static TagClass convert(Tag inputTag, String scope) {

        TagClass result = null;
        if (inputTag != null) {
            result = new TagClass();
            ClassId classId = new ClassId(inputTag.getId(), ISSUER, 1);
            result.setClassId(classId);
            result.setIsSearchable(inputTag.getIsSearchable());
            result.setPattern(inputTag.getPattern());
            result.setScope(scope);
            result.setSymbolicName(inputTag.getName());
            result.setTagType(mapTagValueType(inputTag.getType()));
            convertChoiceList(inputTag, result);
            convertDisplayNameItems(inputTag, result);
        }
        return result;
    }

    private static void convertDisplayNameItems(Tag inputTag, TagClass result) {
        List<MCOI18NLabel> labelList = result.getLabel();
        List<DisplayNameItem> displayNameItemList = inputTag.getDiplayNameItem();
        for (DisplayNameItem displayNameItem : displayNameItemList) {
            addLabelFromDisplayNameItem(labelList, displayNameItem);
        }
    }

    private static void convertChoiceList(Tag inputTag, TagClass result) {
        List<MCOAllowedValue> allowedValueList = result.getAllowedValue();
        List<AllowableTagValue> choicelist = inputTag.getChoicelist();
        for (AllowableTagValue allowableTagValue : choicelist) {
            MCOAllowedValue content = new MCOAllowedValue();
            content.setSymbolicName(allowableTagValue.getSymbolicName());
            List<MCOI18NLabel> labelList = content.getLabel();
            List<DisplayNameItem> displayNameValues = allowableTagValue.getDisplayNameValues();
            for (DisplayNameItem displayNameItem : displayNameValues) {
                addLabelFromDisplayNameItem(labelList, displayNameItem);
            }
            allowedValueList.add(content);
        }
    }

    private static void addLabelFromDisplayNameItem(List<MCOI18NLabel> labelList, DisplayNameItem displayNameItem) {
        MCOI18NLabel label = new MCOI18NLabel();
        label.setLanguage(displayNameItem.getLanguage());
        label.setValue(displayNameItem.getValue());
        labelList.add(label);
    }

    private static TagValueType mapTagValueType(TagType tagType) {

        TagValueType result = null;
        switch (tagType) {
        case BOOLEAN:
            result = TagValueType.BOOLEAN;
            break;
        case INTEGER:
            result = TagValueType.INT;
            break;
        case TIMESTAMP:
            result = TagValueType.DATE;
            break;
        case CHOICELIST:
            result = TagValueType.CHOICELIST;
            break;
        case STRING:
        default:
            result = TagValueType.STRING;
            break;
        }
        return result;
    }

}
