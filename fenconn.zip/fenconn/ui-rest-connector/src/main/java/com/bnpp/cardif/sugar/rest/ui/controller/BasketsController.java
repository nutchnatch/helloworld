package com.bnpp.cardif.sugar.rest.ui.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BasketsService;
import com.bnpp.cardif.sugar.frontend.services.TasksService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpp.cardif.sugar.rest.ui.api.BasketsApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.BasketConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.TaskConverter;
import com.bnpp.cardif.sugar.rest.ui.model.Basket;
import com.bnpp.cardif.sugar.rest.ui.model.Paging;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Task;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class BasketsController extends FrontendController implements BasketsApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(BasketsController.class);

    @Autowired
    BasketsService basketsService;

    @Autowired
    TasksService tasksService;

    @RequestMapping(value = "/baskets/{basketId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Basket>> getBasketById(
            @ApiParam(value = "Basket Id", required = true) @PathVariable("basketId") String basketId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getBasketById called");
        RestResponse<Basket> restResponse = new RestResponse<>();
        try {
            com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket backendBasket = basketsService
                    .getBasketByID(basketId);
            // transform service result into JSON response
            Basket basket = null;
            if (backendBasket != null) {
                basket = BasketConverter.convert(backendBasket, getScope());
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<Basket> valueList = new ArrayList<>();
            valueList.add(basket);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getBasketById end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/baskets/{basketId}/tasks", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Task>> getTaskListFromBasket(
            @ApiParam(value = "Basket Id", required = true) @PathVariable("basketId") String basketId,
            @NotNull @Min(1) @ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue = "1") Integer pageNumber,
            @NotNull @Min(1) @Max(100) @ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue = "10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getTaskListFromBasket called");
        RestResponse<Task> restResponse = new RestResponse<>();
        try {
            @SuppressWarnings("squid:S2259")
            long maximum = pageSize.longValue();
            @SuppressWarnings("squid:S2259")
            long start = (pageNumber.longValue() - 1) * maximum;
            PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task> backendTaskList = tasksService
                    .getTaskListByBasket(basketId, start, maximum);
            // transform service result into JSON response
            List<Task> valueList = null;
            if (backendTaskList != null) {
                valueList = TaskConverter.convert(backendTaskList.getItemList());
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
            fillPaging(pageNumber, pageSize, restResponse, backendTaskList);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getTaskListFromBasket end");
        return ResponseEntity.ok(restResponse);
    }

    private void fillPaging(Integer pageNumber, Integer pageSize, RestResponse<Task> restResponse,
            PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task> backendTaskList) {

        Paging paging = new Paging();
        paging.setCurrentPage(pageNumber.longValue());
        long lpageSize = pageSize.longValue();
        paging.setPageSize(lpageSize);
        long totalItem = backendTaskList.getItemNumber();
        paging.setTotalItems(totalItem);
        Long totalPages = (totalItem + lpageSize - 1) / lpageSize;
        paging.setTotalPages(totalPages);
        restResponse.setPaging(paging);
    }

    @RequestMapping(value = "/baskets", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Basket>> getBaskets(
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getBasketById called");
        RestResponse<Basket> restResponse = new RestResponse<>();
        try {
            List<com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket> backendBasketList = basketsService
                    .getAllBasketList();
            // transform service result into JSON response
            List<Basket> valueList = new ArrayList<>();
            if (backendBasketList != null) {
                List<Basket> basketList = BasketConverter.convert(backendBasketList, getScope());
                valueList.addAll(basketList);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getBasketById end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/baskets", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<Basket>> createBasket(
            @ApiParam(value = "The Basket to create", required = true) @Valid @RequestBody Basket inputBasket,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("createBasket called");
        RestResponse<Basket> restResponse = new RestResponse<>();
        try {
            com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket inputBackendBasket = BasketConverter
                    .convert(inputBasket, getScope());
            com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket backendBasket = basketsService
                    .createBasket(inputBackendBasket);
            // transform service result into JSON response
            Basket basket = null;
            if (backendBasket != null) {
                basket = BasketConverter.convert(backendBasket, getScope());
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<Basket> valueList = new ArrayList<>();
            valueList.add(basket);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("createBasket end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/baskets/{basketId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<Basket>> updateBasket(
            @ApiParam(value = "Basket Id", required = true) @PathVariable("basketId") String basketId,
            @ApiParam(value = "The Basket to update", required = true) @Valid @RequestBody Basket inputBasket,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateBasket called");
        RestResponse<Basket> restResponse = new RestResponse<>();
        try {
            com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket inputBackendBasket = BasketConverter
                    .convert(inputBasket, getScope());
            com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket backendBasket = basketsService
                    .updateBasket(inputBackendBasket);
            // transform service result into JSON response
            Basket basket = null;
            if (backendBasket != null) {
                basket = BasketConverter.convert(backendBasket, getScope());
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<Basket> valueList = new ArrayList<>();
            valueList.add(basket);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateBasket end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/baskets/{basketId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.DELETE)
    public ResponseEntity<RestResponse<String>> deleteBasket(
            @ApiParam(value = "Basket Id", required = true) @PathVariable("basketId") String basketId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateBasket called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            basketsService.deleteBasket(basketId);
            List<String> valueList = new ArrayList<>();
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateBasket end");
        return ResponseEntity.ok(restResponse);
    }

}
