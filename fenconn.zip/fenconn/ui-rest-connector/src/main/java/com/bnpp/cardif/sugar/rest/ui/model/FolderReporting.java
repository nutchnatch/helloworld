package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class FolderReporting implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @JsonProperty("classId")
    private String classId = null;

    @JsonProperty("classVersion")
    private long classVersion = 0;

    @JsonProperty("numberOfFolders")
    private long numberOfFolders = 0;

    public FolderReporting classId(String classId) {
        this.classId = classId;
        return this;
    }

    /**
     * Identifier of the folder class.
     * 
     * @return classId
     **/
    @ApiModelProperty(required = true, value = "Identifier of the folder class.")
    @NotNull
    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public FolderReporting classVersion(long classVersion) {
        this.classVersion = classVersion;
        return this;
    }

    /**
     * Version of the folder class.
     * 
     * @return classVersion
     **/
    @ApiModelProperty(required = true, value = "Version of the folder class.")
    @NotNull
    public long getClassVersion() {
        return classVersion;
    }

    public void setClassVersion(long classVersion) {
        this.classVersion = classVersion;
    }

    public FolderReporting numberOfFolders(long numberOfFolders) {
        this.numberOfFolders = numberOfFolders;
        return this;
    }

    /**
     * Number of folder of the related class.
     * 
     * @return numberOfFolders
     **/
    @ApiModelProperty(required = true, value = "Number of folder of the related class.")
    @NotNull
    public long getNumberOfFolders() {
        return numberOfFolders;
    }

    public void setNumberOfFolders(long numberOfFolders) {
        this.numberOfFolders = numberOfFolders;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((classId == null) ? 0 : classId.hashCode());
        result = prime * result + (int) (classVersion ^ (classVersion >>> 32));
        result = prime * result + (int) (numberOfFolders ^ (numberOfFolders >>> 32));
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof FolderReporting))
            return false;
        FolderReporting other = (FolderReporting) obj;
        if (classId == null) {
            if (other.classId != null)
                return false;
        }
        else if (!classId.equals(other.classId))
            return false;
        if (classVersion != other.classVersion)
            return false;
        if (numberOfFolders != other.numberOfFolders)
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("FolderReporting [classId=");
        builder.append(classId);
        builder.append(", classVersion=");
        builder.append(classVersion);
        builder.append(", numberOfFolders=");
        builder.append(numberOfFolders);
        builder.append("]");
        return builder.toString();
    }

}
