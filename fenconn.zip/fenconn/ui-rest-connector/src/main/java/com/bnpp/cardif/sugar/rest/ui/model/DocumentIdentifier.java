package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class DocumentIdentifier implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("docViewURL")
    private String docViewURL = null;

    public DocumentIdentifier id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Document identification
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Document identification")
    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public DocumentIdentifier name(String name) {
        this.name = name;
        return this;
    }

    /**
     * The name of the document.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "The name of the document.")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DocumentIdentifier docViewURL(String docViewURL) {
        this.docViewURL = docViewURL;
        return this;
    }

    /**
     * The document view URL of the document.
     * 
     * @return docViewURL
     **/
    @ApiModelProperty(required = true, value = "The document view URL of the document.")
    @NotNull
    public String getDocViewURL() {
        return docViewURL;
    }

    public void setDocViewURL(String docViewURL) {
        this.docViewURL = docViewURL;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((docViewURL == null) ? 0 : docViewURL.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof DocumentIdentifier))
            return false;
        DocumentIdentifier other = (DocumentIdentifier) obj;
        if (docViewURL == null) {
            if (other.docViewURL != null)
                return false;
        }
        else if (!docViewURL.equals(other.docViewURL))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        }
        else if (!id.equals(other.id))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        }
        else if (!name.equals(other.name))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DocumentIdentifier [id=");
        builder.append(id);
        builder.append(", name=");
        builder.append(name);
        builder.append(", docViewURL=");
        builder.append(docViewURL);
        builder.append("]");
        return builder.toString();
    }

}
