package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Represents the dysplay name Items, usualy a languange and a type.
 */
@ApiModel(description = "Represents the display name Items, usualy a languange and a type.")
public class DisplayNameItem implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("language")
    private String language = null;

    @JsonProperty("value")
    private String value = null;

    public DisplayNameItem language(String language) {
        this.language = language;
        return this;
    }

    /**
     * Language in which the value is written
     * 
     * @return language
     **/
    @ApiModelProperty(value = "Language in which the value is written")

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public DisplayNameItem value(String value) {
        this.value = value;
        return this;
    }

    /**
     * Value written with the associated language
     * 
     * @return value
     **/
    @ApiModelProperty(value = "Value written with the associated language")

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((language == null) ? 0 : language.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof DisplayNameItem))
            return false;
        DisplayNameItem other = (DisplayNameItem) obj;
        if (language == null) {
            if (other.language != null)
                return false;
        }
        else if (!language.equals(other.language))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        }
        else if (!value.equals(other.value))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DisplayNameItem [language=");
        builder.append(language);
        builder.append(", value=");
        builder.append(value);
        builder.append("]");
        return builder.toString();
    }

}
