package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.bnpp.cardif.sugar.rest.ui.model.AssociatedTag;
import com.bnpp.cardif.sugar.rest.ui.model.DisplayNameItem;
import com.bnpp.cardif.sugar.rest.ui.model.FolderType;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;

/**
 * 
 * @author 831743
 *
 */
public class FolderTypeConverter {

    protected static final String ISSUER = "CARDIF";

    /**
     * private empty constructor
     */
    private FolderTypeConverter() {
        // private constructor to avoid instance creation.
    }

    public static FolderType convert(FolderClass folderClass) {
        FolderType result = null;
        if (folderClass != null) {
            result = new FolderType();
            convertVersionData(folderClass, result);
            result.setName(folderClass.getLongLabel());
            result.setType(folderClass.getType());
            result.setActive(folderClass.isActive());
            DurationType durationType = folderClass.getRetentionDuration();
            if (durationType != null) {
                result.setRetentionDurationUnit(durationType.getTimeUnit());
                result.setRetentionDurationValue(durationType.getValue().intValue());
            }
            convertLabelList(folderClass, result);
            convertTagList(folderClass, result);
        }
        return result;
    }

    private static void convertTagList(FolderClass folderClass, FolderType result) {
        List<MCOTagReference> backendTagList = folderClass.getTagReference();
        List<AssociatedTag> tagList = result.getTagList();
        if (tagList == null) {
            tagList = new ArrayList<>();
        }
        if (backendTagList != null) {
            for (MCOTagReference backendTag : backendTagList) {
                AssociatedTag associatedTag = new AssociatedTag();
                associatedTag.setSymbolicName(backendTag.getSymbolicName());
                associatedTag.setMandatory(backendTag.isMandatory());
                associatedTag.setMultivalued(backendTag.isMultivalued());
                tagList.add(associatedTag);
            }
        }
    }

    private static void convertLabelList(FolderClass folderClass, FolderType result) {
        List<MCOI18NLabel> backendLabelList = folderClass.getShortLabel();
        List<DisplayNameItem> labelList = result.getDisplayNameList();
        if (labelList == null) {
            labelList = new ArrayList<>();
        }
        if (backendLabelList != null) {
            for (MCOI18NLabel backendLabel : backendLabelList) {
                DisplayNameItem label = new DisplayNameItem();
                label.setLanguage(backendLabel.getLanguage());
                label.setValue(backendLabel.getValue());
                labelList.add(label);
            }
        }
    }

    private static void convertVersionData(FolderClass folderClass, FolderType result) {
        ClassId classId = folderClass.getClassId();
        if (classId != null) {
            result.setId(classId.getValue());
            result.setVersion(classId.getVersId());
        }
    }

    public static List<FolderType> convert(List<FolderClass> documentClassList) {

        List<FolderType> result = new ArrayList<>();
        if (documentClassList != null) {
            for (FolderClass documentClass : documentClassList) {
                FolderType content = FolderTypeConverter.convert(documentClass);
                result.add(content);
            }
        }
        return result;
    }

    public static FolderClass convert(FolderType folderType, String scope) {

        FolderClass result = null;
        if (folderType != null) {
            result = new FolderClass();
            result.setActive(folderType.getActive());
            ClassId classId = new ClassId(folderType.getId(), ISSUER, folderType.getVersion());
            result.setClassId(classId);
            result.setLongLabel(folderType.getName());
            DurationType retentionDuration = new DurationType(
                    BigInteger.valueOf(folderType.getRetentionDurationValue()), folderType.getRetentionDurationUnit());
            result.setRetentionDuration(retentionDuration);
            result.setScope(scope);
            result.setType(folderType.getType());
            setTagList(folderType, result);
            setLabelList(folderType, result);
        }
        return result;
    }

    private static void setTagList(FolderType folderType, FolderClass result) {
        List<MCOTagReference> tagList = result.getTagReference();
        List<AssociatedTag> associatedTagList = folderType.getTagList();
        if (associatedTagList != null) {
            for (AssociatedTag associatedTag : associatedTagList) {
                MCOTagReference content = new MCOTagReference(associatedTag.getSymbolicName(),
                        associatedTag.getMandatory(), associatedTag.getMultivalued());
                tagList.add(content);
            }
        }
    }

    private static void setLabelList(FolderType folderType, FolderClass result) {
        List<MCOI18NLabel> labelList = result.getShortLabel();
        List<DisplayNameItem> displayNameList = folderType.getDisplayNameList();
        if (displayNameList != null) {
            for (DisplayNameItem displayNameItem : displayNameList) {
                MCOI18NLabel label = new MCOI18NLabel(displayNameItem.getValue(), displayNameItem.getLanguage());
                labelList.add(label);
            }
        }
    }
}
