package com.bnpp.cardif.sugar.rest.ui.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.ReportingService;
import com.bnpp.cardif.sugar.rest.ui.api.ReportingApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.ReportingConverter;
import com.bnpp.cardif.sugar.rest.ui.model.BasketReporting;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentReporting;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeReporting;
import com.bnpp.cardif.sugar.rest.ui.model.FolderReporting;
import com.bnpp.cardif.sugar.rest.ui.model.ReportingSummary;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class ReportingController extends FrontendController implements ReportingApi {

    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportingController.class);

    @Autowired
    ReportingService reportingService;

    @RequestMapping(value = "/reporting/baskets", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<BasketReporting>> getBasketReporting(
            @ApiParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "startDate", required = true) LocalDate startDate,
            @ApiParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "endDate", required = true) LocalDate endDate,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getBasketReporting called");
        RestResponse<BasketReporting> restResponse = new RestResponse<>();
        try {
            validateInput(startDate, endDate);

            String startingDate = startDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            String endingDate = endDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            // call service
            List<BasketRatio> result = reportingService.getBasketRatioIndicators(startingDate, endingDate);
            // transform service result into JSON response
            List<BasketReporting> basketReportingList = new ArrayList<>();
            if (result != null) {
                basketReportingList = ReportingConverter.convert(result);
            }
            restResponse.setResult(basketReportingList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getBasketReporting end");
        return ResponseEntity.ok(restResponse);
    }

    private void validateInput(LocalDate startDate, LocalDate endDate) throws InvalidInputException {
        if (startDate == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "startDate");
        }
        if (endDate == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "endDate");
        }
    }

    @RequestMapping(value = "/reporting/document", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<DocumentReporting>> getDocumentReporting(
            @ApiParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "startDate", required = true) LocalDate startDate,
            @ApiParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "endDate", required = true) LocalDate endDate,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getDocumentReporting called");
        RestResponse<DocumentReporting> restResponse = new RestResponse<>();
        try {
            validateInput(startDate, endDate);

            String startingDate = startDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            String endingDate = endDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            // call service
            List<DocumentStock> result = reportingService.getDocumentStockIndicators(startingDate, endingDate);
            // transform service result into JSON response
            List<DocumentReporting> documentReportingList = new ArrayList<>();
            if (result != null) {
                documentReportingList = ReportingConverter.convertDoc(result);
            }
            restResponse.setResult(documentReportingList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getDocumentReporting end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/reporting/envelope", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<EnvelopeReporting>> getEnvelopeReporting(
            @ApiParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "startDate", required = true) LocalDate startDate,
            @ApiParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "endDate", required = true) LocalDate endDate,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getEnvelopeReporting called");
        RestResponse<EnvelopeReporting> restResponse = new RestResponse<>();
        try {
            validateInput(startDate, endDate);

            String startingDate = startDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            String endingDate = endDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            // call service
            List<EnvelopeFlows> result = reportingService.getEnvelopeFlowsIndicators(startingDate, endingDate);
            // transform service result into JSON response
            List<EnvelopeReporting> envelopeReportingList = new ArrayList<>();
            if (result != null) {
                envelopeReportingList = ReportingConverter.convertEnv(result);
            }
            restResponse.setResult(envelopeReportingList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getEnvelopeReporting end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/reporting/folder", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<FolderReporting>> getFolderReporting(
            @ApiParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "startDate", required = true) LocalDate startDate,
            @ApiParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "endDate", required = true) LocalDate endDate,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getFolderReporting called");
        RestResponse<FolderReporting> restResponse = new RestResponse<>();
        try {
            validateInput(startDate, endDate);

            String startingDate = startDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            String endingDate = endDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            // call service
            List<FolderStock> result = reportingService.getFolderStockIndicators(startingDate, endingDate);
            // transform service result into JSON response
            List<FolderReporting> envelopeReportingList = new ArrayList<>();
            if (result != null) {
                envelopeReportingList = ReportingConverter.convertFolder(result);
            }
            restResponse.setResult(envelopeReportingList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getFolderReporting end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/reporting/summary", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<ReportingSummary>> getReportingSummary(
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getReportingSummary called");
        RestResponse<ReportingSummary> restResponse = new RestResponse<>();
        try {
            // call service
            Summary result = reportingService.getReportingSummary();
            // transform service result into JSON response
            List<ReportingSummary> reportingSummaryList = new ArrayList<>();
            if (result != null) {
                ReportingSummary content = ReportingConverter.convertSummary(result);
                reportingSummaryList.add(content);
            }
            restResponse.setResult(reportingSummaryList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getReportingSummary end");
        return ResponseEntity.ok(restResponse);
    }

}
