package com.bnpp.cardif.sugar.rest.ui.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpp.cardif.sugar.rest.ui.api.DocumentTypesApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.AclConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.DocumentTypeConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.TagConverter;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentType;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpp.cardif.sugar.utils.CollectionUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class DocumentTypesController extends FrontendController implements DocumentTypesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentTypesController.class);

    @Autowired
    DocumentTypeService documentTypeService;

    @Autowired
    AclService aclService;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.rest.ui.api.DocumentTypesApi#getDocumentTypeById(
     * java.lang.String, java.lang.Integer, java.lang.String, java.lang.String,
     * java.lang.String)
     */
    @RequestMapping(value = "/document-types/{documentTypeId}/{documentTypeVersion}", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<DocumentType>> getDocumentTypeById(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            @ApiParam(value = "Document type Version.", required = true) @PathVariable("documentTypeVersion") Integer documentTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getDocumentTypeById called");
        RestResponse<DocumentType> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputDocumentTypeById(documentTypeId, documentTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = documentTypeVersion.intValue();
            // call service
            DocumentClass result = documentTypeService.getDocumentTypeByID(documentTypeId, version);
            // transform service result into JSON response
            DocumentType documentType = null;
            if (result != null) {
                documentType = DocumentTypeConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<DocumentType> valueList = new ArrayList<>();
            valueList.add(documentType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getDocumentTypeById end");
        return ResponseEntity.ok(restResponse);
    }

    private void validateInputDocumentTypeById(String documentTypeId, Integer documentTypeVersion)
            throws InvalidInputException {
        List<String> missingInputs = new ArrayList<>();
        if (documentTypeId == null || documentTypeId.isEmpty()) {
            missingInputs.add("documentTypeId");
        }
        if (documentTypeVersion == null) {
            missingInputs.add("documentTypeVersion");
        }
        if (!missingInputs.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + CollectionUtils.collectionToString(missingInputs));
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.rest.ui.api.DocumentTypesApi#getDocumentTypes(java.
     * lang.String, java.lang.String, java.lang.String)
     */
    @RequestMapping(value = "/document-types", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<DocumentType>> getDocumentTypes(
            @ApiParam(value = "Includes inactive ones ?", required = false, defaultValue = "false") @RequestParam(value = "inactive", required = false, defaultValue = "false") boolean inactive,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getDocumentTypes called");
        RestResponse<DocumentType> restResponse = new RestResponse<>();
        try {
            // call service
            List<DocumentClass> result = null;
            if (inactive) {
                result = documentTypeService.getAllDocumentTypeWithInactives();
            }
            else {
                result = documentTypeService.getAllDocumentType();
            }
            // transform service result into JSON response
            List<DocumentType> documentTypeList = new ArrayList<>();
            if (result != null) {
                documentTypeList = DocumentTypeConverter.convert(result);
            }
            restResponse.setResult(documentTypeList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getDocumentTypes end");
        return ResponseEntity.ok(restResponse);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.rest.ui.api.DocumentTypesApi#searchDocumentTags(
     * java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @RequestMapping(value = "/document-types/{documentTypeId}/{documentTypeVersion}/tags", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Tag>> searchDocumentTags(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            @ApiParam(value = "Document type Version.", required = true) @PathVariable("documentTypeVersion") Integer documentTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("searchDocumentTags called");
        RestResponse<Tag> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputDocumentTypeById(documentTypeId, documentTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = documentTypeVersion.intValue();
            // call service
            List<TagClass> result = documentTypeService.getDocumentTypeTags(documentTypeId, version);
            // transform service result into JSON response
            List<Tag> valueList = TagConverter.convert(result);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("searchDocumentTags end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/document-types", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<DocumentType>> createDocumentType(
            @ApiParam(value = "The DocumentType to create", required = true) @Valid @RequestBody DocumentType inputDocumentType,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("createDocumentType called");
        RestResponse<DocumentType> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputDocumentType == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "documentType");
            }
            DocumentClass input = DocumentTypeConverter.convert(inputDocumentType, getScope());
            // call service
            DocumentClass result = documentTypeService.createDocumentType(input);
            // transform service result into JSON response
            DocumentType documentType = null;
            if (result != null) {
                documentType = DocumentTypeConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<DocumentType> valueList = new ArrayList<>();
            valueList.add(documentType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("createDocumentType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/document-types/{documentTypeId}/{documentTypeVersion}", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<DocumentType>> updateDocumentType(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            @ApiParam(value = "Document type Version.", required = true) @PathVariable("documentTypeVersion") Integer documentTypeVersion,
            @ApiParam(value = "The DocumentType to create", required = true) @Valid @RequestBody DocumentType inputDocumentType,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateDocumentType called");
        RestResponse<DocumentType> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputDocumentType == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "documentType");
            }
            DocumentClass input = DocumentTypeConverter.convert(inputDocumentType, getScope());
            // call service
            DocumentClass result = documentTypeService.updateDocumentType(input);
            // transform service result into JSON response
            DocumentType documentType = null;
            if (result != null) {
                documentType = DocumentTypeConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<DocumentType> valueList = new ArrayList<>();
            valueList.add(documentType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateDocumentType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/document-types/{documentTypeId}/{documentTypeVersion}/activate", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> activateDocumentType(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            @ApiParam(value = "Document type Version.", required = true) @PathVariable("documentTypeVersion") Integer documentTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("activateDocumentType called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputDocumentTypeById(documentTypeId, documentTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = documentTypeVersion.intValue();
            // call service
            documentTypeService.activateDocumentType(documentTypeId, version);
            List<String> valueList = new ArrayList<>();
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("activateDocumentType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/document-types/{documentTypeId}/{documentTypeVersion}/deactivate", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> deactivateDocumentType(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            @ApiParam(value = "Document type Version.", required = true) @PathVariable("documentTypeVersion") Integer documentTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("deactivateDocumentType called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputDocumentTypeById(documentTypeId, documentTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = documentTypeVersion.intValue();
            // call service
            documentTypeService.deactivateDocumentType(documentTypeId, version);
            List<String> valueList = new ArrayList<>();
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("deactivateDocumentType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/document-types/{documentTypeId}/{documentTypeVersion}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Acl>> getDocumentTypeAcl(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            @ApiParam(value = "Document type Version.", required = true) @PathVariable("documentTypeVersion") Integer documentTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getDocumentTypeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputDocumentTypeById(documentTypeId, documentTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = documentTypeVersion.intValue();
            // call service
            AccessControlList instanceAcl = aclService.getAclListByClassId(documentTypeId, version, true);
            AccessControlList classAcl = aclService.getAclListByClassId(documentTypeId, version, false);
            // transform service result into JSON response
            List<Acl> valueList = AclConverter.convert(instanceAcl, classAcl);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getDocumentTypeAcl end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/document-types/{documentTypeId}/{documentTypeVersion}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = { "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<Acl>> assignDocumentTypeAcl(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            @ApiParam(value = "Document type Version.", required = true) @PathVariable("documentTypeVersion") Integer documentTypeVersion,
            @ApiParam(value = "The Acl to assign", required = true) @Valid @RequestBody Acl inputAcl,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("assignDocumentTypeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputDocumentTypeById(documentTypeId, documentTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = documentTypeVersion.intValue();
            // call service
            AccessControlList result = aclService.assignAclToClassId(inputAcl.getAclId(), documentTypeId,
                    version, inputAcl.getIsInstanceValue());
            // transform service result into JSON response
            List<Acl> valueList = new ArrayList<>();
            if (result != null) {
                Acl assignedAcl = AclConverter.convert(result, inputAcl.getIsInstanceValue());
                valueList.add(assignedAcl);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("assignDocumentTypeAcl end");
        return ResponseEntity.ok(restResponse);
    }

}
