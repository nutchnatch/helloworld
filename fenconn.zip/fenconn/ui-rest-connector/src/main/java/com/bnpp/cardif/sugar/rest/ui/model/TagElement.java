package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Represents a configured tag with the respective value.
 */
@ApiModel(description = "Represents a configured tag with the respective value.")
public class TagElement implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("tagName")
    private String tagName = null;

    @JsonProperty("tagValue")
    private String tagValue = null;

    public TagElement tagName(String tagName) {
        this.tagName = tagName;
        return this;
    }

    /**
     * Get tagName
     * 
     * @return tagName
     **/
    @ApiModelProperty(value = "Symbolic name of the tag")
    @NotNull
    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public TagElement tagValue(String tagValue) {
        this.tagValue = tagValue;
        return this;
    }

    /**
     * Value of the tag.
     * 
     * @return tagValue
     **/
    @ApiModelProperty(required = true, value = "Value of the tag.")
    public String getTagValue() {
        return tagValue;
    }

    public void setTagValue(String tagValue) {
        this.tagValue = tagValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((tagName == null) ? 0 : tagName.hashCode());
        result = prime * result + ((tagValue == null) ? 0 : tagValue.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof TagElement))
            return false;
        TagElement other = (TagElement) obj;
        if (tagName == null) {
            if (other.tagName != null)
                return false;
        }
        else if (!tagName.equals(other.tagName))
            return false;
        if (tagValue == null) {
            if (other.tagValue != null)
                return false;
        }
        else if (!tagValue.equals(other.tagValue))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("TagElement [tagName=");
        builder.append(tagName);
        builder.append(", tagValue=");
        builder.append(tagValue);
        builder.append("]");
        return builder.toString();
    }

}
