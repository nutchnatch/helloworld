package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Represents a Basket.
 */
@ApiModel(description = "Represents a Basket.")
public class Basket implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("basketId")
    private String basketId = null;

    @JsonProperty("displayNameItem")
    private List<DisplayNameItem> displayNameItem = new ArrayList<>();

    @JsonProperty("symbolicName")
    private String symbolicName = null;

    @JsonProperty("scope")
    private String scope = null;

    public Basket basketId(String basketId) {
        this.basketId = basketId;
        return this;
    }

    /**
     * Get basketId
     * 
     * @return basketId
     **/
    @ApiModelProperty(required = true, value = "")
    public String getBasketId() {
        return basketId;
    }

    public void setBasketId(String basketId) {
        this.basketId = basketId;
    }

    public Basket displayNameItem(List<DisplayNameItem> displayNameItem) {
        this.displayNameItem = displayNameItem;
        return this;
    }

    public Basket addDisplayNameItemItem(DisplayNameItem displayNameItemItem) {
        if (this.displayNameItem == null) {
            this.displayNameItem = new ArrayList<>();
        }
        this.displayNameItem.add(displayNameItemItem);
        return this;
    }

    /**
     * Describe the language and its associated value.
     * 
     * @return displayNameItem
     **/
    @ApiModelProperty(value = "Describe the language and its associated value.")
    @Valid
    public List<DisplayNameItem> getDisplayNameItem() {
        return displayNameItem;
    }

    public void setDisplayNameItem(List<DisplayNameItem> displayNameItem) {
        this.displayNameItem = displayNameItem;
    }

    public Basket symbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
        return this;
    }

    /**
     * Symbolic Name
     * 
     * @return symbolicName
     **/
    @ApiModelProperty(value = "Symbolic Name")
    public String getSymbolicName() {
        return symbolicName;
    }

    public void setSymbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
    }

    public Basket scope(String scope) {
        this.scope = scope;
        return this;
    }

    /**
     * Scope
     * 
     * @return scope
     **/
    @ApiModelProperty(value = "Scope")
    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((basketId == null) ? 0 : basketId.hashCode());
        result = prime * result + ((displayNameItem == null) ? 0 : displayNameItem.hashCode());
        result = prime * result + ((scope == null) ? 0 : scope.hashCode());
        result = prime * result + ((symbolicName == null) ? 0 : symbolicName.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Basket))
            return false;
        Basket other = (Basket) obj;
        if (basketId == null) {
            if (other.basketId != null)
                return false;
        }
        else if (!basketId.equals(other.basketId))
            return false;
        if (displayNameItem == null) {
            if (other.displayNameItem != null)
                return false;
        }
        else if (!displayNameItem.equals(other.displayNameItem))
            return false;
        if (scope == null) {
            if (other.scope != null)
                return false;
        }
        else if (!scope.equals(other.scope))
            return false;
        if (symbolicName == null) {
            if (other.symbolicName != null)
                return false;
        }
        else if (!symbolicName.equals(other.symbolicName))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Basket [basketId=");
        builder.append(basketId);
        builder.append(", displayNameItem=");
        builder.append(displayNameItem);
        builder.append(", symbolicName=");
        builder.append(symbolicName);
        builder.append(", scope=");
        builder.append(scope);
        builder.append("]");
        return builder.toString();
    }

}
