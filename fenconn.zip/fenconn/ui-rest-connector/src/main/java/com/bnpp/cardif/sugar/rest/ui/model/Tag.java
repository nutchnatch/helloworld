package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Tag
 */
public class Tag implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("type")
    private TagType type = null;

    @JsonProperty("isSearchable")
    private boolean isSearchable;

    @JsonProperty("pattern")
    private String pattern;

    @JsonProperty("diplayNameItem")
    private List<DisplayNameItem> diplayNameItem = new ArrayList<>();

    @JsonProperty("choicelist")
    private List<AllowableTagValue> choicelist = new ArrayList<>();

    public Tag id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Identification of the Tag
     * 
     * @return id
     **/
    @ApiModelProperty(required = false, value = "Identification of the Tag.")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Tag name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Unique name (ID)
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Unique name (ID)")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Tag type(TagType type) {
        this.type = type;
        return this;
    }

    /**
     * Type of the tag (string, integer, date, choicelist, ...)
     * 
     * @return type
     **/
    @ApiModelProperty(required = true, value = "Type of the tag", allowableValues = "string, timestamp, boolean, integer, choicelist")
    @NotNull
    public TagType getType() {
        return type;
    }

    public void setType(TagType type) {
        this.type = type;
    }

    public Tag isSearchable(boolean isSearchable) {
        this.isSearchable = isSearchable;
        return this;
    }

    /**
     * Indicates if the tag can be searched or not.
     * 
     * @return isSearchable
     **/
    @ApiModelProperty(required = true, value = "Indicates if the tag can be searched or not.")
    @NotNull
    public boolean getIsSearchable() {
        return isSearchable;
    }

    public void setIsSearchable(boolean isSearchable) {
        this.isSearchable = isSearchable;
    }

    public Tag pattern(String pattern) {
        this.pattern = pattern;
        return this;
    }

    /**
     * Regexp pattern in case of a string type.
     * 
     * @return pattern
     **/
    @ApiModelProperty(required = false, value = "Regexp pattern in case of a string type.")
    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public Tag diplayNameItem(List<DisplayNameItem> diplayNameItem) {
        this.diplayNameItem = diplayNameItem;
        return this;
    }

    public Tag addDiplayNameItemItem(DisplayNameItem diplayNameItemItem) {
        if (this.diplayNameItem == null) {
            this.diplayNameItem = new ArrayList<>();
        }
        this.diplayNameItem.add(diplayNameItemItem);
        return this;
    }

    /**
     * Get diplayNameItem
     * 
     * @return diplayNameItem
     **/
    @ApiModelProperty(value = "")

    @Valid

    public List<DisplayNameItem> getDiplayNameItem() {
        return diplayNameItem;
    }

    public void setDiplayNameItem(List<DisplayNameItem> diplayNameItem) {
        this.diplayNameItem = diplayNameItem;
    }

    public Tag choicelist(List<AllowableTagValue> choicelist) {
        this.choicelist = choicelist;
        return this;
    }

    public Tag addChoicelistItem(AllowableTagValue choicelistItem) {
        if (this.choicelist == null) {
            this.choicelist = new ArrayList<>();
        }
        this.choicelist.add(choicelistItem);
        return this;
    }

    /**
     * Optional attribute, used when type selected is choice list.
     * 
     * @return choicelist
     **/
    @ApiModelProperty(value = "Optional attribute, used when type selected is choice list.")

    @Valid

    public List<AllowableTagValue> getChoicelist() {
        return choicelist;
    }

    public void setChoicelist(List<AllowableTagValue> choicelist) {
        this.choicelist = choicelist;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((choicelist == null) ? 0 : choicelist.hashCode());
        result = prime * result + ((diplayNameItem == null) ? 0 : diplayNameItem.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + (isSearchable ? 1231 : 1237);
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((pattern == null) ? 0 : pattern.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Tag))
            return false;
        Tag other = (Tag) obj;
        if (choicelist == null) {
            if (other.choicelist != null)
                return false;
        }
        else if (!choicelist.equals(other.choicelist))
            return false;
        if (diplayNameItem == null) {
            if (other.diplayNameItem != null)
                return false;
        }
        else if (!diplayNameItem.equals(other.diplayNameItem))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        }
        else if (!id.equals(other.id))
            return false;
        if (isSearchable != other.isSearchable)
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        }
        else if (!name.equals(other.name))
            return false;
        if (pattern == null) {
            if (other.pattern != null)
                return false;
        }
        else if (!pattern.equals(other.pattern))
            return false;
        if (type != other.type)
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Tag [id=");
        builder.append(id);
        builder.append(", name=");
        builder.append(name);
        builder.append(", type=");
        builder.append(type);
        builder.append(", isSearchable=");
        builder.append(isSearchable);
        builder.append(", pattern=");
        builder.append(pattern);
        builder.append(", diplayNameItem=");
        builder.append(diplayNameItem);
        builder.append(", choicelist=");
        builder.append(choicelist);
        builder.append("]");
        return builder.toString();
    }

}
