package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Folder
 */
public class Folder implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("owner")
    private String owner = null;

    @JsonProperty("status")
    private String status = null;

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("lastUpdateDate")
    private ZonedDateTime lastUpdateDate = null;

    @JsonProperty("retentionDate")
    private LocalDate retentionDate = null;

    @JsonProperty("folderTypeId")
    private String folderTypeId = null;

    @JsonProperty("folderTypeVersion")
    private int folderTypeVersion;

    @JsonProperty("listOfDocumentId")
    private List<DocumentIdentifier> listOfDocumentId = new ArrayList<>();

    @JsonProperty("tagList")
    private List<TagElement> tagList = new ArrayList<>();

    public Folder id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Folder identification.
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Folder identification.")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Folder name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Name of the Folder.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Name of the Folder.")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Folder owner(String owner) {
        this.owner = owner;
        return this;
    }

    /**
     * Owner of the Folder. On the folder creation, this field will be
     * automatically filled with the current user session id.
     * 
     * @return owner
     **/
    @ApiModelProperty(value = "Owner of the Folder. On the folder creation, this field will be automatically filled with the  current user session id.")
    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Folder status(String status) {
        this.status = status;
        return this;
    }

    /**
     * State of the Folder.
     * 
     * @return status
     **/
    @ApiModelProperty(value = "State of the Folder.")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Folder creationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    /**
     * When the Folder is created. On creation, this date will be filled with
     * the current date.
     * 
     * @return creationDate
     **/
    @ApiModelProperty(value = "When the Folder is created. On creation, this date will be filled with the current date.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public Folder lastUpdateDate(ZonedDateTime lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
        return this;
    }

    /**
     * Last date when the folder was updated.
     * 
     * @return lastUpdateDate
     **/
    @ApiModelProperty(value = "Last date when the folder was updated.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(ZonedDateTime lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public Folder retentionDate(LocalDate retentionDate) {
        this.retentionDate = retentionDate;
        return this;
    }

    /**
     * Date until when this folder can be kept stored.
     * 
     * @return retentionDate
     **/
    @ApiModelProperty(value = "Date until when this folder can be kept stored.")
    @Valid
    public LocalDate getRetentionDate() {
        return retentionDate;
    }

    public void setRetentionDate(LocalDate retentionDate) {
        this.retentionDate = retentionDate;
    }

    public Folder folderTypeId(String folderTypeId) {
        this.folderTypeId = folderTypeId;
        return this;
    }

    /**
     * Identification of the folder type selected. On creation of a document,
     * this field will be filled with a default value fetched from the folder
     * type.
     * 
     * @return folderTypeId
     **/
    @ApiModelProperty(value = "Identification of the folder type selected. On creation of a document, this field will be filled with a default value fetched from the folder type.")
    public String getFolderTypeId() {
        return folderTypeId;
    }

    public void setFolderTypeId(String folderTypeId) {
        this.folderTypeId = folderTypeId;
    }

    public Folder folderTypeVersion(int folderTypeVersion) {
        this.folderTypeVersion = folderTypeVersion;
        return this;
    }

    /**
     * Version of the folder type selected. On creation of a document, this
     * field will be filled with a default value fetched from the folder type.
     * 
     * @return folderTypeVersion
     **/
    @ApiModelProperty(value = "Version of the folder type selected. On creation of a document, this field will be filled with a default value fetched from the folder type.")
    public int getFolderTypeVersion() {
        return folderTypeVersion;
    }

    public void setFolderTypeVersion(int folderTypeVersion) {
        this.folderTypeVersion = folderTypeVersion;
    }

    public Folder listOfDocumentId(List<DocumentIdentifier> listOfDocumentId) {
        this.listOfDocumentId = listOfDocumentId;
        return this;
    }

    public Folder addListOfDocumentIdItem(DocumentIdentifier listOfDocumentIdItem) {
        if (this.listOfDocumentId == null) {
            this.listOfDocumentId = new ArrayList<>();
        }
        this.listOfDocumentId.add(listOfDocumentIdItem);
        return this;
    }

    /**
     * List of document identification.
     * 
     * @return listOfDocumentId
     **/
    @ApiModelProperty(value = "List of document identification.")
    public List<DocumentIdentifier> getListOfDocumentId() {
        return listOfDocumentId;
    }

    public void setListOfDocumentId(List<DocumentIdentifier> listOfDocumentId) {
        this.listOfDocumentId = listOfDocumentId;
    }

    public Folder tagList(List<TagElement> tagList) {
        this.tagList = tagList;
        return this;
    }

    public Folder addTagListItem(TagElement tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * Get tagList
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<TagElement> getTagList() {
        return tagList;
    }

    public void setTagList(List<TagElement> tagList) {
        this.tagList = tagList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
        result = prime * result + ((folderTypeId == null) ? 0 : folderTypeId.hashCode());
        result = prime * result + folderTypeVersion;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((lastUpdateDate == null) ? 0 : lastUpdateDate.hashCode());
        result = prime * result + ((listOfDocumentId == null) ? 0 : listOfDocumentId.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((owner == null) ? 0 : owner.hashCode());
        result = prime * result + ((retentionDate == null) ? 0 : retentionDate.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((tagList == null) ? 0 : tagList.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Folder))
            return false;
        Folder other = (Folder) obj;
        if (creationDate == null) {
            if (other.creationDate != null)
                return false;
        }
        else if (!creationDate.equals(other.creationDate))
            return false;
        if (folderTypeId == null) {
            if (other.folderTypeId != null)
                return false;
        }
        else if (!folderTypeId.equals(other.folderTypeId))
            return false;
        if (folderTypeVersion != other.folderTypeVersion)
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        }
        else if (!id.equals(other.id))
            return false;
        if (lastUpdateDate == null) {
            if (other.lastUpdateDate != null)
                return false;
        }
        else if (!lastUpdateDate.equals(other.lastUpdateDate))
            return false;
        if (listOfDocumentId == null) {
            if (other.listOfDocumentId != null)
                return false;
        }
        else if (!listOfDocumentId.equals(other.listOfDocumentId))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        }
        else if (!name.equals(other.name))
            return false;
        if (owner == null) {
            if (other.owner != null)
                return false;
        }
        else if (!owner.equals(other.owner))
            return false;
        if (retentionDate == null) {
            if (other.retentionDate != null)
                return false;
        }
        else if (!retentionDate.equals(other.retentionDate))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        }
        else if (!status.equals(other.status))
            return false;
        if (tagList == null) {
            if (other.tagList != null)
                return false;
        }
        else if (!tagList.equals(other.tagList))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Folder [id=");
        builder.append(id);
        builder.append(", name=");
        builder.append(name);
        builder.append(", owner=");
        builder.append(owner);
        builder.append(", status=");
        builder.append(status);
        builder.append(", creationDate=");
        builder.append(creationDate);
        builder.append(", lastUpdateDate=");
        builder.append(lastUpdateDate);
        builder.append(", retentionDate=");
        builder.append(retentionDate);
        builder.append(", folderTypeId=");
        builder.append(folderTypeId);
        builder.append(", folderTypeVersion=");
        builder.append(folderTypeVersion);
        builder.append(", listOfDocumentId=");
        builder.append(listOfDocumentId);
        builder.append(", tagList=");
        builder.append(tagList);
        builder.append("]");
        return builder.toString();
    }

}
