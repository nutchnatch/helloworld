package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

public class DocumentFileConverter {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentFileConverter.class);

    private static final String SUGAR_TMP_FILE = "SugarTmpFile";

    /**
     * private empty constructor
     */
    private DocumentFileConverter() {
        // private constructor to avoid instance creation.
    }

    public static DocumentFile convert(MultipartFile file, String scope) throws IOException {

        DocumentFile result = null;
        if (file != null) {
            result = new DocumentFile();
            result.setScope(scope);
            result.setName(file.getOriginalFilename());
            result.setFormatCode(file.getContentType());
            // set the binary content
            FileDataSource fileDataSource = DocumentFileConverter.createFileDataSource(file.getInputStream());
            result.setContent(new DataHandler(fileDataSource));
        }
        return result;
    }

    private static FileDataSource createFileDataSource(InputStream inputStream) throws IOException {

        File tmpFile = File.createTempFile(SUGAR_TMP_FILE, null);
        Files.copy(inputStream, tmpFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        return new FileDataSource(tmpFile);
    }

    public static List<DocumentFile> convert(List<MultipartFile> files, String scope) throws IOException {

        List<DocumentFile> result = new ArrayList<>();
        if (files != null) {
            // loop over the file list
            for (MultipartFile file : files) {
                if (file != null) {
                    result.add(DocumentFileConverter.convert(file, scope));
                }
            }
        }
        return result;
    }

}
