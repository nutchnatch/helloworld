package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.bnpp.cardif.sugar.rest.ui.model.Document;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentCreationResult;
import com.bnpp.cardif.sugar.rest.ui.model.Folder;
import com.bnpp.cardif.sugar.rest.ui.model.TagElement;
import com.bnpp.cardif.sugar.utils.DateUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ParentId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

/**
 * 
 * @author 831743
 *
 */
public class DocumentConverter {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentConverter.class);

    protected static final String ISSUER = "CARDIF";

    protected static final String SCHEME = "Sugar";

    /**
     * private empty constructor
     */
    private DocumentConverter() {
        // private constructor to avoid instance creation.
    }

    /**
     * Convert a backend document into a JSON Document
     * 
     * @param backendDoc
     *            com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document
     * @param token
     *            sesame token (used for rendering URL)
     * @param scope
     *            current business scope (used for rendering URL)
     * @return Document
     */
    public static Document convert(com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc,
            String scope, String token) {
        Document result = null;
        if (backendDoc != null) {
            result = new Document();
            // doc data
            ElectronicDocumentDataType docData = backendDoc.getData();
            convertDocumentData(result, docData);
            // file data
            FileData fileData = backendDoc.getFileData();
            convertFileData(fileData, result, scope, token);
            // parent data
            ParentId documentParent = backendDoc.getParentId();
            convertParentData(result, documentParent);
            // Id
            if (backendDoc.getId() != null) {
                result.setId(backendDoc.getId().getValue());
            }
            // tag list
            List<TagElement> tagList = new ArrayList<>();
            if (backendDoc.getTags() != null) {
                Tags documentTags = backendDoc.getTags();
                List<com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag> documentTagList = documentTags
                        .getTag();
                if (documentTagList != null && !documentTagList.isEmpty()) {
                    tagList = TagConverter.convertElement(documentTagList);
                }
            }
            result.setTagList(tagList);
        }
        return result;
    }

    @SuppressWarnings("squid:S1066")
    private static void convertParentData(Document result, ParentId documentParent) {
        if (documentParent != null) {
            if (documentParent.getId() != null) {
                result.setEnvelopeID(documentParent.getId().getValue());
            }
            // other data
        }
    }

    @SuppressWarnings("squid:S1066")
    private static void convertFileData(FileData fileData, Document result, String scope, String token) {
        if (fileData != null) {
            if (fileData.getURI() != null && !fileData.getURI().isEmpty()) {
                result.setDocFileID(fileData.getURI().get(0));
                result.setDocViewURL("/ARenderHMI/ARender.jsp?scope=" + scope + "&token=" + token + "&uri="
                        + fileData.getURI().get(0));
            }
            // If needed documentFile are here
        }
    }

    private static void convertDocumentData(Document result, ElectronicDocumentDataType docData) {
        if (docData != null) {
            result.setConfidentiality(docData.getConfdntltyLvl());
            if (docData.getCreatnDate() != null) {
                result.setCreationDate(DateUtils.asZonedDateTime(docData.getCreatnDate()));
            }
            if (docData.getClassId() != null) {
                result.setDocTypeId(docData.getClassId().getValue());
                result.setDocTypeVersion(docData.getClassId().getVersId());
            }
            result.setDirection(docData.getDirectionCode());
            if (docData.getValidityCode() != null) {
                result.setValidity(docData.getValidityCode().value());
            }
            result.setLanguage(docData.getLangCode());
            result.setName(docData.getName());
            if (docData.getRetentionEndDate() != null) {
                result.setRetentionEndDate(DateUtils.asLocalDate(docData.getRetentionEndDate()));
            }
            if (docData.getRetentionStartDate() != null) {
                result.setRetentionStartDate(DateUtils.asLocalDate(docData.getRetentionStartDate()));
            }
        }
    }

    /**
     * Convert a list of backend document into a List of JSON Document
     * 
     * @param backendDocList
     *            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document>
     * @param token
     * @param scope
     * @return List<Document>
     */
    public static List<Document> convert(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList, String scope,
            String token) {
        List<Document> result = new ArrayList<>();
        if (backendDocList != null && !backendDocList.isEmpty()) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc : backendDocList) {
                Document content = DocumentConverter.convert(backendDoc, scope, token);
                result.add(content);
            }
        }
        return result;
    }

    public static List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document>
            convert(List<Document> documentList, String scope) {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = new ArrayList<>();
        if (documentList != null) {
            for (Document document : documentList) {
                com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc = DocumentConverter
                        .convert(document, scope);
                result.add(backendDoc);
            }
        }
        return result;
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document convert(Document document,
            String scope) {

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = null;
        if (document != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document();
            result.setCategory(Category.DOCUMENT);
            ElectronicDocumentDataType docData = DocumentConverter.convertData(document);
            result.setData(docData);
            FileData fileData = DocumentConverter.convertFileData(document);
            result.setFileData(fileData);
            Id id = DocumentConverter.convertId(document);
            result.setId(id);
            ParentId parentid = DocumentConverter.convertParent(document);
            result.setParentId(parentid);
            result.setScope(scope);
            Tags docTags = DocumentConverter.convertTags(document);
            result.setTags(docTags);
        }
        return result;
    }

    private static Id convertId(Document document) {
        Id result = new Id();
        if (document != null) {
            result.setIssuer(ISSUER);
            result.setScheme(SCHEME);
            result.setValue(document.getId());
        }
        return result;
    }

    private static Tags convertTags(Document document) {

        List<Tag> backendTagList = new ArrayList<>();
        Tags result = new Tags(backendTagList);
        if (document != null && document.getTagList() != null) {

            List<TagElement> taglist = document.getTagList();
            for (TagElement tagElement : taglist) {
                Tag currentTag = new Tag();
                currentTag.setName(tagElement.getTagName());
                currentTag.setValue(tagElement.getTagValue());
                backendTagList.add(currentTag);
            }
        }
        return result;
    }

    private static ParentId convertParent(Document document) {

        ParentId result = new ParentId();
        if (document != null) {
            Id id = new Id();
            id.setIssuer(ISSUER);
            id.setScheme(SCHEME);
            id.setValue(document.getEnvelopeID());
            result.setId(id);
        }
        return result;
    }

    private static FileData convertFileData(Document document) {

        FileData result = new FileData();
        if (document != null && document.getDocFileID() != null) {
            List<String> uriList = result.getURI();
            uriList.add(document.getDocFileID());
        }
        return result;
    }

    private static ElectronicDocumentDataType convertData(Document document) {

        ElectronicDocumentDataType result = new ElectronicDocumentDataType();
        if (document != null) {
            result.setConfdntltyLvl(document.getConfidentiality());
            ClassId classId = new ClassId(document.getDocTypeId(), ISSUER, document.getDocTypeVersion());
            result.setClassId(classId);
            result.setDirectionCode(document.getDirection());
            result.setLangCode(document.getLanguage());
            result.setName(document.getName());
            LocalDate retentionEndDate = document.getRetentionEndDate();
            if (retentionEndDate != null) {
                result.setRetentionEndDate(DateUtils.asDate(retentionEndDate));
            }
            LocalDate retentionStartDate = document.getRetentionStartDate();
            if (retentionStartDate != null) {
                result.setRetentionStartDate(DateUtils.asDate(retentionStartDate));
            }
            result.setValidityCode(ValdtyCode.valueOf(document.getValidity()));
        }
        return result;
    }

    public static List<DocumentCreationResult> convertToDocumentCreationResult(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList) {

        List<DocumentCreationResult> result = new ArrayList<>();
        if (backendDocList != null && !backendDocList.isEmpty()) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc : backendDocList) {
                DocumentCreationResult content = DocumentConverter.convertToDocumentCreationResult(backendDoc);
                result.add(content);
            }
        }
        return result;
    }

    private static DocumentCreationResult convertToDocumentCreationResult(
            com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc) {

        DocumentCreationResult result = null;
        if (backendDoc != null && backendDoc.getId() != null) {
            result = new DocumentCreationResult();
            result.setDocumentId(backendDoc.getId().getValue());
            if (backendDoc.getParentId() != null && backendDoc.getParentId().getId() != null) {
                result.setEnvelopeId(backendDoc.getParentId().getId().getValue());
            }
        }
        return result;
    }

    public static Document addFolderListToDocument(Document document,
            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> backendFolderList, String scope,
            String token) {

        List<Folder> folderList = FolderConverter.convert(backendFolderList, scope, token);
        if (folderList != null) {
            document.setFolderList(folderList);
        }
        return document;
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document convert(MultipartFile file,
            String scope, DocumentClass defaultDocumentType) {

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = null;
        if (file != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document();
            result.setCategory(Category.DOCUMENT);
            ElectronicDocumentDataType docData = DocumentConverter.convertData(defaultDocumentType, file);
            result.setData(docData);
            result.setScope(scope);
        }
        return result;
    }

    private static ElectronicDocumentDataType convertData(DocumentClass defaultDocumentType, MultipartFile file) {

        ElectronicDocumentDataType result = new ElectronicDocumentDataType();
        if (defaultDocumentType != null) {
            ClassId classId = defaultDocumentType.getClassId();
            result.setClassId(classId);
            result.setName(file.getOriginalFilename());
            result.setCreatnDate(new Date());
            result.setSndngDate(new Date());
            result.setReciptDate(new Date());
            result.setUpdtDate(new Date());
            result.setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
        }
        return result;
    }

    public static List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document>
            convert(List<MultipartFile> fileList, String scope, DocumentClass defaultDocumentType) {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = new ArrayList<>();
        if (fileList != null) {
            // loop over the file list
            for (MultipartFile file : fileList) {
                if (file != null) {
                    com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document content = DocumentConverter
                            .convert(file, scope, defaultDocumentType);
                    result.add(content);
                }
            }
        }
        return result;
    }

}
