package com.bnpp.cardif.sugar.rest.ui.api;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bnpp.cardif.sugar.rest.ui.model.Basket;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Task;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;

@Path("/baskets")
@Api(value = "baskets")
@Produces({ "application/json; charset=UTF-8" })
public interface BasketsApi {

    /**
     * Retrieves a given Basket.
     * 
     * @param basketId
     * @return ResponseEntity<RestResponse<Basket>>
     */
    @ApiOperation(value = "Get Basket", notes = "Retrieves a given Basket.", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 400, message = "Bad Request.(400)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Unauthorized access.(401)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Forbidden access.(403)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "The specified resource was not found.(404)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Internal server error occurred.(500)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Service unavailable.(503)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Gateway timeout.(504)", response = RestResponse.class) })
    @RequestMapping(value = "/baskets/{basketId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    ResponseEntity<RestResponse<Basket>> getBasketById(
            @ApiParam(value = "Basket Id", required = true) @PathVariable("basketId") String basketId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId);

    /**
     * Retrieves a paginated list of tasks from basket.
     * 
     * @param basketId
     * @return ResponseEntity<RestResponse<Task>>
     */
    @ApiOperation(value = "Get tasks from basket", notes = "Retrieves a paginated list of tasks from basket.", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 400, message = "Bad Request.(400)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Unauthorized access.(401)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Forbidden access.(403)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "The specified resource was not found.(404)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Internal server error occurred.(500)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Service unavailable.(503)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Gateway timeout.(504)", response = RestResponse.class) })
    @RequestMapping(value = "/baskets/{basketId}/tasks", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Task>> getTaskListFromBasket(
            @ApiParam(value = "Basket Id", required = true) @PathVariable("basketId") String basketId,
            @NotNull @Min(1) @ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue = "1") Integer pageNumber,
            @NotNull @Min(1) @Max(100) @ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue = "10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId);

    /**
     * Get all existing baskets.
     * 
     * @return ResponseEntity<RestResponse<Basket>>
     */
    @ApiOperation(value = "Get all Baskets", notes = "Get all existing baskets.", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 400, message = "Bad Request.(400)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Unauthorized access.(401)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Forbidden access.(403)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "The specified resource was not found.(404)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Internal server error occurred.(500)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Service unavailable.(503)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Gateway timeout.(504)", response = RestResponse.class) })
    @RequestMapping(value = "/baskets", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    ResponseEntity<RestResponse<Basket>> getBaskets(
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId);

    /**
     * Creates a new Basket.
     * 
     * @param basketId
     * @param body
     * @return ResponseEntity<RestResponse<Basket>>
     */
    @ApiOperation(value = "Create Basket", notes = "Creates a new Basket.", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 400, message = "Bad Request.(400)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Unauthorized access.(401)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Forbidden access.(403)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "The specified resource was not found.(404)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Internal server error occurred.(500)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Service unavailable.(503)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Gateway timeout.(504)", response = RestResponse.class) })
    @RequestMapping(value = "/baskets", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    ResponseEntity<RestResponse<Basket>> createBasket(
            @ApiParam(value = "The Basket to create", required = true) @Valid @RequestBody Basket inputBasket,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId);

    /**
     * Updates an existing Basket.
     * 
     * @param basketId
     * @param body
     * @return ResponseEntity<RestResponse<Basket>>
     */
    @ApiOperation(value = "Update Basket", notes = "Updates an existing Basket.", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 201, message = "Response with created resource.", response = RestResponse.class),
            @ApiResponse(code = 400, message = "Bad Request.(400)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Unauthorized access.(401)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Forbidden access.(403)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "The specified resource was not found.(404)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Internal server error occurred.(500)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Service unavailable.(503)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Gateway timeout.(504)", response = RestResponse.class) })
    @RequestMapping(value = "/baskets/{basketId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    ResponseEntity<RestResponse<Basket>> updateBasket(
            @ApiParam(value = "Basket Id", required = true) @PathVariable("basketId") String basketId,
            @ApiParam(value = "The Basket to update", required = true) @Valid @RequestBody Basket inputBasket,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId);

    /**
     * Deletes an existing Basket.
     * 
     * @param basketId
     * @param body
     * @return ResponseEntity<RestResponse<Basket>>
     */
    @ApiOperation(value = "Delete Basket", notes = "Deletes an existing Basket.", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 201, message = "Response with created resource.", response = RestResponse.class),
            @ApiResponse(code = 400, message = "Bad Request.(400)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Unauthorized access.(401)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Forbidden access.(403)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "The specified resource was not found.(404)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Internal server error occurred.(500)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Service unavailable.(503)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Gateway timeout.(504)", response = RestResponse.class) })
    @RequestMapping(value = "/baskets/{basketId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.DELETE)
    ResponseEntity<RestResponse<String>> deleteBasket(
            @ApiParam(value = "Basket Id", required = true) @PathVariable("basketId") String basketId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId);
}
