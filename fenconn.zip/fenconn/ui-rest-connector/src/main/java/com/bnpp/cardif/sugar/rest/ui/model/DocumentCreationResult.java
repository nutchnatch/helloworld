package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * DocumentCreationResult
 */
public class DocumentCreationResult implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("documentId")
    private String documentId = null;

    @JsonProperty("envelopeId")
    private String envelopeId = null;

    public DocumentCreationResult documentId(String documentId) {
        this.documentId = documentId;
        return this;
    }

    /**
     * Created document identification.
     * 
     * @return documentId
     **/
    @ApiModelProperty(value = "Created document identification.")
    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public DocumentCreationResult envelopeId(String envelopeId) {
        this.envelopeId = envelopeId;
        return this;
    }

    /**
     * Created envelope identification.
     * 
     * @return envelopeId
     **/
    @ApiModelProperty(value = "Created envelope identification.")
    public String getEnvelopeId() {
        return envelopeId;
    }

    public void setEnvelopeId(String envelopeId) {
        this.envelopeId = envelopeId;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((documentId == null) ? 0 : documentId.hashCode());
        result = prime * result + ((envelopeId == null) ? 0 : envelopeId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof DocumentCreationResult))
            return false;
        DocumentCreationResult other = (DocumentCreationResult) obj;
        if (documentId == null) {
            if (other.documentId != null)
                return false;
        }
        else if (!documentId.equals(other.documentId))
            return false;
        if (envelopeId == null) {
            if (other.envelopeId != null)
                return false;
        }
        else if (!envelopeId.equals(other.envelopeId))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DocumentCreationResult [documentId=");
        builder.append(documentId);
        builder.append(", envelopeId=");
        builder.append(envelopeId);
        builder.append("]");
        return builder.toString();
    }

}
