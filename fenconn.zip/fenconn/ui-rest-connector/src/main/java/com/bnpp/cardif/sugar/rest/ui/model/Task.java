package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.time.ZonedDateTime;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Represents a task.
 */
@ApiModel(description = "Represents a task.")
public class Task implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("taskId")
    private String taskId = null;

    @JsonProperty("basketId")
    private String basketId = null;

    @JsonProperty("envelopeId")
    private String envelopeId = null;

    @JsonProperty("lockName")
    private String lockName = null;

    @JsonProperty("status")
    private String status = null;

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("updateDate")
    private ZonedDateTime updateDate = null;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("scope")
    private String scope = null;

    public Task taskId(String taskId) {
        this.taskId = taskId;
        return this;
    }

    /**
     * Identifies one task uniquely.
     * 
     * @return taskId
     **/
    @ApiModelProperty(required = true, value = "Identifies one task uniquely.")
    @NotNull
    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public Task basketId(String basketId) {
        this.basketId = basketId;
        return this;
    }

    /**
     * Bask id that this task belongs to.
     * 
     * @return basketId
     **/
    @ApiModelProperty(value = "Bask id that this task belongs to.")
    public String getBasketId() {
        return basketId;
    }

    public void setBasketId(String basketId) {
        this.basketId = basketId;
    }

    public Task envelopeId(String docId) {
        this.envelopeId = docId;
        return this;
    }

    /**
     * Get envelopeId
     * 
     * @return envelopeId
     **/
    @ApiModelProperty(value = "")
    public String getEnvelopeId() {
        return envelopeId;
    }

    public void setEnvelopeId(String envelopeId) {
        this.envelopeId = envelopeId;
    }

    public Task lockName(String lockName) {
        this.lockName = lockName;
        return this;
    }

    /**
     * Name of the locker of the task.
     * 
     * @return lockName
     **/
    @ApiModelProperty(value = "Name of the locker of the task.")
    public String getLockName() {
        return lockName;
    }

    public void setLockName(String lockName) {
        this.lockName = lockName;
    }

    public Task status(String status) {
        this.status = status;
        return this;
    }

    /**
     * State of the Task.
     * 
     * @return status
     **/
    @ApiModelProperty(value = "State of the Task.")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Task creationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    /**
     * Date of creation of the Task.
     * 
     * @return creationDate
     **/
    @ApiModelProperty(value = "Date of creation of the Task.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public Task updateDate(ZonedDateTime updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    /**
     * When the Task was updated.
     * 
     * @return updateDate
     **/
    @ApiModelProperty(value = "When the Task was updated.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(ZonedDateTime updateDate) {
        this.updateDate = updateDate;
    }

    public Task name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Name of the Task.
     * 
     * @return name
     **/
    @ApiModelProperty(value = "Name of the Task.")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Task scope(String scope) {
        this.scope = scope;
        return this;
    }

    /**
     * Task's scope.
     * 
     * @return scope
     **/
    @ApiModelProperty(value = "Task's scope.")
    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((basketId == null) ? 0 : basketId.hashCode());
        result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
        result = prime * result + ((envelopeId == null) ? 0 : envelopeId.hashCode());
        result = prime * result + ((lockName == null) ? 0 : lockName.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((scope == null) ? 0 : scope.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((taskId == null) ? 0 : taskId.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Task))
            return false;
        Task other = (Task) obj;
        if (basketId == null) {
            if (other.basketId != null)
                return false;
        }
        else if (!basketId.equals(other.basketId))
            return false;
        if (creationDate == null) {
            if (other.creationDate != null)
                return false;
        }
        else if (!creationDate.equals(other.creationDate))
            return false;
        if (envelopeId == null) {
            if (other.envelopeId != null)
                return false;
        }
        else if (!envelopeId.equals(other.envelopeId))
            return false;
        if (lockName == null) {
            if (other.lockName != null)
                return false;
        }
        else if (!lockName.equals(other.lockName))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        }
        else if (!name.equals(other.name))
            return false;
        if (scope == null) {
            if (other.scope != null)
                return false;
        }
        else if (!scope.equals(other.scope))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        }
        else if (!status.equals(other.status))
            return false;
        if (taskId == null) {
            if (other.taskId != null)
                return false;
        }
        else if (!taskId.equals(other.taskId))
            return false;
        if (updateDate == null) {
            if (other.updateDate != null)
                return false;
        }
        else if (!updateDate.equals(other.updateDate))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Task [taskId=");
        builder.append(taskId);
        builder.append(", basketId=");
        builder.append(basketId);
        builder.append(", envelopeId=");
        builder.append(envelopeId);
        builder.append(", lockName=");
        builder.append(lockName);
        builder.append(", status=");
        builder.append(status);
        builder.append(", creationDate=");
        builder.append(creationDate);
        builder.append(", updateDate=");
        builder.append(updateDate);
        builder.append(", name=");
        builder.append(name);
        builder.append(", scope=");
        builder.append(scope);
        builder.append("]");
        return builder.toString();
    }

}
