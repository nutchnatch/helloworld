package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ErrorCause
 */
public class ErrorCause implements Serializable {
    
    private static final long serialVersionUID = 1L;

    @JsonProperty("errorType")
    private String errorType = null;

    @JsonProperty("code")
    private String code = null;

    @JsonProperty("message")
    private String message = null;

    @JsonProperty("errorDate")
    private ZonedDateTime errorDate = null;

    @JsonProperty("stack")
    private ErrorStack stack = null;

    public ErrorCause errorType(String errorType) {
        this.errorType = errorType;
        return this;
    }

    /**
     * Type of error raised- FE: Functional error, TE: Technical error, SE:
     * Security error
     * 
     * @return errorType
     **/
    @ApiModelProperty(value = "Type of error raised- FE: Functional error, TE: Technical error, SE: Security error")
    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public ErrorCause code(String code) {
        this.code = code;
        return this;
    }

    /**
     * Application error code.
     * 
     * @return code
     **/
    @ApiModelProperty(value = "Application error code.")
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ErrorCause message(String message) {
        this.message = message;
        return this;
    }

    /**
     * Application error message description.
     * 
     * @return message
     **/
    @ApiModelProperty(value = "Application error message description.")
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ErrorCause errorDate(ZonedDateTime errorDate) {
        this.errorDate = errorDate;
        return this;
    }

    /**
     * Timestamp when the error occurred.
     * 
     * @return errorDate
     **/
    @ApiModelProperty(value = "Timestamp when the error occurred.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getErrorDate() {
        return errorDate;
    }

    public void setErrorDate(ZonedDateTime errorDate) {
        this.errorDate = errorDate;
    }

    public ErrorCause stack(ErrorStack stack) {
        this.stack = stack;
        return this;
    }

    /**
     * Get stack
     * 
     * @return stack
     **/
    @ApiModelProperty(value = "")
    @Valid
    public ErrorStack getStack() {
        return stack;
    }

    public void setStack(ErrorStack stack) {
        this.stack = stack;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((errorDate == null) ? 0 : errorDate.hashCode());
        result = prime * result + ((errorType == null) ? 0 : errorType.hashCode());
        result = prime * result + ((message == null) ? 0 : message.hashCode());
        result = prime * result + ((stack == null) ? 0 : stack.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof ErrorCause))
            return false;
        ErrorCause other = (ErrorCause) obj;
        if (code == null) {
            if (other.code != null)
                return false;
        }
        else if (!code.equals(other.code))
            return false;
        if (errorDate == null) {
            if (other.errorDate != null)
                return false;
        }
        else if (!errorDate.equals(other.errorDate))
            return false;
        if (errorType == null) {
            if (other.errorType != null)
                return false;
        }
        else if (!errorType.equals(other.errorType))
            return false;
        if (message == null) {
            if (other.message != null)
                return false;
        }
        else if (!message.equals(other.message))
            return false;
        if (stack == null) {
            if (other.stack != null)
                return false;
        }
        else if (!stack.equals(other.stack))
            return false;
        return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ErrorCause [errorType=");
        builder.append(errorType);
        builder.append(", code=");
        builder.append(code);
        builder.append(", message=");
        builder.append(message);
        builder.append(", errorDate=");
        builder.append(errorDate);
        builder.append(", stack=");
        builder.append(stack);
        builder.append("]");
        return builder.toString();
    }

    
}
