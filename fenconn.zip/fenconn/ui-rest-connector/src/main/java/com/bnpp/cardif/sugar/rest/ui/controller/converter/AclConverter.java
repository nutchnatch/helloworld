package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.util.ArrayList;
import java.util.List;

import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;

/**
 * 
 * @author 831743
 *
 */
public class AclConverter {

    /**
     * private empty constructor
     */
    private AclConverter() {
        // private constructor to avoid instance creation.
    }

    public static List<Acl> convert(AccessControlList instanceAcl, AccessControlList classAcl) {

        List<Acl> result = new ArrayList<>();
        if (instanceAcl != null) {
            Acl content1 = AclConverter.convert(instanceAcl, true);
            result.add(content1);
        }
        if (classAcl != null) {
            Acl content2 = AclConverter.convert(classAcl, false);
            result.add(content2);
        }
        return result;
    }

    public static Acl convert(AccessControlList accessControlList, boolean isInstanceValue) {
        Acl result = null;
        if (accessControlList != null) {
            result = new Acl();
            AclId aclId = accessControlList.getAclId();
            if(aclId != null) {
                result.setAclId(aclId.getValue());
            }
            result.setName(accessControlList.getName());
            result.setIsInstanceValue(isInstanceValue);
        }
        return result;
    }

    public static List<Acl> convert(List<AccessControlList> aclList) {
        
        List<Acl> result = new ArrayList<>();
        if(aclList != null) {
            for (AccessControlList accessControlList : aclList) {
                Acl content = AclConverter.convert(accessControlList, false);
                result.add(content);
            }
        }
        return result;
    }

}
