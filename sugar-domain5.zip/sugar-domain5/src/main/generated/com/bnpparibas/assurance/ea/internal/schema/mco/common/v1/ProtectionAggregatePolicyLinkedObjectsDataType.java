
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objets liés aux données
 * 				agrégées contrat
 * 			
 * 
 * <p>Java class for ProtectionAggregatePolicyLinkedObjectsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionAggregatePolicyLinkedObjectsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType"/&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType"/&gt;
 *         &lt;element name="Prdcr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductIdentificationAndHierarchyDataType" minOccurs="0"/&gt;
 *         &lt;element name="RiskCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductRiskIdentificationDataType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionAggregatePolicyLinkedObjectsDataType", propOrder = {
    "distrbtr",
    "pdct",
    "prdcr",
    "corePdct",
    "riskCode"
})
public class ProtectionAggregatePolicyLinkedObjectsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Distrbtr", required = true)
    protected PartnerPartyType distrbtr;
    @XmlElement(name = "Pdct", required = true)
    protected ObjectIdentificationWithVersionType pdct;
    @XmlElement(name = "Prdcr")
    protected PartyRoleType prdcr;
    @XmlElement(name = "CorePdct")
    protected CoreProductIdentificationAndHierarchyDataType corePdct;
    @XmlElement(name = "RiskCode", required = true)
    protected ProductRiskIdentificationDataType riskCode;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionAggregatePolicyLinkedObjectsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionAggregatePolicyLinkedObjectsDataType(final PartnerPartyType distrbtr, final ObjectIdentificationWithVersionType pdct, final PartyRoleType prdcr, final CoreProductIdentificationAndHierarchyDataType corePdct, final ProductRiskIdentificationDataType riskCode) {
        this.distrbtr = distrbtr;
        this.pdct = pdct;
        this.prdcr = prdcr;
        this.corePdct = corePdct;
        this.riskCode = riskCode;
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * @return
     *     possible object is
     *     {@link PartnerPartyType }
     *     
     */
    public PartnerPartyType getDistrbtr() {
        return distrbtr;
    }

    /**
     * Sets the value of the distrbtr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartnerPartyType }
     *     
     */
    public void setDistrbtr(PartnerPartyType value) {
        this.distrbtr = value;
    }

    public boolean isSetDistrbtr() {
        return (this.distrbtr!= null);
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setPdct(ObjectIdentificationWithVersionType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the prdcr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdcr() {
        return prdcr;
    }

    /**
     * Sets the value of the prdcr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdcr(PartyRoleType value) {
        this.prdcr = value;
    }

    public boolean isSetPrdcr() {
        return (this.prdcr!= null);
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public CoreProductIdentificationAndHierarchyDataType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public void setCorePdct(CoreProductIdentificationAndHierarchyDataType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    /**
     * Gets the value of the riskCode property.
     * 
     * @return
     *     possible object is
     *     {@link ProductRiskIdentificationDataType }
     *     
     */
    public ProductRiskIdentificationDataType getRiskCode() {
        return riskCode;
    }

    /**
     * Sets the value of the riskCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductRiskIdentificationDataType }
     *     
     */
    public void setRiskCode(ProductRiskIdentificationDataType value) {
        this.riskCode = value;
    }

    public boolean isSetRiskCode() {
        return (this.riskCode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("distrbtr", distrbtr).add("pdct", pdct).add("prdcr", prdcr).add("corePdct", corePdct).add("riskCode", riskCode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(distrbtr, pdct, prdcr, corePdct, riskCode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionAggregatePolicyLinkedObjectsDataType o = ((ProtectionAggregatePolicyLinkedObjectsDataType) other);
        return ((((Objects.equal(distrbtr, o.distrbtr)&&Objects.equal(pdct, o.pdct))&&Objects.equal(prdcr, o.prdcr))&&Objects.equal(corePdct, o.corePdct))&&Objects.equal(riskCode, o.riskCode));
    }

}
