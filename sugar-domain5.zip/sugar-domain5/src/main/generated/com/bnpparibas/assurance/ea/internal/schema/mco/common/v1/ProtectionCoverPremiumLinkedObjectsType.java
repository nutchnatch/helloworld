
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Object with which a cover premium has dependencies
 * 			
 * 
 * <p>Java class for ProtectionCoverPremiumLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionCoverPremiumLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Insurer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="Insrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionCoverPremiumLinkedObjectsType", propOrder = {
    "insurer",
    "insrd"
})
public class ProtectionCoverPremiumLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Insurer")
    protected PartyRoleType insurer;
    @XmlElement(name = "Insrd")
    protected PartyRoleType insrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionCoverPremiumLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionCoverPremiumLinkedObjectsType(final PartyRoleType insurer, final PartyRoleType insrd) {
        this.insurer = insurer;
        this.insrd = insrd;
    }

    /**
     * Gets the value of the insurer property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsurer() {
        return insurer;
    }

    /**
     * Sets the value of the insurer property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsurer(PartyRoleType value) {
        this.insurer = value;
    }

    public boolean isSetInsurer() {
        return (this.insurer!= null);
    }

    /**
     * Gets the value of the insrd property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsrd() {
        return insrd;
    }

    /**
     * Sets the value of the insrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsrd(PartyRoleType value) {
        this.insrd = value;
    }

    public boolean isSetInsrd() {
        return (this.insrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("insurer", insurer).add("insrd", insrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(insurer, insrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionCoverPremiumLinkedObjectsType o = ((ProtectionCoverPremiumLinkedObjectsType) other);
        return (Objects.equal(insurer, o.insurer)&&Objects.equal(insrd, o.insrd));
    }

}
