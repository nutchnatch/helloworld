
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to define data on entry fund movement linked
 * 				to savings operation in input
 * 			
 * 
 * <p>Java class for SavingsOperationFundMovementInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsOperationFundMovementInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence minOccurs="0"&gt;
 *         &lt;element name="FundDistrbtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsOperationFundDistributionInputType"/&gt;
 *         &lt;element name="AddAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AdditionalAmountType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="MvtFeeDerog" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeeDerogationInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="MvtTax" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsOperationFundMovementInputType", propOrder = {
    "fundDistrbtn",
    "addAmnt",
    "mvtFeeDerog",
    "mvtTax"
})
public class SavingsOperationFundMovementInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FundDistrbtn")
    protected SavingsOperationFundDistributionInputType fundDistrbtn;
    @XmlElement(name = "AddAmnt")
    protected List<AdditionalAmountType> addAmnt;
    @XmlElement(name = "MvtFeeDerog")
    protected List<FeeDerogationInputType> mvtFeeDerog;
    @XmlElement(name = "MvtTax")
    protected List<TaxType> mvtTax;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsOperationFundMovementInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsOperationFundMovementInputType(final SavingsOperationFundDistributionInputType fundDistrbtn, final List<AdditionalAmountType> addAmnt, final List<FeeDerogationInputType> mvtFeeDerog, final List<TaxType> mvtTax) {
        this.fundDistrbtn = fundDistrbtn;
        this.addAmnt = addAmnt;
        this.mvtFeeDerog = mvtFeeDerog;
        this.mvtTax = mvtTax;
    }

    /**
     * Gets the value of the fundDistrbtn property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsOperationFundDistributionInputType }
     *     
     */
    public SavingsOperationFundDistributionInputType getFundDistrbtn() {
        return fundDistrbtn;
    }

    /**
     * Sets the value of the fundDistrbtn property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsOperationFundDistributionInputType }
     *     
     */
    public void setFundDistrbtn(SavingsOperationFundDistributionInputType value) {
        this.fundDistrbtn = value;
    }

    public boolean isSetFundDistrbtn() {
        return (this.fundDistrbtn!= null);
    }

    /**
     * Gets the value of the addAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmountType }
     * 
     * 
     */
    public List<AdditionalAmountType> getAddAmnt() {
        if (addAmnt == null) {
            addAmnt = new ArrayList<AdditionalAmountType>();
        }
        return this.addAmnt;
    }

    public boolean isSetAddAmnt() {
        return ((this.addAmnt!= null)&&(!this.addAmnt.isEmpty()));
    }

    public void unsetAddAmnt() {
        this.addAmnt = null;
    }

    /**
     * Gets the value of the mvtFeeDerog property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mvtFeeDerog property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMvtFeeDerog().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeeDerogationInputType }
     * 
     * 
     */
    public List<FeeDerogationInputType> getMvtFeeDerog() {
        if (mvtFeeDerog == null) {
            mvtFeeDerog = new ArrayList<FeeDerogationInputType>();
        }
        return this.mvtFeeDerog;
    }

    public boolean isSetMvtFeeDerog() {
        return ((this.mvtFeeDerog!= null)&&(!this.mvtFeeDerog.isEmpty()));
    }

    public void unsetMvtFeeDerog() {
        this.mvtFeeDerog = null;
    }

    /**
     * Gets the value of the mvtTax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mvtTax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMvtTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxType }
     * 
     * 
     */
    public List<TaxType> getMvtTax() {
        if (mvtTax == null) {
            mvtTax = new ArrayList<TaxType>();
        }
        return this.mvtTax;
    }

    public boolean isSetMvtTax() {
        return ((this.mvtTax!= null)&&(!this.mvtTax.isEmpty()));
    }

    public void unsetMvtTax() {
        this.mvtTax = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fundDistrbtn", fundDistrbtn).add("addAmnt", addAmnt).add("mvtFeeDerog", mvtFeeDerog).add("mvtTax", mvtTax).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fundDistrbtn, addAmnt, mvtFeeDerog, mvtTax);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsOperationFundMovementInputType o = ((SavingsOperationFundMovementInputType) other);
        return (((Objects.equal(fundDistrbtn, o.fundDistrbtn)&&Objects.equal(addAmnt, o.addAmnt))&&Objects.equal(mvtFeeDerog, o.mvtFeeDerog))&&Objects.equal(mvtTax, o.mvtTax));
    }

}
