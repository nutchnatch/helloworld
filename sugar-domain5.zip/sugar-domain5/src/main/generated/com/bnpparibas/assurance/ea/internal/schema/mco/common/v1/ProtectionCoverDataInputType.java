
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data carried by the cover for
 * 				protection policy
 * 			
 * 
 * <p>Java class for ProtectionCoverDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionCoverDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovrgeCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode" minOccurs="0"/&gt;
 *         &lt;element name="LifeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LifeIndicatorCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="InsrdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="CovLvlRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CovPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionCoverDataInputType", propOrder = {
    "covrgeCode",
    "lifeIndic",
    "insrdAmnt",
    "covLvlRate",
    "benfciaryType",
    "covPrd",
    "duratn"
})
public class ProtectionCoverDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovrgeCode")
    protected String covrgeCode;
    @XmlElement(name = "LifeIndic")
    protected String lifeIndic;
    @XmlElement(name = "InsrdAmnt")
    protected CurrencyAndAmountType insrdAmnt;
    @XmlElement(name = "CovLvlRate")
    protected Double covLvlRate;
    @XmlElement(name = "BenfciaryType")
    protected String benfciaryType;
    @XmlElement(name = "CovPrd")
    protected OptionalDatePeriodType covPrd;
    @XmlElement(name = "Duratn")
    protected DurationType duratn;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionCoverDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionCoverDataInputType(final String covrgeCode, final String lifeIndic, final CurrencyAndAmountType insrdAmnt, final Double covLvlRate, final String benfciaryType, final OptionalDatePeriodType covPrd, final DurationType duratn) {
        this.covrgeCode = covrgeCode;
        this.lifeIndic = lifeIndic;
        this.insrdAmnt = insrdAmnt;
        this.covLvlRate = covLvlRate;
        this.benfciaryType = benfciaryType;
        this.covPrd = covPrd;
        this.duratn = duratn;
    }

    /**
     * Gets the value of the covrgeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovrgeCode() {
        return covrgeCode;
    }

    /**
     * Sets the value of the covrgeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovrgeCode(String value) {
        this.covrgeCode = value;
    }

    public boolean isSetCovrgeCode() {
        return (this.covrgeCode!= null);
    }

    /**
     * Gets the value of the lifeIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifeIndic() {
        return lifeIndic;
    }

    /**
     * Sets the value of the lifeIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifeIndic(String value) {
        this.lifeIndic = value;
    }

    public boolean isSetLifeIndic() {
        return (this.lifeIndic!= null);
    }

    /**
     * Gets the value of the insrdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInsrdAmnt() {
        return insrdAmnt;
    }

    /**
     * Sets the value of the insrdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInsrdAmnt(CurrencyAndAmountType value) {
        this.insrdAmnt = value;
    }

    public boolean isSetInsrdAmnt() {
        return (this.insrdAmnt!= null);
    }

    /**
     * Gets the value of the covLvlRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCovLvlRate() {
        return covLvlRate;
    }

    /**
     * Sets the value of the covLvlRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCovLvlRate(Double value) {
        this.covLvlRate = value;
    }

    public boolean isSetCovLvlRate() {
        return (this.covLvlRate!= null);
    }

    /**
     * Gets the value of the benfciaryType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBenfciaryType() {
        return benfciaryType;
    }

    /**
     * Sets the value of the benfciaryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBenfciaryType(String value) {
        this.benfciaryType = value;
    }

    public boolean isSetBenfciaryType() {
        return (this.benfciaryType!= null);
    }

    /**
     * Gets the value of the covPrd property.
     * 
     * @return
     *     possible object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public OptionalDatePeriodType getCovPrd() {
        return covPrd;
    }

    /**
     * Sets the value of the covPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public void setCovPrd(OptionalDatePeriodType value) {
        this.covPrd = value;
    }

    public boolean isSetCovPrd() {
        return (this.covPrd!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covrgeCode", covrgeCode).add("lifeIndic", lifeIndic).add("insrdAmnt", insrdAmnt).add("covLvlRate", covLvlRate).add("benfciaryType", benfciaryType).add("covPrd", covPrd).add("duratn", duratn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covrgeCode, lifeIndic, insrdAmnt, covLvlRate, benfciaryType, covPrd, duratn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionCoverDataInputType o = ((ProtectionCoverDataInputType) other);
        return ((((((Objects.equal(covrgeCode, o.covrgeCode)&&Objects.equal(lifeIndic, o.lifeIndic))&&Objects.equal(insrdAmnt, o.insrdAmnt))&&Objects.equal(covLvlRate, o.covLvlRate))&&Objects.equal(benfciaryType, o.benfciaryType))&&Objects.equal(covPrd, o.covPrd))&&Objects.equal(duratn, o.duratn));
    }

}
