
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * <p>Java class for ReserveOperationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReserveOperationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReserveTypeCodeSLN"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="CalctnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="SubRsrve" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumDecompositionCodeSLN"/&gt;
 *                   &lt;element name="RuleCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CalculationMethodCodeSLN" minOccurs="0"/&gt;
 *                   &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReserveOperationDataType", propOrder = {
    "type",
    "amnt",
    "calctnDate",
    "prd",
    "subRsrve"
})
public class ReserveOperationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "CalctnDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date calctnDate;
    @XmlElement(name = "Prd")
    protected DatePeriodType prd;
    @XmlElement(name = "SubRsrve")
    protected List<ReserveOperationDataType.SubRsrve> subRsrve;

    /**
     * Default no-arg constructor
     * 
     */
    public ReserveOperationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ReserveOperationDataType(final String type, final CurrencyAndAmountType amnt, final Date calctnDate, final DatePeriodType prd, final List<ReserveOperationDataType.SubRsrve> subRsrve) {
        this.type = type;
        this.amnt = amnt;
        this.calctnDate = calctnDate;
        this.prd = prd;
        this.subRsrve = subRsrve;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the calctnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCalctnDate() {
        return calctnDate;
    }

    /**
     * Sets the value of the calctnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalctnDate(Date value) {
        this.calctnDate = value;
    }

    public boolean isSetCalctnDate() {
        return (this.calctnDate!= null);
    }

    /**
     * Gets the value of the prd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getPrd() {
        return prd;
    }

    /**
     * Sets the value of the prd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setPrd(DatePeriodType value) {
        this.prd = value;
    }

    public boolean isSetPrd() {
        return (this.prd!= null);
    }

    /**
     * Gets the value of the subRsrve property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the subRsrve property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubRsrve().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReserveOperationDataType.SubRsrve }
     * 
     * 
     */
    public List<ReserveOperationDataType.SubRsrve> getSubRsrve() {
        if (subRsrve == null) {
            subRsrve = new ArrayList<ReserveOperationDataType.SubRsrve>();
        }
        return this.subRsrve;
    }

    public boolean isSetSubRsrve() {
        return ((this.subRsrve!= null)&&(!this.subRsrve.isEmpty()));
    }

    public void unsetSubRsrve() {
        this.subRsrve = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("amnt", amnt).add("calctnDate", calctnDate).add("prd", prd).add("subRsrve", subRsrve).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, amnt, calctnDate, prd, subRsrve);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ReserveOperationDataType o = ((ReserveOperationDataType) other);
        return ((((Objects.equal(type, o.type)&&Objects.equal(amnt, o.amnt))&&Objects.equal(calctnDate, o.calctnDate))&&Objects.equal(prd, o.prd))&&Objects.equal(subRsrve, o.subRsrve));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumDecompositionCodeSLN"/&gt;
     *         &lt;element name="RuleCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CalculationMethodCodeSLN" minOccurs="0"/&gt;
     *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "type",
        "ruleCode",
        "amnt"
    })
    public static class SubRsrve implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Type", required = true)
        protected String type;
        @XmlElement(name = "RuleCode")
        protected String ruleCode;
        @XmlElement(name = "Amnt", required = true)
        protected CurrencyAndAmountType amnt;

        /**
         * Default no-arg constructor
         * 
         */
        public SubRsrve() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public SubRsrve(final String type, final String ruleCode, final CurrencyAndAmountType amnt) {
            this.type = type;
            this.ruleCode = ruleCode;
            this.amnt = amnt;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

        public boolean isSetType() {
            return (this.type!= null);
        }

        /**
         * Gets the value of the ruleCode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRuleCode() {
            return ruleCode;
        }

        /**
         * Sets the value of the ruleCode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRuleCode(String value) {
            this.ruleCode = value;
        }

        public boolean isSetRuleCode() {
            return (this.ruleCode!= null);
        }

        /**
         * Gets the value of the amnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getAmnt() {
            return amnt;
        }

        /**
         * Sets the value of the amnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setAmnt(CurrencyAndAmountType value) {
            this.amnt = value;
        }

        public boolean isSetAmnt() {
            return (this.amnt!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("type", type).add("ruleCode", ruleCode).add("amnt", amnt).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(type, ruleCode, amnt);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ReserveOperationDataType.SubRsrve o = ((ReserveOperationDataType.SubRsrve) other);
            return ((Objects.equal(type, o.type)&&Objects.equal(ruleCode, o.ruleCode))&&Objects.equal(amnt, o.amnt));
        }

    }

}
