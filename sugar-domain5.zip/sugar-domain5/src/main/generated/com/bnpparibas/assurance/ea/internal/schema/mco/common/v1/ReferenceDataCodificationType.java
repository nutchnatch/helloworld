
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Bloc for identification
 * 				of a reference data which is not referenced in Cardif IT System
 * 			
 * 
 * <p>Java class for ReferenceDataCodificationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReferenceDataCodificationType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;IdentifierType"&gt;
 *       &lt;attribute name="Issuer" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IssuerCodeSLN" /&gt;
 *       &lt;attribute name="RefDataCode" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExternalNomenclatureCodeSLN" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReferenceDataCodificationType", propOrder = {
    "value"
})
public class ReferenceDataCodificationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected String value;
    @XmlAttribute(name = "Issuer", required = true)
    protected String issuer;
    @XmlAttribute(name = "RefDataCode", required = true)
    protected String refDataCode;

    /**
     * Default no-arg constructor
     * 
     */
    public ReferenceDataCodificationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ReferenceDataCodificationType(final String value, final String issuer, final String refDataCode) {
        this.value = value;
        this.issuer = issuer;
        this.refDataCode = refDataCode;
    }

    /**
     * Any simple identifier
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the issuer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuer() {
        return issuer;
    }

    /**
     * Sets the value of the issuer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuer(String value) {
        this.issuer = value;
    }

    public boolean isSetIssuer() {
        return (this.issuer!= null);
    }

    /**
     * Gets the value of the refDataCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefDataCode() {
        return refDataCode;
    }

    /**
     * Sets the value of the refDataCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefDataCode(String value) {
        this.refDataCode = value;
    }

    public boolean isSetRefDataCode() {
        return (this.refDataCode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("issuer", issuer).add("refDataCode", refDataCode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, issuer, refDataCode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ReferenceDataCodificationType o = ((ReferenceDataCodificationType) other);
        return ((Objects.equal(value, o.value)&&Objects.equal(issuer, o.issuer))&&Objects.equal(refDataCode, o.refDataCode));
    }

}
