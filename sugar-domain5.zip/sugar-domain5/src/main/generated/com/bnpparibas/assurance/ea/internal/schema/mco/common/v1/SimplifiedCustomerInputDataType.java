
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data of a customer without used
 * 				RefCustomerEventInput
 * 			
 * 
 * <p>Java class for SimplifiedCustomerInputDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SimplifiedCustomerInputDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CustIdntctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="IdntyCard" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CustomerCharacteristicsDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="PostAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PostalAddressInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PhoneAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PhoneAddressInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="EmailAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmailAddressInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BnkngRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankingReferenceInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="EmplmntSituation" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimDeclarationEmploymentDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SimplifiedCustomerInputDataType", propOrder = {
    "custIdntctn",
    "idntyCard",
    "postAdrs",
    "phoneAdrs",
    "emailAdrs",
    "bnkngRef",
    "emplmntSituation"
})
public class SimplifiedCustomerInputDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CustIdntctn", required = true)
    protected PartyRoleType custIdntctn;
    @XmlElement(name = "IdntyCard")
    protected CustomerCharacteristicsDataInputType idntyCard;
    @XmlElement(name = "PostAdrs")
    protected List<PostalAddressInputType> postAdrs;
    @XmlElement(name = "PhoneAdrs")
    protected List<PhoneAddressInputType> phoneAdrs;
    @XmlElement(name = "EmailAdrs")
    protected List<EmailAddressInputType> emailAdrs;
    @XmlElement(name = "BnkngRef")
    protected List<BankingReferenceInputType> bnkngRef;
    @XmlElement(name = "EmplmntSituation")
    protected List<ClaimDeclarationEmploymentDataType> emplmntSituation;

    /**
     * Default no-arg constructor
     * 
     */
    public SimplifiedCustomerInputDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SimplifiedCustomerInputDataType(final PartyRoleType custIdntctn, final CustomerCharacteristicsDataInputType idntyCard, final List<PostalAddressInputType> postAdrs, final List<PhoneAddressInputType> phoneAdrs, final List<EmailAddressInputType> emailAdrs, final List<BankingReferenceInputType> bnkngRef, final List<ClaimDeclarationEmploymentDataType> emplmntSituation) {
        this.custIdntctn = custIdntctn;
        this.idntyCard = idntyCard;
        this.postAdrs = postAdrs;
        this.phoneAdrs = phoneAdrs;
        this.emailAdrs = emailAdrs;
        this.bnkngRef = bnkngRef;
        this.emplmntSituation = emplmntSituation;
    }

    /**
     * Gets the value of the custIdntctn property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getCustIdntctn() {
        return custIdntctn;
    }

    /**
     * Sets the value of the custIdntctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setCustIdntctn(PartyRoleType value) {
        this.custIdntctn = value;
    }

    public boolean isSetCustIdntctn() {
        return (this.custIdntctn!= null);
    }

    /**
     * Gets the value of the idntyCard property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerCharacteristicsDataInputType }
     *     
     */
    public CustomerCharacteristicsDataInputType getIdntyCard() {
        return idntyCard;
    }

    /**
     * Sets the value of the idntyCard property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerCharacteristicsDataInputType }
     *     
     */
    public void setIdntyCard(CustomerCharacteristicsDataInputType value) {
        this.idntyCard = value;
    }

    public boolean isSetIdntyCard() {
        return (this.idntyCard!= null);
    }

    /**
     * Gets the value of the postAdrs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the postAdrs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPostAdrs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PostalAddressInputType }
     * 
     * 
     */
    public List<PostalAddressInputType> getPostAdrs() {
        if (postAdrs == null) {
            postAdrs = new ArrayList<PostalAddressInputType>();
        }
        return this.postAdrs;
    }

    public boolean isSetPostAdrs() {
        return ((this.postAdrs!= null)&&(!this.postAdrs.isEmpty()));
    }

    public void unsetPostAdrs() {
        this.postAdrs = null;
    }

    /**
     * Gets the value of the phoneAdrs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phoneAdrs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhoneAdrs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PhoneAddressInputType }
     * 
     * 
     */
    public List<PhoneAddressInputType> getPhoneAdrs() {
        if (phoneAdrs == null) {
            phoneAdrs = new ArrayList<PhoneAddressInputType>();
        }
        return this.phoneAdrs;
    }

    public boolean isSetPhoneAdrs() {
        return ((this.phoneAdrs!= null)&&(!this.phoneAdrs.isEmpty()));
    }

    public void unsetPhoneAdrs() {
        this.phoneAdrs = null;
    }

    /**
     * Gets the value of the emailAdrs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the emailAdrs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmailAdrs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EmailAddressInputType }
     * 
     * 
     */
    public List<EmailAddressInputType> getEmailAdrs() {
        if (emailAdrs == null) {
            emailAdrs = new ArrayList<EmailAddressInputType>();
        }
        return this.emailAdrs;
    }

    public boolean isSetEmailAdrs() {
        return ((this.emailAdrs!= null)&&(!this.emailAdrs.isEmpty()));
    }

    public void unsetEmailAdrs() {
        this.emailAdrs = null;
    }

    /**
     * Gets the value of the bnkngRef property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bnkngRef property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBnkngRef().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BankingReferenceInputType }
     * 
     * 
     */
    public List<BankingReferenceInputType> getBnkngRef() {
        if (bnkngRef == null) {
            bnkngRef = new ArrayList<BankingReferenceInputType>();
        }
        return this.bnkngRef;
    }

    public boolean isSetBnkngRef() {
        return ((this.bnkngRef!= null)&&(!this.bnkngRef.isEmpty()));
    }

    public void unsetBnkngRef() {
        this.bnkngRef = null;
    }

    /**
     * Gets the value of the emplmntSituation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the emplmntSituation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmplmntSituation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClaimDeclarationEmploymentDataType }
     * 
     * 
     */
    public List<ClaimDeclarationEmploymentDataType> getEmplmntSituation() {
        if (emplmntSituation == null) {
            emplmntSituation = new ArrayList<ClaimDeclarationEmploymentDataType>();
        }
        return this.emplmntSituation;
    }

    public boolean isSetEmplmntSituation() {
        return ((this.emplmntSituation!= null)&&(!this.emplmntSituation.isEmpty()));
    }

    public void unsetEmplmntSituation() {
        this.emplmntSituation = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("custIdntctn", custIdntctn).add("idntyCard", idntyCard).add("postAdrs", postAdrs).add("phoneAdrs", phoneAdrs).add("emailAdrs", emailAdrs).add("bnkngRef", bnkngRef).add("emplmntSituation", emplmntSituation).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(custIdntctn, idntyCard, postAdrs, phoneAdrs, emailAdrs, bnkngRef, emplmntSituation);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SimplifiedCustomerInputDataType o = ((SimplifiedCustomerInputDataType) other);
        return ((((((Objects.equal(custIdntctn, o.custIdntctn)&&Objects.equal(idntyCard, o.idntyCard))&&Objects.equal(postAdrs, o.postAdrs))&&Objects.equal(phoneAdrs, o.phoneAdrs))&&Objects.equal(emailAdrs, o.emailAdrs))&&Objects.equal(bnkngRef, o.bnkngRef))&&Objects.equal(emplmntSituation, o.emplmntSituation));
    }

}
