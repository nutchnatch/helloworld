
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage the distribution per fund for a
 * 				savings operation
 * 			
 * 
 * <p>Java class for SavingsOperationFundDistributionInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsOperationFundDistributionInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PdctProfIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="FinanclFundIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialFundIdentificationType"/&gt;
 *         &lt;element name="DistrbtnRnk" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="OutstdngRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="DistrbtnValue" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ValueDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsOperationFundDistributionInputType", propOrder = {
    "pdctProfIdntfctn",
    "financlFundIdntfctn",
    "distrbtnRnk",
    "outstdngRate",
    "distrbtnValue"
})
public class SavingsOperationFundDistributionInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PdctProfIdntfctn")
    protected ObjectIdentificationType pdctProfIdntfctn;
    @XmlElement(name = "FinanclFundIdntfctn", required = true)
    protected FinancialFundIdentificationType financlFundIdntfctn;
    @XmlElement(name = "DistrbtnRnk")
    protected BigInteger distrbtnRnk;
    @XmlElement(name = "OutstdngRate")
    protected Double outstdngRate;
    @XmlElement(name = "DistrbtnValue")
    protected ValueDataType distrbtnValue;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsOperationFundDistributionInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsOperationFundDistributionInputType(final ObjectIdentificationType pdctProfIdntfctn, final FinancialFundIdentificationType financlFundIdntfctn, final BigInteger distrbtnRnk, final Double outstdngRate, final ValueDataType distrbtnValue) {
        this.pdctProfIdntfctn = pdctProfIdntfctn;
        this.financlFundIdntfctn = financlFundIdntfctn;
        this.distrbtnRnk = distrbtnRnk;
        this.outstdngRate = outstdngRate;
        this.distrbtnValue = distrbtnValue;
    }

    /**
     * Gets the value of the pdctProfIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPdctProfIdntfctn() {
        return pdctProfIdntfctn;
    }

    /**
     * Sets the value of the pdctProfIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPdctProfIdntfctn(ObjectIdentificationType value) {
        this.pdctProfIdntfctn = value;
    }

    public boolean isSetPdctProfIdntfctn() {
        return (this.pdctProfIdntfctn!= null);
    }

    /**
     * Gets the value of the financlFundIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialFundIdentificationType }
     *     
     */
    public FinancialFundIdentificationType getFinanclFundIdntfctn() {
        return financlFundIdntfctn;
    }

    /**
     * Sets the value of the financlFundIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialFundIdentificationType }
     *     
     */
    public void setFinanclFundIdntfctn(FinancialFundIdentificationType value) {
        this.financlFundIdntfctn = value;
    }

    public boolean isSetFinanclFundIdntfctn() {
        return (this.financlFundIdntfctn!= null);
    }

    /**
     * Gets the value of the distrbtnRnk property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDistrbtnRnk() {
        return distrbtnRnk;
    }

    /**
     * Sets the value of the distrbtnRnk property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDistrbtnRnk(BigInteger value) {
        this.distrbtnRnk = value;
    }

    public boolean isSetDistrbtnRnk() {
        return (this.distrbtnRnk!= null);
    }

    /**
     * Gets the value of the outstdngRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getOutstdngRate() {
        return outstdngRate;
    }

    /**
     * Sets the value of the outstdngRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setOutstdngRate(Double value) {
        this.outstdngRate = value;
    }

    public boolean isSetOutstdngRate() {
        return (this.outstdngRate!= null);
    }

    /**
     * Gets the value of the distrbtnValue property.
     * 
     * @return
     *     possible object is
     *     {@link ValueDataType }
     *     
     */
    public ValueDataType getDistrbtnValue() {
        return distrbtnValue;
    }

    /**
     * Sets the value of the distrbtnValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueDataType }
     *     
     */
    public void setDistrbtnValue(ValueDataType value) {
        this.distrbtnValue = value;
    }

    public boolean isSetDistrbtnValue() {
        return (this.distrbtnValue!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdctProfIdntfctn", pdctProfIdntfctn).add("financlFundIdntfctn", financlFundIdntfctn).add("distrbtnRnk", distrbtnRnk).add("outstdngRate", outstdngRate).add("distrbtnValue", distrbtnValue).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdctProfIdntfctn, financlFundIdntfctn, distrbtnRnk, outstdngRate, distrbtnValue);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsOperationFundDistributionInputType o = ((SavingsOperationFundDistributionInputType) other);
        return ((((Objects.equal(pdctProfIdntfctn, o.pdctProfIdntfctn)&&Objects.equal(financlFundIdntfctn, o.financlFundIdntfctn))&&Objects.equal(distrbtnRnk, o.distrbtnRnk))&&Objects.equal(outstdngRate, o.outstdngRate))&&Objects.equal(distrbtnValue, o.distrbtnValue));
    }

}
