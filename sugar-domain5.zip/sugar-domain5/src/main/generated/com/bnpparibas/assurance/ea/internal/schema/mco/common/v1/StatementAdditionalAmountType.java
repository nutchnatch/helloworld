
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Currency and amount plus amount type code to manage
 * 				dynamically additional amounts
 * 			
 * 
 * <p>Java class for StatementAdditionalAmountType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatementAdditionalAmountType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;AmountType"&gt;
 *       &lt;attribute name="BalnceAmntType" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BalanceTypeCode" /&gt;
 *       &lt;attribute name="Curr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatementAdditionalAmountType", propOrder = {
    "value"
})
public class StatementAdditionalAmountType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected double value;
    @XmlAttribute(name = "BalnceAmntType", required = true)
    protected String balnceAmntType;
    @XmlAttribute(name = "Curr")
    protected String curr;

    /**
     * Default no-arg constructor
     * 
     */
    public StatementAdditionalAmountType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public StatementAdditionalAmountType(final double value, final String balnceAmntType, final String curr) {
        this.value = value;
        this.balnceAmntType = balnceAmntType;
        this.curr = curr;
    }

    /**
     *  Used to limit the size of the amounts in
     * 				CurrencyandAmount
     * 			
     * 
     */
    public double getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     */
    public void setValue(double value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return true;
    }

    /**
     * Gets the value of the balnceAmntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalnceAmntType() {
        return balnceAmntType;
    }

    /**
     * Sets the value of the balnceAmntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalnceAmntType(String value) {
        this.balnceAmntType = value;
    }

    public boolean isSetBalnceAmntType() {
        return (this.balnceAmntType!= null);
    }

    /**
     * Gets the value of the curr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurr() {
        return curr;
    }

    /**
     * Sets the value of the curr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurr(String value) {
        this.curr = value;
    }

    public boolean isSetCurr() {
        return (this.curr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("balnceAmntType", balnceAmntType).add("curr", curr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, balnceAmntType, curr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final StatementAdditionalAmountType o = ((StatementAdditionalAmountType) other);
        return ((Objects.equal(value, o.value)&&Objects.equal(balnceAmntType, o.balnceAmntType))&&Objects.equal(curr, o.curr));
    }

}
