
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Clause bénéficiaire
 * 				nominative relative à une garantie
 * 			
 * 
 * <p>Java class for SavingsCoverNamedBeneficiaryClauseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsCoverNamedBeneficiaryClauseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Benfciary" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryMinData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryMinimumDataType" minOccurs="0"/&gt;
 *         &lt;element name="DistrbtnRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="Rnk" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="EqulBnftDistrbtnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="BnftMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitModeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AnntyType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AnnuityTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AnntyDuratnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AnnuityDurationCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="AcceptntIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="AcceptatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="TotCeilingRemvlIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsCoverNamedBeneficiaryClauseType", propOrder = {
    "benfciary",
    "benfciaryMinData",
    "distrbtnRate",
    "rnk",
    "equlBnftDistrbtnIndic",
    "bnftMode",
    "anntyType",
    "anntyDuratnType",
    "amnt",
    "acceptntIndic",
    "acceptatnDate",
    "totCeilingRemvlIndic"
})
public class SavingsCoverNamedBeneficiaryClauseType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Benfciary")
    protected PartyRoleType benfciary;
    @XmlElement(name = "BenfciaryMinData")
    protected BeneficiaryMinimumDataType benfciaryMinData;
    @XmlElement(name = "DistrbtnRate")
    protected Double distrbtnRate;
    @XmlElement(name = "Rnk")
    protected BigInteger rnk;
    @XmlElement(name = "EqulBnftDistrbtnIndic")
    protected String equlBnftDistrbtnIndic;
    @XmlElement(name = "BnftMode")
    protected String bnftMode;
    @XmlElement(name = "AnntyType")
    protected String anntyType;
    @XmlElement(name = "AnntyDuratnType")
    protected String anntyDuratnType;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "AcceptntIndic")
    protected String acceptntIndic;
    @XmlElement(name = "AcceptatnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date acceptatnDate;
    @XmlElement(name = "TotCeilingRemvlIndic")
    protected String totCeilingRemvlIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsCoverNamedBeneficiaryClauseType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsCoverNamedBeneficiaryClauseType(final PartyRoleType benfciary, final BeneficiaryMinimumDataType benfciaryMinData, final Double distrbtnRate, final BigInteger rnk, final String equlBnftDistrbtnIndic, final String bnftMode, final String anntyType, final String anntyDuratnType, final CurrencyAndAmountType amnt, final String acceptntIndic, final Date acceptatnDate, final String totCeilingRemvlIndic) {
        this.benfciary = benfciary;
        this.benfciaryMinData = benfciaryMinData;
        this.distrbtnRate = distrbtnRate;
        this.rnk = rnk;
        this.equlBnftDistrbtnIndic = equlBnftDistrbtnIndic;
        this.bnftMode = bnftMode;
        this.anntyType = anntyType;
        this.anntyDuratnType = anntyDuratnType;
        this.amnt = amnt;
        this.acceptntIndic = acceptntIndic;
        this.acceptatnDate = acceptatnDate;
        this.totCeilingRemvlIndic = totCeilingRemvlIndic;
    }

    /**
     * Gets the value of the benfciary property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getBenfciary() {
        return benfciary;
    }

    /**
     * Sets the value of the benfciary property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setBenfciary(PartyRoleType value) {
        this.benfciary = value;
    }

    public boolean isSetBenfciary() {
        return (this.benfciary!= null);
    }

    /**
     * Gets the value of the benfciaryMinData property.
     * 
     * @return
     *     possible object is
     *     {@link BeneficiaryMinimumDataType }
     *     
     */
    public BeneficiaryMinimumDataType getBenfciaryMinData() {
        return benfciaryMinData;
    }

    /**
     * Sets the value of the benfciaryMinData property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeneficiaryMinimumDataType }
     *     
     */
    public void setBenfciaryMinData(BeneficiaryMinimumDataType value) {
        this.benfciaryMinData = value;
    }

    public boolean isSetBenfciaryMinData() {
        return (this.benfciaryMinData!= null);
    }

    /**
     * Gets the value of the distrbtnRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDistrbtnRate() {
        return distrbtnRate;
    }

    /**
     * Sets the value of the distrbtnRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDistrbtnRate(Double value) {
        this.distrbtnRate = value;
    }

    public boolean isSetDistrbtnRate() {
        return (this.distrbtnRate!= null);
    }

    /**
     * Gets the value of the rnk property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRnk() {
        return rnk;
    }

    /**
     * Sets the value of the rnk property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRnk(BigInteger value) {
        this.rnk = value;
    }

    public boolean isSetRnk() {
        return (this.rnk!= null);
    }

    /**
     * Gets the value of the equlBnftDistrbtnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEqulBnftDistrbtnIndic() {
        return equlBnftDistrbtnIndic;
    }

    /**
     * Sets the value of the equlBnftDistrbtnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEqulBnftDistrbtnIndic(String value) {
        this.equlBnftDistrbtnIndic = value;
    }

    public boolean isSetEqulBnftDistrbtnIndic() {
        return (this.equlBnftDistrbtnIndic!= null);
    }

    /**
     * Gets the value of the bnftMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBnftMode() {
        return bnftMode;
    }

    /**
     * Sets the value of the bnftMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBnftMode(String value) {
        this.bnftMode = value;
    }

    public boolean isSetBnftMode() {
        return (this.bnftMode!= null);
    }

    /**
     * Gets the value of the anntyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnntyType() {
        return anntyType;
    }

    /**
     * Sets the value of the anntyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnntyType(String value) {
        this.anntyType = value;
    }

    public boolean isSetAnntyType() {
        return (this.anntyType!= null);
    }

    /**
     * Gets the value of the anntyDuratnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnntyDuratnType() {
        return anntyDuratnType;
    }

    /**
     * Sets the value of the anntyDuratnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnntyDuratnType(String value) {
        this.anntyDuratnType = value;
    }

    public boolean isSetAnntyDuratnType() {
        return (this.anntyDuratnType!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the acceptntIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcceptntIndic() {
        return acceptntIndic;
    }

    /**
     * Sets the value of the acceptntIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcceptntIndic(String value) {
        this.acceptntIndic = value;
    }

    public boolean isSetAcceptntIndic() {
        return (this.acceptntIndic!= null);
    }

    /**
     * Gets the value of the acceptatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getAcceptatnDate() {
        return acceptatnDate;
    }

    /**
     * Sets the value of the acceptatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcceptatnDate(Date value) {
        this.acceptatnDate = value;
    }

    public boolean isSetAcceptatnDate() {
        return (this.acceptatnDate!= null);
    }

    /**
     * Gets the value of the totCeilingRemvlIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotCeilingRemvlIndic() {
        return totCeilingRemvlIndic;
    }

    /**
     * Sets the value of the totCeilingRemvlIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotCeilingRemvlIndic(String value) {
        this.totCeilingRemvlIndic = value;
    }

    public boolean isSetTotCeilingRemvlIndic() {
        return (this.totCeilingRemvlIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("benfciary", benfciary).add("benfciaryMinData", benfciaryMinData).add("distrbtnRate", distrbtnRate).add("rnk", rnk).add("equlBnftDistrbtnIndic", equlBnftDistrbtnIndic).add("bnftMode", bnftMode).add("anntyType", anntyType).add("anntyDuratnType", anntyDuratnType).add("amnt", amnt).add("acceptntIndic", acceptntIndic).add("acceptatnDate", acceptatnDate).add("totCeilingRemvlIndic", totCeilingRemvlIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(benfciary, benfciaryMinData, distrbtnRate, rnk, equlBnftDistrbtnIndic, bnftMode, anntyType, anntyDuratnType, amnt, acceptntIndic, acceptatnDate, totCeilingRemvlIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsCoverNamedBeneficiaryClauseType o = ((SavingsCoverNamedBeneficiaryClauseType) other);
        return (((((((((((Objects.equal(benfciary, o.benfciary)&&Objects.equal(benfciaryMinData, o.benfciaryMinData))&&Objects.equal(distrbtnRate, o.distrbtnRate))&&Objects.equal(rnk, o.rnk))&&Objects.equal(equlBnftDistrbtnIndic, o.equlBnftDistrbtnIndic))&&Objects.equal(bnftMode, o.bnftMode))&&Objects.equal(anntyType, o.anntyType))&&Objects.equal(anntyDuratnType, o.anntyDuratnType))&&Objects.equal(amnt, o.amnt))&&Objects.equal(acceptntIndic, o.acceptntIndic))&&Objects.equal(acceptatnDate, o.acceptatnDate))&&Objects.equal(totCeilingRemvlIndic, o.totCeilingRemvlIndic));
    }

}
