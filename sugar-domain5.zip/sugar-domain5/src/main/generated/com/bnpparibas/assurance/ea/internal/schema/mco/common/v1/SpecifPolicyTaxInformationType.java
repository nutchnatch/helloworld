
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Tax information which are not common to all
 * 				countries
 * 			
 * 
 * <p>Java class for SpecifPolicyTaxInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SpecifPolicyTaxInformationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FiscalYearType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="TaxationMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxationOptionTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FiscalRegim" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FiscalRegimCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecifPolicyTaxInformationType", propOrder = {
    "fiscalYearType",
    "taxationMode",
    "fiscalRegim"
})
public class SpecifPolicyTaxInformationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FiscalYearType")
    protected String fiscalYearType;
    @XmlElement(name = "TaxationMode")
    protected String taxationMode;
    @XmlElement(name = "FiscalRegim")
    protected String fiscalRegim;

    /**
     * Default no-arg constructor
     * 
     */
    public SpecifPolicyTaxInformationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SpecifPolicyTaxInformationType(final String fiscalYearType, final String taxationMode, final String fiscalRegim) {
        this.fiscalYearType = fiscalYearType;
        this.taxationMode = taxationMode;
        this.fiscalRegim = fiscalRegim;
    }

    /**
     * Gets the value of the fiscalYearType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFiscalYearType() {
        return fiscalYearType;
    }

    /**
     * Sets the value of the fiscalYearType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFiscalYearType(String value) {
        this.fiscalYearType = value;
    }

    public boolean isSetFiscalYearType() {
        return (this.fiscalYearType!= null);
    }

    /**
     * Gets the value of the taxationMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxationMode() {
        return taxationMode;
    }

    /**
     * Sets the value of the taxationMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxationMode(String value) {
        this.taxationMode = value;
    }

    public boolean isSetTaxationMode() {
        return (this.taxationMode!= null);
    }

    /**
     * Gets the value of the fiscalRegim property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFiscalRegim() {
        return fiscalRegim;
    }

    /**
     * Sets the value of the fiscalRegim property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFiscalRegim(String value) {
        this.fiscalRegim = value;
    }

    public boolean isSetFiscalRegim() {
        return (this.fiscalRegim!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fiscalYearType", fiscalYearType).add("taxationMode", taxationMode).add("fiscalRegim", fiscalRegim).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fiscalYearType, taxationMode, fiscalRegim);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SpecifPolicyTaxInformationType o = ((SpecifPolicyTaxInformationType) other);
        return ((Objects.equal(fiscalYearType, o.fiscalYearType)&&Objects.equal(taxationMode, o.taxationMode))&&Objects.equal(fiscalRegim, o.fiscalRegim));
    }

}
