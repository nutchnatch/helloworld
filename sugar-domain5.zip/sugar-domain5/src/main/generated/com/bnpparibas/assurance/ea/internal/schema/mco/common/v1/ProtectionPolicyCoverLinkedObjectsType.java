
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a protection policy cover has
 * 				dependencies
 * 			
 * 
 * <p>Java class for ProtectionPolicyCoverLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyCoverLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Insrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsuredType" minOccurs="0"/&gt;
 *         &lt;element name="Insurer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="LoanlIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="GrpPol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GroupPolicySharedDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="InsrdObjct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsuredObjectDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PricList" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPolicyCoverPriceListType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LoanCollateralPolicy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanCollateralPolicyType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyCoverLinkedObjectsType", propOrder = {
    "insrd",
    "insurer",
    "loanlIdntfctn",
    "grpPol",
    "insrdObjct",
    "pricList",
    "loanCollateralPolicy"
})
public class ProtectionPolicyCoverLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Insrd")
    protected InsuredType insrd;
    @XmlElement(name = "Insurer")
    protected PartyRoleType insurer;
    @XmlElement(name = "LoanlIdntfctn")
    protected ObjectIdentificationType loanlIdntfctn;
    @XmlElement(name = "GrpPol")
    protected List<GroupPolicySharedDataType> grpPol;
    @XmlElement(name = "InsrdObjct")
    protected List<InsuredObjectDataType> insrdObjct;
    @XmlElement(name = "PricList")
    protected List<ProtectionPolicyCoverPriceListType> pricList;
    @XmlElement(name = "LoanCollateralPolicy")
    protected List<LoanCollateralPolicyType> loanCollateralPolicy;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyCoverLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyCoverLinkedObjectsType(final InsuredType insrd, final PartyRoleType insurer, final ObjectIdentificationType loanlIdntfctn, final List<GroupPolicySharedDataType> grpPol, final List<InsuredObjectDataType> insrdObjct, final List<ProtectionPolicyCoverPriceListType> pricList, final List<LoanCollateralPolicyType> loanCollateralPolicy) {
        this.insrd = insrd;
        this.insurer = insurer;
        this.loanlIdntfctn = loanlIdntfctn;
        this.grpPol = grpPol;
        this.insrdObjct = insrdObjct;
        this.pricList = pricList;
        this.loanCollateralPolicy = loanCollateralPolicy;
    }

    /**
     * Gets the value of the insrd property.
     * 
     * @return
     *     possible object is
     *     {@link InsuredType }
     *     
     */
    public InsuredType getInsrd() {
        return insrd;
    }

    /**
     * Sets the value of the insrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link InsuredType }
     *     
     */
    public void setInsrd(InsuredType value) {
        this.insrd = value;
    }

    public boolean isSetInsrd() {
        return (this.insrd!= null);
    }

    /**
     * Gets the value of the insurer property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsurer() {
        return insurer;
    }

    /**
     * Sets the value of the insurer property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsurer(PartyRoleType value) {
        this.insurer = value;
    }

    public boolean isSetInsurer() {
        return (this.insurer!= null);
    }

    /**
     * Gets the value of the loanlIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getLoanlIdntfctn() {
        return loanlIdntfctn;
    }

    /**
     * Sets the value of the loanlIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setLoanlIdntfctn(ObjectIdentificationType value) {
        this.loanlIdntfctn = value;
    }

    public boolean isSetLoanlIdntfctn() {
        return (this.loanlIdntfctn!= null);
    }

    /**
     * Gets the value of the grpPol property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the grpPol property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGrpPol().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GroupPolicySharedDataType }
     * 
     * 
     */
    public List<GroupPolicySharedDataType> getGrpPol() {
        if (grpPol == null) {
            grpPol = new ArrayList<GroupPolicySharedDataType>();
        }
        return this.grpPol;
    }

    public boolean isSetGrpPol() {
        return ((this.grpPol!= null)&&(!this.grpPol.isEmpty()));
    }

    public void unsetGrpPol() {
        this.grpPol = null;
    }

    /**
     * Gets the value of the insrdObjct property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the insrdObjct property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInsrdObjct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InsuredObjectDataType }
     * 
     * 
     */
    public List<InsuredObjectDataType> getInsrdObjct() {
        if (insrdObjct == null) {
            insrdObjct = new ArrayList<InsuredObjectDataType>();
        }
        return this.insrdObjct;
    }

    public boolean isSetInsrdObjct() {
        return ((this.insrdObjct!= null)&&(!this.insrdObjct.isEmpty()));
    }

    public void unsetInsrdObjct() {
        this.insrdObjct = null;
    }

    /**
     * Gets the value of the pricList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pricList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPricList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProtectionPolicyCoverPriceListType }
     * 
     * 
     */
    public List<ProtectionPolicyCoverPriceListType> getPricList() {
        if (pricList == null) {
            pricList = new ArrayList<ProtectionPolicyCoverPriceListType>();
        }
        return this.pricList;
    }

    public boolean isSetPricList() {
        return ((this.pricList!= null)&&(!this.pricList.isEmpty()));
    }

    public void unsetPricList() {
        this.pricList = null;
    }

    /**
     * Gets the value of the loanCollateralPolicy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the loanCollateralPolicy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLoanCollateralPolicy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LoanCollateralPolicyType }
     * 
     * 
     */
    public List<LoanCollateralPolicyType> getLoanCollateralPolicy() {
        if (loanCollateralPolicy == null) {
            loanCollateralPolicy = new ArrayList<LoanCollateralPolicyType>();
        }
        return this.loanCollateralPolicy;
    }

    public boolean isSetLoanCollateralPolicy() {
        return ((this.loanCollateralPolicy!= null)&&(!this.loanCollateralPolicy.isEmpty()));
    }

    public void unsetLoanCollateralPolicy() {
        this.loanCollateralPolicy = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("insrd", insrd).add("insurer", insurer).add("loanlIdntfctn", loanlIdntfctn).add("grpPol", grpPol).add("insrdObjct", insrdObjct).add("pricList", pricList).add("loanCollateralPolicy", loanCollateralPolicy).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(insrd, insurer, loanlIdntfctn, grpPol, insrdObjct, pricList, loanCollateralPolicy);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyCoverLinkedObjectsType o = ((ProtectionPolicyCoverLinkedObjectsType) other);
        return ((((((Objects.equal(insrd, o.insrd)&&Objects.equal(insurer, o.insurer))&&Objects.equal(loanlIdntfctn, o.loanlIdntfctn))&&Objects.equal(grpPol, o.grpPol))&&Objects.equal(insrdObjct, o.insrdObjct))&&Objects.equal(pricList, o.pricList))&&Objects.equal(loanCollateralPolicy, o.loanCollateralPolicy));
    }

}
