
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Tax information at policy level
 * 
 * <p>Java class for PolicyTaxInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyTaxInformationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FiscalEffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="FiscalEndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyTaxInformationType", propOrder = {
    "fiscalEffctveDate",
    "fiscalEndDate"
})
public class PolicyTaxInformationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FiscalEffctveDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date fiscalEffctveDate;
    @XmlElement(name = "FiscalEndDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date fiscalEndDate;

    /**
     * Default no-arg constructor
     * 
     */
    public PolicyTaxInformationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PolicyTaxInformationType(final Date fiscalEffctveDate, final Date fiscalEndDate) {
        this.fiscalEffctveDate = fiscalEffctveDate;
        this.fiscalEndDate = fiscalEndDate;
    }

    /**
     * Gets the value of the fiscalEffctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getFiscalEffctveDate() {
        return fiscalEffctveDate;
    }

    /**
     * Sets the value of the fiscalEffctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFiscalEffctveDate(Date value) {
        this.fiscalEffctveDate = value;
    }

    public boolean isSetFiscalEffctveDate() {
        return (this.fiscalEffctveDate!= null);
    }

    /**
     * Gets the value of the fiscalEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getFiscalEndDate() {
        return fiscalEndDate;
    }

    /**
     * Sets the value of the fiscalEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFiscalEndDate(Date value) {
        this.fiscalEndDate = value;
    }

    public boolean isSetFiscalEndDate() {
        return (this.fiscalEndDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fiscalEffctveDate", fiscalEffctveDate).add("fiscalEndDate", fiscalEndDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fiscalEffctveDate, fiscalEndDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PolicyTaxInformationType o = ((PolicyTaxInformationType) other);
        return (Objects.equal(fiscalEffctveDate, o.fiscalEffctveDate)&&Objects.equal(fiscalEndDate, o.fiscalEndDate));
    }

}
