
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage values that can be a rate, an amount
 * 				or a units number
 * 			
 * 
 * <p>Java class for ValueDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ValueDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="UnitNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="AmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValueDataType", propOrder = {
    "rate",
    "unitNumb",
    "amnt",
    "amntType"
})
public class ValueDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Rate")
    protected Double rate;
    @XmlElement(name = "UnitNumb")
    protected Double unitNumb;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "AmntType")
    protected String amntType;

    /**
     * Default no-arg constructor
     * 
     */
    public ValueDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ValueDataType(final Double rate, final Double unitNumb, final CurrencyAndAmountType amnt, final String amntType) {
        this.rate = rate;
        this.unitNumb = unitNumb;
        this.amnt = amnt;
        this.amntType = amntType;
    }

    /**
     * Gets the value of the rate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getRate() {
        return rate;
    }

    /**
     * Sets the value of the rate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setRate(Double value) {
        this.rate = value;
    }

    public boolean isSetRate() {
        return (this.rate!= null);
    }

    /**
     * Gets the value of the unitNumb property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUnitNumb() {
        return unitNumb;
    }

    /**
     * Sets the value of the unitNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUnitNumb(Double value) {
        this.unitNumb = value;
    }

    public boolean isSetUnitNumb() {
        return (this.unitNumb!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the amntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmntType() {
        return amntType;
    }

    /**
     * Sets the value of the amntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmntType(String value) {
        this.amntType = value;
    }

    public boolean isSetAmntType() {
        return (this.amntType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("rate", rate).add("unitNumb", unitNumb).add("amnt", amnt).add("amntType", amntType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(rate, unitNumb, amnt, amntType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ValueDataType o = ((ValueDataType) other);
        return (((Objects.equal(rate, o.rate)&&Objects.equal(unitNumb, o.unitNumb))&&Objects.equal(amnt, o.amnt))&&Objects.equal(amntType, o.amntType));
    }

}
