
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a protection policy has
 * 				dependencies
 * 			
 * 
 * <p>Java class for ProtectionPolicyLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductSharedDataType"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductIdentificationAndHierarchyDataType" minOccurs="0"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Cust" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExtendedPersonIdentificationAndRoleType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="GrpPol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GroupPolicySharedDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ComrclOffer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommercialOfferSharedDataApplicationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CurntEndrsmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyEndorsementDataType" minOccurs="0"/&gt;
 *         &lt;element name="StdCondtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StandardConditionDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyLinkedObjectsType", propOrder = {
    "pdct",
    "corePdct",
    "distrbtr",
    "prdctr",
    "cust",
    "grpPol",
    "comrclOffer",
    "curntEndrsmnt",
    "stdCondtn"
})
public class ProtectionPolicyLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct", required = true)
    protected ProductSharedDataType pdct;
    @XmlElement(name = "CorePdct")
    protected CoreProductIdentificationAndHierarchyDataType corePdct;
    @XmlElement(name = "Distrbtr")
    protected List<PartnerPartyType> distrbtr;
    @XmlElement(name = "Prdctr", required = true)
    protected PartyRoleType prdctr;
    @XmlElement(name = "Cust", required = true)
    protected List<ExtendedPersonIdentificationAndRoleType> cust;
    @XmlElement(name = "GrpPol")
    protected List<GroupPolicySharedDataType> grpPol;
    @XmlElement(name = "ComrclOffer")
    protected List<CommercialOfferSharedDataApplicationType> comrclOffer;
    @XmlElement(name = "CurntEndrsmnt")
    protected PolicyEndorsementDataType curntEndrsmnt;
    @XmlElement(name = "StdCondtn")
    protected List<StandardConditionDataType> stdCondtn;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyLinkedObjectsType(final ProductSharedDataType pdct, final CoreProductIdentificationAndHierarchyDataType corePdct, final List<PartnerPartyType> distrbtr, final PartyRoleType prdctr, final List<ExtendedPersonIdentificationAndRoleType> cust, final List<GroupPolicySharedDataType> grpPol, final List<CommercialOfferSharedDataApplicationType> comrclOffer, final PolicyEndorsementDataType curntEndrsmnt, final List<StandardConditionDataType> stdCondtn) {
        this.pdct = pdct;
        this.corePdct = corePdct;
        this.distrbtr = distrbtr;
        this.prdctr = prdctr;
        this.cust = cust;
        this.grpPol = grpPol;
        this.comrclOffer = comrclOffer;
        this.curntEndrsmnt = curntEndrsmnt;
        this.stdCondtn = stdCondtn;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductSharedDataType }
     *     
     */
    public ProductSharedDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductSharedDataType }
     *     
     */
    public void setPdct(ProductSharedDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public CoreProductIdentificationAndHierarchyDataType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public void setCorePdct(CoreProductIdentificationAndHierarchyDataType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the distrbtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDistrbtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getDistrbtr() {
        if (distrbtr == null) {
            distrbtr = new ArrayList<PartnerPartyType>();
        }
        return this.distrbtr;
    }

    public boolean isSetDistrbtr() {
        return ((this.distrbtr!= null)&&(!this.distrbtr.isEmpty()));
    }

    public void unsetDistrbtr() {
        this.distrbtr = null;
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    /**
     * Gets the value of the cust property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cust property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCust().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExtendedPersonIdentificationAndRoleType }
     * 
     * 
     */
    public List<ExtendedPersonIdentificationAndRoleType> getCust() {
        if (cust == null) {
            cust = new ArrayList<ExtendedPersonIdentificationAndRoleType>();
        }
        return this.cust;
    }

    public boolean isSetCust() {
        return ((this.cust!= null)&&(!this.cust.isEmpty()));
    }

    public void unsetCust() {
        this.cust = null;
    }

    /**
     * Gets the value of the grpPol property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the grpPol property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGrpPol().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GroupPolicySharedDataType }
     * 
     * 
     */
    public List<GroupPolicySharedDataType> getGrpPol() {
        if (grpPol == null) {
            grpPol = new ArrayList<GroupPolicySharedDataType>();
        }
        return this.grpPol;
    }

    public boolean isSetGrpPol() {
        return ((this.grpPol!= null)&&(!this.grpPol.isEmpty()));
    }

    public void unsetGrpPol() {
        this.grpPol = null;
    }

    /**
     * Gets the value of the comrclOffer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comrclOffer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComrclOffer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommercialOfferSharedDataApplicationType }
     * 
     * 
     */
    public List<CommercialOfferSharedDataApplicationType> getComrclOffer() {
        if (comrclOffer == null) {
            comrclOffer = new ArrayList<CommercialOfferSharedDataApplicationType>();
        }
        return this.comrclOffer;
    }

    public boolean isSetComrclOffer() {
        return ((this.comrclOffer!= null)&&(!this.comrclOffer.isEmpty()));
    }

    public void unsetComrclOffer() {
        this.comrclOffer = null;
    }

    /**
     * Gets the value of the curntEndrsmnt property.
     * 
     * @return
     *     possible object is
     *     {@link PolicyEndorsementDataType }
     *     
     */
    public PolicyEndorsementDataType getCurntEndrsmnt() {
        return curntEndrsmnt;
    }

    /**
     * Sets the value of the curntEndrsmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link PolicyEndorsementDataType }
     *     
     */
    public void setCurntEndrsmnt(PolicyEndorsementDataType value) {
        this.curntEndrsmnt = value;
    }

    public boolean isSetCurntEndrsmnt() {
        return (this.curntEndrsmnt!= null);
    }

    /**
     * Gets the value of the stdCondtn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stdCondtn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStdCondtn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StandardConditionDataType }
     * 
     * 
     */
    public List<StandardConditionDataType> getStdCondtn() {
        if (stdCondtn == null) {
            stdCondtn = new ArrayList<StandardConditionDataType>();
        }
        return this.stdCondtn;
    }

    public boolean isSetStdCondtn() {
        return ((this.stdCondtn!= null)&&(!this.stdCondtn.isEmpty()));
    }

    public void unsetStdCondtn() {
        this.stdCondtn = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("corePdct", corePdct).add("distrbtr", distrbtr).add("prdctr", prdctr).add("cust", cust).add("grpPol", grpPol).add("comrclOffer", comrclOffer).add("curntEndrsmnt", curntEndrsmnt).add("stdCondtn", stdCondtn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, corePdct, distrbtr, prdctr, cust, grpPol, comrclOffer, curntEndrsmnt, stdCondtn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyLinkedObjectsType o = ((ProtectionPolicyLinkedObjectsType) other);
        return ((((((((Objects.equal(pdct, o.pdct)&&Objects.equal(corePdct, o.corePdct))&&Objects.equal(distrbtr, o.distrbtr))&&Objects.equal(prdctr, o.prdctr))&&Objects.equal(cust, o.cust))&&Objects.equal(grpPol, o.grpPol))&&Objects.equal(comrclOffer, o.comrclOffer))&&Objects.equal(curntEndrsmnt, o.curntEndrsmnt))&&Objects.equal(stdCondtn, o.stdCondtn));
    }

}
