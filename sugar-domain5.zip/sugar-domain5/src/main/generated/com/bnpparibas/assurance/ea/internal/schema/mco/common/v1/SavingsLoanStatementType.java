
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on loan statement
 * 			
 * 
 * <p>Java class for SavingsLoanStatementType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsLoanStatementType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LoanIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Balnce" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsLoanBalanceType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsLoanStatementType", propOrder = {
    "loanIdntfctn",
    "balnce"
})
public class SavingsLoanStatementType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "LoanIdntfctn", required = true)
    protected ObjectIdentificationType loanIdntfctn;
    @XmlElement(name = "Balnce")
    protected List<SavingsLoanBalanceType> balnce;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsLoanStatementType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsLoanStatementType(final ObjectIdentificationType loanIdntfctn, final List<SavingsLoanBalanceType> balnce) {
        this.loanIdntfctn = loanIdntfctn;
        this.balnce = balnce;
    }

    /**
     * Gets the value of the loanIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getLoanIdntfctn() {
        return loanIdntfctn;
    }

    /**
     * Sets the value of the loanIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setLoanIdntfctn(ObjectIdentificationType value) {
        this.loanIdntfctn = value;
    }

    public boolean isSetLoanIdntfctn() {
        return (this.loanIdntfctn!= null);
    }

    /**
     * Gets the value of the balnce property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the balnce property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBalnce().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SavingsLoanBalanceType }
     * 
     * 
     */
    public List<SavingsLoanBalanceType> getBalnce() {
        if (balnce == null) {
            balnce = new ArrayList<SavingsLoanBalanceType>();
        }
        return this.balnce;
    }

    public boolean isSetBalnce() {
        return ((this.balnce!= null)&&(!this.balnce.isEmpty()));
    }

    public void unsetBalnce() {
        this.balnce = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("loanIdntfctn", loanIdntfctn).add("balnce", balnce).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(loanIdntfctn, balnce);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsLoanStatementType o = ((SavingsLoanStatementType) other);
        return (Objects.equal(loanIdntfctn, o.loanIdntfctn)&&Objects.equal(balnce, o.balnce));
    }

}
