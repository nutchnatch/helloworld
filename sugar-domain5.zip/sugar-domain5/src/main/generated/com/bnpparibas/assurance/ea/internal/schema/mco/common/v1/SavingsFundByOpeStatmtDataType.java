
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Détails des données par
 * 				opération pour un support
 * 			
 * 
 * <p>Java class for SavingsFundByOpeStatmtDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsFundByOpeStatmtDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BalanceTypeCode"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="OpeFund" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsFundByOpeDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsFundByOpeStatmtDataType", propOrder = {
    "amntType",
    "amnt",
    "opeFund"
})
public class SavingsFundByOpeStatmtDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "AmntType", required = true)
    protected String amntType;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "OpeFund")
    protected List<SavingsFundByOpeDataType> opeFund;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsFundByOpeStatmtDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsFundByOpeStatmtDataType(final String amntType, final CurrencyAndAmountType amnt, final List<SavingsFundByOpeDataType> opeFund) {
        this.amntType = amntType;
        this.amnt = amnt;
        this.opeFund = opeFund;
    }

    /**
     * Gets the value of the amntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmntType() {
        return amntType;
    }

    /**
     * Sets the value of the amntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmntType(String value) {
        this.amntType = value;
    }

    public boolean isSetAmntType() {
        return (this.amntType!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the opeFund property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the opeFund property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOpeFund().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SavingsFundByOpeDataType }
     * 
     * 
     */
    public List<SavingsFundByOpeDataType> getOpeFund() {
        if (opeFund == null) {
            opeFund = new ArrayList<SavingsFundByOpeDataType>();
        }
        return this.opeFund;
    }

    public boolean isSetOpeFund() {
        return ((this.opeFund!= null)&&(!this.opeFund.isEmpty()));
    }

    public void unsetOpeFund() {
        this.opeFund = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("amntType", amntType).add("amnt", amnt).add("opeFund", opeFund).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(amntType, amnt, opeFund);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsFundByOpeStatmtDataType o = ((SavingsFundByOpeStatmtDataType) other);
        return ((Objects.equal(amntType, o.amntType)&&Objects.equal(amnt, o.amnt))&&Objects.equal(opeFund, o.opeFund));
    }

}
