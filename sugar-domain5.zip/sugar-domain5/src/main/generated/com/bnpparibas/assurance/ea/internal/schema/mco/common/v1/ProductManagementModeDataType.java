
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Management mode of the product : pure individuel,
 * 				pure groupe, individual group
 * 			
 * 
 * <p>Java class for ProductManagementModeDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductManagementModeDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Mode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ContractualRelationshipTypeCodeSLN"/&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductManagementModeDataType", propOrder = {
    "mode",
    "applctnPrd"
})
public class ProductManagementModeDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Mode", required = true)
    protected String mode;
    @XmlElement(name = "ApplctnPrd")
    protected DatePeriodType applctnPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ProductManagementModeDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProductManagementModeDataType(final String mode, final DatePeriodType applctnPrd) {
        this.mode = mode;
        this.applctnPrd = applctnPrd;
    }

    /**
     * Gets the value of the mode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMode() {
        return mode;
    }

    /**
     * Sets the value of the mode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMode(String value) {
        this.mode = value;
    }

    public boolean isSetMode() {
        return (this.mode!= null);
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("mode", mode).add("applctnPrd", applctnPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mode, applctnPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProductManagementModeDataType o = ((ProductManagementModeDataType) other);
        return (Objects.equal(mode, o.mode)&&Objects.equal(applctnPrd, o.applctnPrd));
    }

}
