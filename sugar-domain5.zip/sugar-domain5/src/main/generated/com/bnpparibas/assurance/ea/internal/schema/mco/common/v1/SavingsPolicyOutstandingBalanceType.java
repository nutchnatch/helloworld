
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on the outstanding balance
 * 				amounts for savings policy
 * 			
 * 
 * <p>Java class for SavingsPolicyOutstandingBalanceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyOutstandingBalanceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RefPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReferencePeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="BalnceType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BalanceTypeCode"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyOutstandingBalanceType", propOrder = {
    "refPrd",
    "balnceType",
    "amnt"
})
public class SavingsPolicyOutstandingBalanceType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "RefPrd")
    protected String refPrd;
    @XmlElement(name = "BalnceType", required = true)
    protected String balnceType;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyOutstandingBalanceType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyOutstandingBalanceType(final String refPrd, final String balnceType, final CurrencyAndAmountType amnt) {
        this.refPrd = refPrd;
        this.balnceType = balnceType;
        this.amnt = amnt;
    }

    /**
     * Gets the value of the refPrd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefPrd() {
        return refPrd;
    }

    /**
     * Sets the value of the refPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefPrd(String value) {
        this.refPrd = value;
    }

    public boolean isSetRefPrd() {
        return (this.refPrd!= null);
    }

    /**
     * Gets the value of the balnceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalnceType() {
        return balnceType;
    }

    /**
     * Sets the value of the balnceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalnceType(String value) {
        this.balnceType = value;
    }

    public boolean isSetBalnceType() {
        return (this.balnceType!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("refPrd", refPrd).add("balnceType", balnceType).add("amnt", amnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(refPrd, balnceType, amnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyOutstandingBalanceType o = ((SavingsPolicyOutstandingBalanceType) other);
        return ((Objects.equal(refPrd, o.refPrd)&&Objects.equal(balnceType, o.balnceType))&&Objects.equal(amnt, o.amnt));
    }

}
