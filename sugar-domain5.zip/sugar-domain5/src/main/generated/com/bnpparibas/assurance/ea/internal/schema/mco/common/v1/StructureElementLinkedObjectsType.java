
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage links tha can have a structure
 * 				element with other objects
 * 			
 * 
 * <p>Java class for StructureElementLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StructureElementLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MainStruct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MainStructureDataType"/&gt;
 *         &lt;element name="CorrspndntPrty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="ElmtParnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StructureElementParentType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StructureElementLinkedObjectsType", propOrder = {
    "mainStruct",
    "corrspndntPrty",
    "elmtParnt"
})
public class StructureElementLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "MainStruct", required = true)
    protected MainStructureDataType mainStruct;
    @XmlElement(name = "CorrspndntPrty")
    protected PartyRoleType corrspndntPrty;
    @XmlElement(name = "ElmtParnt")
    protected List<StructureElementParentType> elmtParnt;

    /**
     * Default no-arg constructor
     * 
     */
    public StructureElementLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public StructureElementLinkedObjectsType(final MainStructureDataType mainStruct, final PartyRoleType corrspndntPrty, final List<StructureElementParentType> elmtParnt) {
        this.mainStruct = mainStruct;
        this.corrspndntPrty = corrspndntPrty;
        this.elmtParnt = elmtParnt;
    }

    /**
     * Gets the value of the mainStruct property.
     * 
     * @return
     *     possible object is
     *     {@link MainStructureDataType }
     *     
     */
    public MainStructureDataType getMainStruct() {
        return mainStruct;
    }

    /**
     * Sets the value of the mainStruct property.
     * 
     * @param value
     *     allowed object is
     *     {@link MainStructureDataType }
     *     
     */
    public void setMainStruct(MainStructureDataType value) {
        this.mainStruct = value;
    }

    public boolean isSetMainStruct() {
        return (this.mainStruct!= null);
    }

    /**
     * Gets the value of the corrspndntPrty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getCorrspndntPrty() {
        return corrspndntPrty;
    }

    /**
     * Sets the value of the corrspndntPrty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setCorrspndntPrty(PartyRoleType value) {
        this.corrspndntPrty = value;
    }

    public boolean isSetCorrspndntPrty() {
        return (this.corrspndntPrty!= null);
    }

    /**
     * Gets the value of the elmtParnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the elmtParnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getElmtParnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StructureElementParentType }
     * 
     * 
     */
    public List<StructureElementParentType> getElmtParnt() {
        if (elmtParnt == null) {
            elmtParnt = new ArrayList<StructureElementParentType>();
        }
        return this.elmtParnt;
    }

    public boolean isSetElmtParnt() {
        return ((this.elmtParnt!= null)&&(!this.elmtParnt.isEmpty()));
    }

    public void unsetElmtParnt() {
        this.elmtParnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("mainStruct", mainStruct).add("corrspndntPrty", corrspndntPrty).add("elmtParnt", elmtParnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mainStruct, corrspndntPrty, elmtParnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final StructureElementLinkedObjectsType o = ((StructureElementLinkedObjectsType) other);
        return ((Objects.equal(mainStruct, o.mainStruct)&&Objects.equal(corrspndntPrty, o.corrspndntPrty))&&Objects.equal(elmtParnt, o.elmtParnt));
    }

}
