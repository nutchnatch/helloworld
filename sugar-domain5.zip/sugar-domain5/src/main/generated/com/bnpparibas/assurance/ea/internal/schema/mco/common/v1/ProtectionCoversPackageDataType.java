
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data of a package of covers linked
 * 				to a simplified protection prioduct
 * 			
 * 
 * <p>Java class for ProtectionCoversPackageDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionCoversPackageDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="CovIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductRiskIdentificationDataType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="MarktngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionCoversPackageDataType", propOrder = {
    "id",
    "name",
    "covIdntfctn",
    "marktngPrd"
})
public class ProtectionCoversPackageDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id", required = true)
    protected String id;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "CovIdntfctn", required = true)
    protected List<ProductRiskIdentificationDataType> covIdntfctn;
    @XmlElement(name = "MarktngPrd")
    protected DatePeriodType marktngPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionCoversPackageDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionCoversPackageDataType(final String id, final String name, final List<ProductRiskIdentificationDataType> covIdntfctn, final DatePeriodType marktngPrd) {
        this.id = id;
        this.name = name;
        this.covIdntfctn = covIdntfctn;
        this.marktngPrd = marktngPrd;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the covIdntfctn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covIdntfctn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovIdntfctn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductRiskIdentificationDataType }
     * 
     * 
     */
    public List<ProductRiskIdentificationDataType> getCovIdntfctn() {
        if (covIdntfctn == null) {
            covIdntfctn = new ArrayList<ProductRiskIdentificationDataType>();
        }
        return this.covIdntfctn;
    }

    public boolean isSetCovIdntfctn() {
        return ((this.covIdntfctn!= null)&&(!this.covIdntfctn.isEmpty()));
    }

    public void unsetCovIdntfctn() {
        this.covIdntfctn = null;
    }

    /**
     * Gets the value of the marktngPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getMarktngPrd() {
        return marktngPrd;
    }

    /**
     * Sets the value of the marktngPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setMarktngPrd(DatePeriodType value) {
        this.marktngPrd = value;
    }

    public boolean isSetMarktngPrd() {
        return (this.marktngPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("name", name).add("covIdntfctn", covIdntfctn).add("marktngPrd", marktngPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, name, covIdntfctn, marktngPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionCoversPackageDataType o = ((ProtectionCoversPackageDataType) other);
        return (((Objects.equal(id, o.id)&&Objects.equal(name, o.name))&&Objects.equal(covIdntfctn, o.covIdntfctn))&&Objects.equal(marktngPrd, o.marktngPrd));
    }

}
