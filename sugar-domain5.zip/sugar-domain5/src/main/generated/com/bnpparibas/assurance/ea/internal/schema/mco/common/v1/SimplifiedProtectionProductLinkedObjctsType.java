
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage links between simplified protection
 * 				product and other objects
 * 			
 * 
 * <p>Java class for SimplifiedProtectionProductLinkedObjctsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SimplifiedProtectionProductLinkedObjctsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Prdcr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SimplifiedProtectionProductLinkedObjctsType", propOrder = {
    "prdcr",
    "corePdct"
})
public class SimplifiedProtectionProductLinkedObjctsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Prdcr", required = true)
    protected PartyRoleType prdcr;
    @XmlElement(name = "CorePdct")
    protected ObjectIdentificationWithVersionType corePdct;

    /**
     * Default no-arg constructor
     * 
     */
    public SimplifiedProtectionProductLinkedObjctsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SimplifiedProtectionProductLinkedObjctsType(final PartyRoleType prdcr, final ObjectIdentificationWithVersionType corePdct) {
        this.prdcr = prdcr;
        this.corePdct = corePdct;
    }

    /**
     * Gets the value of the prdcr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdcr() {
        return prdcr;
    }

    /**
     * Sets the value of the prdcr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdcr(PartyRoleType value) {
        this.prdcr = value;
    }

    public boolean isSetPrdcr() {
        return (this.prdcr!= null);
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setCorePdct(ObjectIdentificationWithVersionType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("prdcr", prdcr).add("corePdct", corePdct).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(prdcr, corePdct);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SimplifiedProtectionProductLinkedObjctsType o = ((SimplifiedProtectionProductLinkedObjctsType) other);
        return (Objects.equal(prdcr, o.prdcr)&&Objects.equal(corePdct, o.corePdct));
    }

}
