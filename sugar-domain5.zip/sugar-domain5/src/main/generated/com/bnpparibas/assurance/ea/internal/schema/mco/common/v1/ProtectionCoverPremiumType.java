
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Cover Premium type
 * 
 * <p>Java class for ProtectionCoverPremiumType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionCoverPremiumType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationCoverIdentificationType"/&gt;
 *         &lt;element name="LinkdObjcts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionCoverPremiumLinkedObjectsType" minOccurs="0"/&gt;
 *         &lt;element name="PremData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionCoverPremiumDataType"/&gt;
 *         &lt;element name="ExtraPrem" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionExtraPremiumDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CovFee" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeeType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CovTax" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionCoverPremiumType", propOrder = {
    "covIdntfctn",
    "linkdObjcts",
    "premData",
    "extraPrem",
    "covFee",
    "covTax"
})
public class ProtectionCoverPremiumType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovIdntfctn", required = true)
    protected OperationCoverIdentificationType covIdntfctn;
    @XmlElement(name = "LinkdObjcts")
    protected ProtectionCoverPremiumLinkedObjectsType linkdObjcts;
    @XmlElement(name = "PremData", required = true)
    protected ProtectionCoverPremiumDataType premData;
    @XmlElement(name = "ExtraPrem")
    protected List<ProtectionExtraPremiumDataType> extraPrem;
    @XmlElement(name = "CovFee")
    protected List<FeeType> covFee;
    @XmlElement(name = "CovTax")
    protected List<TaxType> covTax;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionCoverPremiumType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionCoverPremiumType(final OperationCoverIdentificationType covIdntfctn, final ProtectionCoverPremiumLinkedObjectsType linkdObjcts, final ProtectionCoverPremiumDataType premData, final List<ProtectionExtraPremiumDataType> extraPrem, final List<FeeType> covFee, final List<TaxType> covTax) {
        this.covIdntfctn = covIdntfctn;
        this.linkdObjcts = linkdObjcts;
        this.premData = premData;
        this.extraPrem = extraPrem;
        this.covFee = covFee;
        this.covTax = covTax;
    }

    /**
     * Gets the value of the covIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link OperationCoverIdentificationType }
     *     
     */
    public OperationCoverIdentificationType getCovIdntfctn() {
        return covIdntfctn;
    }

    /**
     * Sets the value of the covIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationCoverIdentificationType }
     *     
     */
    public void setCovIdntfctn(OperationCoverIdentificationType value) {
        this.covIdntfctn = value;
    }

    public boolean isSetCovIdntfctn() {
        return (this.covIdntfctn!= null);
    }

    /**
     * Gets the value of the linkdObjcts property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionCoverPremiumLinkedObjectsType }
     *     
     */
    public ProtectionCoverPremiumLinkedObjectsType getLinkdObjcts() {
        return linkdObjcts;
    }

    /**
     * Sets the value of the linkdObjcts property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionCoverPremiumLinkedObjectsType }
     *     
     */
    public void setLinkdObjcts(ProtectionCoverPremiumLinkedObjectsType value) {
        this.linkdObjcts = value;
    }

    public boolean isSetLinkdObjcts() {
        return (this.linkdObjcts!= null);
    }

    /**
     * Gets the value of the premData property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionCoverPremiumDataType }
     *     
     */
    public ProtectionCoverPremiumDataType getPremData() {
        return premData;
    }

    /**
     * Sets the value of the premData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionCoverPremiumDataType }
     *     
     */
    public void setPremData(ProtectionCoverPremiumDataType value) {
        this.premData = value;
    }

    public boolean isSetPremData() {
        return (this.premData!= null);
    }

    /**
     * Gets the value of the extraPrem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the extraPrem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExtraPrem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProtectionExtraPremiumDataType }
     * 
     * 
     */
    public List<ProtectionExtraPremiumDataType> getExtraPrem() {
        if (extraPrem == null) {
            extraPrem = new ArrayList<ProtectionExtraPremiumDataType>();
        }
        return this.extraPrem;
    }

    public boolean isSetExtraPrem() {
        return ((this.extraPrem!= null)&&(!this.extraPrem.isEmpty()));
    }

    public void unsetExtraPrem() {
        this.extraPrem = null;
    }

    /**
     * Gets the value of the covFee property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covFee property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovFee().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeeType }
     * 
     * 
     */
    public List<FeeType> getCovFee() {
        if (covFee == null) {
            covFee = new ArrayList<FeeType>();
        }
        return this.covFee;
    }

    public boolean isSetCovFee() {
        return ((this.covFee!= null)&&(!this.covFee.isEmpty()));
    }

    public void unsetCovFee() {
        this.covFee = null;
    }

    /**
     * Gets the value of the covTax property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covTax property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovTax().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TaxType }
     * 
     * 
     */
    public List<TaxType> getCovTax() {
        if (covTax == null) {
            covTax = new ArrayList<TaxType>();
        }
        return this.covTax;
    }

    public boolean isSetCovTax() {
        return ((this.covTax!= null)&&(!this.covTax.isEmpty()));
    }

    public void unsetCovTax() {
        this.covTax = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covIdntfctn", covIdntfctn).add("linkdObjcts", linkdObjcts).add("premData", premData).add("extraPrem", extraPrem).add("covFee", covFee).add("covTax", covTax).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covIdntfctn, linkdObjcts, premData, extraPrem, covFee, covTax);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionCoverPremiumType o = ((ProtectionCoverPremiumType) other);
        return (((((Objects.equal(covIdntfctn, o.covIdntfctn)&&Objects.equal(linkdObjcts, o.linkdObjcts))&&Objects.equal(premData, o.premData))&&Objects.equal(extraPrem, o.extraPrem))&&Objects.equal(covFee, o.covFee))&&Objects.equal(covTax, o.covTax));
    }

}
