
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage global data of simplified protection
 * 				product
 * 			
 * 
 * <p>Java class for ProtectionProductDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionProductDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="ShortName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="LongName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="Desc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="RefCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MarktngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType"/&gt;
 *         &lt;element name="StdRenunctnMaxPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="DoorSetpRenunctnMaxPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="LatePaymntChrgeRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *         &lt;element name="SubscrAge" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Min" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
 *                   &lt;element name="Max" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DurtnAndRnwal" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Duratn" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyDurationTypeCode"/&gt;
 *                             &lt;element name="Fixd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *                             &lt;element name="Min" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *                             &lt;element name="Max" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Rnwal" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Mode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ContractRenewalModeCodeSLN"/&gt;
 *                             &lt;element name="Freq" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PremPaymntTolrnce" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}WayOfCalculatingCodeSLN"/&gt;
 *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *                   &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FnctnlStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductFunctionalStatusDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionProductDataType", propOrder = {
    "name",
    "shortName",
    "longName",
    "desc",
    "refCurr",
    "marktngPrd",
    "stdRenunctnMaxPrd",
    "doorSetpRenunctnMaxPrd",
    "latePaymntChrgeRate",
    "subscrAge",
    "durtnAndRnwal",
    "premPaymntTolrnce",
    "fnctnlStatus"
})
public class ProtectionProductDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "ShortName")
    protected String shortName;
    @XmlElement(name = "LongName")
    protected String longName;
    @XmlElement(name = "Desc")
    protected String desc;
    @XmlElement(name = "RefCurr")
    protected String refCurr;
    @XmlElement(name = "MarktngPrd", required = true)
    protected DatePeriodType marktngPrd;
    @XmlElement(name = "StdRenunctnMaxPrd")
    protected DurationType stdRenunctnMaxPrd;
    @XmlElement(name = "DoorSetpRenunctnMaxPrd")
    protected DurationType doorSetpRenunctnMaxPrd;
    @XmlElement(name = "LatePaymntChrgeRate")
    protected BasisRateType latePaymntChrgeRate;
    @XmlElement(name = "SubscrAge")
    protected ProtectionProductDataType.SubscrAge subscrAge;
    @XmlElement(name = "DurtnAndRnwal")
    protected ProtectionProductDataType.DurtnAndRnwal durtnAndRnwal;
    @XmlElement(name = "PremPaymntTolrnce")
    protected ProtectionProductDataType.PremPaymntTolrnce premPaymntTolrnce;
    @XmlElement(name = "FnctnlStatus")
    protected ProductFunctionalStatusDataType fnctnlStatus;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionProductDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionProductDataType(final String name, final String shortName, final String longName, final String desc, final String refCurr, final DatePeriodType marktngPrd, final DurationType stdRenunctnMaxPrd, final DurationType doorSetpRenunctnMaxPrd, final BasisRateType latePaymntChrgeRate, final ProtectionProductDataType.SubscrAge subscrAge, final ProtectionProductDataType.DurtnAndRnwal durtnAndRnwal, final ProtectionProductDataType.PremPaymntTolrnce premPaymntTolrnce, final ProductFunctionalStatusDataType fnctnlStatus) {
        this.name = name;
        this.shortName = shortName;
        this.longName = longName;
        this.desc = desc;
        this.refCurr = refCurr;
        this.marktngPrd = marktngPrd;
        this.stdRenunctnMaxPrd = stdRenunctnMaxPrd;
        this.doorSetpRenunctnMaxPrd = doorSetpRenunctnMaxPrd;
        this.latePaymntChrgeRate = latePaymntChrgeRate;
        this.subscrAge = subscrAge;
        this.durtnAndRnwal = durtnAndRnwal;
        this.premPaymntTolrnce = premPaymntTolrnce;
        this.fnctnlStatus = fnctnlStatus;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the shortName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * Sets the value of the shortName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortName(String value) {
        this.shortName = value;
    }

    public boolean isSetShortName() {
        return (this.shortName!= null);
    }

    /**
     * Gets the value of the longName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongName() {
        return longName;
    }

    /**
     * Sets the value of the longName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongName(String value) {
        this.longName = value;
    }

    public boolean isSetLongName() {
        return (this.longName!= null);
    }

    /**
     * Gets the value of the desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesc() {
        return desc;
    }

    /**
     * Sets the value of the desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesc(String value) {
        this.desc = value;
    }

    public boolean isSetDesc() {
        return (this.desc!= null);
    }

    /**
     * Gets the value of the refCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefCurr() {
        return refCurr;
    }

    /**
     * Sets the value of the refCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefCurr(String value) {
        this.refCurr = value;
    }

    public boolean isSetRefCurr() {
        return (this.refCurr!= null);
    }

    /**
     * Gets the value of the marktngPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getMarktngPrd() {
        return marktngPrd;
    }

    /**
     * Sets the value of the marktngPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setMarktngPrd(DatePeriodType value) {
        this.marktngPrd = value;
    }

    public boolean isSetMarktngPrd() {
        return (this.marktngPrd!= null);
    }

    /**
     * Gets the value of the stdRenunctnMaxPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getStdRenunctnMaxPrd() {
        return stdRenunctnMaxPrd;
    }

    /**
     * Sets the value of the stdRenunctnMaxPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setStdRenunctnMaxPrd(DurationType value) {
        this.stdRenunctnMaxPrd = value;
    }

    public boolean isSetStdRenunctnMaxPrd() {
        return (this.stdRenunctnMaxPrd!= null);
    }

    /**
     * Gets the value of the doorSetpRenunctnMaxPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDoorSetpRenunctnMaxPrd() {
        return doorSetpRenunctnMaxPrd;
    }

    /**
     * Sets the value of the doorSetpRenunctnMaxPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDoorSetpRenunctnMaxPrd(DurationType value) {
        this.doorSetpRenunctnMaxPrd = value;
    }

    public boolean isSetDoorSetpRenunctnMaxPrd() {
        return (this.doorSetpRenunctnMaxPrd!= null);
    }

    /**
     * Gets the value of the latePaymntChrgeRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getLatePaymntChrgeRate() {
        return latePaymntChrgeRate;
    }

    /**
     * Sets the value of the latePaymntChrgeRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setLatePaymntChrgeRate(BasisRateType value) {
        this.latePaymntChrgeRate = value;
    }

    public boolean isSetLatePaymntChrgeRate() {
        return (this.latePaymntChrgeRate!= null);
    }

    /**
     * Gets the value of the subscrAge property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionProductDataType.SubscrAge }
     *     
     */
    public ProtectionProductDataType.SubscrAge getSubscrAge() {
        return subscrAge;
    }

    /**
     * Sets the value of the subscrAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionProductDataType.SubscrAge }
     *     
     */
    public void setSubscrAge(ProtectionProductDataType.SubscrAge value) {
        this.subscrAge = value;
    }

    public boolean isSetSubscrAge() {
        return (this.subscrAge!= null);
    }

    /**
     * Gets the value of the durtnAndRnwal property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionProductDataType.DurtnAndRnwal }
     *     
     */
    public ProtectionProductDataType.DurtnAndRnwal getDurtnAndRnwal() {
        return durtnAndRnwal;
    }

    /**
     * Sets the value of the durtnAndRnwal property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionProductDataType.DurtnAndRnwal }
     *     
     */
    public void setDurtnAndRnwal(ProtectionProductDataType.DurtnAndRnwal value) {
        this.durtnAndRnwal = value;
    }

    public boolean isSetDurtnAndRnwal() {
        return (this.durtnAndRnwal!= null);
    }

    /**
     * Gets the value of the premPaymntTolrnce property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionProductDataType.PremPaymntTolrnce }
     *     
     */
    public ProtectionProductDataType.PremPaymntTolrnce getPremPaymntTolrnce() {
        return premPaymntTolrnce;
    }

    /**
     * Sets the value of the premPaymntTolrnce property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionProductDataType.PremPaymntTolrnce }
     *     
     */
    public void setPremPaymntTolrnce(ProtectionProductDataType.PremPaymntTolrnce value) {
        this.premPaymntTolrnce = value;
    }

    public boolean isSetPremPaymntTolrnce() {
        return (this.premPaymntTolrnce!= null);
    }

    /**
     * Gets the value of the fnctnlStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ProductFunctionalStatusDataType }
     *     
     */
    public ProductFunctionalStatusDataType getFnctnlStatus() {
        return fnctnlStatus;
    }

    /**
     * Sets the value of the fnctnlStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductFunctionalStatusDataType }
     *     
     */
    public void setFnctnlStatus(ProductFunctionalStatusDataType value) {
        this.fnctnlStatus = value;
    }

    public boolean isSetFnctnlStatus() {
        return (this.fnctnlStatus!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("shortName", shortName).add("longName", longName).add("desc", desc).add("refCurr", refCurr).add("marktngPrd", marktngPrd).add("stdRenunctnMaxPrd", stdRenunctnMaxPrd).add("doorSetpRenunctnMaxPrd", doorSetpRenunctnMaxPrd).add("latePaymntChrgeRate", latePaymntChrgeRate).add("subscrAge", subscrAge).add("durtnAndRnwal", durtnAndRnwal).add("premPaymntTolrnce", premPaymntTolrnce).add("fnctnlStatus", fnctnlStatus).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, shortName, longName, desc, refCurr, marktngPrd, stdRenunctnMaxPrd, doorSetpRenunctnMaxPrd, latePaymntChrgeRate, subscrAge, durtnAndRnwal, premPaymntTolrnce, fnctnlStatus);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionProductDataType o = ((ProtectionProductDataType) other);
        return ((((((((((((Objects.equal(name, o.name)&&Objects.equal(shortName, o.shortName))&&Objects.equal(longName, o.longName))&&Objects.equal(desc, o.desc))&&Objects.equal(refCurr, o.refCurr))&&Objects.equal(marktngPrd, o.marktngPrd))&&Objects.equal(stdRenunctnMaxPrd, o.stdRenunctnMaxPrd))&&Objects.equal(doorSetpRenunctnMaxPrd, o.doorSetpRenunctnMaxPrd))&&Objects.equal(latePaymntChrgeRate, o.latePaymntChrgeRate))&&Objects.equal(subscrAge, o.subscrAge))&&Objects.equal(durtnAndRnwal, o.durtnAndRnwal))&&Objects.equal(premPaymntTolrnce, o.premPaymntTolrnce))&&Objects.equal(fnctnlStatus, o.fnctnlStatus));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Duratn" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyDurationTypeCode"/&gt;
     *                   &lt;element name="Fixd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
     *                   &lt;element name="Min" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
     *                   &lt;element name="Max" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Rnwal" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Mode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ContractRenewalModeCodeSLN"/&gt;
     *                   &lt;element name="Freq" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "duratn",
        "rnwal"
    })
    public static class DurtnAndRnwal implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Duratn")
        protected ProtectionProductDataType.DurtnAndRnwal.Duratn duratn;
        @XmlElement(name = "Rnwal")
        protected ProtectionProductDataType.DurtnAndRnwal.Rnwal rnwal;

        /**
         * Default no-arg constructor
         * 
         */
        public DurtnAndRnwal() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public DurtnAndRnwal(final ProtectionProductDataType.DurtnAndRnwal.Duratn duratn, final ProtectionProductDataType.DurtnAndRnwal.Rnwal rnwal) {
            this.duratn = duratn;
            this.rnwal = rnwal;
        }

        /**
         * Gets the value of the duratn property.
         * 
         * @return
         *     possible object is
         *     {@link ProtectionProductDataType.DurtnAndRnwal.Duratn }
         *     
         */
        public ProtectionProductDataType.DurtnAndRnwal.Duratn getDuratn() {
            return duratn;
        }

        /**
         * Sets the value of the duratn property.
         * 
         * @param value
         *     allowed object is
         *     {@link ProtectionProductDataType.DurtnAndRnwal.Duratn }
         *     
         */
        public void setDuratn(ProtectionProductDataType.DurtnAndRnwal.Duratn value) {
            this.duratn = value;
        }

        public boolean isSetDuratn() {
            return (this.duratn!= null);
        }

        /**
         * Gets the value of the rnwal property.
         * 
         * @return
         *     possible object is
         *     {@link ProtectionProductDataType.DurtnAndRnwal.Rnwal }
         *     
         */
        public ProtectionProductDataType.DurtnAndRnwal.Rnwal getRnwal() {
            return rnwal;
        }

        /**
         * Sets the value of the rnwal property.
         * 
         * @param value
         *     allowed object is
         *     {@link ProtectionProductDataType.DurtnAndRnwal.Rnwal }
         *     
         */
        public void setRnwal(ProtectionProductDataType.DurtnAndRnwal.Rnwal value) {
            this.rnwal = value;
        }

        public boolean isSetRnwal() {
            return (this.rnwal!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("duratn", duratn).add("rnwal", rnwal).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(duratn, rnwal);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ProtectionProductDataType.DurtnAndRnwal o = ((ProtectionProductDataType.DurtnAndRnwal) other);
            return (Objects.equal(duratn, o.duratn)&&Objects.equal(rnwal, o.rnwal));
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyDurationTypeCode"/&gt;
         *         &lt;element name="Fixd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
         *         &lt;element name="Min" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
         *         &lt;element name="Max" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "type",
            "fixd",
            "min",
            "max"
        })
        public static class Duratn implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Type", required = true)
            protected String type;
            @XmlElement(name = "Fixd")
            protected DurationType fixd;
            @XmlElement(name = "Min")
            protected DurationType min;
            @XmlElement(name = "Max")
            protected DurationType max;

            /**
             * Default no-arg constructor
             * 
             */
            public Duratn() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public Duratn(final String type, final DurationType fixd, final DurationType min, final DurationType max) {
                this.type = type;
                this.fixd = fixd;
                this.min = min;
                this.max = max;
            }

            /**
             * Gets the value of the type property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getType() {
                return type;
            }

            /**
             * Sets the value of the type property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setType(String value) {
                this.type = value;
            }

            public boolean isSetType() {
                return (this.type!= null);
            }

            /**
             * Gets the value of the fixd property.
             * 
             * @return
             *     possible object is
             *     {@link DurationType }
             *     
             */
            public DurationType getFixd() {
                return fixd;
            }

            /**
             * Sets the value of the fixd property.
             * 
             * @param value
             *     allowed object is
             *     {@link DurationType }
             *     
             */
            public void setFixd(DurationType value) {
                this.fixd = value;
            }

            public boolean isSetFixd() {
                return (this.fixd!= null);
            }

            /**
             * Gets the value of the min property.
             * 
             * @return
             *     possible object is
             *     {@link DurationType }
             *     
             */
            public DurationType getMin() {
                return min;
            }

            /**
             * Sets the value of the min property.
             * 
             * @param value
             *     allowed object is
             *     {@link DurationType }
             *     
             */
            public void setMin(DurationType value) {
                this.min = value;
            }

            public boolean isSetMin() {
                return (this.min!= null);
            }

            /**
             * Gets the value of the max property.
             * 
             * @return
             *     possible object is
             *     {@link DurationType }
             *     
             */
            public DurationType getMax() {
                return max;
            }

            /**
             * Sets the value of the max property.
             * 
             * @param value
             *     allowed object is
             *     {@link DurationType }
             *     
             */
            public void setMax(DurationType value) {
                this.max = value;
            }

            public boolean isSetMax() {
                return (this.max!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("type", type).add("fixd", fixd).add("min", min).add("max", max).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(type, fixd, min, max);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final ProtectionProductDataType.DurtnAndRnwal.Duratn o = ((ProtectionProductDataType.DurtnAndRnwal.Duratn) other);
                return (((Objects.equal(type, o.type)&&Objects.equal(fixd, o.fixd))&&Objects.equal(min, o.min))&&Objects.equal(max, o.max));
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Mode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ContractRenewalModeCodeSLN"/&gt;
         *         &lt;element name="Freq" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "mode",
            "freq"
        })
        public static class Rnwal implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Mode", required = true)
            protected String mode;
            @XmlElement(name = "Freq", required = true)
            protected String freq;

            /**
             * Default no-arg constructor
             * 
             */
            public Rnwal() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public Rnwal(final String mode, final String freq) {
                this.mode = mode;
                this.freq = freq;
            }

            /**
             * Gets the value of the mode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMode() {
                return mode;
            }

            /**
             * Sets the value of the mode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMode(String value) {
                this.mode = value;
            }

            public boolean isSetMode() {
                return (this.mode!= null);
            }

            /**
             * Gets the value of the freq property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFreq() {
                return freq;
            }

            /**
             * Sets the value of the freq property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFreq(String value) {
                this.freq = value;
            }

            public boolean isSetFreq() {
                return (this.freq!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("mode", mode).add("freq", freq).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(mode, freq);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final ProtectionProductDataType.DurtnAndRnwal.Rnwal o = ((ProtectionProductDataType.DurtnAndRnwal.Rnwal) other);
                return (Objects.equal(mode, o.mode)&&Objects.equal(freq, o.freq));
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}WayOfCalculatingCodeSLN"/&gt;
     *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
     *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "type",
        "rate",
        "amnt"
    })
    public static class PremPaymntTolrnce implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Type", required = true)
        protected String type;
        @XmlElement(name = "Rate")
        protected BasisRateType rate;
        @XmlElement(name = "Amnt")
        protected CurrencyAndAmountType amnt;

        /**
         * Default no-arg constructor
         * 
         */
        public PremPaymntTolrnce() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public PremPaymntTolrnce(final String type, final BasisRateType rate, final CurrencyAndAmountType amnt) {
            this.type = type;
            this.rate = rate;
            this.amnt = amnt;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

        public boolean isSetType() {
            return (this.type!= null);
        }

        /**
         * Gets the value of the rate property.
         * 
         * @return
         *     possible object is
         *     {@link BasisRateType }
         *     
         */
        public BasisRateType getRate() {
            return rate;
        }

        /**
         * Sets the value of the rate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BasisRateType }
         *     
         */
        public void setRate(BasisRateType value) {
            this.rate = value;
        }

        public boolean isSetRate() {
            return (this.rate!= null);
        }

        /**
         * Gets the value of the amnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getAmnt() {
            return amnt;
        }

        /**
         * Sets the value of the amnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setAmnt(CurrencyAndAmountType value) {
            this.amnt = value;
        }

        public boolean isSetAmnt() {
            return (this.amnt!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("type", type).add("rate", rate).add("amnt", amnt).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(type, rate, amnt);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ProtectionProductDataType.PremPaymntTolrnce o = ((ProtectionProductDataType.PremPaymntTolrnce) other);
            return ((Objects.equal(type, o.type)&&Objects.equal(rate, o.rate))&&Objects.equal(amnt, o.amnt));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Min" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
     *         &lt;element name="Max" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "min",
        "max"
    })
    public static class SubscrAge implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Min", required = true)
        protected BigInteger min;
        @XmlElement(name = "Max", required = true)
        protected BigInteger max;

        /**
         * Default no-arg constructor
         * 
         */
        public SubscrAge() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public SubscrAge(final BigInteger min, final BigInteger max) {
            this.min = min;
            this.max = max;
        }

        /**
         * Gets the value of the min property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getMin() {
            return min;
        }

        /**
         * Sets the value of the min property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setMin(BigInteger value) {
            this.min = value;
        }

        public boolean isSetMin() {
            return (this.min!= null);
        }

        /**
         * Gets the value of the max property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getMax() {
            return max;
        }

        /**
         * Sets the value of the max property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setMax(BigInteger value) {
            this.max = value;
        }

        public boolean isSetMax() {
            return (this.max!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("min", min).add("max", max).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(min, max);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ProtectionProductDataType.SubscrAge o = ((ProtectionProductDataType.SubscrAge) other);
            return (Objects.equal(min, o.min)&&Objects.equal(max, o.max));
        }

    }

}
