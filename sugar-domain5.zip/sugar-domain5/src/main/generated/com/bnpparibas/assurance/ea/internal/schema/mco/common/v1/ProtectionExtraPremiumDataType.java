
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on protection extra premium
 * 			
 * 
 * <p>Java class for ProtectionExtraPremiumDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionExtraPremiumDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="BaseAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *         &lt;element name="MotivCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExclusionAndExtraPremiumMotiveCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ExclsnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExclusionCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionExtraPremiumDataType", propOrder = {
    "amnt",
    "baseAmnt",
    "rate",
    "motivCode",
    "exclsnType"
})
public class ProtectionExtraPremiumDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "BaseAmnt")
    protected CurrencyAndAmountType baseAmnt;
    @XmlElement(name = "Rate")
    protected BasisRateType rate;
    @XmlElement(name = "MotivCode")
    protected String motivCode;
    @XmlElement(name = "ExclsnType")
    protected String exclsnType;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionExtraPremiumDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionExtraPremiumDataType(final CurrencyAndAmountType amnt, final CurrencyAndAmountType baseAmnt, final BasisRateType rate, final String motivCode, final String exclsnType) {
        this.amnt = amnt;
        this.baseAmnt = baseAmnt;
        this.rate = rate;
        this.motivCode = motivCode;
        this.exclsnType = exclsnType;
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the baseAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getBaseAmnt() {
        return baseAmnt;
    }

    /**
     * Sets the value of the baseAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setBaseAmnt(CurrencyAndAmountType value) {
        this.baseAmnt = value;
    }

    public boolean isSetBaseAmnt() {
        return (this.baseAmnt!= null);
    }

    /**
     * Gets the value of the rate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getRate() {
        return rate;
    }

    /**
     * Sets the value of the rate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setRate(BasisRateType value) {
        this.rate = value;
    }

    public boolean isSetRate() {
        return (this.rate!= null);
    }

    /**
     * Gets the value of the motivCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotivCode() {
        return motivCode;
    }

    /**
     * Sets the value of the motivCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotivCode(String value) {
        this.motivCode = value;
    }

    public boolean isSetMotivCode() {
        return (this.motivCode!= null);
    }

    /**
     * Gets the value of the exclsnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExclsnType() {
        return exclsnType;
    }

    /**
     * Sets the value of the exclsnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExclsnType(String value) {
        this.exclsnType = value;
    }

    public boolean isSetExclsnType() {
        return (this.exclsnType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("amnt", amnt).add("baseAmnt", baseAmnt).add("rate", rate).add("motivCode", motivCode).add("exclsnType", exclsnType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(amnt, baseAmnt, rate, motivCode, exclsnType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionExtraPremiumDataType o = ((ProtectionExtraPremiumDataType) other);
        return ((((Objects.equal(amnt, o.amnt)&&Objects.equal(baseAmnt, o.baseAmnt))&&Objects.equal(rate, o.rate))&&Objects.equal(motivCode, o.motivCode))&&Objects.equal(exclsnType, o.exclsnType));
    }

}
