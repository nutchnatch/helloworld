
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Type to manage third party financial ratios
 * 			
 * 
 * <p>Java class for ThirdPartyFinancialRatiosType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThirdPartyFinancialRatiosType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialRatioCodeSLN"/&gt;
 *         &lt;element name="Value" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisOptionalRateType"/&gt;
 *         &lt;element name="CalctnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThirdPartyFinancialRatiosType", propOrder = {
    "code",
    "value",
    "calctnDate"
})
public class ThirdPartyFinancialRatiosType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Code", required = true)
    protected String code;
    @XmlElement(name = "Value", required = true)
    protected BasisOptionalRateType value;
    @XmlElement(name = "CalctnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date calctnDate;

    /**
     * Default no-arg constructor
     * 
     */
    public ThirdPartyFinancialRatiosType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ThirdPartyFinancialRatiosType(final String code, final BasisOptionalRateType value, final Date calctnDate) {
        this.code = code;
        this.value = value;
        this.calctnDate = calctnDate;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    public boolean isSetCode() {
        return (this.code!= null);
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link BasisOptionalRateType }
     *     
     */
    public BasisOptionalRateType getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisOptionalRateType }
     *     
     */
    public void setValue(BasisOptionalRateType value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the calctnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCalctnDate() {
        return calctnDate;
    }

    /**
     * Sets the value of the calctnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalctnDate(Date value) {
        this.calctnDate = value;
    }

    public boolean isSetCalctnDate() {
        return (this.calctnDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("code", code).add("value", value).add("calctnDate", calctnDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code, value, calctnDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ThirdPartyFinancialRatiosType o = ((ThirdPartyFinancialRatiosType) other);
        return ((Objects.equal(code, o.code)&&Objects.equal(value, o.value))&&Objects.equal(calctnDate, o.calctnDate));
    }

}
