
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Global data of the claim benefit
 * 
 * <p>Java class for ProtectionClaimBenefitDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionClaimBenefitDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="BnftType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitModeCodeSLN"/&gt;
 *         &lt;element name="ExpectPaymntDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="Curr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="NetAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="GrossAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="AddAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AdditionalAmountType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CovrdPrd" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="StartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *                   &lt;element name="EndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionClaimBenefitDataType", propOrder = {
    "opeType",
    "bnftType",
    "expectPaymntDate",
    "curr",
    "netAmnt",
    "grossAmnt",
    "addAmnt",
    "covrdPrd"
})
public class ProtectionClaimBenefitDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeType", required = true)
    protected String opeType;
    @XmlElement(name = "BnftType", required = true)
    protected String bnftType;
    @XmlElement(name = "ExpectPaymntDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date expectPaymntDate;
    @XmlElement(name = "Curr", required = true)
    protected String curr;
    @XmlElement(name = "NetAmnt")
    protected CurrencyAndAmountType netAmnt;
    @XmlElement(name = "GrossAmnt", required = true)
    protected CurrencyAndAmountType grossAmnt;
    @XmlElement(name = "AddAmnt")
    protected List<AdditionalAmountType> addAmnt;
    @XmlElement(name = "CovrdPrd")
    protected ProtectionClaimBenefitDataType.CovrdPrd covrdPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionClaimBenefitDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionClaimBenefitDataType(final String opeType, final String bnftType, final Date expectPaymntDate, final String curr, final CurrencyAndAmountType netAmnt, final CurrencyAndAmountType grossAmnt, final List<AdditionalAmountType> addAmnt, final ProtectionClaimBenefitDataType.CovrdPrd covrdPrd) {
        this.opeType = opeType;
        this.bnftType = bnftType;
        this.expectPaymntDate = expectPaymntDate;
        this.curr = curr;
        this.netAmnt = netAmnt;
        this.grossAmnt = grossAmnt;
        this.addAmnt = addAmnt;
        this.covrdPrd = covrdPrd;
    }

    /**
     * Gets the value of the opeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeType() {
        return opeType;
    }

    /**
     * Sets the value of the opeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeType(String value) {
        this.opeType = value;
    }

    public boolean isSetOpeType() {
        return (this.opeType!= null);
    }

    /**
     * Gets the value of the bnftType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBnftType() {
        return bnftType;
    }

    /**
     * Sets the value of the bnftType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBnftType(String value) {
        this.bnftType = value;
    }

    public boolean isSetBnftType() {
        return (this.bnftType!= null);
    }

    /**
     * Gets the value of the expectPaymntDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getExpectPaymntDate() {
        return expectPaymntDate;
    }

    /**
     * Sets the value of the expectPaymntDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpectPaymntDate(Date value) {
        this.expectPaymntDate = value;
    }

    public boolean isSetExpectPaymntDate() {
        return (this.expectPaymntDate!= null);
    }

    /**
     * Gets the value of the curr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurr() {
        return curr;
    }

    /**
     * Sets the value of the curr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurr(String value) {
        this.curr = value;
    }

    public boolean isSetCurr() {
        return (this.curr!= null);
    }

    /**
     * Gets the value of the netAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getNetAmnt() {
        return netAmnt;
    }

    /**
     * Sets the value of the netAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setNetAmnt(CurrencyAndAmountType value) {
        this.netAmnt = value;
    }

    public boolean isSetNetAmnt() {
        return (this.netAmnt!= null);
    }

    /**
     * Gets the value of the grossAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getGrossAmnt() {
        return grossAmnt;
    }

    /**
     * Sets the value of the grossAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setGrossAmnt(CurrencyAndAmountType value) {
        this.grossAmnt = value;
    }

    public boolean isSetGrossAmnt() {
        return (this.grossAmnt!= null);
    }

    /**
     * Gets the value of the addAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmountType }
     * 
     * 
     */
    public List<AdditionalAmountType> getAddAmnt() {
        if (addAmnt == null) {
            addAmnt = new ArrayList<AdditionalAmountType>();
        }
        return this.addAmnt;
    }

    public boolean isSetAddAmnt() {
        return ((this.addAmnt!= null)&&(!this.addAmnt.isEmpty()));
    }

    public void unsetAddAmnt() {
        this.addAmnt = null;
    }

    /**
     * Gets the value of the covrdPrd property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionClaimBenefitDataType.CovrdPrd }
     *     
     */
    public ProtectionClaimBenefitDataType.CovrdPrd getCovrdPrd() {
        return covrdPrd;
    }

    /**
     * Sets the value of the covrdPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionClaimBenefitDataType.CovrdPrd }
     *     
     */
    public void setCovrdPrd(ProtectionClaimBenefitDataType.CovrdPrd value) {
        this.covrdPrd = value;
    }

    public boolean isSetCovrdPrd() {
        return (this.covrdPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeType", opeType).add("bnftType", bnftType).add("expectPaymntDate", expectPaymntDate).add("curr", curr).add("netAmnt", netAmnt).add("grossAmnt", grossAmnt).add("addAmnt", addAmnt).add("covrdPrd", covrdPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeType, bnftType, expectPaymntDate, curr, netAmnt, grossAmnt, addAmnt, covrdPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionClaimBenefitDataType o = ((ProtectionClaimBenefitDataType) other);
        return (((((((Objects.equal(opeType, o.opeType)&&Objects.equal(bnftType, o.bnftType))&&Objects.equal(expectPaymntDate, o.expectPaymntDate))&&Objects.equal(curr, o.curr))&&Objects.equal(netAmnt, o.netAmnt))&&Objects.equal(grossAmnt, o.grossAmnt))&&Objects.equal(addAmnt, o.addAmnt))&&Objects.equal(covrdPrd, o.covrdPrd));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="StartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
     *         &lt;element name="EndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "startDate",
        "endDate"
    })
    public static class CovrdPrd implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "StartDate", required = true, type = String.class)
        @XmlJavaTypeAdapter(Adapter2 .class)
        @XmlSchemaType(name = "date")
        protected Date startDate;
        @XmlElement(name = "EndDate", required = true, type = String.class)
        @XmlJavaTypeAdapter(Adapter2 .class)
        @XmlSchemaType(name = "date")
        protected Date endDate;

        /**
         * Default no-arg constructor
         * 
         */
        public CovrdPrd() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public CovrdPrd(final Date startDate, final Date endDate) {
            this.startDate = startDate;
            this.endDate = endDate;
        }

        /**
         * Gets the value of the startDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public Date getStartDate() {
            return startDate;
        }

        /**
         * Sets the value of the startDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStartDate(Date value) {
            this.startDate = value;
        }

        public boolean isSetStartDate() {
            return (this.startDate!= null);
        }

        /**
         * Gets the value of the endDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public Date getEndDate() {
            return endDate;
        }

        /**
         * Sets the value of the endDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEndDate(Date value) {
            this.endDate = value;
        }

        public boolean isSetEndDate() {
            return (this.endDate!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("startDate", startDate).add("endDate", endDate).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(startDate, endDate);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ProtectionClaimBenefitDataType.CovrdPrd o = ((ProtectionClaimBenefitDataType.CovrdPrd) other);
            return (Objects.equal(startDate, o.startDate)&&Objects.equal(endDate, o.endDate));
        }

    }

}
