
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a service fee operation has
 * 				dependencies
 * 			
 * 
 * <p>Java class for ServiceFeeOperationLinkedObjetsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceFeeOperationLinkedObjetsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ServProvdr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="ServRcver" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntRecipint" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="SysRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="ThdPrtyAdmnstr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceFeeOperationLinkedObjetsType", propOrder = {
    "servProvdr",
    "servRcver",
    "prdctr",
    "paymntRecipint",
    "sysRef",
    "thdPrtyAdmnstr"
})
public class ServiceFeeOperationLinkedObjetsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ServProvdr", required = true)
    protected PartyRoleType servProvdr;
    @XmlElement(name = "ServRcver", required = true)
    protected PartyRoleType servRcver;
    @XmlElement(name = "Prdctr")
    protected PartyRoleType prdctr;
    @XmlElement(name = "PaymntRecipint")
    protected PartyRoleType paymntRecipint;
    @XmlElement(name = "SysRef")
    protected ObjectIdentificationType sysRef;
    @XmlElement(name = "ThdPrtyAdmnstr")
    protected PartyRoleType thdPrtyAdmnstr;

    /**
     * Default no-arg constructor
     * 
     */
    public ServiceFeeOperationLinkedObjetsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ServiceFeeOperationLinkedObjetsType(final PartyRoleType servProvdr, final PartyRoleType servRcver, final PartyRoleType prdctr, final PartyRoleType paymntRecipint, final ObjectIdentificationType sysRef, final PartyRoleType thdPrtyAdmnstr) {
        this.servProvdr = servProvdr;
        this.servRcver = servRcver;
        this.prdctr = prdctr;
        this.paymntRecipint = paymntRecipint;
        this.sysRef = sysRef;
        this.thdPrtyAdmnstr = thdPrtyAdmnstr;
    }

    /**
     * Gets the value of the servProvdr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getServProvdr() {
        return servProvdr;
    }

    /**
     * Sets the value of the servProvdr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setServProvdr(PartyRoleType value) {
        this.servProvdr = value;
    }

    public boolean isSetServProvdr() {
        return (this.servProvdr!= null);
    }

    /**
     * Gets the value of the servRcver property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getServRcver() {
        return servRcver;
    }

    /**
     * Sets the value of the servRcver property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setServRcver(PartyRoleType value) {
        this.servRcver = value;
    }

    public boolean isSetServRcver() {
        return (this.servRcver!= null);
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    /**
     * Gets the value of the paymntRecipint property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPaymntRecipint() {
        return paymntRecipint;
    }

    /**
     * Sets the value of the paymntRecipint property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPaymntRecipint(PartyRoleType value) {
        this.paymntRecipint = value;
    }

    public boolean isSetPaymntRecipint() {
        return (this.paymntRecipint!= null);
    }

    /**
     * Gets the value of the sysRef property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getSysRef() {
        return sysRef;
    }

    /**
     * Sets the value of the sysRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setSysRef(ObjectIdentificationType value) {
        this.sysRef = value;
    }

    public boolean isSetSysRef() {
        return (this.sysRef!= null);
    }

    /**
     * Gets the value of the thdPrtyAdmnstr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getThdPrtyAdmnstr() {
        return thdPrtyAdmnstr;
    }

    /**
     * Sets the value of the thdPrtyAdmnstr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setThdPrtyAdmnstr(PartyRoleType value) {
        this.thdPrtyAdmnstr = value;
    }

    public boolean isSetThdPrtyAdmnstr() {
        return (this.thdPrtyAdmnstr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("servProvdr", servProvdr).add("servRcver", servRcver).add("prdctr", prdctr).add("paymntRecipint", paymntRecipint).add("sysRef", sysRef).add("thdPrtyAdmnstr", thdPrtyAdmnstr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(servProvdr, servRcver, prdctr, paymntRecipint, sysRef, thdPrtyAdmnstr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ServiceFeeOperationLinkedObjetsType o = ((ServiceFeeOperationLinkedObjetsType) other);
        return (((((Objects.equal(servProvdr, o.servProvdr)&&Objects.equal(servRcver, o.servRcver))&&Objects.equal(prdctr, o.prdctr))&&Objects.equal(paymntRecipint, o.paymntRecipint))&&Objects.equal(sysRef, o.sysRef))&&Objects.equal(thdPrtyAdmnstr, o.thdPrtyAdmnstr));
    }

}
