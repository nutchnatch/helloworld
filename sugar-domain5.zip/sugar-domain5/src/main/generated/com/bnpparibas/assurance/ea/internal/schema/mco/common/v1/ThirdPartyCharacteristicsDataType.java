
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Third Party Characteristics
 * 
 * <p>Java class for ThirdPartyCharacteristicsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThirdPartyCharacteristicsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LegalStatusIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalPersonalityCodeSLN"/&gt;
 *         &lt;element name="NaturlPersn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NaturalPersonType" minOccurs="0"/&gt;
 *         &lt;element name="LegalEntty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalEntityType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThirdPartyCharacteristicsDataType", propOrder = {
    "legalStatusIndic",
    "naturlPersn",
    "legalEntty"
})
public class ThirdPartyCharacteristicsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "LegalStatusIndic", required = true)
    protected String legalStatusIndic;
    @XmlElement(name = "NaturlPersn")
    protected NaturalPersonType naturlPersn;
    @XmlElement(name = "LegalEntty")
    protected LegalEntityType legalEntty;

    /**
     * Default no-arg constructor
     * 
     */
    public ThirdPartyCharacteristicsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ThirdPartyCharacteristicsDataType(final String legalStatusIndic, final NaturalPersonType naturlPersn, final LegalEntityType legalEntty) {
        this.legalStatusIndic = legalStatusIndic;
        this.naturlPersn = naturlPersn;
        this.legalEntty = legalEntty;
    }

    /**
     * Gets the value of the legalStatusIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalStatusIndic() {
        return legalStatusIndic;
    }

    /**
     * Sets the value of the legalStatusIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalStatusIndic(String value) {
        this.legalStatusIndic = value;
    }

    public boolean isSetLegalStatusIndic() {
        return (this.legalStatusIndic!= null);
    }

    /**
     * Gets the value of the naturlPersn property.
     * 
     * @return
     *     possible object is
     *     {@link NaturalPersonType }
     *     
     */
    public NaturalPersonType getNaturlPersn() {
        return naturlPersn;
    }

    /**
     * Sets the value of the naturlPersn property.
     * 
     * @param value
     *     allowed object is
     *     {@link NaturalPersonType }
     *     
     */
    public void setNaturlPersn(NaturalPersonType value) {
        this.naturlPersn = value;
    }

    public boolean isSetNaturlPersn() {
        return (this.naturlPersn!= null);
    }

    /**
     * Gets the value of the legalEntty property.
     * 
     * @return
     *     possible object is
     *     {@link LegalEntityType }
     *     
     */
    public LegalEntityType getLegalEntty() {
        return legalEntty;
    }

    /**
     * Sets the value of the legalEntty property.
     * 
     * @param value
     *     allowed object is
     *     {@link LegalEntityType }
     *     
     */
    public void setLegalEntty(LegalEntityType value) {
        this.legalEntty = value;
    }

    public boolean isSetLegalEntty() {
        return (this.legalEntty!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("legalStatusIndic", legalStatusIndic).add("naturlPersn", naturlPersn).add("legalEntty", legalEntty).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(legalStatusIndic, naturlPersn, legalEntty);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ThirdPartyCharacteristicsDataType o = ((ThirdPartyCharacteristicsDataType) other);
        return ((Objects.equal(legalStatusIndic, o.legalStatusIndic)&&Objects.equal(naturlPersn, o.naturlPersn))&&Objects.equal(legalEntty, o.legalEntty));
    }

}
