
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on triggers to execute a
 * 				regular switch scheduler
 * 			
 * 
 * <p>Java class for SwitchTriggerType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SwitchTriggerType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodicOperationTriggerTypeCodeSLN"/&gt;
 *         &lt;element name="Thrshld" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ValueDataType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SwitchTriggerType", propOrder = {
    "type",
    "thrshld"
})
public class SwitchTriggerType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "Thrshld", required = true)
    protected ValueDataType thrshld;

    /**
     * Default no-arg constructor
     * 
     */
    public SwitchTriggerType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SwitchTriggerType(final String type, final ValueDataType thrshld) {
        this.type = type;
        this.thrshld = thrshld;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the thrshld property.
     * 
     * @return
     *     possible object is
     *     {@link ValueDataType }
     *     
     */
    public ValueDataType getThrshld() {
        return thrshld;
    }

    /**
     * Sets the value of the thrshld property.
     * 
     * @param value
     *     allowed object is
     *     {@link ValueDataType }
     *     
     */
    public void setThrshld(ValueDataType value) {
        this.thrshld = value;
    }

    public boolean isSetThrshld() {
        return (this.thrshld!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("thrshld", thrshld).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, thrshld);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SwitchTriggerType o = ((SwitchTriggerType) other);
        return (Objects.equal(type, o.type)&&Objects.equal(thrshld, o.thrshld));
    }

}
