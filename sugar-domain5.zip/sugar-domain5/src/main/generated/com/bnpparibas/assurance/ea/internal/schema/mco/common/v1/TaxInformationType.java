
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Tax and residence information
 * 
 * <p>Java class for TaxInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaxInformationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ResdnceCntry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN"/&gt;
 *         &lt;element name="ResdnceStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FiscalResidenceCodeSLN"/&gt;
 *         &lt;element name="TaxationType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxationTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="TaxNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaxInformationType", propOrder = {
    "resdnceCntry",
    "resdnceStatus",
    "taxationType",
    "taxNumb"
})
public class TaxInformationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ResdnceCntry", required = true)
    protected String resdnceCntry;
    @XmlElement(name = "ResdnceStatus", required = true)
    protected String resdnceStatus;
    @XmlElement(name = "TaxationType")
    protected String taxationType;
    @XmlElement(name = "TaxNumb")
    protected String taxNumb;

    /**
     * Default no-arg constructor
     * 
     */
    public TaxInformationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public TaxInformationType(final String resdnceCntry, final String resdnceStatus, final String taxationType, final String taxNumb) {
        this.resdnceCntry = resdnceCntry;
        this.resdnceStatus = resdnceStatus;
        this.taxationType = taxationType;
        this.taxNumb = taxNumb;
    }

    /**
     * Gets the value of the resdnceCntry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResdnceCntry() {
        return resdnceCntry;
    }

    /**
     * Sets the value of the resdnceCntry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResdnceCntry(String value) {
        this.resdnceCntry = value;
    }

    public boolean isSetResdnceCntry() {
        return (this.resdnceCntry!= null);
    }

    /**
     * Gets the value of the resdnceStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResdnceStatus() {
        return resdnceStatus;
    }

    /**
     * Sets the value of the resdnceStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResdnceStatus(String value) {
        this.resdnceStatus = value;
    }

    public boolean isSetResdnceStatus() {
        return (this.resdnceStatus!= null);
    }

    /**
     * Gets the value of the taxationType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxationType() {
        return taxationType;
    }

    /**
     * Sets the value of the taxationType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxationType(String value) {
        this.taxationType = value;
    }

    public boolean isSetTaxationType() {
        return (this.taxationType!= null);
    }

    /**
     * Gets the value of the taxNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxNumb() {
        return taxNumb;
    }

    /**
     * Sets the value of the taxNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxNumb(String value) {
        this.taxNumb = value;
    }

    public boolean isSetTaxNumb() {
        return (this.taxNumb!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("resdnceCntry", resdnceCntry).add("resdnceStatus", resdnceStatus).add("taxationType", taxationType).add("taxNumb", taxNumb).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(resdnceCntry, resdnceStatus, taxationType, taxNumb);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final TaxInformationType o = ((TaxInformationType) other);
        return (((Objects.equal(resdnceCntry, o.resdnceCntry)&&Objects.equal(resdnceStatus, o.resdnceStatus))&&Objects.equal(taxationType, o.taxationType))&&Objects.equal(taxNumb, o.taxNumb));
    }

}
