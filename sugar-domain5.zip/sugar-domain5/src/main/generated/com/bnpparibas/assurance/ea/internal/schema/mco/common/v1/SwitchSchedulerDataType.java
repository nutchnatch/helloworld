
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Type to manage data for switch scheduler
 * 			
 * 
 * <p>Java class for SwitchSchedulerDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SwitchSchedulerDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="SignDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="RcveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN"/&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="AmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="DistrbtnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InvestmentVehiculeAllocationTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="DistrbtnKey" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionKeyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="NextSwitchType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SwitchSchedulerDataType", propOrder = {
    "type",
    "signDate",
    "rcveDate",
    "fqcy",
    "applctnPrd",
    "amnt",
    "amntType",
    "distrbtnType",
    "distrbtnKey",
    "nextSwitchType"
})
public class SwitchSchedulerDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "SignDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date signDate;
    @XmlElement(name = "RcveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date rcveDate;
    @XmlElement(name = "Fqcy", required = true)
    protected String fqcy;
    @XmlElement(name = "ApplctnPrd", required = true)
    protected DatePeriodType applctnPrd;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "AmntType")
    protected String amntType;
    @XmlElement(name = "DistrbtnType")
    protected String distrbtnType;
    @XmlElement(name = "DistrbtnKey")
    protected String distrbtnKey;
    @XmlElement(name = "NextSwitchType")
    protected String nextSwitchType;

    /**
     * Default no-arg constructor
     * 
     */
    public SwitchSchedulerDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SwitchSchedulerDataType(final String type, final Date signDate, final Date rcveDate, final String fqcy, final DatePeriodType applctnPrd, final CurrencyAndAmountType amnt, final String amntType, final String distrbtnType, final String distrbtnKey, final String nextSwitchType) {
        this.type = type;
        this.signDate = signDate;
        this.rcveDate = rcveDate;
        this.fqcy = fqcy;
        this.applctnPrd = applctnPrd;
        this.amnt = amnt;
        this.amntType = amntType;
        this.distrbtnType = distrbtnType;
        this.distrbtnKey = distrbtnKey;
        this.nextSwitchType = nextSwitchType;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the signDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSignDate() {
        return signDate;
    }

    /**
     * Sets the value of the signDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignDate(Date value) {
        this.signDate = value;
    }

    public boolean isSetSignDate() {
        return (this.signDate!= null);
    }

    /**
     * Gets the value of the rcveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getRcveDate() {
        return rcveDate;
    }

    /**
     * Sets the value of the rcveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcveDate(Date value) {
        this.rcveDate = value;
    }

    public boolean isSetRcveDate() {
        return (this.rcveDate!= null);
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the amntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmntType() {
        return amntType;
    }

    /**
     * Sets the value of the amntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmntType(String value) {
        this.amntType = value;
    }

    public boolean isSetAmntType() {
        return (this.amntType!= null);
    }

    /**
     * Gets the value of the distrbtnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistrbtnType() {
        return distrbtnType;
    }

    /**
     * Sets the value of the distrbtnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistrbtnType(String value) {
        this.distrbtnType = value;
    }

    public boolean isSetDistrbtnType() {
        return (this.distrbtnType!= null);
    }

    /**
     * Gets the value of the distrbtnKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistrbtnKey() {
        return distrbtnKey;
    }

    /**
     * Sets the value of the distrbtnKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistrbtnKey(String value) {
        this.distrbtnKey = value;
    }

    public boolean isSetDistrbtnKey() {
        return (this.distrbtnKey!= null);
    }

    /**
     * Gets the value of the nextSwitchType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextSwitchType() {
        return nextSwitchType;
    }

    /**
     * Sets the value of the nextSwitchType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextSwitchType(String value) {
        this.nextSwitchType = value;
    }

    public boolean isSetNextSwitchType() {
        return (this.nextSwitchType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("signDate", signDate).add("rcveDate", rcveDate).add("fqcy", fqcy).add("applctnPrd", applctnPrd).add("amnt", amnt).add("amntType", amntType).add("distrbtnType", distrbtnType).add("distrbtnKey", distrbtnKey).add("nextSwitchType", nextSwitchType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, signDate, rcveDate, fqcy, applctnPrd, amnt, amntType, distrbtnType, distrbtnKey, nextSwitchType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SwitchSchedulerDataType o = ((SwitchSchedulerDataType) other);
        return (((((((((Objects.equal(type, o.type)&&Objects.equal(signDate, o.signDate))&&Objects.equal(rcveDate, o.rcveDate))&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(applctnPrd, o.applctnPrd))&&Objects.equal(amnt, o.amnt))&&Objects.equal(amntType, o.amntType))&&Objects.equal(distrbtnType, o.distrbtnType))&&Objects.equal(distrbtnKey, o.distrbtnKey))&&Objects.equal(nextSwitchType, o.nextSwitchType));
    }

}
