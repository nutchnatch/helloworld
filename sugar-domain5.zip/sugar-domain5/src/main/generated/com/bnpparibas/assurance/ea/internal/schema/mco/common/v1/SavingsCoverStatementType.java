
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on cover statement
 * 			
 * 
 * <p>Java class for SavingsCoverStatementType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsCoverStatementType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverIdentificationType"/&gt;
 *         &lt;element name="Statmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StatementAdditionalAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsCoverStatementType", propOrder = {
    "covIdntfctn",
    "statmnt"
})
public class SavingsCoverStatementType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovIdntfctn", required = true)
    protected CoverIdentificationType covIdntfctn;
    @XmlElement(name = "Statmnt")
    protected StatementAdditionalAmountType statmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsCoverStatementType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsCoverStatementType(final CoverIdentificationType covIdntfctn, final StatementAdditionalAmountType statmnt) {
        this.covIdntfctn = covIdntfctn;
        this.statmnt = statmnt;
    }

    /**
     * Gets the value of the covIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link CoverIdentificationType }
     *     
     */
    public CoverIdentificationType getCovIdntfctn() {
        return covIdntfctn;
    }

    /**
     * Sets the value of the covIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverIdentificationType }
     *     
     */
    public void setCovIdntfctn(CoverIdentificationType value) {
        this.covIdntfctn = value;
    }

    public boolean isSetCovIdntfctn() {
        return (this.covIdntfctn!= null);
    }

    /**
     * Gets the value of the statmnt property.
     * 
     * @return
     *     possible object is
     *     {@link StatementAdditionalAmountType }
     *     
     */
    public StatementAdditionalAmountType getStatmnt() {
        return statmnt;
    }

    /**
     * Sets the value of the statmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatementAdditionalAmountType }
     *     
     */
    public void setStatmnt(StatementAdditionalAmountType value) {
        this.statmnt = value;
    }

    public boolean isSetStatmnt() {
        return (this.statmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covIdntfctn", covIdntfctn).add("statmnt", statmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covIdntfctn, statmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsCoverStatementType o = ((SavingsCoverStatementType) other);
        return (Objects.equal(covIdntfctn, o.covIdntfctn)&&Objects.equal(statmnt, o.statmnt));
    }

}
