
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a claim benefit has dependencies
 * 			
 * 
 * <p>Java class for ProtectionClaimBenefitLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionClaimBenefitLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductIdentificationAndHierarchyDataType" minOccurs="0"/&gt;
 *         &lt;element name="Cov" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationCoverIdentificationType"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" minOccurs="0"/&gt;
 *         &lt;element name="Prdcr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Benfciary" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="Insrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="ClaimDeclrtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Claim" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionClaimBenefitLinkedObjectsType", propOrder = {
    "pdct",
    "corePdct",
    "cov",
    "pol",
    "distrbtr",
    "prdcr",
    "benfciary",
    "insrd",
    "claimDeclrtn",
    "claim"
})
public class ProtectionClaimBenefitLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct", required = true)
    protected ObjectIdentificationWithVersionType pdct;
    @XmlElement(name = "CorePdct")
    protected CoreProductIdentificationAndHierarchyDataType corePdct;
    @XmlElement(name = "Cov", required = true)
    protected OperationCoverIdentificationType cov;
    @XmlElement(name = "Pol", required = true)
    protected ObjectIdentificationType pol;
    @XmlElement(name = "Distrbtr")
    protected PartnerPartyType distrbtr;
    @XmlElement(name = "Prdcr", required = true)
    protected PartyRoleType prdcr;
    @XmlElement(name = "Benfciary")
    protected PartyRoleType benfciary;
    @XmlElement(name = "Insrd")
    protected PartyRoleType insrd;
    @XmlElement(name = "ClaimDeclrtn")
    protected ObjectIdentificationType claimDeclrtn;
    @XmlElement(name = "Claim")
    protected ObjectIdentificationType claim;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionClaimBenefitLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionClaimBenefitLinkedObjectsType(final ObjectIdentificationWithVersionType pdct, final CoreProductIdentificationAndHierarchyDataType corePdct, final OperationCoverIdentificationType cov, final ObjectIdentificationType pol, final PartnerPartyType distrbtr, final PartyRoleType prdcr, final PartyRoleType benfciary, final PartyRoleType insrd, final ObjectIdentificationType claimDeclrtn, final ObjectIdentificationType claim) {
        this.pdct = pdct;
        this.corePdct = corePdct;
        this.cov = cov;
        this.pol = pol;
        this.distrbtr = distrbtr;
        this.prdcr = prdcr;
        this.benfciary = benfciary;
        this.insrd = insrd;
        this.claimDeclrtn = claimDeclrtn;
        this.claim = claim;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setPdct(ObjectIdentificationWithVersionType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public CoreProductIdentificationAndHierarchyDataType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public void setCorePdct(CoreProductIdentificationAndHierarchyDataType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    /**
     * Gets the value of the cov property.
     * 
     * @return
     *     possible object is
     *     {@link OperationCoverIdentificationType }
     *     
     */
    public OperationCoverIdentificationType getCov() {
        return cov;
    }

    /**
     * Sets the value of the cov property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationCoverIdentificationType }
     *     
     */
    public void setCov(OperationCoverIdentificationType value) {
        this.cov = value;
    }

    public boolean isSetCov() {
        return (this.cov!= null);
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * @return
     *     possible object is
     *     {@link PartnerPartyType }
     *     
     */
    public PartnerPartyType getDistrbtr() {
        return distrbtr;
    }

    /**
     * Sets the value of the distrbtr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartnerPartyType }
     *     
     */
    public void setDistrbtr(PartnerPartyType value) {
        this.distrbtr = value;
    }

    public boolean isSetDistrbtr() {
        return (this.distrbtr!= null);
    }

    /**
     * Gets the value of the prdcr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdcr() {
        return prdcr;
    }

    /**
     * Sets the value of the prdcr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdcr(PartyRoleType value) {
        this.prdcr = value;
    }

    public boolean isSetPrdcr() {
        return (this.prdcr!= null);
    }

    /**
     * Gets the value of the benfciary property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getBenfciary() {
        return benfciary;
    }

    /**
     * Sets the value of the benfciary property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setBenfciary(PartyRoleType value) {
        this.benfciary = value;
    }

    public boolean isSetBenfciary() {
        return (this.benfciary!= null);
    }

    /**
     * Gets the value of the insrd property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsrd() {
        return insrd;
    }

    /**
     * Sets the value of the insrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsrd(PartyRoleType value) {
        this.insrd = value;
    }

    public boolean isSetInsrd() {
        return (this.insrd!= null);
    }

    /**
     * Gets the value of the claimDeclrtn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getClaimDeclrtn() {
        return claimDeclrtn;
    }

    /**
     * Sets the value of the claimDeclrtn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setClaimDeclrtn(ObjectIdentificationType value) {
        this.claimDeclrtn = value;
    }

    public boolean isSetClaimDeclrtn() {
        return (this.claimDeclrtn!= null);
    }

    /**
     * Gets the value of the claim property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getClaim() {
        return claim;
    }

    /**
     * Sets the value of the claim property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setClaim(ObjectIdentificationType value) {
        this.claim = value;
    }

    public boolean isSetClaim() {
        return (this.claim!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("corePdct", corePdct).add("cov", cov).add("pol", pol).add("distrbtr", distrbtr).add("prdcr", prdcr).add("benfciary", benfciary).add("insrd", insrd).add("claimDeclrtn", claimDeclrtn).add("claim", claim).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, corePdct, cov, pol, distrbtr, prdcr, benfciary, insrd, claimDeclrtn, claim);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionClaimBenefitLinkedObjectsType o = ((ProtectionClaimBenefitLinkedObjectsType) other);
        return (((((((((Objects.equal(pdct, o.pdct)&&Objects.equal(corePdct, o.corePdct))&&Objects.equal(cov, o.cov))&&Objects.equal(pol, o.pol))&&Objects.equal(distrbtr, o.distrbtr))&&Objects.equal(prdcr, o.prdcr))&&Objects.equal(benfciary, o.benfciary))&&Objects.equal(insrd, o.insrd))&&Objects.equal(claimDeclrtn, o.claimDeclrtn))&&Objects.equal(claim, o.claim));
    }

}
