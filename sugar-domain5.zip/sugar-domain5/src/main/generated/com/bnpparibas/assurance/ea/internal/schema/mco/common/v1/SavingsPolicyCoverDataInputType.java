
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to define data of cover linked to a savings
 * 				policy
 * 			
 * 
 * <p>Java class for SavingsPolicyCoverDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyCoverDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverIdentificationInputType" minOccurs="0"/&gt;
 *         &lt;element name="LinkdObjcts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsPolicyCoverLinkedObjectsType" minOccurs="0"/&gt;
 *         &lt;element name="CovData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsCoverDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="BnkngRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentMethodWithPayerInputType" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverBeneficiaryClauseInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyCoverDataInputType", propOrder = {
    "covIdntfctn",
    "linkdObjcts",
    "covData",
    "bnkngRef",
    "benfciaryClause"
})
public class SavingsPolicyCoverDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovIdntfctn")
    protected CoverIdentificationInputType covIdntfctn;
    @XmlElement(name = "LinkdObjcts")
    protected SavingsPolicyCoverLinkedObjectsType linkdObjcts;
    @XmlElement(name = "CovData")
    protected SavingsCoverDataInputType covData;
    @XmlElement(name = "BnkngRef")
    protected PaymentMethodWithPayerInputType bnkngRef;
    @XmlElement(name = "BenfciaryClause")
    protected CoverBeneficiaryClauseInputType benfciaryClause;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyCoverDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyCoverDataInputType(final CoverIdentificationInputType covIdntfctn, final SavingsPolicyCoverLinkedObjectsType linkdObjcts, final SavingsCoverDataInputType covData, final PaymentMethodWithPayerInputType bnkngRef, final CoverBeneficiaryClauseInputType benfciaryClause) {
        this.covIdntfctn = covIdntfctn;
        this.linkdObjcts = linkdObjcts;
        this.covData = covData;
        this.bnkngRef = bnkngRef;
        this.benfciaryClause = benfciaryClause;
    }

    /**
     * Gets the value of the covIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link CoverIdentificationInputType }
     *     
     */
    public CoverIdentificationInputType getCovIdntfctn() {
        return covIdntfctn;
    }

    /**
     * Sets the value of the covIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverIdentificationInputType }
     *     
     */
    public void setCovIdntfctn(CoverIdentificationInputType value) {
        this.covIdntfctn = value;
    }

    public boolean isSetCovIdntfctn() {
        return (this.covIdntfctn!= null);
    }

    /**
     * Gets the value of the linkdObjcts property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsPolicyCoverLinkedObjectsType }
     *     
     */
    public SavingsPolicyCoverLinkedObjectsType getLinkdObjcts() {
        return linkdObjcts;
    }

    /**
     * Sets the value of the linkdObjcts property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsPolicyCoverLinkedObjectsType }
     *     
     */
    public void setLinkdObjcts(SavingsPolicyCoverLinkedObjectsType value) {
        this.linkdObjcts = value;
    }

    public boolean isSetLinkdObjcts() {
        return (this.linkdObjcts!= null);
    }

    /**
     * Gets the value of the covData property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsCoverDataInputType }
     *     
     */
    public SavingsCoverDataInputType getCovData() {
        return covData;
    }

    /**
     * Sets the value of the covData property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsCoverDataInputType }
     *     
     */
    public void setCovData(SavingsCoverDataInputType value) {
        this.covData = value;
    }

    public boolean isSetCovData() {
        return (this.covData!= null);
    }

    /**
     * Gets the value of the bnkngRef property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodWithPayerInputType }
     *     
     */
    public PaymentMethodWithPayerInputType getBnkngRef() {
        return bnkngRef;
    }

    /**
     * Sets the value of the bnkngRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodWithPayerInputType }
     *     
     */
    public void setBnkngRef(PaymentMethodWithPayerInputType value) {
        this.bnkngRef = value;
    }

    public boolean isSetBnkngRef() {
        return (this.bnkngRef!= null);
    }

    /**
     * Gets the value of the benfciaryClause property.
     * 
     * @return
     *     possible object is
     *     {@link CoverBeneficiaryClauseInputType }
     *     
     */
    public CoverBeneficiaryClauseInputType getBenfciaryClause() {
        return benfciaryClause;
    }

    /**
     * Sets the value of the benfciaryClause property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverBeneficiaryClauseInputType }
     *     
     */
    public void setBenfciaryClause(CoverBeneficiaryClauseInputType value) {
        this.benfciaryClause = value;
    }

    public boolean isSetBenfciaryClause() {
        return (this.benfciaryClause!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covIdntfctn", covIdntfctn).add("linkdObjcts", linkdObjcts).add("covData", covData).add("bnkngRef", bnkngRef).add("benfciaryClause", benfciaryClause).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covIdntfctn, linkdObjcts, covData, bnkngRef, benfciaryClause);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyCoverDataInputType o = ((SavingsPolicyCoverDataInputType) other);
        return ((((Objects.equal(covIdntfctn, o.covIdntfctn)&&Objects.equal(linkdObjcts, o.linkdObjcts))&&Objects.equal(covData, o.covData))&&Objects.equal(bnkngRef, o.bnkngRef))&&Objects.equal(benfciaryClause, o.benfciaryClause));
    }

}
