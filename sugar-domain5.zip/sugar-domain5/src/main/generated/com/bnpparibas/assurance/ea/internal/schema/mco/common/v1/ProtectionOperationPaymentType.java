
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage the payment of protection operation
 * 			
 * 
 * <p>Java class for ProtectionOperationPaymentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionOperationPaymentType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PaymntRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentMethodWithPayerInputType" minOccurs="0"/&gt;
 *         &lt;element name="UniquePremPaymnt" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="CheckNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *                   &lt;element name="TransData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CardTransactionDataType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PremPaymntAllctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationPaymentAllocationDataInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionOperationPaymentType", propOrder = {
    "paymntRef",
    "uniquePremPaymnt",
    "premPaymntAllctn"
})
public class ProtectionOperationPaymentType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PaymntRef")
    protected PaymentMethodWithPayerInputType paymntRef;
    @XmlElement(name = "UniquePremPaymnt")
    protected ProtectionOperationPaymentType.UniquePremPaymnt uniquePremPaymnt;
    @XmlElement(name = "PremPaymntAllctn")
    protected OperationPaymentAllocationDataInputType premPaymntAllctn;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionOperationPaymentType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionOperationPaymentType(final PaymentMethodWithPayerInputType paymntRef, final ProtectionOperationPaymentType.UniquePremPaymnt uniquePremPaymnt, final OperationPaymentAllocationDataInputType premPaymntAllctn) {
        this.paymntRef = paymntRef;
        this.uniquePremPaymnt = uniquePremPaymnt;
        this.premPaymntAllctn = premPaymntAllctn;
    }

    /**
     * Gets the value of the paymntRef property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodWithPayerInputType }
     *     
     */
    public PaymentMethodWithPayerInputType getPaymntRef() {
        return paymntRef;
    }

    /**
     * Sets the value of the paymntRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodWithPayerInputType }
     *     
     */
    public void setPaymntRef(PaymentMethodWithPayerInputType value) {
        this.paymntRef = value;
    }

    public boolean isSetPaymntRef() {
        return (this.paymntRef!= null);
    }

    /**
     * Gets the value of the uniquePremPaymnt property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionOperationPaymentType.UniquePremPaymnt }
     *     
     */
    public ProtectionOperationPaymentType.UniquePremPaymnt getUniquePremPaymnt() {
        return uniquePremPaymnt;
    }

    /**
     * Sets the value of the uniquePremPaymnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionOperationPaymentType.UniquePremPaymnt }
     *     
     */
    public void setUniquePremPaymnt(ProtectionOperationPaymentType.UniquePremPaymnt value) {
        this.uniquePremPaymnt = value;
    }

    public boolean isSetUniquePremPaymnt() {
        return (this.uniquePremPaymnt!= null);
    }

    /**
     * Gets the value of the premPaymntAllctn property.
     * 
     * @return
     *     possible object is
     *     {@link OperationPaymentAllocationDataInputType }
     *     
     */
    public OperationPaymentAllocationDataInputType getPremPaymntAllctn() {
        return premPaymntAllctn;
    }

    /**
     * Sets the value of the premPaymntAllctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationPaymentAllocationDataInputType }
     *     
     */
    public void setPremPaymntAllctn(OperationPaymentAllocationDataInputType value) {
        this.premPaymntAllctn = value;
    }

    public boolean isSetPremPaymntAllctn() {
        return (this.premPaymntAllctn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("paymntRef", paymntRef).add("uniquePremPaymnt", uniquePremPaymnt).add("premPaymntAllctn", premPaymntAllctn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(paymntRef, uniquePremPaymnt, premPaymntAllctn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionOperationPaymentType o = ((ProtectionOperationPaymentType) other);
        return ((Objects.equal(paymntRef, o.paymntRef)&&Objects.equal(uniquePremPaymnt, o.uniquePremPaymnt))&&Objects.equal(premPaymntAllctn, o.premPaymntAllctn));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="CheckNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
     *         &lt;element name="TransData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CardTransactionDataType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "checkNumb",
        "transData"
    })
    public static class UniquePremPaymnt implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "CheckNumb")
        protected String checkNumb;
        @XmlElement(name = "TransData")
        protected CardTransactionDataType transData;

        /**
         * Default no-arg constructor
         * 
         */
        public UniquePremPaymnt() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public UniquePremPaymnt(final String checkNumb, final CardTransactionDataType transData) {
            this.checkNumb = checkNumb;
            this.transData = transData;
        }

        /**
         * Gets the value of the checkNumb property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCheckNumb() {
            return checkNumb;
        }

        /**
         * Sets the value of the checkNumb property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCheckNumb(String value) {
            this.checkNumb = value;
        }

        public boolean isSetCheckNumb() {
            return (this.checkNumb!= null);
        }

        /**
         * Gets the value of the transData property.
         * 
         * @return
         *     possible object is
         *     {@link CardTransactionDataType }
         *     
         */
        public CardTransactionDataType getTransData() {
            return transData;
        }

        /**
         * Sets the value of the transData property.
         * 
         * @param value
         *     allowed object is
         *     {@link CardTransactionDataType }
         *     
         */
        public void setTransData(CardTransactionDataType value) {
            this.transData = value;
        }

        public boolean isSetTransData() {
            return (this.transData!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("checkNumb", checkNumb).add("transData", transData).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(checkNumb, transData);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ProtectionOperationPaymentType.UniquePremPaymnt o = ((ProtectionOperationPaymentType.UniquePremPaymnt) other);
            return (Objects.equal(checkNumb, o.checkNumb)&&Objects.equal(transData, o.transData));
        }

    }

}
