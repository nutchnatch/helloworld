
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage data on tax simulation for savings
 * 				policy
 * 			
 * 
 * <p>Java class for SavingsPolicyTaxSimulationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyTaxSimulationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SmltionDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="SmltionAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StatementAdditionalAmountType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyTaxSimulationType", propOrder = {
    "smltionDate",
    "smltionAmnt"
})
public class SavingsPolicyTaxSimulationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SmltionDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date smltionDate;
    @XmlElement(name = "SmltionAmnt")
    protected List<StatementAdditionalAmountType> smltionAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyTaxSimulationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyTaxSimulationType(final Date smltionDate, final List<StatementAdditionalAmountType> smltionAmnt) {
        this.smltionDate = smltionDate;
        this.smltionAmnt = smltionAmnt;
    }

    /**
     * Gets the value of the smltionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSmltionDate() {
        return smltionDate;
    }

    /**
     * Sets the value of the smltionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSmltionDate(Date value) {
        this.smltionDate = value;
    }

    public boolean isSetSmltionDate() {
        return (this.smltionDate!= null);
    }

    /**
     * Gets the value of the smltionAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the smltionAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSmltionAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatementAdditionalAmountType }
     * 
     * 
     */
    public List<StatementAdditionalAmountType> getSmltionAmnt() {
        if (smltionAmnt == null) {
            smltionAmnt = new ArrayList<StatementAdditionalAmountType>();
        }
        return this.smltionAmnt;
    }

    public boolean isSetSmltionAmnt() {
        return ((this.smltionAmnt!= null)&&(!this.smltionAmnt.isEmpty()));
    }

    public void unsetSmltionAmnt() {
        this.smltionAmnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("smltionDate", smltionDate).add("smltionAmnt", smltionAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(smltionDate, smltionAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyTaxSimulationType o = ((SavingsPolicyTaxSimulationType) other);
        return (Objects.equal(smltionDate, o.smltionDate)&&Objects.equal(smltionAmnt, o.smltionAmnt));
    }

}
