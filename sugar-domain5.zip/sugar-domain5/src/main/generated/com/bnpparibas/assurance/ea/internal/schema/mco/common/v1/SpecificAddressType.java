
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage addresses which are t are specific
 * 				to policies , cash bank account, etc
 * 			
 * 
 * <p>Java class for SpecificAddressType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SpecificAddressType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PostAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PostalAddressType"/&gt;
 *         &lt;element name="MailRecipintName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="AddMailRecipintName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="Recipint" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecificAddressType", propOrder = {
    "postAdrs",
    "mailRecipintName",
    "addMailRecipintName",
    "recipint"
})
public class SpecificAddressType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PostAdrs", required = true)
    protected PostalAddressType postAdrs;
    @XmlElement(name = "MailRecipintName")
    protected String mailRecipintName;
    @XmlElement(name = "AddMailRecipintName")
    protected String addMailRecipintName;
    @XmlElement(name = "Recipint")
    protected PartyRoleType recipint;

    /**
     * Default no-arg constructor
     * 
     */
    public SpecificAddressType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SpecificAddressType(final PostalAddressType postAdrs, final String mailRecipintName, final String addMailRecipintName, final PartyRoleType recipint) {
        this.postAdrs = postAdrs;
        this.mailRecipintName = mailRecipintName;
        this.addMailRecipintName = addMailRecipintName;
        this.recipint = recipint;
    }

    /**
     * Gets the value of the postAdrs property.
     * 
     * @return
     *     possible object is
     *     {@link PostalAddressType }
     *     
     */
    public PostalAddressType getPostAdrs() {
        return postAdrs;
    }

    /**
     * Sets the value of the postAdrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link PostalAddressType }
     *     
     */
    public void setPostAdrs(PostalAddressType value) {
        this.postAdrs = value;
    }

    public boolean isSetPostAdrs() {
        return (this.postAdrs!= null);
    }

    /**
     * Gets the value of the mailRecipintName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailRecipintName() {
        return mailRecipintName;
    }

    /**
     * Sets the value of the mailRecipintName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailRecipintName(String value) {
        this.mailRecipintName = value;
    }

    public boolean isSetMailRecipintName() {
        return (this.mailRecipintName!= null);
    }

    /**
     * Gets the value of the addMailRecipintName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddMailRecipintName() {
        return addMailRecipintName;
    }

    /**
     * Sets the value of the addMailRecipintName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddMailRecipintName(String value) {
        this.addMailRecipintName = value;
    }

    public boolean isSetAddMailRecipintName() {
        return (this.addMailRecipintName!= null);
    }

    /**
     * Gets the value of the recipint property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getRecipint() {
        return recipint;
    }

    /**
     * Sets the value of the recipint property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setRecipint(PartyRoleType value) {
        this.recipint = value;
    }

    public boolean isSetRecipint() {
        return (this.recipint!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("postAdrs", postAdrs).add("mailRecipintName", mailRecipintName).add("addMailRecipintName", addMailRecipintName).add("recipint", recipint).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(postAdrs, mailRecipintName, addMailRecipintName, recipint);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SpecificAddressType o = ((SpecificAddressType) other);
        return (((Objects.equal(postAdrs, o.postAdrs)&&Objects.equal(mailRecipintName, o.mailRecipintName))&&Objects.equal(addMailRecipintName, o.addMailRecipintName))&&Objects.equal(recipint, o.recipint));
    }

}
