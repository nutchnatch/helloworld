
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Cover linked opbjects
 * 
 * <p>Java class for ProductCoverLinkedObjectDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductCoverLinkedObjectDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Insurer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="PckgeId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductCoverLinkedObjectDataType", propOrder = {
    "insurer",
    "pckgeId"
})
public class ProductCoverLinkedObjectDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Insurer", required = true)
    protected PartyRoleType insurer;
    @XmlElement(name = "PckgeId")
    protected String pckgeId;

    /**
     * Default no-arg constructor
     * 
     */
    public ProductCoverLinkedObjectDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProductCoverLinkedObjectDataType(final PartyRoleType insurer, final String pckgeId) {
        this.insurer = insurer;
        this.pckgeId = pckgeId;
    }

    /**
     * Gets the value of the insurer property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsurer() {
        return insurer;
    }

    /**
     * Sets the value of the insurer property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsurer(PartyRoleType value) {
        this.insurer = value;
    }

    public boolean isSetInsurer() {
        return (this.insurer!= null);
    }

    /**
     * Gets the value of the pckgeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPckgeId() {
        return pckgeId;
    }

    /**
     * Sets the value of the pckgeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPckgeId(String value) {
        this.pckgeId = value;
    }

    public boolean isSetPckgeId() {
        return (this.pckgeId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("insurer", insurer).add("pckgeId", pckgeId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(insurer, pckgeId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProductCoverLinkedObjectDataType o = ((ProductCoverLinkedObjectDataType) other);
        return (Objects.equal(insurer, o.insurer)&&Objects.equal(pckgeId, o.pckgeId));
    }

}
