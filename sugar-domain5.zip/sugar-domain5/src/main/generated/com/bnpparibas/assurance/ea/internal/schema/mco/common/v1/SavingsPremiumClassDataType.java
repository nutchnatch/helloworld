
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information Min and max premium
 * 				payment class (in france for contrat Madelin, Agri)
 * 			
 * 
 * <p>Java class for SavingsPremiumClassDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPremiumClassDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PremClass" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="AnnualMinAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="AnnualMaxAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPremiumClassDataType", propOrder = {
    "premClass",
    "annualMinAmnt",
    "annualMaxAmnt"
})
public class SavingsPremiumClassDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PremClass")
    protected String premClass;
    @XmlElement(name = "AnnualMinAmnt")
    protected CurrencyAndAmountType annualMinAmnt;
    @XmlElement(name = "AnnualMaxAmnt")
    protected CurrencyAndAmountType annualMaxAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPremiumClassDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPremiumClassDataType(final String premClass, final CurrencyAndAmountType annualMinAmnt, final CurrencyAndAmountType annualMaxAmnt) {
        this.premClass = premClass;
        this.annualMinAmnt = annualMinAmnt;
        this.annualMaxAmnt = annualMaxAmnt;
    }

    /**
     * Gets the value of the premClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremClass() {
        return premClass;
    }

    /**
     * Sets the value of the premClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremClass(String value) {
        this.premClass = value;
    }

    public boolean isSetPremClass() {
        return (this.premClass!= null);
    }

    /**
     * Gets the value of the annualMinAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAnnualMinAmnt() {
        return annualMinAmnt;
    }

    /**
     * Sets the value of the annualMinAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAnnualMinAmnt(CurrencyAndAmountType value) {
        this.annualMinAmnt = value;
    }

    public boolean isSetAnnualMinAmnt() {
        return (this.annualMinAmnt!= null);
    }

    /**
     * Gets the value of the annualMaxAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAnnualMaxAmnt() {
        return annualMaxAmnt;
    }

    /**
     * Sets the value of the annualMaxAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAnnualMaxAmnt(CurrencyAndAmountType value) {
        this.annualMaxAmnt = value;
    }

    public boolean isSetAnnualMaxAmnt() {
        return (this.annualMaxAmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("premClass", premClass).add("annualMinAmnt", annualMinAmnt).add("annualMaxAmnt", annualMaxAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(premClass, annualMinAmnt, annualMaxAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPremiumClassDataType o = ((SavingsPremiumClassDataType) other);
        return ((Objects.equal(premClass, o.premClass)&&Objects.equal(annualMinAmnt, o.annualMinAmnt))&&Objects.equal(annualMaxAmnt, o.annualMaxAmnt));
    }

}
