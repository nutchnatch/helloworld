
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage links between simplified protection
 * 				product and other objects
 * 			
 * 
 * <p>Java class for ProtectionProductLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionProductLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Prdcr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Partnr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductIdentificationAndHierarchyDataType" minOccurs="0"/&gt;
 *         &lt;element name="ComrclOffer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommercialOfferSharedDataApplicationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionProductLinkedObjectsType", propOrder = {
    "prdcr",
    "partnr",
    "corePdct",
    "comrclOffer"
})
public class ProtectionProductLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Prdcr", required = true)
    protected PartyRoleType prdcr;
    @XmlElement(name = "Partnr")
    protected List<PartnerPartyType> partnr;
    @XmlElement(name = "CorePdct")
    protected CoreProductIdentificationAndHierarchyDataType corePdct;
    @XmlElement(name = "ComrclOffer")
    protected List<CommercialOfferSharedDataApplicationType> comrclOffer;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionProductLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionProductLinkedObjectsType(final PartyRoleType prdcr, final List<PartnerPartyType> partnr, final CoreProductIdentificationAndHierarchyDataType corePdct, final List<CommercialOfferSharedDataApplicationType> comrclOffer) {
        this.prdcr = prdcr;
        this.partnr = partnr;
        this.corePdct = corePdct;
        this.comrclOffer = comrclOffer;
    }

    /**
     * Gets the value of the prdcr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdcr() {
        return prdcr;
    }

    /**
     * Sets the value of the prdcr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdcr(PartyRoleType value) {
        this.prdcr = value;
    }

    public boolean isSetPrdcr() {
        return (this.prdcr!= null);
    }

    /**
     * Gets the value of the partnr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partnr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartnr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getPartnr() {
        if (partnr == null) {
            partnr = new ArrayList<PartnerPartyType>();
        }
        return this.partnr;
    }

    public boolean isSetPartnr() {
        return ((this.partnr!= null)&&(!this.partnr.isEmpty()));
    }

    public void unsetPartnr() {
        this.partnr = null;
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public CoreProductIdentificationAndHierarchyDataType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public void setCorePdct(CoreProductIdentificationAndHierarchyDataType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    /**
     * Gets the value of the comrclOffer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comrclOffer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComrclOffer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommercialOfferSharedDataApplicationType }
     * 
     * 
     */
    public List<CommercialOfferSharedDataApplicationType> getComrclOffer() {
        if (comrclOffer == null) {
            comrclOffer = new ArrayList<CommercialOfferSharedDataApplicationType>();
        }
        return this.comrclOffer;
    }

    public boolean isSetComrclOffer() {
        return ((this.comrclOffer!= null)&&(!this.comrclOffer.isEmpty()));
    }

    public void unsetComrclOffer() {
        this.comrclOffer = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("prdcr", prdcr).add("partnr", partnr).add("corePdct", corePdct).add("comrclOffer", comrclOffer).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(prdcr, partnr, corePdct, comrclOffer);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionProductLinkedObjectsType o = ((ProtectionProductLinkedObjectsType) other);
        return (((Objects.equal(prdcr, o.prdcr)&&Objects.equal(partnr, o.partnr))&&Objects.equal(corePdct, o.corePdct))&&Objects.equal(comrclOffer, o.comrclOffer));
    }

}
