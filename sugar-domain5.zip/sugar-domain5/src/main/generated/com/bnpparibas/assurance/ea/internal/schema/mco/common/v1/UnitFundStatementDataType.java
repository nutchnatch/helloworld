
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage data on a unit fund for statement
 * 			
 * 
 * <p>Java class for UnitFundStatementDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UnitFundStatementDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UnitNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="NetAsstValueDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="NetAsstValue" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="FundNetAsstValue" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="CntrctlNavDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ValuatnDateTime" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="CurrExchngeFixng" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyExchangeDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UnitFundStatementDataType", propOrder = {
    "unitNumb",
    "netAsstValueDate",
    "netAsstValue",
    "fundNetAsstValue",
    "cntrctlNavDate",
    "valuatnDateTime",
    "currExchngeFixng"
})
public class UnitFundStatementDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "UnitNumb")
    protected Double unitNumb;
    @XmlElement(name = "NetAsstValueDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date netAsstValueDate;
    @XmlElement(name = "NetAsstValue")
    protected CurrencyAndAmountType netAsstValue;
    @XmlElement(name = "FundNetAsstValue")
    protected CurrencyAndAmountType fundNetAsstValue;
    @XmlElement(name = "CntrctlNavDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date cntrctlNavDate;
    @XmlElement(name = "ValuatnDateTime", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date valuatnDateTime;
    @XmlElement(name = "CurrExchngeFixng")
    protected CurrencyExchangeDataType currExchngeFixng;

    /**
     * Default no-arg constructor
     * 
     */
    public UnitFundStatementDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public UnitFundStatementDataType(final Double unitNumb, final Date netAsstValueDate, final CurrencyAndAmountType netAsstValue, final CurrencyAndAmountType fundNetAsstValue, final Date cntrctlNavDate, final Date valuatnDateTime, final CurrencyExchangeDataType currExchngeFixng) {
        this.unitNumb = unitNumb;
        this.netAsstValueDate = netAsstValueDate;
        this.netAsstValue = netAsstValue;
        this.fundNetAsstValue = fundNetAsstValue;
        this.cntrctlNavDate = cntrctlNavDate;
        this.valuatnDateTime = valuatnDateTime;
        this.currExchngeFixng = currExchngeFixng;
    }

    /**
     * Gets the value of the unitNumb property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUnitNumb() {
        return unitNumb;
    }

    /**
     * Sets the value of the unitNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUnitNumb(Double value) {
        this.unitNumb = value;
    }

    public boolean isSetUnitNumb() {
        return (this.unitNumb!= null);
    }

    /**
     * Gets the value of the netAsstValueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getNetAsstValueDate() {
        return netAsstValueDate;
    }

    /**
     * Sets the value of the netAsstValueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetAsstValueDate(Date value) {
        this.netAsstValueDate = value;
    }

    public boolean isSetNetAsstValueDate() {
        return (this.netAsstValueDate!= null);
    }

    /**
     * Gets the value of the netAsstValue property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getNetAsstValue() {
        return netAsstValue;
    }

    /**
     * Sets the value of the netAsstValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setNetAsstValue(CurrencyAndAmountType value) {
        this.netAsstValue = value;
    }

    public boolean isSetNetAsstValue() {
        return (this.netAsstValue!= null);
    }

    /**
     * Gets the value of the fundNetAsstValue property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFundNetAsstValue() {
        return fundNetAsstValue;
    }

    /**
     * Sets the value of the fundNetAsstValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFundNetAsstValue(CurrencyAndAmountType value) {
        this.fundNetAsstValue = value;
    }

    public boolean isSetFundNetAsstValue() {
        return (this.fundNetAsstValue!= null);
    }

    /**
     * Gets the value of the cntrctlNavDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCntrctlNavDate() {
        return cntrctlNavDate;
    }

    /**
     * Sets the value of the cntrctlNavDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCntrctlNavDate(Date value) {
        this.cntrctlNavDate = value;
    }

    public boolean isSetCntrctlNavDate() {
        return (this.cntrctlNavDate!= null);
    }

    /**
     * Gets the value of the valuatnDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValuatnDateTime() {
        return valuatnDateTime;
    }

    /**
     * Sets the value of the valuatnDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValuatnDateTime(Date value) {
        this.valuatnDateTime = value;
    }

    public boolean isSetValuatnDateTime() {
        return (this.valuatnDateTime!= null);
    }

    /**
     * Gets the value of the currExchngeFixng property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyExchangeDataType }
     *     
     */
    public CurrencyExchangeDataType getCurrExchngeFixng() {
        return currExchngeFixng;
    }

    /**
     * Sets the value of the currExchngeFixng property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyExchangeDataType }
     *     
     */
    public void setCurrExchngeFixng(CurrencyExchangeDataType value) {
        this.currExchngeFixng = value;
    }

    public boolean isSetCurrExchngeFixng() {
        return (this.currExchngeFixng!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("unitNumb", unitNumb).add("netAsstValueDate", netAsstValueDate).add("netAsstValue", netAsstValue).add("fundNetAsstValue", fundNetAsstValue).add("cntrctlNavDate", cntrctlNavDate).add("valuatnDateTime", valuatnDateTime).add("currExchngeFixng", currExchngeFixng).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(unitNumb, netAsstValueDate, netAsstValue, fundNetAsstValue, cntrctlNavDate, valuatnDateTime, currExchngeFixng);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final UnitFundStatementDataType o = ((UnitFundStatementDataType) other);
        return ((((((Objects.equal(unitNumb, o.unitNumb)&&Objects.equal(netAsstValueDate, o.netAsstValueDate))&&Objects.equal(netAsstValue, o.netAsstValue))&&Objects.equal(fundNetAsstValue, o.fundNetAsstValue))&&Objects.equal(cntrctlNavDate, o.cntrctlNavDate))&&Objects.equal(valuatnDateTime, o.valuatnDateTime))&&Objects.equal(currExchngeFixng, o.currExchngeFixng));
    }

}
