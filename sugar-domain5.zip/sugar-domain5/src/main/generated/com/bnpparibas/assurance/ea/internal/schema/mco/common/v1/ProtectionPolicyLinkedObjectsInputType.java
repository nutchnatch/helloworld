
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a protection policy has
 * 				dependencies
 * 			
 * 
 * <p>Java class for ProtectionPolicyLinkedObjectsInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyLinkedObjectsInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductSharedDataType" minOccurs="0"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductIdentificationAndHierarchyDataType" minOccurs="0"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Cust" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExtendedPersonIdentificationAndRoleType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="GrpPol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GroupPolicySharedDataType" minOccurs="0"/&gt;
 *         &lt;element name="ComrclOffer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommercialOfferSharedDataApplicationInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyLinkedObjectsInputType", propOrder = {
    "pdct",
    "corePdct",
    "distrbtr",
    "prdctr",
    "cust",
    "grpPol",
    "comrclOffer",
    "pol"
})
public class ProtectionPolicyLinkedObjectsInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct")
    protected ProductSharedDataType pdct;
    @XmlElement(name = "CorePdct")
    protected CoreProductIdentificationAndHierarchyDataType corePdct;
    @XmlElement(name = "Distrbtr", required = true)
    protected List<PartnerPartyType> distrbtr;
    @XmlElement(name = "Prdctr", required = true)
    protected PartyRoleType prdctr;
    @XmlElement(name = "Cust")
    protected List<ExtendedPersonIdentificationAndRoleType> cust;
    @XmlElement(name = "GrpPol")
    protected GroupPolicySharedDataType grpPol;
    @XmlElement(name = "ComrclOffer")
    protected List<CommercialOfferSharedDataApplicationInputType> comrclOffer;
    @XmlElement(name = "Pol")
    protected ObjectIdentificationType pol;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyLinkedObjectsInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyLinkedObjectsInputType(final ProductSharedDataType pdct, final CoreProductIdentificationAndHierarchyDataType corePdct, final List<PartnerPartyType> distrbtr, final PartyRoleType prdctr, final List<ExtendedPersonIdentificationAndRoleType> cust, final GroupPolicySharedDataType grpPol, final List<CommercialOfferSharedDataApplicationInputType> comrclOffer, final ObjectIdentificationType pol) {
        this.pdct = pdct;
        this.corePdct = corePdct;
        this.distrbtr = distrbtr;
        this.prdctr = prdctr;
        this.cust = cust;
        this.grpPol = grpPol;
        this.comrclOffer = comrclOffer;
        this.pol = pol;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductSharedDataType }
     *     
     */
    public ProductSharedDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductSharedDataType }
     *     
     */
    public void setPdct(ProductSharedDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public CoreProductIdentificationAndHierarchyDataType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public void setCorePdct(CoreProductIdentificationAndHierarchyDataType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the distrbtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDistrbtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getDistrbtr() {
        if (distrbtr == null) {
            distrbtr = new ArrayList<PartnerPartyType>();
        }
        return this.distrbtr;
    }

    public boolean isSetDistrbtr() {
        return ((this.distrbtr!= null)&&(!this.distrbtr.isEmpty()));
    }

    public void unsetDistrbtr() {
        this.distrbtr = null;
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    /**
     * Gets the value of the cust property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cust property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCust().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExtendedPersonIdentificationAndRoleType }
     * 
     * 
     */
    public List<ExtendedPersonIdentificationAndRoleType> getCust() {
        if (cust == null) {
            cust = new ArrayList<ExtendedPersonIdentificationAndRoleType>();
        }
        return this.cust;
    }

    public boolean isSetCust() {
        return ((this.cust!= null)&&(!this.cust.isEmpty()));
    }

    public void unsetCust() {
        this.cust = null;
    }

    /**
     * Gets the value of the grpPol property.
     * 
     * @return
     *     possible object is
     *     {@link GroupPolicySharedDataType }
     *     
     */
    public GroupPolicySharedDataType getGrpPol() {
        return grpPol;
    }

    /**
     * Sets the value of the grpPol property.
     * 
     * @param value
     *     allowed object is
     *     {@link GroupPolicySharedDataType }
     *     
     */
    public void setGrpPol(GroupPolicySharedDataType value) {
        this.grpPol = value;
    }

    public boolean isSetGrpPol() {
        return (this.grpPol!= null);
    }

    /**
     * Gets the value of the comrclOffer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comrclOffer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComrclOffer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommercialOfferSharedDataApplicationInputType }
     * 
     * 
     */
    public List<CommercialOfferSharedDataApplicationInputType> getComrclOffer() {
        if (comrclOffer == null) {
            comrclOffer = new ArrayList<CommercialOfferSharedDataApplicationInputType>();
        }
        return this.comrclOffer;
    }

    public boolean isSetComrclOffer() {
        return ((this.comrclOffer!= null)&&(!this.comrclOffer.isEmpty()));
    }

    public void unsetComrclOffer() {
        this.comrclOffer = null;
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("corePdct", corePdct).add("distrbtr", distrbtr).add("prdctr", prdctr).add("cust", cust).add("grpPol", grpPol).add("comrclOffer", comrclOffer).add("pol", pol).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, corePdct, distrbtr, prdctr, cust, grpPol, comrclOffer, pol);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyLinkedObjectsInputType o = ((ProtectionPolicyLinkedObjectsInputType) other);
        return (((((((Objects.equal(pdct, o.pdct)&&Objects.equal(corePdct, o.corePdct))&&Objects.equal(distrbtr, o.distrbtr))&&Objects.equal(prdctr, o.prdctr))&&Objects.equal(cust, o.cust))&&Objects.equal(grpPol, o.grpPol))&&Objects.equal(comrclOffer, o.comrclOffer))&&Objects.equal(pol, o.pol));
    }

}
