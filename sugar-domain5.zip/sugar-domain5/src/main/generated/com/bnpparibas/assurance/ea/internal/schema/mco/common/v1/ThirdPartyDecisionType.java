
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Third party decision type
 * 
 * <p>Java class for ThirdPartyDecisionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThirdPartyDecisionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ThrdPrty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="FileSndngDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="FileRecptnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ThirdPartyDecisionDataType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThirdPartyDecisionType", propOrder = {
    "thrdPrty",
    "fileSndngDate",
    "fileRecptnDate",
    "data"
})
public class ThirdPartyDecisionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ThrdPrty", required = true)
    protected PartyRoleType thrdPrty;
    @XmlElement(name = "FileSndngDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date fileSndngDate;
    @XmlElement(name = "FileRecptnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date fileRecptnDate;
    @XmlElement(name = "Data", required = true)
    protected ThirdPartyDecisionDataType data;

    /**
     * Default no-arg constructor
     * 
     */
    public ThirdPartyDecisionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ThirdPartyDecisionType(final PartyRoleType thrdPrty, final Date fileSndngDate, final Date fileRecptnDate, final ThirdPartyDecisionDataType data) {
        this.thrdPrty = thrdPrty;
        this.fileSndngDate = fileSndngDate;
        this.fileRecptnDate = fileRecptnDate;
        this.data = data;
    }

    /**
     * Gets the value of the thrdPrty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getThrdPrty() {
        return thrdPrty;
    }

    /**
     * Sets the value of the thrdPrty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setThrdPrty(PartyRoleType value) {
        this.thrdPrty = value;
    }

    public boolean isSetThrdPrty() {
        return (this.thrdPrty!= null);
    }

    /**
     * Gets the value of the fileSndngDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getFileSndngDate() {
        return fileSndngDate;
    }

    /**
     * Sets the value of the fileSndngDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileSndngDate(Date value) {
        this.fileSndngDate = value;
    }

    public boolean isSetFileSndngDate() {
        return (this.fileSndngDate!= null);
    }

    /**
     * Gets the value of the fileRecptnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getFileRecptnDate() {
        return fileRecptnDate;
    }

    /**
     * Sets the value of the fileRecptnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileRecptnDate(Date value) {
        this.fileRecptnDate = value;
    }

    public boolean isSetFileRecptnDate() {
        return (this.fileRecptnDate!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link ThirdPartyDecisionDataType }
     *     
     */
    public ThirdPartyDecisionDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link ThirdPartyDecisionDataType }
     *     
     */
    public void setData(ThirdPartyDecisionDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("thrdPrty", thrdPrty).add("fileSndngDate", fileSndngDate).add("fileRecptnDate", fileRecptnDate).add("data", data).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(thrdPrty, fileSndngDate, fileRecptnDate, data);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ThirdPartyDecisionType o = ((ThirdPartyDecisionType) other);
        return (((Objects.equal(thrdPrty, o.thrdPrty)&&Objects.equal(fileSndngDate, o.fileSndngDate))&&Objects.equal(fileRecptnDate, o.fileRecptnDate))&&Objects.equal(data, o.data));
    }

}
