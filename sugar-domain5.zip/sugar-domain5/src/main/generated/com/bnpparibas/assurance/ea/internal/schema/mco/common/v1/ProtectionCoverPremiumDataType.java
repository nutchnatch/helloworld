
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To define global data of the protection cover
 * 				premium
 * 			
 * 
 * <p>Java class for ProtectionCoverPremiumDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionCoverPremiumDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PremFqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CovrdPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="GrossAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="NetAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="PureAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="AddAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AdditionalAmountType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionCoverPremiumDataType", propOrder = {
    "premFqcy",
    "covrdPrd",
    "grossAmnt",
    "netAmnt",
    "pureAmnt",
    "addAmnt"
})
public class ProtectionCoverPremiumDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PremFqcy")
    protected String premFqcy;
    @XmlElement(name = "CovrdPrd")
    protected DatePeriodType covrdPrd;
    @XmlElement(name = "GrossAmnt", required = true)
    protected CurrencyAndAmountType grossAmnt;
    @XmlElement(name = "NetAmnt")
    protected CurrencyAndAmountType netAmnt;
    @XmlElement(name = "PureAmnt")
    protected CurrencyAndAmountType pureAmnt;
    @XmlElement(name = "AddAmnt")
    protected List<AdditionalAmountType> addAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionCoverPremiumDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionCoverPremiumDataType(final String premFqcy, final DatePeriodType covrdPrd, final CurrencyAndAmountType grossAmnt, final CurrencyAndAmountType netAmnt, final CurrencyAndAmountType pureAmnt, final List<AdditionalAmountType> addAmnt) {
        this.premFqcy = premFqcy;
        this.covrdPrd = covrdPrd;
        this.grossAmnt = grossAmnt;
        this.netAmnt = netAmnt;
        this.pureAmnt = pureAmnt;
        this.addAmnt = addAmnt;
    }

    /**
     * Gets the value of the premFqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremFqcy() {
        return premFqcy;
    }

    /**
     * Sets the value of the premFqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremFqcy(String value) {
        this.premFqcy = value;
    }

    public boolean isSetPremFqcy() {
        return (this.premFqcy!= null);
    }

    /**
     * Gets the value of the covrdPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getCovrdPrd() {
        return covrdPrd;
    }

    /**
     * Sets the value of the covrdPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setCovrdPrd(DatePeriodType value) {
        this.covrdPrd = value;
    }

    public boolean isSetCovrdPrd() {
        return (this.covrdPrd!= null);
    }

    /**
     * Gets the value of the grossAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getGrossAmnt() {
        return grossAmnt;
    }

    /**
     * Sets the value of the grossAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setGrossAmnt(CurrencyAndAmountType value) {
        this.grossAmnt = value;
    }

    public boolean isSetGrossAmnt() {
        return (this.grossAmnt!= null);
    }

    /**
     * Gets the value of the netAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getNetAmnt() {
        return netAmnt;
    }

    /**
     * Sets the value of the netAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setNetAmnt(CurrencyAndAmountType value) {
        this.netAmnt = value;
    }

    public boolean isSetNetAmnt() {
        return (this.netAmnt!= null);
    }

    /**
     * Gets the value of the pureAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPureAmnt() {
        return pureAmnt;
    }

    /**
     * Sets the value of the pureAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPureAmnt(CurrencyAndAmountType value) {
        this.pureAmnt = value;
    }

    public boolean isSetPureAmnt() {
        return (this.pureAmnt!= null);
    }

    /**
     * Gets the value of the addAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmountType }
     * 
     * 
     */
    public List<AdditionalAmountType> getAddAmnt() {
        if (addAmnt == null) {
            addAmnt = new ArrayList<AdditionalAmountType>();
        }
        return this.addAmnt;
    }

    public boolean isSetAddAmnt() {
        return ((this.addAmnt!= null)&&(!this.addAmnt.isEmpty()));
    }

    public void unsetAddAmnt() {
        this.addAmnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("premFqcy", premFqcy).add("covrdPrd", covrdPrd).add("grossAmnt", grossAmnt).add("netAmnt", netAmnt).add("pureAmnt", pureAmnt).add("addAmnt", addAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(premFqcy, covrdPrd, grossAmnt, netAmnt, pureAmnt, addAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionCoverPremiumDataType o = ((ProtectionCoverPremiumDataType) other);
        return (((((Objects.equal(premFqcy, o.premFqcy)&&Objects.equal(covrdPrd, o.covrdPrd))&&Objects.equal(grossAmnt, o.grossAmnt))&&Objects.equal(netAmnt, o.netAmnt))&&Objects.equal(pureAmnt, o.pureAmnt))&&Objects.equal(addAmnt, o.addAmnt));
    }

}
