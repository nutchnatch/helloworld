
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage objects with which a protection premium
 * 				has dependencies
 * 			
 * 
 * <p>Java class for ProtectionPremiumLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPremiumLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductSharedDataType"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="CurntDebtHoldr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="InitDebtHoldr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="ComrclOffer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommercialOfferSharedDataApplicationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ThdPrtyAdmnstr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPremiumLinkedObjectsType", propOrder = {
    "pdct",
    "pol",
    "distrbtr",
    "prdctr",
    "curntDebtHoldr",
    "initDebtHoldr",
    "comrclOffer",
    "thdPrtyAdmnstr"
})
public class ProtectionPremiumLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct", required = true)
    protected ProductSharedDataType pdct;
    @XmlElement(name = "Pol", required = true)
    protected ObjectIdentificationType pol;
    @XmlElement(name = "Distrbtr", required = true)
    protected PartnerPartyType distrbtr;
    @XmlElement(name = "Prdctr", required = true)
    protected PartyRoleType prdctr;
    @XmlElement(name = "CurntDebtHoldr")
    protected PartyRoleType curntDebtHoldr;
    @XmlElement(name = "InitDebtHoldr")
    protected PartyRoleType initDebtHoldr;
    @XmlElement(name = "ComrclOffer")
    protected List<CommercialOfferSharedDataApplicationType> comrclOffer;
    @XmlElement(name = "ThdPrtyAdmnstr")
    protected PartyRoleType thdPrtyAdmnstr;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPremiumLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPremiumLinkedObjectsType(final ProductSharedDataType pdct, final ObjectIdentificationType pol, final PartnerPartyType distrbtr, final PartyRoleType prdctr, final PartyRoleType curntDebtHoldr, final PartyRoleType initDebtHoldr, final List<CommercialOfferSharedDataApplicationType> comrclOffer, final PartyRoleType thdPrtyAdmnstr) {
        this.pdct = pdct;
        this.pol = pol;
        this.distrbtr = distrbtr;
        this.prdctr = prdctr;
        this.curntDebtHoldr = curntDebtHoldr;
        this.initDebtHoldr = initDebtHoldr;
        this.comrclOffer = comrclOffer;
        this.thdPrtyAdmnstr = thdPrtyAdmnstr;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductSharedDataType }
     *     
     */
    public ProductSharedDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductSharedDataType }
     *     
     */
    public void setPdct(ProductSharedDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * @return
     *     possible object is
     *     {@link PartnerPartyType }
     *     
     */
    public PartnerPartyType getDistrbtr() {
        return distrbtr;
    }

    /**
     * Sets the value of the distrbtr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartnerPartyType }
     *     
     */
    public void setDistrbtr(PartnerPartyType value) {
        this.distrbtr = value;
    }

    public boolean isSetDistrbtr() {
        return (this.distrbtr!= null);
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    /**
     * Gets the value of the curntDebtHoldr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getCurntDebtHoldr() {
        return curntDebtHoldr;
    }

    /**
     * Sets the value of the curntDebtHoldr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setCurntDebtHoldr(PartyRoleType value) {
        this.curntDebtHoldr = value;
    }

    public boolean isSetCurntDebtHoldr() {
        return (this.curntDebtHoldr!= null);
    }

    /**
     * Gets the value of the initDebtHoldr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInitDebtHoldr() {
        return initDebtHoldr;
    }

    /**
     * Sets the value of the initDebtHoldr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInitDebtHoldr(PartyRoleType value) {
        this.initDebtHoldr = value;
    }

    public boolean isSetInitDebtHoldr() {
        return (this.initDebtHoldr!= null);
    }

    /**
     * Gets the value of the comrclOffer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comrclOffer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComrclOffer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommercialOfferSharedDataApplicationType }
     * 
     * 
     */
    public List<CommercialOfferSharedDataApplicationType> getComrclOffer() {
        if (comrclOffer == null) {
            comrclOffer = new ArrayList<CommercialOfferSharedDataApplicationType>();
        }
        return this.comrclOffer;
    }

    public boolean isSetComrclOffer() {
        return ((this.comrclOffer!= null)&&(!this.comrclOffer.isEmpty()));
    }

    public void unsetComrclOffer() {
        this.comrclOffer = null;
    }

    /**
     * Gets the value of the thdPrtyAdmnstr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getThdPrtyAdmnstr() {
        return thdPrtyAdmnstr;
    }

    /**
     * Sets the value of the thdPrtyAdmnstr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setThdPrtyAdmnstr(PartyRoleType value) {
        this.thdPrtyAdmnstr = value;
    }

    public boolean isSetThdPrtyAdmnstr() {
        return (this.thdPrtyAdmnstr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("pol", pol).add("distrbtr", distrbtr).add("prdctr", prdctr).add("curntDebtHoldr", curntDebtHoldr).add("initDebtHoldr", initDebtHoldr).add("comrclOffer", comrclOffer).add("thdPrtyAdmnstr", thdPrtyAdmnstr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, pol, distrbtr, prdctr, curntDebtHoldr, initDebtHoldr, comrclOffer, thdPrtyAdmnstr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPremiumLinkedObjectsType o = ((ProtectionPremiumLinkedObjectsType) other);
        return (((((((Objects.equal(pdct, o.pdct)&&Objects.equal(pol, o.pol))&&Objects.equal(distrbtr, o.distrbtr))&&Objects.equal(prdctr, o.prdctr))&&Objects.equal(curntDebtHoldr, o.curntDebtHoldr))&&Objects.equal(initDebtHoldr, o.initDebtHoldr))&&Objects.equal(comrclOffer, o.comrclOffer))&&Objects.equal(thdPrtyAdmnstr, o.thdPrtyAdmnstr));
    }

}
