
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on cover linked to a protection
 * 				policy
 * 			
 * 
 * <p>Java class for ProtectionPolicyCoverDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyCoverDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="LinkdObjcts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPolicyCoverLinkedObjectsInputType" minOccurs="0"/&gt;
 *         &lt;element name="CovData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionCoverDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="ClaimOptions" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverClaimTermsDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="PremOptions" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionCoverPremiumOptionsDataType" minOccurs="0"/&gt;
 *         &lt;element name="CovPaymnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionOperationPaymentType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverBeneficiaryClauseInputType" minOccurs="0"/&gt;
 *         &lt;element name="FeeDerogtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeeDerogationInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BrkrComm" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BrokerCommissionInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyCoverDataInputType", propOrder = {
    "covIdntfctn",
    "linkdObjcts",
    "covData",
    "claimOptions",
    "premOptions",
    "covPaymnt",
    "benfciaryClause",
    "feeDerogtn",
    "brkrComm"
})
public class ProtectionPolicyCoverDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovIdntfctn")
    protected CoverIdentificationType covIdntfctn;
    @XmlElement(name = "LinkdObjcts")
    protected ProtectionPolicyCoverLinkedObjectsInputType linkdObjcts;
    @XmlElement(name = "CovData")
    protected ProtectionCoverDataInputType covData;
    @XmlElement(name = "ClaimOptions")
    protected CoverClaimTermsDataInputType claimOptions;
    @XmlElement(name = "PremOptions")
    protected ProtectionCoverPremiumOptionsDataType premOptions;
    @XmlElement(name = "CovPaymnt")
    protected List<ProtectionOperationPaymentType> covPaymnt;
    @XmlElement(name = "BenfciaryClause")
    protected CoverBeneficiaryClauseInputType benfciaryClause;
    @XmlElement(name = "FeeDerogtn")
    protected List<FeeDerogationInputType> feeDerogtn;
    @XmlElement(name = "BrkrComm")
    protected BrokerCommissionInputType brkrComm;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyCoverDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyCoverDataInputType(final CoverIdentificationType covIdntfctn, final ProtectionPolicyCoverLinkedObjectsInputType linkdObjcts, final ProtectionCoverDataInputType covData, final CoverClaimTermsDataInputType claimOptions, final ProtectionCoverPremiumOptionsDataType premOptions, final List<ProtectionOperationPaymentType> covPaymnt, final CoverBeneficiaryClauseInputType benfciaryClause, final List<FeeDerogationInputType> feeDerogtn, final BrokerCommissionInputType brkrComm) {
        this.covIdntfctn = covIdntfctn;
        this.linkdObjcts = linkdObjcts;
        this.covData = covData;
        this.claimOptions = claimOptions;
        this.premOptions = premOptions;
        this.covPaymnt = covPaymnt;
        this.benfciaryClause = benfciaryClause;
        this.feeDerogtn = feeDerogtn;
        this.brkrComm = brkrComm;
    }

    /**
     * Gets the value of the covIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link CoverIdentificationType }
     *     
     */
    public CoverIdentificationType getCovIdntfctn() {
        return covIdntfctn;
    }

    /**
     * Sets the value of the covIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverIdentificationType }
     *     
     */
    public void setCovIdntfctn(CoverIdentificationType value) {
        this.covIdntfctn = value;
    }

    public boolean isSetCovIdntfctn() {
        return (this.covIdntfctn!= null);
    }

    /**
     * Gets the value of the linkdObjcts property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionPolicyCoverLinkedObjectsInputType }
     *     
     */
    public ProtectionPolicyCoverLinkedObjectsInputType getLinkdObjcts() {
        return linkdObjcts;
    }

    /**
     * Sets the value of the linkdObjcts property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionPolicyCoverLinkedObjectsInputType }
     *     
     */
    public void setLinkdObjcts(ProtectionPolicyCoverLinkedObjectsInputType value) {
        this.linkdObjcts = value;
    }

    public boolean isSetLinkdObjcts() {
        return (this.linkdObjcts!= null);
    }

    /**
     * Gets the value of the covData property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionCoverDataInputType }
     *     
     */
    public ProtectionCoverDataInputType getCovData() {
        return covData;
    }

    /**
     * Sets the value of the covData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionCoverDataInputType }
     *     
     */
    public void setCovData(ProtectionCoverDataInputType value) {
        this.covData = value;
    }

    public boolean isSetCovData() {
        return (this.covData!= null);
    }

    /**
     * Gets the value of the claimOptions property.
     * 
     * @return
     *     possible object is
     *     {@link CoverClaimTermsDataInputType }
     *     
     */
    public CoverClaimTermsDataInputType getClaimOptions() {
        return claimOptions;
    }

    /**
     * Sets the value of the claimOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverClaimTermsDataInputType }
     *     
     */
    public void setClaimOptions(CoverClaimTermsDataInputType value) {
        this.claimOptions = value;
    }

    public boolean isSetClaimOptions() {
        return (this.claimOptions!= null);
    }

    /**
     * Gets the value of the premOptions property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionCoverPremiumOptionsDataType }
     *     
     */
    public ProtectionCoverPremiumOptionsDataType getPremOptions() {
        return premOptions;
    }

    /**
     * Sets the value of the premOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionCoverPremiumOptionsDataType }
     *     
     */
    public void setPremOptions(ProtectionCoverPremiumOptionsDataType value) {
        this.premOptions = value;
    }

    public boolean isSetPremOptions() {
        return (this.premOptions!= null);
    }

    /**
     * Gets the value of the covPaymnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covPaymnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovPaymnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProtectionOperationPaymentType }
     * 
     * 
     */
    public List<ProtectionOperationPaymentType> getCovPaymnt() {
        if (covPaymnt == null) {
            covPaymnt = new ArrayList<ProtectionOperationPaymentType>();
        }
        return this.covPaymnt;
    }

    public boolean isSetCovPaymnt() {
        return ((this.covPaymnt!= null)&&(!this.covPaymnt.isEmpty()));
    }

    public void unsetCovPaymnt() {
        this.covPaymnt = null;
    }

    /**
     * Gets the value of the benfciaryClause property.
     * 
     * @return
     *     possible object is
     *     {@link CoverBeneficiaryClauseInputType }
     *     
     */
    public CoverBeneficiaryClauseInputType getBenfciaryClause() {
        return benfciaryClause;
    }

    /**
     * Sets the value of the benfciaryClause property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverBeneficiaryClauseInputType }
     *     
     */
    public void setBenfciaryClause(CoverBeneficiaryClauseInputType value) {
        this.benfciaryClause = value;
    }

    public boolean isSetBenfciaryClause() {
        return (this.benfciaryClause!= null);
    }

    /**
     * Gets the value of the feeDerogtn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the feeDerogtn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFeeDerogtn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeeDerogationInputType }
     * 
     * 
     */
    public List<FeeDerogationInputType> getFeeDerogtn() {
        if (feeDerogtn == null) {
            feeDerogtn = new ArrayList<FeeDerogationInputType>();
        }
        return this.feeDerogtn;
    }

    public boolean isSetFeeDerogtn() {
        return ((this.feeDerogtn!= null)&&(!this.feeDerogtn.isEmpty()));
    }

    public void unsetFeeDerogtn() {
        this.feeDerogtn = null;
    }

    /**
     * Gets the value of the brkrComm property.
     * 
     * @return
     *     possible object is
     *     {@link BrokerCommissionInputType }
     *     
     */
    public BrokerCommissionInputType getBrkrComm() {
        return brkrComm;
    }

    /**
     * Sets the value of the brkrComm property.
     * 
     * @param value
     *     allowed object is
     *     {@link BrokerCommissionInputType }
     *     
     */
    public void setBrkrComm(BrokerCommissionInputType value) {
        this.brkrComm = value;
    }

    public boolean isSetBrkrComm() {
        return (this.brkrComm!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covIdntfctn", covIdntfctn).add("linkdObjcts", linkdObjcts).add("covData", covData).add("claimOptions", claimOptions).add("premOptions", premOptions).add("covPaymnt", covPaymnt).add("benfciaryClause", benfciaryClause).add("feeDerogtn", feeDerogtn).add("brkrComm", brkrComm).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covIdntfctn, linkdObjcts, covData, claimOptions, premOptions, covPaymnt, benfciaryClause, feeDerogtn, brkrComm);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyCoverDataInputType o = ((ProtectionPolicyCoverDataInputType) other);
        return ((((((((Objects.equal(covIdntfctn, o.covIdntfctn)&&Objects.equal(linkdObjcts, o.linkdObjcts))&&Objects.equal(covData, o.covData))&&Objects.equal(claimOptions, o.claimOptions))&&Objects.equal(premOptions, o.premOptions))&&Objects.equal(covPaymnt, o.covPaymnt))&&Objects.equal(benfciaryClause, o.benfciaryClause))&&Objects.equal(feeDerogtn, o.feeDerogtn))&&Objects.equal(brkrComm, o.brkrComm));
    }

}
