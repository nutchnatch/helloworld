
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for SubscriptionPackageFeatureDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SubscriptionPackageFeatureDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SubscriptionPackageDataInputType"/&gt;
 *         &lt;element name="InsrdPersn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="LoanlIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="CovData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SubscriptionCoverDataInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubscriptionPackageFeatureDataInputType", propOrder = {
    "data",
    "insrdPersn",
    "loanlIdntfctn",
    "covData"
})
public class SubscriptionPackageFeatureDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Data", required = true)
    protected SubscriptionPackageDataInputType data;
    @XmlElement(name = "InsrdPersn", required = true)
    protected PartyRoleType insrdPersn;
    @XmlElement(name = "LoanlIdntfctn")
    protected ObjectIdentificationType loanlIdntfctn;
    @XmlElement(name = "CovData")
    protected List<SubscriptionCoverDataInputType> covData;

    /**
     * Default no-arg constructor
     * 
     */
    public SubscriptionPackageFeatureDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SubscriptionPackageFeatureDataInputType(final SubscriptionPackageDataInputType data, final PartyRoleType insrdPersn, final ObjectIdentificationType loanlIdntfctn, final List<SubscriptionCoverDataInputType> covData) {
        this.data = data;
        this.insrdPersn = insrdPersn;
        this.loanlIdntfctn = loanlIdntfctn;
        this.covData = covData;
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link SubscriptionPackageDataInputType }
     *     
     */
    public SubscriptionPackageDataInputType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubscriptionPackageDataInputType }
     *     
     */
    public void setData(SubscriptionPackageDataInputType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the insrdPersn property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsrdPersn() {
        return insrdPersn;
    }

    /**
     * Sets the value of the insrdPersn property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsrdPersn(PartyRoleType value) {
        this.insrdPersn = value;
    }

    public boolean isSetInsrdPersn() {
        return (this.insrdPersn!= null);
    }

    /**
     * Gets the value of the loanlIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getLoanlIdntfctn() {
        return loanlIdntfctn;
    }

    /**
     * Sets the value of the loanlIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setLoanlIdntfctn(ObjectIdentificationType value) {
        this.loanlIdntfctn = value;
    }

    public boolean isSetLoanlIdntfctn() {
        return (this.loanlIdntfctn!= null);
    }

    /**
     * Gets the value of the covData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SubscriptionCoverDataInputType }
     * 
     * 
     */
    public List<SubscriptionCoverDataInputType> getCovData() {
        if (covData == null) {
            covData = new ArrayList<SubscriptionCoverDataInputType>();
        }
        return this.covData;
    }

    public boolean isSetCovData() {
        return ((this.covData!= null)&&(!this.covData.isEmpty()));
    }

    public void unsetCovData() {
        this.covData = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("data", data).add("insrdPersn", insrdPersn).add("loanlIdntfctn", loanlIdntfctn).add("covData", covData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(data, insrdPersn, loanlIdntfctn, covData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SubscriptionPackageFeatureDataInputType o = ((SubscriptionPackageFeatureDataInputType) other);
        return (((Objects.equal(data, o.data)&&Objects.equal(insrdPersn, o.insrdPersn))&&Objects.equal(loanlIdntfctn, o.loanlIdntfctn))&&Objects.equal(covData, o.covData));
    }

}
