
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * used to define stage of installment of premium or
 * 				loan (no more used)
 * 			
 * 
 * <p>Java class for RateByStageType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RateByStageType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *         &lt;element name="SeqId" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RateByStageType", propOrder = {
    "rate",
    "duratn",
    "seqId"
})
public class RateByStageType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Rate", required = true)
    protected BasisRateType rate;
    @XmlElement(name = "Duratn", required = true)
    protected DurationType duratn;
    @XmlElement(name = "SeqId")
    protected Object seqId;

    /**
     * Default no-arg constructor
     * 
     */
    public RateByStageType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public RateByStageType(final BasisRateType rate, final DurationType duratn, final Object seqId) {
        this.rate = rate;
        this.duratn = duratn;
        this.seqId = seqId;
    }

    /**
     * Gets the value of the rate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getRate() {
        return rate;
    }

    /**
     * Sets the value of the rate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setRate(BasisRateType value) {
        this.rate = value;
    }

    public boolean isSetRate() {
        return (this.rate!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    /**
     * Gets the value of the seqId property.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getSeqId() {
        return seqId;
    }

    /**
     * Sets the value of the seqId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setSeqId(Object value) {
        this.seqId = value;
    }

    public boolean isSetSeqId() {
        return (this.seqId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("rate", rate).add("duratn", duratn).add("seqId", seqId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(rate, duratn, seqId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final RateByStageType o = ((RateByStageType) other);
        return ((Objects.equal(rate, o.rate)&&Objects.equal(duratn, o.duratn))&&Objects.equal(seqId, o.seqId));
    }

}
