
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * List of profiles selected at policy level
 * 			
 * 
 * <p>Java class for SavingsPolicyProfileInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyProfileInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PdctProfIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="ProfType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProfileTypeCode"/&gt;
 *         &lt;element name="InvstmntProfType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialFundProfileTypeCode" minOccurs="0"/&gt;
 *         &lt;element name="ProfPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyProfileInputType", propOrder = {
    "pdctProfIdntfctn",
    "profType",
    "invstmntProfType",
    "profPrd"
})
public class SavingsPolicyProfileInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PdctProfIdntfctn", required = true)
    protected ObjectIdentificationType pdctProfIdntfctn;
    @XmlElement(name = "ProfType", required = true)
    protected String profType;
    @XmlElement(name = "InvstmntProfType")
    protected String invstmntProfType;
    @XmlElement(name = "ProfPrd")
    protected OptionalDatePeriodType profPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyProfileInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyProfileInputType(final ObjectIdentificationType pdctProfIdntfctn, final String profType, final String invstmntProfType, final OptionalDatePeriodType profPrd) {
        this.pdctProfIdntfctn = pdctProfIdntfctn;
        this.profType = profType;
        this.invstmntProfType = invstmntProfType;
        this.profPrd = profPrd;
    }

    /**
     * Gets the value of the pdctProfIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPdctProfIdntfctn() {
        return pdctProfIdntfctn;
    }

    /**
     * Sets the value of the pdctProfIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPdctProfIdntfctn(ObjectIdentificationType value) {
        this.pdctProfIdntfctn = value;
    }

    public boolean isSetPdctProfIdntfctn() {
        return (this.pdctProfIdntfctn!= null);
    }

    /**
     * Gets the value of the profType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProfType() {
        return profType;
    }

    /**
     * Sets the value of the profType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProfType(String value) {
        this.profType = value;
    }

    public boolean isSetProfType() {
        return (this.profType!= null);
    }

    /**
     * Gets the value of the invstmntProfType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvstmntProfType() {
        return invstmntProfType;
    }

    /**
     * Sets the value of the invstmntProfType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvstmntProfType(String value) {
        this.invstmntProfType = value;
    }

    public boolean isSetInvstmntProfType() {
        return (this.invstmntProfType!= null);
    }

    /**
     * Gets the value of the profPrd property.
     * 
     * @return
     *     possible object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public OptionalDatePeriodType getProfPrd() {
        return profPrd;
    }

    /**
     * Sets the value of the profPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public void setProfPrd(OptionalDatePeriodType value) {
        this.profPrd = value;
    }

    public boolean isSetProfPrd() {
        return (this.profPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdctProfIdntfctn", pdctProfIdntfctn).add("profType", profType).add("invstmntProfType", invstmntProfType).add("profPrd", profPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdctProfIdntfctn, profType, invstmntProfType, profPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyProfileInputType o = ((SavingsPolicyProfileInputType) other);
        return (((Objects.equal(pdctProfIdntfctn, o.pdctProfIdntfctn)&&Objects.equal(profType, o.profType))&&Objects.equal(invstmntProfType, o.invstmntProfType))&&Objects.equal(profPrd, o.profPrd));
    }

}
