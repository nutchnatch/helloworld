
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Terms for fees calculation at product level
 * 			
 * 
 * <p>Java class for ProductOperationFeeTermsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductOperationFeeTermsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EventTypeCode"/&gt;
 *         &lt;element name="FeeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeesCodeSLN"/&gt;
 *         &lt;element name="RuleType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountCalculationRuleTypeCodeSLN"/&gt;
 *         &lt;element name="FixdFeeAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="BasisAmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FeeMinAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="FixdRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AmntRnge" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *                   &lt;element name="MinAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *                   &lt;element name="MaxAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="TimeRnge" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *                   &lt;element name="PolMinDurtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *                   &lt;element name="PolMaxDurtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductOperationFeeTermsDataType", propOrder = {
    "type",
    "feeType",
    "ruleType",
    "fixdFeeAmnt",
    "basisAmntType",
    "feeMinAmnt",
    "fixdRate",
    "fqcy",
    "amntRnge",
    "timeRnge",
    "applctnPrd"
})
public class ProductOperationFeeTermsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "FeeType", required = true)
    protected String feeType;
    @XmlElement(name = "RuleType", required = true)
    protected String ruleType;
    @XmlElement(name = "FixdFeeAmnt")
    protected CurrencyAndAmountType fixdFeeAmnt;
    @XmlElement(name = "BasisAmntType")
    protected String basisAmntType;
    @XmlElement(name = "FeeMinAmnt")
    protected CurrencyAndAmountType feeMinAmnt;
    @XmlElement(name = "FixdRate")
    protected BasisRateType fixdRate;
    @XmlElement(name = "Fqcy")
    protected String fqcy;
    @XmlElement(name = "AmntRnge")
    protected List<ProductOperationFeeTermsDataType.AmntRnge> amntRnge;
    @XmlElement(name = "TimeRnge")
    protected List<ProductOperationFeeTermsDataType.TimeRnge> timeRnge;
    @XmlElement(name = "ApplctnPrd")
    protected DatePeriodType applctnPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ProductOperationFeeTermsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProductOperationFeeTermsDataType(final String type, final String feeType, final String ruleType, final CurrencyAndAmountType fixdFeeAmnt, final String basisAmntType, final CurrencyAndAmountType feeMinAmnt, final BasisRateType fixdRate, final String fqcy, final List<ProductOperationFeeTermsDataType.AmntRnge> amntRnge, final List<ProductOperationFeeTermsDataType.TimeRnge> timeRnge, final DatePeriodType applctnPrd) {
        this.type = type;
        this.feeType = feeType;
        this.ruleType = ruleType;
        this.fixdFeeAmnt = fixdFeeAmnt;
        this.basisAmntType = basisAmntType;
        this.feeMinAmnt = feeMinAmnt;
        this.fixdRate = fixdRate;
        this.fqcy = fqcy;
        this.amntRnge = amntRnge;
        this.timeRnge = timeRnge;
        this.applctnPrd = applctnPrd;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the feeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeeType() {
        return feeType;
    }

    /**
     * Sets the value of the feeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeeType(String value) {
        this.feeType = value;
    }

    public boolean isSetFeeType() {
        return (this.feeType!= null);
    }

    /**
     * Gets the value of the ruleType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRuleType() {
        return ruleType;
    }

    /**
     * Sets the value of the ruleType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRuleType(String value) {
        this.ruleType = value;
    }

    public boolean isSetRuleType() {
        return (this.ruleType!= null);
    }

    /**
     * Gets the value of the fixdFeeAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFixdFeeAmnt() {
        return fixdFeeAmnt;
    }

    /**
     * Sets the value of the fixdFeeAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFixdFeeAmnt(CurrencyAndAmountType value) {
        this.fixdFeeAmnt = value;
    }

    public boolean isSetFixdFeeAmnt() {
        return (this.fixdFeeAmnt!= null);
    }

    /**
     * Gets the value of the basisAmntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasisAmntType() {
        return basisAmntType;
    }

    /**
     * Sets the value of the basisAmntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasisAmntType(String value) {
        this.basisAmntType = value;
    }

    public boolean isSetBasisAmntType() {
        return (this.basisAmntType!= null);
    }

    /**
     * Gets the value of the feeMinAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFeeMinAmnt() {
        return feeMinAmnt;
    }

    /**
     * Sets the value of the feeMinAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFeeMinAmnt(CurrencyAndAmountType value) {
        this.feeMinAmnt = value;
    }

    public boolean isSetFeeMinAmnt() {
        return (this.feeMinAmnt!= null);
    }

    /**
     * Gets the value of the fixdRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getFixdRate() {
        return fixdRate;
    }

    /**
     * Sets the value of the fixdRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setFixdRate(BasisRateType value) {
        this.fixdRate = value;
    }

    public boolean isSetFixdRate() {
        return (this.fixdRate!= null);
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the amntRnge property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the amntRnge property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAmntRnge().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductOperationFeeTermsDataType.AmntRnge }
     * 
     * 
     */
    public List<ProductOperationFeeTermsDataType.AmntRnge> getAmntRnge() {
        if (amntRnge == null) {
            amntRnge = new ArrayList<ProductOperationFeeTermsDataType.AmntRnge>();
        }
        return this.amntRnge;
    }

    public boolean isSetAmntRnge() {
        return ((this.amntRnge!= null)&&(!this.amntRnge.isEmpty()));
    }

    public void unsetAmntRnge() {
        this.amntRnge = null;
    }

    /**
     * Gets the value of the timeRnge property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the timeRnge property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTimeRnge().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductOperationFeeTermsDataType.TimeRnge }
     * 
     * 
     */
    public List<ProductOperationFeeTermsDataType.TimeRnge> getTimeRnge() {
        if (timeRnge == null) {
            timeRnge = new ArrayList<ProductOperationFeeTermsDataType.TimeRnge>();
        }
        return this.timeRnge;
    }

    public boolean isSetTimeRnge() {
        return ((this.timeRnge!= null)&&(!this.timeRnge.isEmpty()));
    }

    public void unsetTimeRnge() {
        this.timeRnge = null;
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("feeType", feeType).add("ruleType", ruleType).add("fixdFeeAmnt", fixdFeeAmnt).add("basisAmntType", basisAmntType).add("feeMinAmnt", feeMinAmnt).add("fixdRate", fixdRate).add("fqcy", fqcy).add("amntRnge", amntRnge).add("timeRnge", timeRnge).add("applctnPrd", applctnPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, feeType, ruleType, fixdFeeAmnt, basisAmntType, feeMinAmnt, fixdRate, fqcy, amntRnge, timeRnge, applctnPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProductOperationFeeTermsDataType o = ((ProductOperationFeeTermsDataType) other);
        return ((((((((((Objects.equal(type, o.type)&&Objects.equal(feeType, o.feeType))&&Objects.equal(ruleType, o.ruleType))&&Objects.equal(fixdFeeAmnt, o.fixdFeeAmnt))&&Objects.equal(basisAmntType, o.basisAmntType))&&Objects.equal(feeMinAmnt, o.feeMinAmnt))&&Objects.equal(fixdRate, o.fixdRate))&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(amntRnge, o.amntRnge))&&Objects.equal(timeRnge, o.timeRnge))&&Objects.equal(applctnPrd, o.applctnPrd));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
     *         &lt;element name="MinAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
     *         &lt;element name="MaxAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "rate",
        "minAmnt",
        "maxAmnt"
    })
    public static class AmntRnge implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Rate", required = true)
        protected BasisRateType rate;
        @XmlElement(name = "MinAmnt", required = true)
        protected CurrencyAndAmountType minAmnt;
        @XmlElement(name = "MaxAmnt")
        protected CurrencyAndAmountType maxAmnt;

        /**
         * Default no-arg constructor
         * 
         */
        public AmntRnge() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public AmntRnge(final BasisRateType rate, final CurrencyAndAmountType minAmnt, final CurrencyAndAmountType maxAmnt) {
            this.rate = rate;
            this.minAmnt = minAmnt;
            this.maxAmnt = maxAmnt;
        }

        /**
         * Gets the value of the rate property.
         * 
         * @return
         *     possible object is
         *     {@link BasisRateType }
         *     
         */
        public BasisRateType getRate() {
            return rate;
        }

        /**
         * Sets the value of the rate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BasisRateType }
         *     
         */
        public void setRate(BasisRateType value) {
            this.rate = value;
        }

        public boolean isSetRate() {
            return (this.rate!= null);
        }

        /**
         * Gets the value of the minAmnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getMinAmnt() {
            return minAmnt;
        }

        /**
         * Sets the value of the minAmnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setMinAmnt(CurrencyAndAmountType value) {
            this.minAmnt = value;
        }

        public boolean isSetMinAmnt() {
            return (this.minAmnt!= null);
        }

        /**
         * Gets the value of the maxAmnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getMaxAmnt() {
            return maxAmnt;
        }

        /**
         * Sets the value of the maxAmnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setMaxAmnt(CurrencyAndAmountType value) {
            this.maxAmnt = value;
        }

        public boolean isSetMaxAmnt() {
            return (this.maxAmnt!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("rate", rate).add("minAmnt", minAmnt).add("maxAmnt", maxAmnt).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(rate, minAmnt, maxAmnt);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ProductOperationFeeTermsDataType.AmntRnge o = ((ProductOperationFeeTermsDataType.AmntRnge) other);
            return ((Objects.equal(rate, o.rate)&&Objects.equal(minAmnt, o.minAmnt))&&Objects.equal(maxAmnt, o.maxAmnt));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
     *         &lt;element name="PolMinDurtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
     *         &lt;element name="PolMaxDurtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "rate",
        "polMinDurtn",
        "polMaxDurtn"
    })
    public static class TimeRnge implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Rate", required = true)
        protected BasisRateType rate;
        @XmlElement(name = "PolMinDurtn", required = true)
        protected DurationType polMinDurtn;
        @XmlElement(name = "PolMaxDurtn", required = true)
        protected DurationType polMaxDurtn;

        /**
         * Default no-arg constructor
         * 
         */
        public TimeRnge() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public TimeRnge(final BasisRateType rate, final DurationType polMinDurtn, final DurationType polMaxDurtn) {
            this.rate = rate;
            this.polMinDurtn = polMinDurtn;
            this.polMaxDurtn = polMaxDurtn;
        }

        /**
         * Gets the value of the rate property.
         * 
         * @return
         *     possible object is
         *     {@link BasisRateType }
         *     
         */
        public BasisRateType getRate() {
            return rate;
        }

        /**
         * Sets the value of the rate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BasisRateType }
         *     
         */
        public void setRate(BasisRateType value) {
            this.rate = value;
        }

        public boolean isSetRate() {
            return (this.rate!= null);
        }

        /**
         * Gets the value of the polMinDurtn property.
         * 
         * @return
         *     possible object is
         *     {@link DurationType }
         *     
         */
        public DurationType getPolMinDurtn() {
            return polMinDurtn;
        }

        /**
         * Sets the value of the polMinDurtn property.
         * 
         * @param value
         *     allowed object is
         *     {@link DurationType }
         *     
         */
        public void setPolMinDurtn(DurationType value) {
            this.polMinDurtn = value;
        }

        public boolean isSetPolMinDurtn() {
            return (this.polMinDurtn!= null);
        }

        /**
         * Gets the value of the polMaxDurtn property.
         * 
         * @return
         *     possible object is
         *     {@link DurationType }
         *     
         */
        public DurationType getPolMaxDurtn() {
            return polMaxDurtn;
        }

        /**
         * Sets the value of the polMaxDurtn property.
         * 
         * @param value
         *     allowed object is
         *     {@link DurationType }
         *     
         */
        public void setPolMaxDurtn(DurationType value) {
            this.polMaxDurtn = value;
        }

        public boolean isSetPolMaxDurtn() {
            return (this.polMaxDurtn!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("rate", rate).add("polMinDurtn", polMinDurtn).add("polMaxDurtn", polMaxDurtn).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(rate, polMinDurtn, polMaxDurtn);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ProductOperationFeeTermsDataType.TimeRnge o = ((ProductOperationFeeTermsDataType.TimeRnge) other);
            return ((Objects.equal(rate, o.rate)&&Objects.equal(polMinDurtn, o.polMinDurtn))&&Objects.equal(polMaxDurtn, o.polMaxDurtn));
        }

    }

}
