
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data carried by the cover for
 * 				protection policy
 * 			
 * 
 * <p>Java class for ProtectionCoverDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionCoverDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PremFqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="InsrdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="CovLvlRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CovPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="PremAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="PremAmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="PremApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="PremDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="InitiatngInsrdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="FaclttveReinsrnc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="PremPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="FrstPremAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="MdclClauseInd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionCoverDataType", propOrder = {
    "premFqcy",
    "insrdAmnt",
    "covLvlRate",
    "benfciaryType",
    "covPrd",
    "duratn",
    "premAmnt",
    "premAmntType",
    "premApplctnPrd",
    "premDuratn",
    "initiatngInsrdAmnt",
    "faclttveReinsrnc",
    "premPrd",
    "frstPremAmnt",
    "mdclClauseInd"
})
public class ProtectionCoverDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PremFqcy")
    protected String premFqcy;
    @XmlElement(name = "InsrdAmnt")
    protected CurrencyAndAmountType insrdAmnt;
    @XmlElement(name = "CovLvlRate")
    protected Double covLvlRate;
    @XmlElement(name = "BenfciaryType")
    protected String benfciaryType;
    @XmlElement(name = "CovPrd")
    protected DatePeriodType covPrd;
    @XmlElement(name = "Duratn")
    protected DurationType duratn;
    @XmlElement(name = "PremAmnt")
    protected CurrencyAndAmountType premAmnt;
    @XmlElement(name = "PremAmntType")
    protected String premAmntType;
    @XmlElement(name = "PremApplctnPrd")
    protected DatePeriodType premApplctnPrd;
    @XmlElement(name = "PremDuratn")
    protected DurationType premDuratn;
    @XmlElement(name = "InitiatngInsrdAmnt")
    protected CurrencyAndAmountType initiatngInsrdAmnt;
    @XmlElement(name = "FaclttveReinsrnc")
    protected String faclttveReinsrnc;
    @XmlElement(name = "PremPrd")
    protected DatePeriodType premPrd;
    @XmlElement(name = "FrstPremAmnt")
    protected CurrencyAndAmountType frstPremAmnt;
    @XmlElement(name = "MdclClauseInd")
    protected String mdclClauseInd;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionCoverDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionCoverDataType(final String premFqcy, final CurrencyAndAmountType insrdAmnt, final Double covLvlRate, final String benfciaryType, final DatePeriodType covPrd, final DurationType duratn, final CurrencyAndAmountType premAmnt, final String premAmntType, final DatePeriodType premApplctnPrd, final DurationType premDuratn, final CurrencyAndAmountType initiatngInsrdAmnt, final String faclttveReinsrnc, final DatePeriodType premPrd, final CurrencyAndAmountType frstPremAmnt, final String mdclClauseInd) {
        this.premFqcy = premFqcy;
        this.insrdAmnt = insrdAmnt;
        this.covLvlRate = covLvlRate;
        this.benfciaryType = benfciaryType;
        this.covPrd = covPrd;
        this.duratn = duratn;
        this.premAmnt = premAmnt;
        this.premAmntType = premAmntType;
        this.premApplctnPrd = premApplctnPrd;
        this.premDuratn = premDuratn;
        this.initiatngInsrdAmnt = initiatngInsrdAmnt;
        this.faclttveReinsrnc = faclttveReinsrnc;
        this.premPrd = premPrd;
        this.frstPremAmnt = frstPremAmnt;
        this.mdclClauseInd = mdclClauseInd;
    }

    /**
     * Gets the value of the premFqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremFqcy() {
        return premFqcy;
    }

    /**
     * Sets the value of the premFqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremFqcy(String value) {
        this.premFqcy = value;
    }

    public boolean isSetPremFqcy() {
        return (this.premFqcy!= null);
    }

    /**
     * Gets the value of the insrdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInsrdAmnt() {
        return insrdAmnt;
    }

    /**
     * Sets the value of the insrdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInsrdAmnt(CurrencyAndAmountType value) {
        this.insrdAmnt = value;
    }

    public boolean isSetInsrdAmnt() {
        return (this.insrdAmnt!= null);
    }

    /**
     * Gets the value of the covLvlRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCovLvlRate() {
        return covLvlRate;
    }

    /**
     * Sets the value of the covLvlRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCovLvlRate(Double value) {
        this.covLvlRate = value;
    }

    public boolean isSetCovLvlRate() {
        return (this.covLvlRate!= null);
    }

    /**
     * Gets the value of the benfciaryType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBenfciaryType() {
        return benfciaryType;
    }

    /**
     * Sets the value of the benfciaryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBenfciaryType(String value) {
        this.benfciaryType = value;
    }

    public boolean isSetBenfciaryType() {
        return (this.benfciaryType!= null);
    }

    /**
     * Gets the value of the covPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getCovPrd() {
        return covPrd;
    }

    /**
     * Sets the value of the covPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setCovPrd(DatePeriodType value) {
        this.covPrd = value;
    }

    public boolean isSetCovPrd() {
        return (this.covPrd!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    /**
     * Gets the value of the premAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPremAmnt() {
        return premAmnt;
    }

    /**
     * Sets the value of the premAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPremAmnt(CurrencyAndAmountType value) {
        this.premAmnt = value;
    }

    public boolean isSetPremAmnt() {
        return (this.premAmnt!= null);
    }

    /**
     * Gets the value of the premAmntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremAmntType() {
        return premAmntType;
    }

    /**
     * Sets the value of the premAmntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremAmntType(String value) {
        this.premAmntType = value;
    }

    public boolean isSetPremAmntType() {
        return (this.premAmntType!= null);
    }

    /**
     * Gets the value of the premApplctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getPremApplctnPrd() {
        return premApplctnPrd;
    }

    /**
     * Sets the value of the premApplctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setPremApplctnPrd(DatePeriodType value) {
        this.premApplctnPrd = value;
    }

    public boolean isSetPremApplctnPrd() {
        return (this.premApplctnPrd!= null);
    }

    /**
     * Gets the value of the premDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getPremDuratn() {
        return premDuratn;
    }

    /**
     * Sets the value of the premDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setPremDuratn(DurationType value) {
        this.premDuratn = value;
    }

    public boolean isSetPremDuratn() {
        return (this.premDuratn!= null);
    }

    /**
     * Gets the value of the initiatngInsrdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInitiatngInsrdAmnt() {
        return initiatngInsrdAmnt;
    }

    /**
     * Sets the value of the initiatngInsrdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInitiatngInsrdAmnt(CurrencyAndAmountType value) {
        this.initiatngInsrdAmnt = value;
    }

    public boolean isSetInitiatngInsrdAmnt() {
        return (this.initiatngInsrdAmnt!= null);
    }

    /**
     * Gets the value of the faclttveReinsrnc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaclttveReinsrnc() {
        return faclttveReinsrnc;
    }

    /**
     * Sets the value of the faclttveReinsrnc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaclttveReinsrnc(String value) {
        this.faclttveReinsrnc = value;
    }

    public boolean isSetFaclttveReinsrnc() {
        return (this.faclttveReinsrnc!= null);
    }

    /**
     * Gets the value of the premPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getPremPrd() {
        return premPrd;
    }

    /**
     * Sets the value of the premPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setPremPrd(DatePeriodType value) {
        this.premPrd = value;
    }

    public boolean isSetPremPrd() {
        return (this.premPrd!= null);
    }

    /**
     * Gets the value of the frstPremAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFrstPremAmnt() {
        return frstPremAmnt;
    }

    /**
     * Sets the value of the frstPremAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFrstPremAmnt(CurrencyAndAmountType value) {
        this.frstPremAmnt = value;
    }

    public boolean isSetFrstPremAmnt() {
        return (this.frstPremAmnt!= null);
    }

    /**
     * Gets the value of the mdclClauseInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMdclClauseInd() {
        return mdclClauseInd;
    }

    /**
     * Sets the value of the mdclClauseInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMdclClauseInd(String value) {
        this.mdclClauseInd = value;
    }

    public boolean isSetMdclClauseInd() {
        return (this.mdclClauseInd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("premFqcy", premFqcy).add("insrdAmnt", insrdAmnt).add("covLvlRate", covLvlRate).add("benfciaryType", benfciaryType).add("covPrd", covPrd).add("duratn", duratn).add("premAmnt", premAmnt).add("premAmntType", premAmntType).add("premApplctnPrd", premApplctnPrd).add("premDuratn", premDuratn).add("initiatngInsrdAmnt", initiatngInsrdAmnt).add("faclttveReinsrnc", faclttveReinsrnc).add("premPrd", premPrd).add("frstPremAmnt", frstPremAmnt).add("mdclClauseInd", mdclClauseInd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(premFqcy, insrdAmnt, covLvlRate, benfciaryType, covPrd, duratn, premAmnt, premAmntType, premApplctnPrd, premDuratn, initiatngInsrdAmnt, faclttveReinsrnc, premPrd, frstPremAmnt, mdclClauseInd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionCoverDataType o = ((ProtectionCoverDataType) other);
        return ((((((((((((((Objects.equal(premFqcy, o.premFqcy)&&Objects.equal(insrdAmnt, o.insrdAmnt))&&Objects.equal(covLvlRate, o.covLvlRate))&&Objects.equal(benfciaryType, o.benfciaryType))&&Objects.equal(covPrd, o.covPrd))&&Objects.equal(duratn, o.duratn))&&Objects.equal(premAmnt, o.premAmnt))&&Objects.equal(premAmntType, o.premAmntType))&&Objects.equal(premApplctnPrd, o.premApplctnPrd))&&Objects.equal(premDuratn, o.premDuratn))&&Objects.equal(initiatngInsrdAmnt, o.initiatngInsrdAmnt))&&Objects.equal(faclttveReinsrnc, o.faclttveReinsrnc))&&Objects.equal(premPrd, o.premPrd))&&Objects.equal(frstPremAmnt, o.frstPremAmnt))&&Objects.equal(mdclClauseInd, o.mdclClauseInd));
    }

}
