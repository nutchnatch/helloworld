
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data which
 * 				can be referenced in different exchange data models
 * 			
 * 
 * <p>Java class for ProductAndLegalSchemeDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductAndLegalSchemeDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PdctIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType"/&gt;
 *         &lt;element name="LegalSchme" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalSchemeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="PdctName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductAndLegalSchemeDataType", propOrder = {
    "pdctIdntfctn",
    "legalSchme",
    "pdctName"
})
public class ProductAndLegalSchemeDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PdctIdntfctn", required = true)
    protected ObjectIdentificationWithVersionType pdctIdntfctn;
    @XmlElement(name = "LegalSchme")
    protected String legalSchme;
    @XmlElement(name = "PdctName")
    protected String pdctName;

    /**
     * Default no-arg constructor
     * 
     */
    public ProductAndLegalSchemeDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProductAndLegalSchemeDataType(final ObjectIdentificationWithVersionType pdctIdntfctn, final String legalSchme, final String pdctName) {
        this.pdctIdntfctn = pdctIdntfctn;
        this.legalSchme = legalSchme;
        this.pdctName = pdctName;
    }

    /**
     * Gets the value of the pdctIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getPdctIdntfctn() {
        return pdctIdntfctn;
    }

    /**
     * Sets the value of the pdctIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setPdctIdntfctn(ObjectIdentificationWithVersionType value) {
        this.pdctIdntfctn = value;
    }

    public boolean isSetPdctIdntfctn() {
        return (this.pdctIdntfctn!= null);
    }

    /**
     * Gets the value of the legalSchme property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalSchme() {
        return legalSchme;
    }

    /**
     * Sets the value of the legalSchme property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalSchme(String value) {
        this.legalSchme = value;
    }

    public boolean isSetLegalSchme() {
        return (this.legalSchme!= null);
    }

    /**
     * Gets the value of the pdctName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctName() {
        return pdctName;
    }

    /**
     * Sets the value of the pdctName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctName(String value) {
        this.pdctName = value;
    }

    public boolean isSetPdctName() {
        return (this.pdctName!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdctIdntfctn", pdctIdntfctn).add("legalSchme", legalSchme).add("pdctName", pdctName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdctIdntfctn, legalSchme, pdctName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProductAndLegalSchemeDataType o = ((ProductAndLegalSchemeDataType) other);
        return ((Objects.equal(pdctIdntfctn, o.pdctIdntfctn)&&Objects.equal(legalSchme, o.legalSchme))&&Objects.equal(pdctName, o.pdctName));
    }

}
