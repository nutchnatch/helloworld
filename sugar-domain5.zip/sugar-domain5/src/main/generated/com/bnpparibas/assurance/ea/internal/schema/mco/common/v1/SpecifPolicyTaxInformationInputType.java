
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Tax information at policy level specific to france
 * 			
 * 
 * <p>Java class for SpecifPolicyTaxInformationInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SpecifPolicyTaxInformationInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TaxationMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxationOptionTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FiscalRegim" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FiscalRegimCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecifPolicyTaxInformationInputType", propOrder = {
    "taxationMode",
    "fiscalRegim"
})
public class SpecifPolicyTaxInformationInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "TaxationMode")
    protected String taxationMode;
    @XmlElement(name = "FiscalRegim")
    protected String fiscalRegim;

    /**
     * Default no-arg constructor
     * 
     */
    public SpecifPolicyTaxInformationInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SpecifPolicyTaxInformationInputType(final String taxationMode, final String fiscalRegim) {
        this.taxationMode = taxationMode;
        this.fiscalRegim = fiscalRegim;
    }

    /**
     * Gets the value of the taxationMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxationMode() {
        return taxationMode;
    }

    /**
     * Sets the value of the taxationMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxationMode(String value) {
        this.taxationMode = value;
    }

    public boolean isSetTaxationMode() {
        return (this.taxationMode!= null);
    }

    /**
     * Gets the value of the fiscalRegim property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFiscalRegim() {
        return fiscalRegim;
    }

    /**
     * Sets the value of the fiscalRegim property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFiscalRegim(String value) {
        this.fiscalRegim = value;
    }

    public boolean isSetFiscalRegim() {
        return (this.fiscalRegim!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("taxationMode", taxationMode).add("fiscalRegim", fiscalRegim).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(taxationMode, fiscalRegim);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SpecifPolicyTaxInformationInputType o = ((SpecifPolicyTaxInformationInputType) other);
        return (Objects.equal(taxationMode, o.taxationMode)&&Objects.equal(fiscalRegim, o.fiscalRegim));
    }

}
