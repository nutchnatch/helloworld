
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage general data of policy
 * 			
 * 
 * <p>Java class for ProtectionPolicyGenDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyGenDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SignDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ReciptDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="PolCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="InsrdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="ClosngClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoSubscriptionClosingClauseCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="HandcpIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="RenunctnPrdWaitngIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="PolPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType"/&gt;
 *         &lt;element name="TermDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="SubscrptnChnnl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommunicationChannelCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="SigndSubscrptnDocIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="RenwlDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodicDateType" minOccurs="0"/&gt;
 *         &lt;element name="KeyPersnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="ActiveSrrnderFeeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="TempryIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="JointPolholdrIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyGenDataType", propOrder = {
    "signDate",
    "reciptDate",
    "polCurr",
    "insrdAmnt",
    "duratn",
    "closngClause",
    "handcpIndic",
    "renunctnPrdWaitngIndic",
    "polPrd",
    "termDate",
    "subscrptnChnnl",
    "signdSubscrptnDocIndic",
    "renwlDate",
    "keyPersnIndic",
    "activeSrrnderFeeIndic",
    "tempryIndic",
    "jointPolholdrIndic"
})
public class ProtectionPolicyGenDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SignDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date signDate;
    @XmlElement(name = "ReciptDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date reciptDate;
    @XmlElement(name = "PolCurr")
    protected String polCurr;
    @XmlElement(name = "InsrdAmnt")
    protected CurrencyAndAmountType insrdAmnt;
    @XmlElement(name = "Duratn")
    protected DurationType duratn;
    @XmlElement(name = "ClosngClause")
    protected String closngClause;
    @XmlElement(name = "HandcpIndic")
    protected String handcpIndic;
    @XmlElement(name = "RenunctnPrdWaitngIndic")
    protected String renunctnPrdWaitngIndic;
    @XmlElement(name = "PolPrd", required = true)
    protected DatePeriodType polPrd;
    @XmlElement(name = "TermDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date termDate;
    @XmlElement(name = "SubscrptnChnnl")
    protected String subscrptnChnnl;
    @XmlElement(name = "SigndSubscrptnDocIndic")
    protected String signdSubscrptnDocIndic;
    @XmlElement(name = "RenwlDate")
    protected String renwlDate;
    @XmlElement(name = "KeyPersnIndic")
    protected String keyPersnIndic;
    @XmlElement(name = "ActiveSrrnderFeeIndic")
    protected String activeSrrnderFeeIndic;
    @XmlElement(name = "TempryIndic")
    protected String tempryIndic;
    @XmlElement(name = "JointPolholdrIndic")
    protected String jointPolholdrIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyGenDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyGenDataType(final Date signDate, final Date reciptDate, final String polCurr, final CurrencyAndAmountType insrdAmnt, final DurationType duratn, final String closngClause, final String handcpIndic, final String renunctnPrdWaitngIndic, final DatePeriodType polPrd, final Date termDate, final String subscrptnChnnl, final String signdSubscrptnDocIndic, final String renwlDate, final String keyPersnIndic, final String activeSrrnderFeeIndic, final String tempryIndic, final String jointPolholdrIndic) {
        this.signDate = signDate;
        this.reciptDate = reciptDate;
        this.polCurr = polCurr;
        this.insrdAmnt = insrdAmnt;
        this.duratn = duratn;
        this.closngClause = closngClause;
        this.handcpIndic = handcpIndic;
        this.renunctnPrdWaitngIndic = renunctnPrdWaitngIndic;
        this.polPrd = polPrd;
        this.termDate = termDate;
        this.subscrptnChnnl = subscrptnChnnl;
        this.signdSubscrptnDocIndic = signdSubscrptnDocIndic;
        this.renwlDate = renwlDate;
        this.keyPersnIndic = keyPersnIndic;
        this.activeSrrnderFeeIndic = activeSrrnderFeeIndic;
        this.tempryIndic = tempryIndic;
        this.jointPolholdrIndic = jointPolholdrIndic;
    }

    /**
     * Gets the value of the signDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSignDate() {
        return signDate;
    }

    /**
     * Sets the value of the signDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignDate(Date value) {
        this.signDate = value;
    }

    public boolean isSetSignDate() {
        return (this.signDate!= null);
    }

    /**
     * Gets the value of the reciptDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getReciptDate() {
        return reciptDate;
    }

    /**
     * Sets the value of the reciptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReciptDate(Date value) {
        this.reciptDate = value;
    }

    public boolean isSetReciptDate() {
        return (this.reciptDate!= null);
    }

    /**
     * Gets the value of the polCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolCurr() {
        return polCurr;
    }

    /**
     * Sets the value of the polCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolCurr(String value) {
        this.polCurr = value;
    }

    public boolean isSetPolCurr() {
        return (this.polCurr!= null);
    }

    /**
     * Gets the value of the insrdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInsrdAmnt() {
        return insrdAmnt;
    }

    /**
     * Sets the value of the insrdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInsrdAmnt(CurrencyAndAmountType value) {
        this.insrdAmnt = value;
    }

    public boolean isSetInsrdAmnt() {
        return (this.insrdAmnt!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    /**
     * Gets the value of the closngClause property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosngClause() {
        return closngClause;
    }

    /**
     * Sets the value of the closngClause property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosngClause(String value) {
        this.closngClause = value;
    }

    public boolean isSetClosngClause() {
        return (this.closngClause!= null);
    }

    /**
     * Gets the value of the handcpIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHandcpIndic() {
        return handcpIndic;
    }

    /**
     * Sets the value of the handcpIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHandcpIndic(String value) {
        this.handcpIndic = value;
    }

    public boolean isSetHandcpIndic() {
        return (this.handcpIndic!= null);
    }

    /**
     * Gets the value of the renunctnPrdWaitngIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenunctnPrdWaitngIndic() {
        return renunctnPrdWaitngIndic;
    }

    /**
     * Sets the value of the renunctnPrdWaitngIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenunctnPrdWaitngIndic(String value) {
        this.renunctnPrdWaitngIndic = value;
    }

    public boolean isSetRenunctnPrdWaitngIndic() {
        return (this.renunctnPrdWaitngIndic!= null);
    }

    /**
     * Gets the value of the polPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getPolPrd() {
        return polPrd;
    }

    /**
     * Sets the value of the polPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setPolPrd(DatePeriodType value) {
        this.polPrd = value;
    }

    public boolean isSetPolPrd() {
        return (this.polPrd!= null);
    }

    /**
     * Gets the value of the termDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getTermDate() {
        return termDate;
    }

    /**
     * Sets the value of the termDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTermDate(Date value) {
        this.termDate = value;
    }

    public boolean isSetTermDate() {
        return (this.termDate!= null);
    }

    /**
     * Gets the value of the subscrptnChnnl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscrptnChnnl() {
        return subscrptnChnnl;
    }

    /**
     * Sets the value of the subscrptnChnnl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscrptnChnnl(String value) {
        this.subscrptnChnnl = value;
    }

    public boolean isSetSubscrptnChnnl() {
        return (this.subscrptnChnnl!= null);
    }

    /**
     * Gets the value of the signdSubscrptnDocIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSigndSubscrptnDocIndic() {
        return signdSubscrptnDocIndic;
    }

    /**
     * Sets the value of the signdSubscrptnDocIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSigndSubscrptnDocIndic(String value) {
        this.signdSubscrptnDocIndic = value;
    }

    public boolean isSetSigndSubscrptnDocIndic() {
        return (this.signdSubscrptnDocIndic!= null);
    }

    /**
     * Gets the value of the renwlDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenwlDate() {
        return renwlDate;
    }

    /**
     * Sets the value of the renwlDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenwlDate(String value) {
        this.renwlDate = value;
    }

    public boolean isSetRenwlDate() {
        return (this.renwlDate!= null);
    }

    /**
     * Gets the value of the keyPersnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeyPersnIndic() {
        return keyPersnIndic;
    }

    /**
     * Sets the value of the keyPersnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeyPersnIndic(String value) {
        this.keyPersnIndic = value;
    }

    public boolean isSetKeyPersnIndic() {
        return (this.keyPersnIndic!= null);
    }

    /**
     * Gets the value of the activeSrrnderFeeIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActiveSrrnderFeeIndic() {
        return activeSrrnderFeeIndic;
    }

    /**
     * Sets the value of the activeSrrnderFeeIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActiveSrrnderFeeIndic(String value) {
        this.activeSrrnderFeeIndic = value;
    }

    public boolean isSetActiveSrrnderFeeIndic() {
        return (this.activeSrrnderFeeIndic!= null);
    }

    /**
     * Gets the value of the tempryIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTempryIndic() {
        return tempryIndic;
    }

    /**
     * Sets the value of the tempryIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTempryIndic(String value) {
        this.tempryIndic = value;
    }

    public boolean isSetTempryIndic() {
        return (this.tempryIndic!= null);
    }

    /**
     * Gets the value of the jointPolholdrIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJointPolholdrIndic() {
        return jointPolholdrIndic;
    }

    /**
     * Sets the value of the jointPolholdrIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJointPolholdrIndic(String value) {
        this.jointPolholdrIndic = value;
    }

    public boolean isSetJointPolholdrIndic() {
        return (this.jointPolholdrIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("signDate", signDate).add("reciptDate", reciptDate).add("polCurr", polCurr).add("insrdAmnt", insrdAmnt).add("duratn", duratn).add("closngClause", closngClause).add("handcpIndic", handcpIndic).add("renunctnPrdWaitngIndic", renunctnPrdWaitngIndic).add("polPrd", polPrd).add("termDate", termDate).add("subscrptnChnnl", subscrptnChnnl).add("signdSubscrptnDocIndic", signdSubscrptnDocIndic).add("renwlDate", renwlDate).add("keyPersnIndic", keyPersnIndic).add("activeSrrnderFeeIndic", activeSrrnderFeeIndic).add("tempryIndic", tempryIndic).add("jointPolholdrIndic", jointPolholdrIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(signDate, reciptDate, polCurr, insrdAmnt, duratn, closngClause, handcpIndic, renunctnPrdWaitngIndic, polPrd, termDate, subscrptnChnnl, signdSubscrptnDocIndic, renwlDate, keyPersnIndic, activeSrrnderFeeIndic, tempryIndic, jointPolholdrIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyGenDataType o = ((ProtectionPolicyGenDataType) other);
        return ((((((((((((((((Objects.equal(signDate, o.signDate)&&Objects.equal(reciptDate, o.reciptDate))&&Objects.equal(polCurr, o.polCurr))&&Objects.equal(insrdAmnt, o.insrdAmnt))&&Objects.equal(duratn, o.duratn))&&Objects.equal(closngClause, o.closngClause))&&Objects.equal(handcpIndic, o.handcpIndic))&&Objects.equal(renunctnPrdWaitngIndic, o.renunctnPrdWaitngIndic))&&Objects.equal(polPrd, o.polPrd))&&Objects.equal(termDate, o.termDate))&&Objects.equal(subscrptnChnnl, o.subscrptnChnnl))&&Objects.equal(signdSubscrptnDocIndic, o.signdSubscrptnDocIndic))&&Objects.equal(renwlDate, o.renwlDate))&&Objects.equal(keyPersnIndic, o.keyPersnIndic))&&Objects.equal(activeSrrnderFeeIndic, o.activeSrrnderFeeIndic))&&Objects.equal(tempryIndic, o.tempryIndic))&&Objects.equal(jointPolholdrIndic, o.jointPolholdrIndic));
    }

}
