
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage specific data for protection policy
 * 			
 * 
 * <p>Java class for ProtectionPolicyDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SignDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ReciptDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="PolCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="InsrdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="ClosngClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoSubscriptionClosingClauseCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="HandcpIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="RenunctnPrdWaitngIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="SigndSubscrptnDocIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="MainHomeLoanIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="ZeroRateBnftIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="LoanCtgory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanObjectCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MrtggeAdviceReq" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="TempryIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="JointPolholdrIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyDataInputType", propOrder = {
    "signDate",
    "reciptDate",
    "polCurr",
    "insrdAmnt",
    "duratn",
    "closngClause",
    "handcpIndic",
    "renunctnPrdWaitngIndic",
    "signdSubscrptnDocIndic",
    "mainHomeLoanIndic",
    "zeroRateBnftIndic",
    "loanCtgory",
    "mrtggeAdviceReq",
    "tempryIndic",
    "jointPolholdrIndic"
})
public class ProtectionPolicyDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SignDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date signDate;
    @XmlElement(name = "ReciptDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date reciptDate;
    @XmlElement(name = "PolCurr")
    protected String polCurr;
    @XmlElement(name = "InsrdAmnt")
    protected CurrencyAndAmountType insrdAmnt;
    @XmlElement(name = "Duratn")
    protected DurationType duratn;
    @XmlElement(name = "ClosngClause")
    protected String closngClause;
    @XmlElement(name = "HandcpIndic")
    protected String handcpIndic;
    @XmlElement(name = "RenunctnPrdWaitngIndic")
    protected String renunctnPrdWaitngIndic;
    @XmlElement(name = "SigndSubscrptnDocIndic")
    protected String signdSubscrptnDocIndic;
    @XmlElement(name = "MainHomeLoanIndic")
    protected String mainHomeLoanIndic;
    @XmlElement(name = "ZeroRateBnftIndic")
    protected String zeroRateBnftIndic;
    @XmlElement(name = "LoanCtgory")
    protected String loanCtgory;
    @XmlElement(name = "MrtggeAdviceReq")
    protected String mrtggeAdviceReq;
    @XmlElement(name = "TempryIndic")
    protected String tempryIndic;
    @XmlElement(name = "JointPolholdrIndic")
    protected String jointPolholdrIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyDataInputType(final Date signDate, final Date reciptDate, final String polCurr, final CurrencyAndAmountType insrdAmnt, final DurationType duratn, final String closngClause, final String handcpIndic, final String renunctnPrdWaitngIndic, final String signdSubscrptnDocIndic, final String mainHomeLoanIndic, final String zeroRateBnftIndic, final String loanCtgory, final String mrtggeAdviceReq, final String tempryIndic, final String jointPolholdrIndic) {
        this.signDate = signDate;
        this.reciptDate = reciptDate;
        this.polCurr = polCurr;
        this.insrdAmnt = insrdAmnt;
        this.duratn = duratn;
        this.closngClause = closngClause;
        this.handcpIndic = handcpIndic;
        this.renunctnPrdWaitngIndic = renunctnPrdWaitngIndic;
        this.signdSubscrptnDocIndic = signdSubscrptnDocIndic;
        this.mainHomeLoanIndic = mainHomeLoanIndic;
        this.zeroRateBnftIndic = zeroRateBnftIndic;
        this.loanCtgory = loanCtgory;
        this.mrtggeAdviceReq = mrtggeAdviceReq;
        this.tempryIndic = tempryIndic;
        this.jointPolholdrIndic = jointPolholdrIndic;
    }

    /**
     * Gets the value of the signDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSignDate() {
        return signDate;
    }

    /**
     * Sets the value of the signDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignDate(Date value) {
        this.signDate = value;
    }

    public boolean isSetSignDate() {
        return (this.signDate!= null);
    }

    /**
     * Gets the value of the reciptDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getReciptDate() {
        return reciptDate;
    }

    /**
     * Sets the value of the reciptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReciptDate(Date value) {
        this.reciptDate = value;
    }

    public boolean isSetReciptDate() {
        return (this.reciptDate!= null);
    }

    /**
     * Gets the value of the polCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolCurr() {
        return polCurr;
    }

    /**
     * Sets the value of the polCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolCurr(String value) {
        this.polCurr = value;
    }

    public boolean isSetPolCurr() {
        return (this.polCurr!= null);
    }

    /**
     * Gets the value of the insrdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInsrdAmnt() {
        return insrdAmnt;
    }

    /**
     * Sets the value of the insrdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInsrdAmnt(CurrencyAndAmountType value) {
        this.insrdAmnt = value;
    }

    public boolean isSetInsrdAmnt() {
        return (this.insrdAmnt!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    /**
     * Gets the value of the closngClause property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosngClause() {
        return closngClause;
    }

    /**
     * Sets the value of the closngClause property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosngClause(String value) {
        this.closngClause = value;
    }

    public boolean isSetClosngClause() {
        return (this.closngClause!= null);
    }

    /**
     * Gets the value of the handcpIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHandcpIndic() {
        return handcpIndic;
    }

    /**
     * Sets the value of the handcpIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHandcpIndic(String value) {
        this.handcpIndic = value;
    }

    public boolean isSetHandcpIndic() {
        return (this.handcpIndic!= null);
    }

    /**
     * Gets the value of the renunctnPrdWaitngIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenunctnPrdWaitngIndic() {
        return renunctnPrdWaitngIndic;
    }

    /**
     * Sets the value of the renunctnPrdWaitngIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenunctnPrdWaitngIndic(String value) {
        this.renunctnPrdWaitngIndic = value;
    }

    public boolean isSetRenunctnPrdWaitngIndic() {
        return (this.renunctnPrdWaitngIndic!= null);
    }

    /**
     * Gets the value of the signdSubscrptnDocIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSigndSubscrptnDocIndic() {
        return signdSubscrptnDocIndic;
    }

    /**
     * Sets the value of the signdSubscrptnDocIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSigndSubscrptnDocIndic(String value) {
        this.signdSubscrptnDocIndic = value;
    }

    public boolean isSetSigndSubscrptnDocIndic() {
        return (this.signdSubscrptnDocIndic!= null);
    }

    /**
     * Gets the value of the mainHomeLoanIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMainHomeLoanIndic() {
        return mainHomeLoanIndic;
    }

    /**
     * Sets the value of the mainHomeLoanIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMainHomeLoanIndic(String value) {
        this.mainHomeLoanIndic = value;
    }

    public boolean isSetMainHomeLoanIndic() {
        return (this.mainHomeLoanIndic!= null);
    }

    /**
     * Gets the value of the zeroRateBnftIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZeroRateBnftIndic() {
        return zeroRateBnftIndic;
    }

    /**
     * Sets the value of the zeroRateBnftIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZeroRateBnftIndic(String value) {
        this.zeroRateBnftIndic = value;
    }

    public boolean isSetZeroRateBnftIndic() {
        return (this.zeroRateBnftIndic!= null);
    }

    /**
     * Gets the value of the loanCtgory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanCtgory() {
        return loanCtgory;
    }

    /**
     * Sets the value of the loanCtgory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanCtgory(String value) {
        this.loanCtgory = value;
    }

    public boolean isSetLoanCtgory() {
        return (this.loanCtgory!= null);
    }

    /**
     * Gets the value of the mrtggeAdviceReq property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMrtggeAdviceReq() {
        return mrtggeAdviceReq;
    }

    /**
     * Sets the value of the mrtggeAdviceReq property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMrtggeAdviceReq(String value) {
        this.mrtggeAdviceReq = value;
    }

    public boolean isSetMrtggeAdviceReq() {
        return (this.mrtggeAdviceReq!= null);
    }

    /**
     * Gets the value of the tempryIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTempryIndic() {
        return tempryIndic;
    }

    /**
     * Sets the value of the tempryIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTempryIndic(String value) {
        this.tempryIndic = value;
    }

    public boolean isSetTempryIndic() {
        return (this.tempryIndic!= null);
    }

    /**
     * Gets the value of the jointPolholdrIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJointPolholdrIndic() {
        return jointPolholdrIndic;
    }

    /**
     * Sets the value of the jointPolholdrIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJointPolholdrIndic(String value) {
        this.jointPolholdrIndic = value;
    }

    public boolean isSetJointPolholdrIndic() {
        return (this.jointPolholdrIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("signDate", signDate).add("reciptDate", reciptDate).add("polCurr", polCurr).add("insrdAmnt", insrdAmnt).add("duratn", duratn).add("closngClause", closngClause).add("handcpIndic", handcpIndic).add("renunctnPrdWaitngIndic", renunctnPrdWaitngIndic).add("signdSubscrptnDocIndic", signdSubscrptnDocIndic).add("mainHomeLoanIndic", mainHomeLoanIndic).add("zeroRateBnftIndic", zeroRateBnftIndic).add("loanCtgory", loanCtgory).add("mrtggeAdviceReq", mrtggeAdviceReq).add("tempryIndic", tempryIndic).add("jointPolholdrIndic", jointPolholdrIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(signDate, reciptDate, polCurr, insrdAmnt, duratn, closngClause, handcpIndic, renunctnPrdWaitngIndic, signdSubscrptnDocIndic, mainHomeLoanIndic, zeroRateBnftIndic, loanCtgory, mrtggeAdviceReq, tempryIndic, jointPolholdrIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyDataInputType o = ((ProtectionPolicyDataInputType) other);
        return ((((((((((((((Objects.equal(signDate, o.signDate)&&Objects.equal(reciptDate, o.reciptDate))&&Objects.equal(polCurr, o.polCurr))&&Objects.equal(insrdAmnt, o.insrdAmnt))&&Objects.equal(duratn, o.duratn))&&Objects.equal(closngClause, o.closngClause))&&Objects.equal(handcpIndic, o.handcpIndic))&&Objects.equal(renunctnPrdWaitngIndic, o.renunctnPrdWaitngIndic))&&Objects.equal(signdSubscrptnDocIndic, o.signdSubscrptnDocIndic))&&Objects.equal(mainHomeLoanIndic, o.mainHomeLoanIndic))&&Objects.equal(zeroRateBnftIndic, o.zeroRateBnftIndic))&&Objects.equal(loanCtgory, o.loanCtgory))&&Objects.equal(mrtggeAdviceReq, o.mrtggeAdviceReq))&&Objects.equal(tempryIndic, o.tempryIndic))&&Objects.equal(jointPolholdrIndic, o.jointPolholdrIndic));
    }

}
