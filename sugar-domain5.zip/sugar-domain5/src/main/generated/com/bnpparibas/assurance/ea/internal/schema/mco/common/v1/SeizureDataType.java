
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on a policy seizure
 * 			
 * 
 * <p>Java class for SeizureDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SeizureDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MeasureOfConservationTypeCodeSLN"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalMeasuresStatusCodeSLN"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="FreeText" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FreeTextType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SeizureDataType", propOrder = {
    "idntctn",
    "type",
    "status",
    "effctveDate",
    "freeText"
})
public class SeizureDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntctn", required = true)
    protected ObjectIdentificationType idntctn;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "Status", required = true)
    protected String status;
    @XmlElement(name = "EffctveDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date effctveDate;
    @XmlElement(name = "FreeText")
    protected String freeText;

    /**
     * Default no-arg constructor
     * 
     */
    public SeizureDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SeizureDataType(final ObjectIdentificationType idntctn, final String type, final String status, final Date effctveDate, final String freeText) {
        this.idntctn = idntctn;
        this.type = type;
        this.status = status;
        this.effctveDate = effctveDate;
        this.freeText = freeText;
    }

    /**
     * Gets the value of the idntctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntctn() {
        return idntctn;
    }

    /**
     * Sets the value of the idntctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntctn(ObjectIdentificationType value) {
        this.idntctn = value;
    }

    public boolean isSetIdntctn() {
        return (this.idntctn!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the freeText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeText() {
        return freeText;
    }

    /**
     * Sets the value of the freeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeText(String value) {
        this.freeText = value;
    }

    public boolean isSetFreeText() {
        return (this.freeText!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntctn", idntctn).add("type", type).add("status", status).add("effctveDate", effctveDate).add("freeText", freeText).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntctn, type, status, effctveDate, freeText);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SeizureDataType o = ((SeizureDataType) other);
        return ((((Objects.equal(idntctn, o.idntctn)&&Objects.equal(type, o.type))&&Objects.equal(status, o.status))&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(freeText, o.freeText));
    }

}
