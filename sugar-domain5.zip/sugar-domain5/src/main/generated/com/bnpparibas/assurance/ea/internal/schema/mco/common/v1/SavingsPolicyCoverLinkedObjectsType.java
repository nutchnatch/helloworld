
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a savings policy cover request
 * 				has dependencies
 * 			
 * 
 * <p>Java class for SavingsPolicyCoverLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyCoverLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Insrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="Insurer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyCoverLinkedObjectsType", propOrder = {
    "insrd",
    "insurer"
})
public class SavingsPolicyCoverLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Insrd")
    protected PartyRoleType insrd;
    @XmlElement(name = "Insurer")
    protected PartyRoleType insurer;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyCoverLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyCoverLinkedObjectsType(final PartyRoleType insrd, final PartyRoleType insurer) {
        this.insrd = insrd;
        this.insurer = insurer;
    }

    /**
     * Gets the value of the insrd property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsrd() {
        return insrd;
    }

    /**
     * Sets the value of the insrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsrd(PartyRoleType value) {
        this.insrd = value;
    }

    public boolean isSetInsrd() {
        return (this.insrd!= null);
    }

    /**
     * Gets the value of the insurer property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsurer() {
        return insurer;
    }

    /**
     * Sets the value of the insurer property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsurer(PartyRoleType value) {
        this.insurer = value;
    }

    public boolean isSetInsurer() {
        return (this.insurer!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("insrd", insrd).add("insurer", insurer).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(insrd, insurer);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyCoverLinkedObjectsType o = ((SavingsPolicyCoverLinkedObjectsType) other);
        return (Objects.equal(insrd, o.insrd)&&Objects.equal(insurer, o.insurer));
    }

}
