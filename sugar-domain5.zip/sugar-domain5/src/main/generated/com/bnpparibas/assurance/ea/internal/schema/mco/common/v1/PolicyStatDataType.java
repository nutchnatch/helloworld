
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Statistiques sur les
 * 				contrats liés au produit de prévoyance et à un partenaire
 * 			
 * 
 * <p>Java class for PolicyStatDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyStatDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MinDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *         &lt;element name="MaxDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *         &lt;element name="AvrgeDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyStatDataType", propOrder = {
    "minDuratn",
    "maxDuratn",
    "avrgeDuratn"
})
public class PolicyStatDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "MinDuratn", required = true)
    protected DurationType minDuratn;
    @XmlElement(name = "MaxDuratn", required = true)
    protected DurationType maxDuratn;
    @XmlElement(name = "AvrgeDuratn", required = true)
    protected DurationType avrgeDuratn;

    /**
     * Default no-arg constructor
     * 
     */
    public PolicyStatDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PolicyStatDataType(final DurationType minDuratn, final DurationType maxDuratn, final DurationType avrgeDuratn) {
        this.minDuratn = minDuratn;
        this.maxDuratn = maxDuratn;
        this.avrgeDuratn = avrgeDuratn;
    }

    /**
     * Gets the value of the minDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getMinDuratn() {
        return minDuratn;
    }

    /**
     * Sets the value of the minDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setMinDuratn(DurationType value) {
        this.minDuratn = value;
    }

    public boolean isSetMinDuratn() {
        return (this.minDuratn!= null);
    }

    /**
     * Gets the value of the maxDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getMaxDuratn() {
        return maxDuratn;
    }

    /**
     * Sets the value of the maxDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setMaxDuratn(DurationType value) {
        this.maxDuratn = value;
    }

    public boolean isSetMaxDuratn() {
        return (this.maxDuratn!= null);
    }

    /**
     * Gets the value of the avrgeDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getAvrgeDuratn() {
        return avrgeDuratn;
    }

    /**
     * Sets the value of the avrgeDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setAvrgeDuratn(DurationType value) {
        this.avrgeDuratn = value;
    }

    public boolean isSetAvrgeDuratn() {
        return (this.avrgeDuratn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("minDuratn", minDuratn).add("maxDuratn", maxDuratn).add("avrgeDuratn", avrgeDuratn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(minDuratn, maxDuratn, avrgeDuratn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PolicyStatDataType o = ((PolicyStatDataType) other);
        return ((Objects.equal(minDuratn, o.minDuratn)&&Objects.equal(maxDuratn, o.maxDuratn))&&Objects.equal(avrgeDuratn, o.avrgeDuratn));
    }

}
