
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * libellé avec code langue
 * 			
 * 
 * <p>Java class for Wording complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Wording"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
 *       &lt;attribute name="Lang" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LanguageCode" /&gt;
 *       &lt;attribute name="Country" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Wording", propOrder = {
    "value"
})
public class Wording implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected String value;
    @XmlAttribute(name = "Lang")
    protected String lang;
    @XmlAttribute(name = "Country")
    protected String country;

    /**
     * Default no-arg constructor
     * 
     */
    public Wording() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Wording(final String value, final String lang, final String country) {
        this.value = value;
        this.lang = lang;
        this.country = country;
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    /**
     * Gets the value of the country property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountry() {
        return country;
    }

    /**
     * Sets the value of the country property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountry(String value) {
        this.country = value;
    }

    public boolean isSetCountry() {
        return (this.country!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("lang", lang).add("country", country).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, lang, country);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Wording o = ((Wording) other);
        return ((Objects.equal(value, o.value)&&Objects.equal(lang, o.lang))&&Objects.equal(country, o.country));
    }

}
