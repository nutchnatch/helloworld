
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Statistiques sur les
 * 				primes
 * 			
 * 
 * <p>Java class for PremiumStatDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PremiumStatDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PremType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumTypeCodeSLN"/&gt;
 *         &lt;element name="AmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN"/&gt;
 *         &lt;element name="AvrgeAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="TotAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="PrevTotAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PremiumStatDataType", propOrder = {
    "premType",
    "amntType",
    "avrgeAmnt",
    "totAmnt",
    "prevTotAmnt"
})
public class PremiumStatDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PremType", required = true)
    protected String premType;
    @XmlElement(name = "AmntType", required = true)
    protected String amntType;
    @XmlElement(name = "AvrgeAmnt")
    protected CurrencyAndAmountType avrgeAmnt;
    @XmlElement(name = "TotAmnt")
    protected CurrencyAndAmountType totAmnt;
    @XmlElement(name = "PrevTotAmnt")
    protected CurrencyAndAmountType prevTotAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public PremiumStatDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PremiumStatDataType(final String premType, final String amntType, final CurrencyAndAmountType avrgeAmnt, final CurrencyAndAmountType totAmnt, final CurrencyAndAmountType prevTotAmnt) {
        this.premType = premType;
        this.amntType = amntType;
        this.avrgeAmnt = avrgeAmnt;
        this.totAmnt = totAmnt;
        this.prevTotAmnt = prevTotAmnt;
    }

    /**
     * Gets the value of the premType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremType() {
        return premType;
    }

    /**
     * Sets the value of the premType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremType(String value) {
        this.premType = value;
    }

    public boolean isSetPremType() {
        return (this.premType!= null);
    }

    /**
     * Gets the value of the amntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmntType() {
        return amntType;
    }

    /**
     * Sets the value of the amntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmntType(String value) {
        this.amntType = value;
    }

    public boolean isSetAmntType() {
        return (this.amntType!= null);
    }

    /**
     * Gets the value of the avrgeAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAvrgeAmnt() {
        return avrgeAmnt;
    }

    /**
     * Sets the value of the avrgeAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAvrgeAmnt(CurrencyAndAmountType value) {
        this.avrgeAmnt = value;
    }

    public boolean isSetAvrgeAmnt() {
        return (this.avrgeAmnt!= null);
    }

    /**
     * Gets the value of the totAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getTotAmnt() {
        return totAmnt;
    }

    /**
     * Sets the value of the totAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setTotAmnt(CurrencyAndAmountType value) {
        this.totAmnt = value;
    }

    public boolean isSetTotAmnt() {
        return (this.totAmnt!= null);
    }

    /**
     * Gets the value of the prevTotAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPrevTotAmnt() {
        return prevTotAmnt;
    }

    /**
     * Sets the value of the prevTotAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPrevTotAmnt(CurrencyAndAmountType value) {
        this.prevTotAmnt = value;
    }

    public boolean isSetPrevTotAmnt() {
        return (this.prevTotAmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("premType", premType).add("amntType", amntType).add("avrgeAmnt", avrgeAmnt).add("totAmnt", totAmnt).add("prevTotAmnt", prevTotAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(premType, amntType, avrgeAmnt, totAmnt, prevTotAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PremiumStatDataType o = ((PremiumStatDataType) other);
        return ((((Objects.equal(premType, o.premType)&&Objects.equal(amntType, o.amntType))&&Objects.equal(avrgeAmnt, o.avrgeAmnt))&&Objects.equal(totAmnt, o.totAmnt))&&Objects.equal(prevTotAmnt, o.prevTotAmnt));
    }

}
