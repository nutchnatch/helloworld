
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data of a package of covers linked
 * 				to a simplified protection prioduct
 * 			
 * 
 * <p>Java class for SimplifiedProtectionCoversPackageDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SimplifiedProtectionCoversPackageDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="CovIdntfctn" maxOccurs="unbounded"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *                   &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode"/&gt;
 *                   &lt;element name="LifeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LifeIndicatorCodeSLN"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="MarktngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SimplifiedProtectionCoversPackageDataType", propOrder = {
    "id",
    "name",
    "covIdntfctn",
    "marktngPrd"
})
public class SimplifiedProtectionCoversPackageDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id", required = true)
    protected String id;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "CovIdntfctn", required = true)
    protected List<SimplifiedProtectionCoversPackageDataType.CovIdntfctn> covIdntfctn;
    @XmlElement(name = "MarktngPrd")
    protected DatePeriodType marktngPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public SimplifiedProtectionCoversPackageDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SimplifiedProtectionCoversPackageDataType(final String id, final String name, final List<SimplifiedProtectionCoversPackageDataType.CovIdntfctn> covIdntfctn, final DatePeriodType marktngPrd) {
        this.id = id;
        this.name = name;
        this.covIdntfctn = covIdntfctn;
        this.marktngPrd = marktngPrd;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the covIdntfctn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covIdntfctn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovIdntfctn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SimplifiedProtectionCoversPackageDataType.CovIdntfctn }
     * 
     * 
     */
    public List<SimplifiedProtectionCoversPackageDataType.CovIdntfctn> getCovIdntfctn() {
        if (covIdntfctn == null) {
            covIdntfctn = new ArrayList<SimplifiedProtectionCoversPackageDataType.CovIdntfctn>();
        }
        return this.covIdntfctn;
    }

    public boolean isSetCovIdntfctn() {
        return ((this.covIdntfctn!= null)&&(!this.covIdntfctn.isEmpty()));
    }

    public void unsetCovIdntfctn() {
        this.covIdntfctn = null;
    }

    /**
     * Gets the value of the marktngPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getMarktngPrd() {
        return marktngPrd;
    }

    /**
     * Sets the value of the marktngPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setMarktngPrd(DatePeriodType value) {
        this.marktngPrd = value;
    }

    public boolean isSetMarktngPrd() {
        return (this.marktngPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("name", name).add("covIdntfctn", covIdntfctn).add("marktngPrd", marktngPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, name, covIdntfctn, marktngPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SimplifiedProtectionCoversPackageDataType o = ((SimplifiedProtectionCoversPackageDataType) other);
        return (((Objects.equal(id, o.id)&&Objects.equal(name, o.name))&&Objects.equal(covIdntfctn, o.covIdntfctn))&&Objects.equal(marktngPrd, o.marktngPrd));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
     *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode"/&gt;
     *         &lt;element name="LifeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LifeIndicatorCodeSLN"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "id",
        "code",
        "lifeIndic"
    })
    public static class CovIdntfctn implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Id", required = true)
        protected String id;
        @XmlElement(name = "Code", required = true)
        protected String code;
        @XmlElement(name = "LifeIndic", required = true)
        protected String lifeIndic;

        /**
         * Default no-arg constructor
         * 
         */
        public CovIdntfctn() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public CovIdntfctn(final String id, final String code, final String lifeIndic) {
            this.id = id;
            this.code = code;
            this.lifeIndic = lifeIndic;
        }

        /**
         * Gets the value of the id property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getId() {
            return id;
        }

        /**
         * Sets the value of the id property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setId(String value) {
            this.id = value;
        }

        public boolean isSetId() {
            return (this.id!= null);
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        public boolean isSetCode() {
            return (this.code!= null);
        }

        /**
         * Gets the value of the lifeIndic property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLifeIndic() {
            return lifeIndic;
        }

        /**
         * Sets the value of the lifeIndic property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLifeIndic(String value) {
            this.lifeIndic = value;
        }

        public boolean isSetLifeIndic() {
            return (this.lifeIndic!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("id", id).add("code", code).add("lifeIndic", lifeIndic).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(id, code, lifeIndic);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final SimplifiedProtectionCoversPackageDataType.CovIdntfctn o = ((SimplifiedProtectionCoversPackageDataType.CovIdntfctn) other);
            return ((Objects.equal(id, o.id)&&Objects.equal(code, o.code))&&Objects.equal(lifeIndic, o.lifeIndic));
        }

    }

}
