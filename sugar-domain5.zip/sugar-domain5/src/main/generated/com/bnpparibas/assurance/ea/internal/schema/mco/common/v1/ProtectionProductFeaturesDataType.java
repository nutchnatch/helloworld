
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Protection product features
 * 
 * <p>Java class for ProtectionProductFeaturesDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionProductFeaturesDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="StdCondtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StandardConditionDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="DueDay" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MonthDayCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="MgmtMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductManagementModeDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PremNature" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumTypeDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AuthrzdOpeReq" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductAuthorizedOperationRequestDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OpeFeeTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductOperationFeeTermsDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="TrgetPop" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TargetPopulationDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PaymntMethd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductAuthorizedPaymentMethodDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PremRecvrySchme" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumRecoverySchemeDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SocioPrfssnalCtgory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductSocioProfessionalCategoryDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LoanTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductLoanDataTermsDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionProductFeaturesDataType", propOrder = {
    "stdCondtn",
    "dueDay",
    "mgmtMode",
    "premNature",
    "authrzdOpeReq",
    "opeFeeTerms",
    "trgetPop",
    "paymntMethd",
    "premRecvrySchme",
    "socioPrfssnalCtgory",
    "loanTerms"
})
public class ProtectionProductFeaturesDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "StdCondtn")
    protected List<StandardConditionDataType> stdCondtn;
    @XmlElement(name = "DueDay")
    protected List<String> dueDay;
    @XmlElement(name = "MgmtMode")
    protected List<ProductManagementModeDataType> mgmtMode;
    @XmlElement(name = "PremNature")
    protected List<PremiumTypeDataType> premNature;
    @XmlElement(name = "AuthrzdOpeReq")
    protected List<ProductAuthorizedOperationRequestDataType> authrzdOpeReq;
    @XmlElement(name = "OpeFeeTerms")
    protected List<ProductOperationFeeTermsDataType> opeFeeTerms;
    @XmlElement(name = "TrgetPop")
    protected List<TargetPopulationDataType> trgetPop;
    @XmlElement(name = "PaymntMethd")
    protected List<ProductAuthorizedPaymentMethodDataType> paymntMethd;
    @XmlElement(name = "PremRecvrySchme")
    protected List<PremiumRecoverySchemeDataType> premRecvrySchme;
    @XmlElement(name = "SocioPrfssnalCtgory")
    protected List<ProductSocioProfessionalCategoryDataType> socioPrfssnalCtgory;
    @XmlElement(name = "LoanTerms")
    protected List<ProductLoanDataTermsDataType> loanTerms;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionProductFeaturesDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionProductFeaturesDataType(final List<StandardConditionDataType> stdCondtn, final List<String> dueDay, final List<ProductManagementModeDataType> mgmtMode, final List<PremiumTypeDataType> premNature, final List<ProductAuthorizedOperationRequestDataType> authrzdOpeReq, final List<ProductOperationFeeTermsDataType> opeFeeTerms, final List<TargetPopulationDataType> trgetPop, final List<ProductAuthorizedPaymentMethodDataType> paymntMethd, final List<PremiumRecoverySchemeDataType> premRecvrySchme, final List<ProductSocioProfessionalCategoryDataType> socioPrfssnalCtgory, final List<ProductLoanDataTermsDataType> loanTerms) {
        this.stdCondtn = stdCondtn;
        this.dueDay = dueDay;
        this.mgmtMode = mgmtMode;
        this.premNature = premNature;
        this.authrzdOpeReq = authrzdOpeReq;
        this.opeFeeTerms = opeFeeTerms;
        this.trgetPop = trgetPop;
        this.paymntMethd = paymntMethd;
        this.premRecvrySchme = premRecvrySchme;
        this.socioPrfssnalCtgory = socioPrfssnalCtgory;
        this.loanTerms = loanTerms;
    }

    /**
     * Gets the value of the stdCondtn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stdCondtn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStdCondtn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StandardConditionDataType }
     * 
     * 
     */
    public List<StandardConditionDataType> getStdCondtn() {
        if (stdCondtn == null) {
            stdCondtn = new ArrayList<StandardConditionDataType>();
        }
        return this.stdCondtn;
    }

    public boolean isSetStdCondtn() {
        return ((this.stdCondtn!= null)&&(!this.stdCondtn.isEmpty()));
    }

    public void unsetStdCondtn() {
        this.stdCondtn = null;
    }

    /**
     * Gets the value of the dueDay property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dueDay property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDueDay().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getDueDay() {
        if (dueDay == null) {
            dueDay = new ArrayList<String>();
        }
        return this.dueDay;
    }

    public boolean isSetDueDay() {
        return ((this.dueDay!= null)&&(!this.dueDay.isEmpty()));
    }

    public void unsetDueDay() {
        this.dueDay = null;
    }

    /**
     * Gets the value of the mgmtMode property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mgmtMode property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMgmtMode().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductManagementModeDataType }
     * 
     * 
     */
    public List<ProductManagementModeDataType> getMgmtMode() {
        if (mgmtMode == null) {
            mgmtMode = new ArrayList<ProductManagementModeDataType>();
        }
        return this.mgmtMode;
    }

    public boolean isSetMgmtMode() {
        return ((this.mgmtMode!= null)&&(!this.mgmtMode.isEmpty()));
    }

    public void unsetMgmtMode() {
        this.mgmtMode = null;
    }

    /**
     * Gets the value of the premNature property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the premNature property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPremNature().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PremiumTypeDataType }
     * 
     * 
     */
    public List<PremiumTypeDataType> getPremNature() {
        if (premNature == null) {
            premNature = new ArrayList<PremiumTypeDataType>();
        }
        return this.premNature;
    }

    public boolean isSetPremNature() {
        return ((this.premNature!= null)&&(!this.premNature.isEmpty()));
    }

    public void unsetPremNature() {
        this.premNature = null;
    }

    /**
     * Gets the value of the authrzdOpeReq property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the authrzdOpeReq property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthrzdOpeReq().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAuthorizedOperationRequestDataType }
     * 
     * 
     */
    public List<ProductAuthorizedOperationRequestDataType> getAuthrzdOpeReq() {
        if (authrzdOpeReq == null) {
            authrzdOpeReq = new ArrayList<ProductAuthorizedOperationRequestDataType>();
        }
        return this.authrzdOpeReq;
    }

    public boolean isSetAuthrzdOpeReq() {
        return ((this.authrzdOpeReq!= null)&&(!this.authrzdOpeReq.isEmpty()));
    }

    public void unsetAuthrzdOpeReq() {
        this.authrzdOpeReq = null;
    }

    /**
     * Gets the value of the opeFeeTerms property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the opeFeeTerms property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOpeFeeTerms().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductOperationFeeTermsDataType }
     * 
     * 
     */
    public List<ProductOperationFeeTermsDataType> getOpeFeeTerms() {
        if (opeFeeTerms == null) {
            opeFeeTerms = new ArrayList<ProductOperationFeeTermsDataType>();
        }
        return this.opeFeeTerms;
    }

    public boolean isSetOpeFeeTerms() {
        return ((this.opeFeeTerms!= null)&&(!this.opeFeeTerms.isEmpty()));
    }

    public void unsetOpeFeeTerms() {
        this.opeFeeTerms = null;
    }

    /**
     * Gets the value of the trgetPop property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the trgetPop property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTrgetPop().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TargetPopulationDataType }
     * 
     * 
     */
    public List<TargetPopulationDataType> getTrgetPop() {
        if (trgetPop == null) {
            trgetPop = new ArrayList<TargetPopulationDataType>();
        }
        return this.trgetPop;
    }

    public boolean isSetTrgetPop() {
        return ((this.trgetPop!= null)&&(!this.trgetPop.isEmpty()));
    }

    public void unsetTrgetPop() {
        this.trgetPop = null;
    }

    /**
     * Gets the value of the paymntMethd property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the paymntMethd property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPaymntMethd().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductAuthorizedPaymentMethodDataType }
     * 
     * 
     */
    public List<ProductAuthorizedPaymentMethodDataType> getPaymntMethd() {
        if (paymntMethd == null) {
            paymntMethd = new ArrayList<ProductAuthorizedPaymentMethodDataType>();
        }
        return this.paymntMethd;
    }

    public boolean isSetPaymntMethd() {
        return ((this.paymntMethd!= null)&&(!this.paymntMethd.isEmpty()));
    }

    public void unsetPaymntMethd() {
        this.paymntMethd = null;
    }

    /**
     * Gets the value of the premRecvrySchme property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the premRecvrySchme property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPremRecvrySchme().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PremiumRecoverySchemeDataType }
     * 
     * 
     */
    public List<PremiumRecoverySchemeDataType> getPremRecvrySchme() {
        if (premRecvrySchme == null) {
            premRecvrySchme = new ArrayList<PremiumRecoverySchemeDataType>();
        }
        return this.premRecvrySchme;
    }

    public boolean isSetPremRecvrySchme() {
        return ((this.premRecvrySchme!= null)&&(!this.premRecvrySchme.isEmpty()));
    }

    public void unsetPremRecvrySchme() {
        this.premRecvrySchme = null;
    }

    /**
     * Gets the value of the socioPrfssnalCtgory property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the socioPrfssnalCtgory property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSocioPrfssnalCtgory().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductSocioProfessionalCategoryDataType }
     * 
     * 
     */
    public List<ProductSocioProfessionalCategoryDataType> getSocioPrfssnalCtgory() {
        if (socioPrfssnalCtgory == null) {
            socioPrfssnalCtgory = new ArrayList<ProductSocioProfessionalCategoryDataType>();
        }
        return this.socioPrfssnalCtgory;
    }

    public boolean isSetSocioPrfssnalCtgory() {
        return ((this.socioPrfssnalCtgory!= null)&&(!this.socioPrfssnalCtgory.isEmpty()));
    }

    public void unsetSocioPrfssnalCtgory() {
        this.socioPrfssnalCtgory = null;
    }

    /**
     * Gets the value of the loanTerms property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the loanTerms property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLoanTerms().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductLoanDataTermsDataType }
     * 
     * 
     */
    public List<ProductLoanDataTermsDataType> getLoanTerms() {
        if (loanTerms == null) {
            loanTerms = new ArrayList<ProductLoanDataTermsDataType>();
        }
        return this.loanTerms;
    }

    public boolean isSetLoanTerms() {
        return ((this.loanTerms!= null)&&(!this.loanTerms.isEmpty()));
    }

    public void unsetLoanTerms() {
        this.loanTerms = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("stdCondtn", stdCondtn).add("dueDay", dueDay).add("mgmtMode", mgmtMode).add("premNature", premNature).add("authrzdOpeReq", authrzdOpeReq).add("opeFeeTerms", opeFeeTerms).add("trgetPop", trgetPop).add("paymntMethd", paymntMethd).add("premRecvrySchme", premRecvrySchme).add("socioPrfssnalCtgory", socioPrfssnalCtgory).add("loanTerms", loanTerms).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(stdCondtn, dueDay, mgmtMode, premNature, authrzdOpeReq, opeFeeTerms, trgetPop, paymntMethd, premRecvrySchme, socioPrfssnalCtgory, loanTerms);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionProductFeaturesDataType o = ((ProtectionProductFeaturesDataType) other);
        return ((((((((((Objects.equal(stdCondtn, o.stdCondtn)&&Objects.equal(dueDay, o.dueDay))&&Objects.equal(mgmtMode, o.mgmtMode))&&Objects.equal(premNature, o.premNature))&&Objects.equal(authrzdOpeReq, o.authrzdOpeReq))&&Objects.equal(opeFeeTerms, o.opeFeeTerms))&&Objects.equal(trgetPop, o.trgetPop))&&Objects.equal(paymntMethd, o.paymntMethd))&&Objects.equal(premRecvrySchme, o.premRecvrySchme))&&Objects.equal(socioPrfssnalCtgory, o.socioPrfssnalCtgory))&&Objects.equal(loanTerms, o.loanTerms));
    }

}
