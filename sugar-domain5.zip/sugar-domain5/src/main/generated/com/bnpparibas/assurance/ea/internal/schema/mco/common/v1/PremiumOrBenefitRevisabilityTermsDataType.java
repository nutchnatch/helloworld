
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on the revisability of premium
 * 				or benefit calculation
 * 			
 * 
 * <p>Java class for PremiumOrBenefitRevisabilityTermsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PremiumOrBenefitRevisabilityTermsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RvsbleIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="UnlimitedIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PremiumOrBenefitRevisabilityTermsDataType", propOrder = {
    "rvsbleIndic",
    "unlimitedIndic",
    "prd"
})
public class PremiumOrBenefitRevisabilityTermsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "RvsbleIndic")
    protected String rvsbleIndic;
    @XmlElement(name = "UnlimitedIndic")
    protected String unlimitedIndic;
    @XmlElement(name = "Prd")
    protected DurationType prd;

    /**
     * Default no-arg constructor
     * 
     */
    public PremiumOrBenefitRevisabilityTermsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PremiumOrBenefitRevisabilityTermsDataType(final String rvsbleIndic, final String unlimitedIndic, final DurationType prd) {
        this.rvsbleIndic = rvsbleIndic;
        this.unlimitedIndic = unlimitedIndic;
        this.prd = prd;
    }

    /**
     * Gets the value of the rvsbleIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRvsbleIndic() {
        return rvsbleIndic;
    }

    /**
     * Sets the value of the rvsbleIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRvsbleIndic(String value) {
        this.rvsbleIndic = value;
    }

    public boolean isSetRvsbleIndic() {
        return (this.rvsbleIndic!= null);
    }

    /**
     * Gets the value of the unlimitedIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnlimitedIndic() {
        return unlimitedIndic;
    }

    /**
     * Sets the value of the unlimitedIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnlimitedIndic(String value) {
        this.unlimitedIndic = value;
    }

    public boolean isSetUnlimitedIndic() {
        return (this.unlimitedIndic!= null);
    }

    /**
     * Gets the value of the prd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getPrd() {
        return prd;
    }

    /**
     * Sets the value of the prd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setPrd(DurationType value) {
        this.prd = value;
    }

    public boolean isSetPrd() {
        return (this.prd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("rvsbleIndic", rvsbleIndic).add("unlimitedIndic", unlimitedIndic).add("prd", prd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(rvsbleIndic, unlimitedIndic, prd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PremiumOrBenefitRevisabilityTermsDataType o = ((PremiumOrBenefitRevisabilityTermsDataType) other);
        return ((Objects.equal(rvsbleIndic, o.rvsbleIndic)&&Objects.equal(unlimitedIndic, o.unlimitedIndic))&&Objects.equal(prd, o.prd));
    }

}
