
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Justification des tarifs
 * 				appliqués aux garanties souscrites
 * 			
 * 
 * <p>Java class for ProtectionPolicyCoverPricingRationaleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyCoverPricingRationaleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SurchrgOrDscnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPolicyCoverSurchrgOrDiscntType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AdjstmntRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyCoverPricingRationaleType", propOrder = {
    "surchrgOrDscnt",
    "adjstmntRate"
})
public class ProtectionPolicyCoverPricingRationaleType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SurchrgOrDscnt")
    protected List<ProtectionPolicyCoverSurchrgOrDiscntType> surchrgOrDscnt;
    @XmlElement(name = "AdjstmntRate")
    protected BasisRateType adjstmntRate;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyCoverPricingRationaleType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyCoverPricingRationaleType(final List<ProtectionPolicyCoverSurchrgOrDiscntType> surchrgOrDscnt, final BasisRateType adjstmntRate) {
        this.surchrgOrDscnt = surchrgOrDscnt;
        this.adjstmntRate = adjstmntRate;
    }

    /**
     * Gets the value of the surchrgOrDscnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the surchrgOrDscnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSurchrgOrDscnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProtectionPolicyCoverSurchrgOrDiscntType }
     * 
     * 
     */
    public List<ProtectionPolicyCoverSurchrgOrDiscntType> getSurchrgOrDscnt() {
        if (surchrgOrDscnt == null) {
            surchrgOrDscnt = new ArrayList<ProtectionPolicyCoverSurchrgOrDiscntType>();
        }
        return this.surchrgOrDscnt;
    }

    public boolean isSetSurchrgOrDscnt() {
        return ((this.surchrgOrDscnt!= null)&&(!this.surchrgOrDscnt.isEmpty()));
    }

    public void unsetSurchrgOrDscnt() {
        this.surchrgOrDscnt = null;
    }

    /**
     * Gets the value of the adjstmntRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getAdjstmntRate() {
        return adjstmntRate;
    }

    /**
     * Sets the value of the adjstmntRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setAdjstmntRate(BasisRateType value) {
        this.adjstmntRate = value;
    }

    public boolean isSetAdjstmntRate() {
        return (this.adjstmntRate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("surchrgOrDscnt", surchrgOrDscnt).add("adjstmntRate", adjstmntRate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(surchrgOrDscnt, adjstmntRate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyCoverPricingRationaleType o = ((ProtectionPolicyCoverPricingRationaleType) other);
        return (Objects.equal(surchrgOrDscnt, o.surchrgOrDscnt)&&Objects.equal(adjstmntRate, o.adjstmntRate));
    }

}
