
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for SubscriptionCoverDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SubscriptionCoverDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductRiskIdentificationDataType"/&gt;
 *         &lt;element name="ClaimOptions" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverClaimTermsDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="InstllmntBnftIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubscriptionCoverDataInputType", propOrder = {
    "idntfctn",
    "claimOptions",
    "instllmntBnftIndic"
})
public class SubscriptionCoverDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn", required = true)
    protected ProductRiskIdentificationDataType idntfctn;
    @XmlElement(name = "ClaimOptions")
    protected CoverClaimTermsDataInputType claimOptions;
    @XmlElement(name = "InstllmntBnftIndic")
    protected String instllmntBnftIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public SubscriptionCoverDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SubscriptionCoverDataInputType(final ProductRiskIdentificationDataType idntfctn, final CoverClaimTermsDataInputType claimOptions, final String instllmntBnftIndic) {
        this.idntfctn = idntfctn;
        this.claimOptions = claimOptions;
        this.instllmntBnftIndic = instllmntBnftIndic;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ProductRiskIdentificationDataType }
     *     
     */
    public ProductRiskIdentificationDataType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductRiskIdentificationDataType }
     *     
     */
    public void setIdntfctn(ProductRiskIdentificationDataType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the claimOptions property.
     * 
     * @return
     *     possible object is
     *     {@link CoverClaimTermsDataInputType }
     *     
     */
    public CoverClaimTermsDataInputType getClaimOptions() {
        return claimOptions;
    }

    /**
     * Sets the value of the claimOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverClaimTermsDataInputType }
     *     
     */
    public void setClaimOptions(CoverClaimTermsDataInputType value) {
        this.claimOptions = value;
    }

    public boolean isSetClaimOptions() {
        return (this.claimOptions!= null);
    }

    /**
     * Gets the value of the instllmntBnftIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstllmntBnftIndic() {
        return instllmntBnftIndic;
    }

    /**
     * Sets the value of the instllmntBnftIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstllmntBnftIndic(String value) {
        this.instllmntBnftIndic = value;
    }

    public boolean isSetInstllmntBnftIndic() {
        return (this.instllmntBnftIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("claimOptions", claimOptions).add("instllmntBnftIndic", instllmntBnftIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, claimOptions, instllmntBnftIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SubscriptionCoverDataInputType o = ((SubscriptionCoverDataInputType) other);
        return ((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(claimOptions, o.claimOptions))&&Objects.equal(instllmntBnftIndic, o.instllmntBnftIndic));
    }

}
