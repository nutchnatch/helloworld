
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage specific information for savings
 * 				operation requests
 * 			
 * 
 * <p>Java class for SavingsOperationInputDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsOperationInputDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SignDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ReciptDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="OriginCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationOriginCode" minOccurs="0"/&gt;
 *         &lt;element name="DelgatnMndateIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="DistrbtnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionTypeCode" minOccurs="0"/&gt;
 *         &lt;element name="SpecificSwitchData" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="InDistrbtnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionTypeCode" minOccurs="0"/&gt;
 *                   &lt;element name="OutDistrbtnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionTypeCode" minOccurs="0"/&gt;
 *                   &lt;element name="NewDistrbtnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="OpeCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="GrossAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="NetAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="TaxationMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxationOptionTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AddAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AdditionalAmountType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SigndReqDocIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsOperationInputDataType", propOrder = {
    "signDate",
    "reciptDate",
    "originCode",
    "delgatnMndateIndic",
    "distrbtnType",
    "specificSwitchData",
    "opeCurr",
    "grossAmnt",
    "netAmnt",
    "taxationMode",
    "addAmnt",
    "signdReqDocIndic"
})
public class SavingsOperationInputDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SignDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date signDate;
    @XmlElement(name = "ReciptDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date reciptDate;
    @XmlElement(name = "OriginCode")
    protected String originCode;
    @XmlElement(name = "DelgatnMndateIndic")
    protected String delgatnMndateIndic;
    @XmlElement(name = "DistrbtnType")
    protected String distrbtnType;
    @XmlElement(name = "SpecificSwitchData")
    protected SavingsOperationInputDataType.SpecificSwitchData specificSwitchData;
    @XmlElement(name = "OpeCurr", required = true)
    protected String opeCurr;
    @XmlElement(name = "GrossAmnt")
    protected CurrencyAndAmountType grossAmnt;
    @XmlElement(name = "NetAmnt")
    protected CurrencyAndAmountType netAmnt;
    @XmlElement(name = "TaxationMode")
    protected String taxationMode;
    @XmlElement(name = "AddAmnt")
    protected List<AdditionalAmountType> addAmnt;
    @XmlElement(name = "SigndReqDocIndic")
    protected String signdReqDocIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsOperationInputDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsOperationInputDataType(final Date signDate, final Date reciptDate, final String originCode, final String delgatnMndateIndic, final String distrbtnType, final SavingsOperationInputDataType.SpecificSwitchData specificSwitchData, final String opeCurr, final CurrencyAndAmountType grossAmnt, final CurrencyAndAmountType netAmnt, final String taxationMode, final List<AdditionalAmountType> addAmnt, final String signdReqDocIndic) {
        this.signDate = signDate;
        this.reciptDate = reciptDate;
        this.originCode = originCode;
        this.delgatnMndateIndic = delgatnMndateIndic;
        this.distrbtnType = distrbtnType;
        this.specificSwitchData = specificSwitchData;
        this.opeCurr = opeCurr;
        this.grossAmnt = grossAmnt;
        this.netAmnt = netAmnt;
        this.taxationMode = taxationMode;
        this.addAmnt = addAmnt;
        this.signdReqDocIndic = signdReqDocIndic;
    }

    /**
     * Gets the value of the signDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSignDate() {
        return signDate;
    }

    /**
     * Sets the value of the signDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignDate(Date value) {
        this.signDate = value;
    }

    public boolean isSetSignDate() {
        return (this.signDate!= null);
    }

    /**
     * Gets the value of the reciptDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getReciptDate() {
        return reciptDate;
    }

    /**
     * Sets the value of the reciptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReciptDate(Date value) {
        this.reciptDate = value;
    }

    public boolean isSetReciptDate() {
        return (this.reciptDate!= null);
    }

    /**
     * Gets the value of the originCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginCode() {
        return originCode;
    }

    /**
     * Sets the value of the originCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginCode(String value) {
        this.originCode = value;
    }

    public boolean isSetOriginCode() {
        return (this.originCode!= null);
    }

    /**
     * Gets the value of the delgatnMndateIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelgatnMndateIndic() {
        return delgatnMndateIndic;
    }

    /**
     * Sets the value of the delgatnMndateIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelgatnMndateIndic(String value) {
        this.delgatnMndateIndic = value;
    }

    public boolean isSetDelgatnMndateIndic() {
        return (this.delgatnMndateIndic!= null);
    }

    /**
     * Gets the value of the distrbtnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistrbtnType() {
        return distrbtnType;
    }

    /**
     * Sets the value of the distrbtnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistrbtnType(String value) {
        this.distrbtnType = value;
    }

    public boolean isSetDistrbtnType() {
        return (this.distrbtnType!= null);
    }

    /**
     * Gets the value of the specificSwitchData property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsOperationInputDataType.SpecificSwitchData }
     *     
     */
    public SavingsOperationInputDataType.SpecificSwitchData getSpecificSwitchData() {
        return specificSwitchData;
    }

    /**
     * Sets the value of the specificSwitchData property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsOperationInputDataType.SpecificSwitchData }
     *     
     */
    public void setSpecificSwitchData(SavingsOperationInputDataType.SpecificSwitchData value) {
        this.specificSwitchData = value;
    }

    public boolean isSetSpecificSwitchData() {
        return (this.specificSwitchData!= null);
    }

    /**
     * Gets the value of the opeCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeCurr() {
        return opeCurr;
    }

    /**
     * Sets the value of the opeCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeCurr(String value) {
        this.opeCurr = value;
    }

    public boolean isSetOpeCurr() {
        return (this.opeCurr!= null);
    }

    /**
     * Gets the value of the grossAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getGrossAmnt() {
        return grossAmnt;
    }

    /**
     * Sets the value of the grossAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setGrossAmnt(CurrencyAndAmountType value) {
        this.grossAmnt = value;
    }

    public boolean isSetGrossAmnt() {
        return (this.grossAmnt!= null);
    }

    /**
     * Gets the value of the netAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getNetAmnt() {
        return netAmnt;
    }

    /**
     * Sets the value of the netAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setNetAmnt(CurrencyAndAmountType value) {
        this.netAmnt = value;
    }

    public boolean isSetNetAmnt() {
        return (this.netAmnt!= null);
    }

    /**
     * Gets the value of the taxationMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxationMode() {
        return taxationMode;
    }

    /**
     * Sets the value of the taxationMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxationMode(String value) {
        this.taxationMode = value;
    }

    public boolean isSetTaxationMode() {
        return (this.taxationMode!= null);
    }

    /**
     * Gets the value of the addAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmountType }
     * 
     * 
     */
    public List<AdditionalAmountType> getAddAmnt() {
        if (addAmnt == null) {
            addAmnt = new ArrayList<AdditionalAmountType>();
        }
        return this.addAmnt;
    }

    public boolean isSetAddAmnt() {
        return ((this.addAmnt!= null)&&(!this.addAmnt.isEmpty()));
    }

    public void unsetAddAmnt() {
        this.addAmnt = null;
    }

    /**
     * Gets the value of the signdReqDocIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSigndReqDocIndic() {
        return signdReqDocIndic;
    }

    /**
     * Sets the value of the signdReqDocIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSigndReqDocIndic(String value) {
        this.signdReqDocIndic = value;
    }

    public boolean isSetSigndReqDocIndic() {
        return (this.signdReqDocIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("signDate", signDate).add("reciptDate", reciptDate).add("originCode", originCode).add("delgatnMndateIndic", delgatnMndateIndic).add("distrbtnType", distrbtnType).add("specificSwitchData", specificSwitchData).add("opeCurr", opeCurr).add("grossAmnt", grossAmnt).add("netAmnt", netAmnt).add("taxationMode", taxationMode).add("addAmnt", addAmnt).add("signdReqDocIndic", signdReqDocIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(signDate, reciptDate, originCode, delgatnMndateIndic, distrbtnType, specificSwitchData, opeCurr, grossAmnt, netAmnt, taxationMode, addAmnt, signdReqDocIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsOperationInputDataType o = ((SavingsOperationInputDataType) other);
        return (((((((((((Objects.equal(signDate, o.signDate)&&Objects.equal(reciptDate, o.reciptDate))&&Objects.equal(originCode, o.originCode))&&Objects.equal(delgatnMndateIndic, o.delgatnMndateIndic))&&Objects.equal(distrbtnType, o.distrbtnType))&&Objects.equal(specificSwitchData, o.specificSwitchData))&&Objects.equal(opeCurr, o.opeCurr))&&Objects.equal(grossAmnt, o.grossAmnt))&&Objects.equal(netAmnt, o.netAmnt))&&Objects.equal(taxationMode, o.taxationMode))&&Objects.equal(addAmnt, o.addAmnt))&&Objects.equal(signdReqDocIndic, o.signdReqDocIndic));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="InDistrbtnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionTypeCode" minOccurs="0"/&gt;
     *         &lt;element name="OutDistrbtnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionTypeCode" minOccurs="0"/&gt;
     *         &lt;element name="NewDistrbtnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "inDistrbtnType",
        "outDistrbtnType",
        "newDistrbtnIndic"
    })
    public static class SpecificSwitchData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "InDistrbtnType")
        protected String inDistrbtnType;
        @XmlElement(name = "OutDistrbtnType")
        protected String outDistrbtnType;
        @XmlElement(name = "NewDistrbtnIndic")
        protected String newDistrbtnIndic;

        /**
         * Default no-arg constructor
         * 
         */
        public SpecificSwitchData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public SpecificSwitchData(final String inDistrbtnType, final String outDistrbtnType, final String newDistrbtnIndic) {
            this.inDistrbtnType = inDistrbtnType;
            this.outDistrbtnType = outDistrbtnType;
            this.newDistrbtnIndic = newDistrbtnIndic;
        }

        /**
         * Gets the value of the inDistrbtnType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getInDistrbtnType() {
            return inDistrbtnType;
        }

        /**
         * Sets the value of the inDistrbtnType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setInDistrbtnType(String value) {
            this.inDistrbtnType = value;
        }

        public boolean isSetInDistrbtnType() {
            return (this.inDistrbtnType!= null);
        }

        /**
         * Gets the value of the outDistrbtnType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOutDistrbtnType() {
            return outDistrbtnType;
        }

        /**
         * Sets the value of the outDistrbtnType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOutDistrbtnType(String value) {
            this.outDistrbtnType = value;
        }

        public boolean isSetOutDistrbtnType() {
            return (this.outDistrbtnType!= null);
        }

        /**
         * Gets the value of the newDistrbtnIndic property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNewDistrbtnIndic() {
            return newDistrbtnIndic;
        }

        /**
         * Sets the value of the newDistrbtnIndic property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNewDistrbtnIndic(String value) {
            this.newDistrbtnIndic = value;
        }

        public boolean isSetNewDistrbtnIndic() {
            return (this.newDistrbtnIndic!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("inDistrbtnType", inDistrbtnType).add("outDistrbtnType", outDistrbtnType).add("newDistrbtnIndic", newDistrbtnIndic).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(inDistrbtnType, outDistrbtnType, newDistrbtnIndic);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final SavingsOperationInputDataType.SpecificSwitchData o = ((SavingsOperationInputDataType.SpecificSwitchData) other);
            return ((Objects.equal(inDistrbtnType, o.inDistrbtnType)&&Objects.equal(outDistrbtnType, o.outDistrbtnType))&&Objects.equal(newDistrbtnIndic, o.newDistrbtnIndic));
        }

    }

}
