
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to define the options of claim benefit in the
 * 				protection policy
 * 			
 * 
 * <p>Java class for ProtectionPolicyClaimOptionsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyClaimOptionsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Ddctble" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DeductibleDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BnftPaymntOptCmplte" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="BnftPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyClaimOptionsDataType", propOrder = {
    "ddctble",
    "bnftPaymntOptCmplte",
    "bnftPrd"
})
public class ProtectionPolicyClaimOptionsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Ddctble")
    protected List<DeductibleDataType> ddctble;
    @XmlElement(name = "BnftPaymntOptCmplte")
    protected String bnftPaymntOptCmplte;
    @XmlElement(name = "BnftPrd")
    protected DurationType bnftPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyClaimOptionsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyClaimOptionsDataType(final List<DeductibleDataType> ddctble, final String bnftPaymntOptCmplte, final DurationType bnftPrd) {
        this.ddctble = ddctble;
        this.bnftPaymntOptCmplte = bnftPaymntOptCmplte;
        this.bnftPrd = bnftPrd;
    }

    /**
     * Gets the value of the ddctble property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ddctble property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDdctble().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DeductibleDataType }
     * 
     * 
     */
    public List<DeductibleDataType> getDdctble() {
        if (ddctble == null) {
            ddctble = new ArrayList<DeductibleDataType>();
        }
        return this.ddctble;
    }

    public boolean isSetDdctble() {
        return ((this.ddctble!= null)&&(!this.ddctble.isEmpty()));
    }

    public void unsetDdctble() {
        this.ddctble = null;
    }

    /**
     * Gets the value of the bnftPaymntOptCmplte property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBnftPaymntOptCmplte() {
        return bnftPaymntOptCmplte;
    }

    /**
     * Sets the value of the bnftPaymntOptCmplte property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBnftPaymntOptCmplte(String value) {
        this.bnftPaymntOptCmplte = value;
    }

    public boolean isSetBnftPaymntOptCmplte() {
        return (this.bnftPaymntOptCmplte!= null);
    }

    /**
     * Gets the value of the bnftPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getBnftPrd() {
        return bnftPrd;
    }

    /**
     * Sets the value of the bnftPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setBnftPrd(DurationType value) {
        this.bnftPrd = value;
    }

    public boolean isSetBnftPrd() {
        return (this.bnftPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("ddctble", ddctble).add("bnftPaymntOptCmplte", bnftPaymntOptCmplte).add("bnftPrd", bnftPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(ddctble, bnftPaymntOptCmplte, bnftPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyClaimOptionsDataType o = ((ProtectionPolicyClaimOptionsDataType) other);
        return ((Objects.equal(ddctble, o.ddctble)&&Objects.equal(bnftPaymntOptCmplte, o.bnftPaymntOptCmplte))&&Objects.equal(bnftPrd, o.bnftPrd));
    }

}
