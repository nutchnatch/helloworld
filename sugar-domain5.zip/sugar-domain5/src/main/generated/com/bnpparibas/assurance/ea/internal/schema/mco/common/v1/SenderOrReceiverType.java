
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on the sender or the
 * 				receiver of data
 * 			
 * 
 * <p>Java class for SenderOrReceiverType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SenderOrReceiverType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IssuerCodeSLN"/&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="CntryCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SenderOrReceiverType", propOrder = {
    "code",
    "name",
    "cntryCode"
})
public class SenderOrReceiverType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Code", required = true)
    protected String code;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "CntryCode", required = true)
    protected String cntryCode;

    /**
     * Default no-arg constructor
     * 
     */
    public SenderOrReceiverType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SenderOrReceiverType(final String code, final String name, final String cntryCode) {
        this.code = code;
        this.name = name;
        this.cntryCode = cntryCode;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    public boolean isSetCode() {
        return (this.code!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the cntryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCntryCode() {
        return cntryCode;
    }

    /**
     * Sets the value of the cntryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCntryCode(String value) {
        this.cntryCode = value;
    }

    public boolean isSetCntryCode() {
        return (this.cntryCode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("code", code).add("name", name).add("cntryCode", cntryCode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code, name, cntryCode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SenderOrReceiverType o = ((SenderOrReceiverType) other);
        return ((Objects.equal(code, o.code)&&Objects.equal(name, o.name))&&Objects.equal(cntryCode, o.cntryCode));
    }

}
