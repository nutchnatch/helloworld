
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Type to manage specific data for a savings policy
 * 				statement
 * 			
 * 
 * <p>Java class for SavingsPolicyStatementDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyStatementDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ValuatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="Curr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyStatementDataType", propOrder = {
    "valuatnDate",
    "curr"
})
public class SavingsPolicyStatementDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ValuatnDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date valuatnDate;
    @XmlElement(name = "Curr")
    protected String curr;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyStatementDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyStatementDataType(final Date valuatnDate, final String curr) {
        this.valuatnDate = valuatnDate;
        this.curr = curr;
    }

    /**
     * Gets the value of the valuatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValuatnDate() {
        return valuatnDate;
    }

    /**
     * Sets the value of the valuatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValuatnDate(Date value) {
        this.valuatnDate = value;
    }

    public boolean isSetValuatnDate() {
        return (this.valuatnDate!= null);
    }

    /**
     * Gets the value of the curr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurr() {
        return curr;
    }

    /**
     * Sets the value of the curr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurr(String value) {
        this.curr = value;
    }

    public boolean isSetCurr() {
        return (this.curr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("valuatnDate", valuatnDate).add("curr", curr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(valuatnDate, curr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyStatementDataType o = ((SavingsPolicyStatementDataType) other);
        return (Objects.equal(valuatnDate, o.valuatnDate)&&Objects.equal(curr, o.curr));
    }

}
