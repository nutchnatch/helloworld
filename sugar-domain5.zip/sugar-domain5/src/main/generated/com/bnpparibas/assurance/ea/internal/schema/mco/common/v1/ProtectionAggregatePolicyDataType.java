
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Données agrégés contrat
 * 				de prévoyance
 * 			
 * 
 * <p>Java class for ProtectionAggregatePolicyDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionAggregatePolicyDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ReprtngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="InsrdPop" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsrdPopStatDataType"/&gt;
 *         &lt;element name="PolStatstc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyStatDataType"/&gt;
 *         &lt;element name="Prem" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumStatDataType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Rsrve" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReserveStatDataType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionAggregatePolicyDataType", propOrder = {
    "reprtngPrd",
    "insrdPop",
    "polStatstc",
    "prem",
    "rsrve"
})
public class ProtectionAggregatePolicyDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ReprtngPrd")
    protected DatePeriodType reprtngPrd;
    @XmlElement(name = "InsrdPop", required = true)
    protected InsrdPopStatDataType insrdPop;
    @XmlElement(name = "PolStatstc", required = true)
    protected PolicyStatDataType polStatstc;
    @XmlElement(name = "Prem", required = true)
    protected List<PremiumStatDataType> prem;
    @XmlElement(name = "Rsrve", required = true)
    protected List<ReserveStatDataType> rsrve;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionAggregatePolicyDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionAggregatePolicyDataType(final DatePeriodType reprtngPrd, final InsrdPopStatDataType insrdPop, final PolicyStatDataType polStatstc, final List<PremiumStatDataType> prem, final List<ReserveStatDataType> rsrve) {
        this.reprtngPrd = reprtngPrd;
        this.insrdPop = insrdPop;
        this.polStatstc = polStatstc;
        this.prem = prem;
        this.rsrve = rsrve;
    }

    /**
     * Gets the value of the reprtngPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getReprtngPrd() {
        return reprtngPrd;
    }

    /**
     * Sets the value of the reprtngPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setReprtngPrd(DatePeriodType value) {
        this.reprtngPrd = value;
    }

    public boolean isSetReprtngPrd() {
        return (this.reprtngPrd!= null);
    }

    /**
     * Gets the value of the insrdPop property.
     * 
     * @return
     *     possible object is
     *     {@link InsrdPopStatDataType }
     *     
     */
    public InsrdPopStatDataType getInsrdPop() {
        return insrdPop;
    }

    /**
     * Sets the value of the insrdPop property.
     * 
     * @param value
     *     allowed object is
     *     {@link InsrdPopStatDataType }
     *     
     */
    public void setInsrdPop(InsrdPopStatDataType value) {
        this.insrdPop = value;
    }

    public boolean isSetInsrdPop() {
        return (this.insrdPop!= null);
    }

    /**
     * Gets the value of the polStatstc property.
     * 
     * @return
     *     possible object is
     *     {@link PolicyStatDataType }
     *     
     */
    public PolicyStatDataType getPolStatstc() {
        return polStatstc;
    }

    /**
     * Sets the value of the polStatstc property.
     * 
     * @param value
     *     allowed object is
     *     {@link PolicyStatDataType }
     *     
     */
    public void setPolStatstc(PolicyStatDataType value) {
        this.polStatstc = value;
    }

    public boolean isSetPolStatstc() {
        return (this.polStatstc!= null);
    }

    /**
     * Gets the value of the prem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the prem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PremiumStatDataType }
     * 
     * 
     */
    public List<PremiumStatDataType> getPrem() {
        if (prem == null) {
            prem = new ArrayList<PremiumStatDataType>();
        }
        return this.prem;
    }

    public boolean isSetPrem() {
        return ((this.prem!= null)&&(!this.prem.isEmpty()));
    }

    public void unsetPrem() {
        this.prem = null;
    }

    /**
     * Gets the value of the rsrve property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rsrve property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRsrve().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReserveStatDataType }
     * 
     * 
     */
    public List<ReserveStatDataType> getRsrve() {
        if (rsrve == null) {
            rsrve = new ArrayList<ReserveStatDataType>();
        }
        return this.rsrve;
    }

    public boolean isSetRsrve() {
        return ((this.rsrve!= null)&&(!this.rsrve.isEmpty()));
    }

    public void unsetRsrve() {
        this.rsrve = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("reprtngPrd", reprtngPrd).add("insrdPop", insrdPop).add("polStatstc", polStatstc).add("prem", prem).add("rsrve", rsrve).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(reprtngPrd, insrdPop, polStatstc, prem, rsrve);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionAggregatePolicyDataType o = ((ProtectionAggregatePolicyDataType) other);
        return ((((Objects.equal(reprtngPrd, o.reprtngPrd)&&Objects.equal(insrdPop, o.insrdPop))&&Objects.equal(polStatstc, o.polStatstc))&&Objects.equal(prem, o.prem))&&Objects.equal(rsrve, o.rsrve));
    }

}
