
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Réduction/majoration
 * 				appliqués aux garanties souscrites (selon critère objectif sur
 * 				l'assuré)
 * 			
 * 
 * <p>Java class for ProtectionPolicyCoverSurchrgOrDiscntType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyCoverSurchrgOrDiscntType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SurchrgOrDscntRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *         &lt;element name="SurchrgOrDscntMotiv" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReductionMajorationReasonCodeFRSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyCoverSurchrgOrDiscntType", propOrder = {
    "surchrgOrDscntRate",
    "surchrgOrDscntMotiv"
})
public class ProtectionPolicyCoverSurchrgOrDiscntType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SurchrgOrDscntRate")
    protected BasisRateType surchrgOrDscntRate;
    @XmlElement(name = "SurchrgOrDscntMotiv")
    protected String surchrgOrDscntMotiv;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyCoverSurchrgOrDiscntType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyCoverSurchrgOrDiscntType(final BasisRateType surchrgOrDscntRate, final String surchrgOrDscntMotiv) {
        this.surchrgOrDscntRate = surchrgOrDscntRate;
        this.surchrgOrDscntMotiv = surchrgOrDscntMotiv;
    }

    /**
     * Gets the value of the surchrgOrDscntRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getSurchrgOrDscntRate() {
        return surchrgOrDscntRate;
    }

    /**
     * Sets the value of the surchrgOrDscntRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setSurchrgOrDscntRate(BasisRateType value) {
        this.surchrgOrDscntRate = value;
    }

    public boolean isSetSurchrgOrDscntRate() {
        return (this.surchrgOrDscntRate!= null);
    }

    /**
     * Gets the value of the surchrgOrDscntMotiv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurchrgOrDscntMotiv() {
        return surchrgOrDscntMotiv;
    }

    /**
     * Sets the value of the surchrgOrDscntMotiv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurchrgOrDscntMotiv(String value) {
        this.surchrgOrDscntMotiv = value;
    }

    public boolean isSetSurchrgOrDscntMotiv() {
        return (this.surchrgOrDscntMotiv!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("surchrgOrDscntRate", surchrgOrDscntRate).add("surchrgOrDscntMotiv", surchrgOrDscntMotiv).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(surchrgOrDscntRate, surchrgOrDscntMotiv);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyCoverSurchrgOrDiscntType o = ((ProtectionPolicyCoverSurchrgOrDiscntType) other);
        return (Objects.equal(surchrgOrDscntRate, o.surchrgOrDscntRate)&&Objects.equal(surchrgOrDscntMotiv, o.surchrgOrDscntMotiv));
    }

}
