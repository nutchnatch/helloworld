
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage link beteween parties
 * 			
 * 
 * <p>Java class for ThirdPartyLinkType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThirdPartyLinkType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PersonLinkTypeCode"/&gt;
 *         &lt;element name="LinkdPrtyIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="StartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="EndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThirdPartyLinkType", propOrder = {
    "type",
    "linkdPrtyIdntfctn",
    "startDate",
    "endDate"
})
public class ThirdPartyLinkType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "LinkdPrtyIdntfctn", required = true)
    protected ObjectIdentificationType linkdPrtyIdntfctn;
    @XmlElement(name = "StartDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date startDate;
    @XmlElement(name = "EndDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date endDate;

    /**
     * Default no-arg constructor
     * 
     */
    public ThirdPartyLinkType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ThirdPartyLinkType(final String type, final ObjectIdentificationType linkdPrtyIdntfctn, final Date startDate, final Date endDate) {
        this.type = type;
        this.linkdPrtyIdntfctn = linkdPrtyIdntfctn;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the linkdPrtyIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getLinkdPrtyIdntfctn() {
        return linkdPrtyIdntfctn;
    }

    /**
     * Sets the value of the linkdPrtyIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setLinkdPrtyIdntfctn(ObjectIdentificationType value) {
        this.linkdPrtyIdntfctn = value;
    }

    public boolean isSetLinkdPrtyIdntfctn() {
        return (this.linkdPrtyIdntfctn!= null);
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDate(Date value) {
        this.startDate = value;
    }

    public boolean isSetStartDate() {
        return (this.startDate!= null);
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDate(Date value) {
        this.endDate = value;
    }

    public boolean isSetEndDate() {
        return (this.endDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("linkdPrtyIdntfctn", linkdPrtyIdntfctn).add("startDate", startDate).add("endDate", endDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, linkdPrtyIdntfctn, startDate, endDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ThirdPartyLinkType o = ((ThirdPartyLinkType) other);
        return (((Objects.equal(type, o.type)&&Objects.equal(linkdPrtyIdntfctn, o.linkdPrtyIdntfctn))&&Objects.equal(startDate, o.startDate))&&Objects.equal(endDate, o.endDate));
    }

}
