
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ValdtyCode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ValdtyCode"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="VALID"/&gt;
 *     &lt;enumeration value="INVALID"/&gt;
 *     &lt;enumeration value="UNDER_CONSTRUCTION"/&gt;
 *     &lt;enumeration value="NOT_APPLICABLE"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ValdtyCode")
@XmlEnum
public enum ValdtyCode {

    VALID,
    INVALID,
    UNDER_CONSTRUCTION,
    NOT_APPLICABLE;

    public String value() {
        return name();
    }

    public static ValdtyCode fromValue(String v) {
        return valueOf(v);
    }

}
