
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Premium recovery scheme for the due premiums
 * 			
 * 
 * <p>Java class for PremiumRecoverySchemeDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PremiumRecoverySchemeDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RefDateType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReferenceDateTypeCodeSLN"/&gt;
 *         &lt;element name="ExctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="ActnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OutstandingPremiumCollectionPatternCodeSLN" maxOccurs="unbounded"/&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PremiumRecoverySchemeDataType", propOrder = {
    "refDateType",
    "exctnPrd",
    "actnType",
    "applctnPrd"
})
public class PremiumRecoverySchemeDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "RefDateType", required = true)
    protected String refDateType;
    @XmlElement(name = "ExctnPrd")
    protected DurationType exctnPrd;
    @XmlElement(name = "ActnType", required = true)
    protected List<String> actnType;
    @XmlElement(name = "ApplctnPrd")
    protected DatePeriodType applctnPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public PremiumRecoverySchemeDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PremiumRecoverySchemeDataType(final String refDateType, final DurationType exctnPrd, final List<String> actnType, final DatePeriodType applctnPrd) {
        this.refDateType = refDateType;
        this.exctnPrd = exctnPrd;
        this.actnType = actnType;
        this.applctnPrd = applctnPrd;
    }

    /**
     * Gets the value of the refDateType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefDateType() {
        return refDateType;
    }

    /**
     * Sets the value of the refDateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefDateType(String value) {
        this.refDateType = value;
    }

    public boolean isSetRefDateType() {
        return (this.refDateType!= null);
    }

    /**
     * Gets the value of the exctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getExctnPrd() {
        return exctnPrd;
    }

    /**
     * Sets the value of the exctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setExctnPrd(DurationType value) {
        this.exctnPrd = value;
    }

    public boolean isSetExctnPrd() {
        return (this.exctnPrd!= null);
    }

    /**
     * Gets the value of the actnType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actnType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActnType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getActnType() {
        if (actnType == null) {
            actnType = new ArrayList<String>();
        }
        return this.actnType;
    }

    public boolean isSetActnType() {
        return ((this.actnType!= null)&&(!this.actnType.isEmpty()));
    }

    public void unsetActnType() {
        this.actnType = null;
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("refDateType", refDateType).add("exctnPrd", exctnPrd).add("actnType", actnType).add("applctnPrd", applctnPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(refDateType, exctnPrd, actnType, applctnPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PremiumRecoverySchemeDataType o = ((PremiumRecoverySchemeDataType) other);
        return (((Objects.equal(refDateType, o.refDateType)&&Objects.equal(exctnPrd, o.exctnPrd))&&Objects.equal(actnType, o.actnType))&&Objects.equal(applctnPrd, o.applctnPrd));
    }

}
