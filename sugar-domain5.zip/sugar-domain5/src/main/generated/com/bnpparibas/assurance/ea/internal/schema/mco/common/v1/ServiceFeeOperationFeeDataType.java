
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * To manage global data of the service fee operation
 * 			
 * 
 * <p>Java class for ServiceFeeOperationFeeDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceFeeOperationFeeDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ExpectPaymntDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="FeeCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="GrossAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="NetAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="ServiceType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ServiceTypeCode"/&gt;
 *         &lt;element name="ServDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="ServPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MandatoryDateTimePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="AddAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AdditionalAmountType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceFeeOperationFeeDataType", propOrder = {
    "expectPaymntDate",
    "feeCurr",
    "grossAmnt",
    "netAmnt",
    "serviceType",
    "servDuratn",
    "servPrd",
    "addAmnt"
})
public class ServiceFeeOperationFeeDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ExpectPaymntDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date expectPaymntDate;
    @XmlElement(name = "FeeCurr", required = true)
    protected String feeCurr;
    @XmlElement(name = "GrossAmnt", required = true)
    protected CurrencyAndAmountType grossAmnt;
    @XmlElement(name = "NetAmnt")
    protected CurrencyAndAmountType netAmnt;
    @XmlElement(name = "ServiceType", required = true)
    protected String serviceType;
    @XmlElement(name = "ServDuratn")
    protected DurationType servDuratn;
    @XmlElement(name = "ServPrd")
    protected MandatoryDateTimePeriodType servPrd;
    @XmlElement(name = "AddAmnt")
    protected List<AdditionalAmountType> addAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public ServiceFeeOperationFeeDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ServiceFeeOperationFeeDataType(final Date expectPaymntDate, final String feeCurr, final CurrencyAndAmountType grossAmnt, final CurrencyAndAmountType netAmnt, final String serviceType, final DurationType servDuratn, final MandatoryDateTimePeriodType servPrd, final List<AdditionalAmountType> addAmnt) {
        this.expectPaymntDate = expectPaymntDate;
        this.feeCurr = feeCurr;
        this.grossAmnt = grossAmnt;
        this.netAmnt = netAmnt;
        this.serviceType = serviceType;
        this.servDuratn = servDuratn;
        this.servPrd = servPrd;
        this.addAmnt = addAmnt;
    }

    /**
     * Gets the value of the expectPaymntDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getExpectPaymntDate() {
        return expectPaymntDate;
    }

    /**
     * Sets the value of the expectPaymntDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpectPaymntDate(Date value) {
        this.expectPaymntDate = value;
    }

    public boolean isSetExpectPaymntDate() {
        return (this.expectPaymntDate!= null);
    }

    /**
     * Gets the value of the feeCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeeCurr() {
        return feeCurr;
    }

    /**
     * Sets the value of the feeCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeeCurr(String value) {
        this.feeCurr = value;
    }

    public boolean isSetFeeCurr() {
        return (this.feeCurr!= null);
    }

    /**
     * Gets the value of the grossAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getGrossAmnt() {
        return grossAmnt;
    }

    /**
     * Sets the value of the grossAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setGrossAmnt(CurrencyAndAmountType value) {
        this.grossAmnt = value;
    }

    public boolean isSetGrossAmnt() {
        return (this.grossAmnt!= null);
    }

    /**
     * Gets the value of the netAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getNetAmnt() {
        return netAmnt;
    }

    /**
     * Sets the value of the netAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setNetAmnt(CurrencyAndAmountType value) {
        this.netAmnt = value;
    }

    public boolean isSetNetAmnt() {
        return (this.netAmnt!= null);
    }

    /**
     * Gets the value of the serviceType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceType() {
        return serviceType;
    }

    /**
     * Sets the value of the serviceType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceType(String value) {
        this.serviceType = value;
    }

    public boolean isSetServiceType() {
        return (this.serviceType!= null);
    }

    /**
     * Gets the value of the servDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getServDuratn() {
        return servDuratn;
    }

    /**
     * Sets the value of the servDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setServDuratn(DurationType value) {
        this.servDuratn = value;
    }

    public boolean isSetServDuratn() {
        return (this.servDuratn!= null);
    }

    /**
     * Gets the value of the servPrd property.
     * 
     * @return
     *     possible object is
     *     {@link MandatoryDateTimePeriodType }
     *     
     */
    public MandatoryDateTimePeriodType getServPrd() {
        return servPrd;
    }

    /**
     * Sets the value of the servPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link MandatoryDateTimePeriodType }
     *     
     */
    public void setServPrd(MandatoryDateTimePeriodType value) {
        this.servPrd = value;
    }

    public boolean isSetServPrd() {
        return (this.servPrd!= null);
    }

    /**
     * Gets the value of the addAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmountType }
     * 
     * 
     */
    public List<AdditionalAmountType> getAddAmnt() {
        if (addAmnt == null) {
            addAmnt = new ArrayList<AdditionalAmountType>();
        }
        return this.addAmnt;
    }

    public boolean isSetAddAmnt() {
        return ((this.addAmnt!= null)&&(!this.addAmnt.isEmpty()));
    }

    public void unsetAddAmnt() {
        this.addAmnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("expectPaymntDate", expectPaymntDate).add("feeCurr", feeCurr).add("grossAmnt", grossAmnt).add("netAmnt", netAmnt).add("serviceType", serviceType).add("servDuratn", servDuratn).add("servPrd", servPrd).add("addAmnt", addAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(expectPaymntDate, feeCurr, grossAmnt, netAmnt, serviceType, servDuratn, servPrd, addAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ServiceFeeOperationFeeDataType o = ((ServiceFeeOperationFeeDataType) other);
        return (((((((Objects.equal(expectPaymntDate, o.expectPaymntDate)&&Objects.equal(feeCurr, o.feeCurr))&&Objects.equal(grossAmnt, o.grossAmnt))&&Objects.equal(netAmnt, o.netAmnt))&&Objects.equal(serviceType, o.serviceType))&&Objects.equal(servDuratn, o.servDuratn))&&Objects.equal(servPrd, o.servPrd))&&Objects.equal(addAmnt, o.addAmnt));
    }

}
