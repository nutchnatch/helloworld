
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to calculate fees from the premium amount
 * 			
 * 
 * <p>Java class for ProtectionPremiumFeesCalculationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPremiumFeesCalculationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FeeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeesCodeSLN"/&gt;
 *         &lt;element name="FeeRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *         &lt;element name="BasisAmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumBasisFeesTypeCodeSLN"/&gt;
 *         &lt;element name="FixdBasisAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPremiumFeesCalculationDataType", propOrder = {
    "feeType",
    "feeRate",
    "basisAmntType",
    "fixdBasisAmnt"
})
public class ProtectionPremiumFeesCalculationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FeeType", required = true)
    protected String feeType;
    @XmlElement(name = "FeeRate", required = true)
    protected BasisRateType feeRate;
    @XmlElement(name = "BasisAmntType", required = true)
    protected String basisAmntType;
    @XmlElement(name = "FixdBasisAmnt")
    protected CurrencyAndAmountType fixdBasisAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPremiumFeesCalculationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPremiumFeesCalculationDataType(final String feeType, final BasisRateType feeRate, final String basisAmntType, final CurrencyAndAmountType fixdBasisAmnt) {
        this.feeType = feeType;
        this.feeRate = feeRate;
        this.basisAmntType = basisAmntType;
        this.fixdBasisAmnt = fixdBasisAmnt;
    }

    /**
     * Gets the value of the feeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeeType() {
        return feeType;
    }

    /**
     * Sets the value of the feeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeeType(String value) {
        this.feeType = value;
    }

    public boolean isSetFeeType() {
        return (this.feeType!= null);
    }

    /**
     * Gets the value of the feeRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getFeeRate() {
        return feeRate;
    }

    /**
     * Sets the value of the feeRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setFeeRate(BasisRateType value) {
        this.feeRate = value;
    }

    public boolean isSetFeeRate() {
        return (this.feeRate!= null);
    }

    /**
     * Gets the value of the basisAmntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasisAmntType() {
        return basisAmntType;
    }

    /**
     * Sets the value of the basisAmntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasisAmntType(String value) {
        this.basisAmntType = value;
    }

    public boolean isSetBasisAmntType() {
        return (this.basisAmntType!= null);
    }

    /**
     * Gets the value of the fixdBasisAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFixdBasisAmnt() {
        return fixdBasisAmnt;
    }

    /**
     * Sets the value of the fixdBasisAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFixdBasisAmnt(CurrencyAndAmountType value) {
        this.fixdBasisAmnt = value;
    }

    public boolean isSetFixdBasisAmnt() {
        return (this.fixdBasisAmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("feeType", feeType).add("feeRate", feeRate).add("basisAmntType", basisAmntType).add("fixdBasisAmnt", fixdBasisAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(feeType, feeRate, basisAmntType, fixdBasisAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPremiumFeesCalculationDataType o = ((ProtectionPremiumFeesCalculationDataType) other);
        return (((Objects.equal(feeType, o.feeType)&&Objects.equal(feeRate, o.feeRate))&&Objects.equal(basisAmntType, o.basisAmntType))&&Objects.equal(fixdBasisAmnt, o.fixdBasisAmnt));
    }

}
