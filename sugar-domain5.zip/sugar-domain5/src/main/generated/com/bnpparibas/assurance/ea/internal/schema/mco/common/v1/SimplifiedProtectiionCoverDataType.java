
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage dat of protection cover linked to a
 * 				simplified protection prioduct
 * 			
 * 
 * <p>Java class for SimplifiedProtectiionCoverDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SimplifiedProtectiionCoverDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *                   &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode"/&gt;
 *                   &lt;element name="LifeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LifeIndicatorCodeSLN"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Data"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *                   &lt;element name="MarktngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *                   &lt;element name="MndtryIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *                   &lt;element name="InsrdEntryMaxAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ClaimTerms" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="WaitngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *                   &lt;element name="BnftMaxPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *                   &lt;element name="MaxBnftAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *                   &lt;element name="Ddctble" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DeductibleTypeCodeSLN"/&gt;
 *                             &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="LoanBnftTerms" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="InstllmntMaxNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *                             &lt;element name="InstllmntRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *                             &lt;element name="SurndrPnlty" minOccurs="0"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *                                       &lt;element name="FixAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Bnft" maxOccurs="unbounded" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitModeCodeSLN"/&gt;
 *                             &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="RvsbltyTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumOrBenefitRevisabilityTermsDataType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Prem" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="SngleIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN"/&gt;
 *                   &lt;element name="AuthrzdPaymntFqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                   &lt;element name="RvsbltyTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumOrBenefitRevisabilityTermsDataType" minOccurs="0"/&gt;
 *                   &lt;element name="CalctnTerms" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="CalctnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountCalculationRuleTypeCodeSLN"/&gt;
 *                             &lt;element name="Basis" maxOccurs="unbounded" minOccurs="0"&gt;
 *                               &lt;complexType&gt;
 *                                 &lt;complexContent&gt;
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                     &lt;sequence&gt;
 *                                       &lt;element name="AgeIntrvl" minOccurs="0"&gt;
 *                                         &lt;complexType&gt;
 *                                           &lt;complexContent&gt;
 *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                               &lt;sequence&gt;
 *                                                 &lt;element name="LowrLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
 *                                                 &lt;element name="UpprLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
 *                                               &lt;/sequence&gt;
 *                                             &lt;/restriction&gt;
 *                                           &lt;/complexContent&gt;
 *                                         &lt;/complexType&gt;
 *                                       &lt;/element&gt;
 *                                       &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *                                       &lt;element name="InitAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                                       &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
 *                                     &lt;/sequence&gt;
 *                                   &lt;/restriction&gt;
 *                                 &lt;/complexContent&gt;
 *                               &lt;/complexType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="FixdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="RfndBasisAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Fee" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="FeeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeesCodeSLN"/&gt;
 *                   &lt;element name="CalctnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountCalculationRuleTypeCodeSLN"/&gt;
 *                   &lt;element name="Basis" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *                             &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="FixdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SimplifiedProtectiionCoverDataType", propOrder = {
    "idntfctn",
    "data",
    "claimTerms",
    "prem",
    "fee"
})
public class SimplifiedProtectiionCoverDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn", required = true)
    protected SimplifiedProtectiionCoverDataType.Idntfctn idntfctn;
    @XmlElement(name = "Data", required = true)
    protected SimplifiedProtectiionCoverDataType.Data data;
    @XmlElement(name = "ClaimTerms")
    protected SimplifiedProtectiionCoverDataType.ClaimTerms claimTerms;
    @XmlElement(name = "Prem")
    protected SimplifiedProtectiionCoverDataType.Prem prem;
    @XmlElement(name = "Fee")
    protected List<SimplifiedProtectiionCoverDataType.Fee> fee;

    /**
     * Default no-arg constructor
     * 
     */
    public SimplifiedProtectiionCoverDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SimplifiedProtectiionCoverDataType(final SimplifiedProtectiionCoverDataType.Idntfctn idntfctn, final SimplifiedProtectiionCoverDataType.Data data, final SimplifiedProtectiionCoverDataType.ClaimTerms claimTerms, final SimplifiedProtectiionCoverDataType.Prem prem, final List<SimplifiedProtectiionCoverDataType.Fee> fee) {
        this.idntfctn = idntfctn;
        this.data = data;
        this.claimTerms = claimTerms;
        this.prem = prem;
        this.fee = fee;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link SimplifiedProtectiionCoverDataType.Idntfctn }
     *     
     */
    public SimplifiedProtectiionCoverDataType.Idntfctn getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link SimplifiedProtectiionCoverDataType.Idntfctn }
     *     
     */
    public void setIdntfctn(SimplifiedProtectiionCoverDataType.Idntfctn value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link SimplifiedProtectiionCoverDataType.Data }
     *     
     */
    public SimplifiedProtectiionCoverDataType.Data getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link SimplifiedProtectiionCoverDataType.Data }
     *     
     */
    public void setData(SimplifiedProtectiionCoverDataType.Data value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the claimTerms property.
     * 
     * @return
     *     possible object is
     *     {@link SimplifiedProtectiionCoverDataType.ClaimTerms }
     *     
     */
    public SimplifiedProtectiionCoverDataType.ClaimTerms getClaimTerms() {
        return claimTerms;
    }

    /**
     * Sets the value of the claimTerms property.
     * 
     * @param value
     *     allowed object is
     *     {@link SimplifiedProtectiionCoverDataType.ClaimTerms }
     *     
     */
    public void setClaimTerms(SimplifiedProtectiionCoverDataType.ClaimTerms value) {
        this.claimTerms = value;
    }

    public boolean isSetClaimTerms() {
        return (this.claimTerms!= null);
    }

    /**
     * Gets the value of the prem property.
     * 
     * @return
     *     possible object is
     *     {@link SimplifiedProtectiionCoverDataType.Prem }
     *     
     */
    public SimplifiedProtectiionCoverDataType.Prem getPrem() {
        return prem;
    }

    /**
     * Sets the value of the prem property.
     * 
     * @param value
     *     allowed object is
     *     {@link SimplifiedProtectiionCoverDataType.Prem }
     *     
     */
    public void setPrem(SimplifiedProtectiionCoverDataType.Prem value) {
        this.prem = value;
    }

    public boolean isSetPrem() {
        return (this.prem!= null);
    }

    /**
     * Gets the value of the fee property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fee property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFee().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SimplifiedProtectiionCoverDataType.Fee }
     * 
     * 
     */
    public List<SimplifiedProtectiionCoverDataType.Fee> getFee() {
        if (fee == null) {
            fee = new ArrayList<SimplifiedProtectiionCoverDataType.Fee>();
        }
        return this.fee;
    }

    public boolean isSetFee() {
        return ((this.fee!= null)&&(!this.fee.isEmpty()));
    }

    public void unsetFee() {
        this.fee = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("data", data).add("claimTerms", claimTerms).add("prem", prem).add("fee", fee).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, data, claimTerms, prem, fee);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SimplifiedProtectiionCoverDataType o = ((SimplifiedProtectiionCoverDataType) other);
        return ((((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(data, o.data))&&Objects.equal(claimTerms, o.claimTerms))&&Objects.equal(prem, o.prem))&&Objects.equal(fee, o.fee));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="WaitngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
     *         &lt;element name="BnftMaxPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
     *         &lt;element name="MaxBnftAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
     *         &lt;element name="Ddctble" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DeductibleTypeCodeSLN"/&gt;
     *                   &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="LoanBnftTerms" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="InstllmntMaxNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
     *                   &lt;element name="InstllmntRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
     *                   &lt;element name="SurndrPnlty" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
     *                             &lt;element name="FixAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Bnft" maxOccurs="unbounded" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitModeCodeSLN"/&gt;
     *                   &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="RvsbltyTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumOrBenefitRevisabilityTermsDataType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "waitngPrd",
        "bnftMaxPrd",
        "maxBnftAge",
        "ddctble",
        "loanBnftTerms",
        "bnft",
        "rvsbltyTerms"
    })
    public static class ClaimTerms implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "WaitngPrd")
        protected DurationType waitngPrd;
        @XmlElement(name = "BnftMaxPrd")
        protected DurationType bnftMaxPrd;
        @XmlElement(name = "MaxBnftAge")
        protected BigInteger maxBnftAge;
        @XmlElement(name = "Ddctble")
        protected SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble ddctble;
        @XmlElement(name = "LoanBnftTerms")
        protected SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms loanBnftTerms;
        @XmlElement(name = "Bnft")
        protected List<SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft> bnft;
        @XmlElement(name = "RvsbltyTerms")
        protected PremiumOrBenefitRevisabilityTermsDataType rvsbltyTerms;

        /**
         * Default no-arg constructor
         * 
         */
        public ClaimTerms() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public ClaimTerms(final DurationType waitngPrd, final DurationType bnftMaxPrd, final BigInteger maxBnftAge, final SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble ddctble, final SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms loanBnftTerms, final List<SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft> bnft, final PremiumOrBenefitRevisabilityTermsDataType rvsbltyTerms) {
            this.waitngPrd = waitngPrd;
            this.bnftMaxPrd = bnftMaxPrd;
            this.maxBnftAge = maxBnftAge;
            this.ddctble = ddctble;
            this.loanBnftTerms = loanBnftTerms;
            this.bnft = bnft;
            this.rvsbltyTerms = rvsbltyTerms;
        }

        /**
         * Gets the value of the waitngPrd property.
         * 
         * @return
         *     possible object is
         *     {@link DurationType }
         *     
         */
        public DurationType getWaitngPrd() {
            return waitngPrd;
        }

        /**
         * Sets the value of the waitngPrd property.
         * 
         * @param value
         *     allowed object is
         *     {@link DurationType }
         *     
         */
        public void setWaitngPrd(DurationType value) {
            this.waitngPrd = value;
        }

        public boolean isSetWaitngPrd() {
            return (this.waitngPrd!= null);
        }

        /**
         * Gets the value of the bnftMaxPrd property.
         * 
         * @return
         *     possible object is
         *     {@link DurationType }
         *     
         */
        public DurationType getBnftMaxPrd() {
            return bnftMaxPrd;
        }

        /**
         * Sets the value of the bnftMaxPrd property.
         * 
         * @param value
         *     allowed object is
         *     {@link DurationType }
         *     
         */
        public void setBnftMaxPrd(DurationType value) {
            this.bnftMaxPrd = value;
        }

        public boolean isSetBnftMaxPrd() {
            return (this.bnftMaxPrd!= null);
        }

        /**
         * Gets the value of the maxBnftAge property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getMaxBnftAge() {
            return maxBnftAge;
        }

        /**
         * Sets the value of the maxBnftAge property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setMaxBnftAge(BigInteger value) {
            this.maxBnftAge = value;
        }

        public boolean isSetMaxBnftAge() {
            return (this.maxBnftAge!= null);
        }

        /**
         * Gets the value of the ddctble property.
         * 
         * @return
         *     possible object is
         *     {@link SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble }
         *     
         */
        public SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble getDdctble() {
            return ddctble;
        }

        /**
         * Sets the value of the ddctble property.
         * 
         * @param value
         *     allowed object is
         *     {@link SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble }
         *     
         */
        public void setDdctble(SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble value) {
            this.ddctble = value;
        }

        public boolean isSetDdctble() {
            return (this.ddctble!= null);
        }

        /**
         * Gets the value of the loanBnftTerms property.
         * 
         * @return
         *     possible object is
         *     {@link SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms }
         *     
         */
        public SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms getLoanBnftTerms() {
            return loanBnftTerms;
        }

        /**
         * Sets the value of the loanBnftTerms property.
         * 
         * @param value
         *     allowed object is
         *     {@link SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms }
         *     
         */
        public void setLoanBnftTerms(SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms value) {
            this.loanBnftTerms = value;
        }

        public boolean isSetLoanBnftTerms() {
            return (this.loanBnftTerms!= null);
        }

        /**
         * Gets the value of the bnft property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the bnft property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getBnft().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft }
         * 
         * 
         */
        public List<SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft> getBnft() {
            if (bnft == null) {
                bnft = new ArrayList<SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft>();
            }
            return this.bnft;
        }

        public boolean isSetBnft() {
            return ((this.bnft!= null)&&(!this.bnft.isEmpty()));
        }

        public void unsetBnft() {
            this.bnft = null;
        }

        /**
         * Gets the value of the rvsbltyTerms property.
         * 
         * @return
         *     possible object is
         *     {@link PremiumOrBenefitRevisabilityTermsDataType }
         *     
         */
        public PremiumOrBenefitRevisabilityTermsDataType getRvsbltyTerms() {
            return rvsbltyTerms;
        }

        /**
         * Sets the value of the rvsbltyTerms property.
         * 
         * @param value
         *     allowed object is
         *     {@link PremiumOrBenefitRevisabilityTermsDataType }
         *     
         */
        public void setRvsbltyTerms(PremiumOrBenefitRevisabilityTermsDataType value) {
            this.rvsbltyTerms = value;
        }

        public boolean isSetRvsbltyTerms() {
            return (this.rvsbltyTerms!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("waitngPrd", waitngPrd).add("bnftMaxPrd", bnftMaxPrd).add("maxBnftAge", maxBnftAge).add("ddctble", ddctble).add("loanBnftTerms", loanBnftTerms).add("bnft", bnft).add("rvsbltyTerms", rvsbltyTerms).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(waitngPrd, bnftMaxPrd, maxBnftAge, ddctble, loanBnftTerms, bnft, rvsbltyTerms);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final SimplifiedProtectiionCoverDataType.ClaimTerms o = ((SimplifiedProtectiionCoverDataType.ClaimTerms) other);
            return ((((((Objects.equal(waitngPrd, o.waitngPrd)&&Objects.equal(bnftMaxPrd, o.bnftMaxPrd))&&Objects.equal(maxBnftAge, o.maxBnftAge))&&Objects.equal(ddctble, o.ddctble))&&Objects.equal(loanBnftTerms, o.loanBnftTerms))&&Objects.equal(bnft, o.bnft))&&Objects.equal(rvsbltyTerms, o.rvsbltyTerms));
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitModeCodeSLN"/&gt;
         *         &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "type",
            "prd"
        })
        public static class Bnft implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Type", required = true)
            protected String type;
            @XmlElement(name = "Prd")
            protected DatePeriodType prd;

            /**
             * Default no-arg constructor
             * 
             */
            public Bnft() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public Bnft(final String type, final DatePeriodType prd) {
                this.type = type;
                this.prd = prd;
            }

            /**
             * Gets the value of the type property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getType() {
                return type;
            }

            /**
             * Sets the value of the type property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setType(String value) {
                this.type = value;
            }

            public boolean isSetType() {
                return (this.type!= null);
            }

            /**
             * Gets the value of the prd property.
             * 
             * @return
             *     possible object is
             *     {@link DatePeriodType }
             *     
             */
            public DatePeriodType getPrd() {
                return prd;
            }

            /**
             * Sets the value of the prd property.
             * 
             * @param value
             *     allowed object is
             *     {@link DatePeriodType }
             *     
             */
            public void setPrd(DatePeriodType value) {
                this.prd = value;
            }

            public boolean isSetPrd() {
                return (this.prd!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("type", type).add("prd", prd).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(type, prd);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft o = ((SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft) other);
                return (Objects.equal(type, o.type)&&Objects.equal(prd, o.prd));
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DeductibleTypeCodeSLN"/&gt;
         *         &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "type",
            "prd"
        })
        public static class Ddctble implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Type", required = true)
            protected String type;
            @XmlElement(name = "Prd", required = true)
            protected DurationType prd;

            /**
             * Default no-arg constructor
             * 
             */
            public Ddctble() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public Ddctble(final String type, final DurationType prd) {
                this.type = type;
                this.prd = prd;
            }

            /**
             * Gets the value of the type property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getType() {
                return type;
            }

            /**
             * Sets the value of the type property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setType(String value) {
                this.type = value;
            }

            public boolean isSetType() {
                return (this.type!= null);
            }

            /**
             * Gets the value of the prd property.
             * 
             * @return
             *     possible object is
             *     {@link DurationType }
             *     
             */
            public DurationType getPrd() {
                return prd;
            }

            /**
             * Sets the value of the prd property.
             * 
             * @param value
             *     allowed object is
             *     {@link DurationType }
             *     
             */
            public void setPrd(DurationType value) {
                this.prd = value;
            }

            public boolean isSetPrd() {
                return (this.prd!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("type", type).add("prd", prd).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(type, prd);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble o = ((SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble) other);
                return (Objects.equal(type, o.type)&&Objects.equal(prd, o.prd));
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="InstllmntMaxNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
         *         &lt;element name="InstllmntRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
         *         &lt;element name="SurndrPnlty" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
         *                   &lt;element name="FixAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "instllmntMaxNumb",
            "instllmntRate",
            "surndrPnlty"
        })
        public static class LoanBnftTerms implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "InstllmntMaxNumb")
            protected BigInteger instllmntMaxNumb;
            @XmlElement(name = "InstllmntRate")
            protected BasisRateType instllmntRate;
            @XmlElement(name = "SurndrPnlty")
            protected SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty surndrPnlty;

            /**
             * Default no-arg constructor
             * 
             */
            public LoanBnftTerms() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public LoanBnftTerms(final BigInteger instllmntMaxNumb, final BasisRateType instllmntRate, final SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty surndrPnlty) {
                this.instllmntMaxNumb = instllmntMaxNumb;
                this.instllmntRate = instllmntRate;
                this.surndrPnlty = surndrPnlty;
            }

            /**
             * Gets the value of the instllmntMaxNumb property.
             * 
             * @return
             *     possible object is
             *     {@link BigInteger }
             *     
             */
            public BigInteger getInstllmntMaxNumb() {
                return instllmntMaxNumb;
            }

            /**
             * Sets the value of the instllmntMaxNumb property.
             * 
             * @param value
             *     allowed object is
             *     {@link BigInteger }
             *     
             */
            public void setInstllmntMaxNumb(BigInteger value) {
                this.instllmntMaxNumb = value;
            }

            public boolean isSetInstllmntMaxNumb() {
                return (this.instllmntMaxNumb!= null);
            }

            /**
             * Gets the value of the instllmntRate property.
             * 
             * @return
             *     possible object is
             *     {@link BasisRateType }
             *     
             */
            public BasisRateType getInstllmntRate() {
                return instllmntRate;
            }

            /**
             * Sets the value of the instllmntRate property.
             * 
             * @param value
             *     allowed object is
             *     {@link BasisRateType }
             *     
             */
            public void setInstllmntRate(BasisRateType value) {
                this.instllmntRate = value;
            }

            public boolean isSetInstllmntRate() {
                return (this.instllmntRate!= null);
            }

            /**
             * Gets the value of the surndrPnlty property.
             * 
             * @return
             *     possible object is
             *     {@link SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty }
             *     
             */
            public SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty getSurndrPnlty() {
                return surndrPnlty;
            }

            /**
             * Sets the value of the surndrPnlty property.
             * 
             * @param value
             *     allowed object is
             *     {@link SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty }
             *     
             */
            public void setSurndrPnlty(SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty value) {
                this.surndrPnlty = value;
            }

            public boolean isSetSurndrPnlty() {
                return (this.surndrPnlty!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("instllmntMaxNumb", instllmntMaxNumb).add("instllmntRate", instllmntRate).add("surndrPnlty", surndrPnlty).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(instllmntMaxNumb, instllmntRate, surndrPnlty);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms o = ((SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms) other);
                return ((Objects.equal(instllmntMaxNumb, o.instllmntMaxNumb)&&Objects.equal(instllmntRate, o.instllmntRate))&&Objects.equal(surndrPnlty, o.surndrPnlty));
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
             *         &lt;element name="FixAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "rate",
                "fixAmnt"
            })
            public static class SurndrPnlty implements Serializable
            {

                private final static long serialVersionUID = 1L;
                @XmlElement(name = "Rate")
                protected BasisRateType rate;
                @XmlElement(name = "FixAmnt")
                protected CurrencyAndAmountType fixAmnt;

                /**
                 * Default no-arg constructor
                 * 
                 */
                public SurndrPnlty() {
                    super();
                }

                /**
                 * Fully-initialising value constructor
                 * 
                 */
                public SurndrPnlty(final BasisRateType rate, final CurrencyAndAmountType fixAmnt) {
                    this.rate = rate;
                    this.fixAmnt = fixAmnt;
                }

                /**
                 * Gets the value of the rate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BasisRateType }
                 *     
                 */
                public BasisRateType getRate() {
                    return rate;
                }

                /**
                 * Sets the value of the rate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BasisRateType }
                 *     
                 */
                public void setRate(BasisRateType value) {
                    this.rate = value;
                }

                public boolean isSetRate() {
                    return (this.rate!= null);
                }

                /**
                 * Gets the value of the fixAmnt property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CurrencyAndAmountType }
                 *     
                 */
                public CurrencyAndAmountType getFixAmnt() {
                    return fixAmnt;
                }

                /**
                 * Sets the value of the fixAmnt property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CurrencyAndAmountType }
                 *     
                 */
                public void setFixAmnt(CurrencyAndAmountType value) {
                    this.fixAmnt = value;
                }

                public boolean isSetFixAmnt() {
                    return (this.fixAmnt!= null);
                }

                @Override
                public String toString() {
                    return Objects.toStringHelper(this).add("rate", rate).add("fixAmnt", fixAmnt).toString();
                }

                @Override
                public int hashCode() {
                    return Objects.hashCode(rate, fixAmnt);
                }

                @Override
                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (other == null) {
                        return false;
                    }
                    if (getClass()!= other.getClass()) {
                        return false;
                    }
                    final SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty o = ((SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty) other);
                    return (Objects.equal(rate, o.rate)&&Objects.equal(fixAmnt, o.fixAmnt));
                }

            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
     *         &lt;element name="MarktngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
     *         &lt;element name="MndtryIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
     *         &lt;element name="InsrdEntryMaxAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "name",
        "marktngPrd",
        "mndtryIndic",
        "insrdEntryMaxAge"
    })
    public static class Data implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Name")
        protected String name;
        @XmlElement(name = "MarktngPrd")
        protected DatePeriodType marktngPrd;
        @XmlElement(name = "MndtryIndic")
        protected String mndtryIndic;
        @XmlElement(name = "InsrdEntryMaxAge", required = true)
        protected BigInteger insrdEntryMaxAge;

        /**
         * Default no-arg constructor
         * 
         */
        public Data() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Data(final String name, final DatePeriodType marktngPrd, final String mndtryIndic, final BigInteger insrdEntryMaxAge) {
            this.name = name;
            this.marktngPrd = marktngPrd;
            this.mndtryIndic = mndtryIndic;
            this.insrdEntryMaxAge = insrdEntryMaxAge;
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

        public boolean isSetName() {
            return (this.name!= null);
        }

        /**
         * Gets the value of the marktngPrd property.
         * 
         * @return
         *     possible object is
         *     {@link DatePeriodType }
         *     
         */
        public DatePeriodType getMarktngPrd() {
            return marktngPrd;
        }

        /**
         * Sets the value of the marktngPrd property.
         * 
         * @param value
         *     allowed object is
         *     {@link DatePeriodType }
         *     
         */
        public void setMarktngPrd(DatePeriodType value) {
            this.marktngPrd = value;
        }

        public boolean isSetMarktngPrd() {
            return (this.marktngPrd!= null);
        }

        /**
         * Gets the value of the mndtryIndic property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMndtryIndic() {
            return mndtryIndic;
        }

        /**
         * Sets the value of the mndtryIndic property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMndtryIndic(String value) {
            this.mndtryIndic = value;
        }

        public boolean isSetMndtryIndic() {
            return (this.mndtryIndic!= null);
        }

        /**
         * Gets the value of the insrdEntryMaxAge property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getInsrdEntryMaxAge() {
            return insrdEntryMaxAge;
        }

        /**
         * Sets the value of the insrdEntryMaxAge property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setInsrdEntryMaxAge(BigInteger value) {
            this.insrdEntryMaxAge = value;
        }

        public boolean isSetInsrdEntryMaxAge() {
            return (this.insrdEntryMaxAge!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("name", name).add("marktngPrd", marktngPrd).add("mndtryIndic", mndtryIndic).add("insrdEntryMaxAge", insrdEntryMaxAge).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(name, marktngPrd, mndtryIndic, insrdEntryMaxAge);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final SimplifiedProtectiionCoverDataType.Data o = ((SimplifiedProtectiionCoverDataType.Data) other);
            return (((Objects.equal(name, o.name)&&Objects.equal(marktngPrd, o.marktngPrd))&&Objects.equal(mndtryIndic, o.mndtryIndic))&&Objects.equal(insrdEntryMaxAge, o.insrdEntryMaxAge));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="FeeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeesCodeSLN"/&gt;
     *         &lt;element name="CalctnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountCalculationRuleTypeCodeSLN"/&gt;
     *         &lt;element name="Basis" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
     *                   &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="FixdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "feeType",
        "calctnType",
        "basis",
        "fixdAmnt"
    })
    public static class Fee implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "FeeType", required = true)
        protected String feeType;
        @XmlElement(name = "CalctnType", required = true)
        protected String calctnType;
        @XmlElement(name = "Basis")
        protected SimplifiedProtectiionCoverDataType.Fee.Basis basis;
        @XmlElement(name = "FixdAmnt")
        protected CurrencyAndAmountType fixdAmnt;

        /**
         * Default no-arg constructor
         * 
         */
        public Fee() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Fee(final String feeType, final String calctnType, final SimplifiedProtectiionCoverDataType.Fee.Basis basis, final CurrencyAndAmountType fixdAmnt) {
            this.feeType = feeType;
            this.calctnType = calctnType;
            this.basis = basis;
            this.fixdAmnt = fixdAmnt;
        }

        /**
         * Gets the value of the feeType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFeeType() {
            return feeType;
        }

        /**
         * Sets the value of the feeType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFeeType(String value) {
            this.feeType = value;
        }

        public boolean isSetFeeType() {
            return (this.feeType!= null);
        }

        /**
         * Gets the value of the calctnType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCalctnType() {
            return calctnType;
        }

        /**
         * Sets the value of the calctnType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCalctnType(String value) {
            this.calctnType = value;
        }

        public boolean isSetCalctnType() {
            return (this.calctnType!= null);
        }

        /**
         * Gets the value of the basis property.
         * 
         * @return
         *     possible object is
         *     {@link SimplifiedProtectiionCoverDataType.Fee.Basis }
         *     
         */
        public SimplifiedProtectiionCoverDataType.Fee.Basis getBasis() {
            return basis;
        }

        /**
         * Sets the value of the basis property.
         * 
         * @param value
         *     allowed object is
         *     {@link SimplifiedProtectiionCoverDataType.Fee.Basis }
         *     
         */
        public void setBasis(SimplifiedProtectiionCoverDataType.Fee.Basis value) {
            this.basis = value;
        }

        public boolean isSetBasis() {
            return (this.basis!= null);
        }

        /**
         * Gets the value of the fixdAmnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getFixdAmnt() {
            return fixdAmnt;
        }

        /**
         * Sets the value of the fixdAmnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setFixdAmnt(CurrencyAndAmountType value) {
            this.fixdAmnt = value;
        }

        public boolean isSetFixdAmnt() {
            return (this.fixdAmnt!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("feeType", feeType).add("calctnType", calctnType).add("basis", basis).add("fixdAmnt", fixdAmnt).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(feeType, calctnType, basis, fixdAmnt);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final SimplifiedProtectiionCoverDataType.Fee o = ((SimplifiedProtectiionCoverDataType.Fee) other);
            return (((Objects.equal(feeType, o.feeType)&&Objects.equal(calctnType, o.calctnType))&&Objects.equal(basis, o.basis))&&Objects.equal(fixdAmnt, o.fixdAmnt));
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
         *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "rate",
            "amnt"
        })
        public static class Basis implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Rate")
            protected BasisRateType rate;
            @XmlElement(name = "Amnt")
            protected CurrencyAndAmountType amnt;

            /**
             * Default no-arg constructor
             * 
             */
            public Basis() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public Basis(final BasisRateType rate, final CurrencyAndAmountType amnt) {
                this.rate = rate;
                this.amnt = amnt;
            }

            /**
             * Gets the value of the rate property.
             * 
             * @return
             *     possible object is
             *     {@link BasisRateType }
             *     
             */
            public BasisRateType getRate() {
                return rate;
            }

            /**
             * Sets the value of the rate property.
             * 
             * @param value
             *     allowed object is
             *     {@link BasisRateType }
             *     
             */
            public void setRate(BasisRateType value) {
                this.rate = value;
            }

            public boolean isSetRate() {
                return (this.rate!= null);
            }

            /**
             * Gets the value of the amnt property.
             * 
             * @return
             *     possible object is
             *     {@link CurrencyAndAmountType }
             *     
             */
            public CurrencyAndAmountType getAmnt() {
                return amnt;
            }

            /**
             * Sets the value of the amnt property.
             * 
             * @param value
             *     allowed object is
             *     {@link CurrencyAndAmountType }
             *     
             */
            public void setAmnt(CurrencyAndAmountType value) {
                this.amnt = value;
            }

            public boolean isSetAmnt() {
                return (this.amnt!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("rate", rate).add("amnt", amnt).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(rate, amnt);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final SimplifiedProtectiionCoverDataType.Fee.Basis o = ((SimplifiedProtectiionCoverDataType.Fee.Basis) other);
                return (Objects.equal(rate, o.rate)&&Objects.equal(amnt, o.amnt));
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
     *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode"/&gt;
     *         &lt;element name="LifeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LifeIndicatorCodeSLN"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "id",
        "code",
        "lifeIndic"
    })
    public static class Idntfctn implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Id", required = true)
        protected String id;
        @XmlElement(name = "Code", required = true)
        protected String code;
        @XmlElement(name = "LifeIndic", required = true)
        protected String lifeIndic;

        /**
         * Default no-arg constructor
         * 
         */
        public Idntfctn() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Idntfctn(final String id, final String code, final String lifeIndic) {
            this.id = id;
            this.code = code;
            this.lifeIndic = lifeIndic;
        }

        /**
         * Gets the value of the id property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getId() {
            return id;
        }

        /**
         * Sets the value of the id property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setId(String value) {
            this.id = value;
        }

        public boolean isSetId() {
            return (this.id!= null);
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        public boolean isSetCode() {
            return (this.code!= null);
        }

        /**
         * Gets the value of the lifeIndic property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLifeIndic() {
            return lifeIndic;
        }

        /**
         * Sets the value of the lifeIndic property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLifeIndic(String value) {
            this.lifeIndic = value;
        }

        public boolean isSetLifeIndic() {
            return (this.lifeIndic!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("id", id).add("code", code).add("lifeIndic", lifeIndic).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(id, code, lifeIndic);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final SimplifiedProtectiionCoverDataType.Idntfctn o = ((SimplifiedProtectiionCoverDataType.Idntfctn) other);
            return ((Objects.equal(id, o.id)&&Objects.equal(code, o.code))&&Objects.equal(lifeIndic, o.lifeIndic));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="SngleIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN"/&gt;
     *         &lt;element name="AuthrzdPaymntFqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
     *         &lt;element name="RvsbltyTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumOrBenefitRevisabilityTermsDataType" minOccurs="0"/&gt;
     *         &lt;element name="CalctnTerms" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="CalctnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountCalculationRuleTypeCodeSLN"/&gt;
     *                   &lt;element name="Basis" maxOccurs="unbounded" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="AgeIntrvl" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="LowrLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
     *                                       &lt;element name="UpprLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
     *                             &lt;element name="InitAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *                             &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="FixdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="RfndBasisAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "sngleIndic",
        "authrzdPaymntFqcy",
        "rvsbltyTerms",
        "calctnTerms",
        "rfndBasisAmnt"
    })
    public static class Prem implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "SngleIndic", required = true)
        protected String sngleIndic;
        @XmlElement(name = "AuthrzdPaymntFqcy")
        protected List<String> authrzdPaymntFqcy;
        @XmlElement(name = "RvsbltyTerms")
        protected PremiumOrBenefitRevisabilityTermsDataType rvsbltyTerms;
        @XmlElement(name = "CalctnTerms")
        protected SimplifiedProtectiionCoverDataType.Prem.CalctnTerms calctnTerms;
        @XmlElement(name = "RfndBasisAmnt")
        protected CurrencyAndAmountType rfndBasisAmnt;

        /**
         * Default no-arg constructor
         * 
         */
        public Prem() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Prem(final String sngleIndic, final List<String> authrzdPaymntFqcy, final PremiumOrBenefitRevisabilityTermsDataType rvsbltyTerms, final SimplifiedProtectiionCoverDataType.Prem.CalctnTerms calctnTerms, final CurrencyAndAmountType rfndBasisAmnt) {
            this.sngleIndic = sngleIndic;
            this.authrzdPaymntFqcy = authrzdPaymntFqcy;
            this.rvsbltyTerms = rvsbltyTerms;
            this.calctnTerms = calctnTerms;
            this.rfndBasisAmnt = rfndBasisAmnt;
        }

        /**
         * Gets the value of the sngleIndic property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSngleIndic() {
            return sngleIndic;
        }

        /**
         * Sets the value of the sngleIndic property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSngleIndic(String value) {
            this.sngleIndic = value;
        }

        public boolean isSetSngleIndic() {
            return (this.sngleIndic!= null);
        }

        /**
         * Gets the value of the authrzdPaymntFqcy property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the authrzdPaymntFqcy property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getAuthrzdPaymntFqcy().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getAuthrzdPaymntFqcy() {
            if (authrzdPaymntFqcy == null) {
                authrzdPaymntFqcy = new ArrayList<String>();
            }
            return this.authrzdPaymntFqcy;
        }

        public boolean isSetAuthrzdPaymntFqcy() {
            return ((this.authrzdPaymntFqcy!= null)&&(!this.authrzdPaymntFqcy.isEmpty()));
        }

        public void unsetAuthrzdPaymntFqcy() {
            this.authrzdPaymntFqcy = null;
        }

        /**
         * Gets the value of the rvsbltyTerms property.
         * 
         * @return
         *     possible object is
         *     {@link PremiumOrBenefitRevisabilityTermsDataType }
         *     
         */
        public PremiumOrBenefitRevisabilityTermsDataType getRvsbltyTerms() {
            return rvsbltyTerms;
        }

        /**
         * Sets the value of the rvsbltyTerms property.
         * 
         * @param value
         *     allowed object is
         *     {@link PremiumOrBenefitRevisabilityTermsDataType }
         *     
         */
        public void setRvsbltyTerms(PremiumOrBenefitRevisabilityTermsDataType value) {
            this.rvsbltyTerms = value;
        }

        public boolean isSetRvsbltyTerms() {
            return (this.rvsbltyTerms!= null);
        }

        /**
         * Gets the value of the calctnTerms property.
         * 
         * @return
         *     possible object is
         *     {@link SimplifiedProtectiionCoverDataType.Prem.CalctnTerms }
         *     
         */
        public SimplifiedProtectiionCoverDataType.Prem.CalctnTerms getCalctnTerms() {
            return calctnTerms;
        }

        /**
         * Sets the value of the calctnTerms property.
         * 
         * @param value
         *     allowed object is
         *     {@link SimplifiedProtectiionCoverDataType.Prem.CalctnTerms }
         *     
         */
        public void setCalctnTerms(SimplifiedProtectiionCoverDataType.Prem.CalctnTerms value) {
            this.calctnTerms = value;
        }

        public boolean isSetCalctnTerms() {
            return (this.calctnTerms!= null);
        }

        /**
         * Gets the value of the rfndBasisAmnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getRfndBasisAmnt() {
            return rfndBasisAmnt;
        }

        /**
         * Sets the value of the rfndBasisAmnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setRfndBasisAmnt(CurrencyAndAmountType value) {
            this.rfndBasisAmnt = value;
        }

        public boolean isSetRfndBasisAmnt() {
            return (this.rfndBasisAmnt!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("sngleIndic", sngleIndic).add("authrzdPaymntFqcy", authrzdPaymntFqcy).add("rvsbltyTerms", rvsbltyTerms).add("calctnTerms", calctnTerms).add("rfndBasisAmnt", rfndBasisAmnt).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(sngleIndic, authrzdPaymntFqcy, rvsbltyTerms, calctnTerms, rfndBasisAmnt);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final SimplifiedProtectiionCoverDataType.Prem o = ((SimplifiedProtectiionCoverDataType.Prem) other);
            return ((((Objects.equal(sngleIndic, o.sngleIndic)&&Objects.equal(authrzdPaymntFqcy, o.authrzdPaymntFqcy))&&Objects.equal(rvsbltyTerms, o.rvsbltyTerms))&&Objects.equal(calctnTerms, o.calctnTerms))&&Objects.equal(rfndBasisAmnt, o.rfndBasisAmnt));
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="CalctnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountCalculationRuleTypeCodeSLN"/&gt;
         *         &lt;element name="Basis" maxOccurs="unbounded" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="AgeIntrvl" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="LowrLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
         *                             &lt;element name="UpprLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
         *                   &lt;element name="InitAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
         *                   &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="FixdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "calctnType",
            "basis",
            "fixdAmnt"
        })
        public static class CalctnTerms implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "CalctnType", required = true)
            protected String calctnType;
            @XmlElement(name = "Basis")
            protected List<SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis> basis;
            @XmlElement(name = "FixdAmnt")
            protected CurrencyAndAmountType fixdAmnt;

            /**
             * Default no-arg constructor
             * 
             */
            public CalctnTerms() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public CalctnTerms(final String calctnType, final List<SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis> basis, final CurrencyAndAmountType fixdAmnt) {
                this.calctnType = calctnType;
                this.basis = basis;
                this.fixdAmnt = fixdAmnt;
            }

            /**
             * Gets the value of the calctnType property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCalctnType() {
                return calctnType;
            }

            /**
             * Sets the value of the calctnType property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCalctnType(String value) {
                this.calctnType = value;
            }

            public boolean isSetCalctnType() {
                return (this.calctnType!= null);
            }

            /**
             * Gets the value of the basis property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the basis property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getBasis().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis }
             * 
             * 
             */
            public List<SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis> getBasis() {
                if (basis == null) {
                    basis = new ArrayList<SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis>();
                }
                return this.basis;
            }

            public boolean isSetBasis() {
                return ((this.basis!= null)&&(!this.basis.isEmpty()));
            }

            public void unsetBasis() {
                this.basis = null;
            }

            /**
             * Gets the value of the fixdAmnt property.
             * 
             * @return
             *     possible object is
             *     {@link CurrencyAndAmountType }
             *     
             */
            public CurrencyAndAmountType getFixdAmnt() {
                return fixdAmnt;
            }

            /**
             * Sets the value of the fixdAmnt property.
             * 
             * @param value
             *     allowed object is
             *     {@link CurrencyAndAmountType }
             *     
             */
            public void setFixdAmnt(CurrencyAndAmountType value) {
                this.fixdAmnt = value;
            }

            public boolean isSetFixdAmnt() {
                return (this.fixdAmnt!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("calctnType", calctnType).add("basis", basis).add("fixdAmnt", fixdAmnt).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(calctnType, basis, fixdAmnt);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final SimplifiedProtectiionCoverDataType.Prem.CalctnTerms o = ((SimplifiedProtectiionCoverDataType.Prem.CalctnTerms) other);
                return ((Objects.equal(calctnType, o.calctnType)&&Objects.equal(basis, o.basis))&&Objects.equal(fixdAmnt, o.fixdAmnt));
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="AgeIntrvl" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="LowrLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
             *                   &lt;element name="UpprLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
             *         &lt;element name="InitAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
             *         &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "ageIntrvl",
                "rate",
                "initAmnt",
                "gendr"
            })
            public static class Basis implements Serializable
            {

                private final static long serialVersionUID = 1L;
                @XmlElement(name = "AgeIntrvl")
                protected SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl ageIntrvl;
                @XmlElement(name = "Rate", required = true)
                protected BasisRateType rate;
                @XmlElement(name = "InitAmnt")
                protected CurrencyAndAmountType initAmnt;
                @XmlElement(name = "Gendr")
                protected String gendr;

                /**
                 * Default no-arg constructor
                 * 
                 */
                public Basis() {
                    super();
                }

                /**
                 * Fully-initialising value constructor
                 * 
                 */
                public Basis(final SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl ageIntrvl, final BasisRateType rate, final CurrencyAndAmountType initAmnt, final String gendr) {
                    this.ageIntrvl = ageIntrvl;
                    this.rate = rate;
                    this.initAmnt = initAmnt;
                    this.gendr = gendr;
                }

                /**
                 * Gets the value of the ageIntrvl property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl }
                 *     
                 */
                public SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl getAgeIntrvl() {
                    return ageIntrvl;
                }

                /**
                 * Sets the value of the ageIntrvl property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl }
                 *     
                 */
                public void setAgeIntrvl(SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl value) {
                    this.ageIntrvl = value;
                }

                public boolean isSetAgeIntrvl() {
                    return (this.ageIntrvl!= null);
                }

                /**
                 * Gets the value of the rate property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link BasisRateType }
                 *     
                 */
                public BasisRateType getRate() {
                    return rate;
                }

                /**
                 * Sets the value of the rate property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link BasisRateType }
                 *     
                 */
                public void setRate(BasisRateType value) {
                    this.rate = value;
                }

                public boolean isSetRate() {
                    return (this.rate!= null);
                }

                /**
                 * Gets the value of the initAmnt property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CurrencyAndAmountType }
                 *     
                 */
                public CurrencyAndAmountType getInitAmnt() {
                    return initAmnt;
                }

                /**
                 * Sets the value of the initAmnt property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CurrencyAndAmountType }
                 *     
                 */
                public void setInitAmnt(CurrencyAndAmountType value) {
                    this.initAmnt = value;
                }

                public boolean isSetInitAmnt() {
                    return (this.initAmnt!= null);
                }

                /**
                 * Gets the value of the gendr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getGendr() {
                    return gendr;
                }

                /**
                 * Sets the value of the gendr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setGendr(String value) {
                    this.gendr = value;
                }

                public boolean isSetGendr() {
                    return (this.gendr!= null);
                }

                @Override
                public String toString() {
                    return Objects.toStringHelper(this).add("ageIntrvl", ageIntrvl).add("rate", rate).add("initAmnt", initAmnt).add("gendr", gendr).toString();
                }

                @Override
                public int hashCode() {
                    return Objects.hashCode(ageIntrvl, rate, initAmnt, gendr);
                }

                @Override
                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (other == null) {
                        return false;
                    }
                    if (getClass()!= other.getClass()) {
                        return false;
                    }
                    final SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis o = ((SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis) other);
                    return (((Objects.equal(ageIntrvl, o.ageIntrvl)&&Objects.equal(rate, o.rate))&&Objects.equal(initAmnt, o.initAmnt))&&Objects.equal(gendr, o.gendr));
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="LowrLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
                 *         &lt;element name="UpprLimit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "lowrLimit",
                    "upprLimit"
                })
                public static class AgeIntrvl implements Serializable
                {

                    private final static long serialVersionUID = 1L;
                    @XmlElement(name = "LowrLimit", required = true)
                    protected BigInteger lowrLimit;
                    @XmlElement(name = "UpprLimit", required = true)
                    protected BigInteger upprLimit;

                    /**
                     * Default no-arg constructor
                     * 
                     */
                    public AgeIntrvl() {
                        super();
                    }

                    /**
                     * Fully-initialising value constructor
                     * 
                     */
                    public AgeIntrvl(final BigInteger lowrLimit, final BigInteger upprLimit) {
                        this.lowrLimit = lowrLimit;
                        this.upprLimit = upprLimit;
                    }

                    /**
                     * Gets the value of the lowrLimit property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *     
                     */
                    public BigInteger getLowrLimit() {
                        return lowrLimit;
                    }

                    /**
                     * Sets the value of the lowrLimit property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *     
                     */
                    public void setLowrLimit(BigInteger value) {
                        this.lowrLimit = value;
                    }

                    public boolean isSetLowrLimit() {
                        return (this.lowrLimit!= null);
                    }

                    /**
                     * Gets the value of the upprLimit property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigInteger }
                     *     
                     */
                    public BigInteger getUpprLimit() {
                        return upprLimit;
                    }

                    /**
                     * Sets the value of the upprLimit property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigInteger }
                     *     
                     */
                    public void setUpprLimit(BigInteger value) {
                        this.upprLimit = value;
                    }

                    public boolean isSetUpprLimit() {
                        return (this.upprLimit!= null);
                    }

                    @Override
                    public String toString() {
                        return Objects.toStringHelper(this).add("lowrLimit", lowrLimit).add("upprLimit", upprLimit).toString();
                    }

                    @Override
                    public int hashCode() {
                        return Objects.hashCode(lowrLimit, upprLimit);
                    }

                    @Override
                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (other == null) {
                            return false;
                        }
                        if (getClass()!= other.getClass()) {
                            return false;
                        }
                        final SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl o = ((SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl) other);
                        return (Objects.equal(lowrLimit, o.lowrLimit)&&Objects.equal(upprLimit, o.upprLimit));
                    }

                }

            }

        }

    }

}
