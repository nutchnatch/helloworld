
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.google.common.base.Objects;


/**
 * <p>Java class for TimePeriodType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TimePeriodType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FromTime" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISOTimeType"/&gt;
 *         &lt;element name="ToTime" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISOTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TimePeriodType", propOrder = {
    "fromTime",
    "toTime"
})
public class TimePeriodType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FromTime", required = true)
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar fromTime;
    @XmlElement(name = "ToTime")
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar toTime;

    /**
     * Default no-arg constructor
     * 
     */
    public TimePeriodType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public TimePeriodType(final XMLGregorianCalendar fromTime, final XMLGregorianCalendar toTime) {
        this.fromTime = fromTime;
        this.toTime = toTime;
    }

    /**
     * Gets the value of the fromTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFromTime() {
        return fromTime;
    }

    /**
     * Sets the value of the fromTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFromTime(XMLGregorianCalendar value) {
        this.fromTime = value;
    }

    public boolean isSetFromTime() {
        return (this.fromTime!= null);
    }

    /**
     * Gets the value of the toTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getToTime() {
        return toTime;
    }

    /**
     * Sets the value of the toTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setToTime(XMLGregorianCalendar value) {
        this.toTime = value;
    }

    public boolean isSetToTime() {
        return (this.toTime!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fromTime", fromTime).add("toTime", toTime).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fromTime, toTime);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final TimePeriodType o = ((TimePeriodType) other);
        return (Objects.equal(fromTime, o.fromTime)&&Objects.equal(toTime, o.toTime));
    }

}
