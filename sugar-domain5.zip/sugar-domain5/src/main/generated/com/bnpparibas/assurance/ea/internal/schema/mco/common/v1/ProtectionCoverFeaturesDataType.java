
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for ProtectionCoverFeaturesDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionCoverFeaturesDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductRiskIdentificationDataType"/&gt;
 *         &lt;element name="LinkdObjcts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductCoverLinkedObjectDataType" minOccurs="0"/&gt;
 *         &lt;element name="CovData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductCoverDataType" minOccurs="0"/&gt;
 *         &lt;element name="ClaimTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverClaimTermsDataType" minOccurs="0"/&gt;
 *         &lt;element name="StdExclsn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverStandardExclusionDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ExitBnft" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverExitBenefitDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AuthrzdBenfciaryClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverAuthorizedBenficiaryClauseDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PremTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverPremiumCalculationAndRevisabiltyTermsDataType" minOccurs="0"/&gt;
 *         &lt;element name="PremFeeTerms" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverPremiumFeeTermsDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PremFeesCalctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPremiumFeesCalculationDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionCoverFeaturesDataType", propOrder = {
    "idntfctn",
    "linkdObjcts",
    "covData",
    "claimTerms",
    "stdExclsn",
    "exitBnft",
    "authrzdBenfciaryClause",
    "premTerms",
    "premFeeTerms",
    "premFeesCalctn"
})
public class ProtectionCoverFeaturesDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn", required = true)
    protected ProductRiskIdentificationDataType idntfctn;
    @XmlElement(name = "LinkdObjcts")
    protected ProductCoverLinkedObjectDataType linkdObjcts;
    @XmlElement(name = "CovData")
    protected ProductCoverDataType covData;
    @XmlElement(name = "ClaimTerms")
    protected CoverClaimTermsDataType claimTerms;
    @XmlElement(name = "StdExclsn")
    protected List<CoverStandardExclusionDataType> stdExclsn;
    @XmlElement(name = "ExitBnft")
    protected List<CoverExitBenefitDataType> exitBnft;
    @XmlElement(name = "AuthrzdBenfciaryClause")
    protected List<CoverAuthorizedBenficiaryClauseDataType> authrzdBenfciaryClause;
    @XmlElement(name = "PremTerms")
    protected CoverPremiumCalculationAndRevisabiltyTermsDataType premTerms;
    @XmlElement(name = "PremFeeTerms")
    protected List<CoverPremiumFeeTermsDataType> premFeeTerms;
    @XmlElement(name = "PremFeesCalctn")
    protected List<ProtectionPremiumFeesCalculationDataType> premFeesCalctn;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionCoverFeaturesDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionCoverFeaturesDataType(final ProductRiskIdentificationDataType idntfctn, final ProductCoverLinkedObjectDataType linkdObjcts, final ProductCoverDataType covData, final CoverClaimTermsDataType claimTerms, final List<CoverStandardExclusionDataType> stdExclsn, final List<CoverExitBenefitDataType> exitBnft, final List<CoverAuthorizedBenficiaryClauseDataType> authrzdBenfciaryClause, final CoverPremiumCalculationAndRevisabiltyTermsDataType premTerms, final List<CoverPremiumFeeTermsDataType> premFeeTerms, final List<ProtectionPremiumFeesCalculationDataType> premFeesCalctn) {
        this.idntfctn = idntfctn;
        this.linkdObjcts = linkdObjcts;
        this.covData = covData;
        this.claimTerms = claimTerms;
        this.stdExclsn = stdExclsn;
        this.exitBnft = exitBnft;
        this.authrzdBenfciaryClause = authrzdBenfciaryClause;
        this.premTerms = premTerms;
        this.premFeeTerms = premFeeTerms;
        this.premFeesCalctn = premFeesCalctn;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ProductRiskIdentificationDataType }
     *     
     */
    public ProductRiskIdentificationDataType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductRiskIdentificationDataType }
     *     
     */
    public void setIdntfctn(ProductRiskIdentificationDataType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the linkdObjcts property.
     * 
     * @return
     *     possible object is
     *     {@link ProductCoverLinkedObjectDataType }
     *     
     */
    public ProductCoverLinkedObjectDataType getLinkdObjcts() {
        return linkdObjcts;
    }

    /**
     * Sets the value of the linkdObjcts property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductCoverLinkedObjectDataType }
     *     
     */
    public void setLinkdObjcts(ProductCoverLinkedObjectDataType value) {
        this.linkdObjcts = value;
    }

    public boolean isSetLinkdObjcts() {
        return (this.linkdObjcts!= null);
    }

    /**
     * Gets the value of the covData property.
     * 
     * @return
     *     possible object is
     *     {@link ProductCoverDataType }
     *     
     */
    public ProductCoverDataType getCovData() {
        return covData;
    }

    /**
     * Sets the value of the covData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductCoverDataType }
     *     
     */
    public void setCovData(ProductCoverDataType value) {
        this.covData = value;
    }

    public boolean isSetCovData() {
        return (this.covData!= null);
    }

    /**
     * Gets the value of the claimTerms property.
     * 
     * @return
     *     possible object is
     *     {@link CoverClaimTermsDataType }
     *     
     */
    public CoverClaimTermsDataType getClaimTerms() {
        return claimTerms;
    }

    /**
     * Sets the value of the claimTerms property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverClaimTermsDataType }
     *     
     */
    public void setClaimTerms(CoverClaimTermsDataType value) {
        this.claimTerms = value;
    }

    public boolean isSetClaimTerms() {
        return (this.claimTerms!= null);
    }

    /**
     * Gets the value of the stdExclsn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the stdExclsn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStdExclsn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverStandardExclusionDataType }
     * 
     * 
     */
    public List<CoverStandardExclusionDataType> getStdExclsn() {
        if (stdExclsn == null) {
            stdExclsn = new ArrayList<CoverStandardExclusionDataType>();
        }
        return this.stdExclsn;
    }

    public boolean isSetStdExclsn() {
        return ((this.stdExclsn!= null)&&(!this.stdExclsn.isEmpty()));
    }

    public void unsetStdExclsn() {
        this.stdExclsn = null;
    }

    /**
     * Gets the value of the exitBnft property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the exitBnft property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExitBnft().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverExitBenefitDataType }
     * 
     * 
     */
    public List<CoverExitBenefitDataType> getExitBnft() {
        if (exitBnft == null) {
            exitBnft = new ArrayList<CoverExitBenefitDataType>();
        }
        return this.exitBnft;
    }

    public boolean isSetExitBnft() {
        return ((this.exitBnft!= null)&&(!this.exitBnft.isEmpty()));
    }

    public void unsetExitBnft() {
        this.exitBnft = null;
    }

    /**
     * Gets the value of the authrzdBenfciaryClause property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the authrzdBenfciaryClause property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthrzdBenfciaryClause().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverAuthorizedBenficiaryClauseDataType }
     * 
     * 
     */
    public List<CoverAuthorizedBenficiaryClauseDataType> getAuthrzdBenfciaryClause() {
        if (authrzdBenfciaryClause == null) {
            authrzdBenfciaryClause = new ArrayList<CoverAuthorizedBenficiaryClauseDataType>();
        }
        return this.authrzdBenfciaryClause;
    }

    public boolean isSetAuthrzdBenfciaryClause() {
        return ((this.authrzdBenfciaryClause!= null)&&(!this.authrzdBenfciaryClause.isEmpty()));
    }

    public void unsetAuthrzdBenfciaryClause() {
        this.authrzdBenfciaryClause = null;
    }

    /**
     * Gets the value of the premTerms property.
     * 
     * @return
     *     possible object is
     *     {@link CoverPremiumCalculationAndRevisabiltyTermsDataType }
     *     
     */
    public CoverPremiumCalculationAndRevisabiltyTermsDataType getPremTerms() {
        return premTerms;
    }

    /**
     * Sets the value of the premTerms property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverPremiumCalculationAndRevisabiltyTermsDataType }
     *     
     */
    public void setPremTerms(CoverPremiumCalculationAndRevisabiltyTermsDataType value) {
        this.premTerms = value;
    }

    public boolean isSetPremTerms() {
        return (this.premTerms!= null);
    }

    /**
     * Gets the value of the premFeeTerms property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the premFeeTerms property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPremFeeTerms().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverPremiumFeeTermsDataType }
     * 
     * 
     */
    public List<CoverPremiumFeeTermsDataType> getPremFeeTerms() {
        if (premFeeTerms == null) {
            premFeeTerms = new ArrayList<CoverPremiumFeeTermsDataType>();
        }
        return this.premFeeTerms;
    }

    public boolean isSetPremFeeTerms() {
        return ((this.premFeeTerms!= null)&&(!this.premFeeTerms.isEmpty()));
    }

    public void unsetPremFeeTerms() {
        this.premFeeTerms = null;
    }

    /**
     * Gets the value of the premFeesCalctn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the premFeesCalctn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPremFeesCalctn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProtectionPremiumFeesCalculationDataType }
     * 
     * 
     */
    public List<ProtectionPremiumFeesCalculationDataType> getPremFeesCalctn() {
        if (premFeesCalctn == null) {
            premFeesCalctn = new ArrayList<ProtectionPremiumFeesCalculationDataType>();
        }
        return this.premFeesCalctn;
    }

    public boolean isSetPremFeesCalctn() {
        return ((this.premFeesCalctn!= null)&&(!this.premFeesCalctn.isEmpty()));
    }

    public void unsetPremFeesCalctn() {
        this.premFeesCalctn = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("linkdObjcts", linkdObjcts).add("covData", covData).add("claimTerms", claimTerms).add("stdExclsn", stdExclsn).add("exitBnft", exitBnft).add("authrzdBenfciaryClause", authrzdBenfciaryClause).add("premTerms", premTerms).add("premFeeTerms", premFeeTerms).add("premFeesCalctn", premFeesCalctn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, linkdObjcts, covData, claimTerms, stdExclsn, exitBnft, authrzdBenfciaryClause, premTerms, premFeeTerms, premFeesCalctn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionCoverFeaturesDataType o = ((ProtectionCoverFeaturesDataType) other);
        return (((((((((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(linkdObjcts, o.linkdObjcts))&&Objects.equal(covData, o.covData))&&Objects.equal(claimTerms, o.claimTerms))&&Objects.equal(stdExclsn, o.stdExclsn))&&Objects.equal(exitBnft, o.exitBnft))&&Objects.equal(authrzdBenfciaryClause, o.authrzdBenfciaryClause))&&Objects.equal(premTerms, o.premTerms))&&Objects.equal(premFeeTerms, o.premFeeTerms))&&Objects.equal(premFeesCalctn, o.premFeesCalctn));
    }

}
