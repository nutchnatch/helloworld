
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type of postal or geographic address
 * 			
 * 
 * <p>Java class for PostalAddressInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PostalAddressInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UseType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ContactInformationUseTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="UseCntxt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UseContextTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Line" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AddressLineType" maxOccurs="5"/&gt;
 *         &lt;element name="CityName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CityNameType"/&gt;
 *         &lt;element name="ReginOrStatName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RegionOrStateNameType" minOccurs="0"/&gt;
 *         &lt;element name="ZipOrPostCodeNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ZipOrPostCodeType"/&gt;
 *         &lt;element name="Cntry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN"/&gt;
 *         &lt;element name="ValdtyDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PostalAddressInputType", propOrder = {
    "useType",
    "useCntxt",
    "line",
    "cityName",
    "reginOrStatName",
    "zipOrPostCodeNumb",
    "cntry",
    "valdtyDate"
})
public class PostalAddressInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "UseType")
    protected String useType;
    @XmlElement(name = "UseCntxt")
    protected String useCntxt;
    @XmlElement(name = "Line", required = true)
    protected List<String> line;
    @XmlElement(name = "CityName", required = true)
    protected String cityName;
    @XmlElement(name = "ReginOrStatName")
    protected String reginOrStatName;
    @XmlElement(name = "ZipOrPostCodeNumb", required = true)
    protected String zipOrPostCodeNumb;
    @XmlElement(name = "Cntry", required = true)
    protected String cntry;
    @XmlElement(name = "ValdtyDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valdtyDate;

    /**
     * Default no-arg constructor
     * 
     */
    public PostalAddressInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PostalAddressInputType(final String useType, final String useCntxt, final List<String> line, final String cityName, final String reginOrStatName, final String zipOrPostCodeNumb, final String cntry, final Date valdtyDate) {
        this.useType = useType;
        this.useCntxt = useCntxt;
        this.line = line;
        this.cityName = cityName;
        this.reginOrStatName = reginOrStatName;
        this.zipOrPostCodeNumb = zipOrPostCodeNumb;
        this.cntry = cntry;
        this.valdtyDate = valdtyDate;
    }

    /**
     * Gets the value of the useType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseType() {
        return useType;
    }

    /**
     * Sets the value of the useType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseType(String value) {
        this.useType = value;
    }

    public boolean isSetUseType() {
        return (this.useType!= null);
    }

    /**
     * Gets the value of the useCntxt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseCntxt() {
        return useCntxt;
    }

    /**
     * Sets the value of the useCntxt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseCntxt(String value) {
        this.useCntxt = value;
    }

    public boolean isSetUseCntxt() {
        return (this.useCntxt!= null);
    }

    /**
     * Gets the value of the line property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the line property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLine().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getLine() {
        if (line == null) {
            line = new ArrayList<String>();
        }
        return this.line;
    }

    public boolean isSetLine() {
        return ((this.line!= null)&&(!this.line.isEmpty()));
    }

    public void unsetLine() {
        this.line = null;
    }

    /**
     * Gets the value of the cityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Sets the value of the cityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityName(String value) {
        this.cityName = value;
    }

    public boolean isSetCityName() {
        return (this.cityName!= null);
    }

    /**
     * Gets the value of the reginOrStatName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReginOrStatName() {
        return reginOrStatName;
    }

    /**
     * Sets the value of the reginOrStatName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReginOrStatName(String value) {
        this.reginOrStatName = value;
    }

    public boolean isSetReginOrStatName() {
        return (this.reginOrStatName!= null);
    }

    /**
     * Gets the value of the zipOrPostCodeNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipOrPostCodeNumb() {
        return zipOrPostCodeNumb;
    }

    /**
     * Sets the value of the zipOrPostCodeNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipOrPostCodeNumb(String value) {
        this.zipOrPostCodeNumb = value;
    }

    public boolean isSetZipOrPostCodeNumb() {
        return (this.zipOrPostCodeNumb!= null);
    }

    /**
     * Gets the value of the cntry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCntry() {
        return cntry;
    }

    /**
     * Sets the value of the cntry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCntry(String value) {
        this.cntry = value;
    }

    public boolean isSetCntry() {
        return (this.cntry!= null);
    }

    /**
     * Gets the value of the valdtyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValdtyDate() {
        return valdtyDate;
    }

    /**
     * Sets the value of the valdtyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValdtyDate(Date value) {
        this.valdtyDate = value;
    }

    public boolean isSetValdtyDate() {
        return (this.valdtyDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("useType", useType).add("useCntxt", useCntxt).add("line", line).add("cityName", cityName).add("reginOrStatName", reginOrStatName).add("zipOrPostCodeNumb", zipOrPostCodeNumb).add("cntry", cntry).add("valdtyDate", valdtyDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(useType, useCntxt, line, cityName, reginOrStatName, zipOrPostCodeNumb, cntry, valdtyDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PostalAddressInputType o = ((PostalAddressInputType) other);
        return (((((((Objects.equal(useType, o.useType)&&Objects.equal(useCntxt, o.useCntxt))&&Objects.equal(line, o.line))&&Objects.equal(cityName, o.cityName))&&Objects.equal(reginOrStatName, o.reginOrStatName))&&Objects.equal(zipOrPostCodeNumb, o.zipOrPostCodeNumb))&&Objects.equal(cntry, o.cntry))&&Objects.equal(valdtyDate, o.valdtyDate));
    }

}
