
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage fees derogation linked to a savings
 * 				policy
 * 			
 * 
 * <p>Java class for SavingsPolicyFeesDerogationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyFeesDerogationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PolLvl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeeDerogationType" minOccurs="0"/&gt;
 *         &lt;element name="FundLvl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FundFeeDerogationDataType" minOccurs="0"/&gt;
 *         &lt;element name="FundClasLvl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FundClassFeeDerogationDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyFeesDerogationType", propOrder = {
    "polLvl",
    "fundLvl",
    "fundClasLvl"
})
public class SavingsPolicyFeesDerogationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PolLvl")
    protected FeeDerogationType polLvl;
    @XmlElement(name = "FundLvl")
    protected FundFeeDerogationDataType fundLvl;
    @XmlElement(name = "FundClasLvl")
    protected FundClassFeeDerogationDataType fundClasLvl;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyFeesDerogationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyFeesDerogationType(final FeeDerogationType polLvl, final FundFeeDerogationDataType fundLvl, final FundClassFeeDerogationDataType fundClasLvl) {
        this.polLvl = polLvl;
        this.fundLvl = fundLvl;
        this.fundClasLvl = fundClasLvl;
    }

    /**
     * Gets the value of the polLvl property.
     * 
     * @return
     *     possible object is
     *     {@link FeeDerogationType }
     *     
     */
    public FeeDerogationType getPolLvl() {
        return polLvl;
    }

    /**
     * Sets the value of the polLvl property.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeDerogationType }
     *     
     */
    public void setPolLvl(FeeDerogationType value) {
        this.polLvl = value;
    }

    public boolean isSetPolLvl() {
        return (this.polLvl!= null);
    }

    /**
     * Gets the value of the fundLvl property.
     * 
     * @return
     *     possible object is
     *     {@link FundFeeDerogationDataType }
     *     
     */
    public FundFeeDerogationDataType getFundLvl() {
        return fundLvl;
    }

    /**
     * Sets the value of the fundLvl property.
     * 
     * @param value
     *     allowed object is
     *     {@link FundFeeDerogationDataType }
     *     
     */
    public void setFundLvl(FundFeeDerogationDataType value) {
        this.fundLvl = value;
    }

    public boolean isSetFundLvl() {
        return (this.fundLvl!= null);
    }

    /**
     * Gets the value of the fundClasLvl property.
     * 
     * @return
     *     possible object is
     *     {@link FundClassFeeDerogationDataType }
     *     
     */
    public FundClassFeeDerogationDataType getFundClasLvl() {
        return fundClasLvl;
    }

    /**
     * Sets the value of the fundClasLvl property.
     * 
     * @param value
     *     allowed object is
     *     {@link FundClassFeeDerogationDataType }
     *     
     */
    public void setFundClasLvl(FundClassFeeDerogationDataType value) {
        this.fundClasLvl = value;
    }

    public boolean isSetFundClasLvl() {
        return (this.fundClasLvl!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("polLvl", polLvl).add("fundLvl", fundLvl).add("fundClasLvl", fundClasLvl).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(polLvl, fundLvl, fundClasLvl);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyFeesDerogationType o = ((SavingsPolicyFeesDerogationType) other);
        return ((Objects.equal(polLvl, o.polLvl)&&Objects.equal(fundLvl, o.fundLvl))&&Objects.equal(fundClasLvl, o.fundClasLvl));
    }

}
