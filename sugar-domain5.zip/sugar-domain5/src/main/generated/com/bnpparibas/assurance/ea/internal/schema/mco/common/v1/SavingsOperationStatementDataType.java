
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data for savings operation statement
 * 			
 * 
 * <p>Java class for SavingsOperationStatementDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsOperationStatementDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RefPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReferencePeriodTypeCodeSLN"/&gt;
 *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="OpeStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationStatusCodeSLN"/&gt;
 *         &lt;element name="Statmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsFundByOpeStatmtDataType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsOperationStatementDataType", propOrder = {
    "refPrd",
    "opeType",
    "opeStatus",
    "statmnt"
})
public class SavingsOperationStatementDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "RefPrd", required = true)
    protected String refPrd;
    @XmlElement(name = "OpeType", required = true)
    protected String opeType;
    @XmlElement(name = "OpeStatus", required = true)
    protected String opeStatus;
    @XmlElement(name = "Statmnt", required = true)
    protected List<SavingsFundByOpeStatmtDataType> statmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsOperationStatementDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsOperationStatementDataType(final String refPrd, final String opeType, final String opeStatus, final List<SavingsFundByOpeStatmtDataType> statmnt) {
        this.refPrd = refPrd;
        this.opeType = opeType;
        this.opeStatus = opeStatus;
        this.statmnt = statmnt;
    }

    /**
     * Gets the value of the refPrd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefPrd() {
        return refPrd;
    }

    /**
     * Sets the value of the refPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefPrd(String value) {
        this.refPrd = value;
    }

    public boolean isSetRefPrd() {
        return (this.refPrd!= null);
    }

    /**
     * Gets the value of the opeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeType() {
        return opeType;
    }

    /**
     * Sets the value of the opeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeType(String value) {
        this.opeType = value;
    }

    public boolean isSetOpeType() {
        return (this.opeType!= null);
    }

    /**
     * Gets the value of the opeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeStatus() {
        return opeStatus;
    }

    /**
     * Sets the value of the opeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeStatus(String value) {
        this.opeStatus = value;
    }

    public boolean isSetOpeStatus() {
        return (this.opeStatus!= null);
    }

    /**
     * Gets the value of the statmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SavingsFundByOpeStatmtDataType }
     * 
     * 
     */
    public List<SavingsFundByOpeStatmtDataType> getStatmnt() {
        if (statmnt == null) {
            statmnt = new ArrayList<SavingsFundByOpeStatmtDataType>();
        }
        return this.statmnt;
    }

    public boolean isSetStatmnt() {
        return ((this.statmnt!= null)&&(!this.statmnt.isEmpty()));
    }

    public void unsetStatmnt() {
        this.statmnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("refPrd", refPrd).add("opeType", opeType).add("opeStatus", opeStatus).add("statmnt", statmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(refPrd, opeType, opeStatus, statmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsOperationStatementDataType o = ((SavingsOperationStatementDataType) other);
        return (((Objects.equal(refPrd, o.refPrd)&&Objects.equal(opeType, o.opeType))&&Objects.equal(opeStatus, o.opeStatus))&&Objects.equal(statmnt, o.statmnt));
    }

}
