
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a savings policy after sales
 * 				request has dependencies
 * 			
 * 
 * <p>Java class for SavingsPolicyLinkedObjectsInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyLinkedObjectsInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductSharedDataType" minOccurs="0"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Cust" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PersonIdentificationAndRoleSubRoleType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="GrpPol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="PrtctnPol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="ComrclOffer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommercialOfferSharedDataApplicationInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SavngsPol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyLinkedObjectsInputType", propOrder = {
    "pdct",
    "distrbtr",
    "prdctr",
    "cust",
    "grpPol",
    "prtctnPol",
    "comrclOffer",
    "savngsPol"
})
public class SavingsPolicyLinkedObjectsInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct")
    protected ProductSharedDataType pdct;
    @XmlElement(name = "Distrbtr", required = true)
    protected List<PartnerPartyType> distrbtr;
    @XmlElement(name = "Prdctr", required = true)
    protected PartyRoleType prdctr;
    @XmlElement(name = "Cust")
    protected List<PersonIdentificationAndRoleSubRoleType> cust;
    @XmlElement(name = "GrpPol")
    protected ObjectIdentificationType grpPol;
    @XmlElement(name = "PrtctnPol")
    protected ObjectIdentificationType prtctnPol;
    @XmlElement(name = "ComrclOffer")
    protected List<CommercialOfferSharedDataApplicationInputType> comrclOffer;
    @XmlElement(name = "SavngsPol")
    protected ObjectIdentificationType savngsPol;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyLinkedObjectsInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyLinkedObjectsInputType(final ProductSharedDataType pdct, final List<PartnerPartyType> distrbtr, final PartyRoleType prdctr, final List<PersonIdentificationAndRoleSubRoleType> cust, final ObjectIdentificationType grpPol, final ObjectIdentificationType prtctnPol, final List<CommercialOfferSharedDataApplicationInputType> comrclOffer, final ObjectIdentificationType savngsPol) {
        this.pdct = pdct;
        this.distrbtr = distrbtr;
        this.prdctr = prdctr;
        this.cust = cust;
        this.grpPol = grpPol;
        this.prtctnPol = prtctnPol;
        this.comrclOffer = comrclOffer;
        this.savngsPol = savngsPol;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductSharedDataType }
     *     
     */
    public ProductSharedDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductSharedDataType }
     *     
     */
    public void setPdct(ProductSharedDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the distrbtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDistrbtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getDistrbtr() {
        if (distrbtr == null) {
            distrbtr = new ArrayList<PartnerPartyType>();
        }
        return this.distrbtr;
    }

    public boolean isSetDistrbtr() {
        return ((this.distrbtr!= null)&&(!this.distrbtr.isEmpty()));
    }

    public void unsetDistrbtr() {
        this.distrbtr = null;
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    /**
     * Gets the value of the cust property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cust property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCust().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonIdentificationAndRoleSubRoleType }
     * 
     * 
     */
    public List<PersonIdentificationAndRoleSubRoleType> getCust() {
        if (cust == null) {
            cust = new ArrayList<PersonIdentificationAndRoleSubRoleType>();
        }
        return this.cust;
    }

    public boolean isSetCust() {
        return ((this.cust!= null)&&(!this.cust.isEmpty()));
    }

    public void unsetCust() {
        this.cust = null;
    }

    /**
     * Gets the value of the grpPol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getGrpPol() {
        return grpPol;
    }

    /**
     * Sets the value of the grpPol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setGrpPol(ObjectIdentificationType value) {
        this.grpPol = value;
    }

    public boolean isSetGrpPol() {
        return (this.grpPol!= null);
    }

    /**
     * Gets the value of the prtctnPol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPrtctnPol() {
        return prtctnPol;
    }

    /**
     * Sets the value of the prtctnPol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPrtctnPol(ObjectIdentificationType value) {
        this.prtctnPol = value;
    }

    public boolean isSetPrtctnPol() {
        return (this.prtctnPol!= null);
    }

    /**
     * Gets the value of the comrclOffer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comrclOffer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComrclOffer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommercialOfferSharedDataApplicationInputType }
     * 
     * 
     */
    public List<CommercialOfferSharedDataApplicationInputType> getComrclOffer() {
        if (comrclOffer == null) {
            comrclOffer = new ArrayList<CommercialOfferSharedDataApplicationInputType>();
        }
        return this.comrclOffer;
    }

    public boolean isSetComrclOffer() {
        return ((this.comrclOffer!= null)&&(!this.comrclOffer.isEmpty()));
    }

    public void unsetComrclOffer() {
        this.comrclOffer = null;
    }

    /**
     * Gets the value of the savngsPol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getSavngsPol() {
        return savngsPol;
    }

    /**
     * Sets the value of the savngsPol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setSavngsPol(ObjectIdentificationType value) {
        this.savngsPol = value;
    }

    public boolean isSetSavngsPol() {
        return (this.savngsPol!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("distrbtr", distrbtr).add("prdctr", prdctr).add("cust", cust).add("grpPol", grpPol).add("prtctnPol", prtctnPol).add("comrclOffer", comrclOffer).add("savngsPol", savngsPol).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, distrbtr, prdctr, cust, grpPol, prtctnPol, comrclOffer, savngsPol);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyLinkedObjectsInputType o = ((SavingsPolicyLinkedObjectsInputType) other);
        return (((((((Objects.equal(pdct, o.pdct)&&Objects.equal(distrbtr, o.distrbtr))&&Objects.equal(prdctr, o.prdctr))&&Objects.equal(cust, o.cust))&&Objects.equal(grpPol, o.grpPol))&&Objects.equal(prtctnPol, o.prtctnPol))&&Objects.equal(comrclOffer, o.comrclOffer))&&Objects.equal(savngsPol, o.savngsPol));
    }

}
