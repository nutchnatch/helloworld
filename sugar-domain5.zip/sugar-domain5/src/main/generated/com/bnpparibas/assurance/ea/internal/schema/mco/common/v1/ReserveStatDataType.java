
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Statistiques sur les
 * 				provisions liés aux primes
 * 			
 * 
 * <p>Java class for ReserveStatDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReserveStatDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReserveTypeCodeSLN"/&gt;
 *         &lt;element name="RuleCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CalculationMethodCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="AnnualTechnIntrstRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReserveStatDataType", propOrder = {
    "type",
    "ruleCode",
    "amnt",
    "annualTechnIntrstRate"
})
public class ReserveStatDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "RuleCode")
    protected String ruleCode;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "AnnualTechnIntrstRate", required = true)
    protected BasisRateType annualTechnIntrstRate;

    /**
     * Default no-arg constructor
     * 
     */
    public ReserveStatDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ReserveStatDataType(final String type, final String ruleCode, final CurrencyAndAmountType amnt, final BasisRateType annualTechnIntrstRate) {
        this.type = type;
        this.ruleCode = ruleCode;
        this.amnt = amnt;
        this.annualTechnIntrstRate = annualTechnIntrstRate;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the ruleCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRuleCode() {
        return ruleCode;
    }

    /**
     * Sets the value of the ruleCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRuleCode(String value) {
        this.ruleCode = value;
    }

    public boolean isSetRuleCode() {
        return (this.ruleCode!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the annualTechnIntrstRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getAnnualTechnIntrstRate() {
        return annualTechnIntrstRate;
    }

    /**
     * Sets the value of the annualTechnIntrstRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setAnnualTechnIntrstRate(BasisRateType value) {
        this.annualTechnIntrstRate = value;
    }

    public boolean isSetAnnualTechnIntrstRate() {
        return (this.annualTechnIntrstRate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("ruleCode", ruleCode).add("amnt", amnt).add("annualTechnIntrstRate", annualTechnIntrstRate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, ruleCode, amnt, annualTechnIntrstRate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ReserveStatDataType o = ((ReserveStatDataType) other);
        return (((Objects.equal(type, o.type)&&Objects.equal(ruleCode, o.ruleCode))&&Objects.equal(amnt, o.amnt))&&Objects.equal(annualTechnIntrstRate, o.annualTechnIntrstRate));
    }

}
