
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage global dat of the profit or loss
 * 				operation
 * 			
 * 
 * <p>Java class for ProfitAndLossOperationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProfitAndLossOperationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountType"/&gt;
 *         &lt;element name="OpeCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="OpeCtgory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProfitLossOperationCategoryCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProfitAndLossOperationDataType", propOrder = {
    "amnt",
    "opeCurr",
    "effctveDate",
    "opeCtgory"
})
public class ProfitAndLossOperationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Amnt")
    protected double amnt;
    @XmlElement(name = "OpeCurr", required = true)
    protected String opeCurr;
    @XmlElement(name = "EffctveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date effctveDate;
    @XmlElement(name = "OpeCtgory", required = true)
    protected String opeCtgory;

    /**
     * Default no-arg constructor
     * 
     */
    public ProfitAndLossOperationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProfitAndLossOperationDataType(final double amnt, final String opeCurr, final Date effctveDate, final String opeCtgory) {
        this.amnt = amnt;
        this.opeCurr = opeCurr;
        this.effctveDate = effctveDate;
        this.opeCtgory = opeCtgory;
    }

    /**
     * Gets the value of the amnt property.
     * 
     */
    public double getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     */
    public void setAmnt(double value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return true;
    }

    /**
     * Gets the value of the opeCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeCurr() {
        return opeCurr;
    }

    /**
     * Sets the value of the opeCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeCurr(String value) {
        this.opeCurr = value;
    }

    public boolean isSetOpeCurr() {
        return (this.opeCurr!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the opeCtgory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeCtgory() {
        return opeCtgory;
    }

    /**
     * Sets the value of the opeCtgory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeCtgory(String value) {
        this.opeCtgory = value;
    }

    public boolean isSetOpeCtgory() {
        return (this.opeCtgory!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("amnt", amnt).add("opeCurr", opeCurr).add("effctveDate", effctveDate).add("opeCtgory", opeCtgory).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(amnt, opeCurr, effctveDate, opeCtgory);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProfitAndLossOperationDataType o = ((ProfitAndLossOperationDataType) other);
        return (((Objects.equal(amnt, o.amnt)&&Objects.equal(opeCurr, o.opeCurr))&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(opeCtgory, o.opeCtgory));
    }

}
