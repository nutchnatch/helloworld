
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Type to manage premium at cover level
 * 			
 * 
 * <p>Java class for ProtectionPolicyCoverPremiumDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyCoverPremiumDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Nature" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FixdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="FixdRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *         &lt;element name="FrstPremAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="DueDayNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MonthDayCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="DdctbleTaxIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="RevisdPremIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="SplitUp" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FrstPymntDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="InitDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyCoverPremiumDataType", propOrder = {
    "nature",
    "fqcy",
    "amntType",
    "fixdAmnt",
    "fixdRate",
    "frstPremAmnt",
    "paymntDuratn",
    "paymntPrd",
    "dueDayNumb",
    "ddctbleTaxIndic",
    "revisdPremIndic",
    "splitUp",
    "status",
    "frstPymntDate",
    "initDuratn"
})
public class ProtectionPolicyCoverPremiumDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Nature")
    protected String nature;
    @XmlElement(name = "Fqcy")
    protected String fqcy;
    @XmlElement(name = "AmntType")
    protected String amntType;
    @XmlElement(name = "FixdAmnt")
    protected CurrencyAndAmountType fixdAmnt;
    @XmlElement(name = "FixdRate")
    protected BasisRateType fixdRate;
    @XmlElement(name = "FrstPremAmnt")
    protected CurrencyAndAmountType frstPremAmnt;
    @XmlElement(name = "PaymntDuratn")
    protected DurationType paymntDuratn;
    @XmlElement(name = "PaymntPrd")
    protected DatePeriodType paymntPrd;
    @XmlElement(name = "DueDayNumb")
    protected String dueDayNumb;
    @XmlElement(name = "DdctbleTaxIndic")
    protected String ddctbleTaxIndic;
    @XmlElement(name = "RevisdPremIndic")
    protected String revisdPremIndic;
    @XmlElement(name = "SplitUp")
    protected String splitUp;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "FrstPymntDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date frstPymntDate;
    @XmlElement(name = "InitDuratn")
    protected DurationType initDuratn;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyCoverPremiumDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyCoverPremiumDataType(final String nature, final String fqcy, final String amntType, final CurrencyAndAmountType fixdAmnt, final BasisRateType fixdRate, final CurrencyAndAmountType frstPremAmnt, final DurationType paymntDuratn, final DatePeriodType paymntPrd, final String dueDayNumb, final String ddctbleTaxIndic, final String revisdPremIndic, final String splitUp, final String status, final Date frstPymntDate, final DurationType initDuratn) {
        this.nature = nature;
        this.fqcy = fqcy;
        this.amntType = amntType;
        this.fixdAmnt = fixdAmnt;
        this.fixdRate = fixdRate;
        this.frstPremAmnt = frstPremAmnt;
        this.paymntDuratn = paymntDuratn;
        this.paymntPrd = paymntPrd;
        this.dueDayNumb = dueDayNumb;
        this.ddctbleTaxIndic = ddctbleTaxIndic;
        this.revisdPremIndic = revisdPremIndic;
        this.splitUp = splitUp;
        this.status = status;
        this.frstPymntDate = frstPymntDate;
        this.initDuratn = initDuratn;
    }

    /**
     * Gets the value of the nature property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNature() {
        return nature;
    }

    /**
     * Sets the value of the nature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNature(String value) {
        this.nature = value;
    }

    public boolean isSetNature() {
        return (this.nature!= null);
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the amntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmntType() {
        return amntType;
    }

    /**
     * Sets the value of the amntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmntType(String value) {
        this.amntType = value;
    }

    public boolean isSetAmntType() {
        return (this.amntType!= null);
    }

    /**
     * Gets the value of the fixdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFixdAmnt() {
        return fixdAmnt;
    }

    /**
     * Sets the value of the fixdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFixdAmnt(CurrencyAndAmountType value) {
        this.fixdAmnt = value;
    }

    public boolean isSetFixdAmnt() {
        return (this.fixdAmnt!= null);
    }

    /**
     * Gets the value of the fixdRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getFixdRate() {
        return fixdRate;
    }

    /**
     * Sets the value of the fixdRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setFixdRate(BasisRateType value) {
        this.fixdRate = value;
    }

    public boolean isSetFixdRate() {
        return (this.fixdRate!= null);
    }

    /**
     * Gets the value of the frstPremAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFrstPremAmnt() {
        return frstPremAmnt;
    }

    /**
     * Sets the value of the frstPremAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFrstPremAmnt(CurrencyAndAmountType value) {
        this.frstPremAmnt = value;
    }

    public boolean isSetFrstPremAmnt() {
        return (this.frstPremAmnt!= null);
    }

    /**
     * Gets the value of the paymntDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getPaymntDuratn() {
        return paymntDuratn;
    }

    /**
     * Sets the value of the paymntDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setPaymntDuratn(DurationType value) {
        this.paymntDuratn = value;
    }

    public boolean isSetPaymntDuratn() {
        return (this.paymntDuratn!= null);
    }

    /**
     * Gets the value of the paymntPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getPaymntPrd() {
        return paymntPrd;
    }

    /**
     * Sets the value of the paymntPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setPaymntPrd(DatePeriodType value) {
        this.paymntPrd = value;
    }

    public boolean isSetPaymntPrd() {
        return (this.paymntPrd!= null);
    }

    /**
     * Gets the value of the dueDayNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDueDayNumb() {
        return dueDayNumb;
    }

    /**
     * Sets the value of the dueDayNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDueDayNumb(String value) {
        this.dueDayNumb = value;
    }

    public boolean isSetDueDayNumb() {
        return (this.dueDayNumb!= null);
    }

    /**
     * Gets the value of the ddctbleTaxIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDdctbleTaxIndic() {
        return ddctbleTaxIndic;
    }

    /**
     * Sets the value of the ddctbleTaxIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDdctbleTaxIndic(String value) {
        this.ddctbleTaxIndic = value;
    }

    public boolean isSetDdctbleTaxIndic() {
        return (this.ddctbleTaxIndic!= null);
    }

    /**
     * Gets the value of the revisdPremIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRevisdPremIndic() {
        return revisdPremIndic;
    }

    /**
     * Sets the value of the revisdPremIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRevisdPremIndic(String value) {
        this.revisdPremIndic = value;
    }

    public boolean isSetRevisdPremIndic() {
        return (this.revisdPremIndic!= null);
    }

    /**
     * Gets the value of the splitUp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitUp() {
        return splitUp;
    }

    /**
     * Sets the value of the splitUp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitUp(String value) {
        this.splitUp = value;
    }

    public boolean isSetSplitUp() {
        return (this.splitUp!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the frstPymntDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getFrstPymntDate() {
        return frstPymntDate;
    }

    /**
     * Sets the value of the frstPymntDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrstPymntDate(Date value) {
        this.frstPymntDate = value;
    }

    public boolean isSetFrstPymntDate() {
        return (this.frstPymntDate!= null);
    }

    /**
     * Gets the value of the initDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getInitDuratn() {
        return initDuratn;
    }

    /**
     * Sets the value of the initDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setInitDuratn(DurationType value) {
        this.initDuratn = value;
    }

    public boolean isSetInitDuratn() {
        return (this.initDuratn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("nature", nature).add("fqcy", fqcy).add("amntType", amntType).add("fixdAmnt", fixdAmnt).add("fixdRate", fixdRate).add("frstPremAmnt", frstPremAmnt).add("paymntDuratn", paymntDuratn).add("paymntPrd", paymntPrd).add("dueDayNumb", dueDayNumb).add("ddctbleTaxIndic", ddctbleTaxIndic).add("revisdPremIndic", revisdPremIndic).add("splitUp", splitUp).add("status", status).add("frstPymntDate", frstPymntDate).add("initDuratn", initDuratn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(nature, fqcy, amntType, fixdAmnt, fixdRate, frstPremAmnt, paymntDuratn, paymntPrd, dueDayNumb, ddctbleTaxIndic, revisdPremIndic, splitUp, status, frstPymntDate, initDuratn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyCoverPremiumDataType o = ((ProtectionPolicyCoverPremiumDataType) other);
        return ((((((((((((((Objects.equal(nature, o.nature)&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(amntType, o.amntType))&&Objects.equal(fixdAmnt, o.fixdAmnt))&&Objects.equal(fixdRate, o.fixdRate))&&Objects.equal(frstPremAmnt, o.frstPremAmnt))&&Objects.equal(paymntDuratn, o.paymntDuratn))&&Objects.equal(paymntPrd, o.paymntPrd))&&Objects.equal(dueDayNumb, o.dueDayNumb))&&Objects.equal(ddctbleTaxIndic, o.ddctbleTaxIndic))&&Objects.equal(revisdPremIndic, o.revisdPremIndic))&&Objects.equal(splitUp, o.splitUp))&&Objects.equal(status, o.status))&&Objects.equal(frstPymntDate, o.frstPymntDate))&&Objects.equal(initDuratn, o.initDuratn));
    }

}
