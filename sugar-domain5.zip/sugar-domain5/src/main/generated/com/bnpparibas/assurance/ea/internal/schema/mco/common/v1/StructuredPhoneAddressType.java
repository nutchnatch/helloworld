
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Structured phone contact
 * 
 * <p>Java class for StructuredPhoneAddressType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StructuredPhoneAddressType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CntryNumcCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryDialingCodeSLN"/&gt;
 *         &lt;element name="AreaCodeNumb"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="10"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Numb"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ExtnsnNumb"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StructuredPhoneAddressType", propOrder = {
    "cntryNumcCode",
    "areaCodeNumb",
    "numb",
    "extnsnNumb"
})
public class StructuredPhoneAddressType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CntryNumcCode", required = true)
    protected String cntryNumcCode;
    @XmlElement(name = "AreaCodeNumb", required = true)
    protected String areaCodeNumb;
    @XmlElement(name = "Numb", required = true)
    protected String numb;
    @XmlElement(name = "ExtnsnNumb", required = true)
    protected String extnsnNumb;

    /**
     * Default no-arg constructor
     * 
     */
    public StructuredPhoneAddressType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public StructuredPhoneAddressType(final String cntryNumcCode, final String areaCodeNumb, final String numb, final String extnsnNumb) {
        this.cntryNumcCode = cntryNumcCode;
        this.areaCodeNumb = areaCodeNumb;
        this.numb = numb;
        this.extnsnNumb = extnsnNumb;
    }

    /**
     * Gets the value of the cntryNumcCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCntryNumcCode() {
        return cntryNumcCode;
    }

    /**
     * Sets the value of the cntryNumcCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCntryNumcCode(String value) {
        this.cntryNumcCode = value;
    }

    public boolean isSetCntryNumcCode() {
        return (this.cntryNumcCode!= null);
    }

    /**
     * Gets the value of the areaCodeNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAreaCodeNumb() {
        return areaCodeNumb;
    }

    /**
     * Sets the value of the areaCodeNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAreaCodeNumb(String value) {
        this.areaCodeNumb = value;
    }

    public boolean isSetAreaCodeNumb() {
        return (this.areaCodeNumb!= null);
    }

    /**
     * Gets the value of the numb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumb() {
        return numb;
    }

    /**
     * Sets the value of the numb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumb(String value) {
        this.numb = value;
    }

    public boolean isSetNumb() {
        return (this.numb!= null);
    }

    /**
     * Gets the value of the extnsnNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtnsnNumb() {
        return extnsnNumb;
    }

    /**
     * Sets the value of the extnsnNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtnsnNumb(String value) {
        this.extnsnNumb = value;
    }

    public boolean isSetExtnsnNumb() {
        return (this.extnsnNumb!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cntryNumcCode", cntryNumcCode).add("areaCodeNumb", areaCodeNumb).add("numb", numb).add("extnsnNumb", extnsnNumb).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cntryNumcCode, areaCodeNumb, numb, extnsnNumb);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final StructuredPhoneAddressType o = ((StructuredPhoneAddressType) other);
        return (((Objects.equal(cntryNumcCode, o.cntryNumcCode)&&Objects.equal(areaCodeNumb, o.areaCodeNumb))&&Objects.equal(numb, o.numb))&&Objects.equal(extnsnNumb, o.extnsnNumb));
    }

}
