
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data carried by the cover for
 * 				savings policy
 * 			
 * 
 * <p>Java class for SavingsCoverDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsCoverDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovrgeCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode" minOccurs="0"/&gt;
 *         &lt;element name="LifeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LifeIndicatorCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="PremFqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="InsrdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CovPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentModeCode" minOccurs="0"/&gt;
 *         &lt;element name="PremAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="PremAmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsCoverDataInputType", propOrder = {
    "covrgeCode",
    "lifeIndic",
    "premFqcy",
    "insrdAmnt",
    "benfciaryType",
    "covPrd",
    "duratn",
    "paymntMode",
    "premAmnt",
    "premAmntType"
})
public class SavingsCoverDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovrgeCode")
    protected String covrgeCode;
    @XmlElement(name = "LifeIndic")
    protected String lifeIndic;
    @XmlElement(name = "PremFqcy")
    protected String premFqcy;
    @XmlElement(name = "InsrdAmnt")
    protected CurrencyAndAmountType insrdAmnt;
    @XmlElement(name = "BenfciaryType")
    protected String benfciaryType;
    @XmlElement(name = "CovPrd")
    protected OptionalDatePeriodType covPrd;
    @XmlElement(name = "Duratn")
    protected DurationType duratn;
    @XmlElement(name = "PaymntMode")
    protected String paymntMode;
    @XmlElement(name = "PremAmnt")
    protected CurrencyAndAmountType premAmnt;
    @XmlElement(name = "PremAmntType")
    protected String premAmntType;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsCoverDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsCoverDataInputType(final String covrgeCode, final String lifeIndic, final String premFqcy, final CurrencyAndAmountType insrdAmnt, final String benfciaryType, final OptionalDatePeriodType covPrd, final DurationType duratn, final String paymntMode, final CurrencyAndAmountType premAmnt, final String premAmntType) {
        this.covrgeCode = covrgeCode;
        this.lifeIndic = lifeIndic;
        this.premFqcy = premFqcy;
        this.insrdAmnt = insrdAmnt;
        this.benfciaryType = benfciaryType;
        this.covPrd = covPrd;
        this.duratn = duratn;
        this.paymntMode = paymntMode;
        this.premAmnt = premAmnt;
        this.premAmntType = premAmntType;
    }

    /**
     * Gets the value of the covrgeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovrgeCode() {
        return covrgeCode;
    }

    /**
     * Sets the value of the covrgeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovrgeCode(String value) {
        this.covrgeCode = value;
    }

    public boolean isSetCovrgeCode() {
        return (this.covrgeCode!= null);
    }

    /**
     * Gets the value of the lifeIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifeIndic() {
        return lifeIndic;
    }

    /**
     * Sets the value of the lifeIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifeIndic(String value) {
        this.lifeIndic = value;
    }

    public boolean isSetLifeIndic() {
        return (this.lifeIndic!= null);
    }

    /**
     * Gets the value of the premFqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremFqcy() {
        return premFqcy;
    }

    /**
     * Sets the value of the premFqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremFqcy(String value) {
        this.premFqcy = value;
    }

    public boolean isSetPremFqcy() {
        return (this.premFqcy!= null);
    }

    /**
     * Gets the value of the insrdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInsrdAmnt() {
        return insrdAmnt;
    }

    /**
     * Sets the value of the insrdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInsrdAmnt(CurrencyAndAmountType value) {
        this.insrdAmnt = value;
    }

    public boolean isSetInsrdAmnt() {
        return (this.insrdAmnt!= null);
    }

    /**
     * Gets the value of the benfciaryType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBenfciaryType() {
        return benfciaryType;
    }

    /**
     * Sets the value of the benfciaryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBenfciaryType(String value) {
        this.benfciaryType = value;
    }

    public boolean isSetBenfciaryType() {
        return (this.benfciaryType!= null);
    }

    /**
     * Gets the value of the covPrd property.
     * 
     * @return
     *     possible object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public OptionalDatePeriodType getCovPrd() {
        return covPrd;
    }

    /**
     * Sets the value of the covPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public void setCovPrd(OptionalDatePeriodType value) {
        this.covPrd = value;
    }

    public boolean isSetCovPrd() {
        return (this.covPrd!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    /**
     * Gets the value of the paymntMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymntMode() {
        return paymntMode;
    }

    /**
     * Sets the value of the paymntMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymntMode(String value) {
        this.paymntMode = value;
    }

    public boolean isSetPaymntMode() {
        return (this.paymntMode!= null);
    }

    /**
     * Gets the value of the premAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPremAmnt() {
        return premAmnt;
    }

    /**
     * Sets the value of the premAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPremAmnt(CurrencyAndAmountType value) {
        this.premAmnt = value;
    }

    public boolean isSetPremAmnt() {
        return (this.premAmnt!= null);
    }

    /**
     * Gets the value of the premAmntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremAmntType() {
        return premAmntType;
    }

    /**
     * Sets the value of the premAmntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremAmntType(String value) {
        this.premAmntType = value;
    }

    public boolean isSetPremAmntType() {
        return (this.premAmntType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covrgeCode", covrgeCode).add("lifeIndic", lifeIndic).add("premFqcy", premFqcy).add("insrdAmnt", insrdAmnt).add("benfciaryType", benfciaryType).add("covPrd", covPrd).add("duratn", duratn).add("paymntMode", paymntMode).add("premAmnt", premAmnt).add("premAmntType", premAmntType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covrgeCode, lifeIndic, premFqcy, insrdAmnt, benfciaryType, covPrd, duratn, paymntMode, premAmnt, premAmntType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsCoverDataInputType o = ((SavingsCoverDataInputType) other);
        return (((((((((Objects.equal(covrgeCode, o.covrgeCode)&&Objects.equal(lifeIndic, o.lifeIndic))&&Objects.equal(premFqcy, o.premFqcy))&&Objects.equal(insrdAmnt, o.insrdAmnt))&&Objects.equal(benfciaryType, o.benfciaryType))&&Objects.equal(covPrd, o.covPrd))&&Objects.equal(duratn, o.duratn))&&Objects.equal(paymntMode, o.paymntMode))&&Objects.equal(premAmnt, o.premAmnt))&&Objects.equal(premAmntType, o.premAmntType));
    }

}
