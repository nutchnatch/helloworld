
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage global data for sales and after
 * 				sales requests linked to a savings policy
 * 			
 * 
 * <p>Java class for SavingsPolicyDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SignDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ReciptDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="PolCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ClosngClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoSubscriptionClosingClauseCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="SigndSubscrptnDocIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyDataInputType", propOrder = {
    "signDate",
    "reciptDate",
    "polCurr",
    "closngClause",
    "duratn",
    "signdSubscrptnDocIndic"
})
public class SavingsPolicyDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SignDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date signDate;
    @XmlElement(name = "ReciptDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date reciptDate;
    @XmlElement(name = "PolCurr")
    protected String polCurr;
    @XmlElement(name = "ClosngClause")
    protected String closngClause;
    @XmlElement(name = "Duratn")
    protected DurationType duratn;
    @XmlElement(name = "SigndSubscrptnDocIndic")
    protected String signdSubscrptnDocIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyDataInputType(final Date signDate, final Date reciptDate, final String polCurr, final String closngClause, final DurationType duratn, final String signdSubscrptnDocIndic) {
        this.signDate = signDate;
        this.reciptDate = reciptDate;
        this.polCurr = polCurr;
        this.closngClause = closngClause;
        this.duratn = duratn;
        this.signdSubscrptnDocIndic = signdSubscrptnDocIndic;
    }

    /**
     * Gets the value of the signDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSignDate() {
        return signDate;
    }

    /**
     * Sets the value of the signDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignDate(Date value) {
        this.signDate = value;
    }

    public boolean isSetSignDate() {
        return (this.signDate!= null);
    }

    /**
     * Gets the value of the reciptDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getReciptDate() {
        return reciptDate;
    }

    /**
     * Sets the value of the reciptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReciptDate(Date value) {
        this.reciptDate = value;
    }

    public boolean isSetReciptDate() {
        return (this.reciptDate!= null);
    }

    /**
     * Gets the value of the polCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolCurr() {
        return polCurr;
    }

    /**
     * Sets the value of the polCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolCurr(String value) {
        this.polCurr = value;
    }

    public boolean isSetPolCurr() {
        return (this.polCurr!= null);
    }

    /**
     * Gets the value of the closngClause property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosngClause() {
        return closngClause;
    }

    /**
     * Sets the value of the closngClause property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosngClause(String value) {
        this.closngClause = value;
    }

    public boolean isSetClosngClause() {
        return (this.closngClause!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    /**
     * Gets the value of the signdSubscrptnDocIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSigndSubscrptnDocIndic() {
        return signdSubscrptnDocIndic;
    }

    /**
     * Sets the value of the signdSubscrptnDocIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSigndSubscrptnDocIndic(String value) {
        this.signdSubscrptnDocIndic = value;
    }

    public boolean isSetSigndSubscrptnDocIndic() {
        return (this.signdSubscrptnDocIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("signDate", signDate).add("reciptDate", reciptDate).add("polCurr", polCurr).add("closngClause", closngClause).add("duratn", duratn).add("signdSubscrptnDocIndic", signdSubscrptnDocIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(signDate, reciptDate, polCurr, closngClause, duratn, signdSubscrptnDocIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyDataInputType o = ((SavingsPolicyDataInputType) other);
        return (((((Objects.equal(signDate, o.signDate)&&Objects.equal(reciptDate, o.reciptDate))&&Objects.equal(polCurr, o.polCurr))&&Objects.equal(closngClause, o.closngClause))&&Objects.equal(duratn, o.duratn))&&Objects.equal(signdSubscrptnDocIndic, o.signdSubscrptnDocIndic));
    }

}
