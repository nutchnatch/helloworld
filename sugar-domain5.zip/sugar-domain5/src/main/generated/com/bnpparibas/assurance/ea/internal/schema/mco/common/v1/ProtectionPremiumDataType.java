
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * To manage global data of protection premium
 * 			
 * 
 * <p>Java class for ProtectionPremiumDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPremiumDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DueDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="PremCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="NetAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="GrossAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="PureAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="PrdicPremIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN"/&gt;
 *         &lt;element name="RecvryNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="AddAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AdditionalAmountType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PremFqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CovrdPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="FrstPremIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPremiumDataType", propOrder = {
    "dueDate",
    "premCurr",
    "netAmnt",
    "grossAmnt",
    "pureAmnt",
    "prdicPremIndic",
    "recvryNumb",
    "addAmnt",
    "premFqcy",
    "covrdPrd",
    "frstPremIndic"
})
public class ProtectionPremiumDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "DueDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date dueDate;
    @XmlElement(name = "PremCurr", required = true)
    protected String premCurr;
    @XmlElement(name = "NetAmnt", required = true)
    protected CurrencyAndAmountType netAmnt;
    @XmlElement(name = "GrossAmnt", required = true)
    protected CurrencyAndAmountType grossAmnt;
    @XmlElement(name = "PureAmnt")
    protected CurrencyAndAmountType pureAmnt;
    @XmlElement(name = "PrdicPremIndic", required = true)
    protected String prdicPremIndic;
    @XmlElement(name = "RecvryNumb")
    protected BigInteger recvryNumb;
    @XmlElement(name = "AddAmnt")
    protected List<AdditionalAmountType> addAmnt;
    @XmlElement(name = "PremFqcy")
    protected String premFqcy;
    @XmlElement(name = "CovrdPrd")
    protected DatePeriodType covrdPrd;
    @XmlElement(name = "FrstPremIndic")
    protected String frstPremIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPremiumDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPremiumDataType(final Date dueDate, final String premCurr, final CurrencyAndAmountType netAmnt, final CurrencyAndAmountType grossAmnt, final CurrencyAndAmountType pureAmnt, final String prdicPremIndic, final BigInteger recvryNumb, final List<AdditionalAmountType> addAmnt, final String premFqcy, final DatePeriodType covrdPrd, final String frstPremIndic) {
        this.dueDate = dueDate;
        this.premCurr = premCurr;
        this.netAmnt = netAmnt;
        this.grossAmnt = grossAmnt;
        this.pureAmnt = pureAmnt;
        this.prdicPremIndic = prdicPremIndic;
        this.recvryNumb = recvryNumb;
        this.addAmnt = addAmnt;
        this.premFqcy = premFqcy;
        this.covrdPrd = covrdPrd;
        this.frstPremIndic = frstPremIndic;
    }

    /**
     * Gets the value of the dueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDueDate() {
        return dueDate;
    }

    /**
     * Sets the value of the dueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDueDate(Date value) {
        this.dueDate = value;
    }

    public boolean isSetDueDate() {
        return (this.dueDate!= null);
    }

    /**
     * Gets the value of the premCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremCurr() {
        return premCurr;
    }

    /**
     * Sets the value of the premCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremCurr(String value) {
        this.premCurr = value;
    }

    public boolean isSetPremCurr() {
        return (this.premCurr!= null);
    }

    /**
     * Gets the value of the netAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getNetAmnt() {
        return netAmnt;
    }

    /**
     * Sets the value of the netAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setNetAmnt(CurrencyAndAmountType value) {
        this.netAmnt = value;
    }

    public boolean isSetNetAmnt() {
        return (this.netAmnt!= null);
    }

    /**
     * Gets the value of the grossAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getGrossAmnt() {
        return grossAmnt;
    }

    /**
     * Sets the value of the grossAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setGrossAmnt(CurrencyAndAmountType value) {
        this.grossAmnt = value;
    }

    public boolean isSetGrossAmnt() {
        return (this.grossAmnt!= null);
    }

    /**
     * Gets the value of the pureAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPureAmnt() {
        return pureAmnt;
    }

    /**
     * Sets the value of the pureAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPureAmnt(CurrencyAndAmountType value) {
        this.pureAmnt = value;
    }

    public boolean isSetPureAmnt() {
        return (this.pureAmnt!= null);
    }

    /**
     * Gets the value of the prdicPremIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrdicPremIndic() {
        return prdicPremIndic;
    }

    /**
     * Sets the value of the prdicPremIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrdicPremIndic(String value) {
        this.prdicPremIndic = value;
    }

    public boolean isSetPrdicPremIndic() {
        return (this.prdicPremIndic!= null);
    }

    /**
     * Gets the value of the recvryNumb property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRecvryNumb() {
        return recvryNumb;
    }

    /**
     * Sets the value of the recvryNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRecvryNumb(BigInteger value) {
        this.recvryNumb = value;
    }

    public boolean isSetRecvryNumb() {
        return (this.recvryNumb!= null);
    }

    /**
     * Gets the value of the addAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmountType }
     * 
     * 
     */
    public List<AdditionalAmountType> getAddAmnt() {
        if (addAmnt == null) {
            addAmnt = new ArrayList<AdditionalAmountType>();
        }
        return this.addAmnt;
    }

    public boolean isSetAddAmnt() {
        return ((this.addAmnt!= null)&&(!this.addAmnt.isEmpty()));
    }

    public void unsetAddAmnt() {
        this.addAmnt = null;
    }

    /**
     * Gets the value of the premFqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPremFqcy() {
        return premFqcy;
    }

    /**
     * Sets the value of the premFqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPremFqcy(String value) {
        this.premFqcy = value;
    }

    public boolean isSetPremFqcy() {
        return (this.premFqcy!= null);
    }

    /**
     * Gets the value of the covrdPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getCovrdPrd() {
        return covrdPrd;
    }

    /**
     * Sets the value of the covrdPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setCovrdPrd(DatePeriodType value) {
        this.covrdPrd = value;
    }

    public boolean isSetCovrdPrd() {
        return (this.covrdPrd!= null);
    }

    /**
     * Gets the value of the frstPremIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrstPremIndic() {
        return frstPremIndic;
    }

    /**
     * Sets the value of the frstPremIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrstPremIndic(String value) {
        this.frstPremIndic = value;
    }

    public boolean isSetFrstPremIndic() {
        return (this.frstPremIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("dueDate", dueDate).add("premCurr", premCurr).add("netAmnt", netAmnt).add("grossAmnt", grossAmnt).add("pureAmnt", pureAmnt).add("prdicPremIndic", prdicPremIndic).add("recvryNumb", recvryNumb).add("addAmnt", addAmnt).add("premFqcy", premFqcy).add("covrdPrd", covrdPrd).add("frstPremIndic", frstPremIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(dueDate, premCurr, netAmnt, grossAmnt, pureAmnt, prdicPremIndic, recvryNumb, addAmnt, premFqcy, covrdPrd, frstPremIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPremiumDataType o = ((ProtectionPremiumDataType) other);
        return ((((((((((Objects.equal(dueDate, o.dueDate)&&Objects.equal(premCurr, o.premCurr))&&Objects.equal(netAmnt, o.netAmnt))&&Objects.equal(grossAmnt, o.grossAmnt))&&Objects.equal(pureAmnt, o.pureAmnt))&&Objects.equal(prdicPremIndic, o.prdicPremIndic))&&Objects.equal(recvryNumb, o.recvryNumb))&&Objects.equal(addAmnt, o.addAmnt))&&Objects.equal(premFqcy, o.premFqcy))&&Objects.equal(covrdPrd, o.covrdPrd))&&Objects.equal(frstPremIndic, o.frstPremIndic));
    }

}
