
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Cover data
 * 
 * <p>Java class for ProductCoverDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductCoverDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="MarktngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="MndtryIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="InsrdEntryMinAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="InsrdEntryMaxAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="InsrdMinAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="InsrdMaxAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="RfndBasisAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="RfndRuleCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CalculationMethodCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductCoverDataType", propOrder = {
    "name",
    "marktngPrd",
    "mndtryIndic",
    "insrdEntryMinAge",
    "insrdEntryMaxAge",
    "insrdMinAmnt",
    "insrdMaxAmnt",
    "rfndBasisAmnt",
    "rfndRuleCode"
})
public class ProductCoverDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "MarktngPrd")
    protected DatePeriodType marktngPrd;
    @XmlElement(name = "MndtryIndic")
    protected String mndtryIndic;
    @XmlElement(name = "InsrdEntryMinAge")
    protected BigInteger insrdEntryMinAge;
    @XmlElement(name = "InsrdEntryMaxAge")
    protected BigInteger insrdEntryMaxAge;
    @XmlElement(name = "InsrdMinAmnt")
    protected CurrencyAndAmountType insrdMinAmnt;
    @XmlElement(name = "InsrdMaxAmnt")
    protected CurrencyAndAmountType insrdMaxAmnt;
    @XmlElement(name = "RfndBasisAmnt")
    protected CurrencyAndAmountType rfndBasisAmnt;
    @XmlElement(name = "RfndRuleCode")
    protected String rfndRuleCode;

    /**
     * Default no-arg constructor
     * 
     */
    public ProductCoverDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProductCoverDataType(final String name, final DatePeriodType marktngPrd, final String mndtryIndic, final BigInteger insrdEntryMinAge, final BigInteger insrdEntryMaxAge, final CurrencyAndAmountType insrdMinAmnt, final CurrencyAndAmountType insrdMaxAmnt, final CurrencyAndAmountType rfndBasisAmnt, final String rfndRuleCode) {
        this.name = name;
        this.marktngPrd = marktngPrd;
        this.mndtryIndic = mndtryIndic;
        this.insrdEntryMinAge = insrdEntryMinAge;
        this.insrdEntryMaxAge = insrdEntryMaxAge;
        this.insrdMinAmnt = insrdMinAmnt;
        this.insrdMaxAmnt = insrdMaxAmnt;
        this.rfndBasisAmnt = rfndBasisAmnt;
        this.rfndRuleCode = rfndRuleCode;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the marktngPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getMarktngPrd() {
        return marktngPrd;
    }

    /**
     * Sets the value of the marktngPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setMarktngPrd(DatePeriodType value) {
        this.marktngPrd = value;
    }

    public boolean isSetMarktngPrd() {
        return (this.marktngPrd!= null);
    }

    /**
     * Gets the value of the mndtryIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMndtryIndic() {
        return mndtryIndic;
    }

    /**
     * Sets the value of the mndtryIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMndtryIndic(String value) {
        this.mndtryIndic = value;
    }

    public boolean isSetMndtryIndic() {
        return (this.mndtryIndic!= null);
    }

    /**
     * Gets the value of the insrdEntryMinAge property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getInsrdEntryMinAge() {
        return insrdEntryMinAge;
    }

    /**
     * Sets the value of the insrdEntryMinAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setInsrdEntryMinAge(BigInteger value) {
        this.insrdEntryMinAge = value;
    }

    public boolean isSetInsrdEntryMinAge() {
        return (this.insrdEntryMinAge!= null);
    }

    /**
     * Gets the value of the insrdEntryMaxAge property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getInsrdEntryMaxAge() {
        return insrdEntryMaxAge;
    }

    /**
     * Sets the value of the insrdEntryMaxAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setInsrdEntryMaxAge(BigInteger value) {
        this.insrdEntryMaxAge = value;
    }

    public boolean isSetInsrdEntryMaxAge() {
        return (this.insrdEntryMaxAge!= null);
    }

    /**
     * Gets the value of the insrdMinAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInsrdMinAmnt() {
        return insrdMinAmnt;
    }

    /**
     * Sets the value of the insrdMinAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInsrdMinAmnt(CurrencyAndAmountType value) {
        this.insrdMinAmnt = value;
    }

    public boolean isSetInsrdMinAmnt() {
        return (this.insrdMinAmnt!= null);
    }

    /**
     * Gets the value of the insrdMaxAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInsrdMaxAmnt() {
        return insrdMaxAmnt;
    }

    /**
     * Sets the value of the insrdMaxAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInsrdMaxAmnt(CurrencyAndAmountType value) {
        this.insrdMaxAmnt = value;
    }

    public boolean isSetInsrdMaxAmnt() {
        return (this.insrdMaxAmnt!= null);
    }

    /**
     * Gets the value of the rfndBasisAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getRfndBasisAmnt() {
        return rfndBasisAmnt;
    }

    /**
     * Sets the value of the rfndBasisAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setRfndBasisAmnt(CurrencyAndAmountType value) {
        this.rfndBasisAmnt = value;
    }

    public boolean isSetRfndBasisAmnt() {
        return (this.rfndBasisAmnt!= null);
    }

    /**
     * Gets the value of the rfndRuleCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRfndRuleCode() {
        return rfndRuleCode;
    }

    /**
     * Sets the value of the rfndRuleCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRfndRuleCode(String value) {
        this.rfndRuleCode = value;
    }

    public boolean isSetRfndRuleCode() {
        return (this.rfndRuleCode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("marktngPrd", marktngPrd).add("mndtryIndic", mndtryIndic).add("insrdEntryMinAge", insrdEntryMinAge).add("insrdEntryMaxAge", insrdEntryMaxAge).add("insrdMinAmnt", insrdMinAmnt).add("insrdMaxAmnt", insrdMaxAmnt).add("rfndBasisAmnt", rfndBasisAmnt).add("rfndRuleCode", rfndRuleCode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, marktngPrd, mndtryIndic, insrdEntryMinAge, insrdEntryMaxAge, insrdMinAmnt, insrdMaxAmnt, rfndBasisAmnt, rfndRuleCode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProductCoverDataType o = ((ProductCoverDataType) other);
        return ((((((((Objects.equal(name, o.name)&&Objects.equal(marktngPrd, o.marktngPrd))&&Objects.equal(mndtryIndic, o.mndtryIndic))&&Objects.equal(insrdEntryMinAge, o.insrdEntryMinAge))&&Objects.equal(insrdEntryMaxAge, o.insrdEntryMaxAge))&&Objects.equal(insrdMinAmnt, o.insrdMinAmnt))&&Objects.equal(insrdMaxAmnt, o.insrdMaxAmnt))&&Objects.equal(rfndBasisAmnt, o.rfndBasisAmnt))&&Objects.equal(rfndRuleCode, o.rfndRuleCode));
    }

}
