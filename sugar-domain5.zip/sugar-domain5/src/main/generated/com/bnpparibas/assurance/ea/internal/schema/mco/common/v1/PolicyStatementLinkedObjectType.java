
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a policy statement has
 * 				dependencies
 * 			
 * 
 * <p>Java class for PolicyStatementLinkedObjectType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyStatementLinkedObjectType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductAndLegalSchemeDataType"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductIdentificationAndHierarchyDataType" minOccurs="0"/&gt;
 *         &lt;element name="Partnr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Prdcr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyStatementLinkedObjectType", propOrder = {
    "pdct",
    "corePdct",
    "partnr",
    "prdcr",
    "pol"
})
public class PolicyStatementLinkedObjectType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct", required = true)
    protected ProductAndLegalSchemeDataType pdct;
    @XmlElement(name = "CorePdct")
    protected CoreProductIdentificationAndHierarchyDataType corePdct;
    @XmlElement(name = "Partnr")
    protected List<PartnerPartyType> partnr;
    @XmlElement(name = "Prdcr")
    protected PartyRoleType prdcr;
    @XmlElement(name = "Pol", required = true)
    protected ObjectIdentificationType pol;

    /**
     * Default no-arg constructor
     * 
     */
    public PolicyStatementLinkedObjectType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PolicyStatementLinkedObjectType(final ProductAndLegalSchemeDataType pdct, final CoreProductIdentificationAndHierarchyDataType corePdct, final List<PartnerPartyType> partnr, final PartyRoleType prdcr, final ObjectIdentificationType pol) {
        this.pdct = pdct;
        this.corePdct = corePdct;
        this.partnr = partnr;
        this.prdcr = prdcr;
        this.pol = pol;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductAndLegalSchemeDataType }
     *     
     */
    public ProductAndLegalSchemeDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductAndLegalSchemeDataType }
     *     
     */
    public void setPdct(ProductAndLegalSchemeDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public CoreProductIdentificationAndHierarchyDataType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public void setCorePdct(CoreProductIdentificationAndHierarchyDataType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    /**
     * Gets the value of the partnr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partnr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartnr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getPartnr() {
        if (partnr == null) {
            partnr = new ArrayList<PartnerPartyType>();
        }
        return this.partnr;
    }

    public boolean isSetPartnr() {
        return ((this.partnr!= null)&&(!this.partnr.isEmpty()));
    }

    public void unsetPartnr() {
        this.partnr = null;
    }

    /**
     * Gets the value of the prdcr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdcr() {
        return prdcr;
    }

    /**
     * Sets the value of the prdcr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdcr(PartyRoleType value) {
        this.prdcr = value;
    }

    public boolean isSetPrdcr() {
        return (this.prdcr!= null);
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("corePdct", corePdct).add("partnr", partnr).add("prdcr", prdcr).add("pol", pol).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, corePdct, partnr, prdcr, pol);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PolicyStatementLinkedObjectType o = ((PolicyStatementLinkedObjectType) other);
        return ((((Objects.equal(pdct, o.pdct)&&Objects.equal(corePdct, o.corePdct))&&Objects.equal(partnr, o.partnr))&&Objects.equal(prdcr, o.prdcr))&&Objects.equal(pol, o.pol));
    }

}
