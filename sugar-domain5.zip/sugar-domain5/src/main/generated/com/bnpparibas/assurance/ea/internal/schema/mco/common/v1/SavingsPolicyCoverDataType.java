
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to define data of cover linked to a savings
 * 				policy
 * 			
 * 
 * <p>Java class for SavingsPolicyCoverDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyCoverDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="CovStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverStatusType" minOccurs="0"/&gt;
 *         &lt;element name="LinkdObjcts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsPolicyCoverLinkedObjectsType" minOccurs="0"/&gt;
 *         &lt;element name="CovData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsCoverDataType"/&gt;
 *         &lt;element name="BnkngRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentMethodWithPayerType" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsCoverBeneficiaryClauseType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PartExclsn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverParticularExclusionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ExtraPrem" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExtraPremiumType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyCoverDataType", propOrder = {
    "covIdntfctn",
    "covStatus",
    "linkdObjcts",
    "covData",
    "bnkngRef",
    "benfciaryClause",
    "partExclsn",
    "extraPrem"
})
public class SavingsPolicyCoverDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovIdntfctn")
    protected CoverIdentificationType covIdntfctn;
    @XmlElement(name = "CovStatus")
    protected CoverStatusType covStatus;
    @XmlElement(name = "LinkdObjcts")
    protected SavingsPolicyCoverLinkedObjectsType linkdObjcts;
    @XmlElement(name = "CovData", required = true)
    protected SavingsCoverDataType covData;
    @XmlElement(name = "BnkngRef")
    protected PaymentMethodWithPayerType bnkngRef;
    @XmlElement(name = "BenfciaryClause")
    protected List<SavingsCoverBeneficiaryClauseType> benfciaryClause;
    @XmlElement(name = "PartExclsn")
    protected List<CoverParticularExclusionType> partExclsn;
    @XmlElement(name = "ExtraPrem")
    protected List<ExtraPremiumType> extraPrem;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyCoverDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyCoverDataType(final CoverIdentificationType covIdntfctn, final CoverStatusType covStatus, final SavingsPolicyCoverLinkedObjectsType linkdObjcts, final SavingsCoverDataType covData, final PaymentMethodWithPayerType bnkngRef, final List<SavingsCoverBeneficiaryClauseType> benfciaryClause, final List<CoverParticularExclusionType> partExclsn, final List<ExtraPremiumType> extraPrem) {
        this.covIdntfctn = covIdntfctn;
        this.covStatus = covStatus;
        this.linkdObjcts = linkdObjcts;
        this.covData = covData;
        this.bnkngRef = bnkngRef;
        this.benfciaryClause = benfciaryClause;
        this.partExclsn = partExclsn;
        this.extraPrem = extraPrem;
    }

    /**
     * Gets the value of the covIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link CoverIdentificationType }
     *     
     */
    public CoverIdentificationType getCovIdntfctn() {
        return covIdntfctn;
    }

    /**
     * Sets the value of the covIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverIdentificationType }
     *     
     */
    public void setCovIdntfctn(CoverIdentificationType value) {
        this.covIdntfctn = value;
    }

    public boolean isSetCovIdntfctn() {
        return (this.covIdntfctn!= null);
    }

    /**
     * Gets the value of the covStatus property.
     * 
     * @return
     *     possible object is
     *     {@link CoverStatusType }
     *     
     */
    public CoverStatusType getCovStatus() {
        return covStatus;
    }

    /**
     * Sets the value of the covStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverStatusType }
     *     
     */
    public void setCovStatus(CoverStatusType value) {
        this.covStatus = value;
    }

    public boolean isSetCovStatus() {
        return (this.covStatus!= null);
    }

    /**
     * Gets the value of the linkdObjcts property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsPolicyCoverLinkedObjectsType }
     *     
     */
    public SavingsPolicyCoverLinkedObjectsType getLinkdObjcts() {
        return linkdObjcts;
    }

    /**
     * Sets the value of the linkdObjcts property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsPolicyCoverLinkedObjectsType }
     *     
     */
    public void setLinkdObjcts(SavingsPolicyCoverLinkedObjectsType value) {
        this.linkdObjcts = value;
    }

    public boolean isSetLinkdObjcts() {
        return (this.linkdObjcts!= null);
    }

    /**
     * Gets the value of the covData property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsCoverDataType }
     *     
     */
    public SavingsCoverDataType getCovData() {
        return covData;
    }

    /**
     * Sets the value of the covData property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsCoverDataType }
     *     
     */
    public void setCovData(SavingsCoverDataType value) {
        this.covData = value;
    }

    public boolean isSetCovData() {
        return (this.covData!= null);
    }

    /**
     * Gets the value of the bnkngRef property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodWithPayerType }
     *     
     */
    public PaymentMethodWithPayerType getBnkngRef() {
        return bnkngRef;
    }

    /**
     * Sets the value of the bnkngRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodWithPayerType }
     *     
     */
    public void setBnkngRef(PaymentMethodWithPayerType value) {
        this.bnkngRef = value;
    }

    public boolean isSetBnkngRef() {
        return (this.bnkngRef!= null);
    }

    /**
     * Gets the value of the benfciaryClause property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the benfciaryClause property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBenfciaryClause().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SavingsCoverBeneficiaryClauseType }
     * 
     * 
     */
    public List<SavingsCoverBeneficiaryClauseType> getBenfciaryClause() {
        if (benfciaryClause == null) {
            benfciaryClause = new ArrayList<SavingsCoverBeneficiaryClauseType>();
        }
        return this.benfciaryClause;
    }

    public boolean isSetBenfciaryClause() {
        return ((this.benfciaryClause!= null)&&(!this.benfciaryClause.isEmpty()));
    }

    public void unsetBenfciaryClause() {
        this.benfciaryClause = null;
    }

    /**
     * Gets the value of the partExclsn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partExclsn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartExclsn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverParticularExclusionType }
     * 
     * 
     */
    public List<CoverParticularExclusionType> getPartExclsn() {
        if (partExclsn == null) {
            partExclsn = new ArrayList<CoverParticularExclusionType>();
        }
        return this.partExclsn;
    }

    public boolean isSetPartExclsn() {
        return ((this.partExclsn!= null)&&(!this.partExclsn.isEmpty()));
    }

    public void unsetPartExclsn() {
        this.partExclsn = null;
    }

    /**
     * Gets the value of the extraPrem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the extraPrem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExtraPrem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExtraPremiumType }
     * 
     * 
     */
    public List<ExtraPremiumType> getExtraPrem() {
        if (extraPrem == null) {
            extraPrem = new ArrayList<ExtraPremiumType>();
        }
        return this.extraPrem;
    }

    public boolean isSetExtraPrem() {
        return ((this.extraPrem!= null)&&(!this.extraPrem.isEmpty()));
    }

    public void unsetExtraPrem() {
        this.extraPrem = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covIdntfctn", covIdntfctn).add("covStatus", covStatus).add("linkdObjcts", linkdObjcts).add("covData", covData).add("bnkngRef", bnkngRef).add("benfciaryClause", benfciaryClause).add("partExclsn", partExclsn).add("extraPrem", extraPrem).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covIdntfctn, covStatus, linkdObjcts, covData, bnkngRef, benfciaryClause, partExclsn, extraPrem);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyCoverDataType o = ((SavingsPolicyCoverDataType) other);
        return (((((((Objects.equal(covIdntfctn, o.covIdntfctn)&&Objects.equal(covStatus, o.covStatus))&&Objects.equal(linkdObjcts, o.linkdObjcts))&&Objects.equal(covData, o.covData))&&Objects.equal(bnkngRef, o.bnkngRef))&&Objects.equal(benfciaryClause, o.benfciaryClause))&&Objects.equal(partExclsn, o.partExclsn))&&Objects.equal(extraPrem, o.extraPrem));
    }

}
