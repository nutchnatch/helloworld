
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage data on the parent of a structure
 * 				element
 * 			
 * 
 * <p>Java class for StructureElementParentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StructureElementParentType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="LinkData" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Type" minOccurs="0"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;maxLength value="50"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="StartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *                   &lt;element name="EndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StructureElementParentType", propOrder = {
    "idntfctn",
    "linkData"
})
public class StructureElementParentType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn", required = true)
    protected ObjectIdentificationType idntfctn;
    @XmlElement(name = "LinkData")
    protected StructureElementParentType.LinkData linkData;

    /**
     * Default no-arg constructor
     * 
     */
    public StructureElementParentType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public StructureElementParentType(final ObjectIdentificationType idntfctn, final StructureElementParentType.LinkData linkData) {
        this.idntfctn = idntfctn;
        this.linkData = linkData;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntfctn(ObjectIdentificationType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the linkData property.
     * 
     * @return
     *     possible object is
     *     {@link StructureElementParentType.LinkData }
     *     
     */
    public StructureElementParentType.LinkData getLinkData() {
        return linkData;
    }

    /**
     * Sets the value of the linkData property.
     * 
     * @param value
     *     allowed object is
     *     {@link StructureElementParentType.LinkData }
     *     
     */
    public void setLinkData(StructureElementParentType.LinkData value) {
        this.linkData = value;
    }

    public boolean isSetLinkData() {
        return (this.linkData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("linkData", linkData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, linkData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final StructureElementParentType o = ((StructureElementParentType) other);
        return (Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(linkData, o.linkData));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Type" minOccurs="0"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;maxLength value="50"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="StartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
     *         &lt;element name="EndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "type",
        "startDate",
        "endDate"
    })
    public static class LinkData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Type")
        protected String type;
        @XmlElement(name = "StartDate", type = String.class)
        @XmlJavaTypeAdapter(Adapter2 .class)
        @XmlSchemaType(name = "date")
        protected Date startDate;
        @XmlElement(name = "EndDate", type = String.class)
        @XmlJavaTypeAdapter(Adapter2 .class)
        @XmlSchemaType(name = "date")
        protected Date endDate;

        /**
         * Default no-arg constructor
         * 
         */
        public LinkData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public LinkData(final String type, final Date startDate, final Date endDate) {
            this.type = type;
            this.startDate = startDate;
            this.endDate = endDate;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

        public boolean isSetType() {
            return (this.type!= null);
        }

        /**
         * Gets the value of the startDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public Date getStartDate() {
            return startDate;
        }

        /**
         * Sets the value of the startDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStartDate(Date value) {
            this.startDate = value;
        }

        public boolean isSetStartDate() {
            return (this.startDate!= null);
        }

        /**
         * Gets the value of the endDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public Date getEndDate() {
            return endDate;
        }

        /**
         * Sets the value of the endDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEndDate(Date value) {
            this.endDate = value;
        }

        public boolean isSetEndDate() {
            return (this.endDate!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("type", type).add("startDate", startDate).add("endDate", endDate).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(type, startDate, endDate);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final StructureElementParentType.LinkData o = ((StructureElementParentType.LinkData) other);
            return ((Objects.equal(type, o.type)&&Objects.equal(startDate, o.startDate))&&Objects.equal(endDate, o.endDate));
        }

    }

}
