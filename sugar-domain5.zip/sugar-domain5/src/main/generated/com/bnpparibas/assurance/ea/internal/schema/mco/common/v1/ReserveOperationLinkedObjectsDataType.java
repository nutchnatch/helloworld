
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for ReserveOperationLinkedObjectsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ReserveOperationLinkedObjectsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Prdcr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductIdentificationAndHierarchyDataType" minOccurs="0"/&gt;
 *         &lt;element name="Partnr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Cov" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductRiskIdentificationDataType"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Prem" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Claim" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReserveOperationLinkedObjectsDataType", propOrder = {
    "prdcr",
    "pdct",
    "corePdct",
    "partnr",
    "cov",
    "pol",
    "prem",
    "claim"
})
public class ReserveOperationLinkedObjectsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Prdcr", required = true)
    protected PartyRoleType prdcr;
    @XmlElement(name = "Pdct", required = true)
    protected ObjectIdentificationWithVersionType pdct;
    @XmlElement(name = "CorePdct")
    protected CoreProductIdentificationAndHierarchyDataType corePdct;
    @XmlElement(name = "Partnr")
    protected List<PartnerPartyType> partnr;
    @XmlElement(name = "Cov", required = true)
    protected ProductRiskIdentificationDataType cov;
    @XmlElement(name = "Pol")
    protected ObjectIdentificationType pol;
    @XmlElement(name = "Prem")
    protected ObjectIdentificationType prem;
    @XmlElement(name = "Claim")
    protected ObjectIdentificationType claim;

    /**
     * Default no-arg constructor
     * 
     */
    public ReserveOperationLinkedObjectsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ReserveOperationLinkedObjectsDataType(final PartyRoleType prdcr, final ObjectIdentificationWithVersionType pdct, final CoreProductIdentificationAndHierarchyDataType corePdct, final List<PartnerPartyType> partnr, final ProductRiskIdentificationDataType cov, final ObjectIdentificationType pol, final ObjectIdentificationType prem, final ObjectIdentificationType claim) {
        this.prdcr = prdcr;
        this.pdct = pdct;
        this.corePdct = corePdct;
        this.partnr = partnr;
        this.cov = cov;
        this.pol = pol;
        this.prem = prem;
        this.claim = claim;
    }

    /**
     * Gets the value of the prdcr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdcr() {
        return prdcr;
    }

    /**
     * Sets the value of the prdcr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdcr(PartyRoleType value) {
        this.prdcr = value;
    }

    public boolean isSetPrdcr() {
        return (this.prdcr!= null);
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setPdct(ObjectIdentificationWithVersionType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public CoreProductIdentificationAndHierarchyDataType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public void setCorePdct(CoreProductIdentificationAndHierarchyDataType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    /**
     * Gets the value of the partnr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partnr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartnr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getPartnr() {
        if (partnr == null) {
            partnr = new ArrayList<PartnerPartyType>();
        }
        return this.partnr;
    }

    public boolean isSetPartnr() {
        return ((this.partnr!= null)&&(!this.partnr.isEmpty()));
    }

    public void unsetPartnr() {
        this.partnr = null;
    }

    /**
     * Gets the value of the cov property.
     * 
     * @return
     *     possible object is
     *     {@link ProductRiskIdentificationDataType }
     *     
     */
    public ProductRiskIdentificationDataType getCov() {
        return cov;
    }

    /**
     * Sets the value of the cov property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductRiskIdentificationDataType }
     *     
     */
    public void setCov(ProductRiskIdentificationDataType value) {
        this.cov = value;
    }

    public boolean isSetCov() {
        return (this.cov!= null);
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    /**
     * Gets the value of the prem property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPrem() {
        return prem;
    }

    /**
     * Sets the value of the prem property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPrem(ObjectIdentificationType value) {
        this.prem = value;
    }

    public boolean isSetPrem() {
        return (this.prem!= null);
    }

    /**
     * Gets the value of the claim property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getClaim() {
        return claim;
    }

    /**
     * Sets the value of the claim property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setClaim(ObjectIdentificationType value) {
        this.claim = value;
    }

    public boolean isSetClaim() {
        return (this.claim!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("prdcr", prdcr).add("pdct", pdct).add("corePdct", corePdct).add("partnr", partnr).add("cov", cov).add("pol", pol).add("prem", prem).add("claim", claim).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(prdcr, pdct, corePdct, partnr, cov, pol, prem, claim);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ReserveOperationLinkedObjectsDataType o = ((ReserveOperationLinkedObjectsDataType) other);
        return (((((((Objects.equal(prdcr, o.prdcr)&&Objects.equal(pdct, o.pdct))&&Objects.equal(corePdct, o.corePdct))&&Objects.equal(partnr, o.partnr))&&Objects.equal(cov, o.cov))&&Objects.equal(pol, o.pol))&&Objects.equal(prem, o.prem))&&Objects.equal(claim, o.claim));
    }

}
