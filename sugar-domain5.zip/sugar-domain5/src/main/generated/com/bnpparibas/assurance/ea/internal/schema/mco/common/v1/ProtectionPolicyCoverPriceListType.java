
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Bareme tarifaire
 * 
 * <p>Java class for ProtectionPolicyCoverPriceListType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyCoverPriceListType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PricListIdntctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="BasisAmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyCoverPriceListType", propOrder = {
    "pricListIdntctn",
    "basisAmntType"
})
public class ProtectionPolicyCoverPriceListType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PricListIdntctn", required = true)
    protected ObjectIdentificationType pricListIdntctn;
    @XmlElement(name = "BasisAmntType", required = true)
    protected String basisAmntType;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyCoverPriceListType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyCoverPriceListType(final ObjectIdentificationType pricListIdntctn, final String basisAmntType) {
        this.pricListIdntctn = pricListIdntctn;
        this.basisAmntType = basisAmntType;
    }

    /**
     * Gets the value of the pricListIdntctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPricListIdntctn() {
        return pricListIdntctn;
    }

    /**
     * Sets the value of the pricListIdntctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPricListIdntctn(ObjectIdentificationType value) {
        this.pricListIdntctn = value;
    }

    public boolean isSetPricListIdntctn() {
        return (this.pricListIdntctn!= null);
    }

    /**
     * Gets the value of the basisAmntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasisAmntType() {
        return basisAmntType;
    }

    /**
     * Sets the value of the basisAmntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasisAmntType(String value) {
        this.basisAmntType = value;
    }

    public boolean isSetBasisAmntType() {
        return (this.basisAmntType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pricListIdntctn", pricListIdntctn).add("basisAmntType", basisAmntType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pricListIdntctn, basisAmntType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyCoverPriceListType o = ((ProtectionPolicyCoverPriceListType) other);
        return (Objects.equal(pricListIdntctn, o.pricListIdntctn)&&Objects.equal(basisAmntType, o.basisAmntType));
    }

}
