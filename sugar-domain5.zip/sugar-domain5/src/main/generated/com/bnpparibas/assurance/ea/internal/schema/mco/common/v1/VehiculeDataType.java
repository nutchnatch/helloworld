
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to describe an insured vehicule
 * 			
 * 
 * <p>Java class for VehiculeDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="VehiculeDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LcnceNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="RegstrtnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="Model" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="Color" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="Mileage" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="ScndHandIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VehiculeDataType", propOrder = {
    "lcnceNumb",
    "regstrtnDate",
    "model",
    "color",
    "mileage",
    "scndHandIndic"
})
public class VehiculeDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "LcnceNumb", required = true)
    protected String lcnceNumb;
    @XmlElement(name = "RegstrtnDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date regstrtnDate;
    @XmlElement(name = "Model")
    protected String model;
    @XmlElement(name = "Color")
    protected String color;
    @XmlElement(name = "Mileage")
    protected BigInteger mileage;
    @XmlElement(name = "ScndHandIndic")
    protected String scndHandIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public VehiculeDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public VehiculeDataType(final String lcnceNumb, final Date regstrtnDate, final String model, final String color, final BigInteger mileage, final String scndHandIndic) {
        this.lcnceNumb = lcnceNumb;
        this.regstrtnDate = regstrtnDate;
        this.model = model;
        this.color = color;
        this.mileage = mileage;
        this.scndHandIndic = scndHandIndic;
    }

    /**
     * Gets the value of the lcnceNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLcnceNumb() {
        return lcnceNumb;
    }

    /**
     * Sets the value of the lcnceNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLcnceNumb(String value) {
        this.lcnceNumb = value;
    }

    public boolean isSetLcnceNumb() {
        return (this.lcnceNumb!= null);
    }

    /**
     * Gets the value of the regstrtnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getRegstrtnDate() {
        return regstrtnDate;
    }

    /**
     * Sets the value of the regstrtnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegstrtnDate(Date value) {
        this.regstrtnDate = value;
    }

    public boolean isSetRegstrtnDate() {
        return (this.regstrtnDate!= null);
    }

    /**
     * Gets the value of the model property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the value of the model property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModel(String value) {
        this.model = value;
    }

    public boolean isSetModel() {
        return (this.model!= null);
    }

    /**
     * Gets the value of the color property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getColor() {
        return color;
    }

    /**
     * Sets the value of the color property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setColor(String value) {
        this.color = value;
    }

    public boolean isSetColor() {
        return (this.color!= null);
    }

    /**
     * Gets the value of the mileage property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMileage() {
        return mileage;
    }

    /**
     * Sets the value of the mileage property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMileage(BigInteger value) {
        this.mileage = value;
    }

    public boolean isSetMileage() {
        return (this.mileage!= null);
    }

    /**
     * Gets the value of the scndHandIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScndHandIndic() {
        return scndHandIndic;
    }

    /**
     * Sets the value of the scndHandIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScndHandIndic(String value) {
        this.scndHandIndic = value;
    }

    public boolean isSetScndHandIndic() {
        return (this.scndHandIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("lcnceNumb", lcnceNumb).add("regstrtnDate", regstrtnDate).add("model", model).add("color", color).add("mileage", mileage).add("scndHandIndic", scndHandIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(lcnceNumb, regstrtnDate, model, color, mileage, scndHandIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final VehiculeDataType o = ((VehiculeDataType) other);
        return (((((Objects.equal(lcnceNumb, o.lcnceNumb)&&Objects.equal(regstrtnDate, o.regstrtnDate))&&Objects.equal(model, o.model))&&Objects.equal(color, o.color))&&Objects.equal(mileage, o.mileage))&&Objects.equal(scndHandIndic, o.scndHandIndic));
    }

}
