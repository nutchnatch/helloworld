
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SugarRoles.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SugarRoles"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="SUGAR_ADMIN"/&gt;
 *     &lt;enumeration value="SUGAR_BS_MANAGER"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "SugarRoles")
@XmlEnum
public enum SugarRoles {

    SUGAR_ADMIN,
    SUGAR_BS_MANAGER;

    public String value() {
        return name();
    }

    public static SugarRoles fromValue(String v) {
        return valueOf(v);
    }

}
