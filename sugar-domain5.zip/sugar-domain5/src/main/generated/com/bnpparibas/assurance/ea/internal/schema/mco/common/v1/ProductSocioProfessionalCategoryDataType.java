
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * List of auhorized socio professional categories on
 * 				the product
 * 			
 * 
 * <p>Java class for ProductSocioProfessionalCategoryDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductSocioProfessionalCategoryDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CSPCode"/&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductSocioProfessionalCategoryDataType", propOrder = {
    "code",
    "applctnPrd"
})
public class ProductSocioProfessionalCategoryDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Code", required = true)
    protected String code;
    @XmlElement(name = "ApplctnPrd")
    protected DatePeriodType applctnPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ProductSocioProfessionalCategoryDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProductSocioProfessionalCategoryDataType(final String code, final DatePeriodType applctnPrd) {
        this.code = code;
        this.applctnPrd = applctnPrd;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    public boolean isSetCode() {
        return (this.code!= null);
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("code", code).add("applctnPrd", applctnPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code, applctnPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProductSocioProfessionalCategoryDataType o = ((ProductSocioProfessionalCategoryDataType) other);
        return (Objects.equal(code, o.code)&&Objects.equal(applctnPrd, o.applctnPrd));
    }

}
