
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data which can be referenced in
 * 				different exchange data models
 * 			
 * 
 * <p>Java class for ProductSharedDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductSharedDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PdctIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType"/&gt;
 *         &lt;element name="InsActvty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsuranceActivityCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="PdctFam" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductFamilyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="LegalSchme" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalSchemeCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductSharedDataType", propOrder = {
    "pdctIdntfctn",
    "insActvty",
    "pdctFam",
    "legalSchme"
})
public class ProductSharedDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PdctIdntfctn", required = true)
    protected ObjectIdentificationWithVersionType pdctIdntfctn;
    @XmlElement(name = "InsActvty")
    protected String insActvty;
    @XmlElement(name = "PdctFam")
    protected String pdctFam;
    @XmlElement(name = "LegalSchme")
    protected String legalSchme;

    /**
     * Default no-arg constructor
     * 
     */
    public ProductSharedDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProductSharedDataType(final ObjectIdentificationWithVersionType pdctIdntfctn, final String insActvty, final String pdctFam, final String legalSchme) {
        this.pdctIdntfctn = pdctIdntfctn;
        this.insActvty = insActvty;
        this.pdctFam = pdctFam;
        this.legalSchme = legalSchme;
    }

    /**
     * Gets the value of the pdctIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getPdctIdntfctn() {
        return pdctIdntfctn;
    }

    /**
     * Sets the value of the pdctIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setPdctIdntfctn(ObjectIdentificationWithVersionType value) {
        this.pdctIdntfctn = value;
    }

    public boolean isSetPdctIdntfctn() {
        return (this.pdctIdntfctn!= null);
    }

    /**
     * Gets the value of the insActvty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInsActvty() {
        return insActvty;
    }

    /**
     * Sets the value of the insActvty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInsActvty(String value) {
        this.insActvty = value;
    }

    public boolean isSetInsActvty() {
        return (this.insActvty!= null);
    }

    /**
     * Gets the value of the pdctFam property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctFam() {
        return pdctFam;
    }

    /**
     * Sets the value of the pdctFam property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctFam(String value) {
        this.pdctFam = value;
    }

    public boolean isSetPdctFam() {
        return (this.pdctFam!= null);
    }

    /**
     * Gets the value of the legalSchme property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalSchme() {
        return legalSchme;
    }

    /**
     * Sets the value of the legalSchme property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalSchme(String value) {
        this.legalSchme = value;
    }

    public boolean isSetLegalSchme() {
        return (this.legalSchme!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdctIdntfctn", pdctIdntfctn).add("insActvty", insActvty).add("pdctFam", pdctFam).add("legalSchme", legalSchme).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdctIdntfctn, insActvty, pdctFam, legalSchme);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProductSharedDataType o = ((ProductSharedDataType) other);
        return (((Objects.equal(pdctIdntfctn, o.pdctIdntfctn)&&Objects.equal(insActvty, o.insActvty))&&Objects.equal(pdctFam, o.pdctFam))&&Objects.equal(legalSchme, o.legalSchme));
    }

}
