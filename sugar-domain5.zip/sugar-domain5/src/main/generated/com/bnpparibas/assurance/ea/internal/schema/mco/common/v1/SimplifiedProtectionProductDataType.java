
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage global data of simplified protection
 * 				product
 * 			
 * 
 * <p>Java class for SimplifiedProtectionProductDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SimplifiedProtectionProductDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="RefCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MarktngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType"/&gt;
 *         &lt;element name="RnwalData" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="TacitIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN"/&gt;
 *                   &lt;element name="Freq" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SimplifiedProtectionProductDataType", propOrder = {
    "name",
    "refCurr",
    "marktngPrd",
    "rnwalData"
})
public class SimplifiedProtectionProductDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "RefCurr")
    protected String refCurr;
    @XmlElement(name = "MarktngPrd", required = true)
    protected DatePeriodType marktngPrd;
    @XmlElement(name = "RnwalData")
    protected SimplifiedProtectionProductDataType.RnwalData rnwalData;

    /**
     * Default no-arg constructor
     * 
     */
    public SimplifiedProtectionProductDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SimplifiedProtectionProductDataType(final String name, final String refCurr, final DatePeriodType marktngPrd, final SimplifiedProtectionProductDataType.RnwalData rnwalData) {
        this.name = name;
        this.refCurr = refCurr;
        this.marktngPrd = marktngPrd;
        this.rnwalData = rnwalData;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the refCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefCurr() {
        return refCurr;
    }

    /**
     * Sets the value of the refCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefCurr(String value) {
        this.refCurr = value;
    }

    public boolean isSetRefCurr() {
        return (this.refCurr!= null);
    }

    /**
     * Gets the value of the marktngPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getMarktngPrd() {
        return marktngPrd;
    }

    /**
     * Sets the value of the marktngPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setMarktngPrd(DatePeriodType value) {
        this.marktngPrd = value;
    }

    public boolean isSetMarktngPrd() {
        return (this.marktngPrd!= null);
    }

    /**
     * Gets the value of the rnwalData property.
     * 
     * @return
     *     possible object is
     *     {@link SimplifiedProtectionProductDataType.RnwalData }
     *     
     */
    public SimplifiedProtectionProductDataType.RnwalData getRnwalData() {
        return rnwalData;
    }

    /**
     * Sets the value of the rnwalData property.
     * 
     * @param value
     *     allowed object is
     *     {@link SimplifiedProtectionProductDataType.RnwalData }
     *     
     */
    public void setRnwalData(SimplifiedProtectionProductDataType.RnwalData value) {
        this.rnwalData = value;
    }

    public boolean isSetRnwalData() {
        return (this.rnwalData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("refCurr", refCurr).add("marktngPrd", marktngPrd).add("rnwalData", rnwalData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, refCurr, marktngPrd, rnwalData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SimplifiedProtectionProductDataType o = ((SimplifiedProtectionProductDataType) other);
        return (((Objects.equal(name, o.name)&&Objects.equal(refCurr, o.refCurr))&&Objects.equal(marktngPrd, o.marktngPrd))&&Objects.equal(rnwalData, o.rnwalData));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="TacitIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN"/&gt;
     *         &lt;element name="Freq" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tacitIndic",
        "freq"
    })
    public static class RnwalData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "TacitIndic", required = true)
        protected String tacitIndic;
        @XmlElement(name = "Freq", required = true)
        protected String freq;

        /**
         * Default no-arg constructor
         * 
         */
        public RnwalData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public RnwalData(final String tacitIndic, final String freq) {
            this.tacitIndic = tacitIndic;
            this.freq = freq;
        }

        /**
         * Gets the value of the tacitIndic property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTacitIndic() {
            return tacitIndic;
        }

        /**
         * Sets the value of the tacitIndic property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTacitIndic(String value) {
            this.tacitIndic = value;
        }

        public boolean isSetTacitIndic() {
            return (this.tacitIndic!= null);
        }

        /**
         * Gets the value of the freq property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFreq() {
            return freq;
        }

        /**
         * Sets the value of the freq property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFreq(String value) {
            this.freq = value;
        }

        public boolean isSetFreq() {
            return (this.freq!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("tacitIndic", tacitIndic).add("freq", freq).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(tacitIndic, freq);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final SimplifiedProtectionProductDataType.RnwalData o = ((SimplifiedProtectionProductDataType.RnwalData) other);
            return (Objects.equal(tacitIndic, o.tacitIndic)&&Objects.equal(freq, o.freq));
        }

    }

}
