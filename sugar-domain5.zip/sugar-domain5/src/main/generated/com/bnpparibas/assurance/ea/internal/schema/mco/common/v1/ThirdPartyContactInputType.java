
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information about the person who is
 * 				the contact for a third party person
 * 			
 * 
 * <p>Java class for ThirdPartyContactInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThirdPartyContactInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CntctIdnty" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Title" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CivilityUsualNamingCodeSLN" minOccurs="0"/&gt;
 *                   &lt;element name="LastName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *                   &lt;element name="FrstName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *                   &lt;element name="Cvlty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MainCivilityCodeSLN" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="JobTitleDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="Lang" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LocalType" minOccurs="0"/&gt;
 *         &lt;element name="PhoneAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PhoneAddressInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="EmailAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmailAddressInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThirdPartyContactInputType", propOrder = {
    "cntctIdnty",
    "jobTitleDesc",
    "lang",
    "phoneAdrs",
    "emailAdrs"
})
public class ThirdPartyContactInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CntctIdnty")
    protected ThirdPartyContactInputType.CntctIdnty cntctIdnty;
    @XmlElement(name = "JobTitleDesc")
    protected String jobTitleDesc;
    @XmlElement(name = "Lang")
    protected LocalType lang;
    @XmlElement(name = "PhoneAdrs")
    protected List<PhoneAddressInputType> phoneAdrs;
    @XmlElement(name = "EmailAdrs")
    protected List<EmailAddressInputType> emailAdrs;

    /**
     * Default no-arg constructor
     * 
     */
    public ThirdPartyContactInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ThirdPartyContactInputType(final ThirdPartyContactInputType.CntctIdnty cntctIdnty, final String jobTitleDesc, final LocalType lang, final List<PhoneAddressInputType> phoneAdrs, final List<EmailAddressInputType> emailAdrs) {
        this.cntctIdnty = cntctIdnty;
        this.jobTitleDesc = jobTitleDesc;
        this.lang = lang;
        this.phoneAdrs = phoneAdrs;
        this.emailAdrs = emailAdrs;
    }

    /**
     * Gets the value of the cntctIdnty property.
     * 
     * @return
     *     possible object is
     *     {@link ThirdPartyContactInputType.CntctIdnty }
     *     
     */
    public ThirdPartyContactInputType.CntctIdnty getCntctIdnty() {
        return cntctIdnty;
    }

    /**
     * Sets the value of the cntctIdnty property.
     * 
     * @param value
     *     allowed object is
     *     {@link ThirdPartyContactInputType.CntctIdnty }
     *     
     */
    public void setCntctIdnty(ThirdPartyContactInputType.CntctIdnty value) {
        this.cntctIdnty = value;
    }

    public boolean isSetCntctIdnty() {
        return (this.cntctIdnty!= null);
    }

    /**
     * Gets the value of the jobTitleDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobTitleDesc() {
        return jobTitleDesc;
    }

    /**
     * Sets the value of the jobTitleDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobTitleDesc(String value) {
        this.jobTitleDesc = value;
    }

    public boolean isSetJobTitleDesc() {
        return (this.jobTitleDesc!= null);
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link LocalType }
     *     
     */
    public LocalType getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocalType }
     *     
     */
    public void setLang(LocalType value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    /**
     * Gets the value of the phoneAdrs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phoneAdrs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhoneAdrs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PhoneAddressInputType }
     * 
     * 
     */
    public List<PhoneAddressInputType> getPhoneAdrs() {
        if (phoneAdrs == null) {
            phoneAdrs = new ArrayList<PhoneAddressInputType>();
        }
        return this.phoneAdrs;
    }

    public boolean isSetPhoneAdrs() {
        return ((this.phoneAdrs!= null)&&(!this.phoneAdrs.isEmpty()));
    }

    public void unsetPhoneAdrs() {
        this.phoneAdrs = null;
    }

    /**
     * Gets the value of the emailAdrs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the emailAdrs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmailAdrs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EmailAddressInputType }
     * 
     * 
     */
    public List<EmailAddressInputType> getEmailAdrs() {
        if (emailAdrs == null) {
            emailAdrs = new ArrayList<EmailAddressInputType>();
        }
        return this.emailAdrs;
    }

    public boolean isSetEmailAdrs() {
        return ((this.emailAdrs!= null)&&(!this.emailAdrs.isEmpty()));
    }

    public void unsetEmailAdrs() {
        this.emailAdrs = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cntctIdnty", cntctIdnty).add("jobTitleDesc", jobTitleDesc).add("lang", lang).add("phoneAdrs", phoneAdrs).add("emailAdrs", emailAdrs).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cntctIdnty, jobTitleDesc, lang, phoneAdrs, emailAdrs);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ThirdPartyContactInputType o = ((ThirdPartyContactInputType) other);
        return ((((Objects.equal(cntctIdnty, o.cntctIdnty)&&Objects.equal(jobTitleDesc, o.jobTitleDesc))&&Objects.equal(lang, o.lang))&&Objects.equal(phoneAdrs, o.phoneAdrs))&&Objects.equal(emailAdrs, o.emailAdrs));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Title" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CivilityUsualNamingCodeSLN" minOccurs="0"/&gt;
     *         &lt;element name="LastName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
     *         &lt;element name="FrstName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
     *         &lt;element name="Cvlty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MainCivilityCodeSLN" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "title",
        "lastName",
        "frstName",
        "cvlty"
    })
    public static class CntctIdnty implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Title")
        protected String title;
        @XmlElement(name = "LastName")
        protected String lastName;
        @XmlElement(name = "FrstName")
        protected String frstName;
        @XmlElement(name = "Cvlty")
        protected String cvlty;

        /**
         * Default no-arg constructor
         * 
         */
        public CntctIdnty() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public CntctIdnty(final String title, final String lastName, final String frstName, final String cvlty) {
            this.title = title;
            this.lastName = lastName;
            this.frstName = frstName;
            this.cvlty = cvlty;
        }

        /**
         * Gets the value of the title property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTitle() {
            return title;
        }

        /**
         * Sets the value of the title property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTitle(String value) {
            this.title = value;
        }

        public boolean isSetTitle() {
            return (this.title!= null);
        }

        /**
         * Gets the value of the lastName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLastName() {
            return lastName;
        }

        /**
         * Sets the value of the lastName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLastName(String value) {
            this.lastName = value;
        }

        public boolean isSetLastName() {
            return (this.lastName!= null);
        }

        /**
         * Gets the value of the frstName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFrstName() {
            return frstName;
        }

        /**
         * Sets the value of the frstName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFrstName(String value) {
            this.frstName = value;
        }

        public boolean isSetFrstName() {
            return (this.frstName!= null);
        }

        /**
         * Gets the value of the cvlty property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCvlty() {
            return cvlty;
        }

        /**
         * Sets the value of the cvlty property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCvlty(String value) {
            this.cvlty = value;
        }

        public boolean isSetCvlty() {
            return (this.cvlty!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("title", title).add("lastName", lastName).add("frstName", frstName).add("cvlty", cvlty).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(title, lastName, frstName, cvlty);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ThirdPartyContactInputType.CntctIdnty o = ((ThirdPartyContactInputType.CntctIdnty) other);
            return (((Objects.equal(title, o.title)&&Objects.equal(lastName, o.lastName))&&Objects.equal(frstName, o.frstName))&&Objects.equal(cvlty, o.cvlty));
        }

    }

}
