
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Type to manage information about tax
 * 			
 * 
 * <p>Java class for TaxType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TaxType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;AmountType"&gt;
 *       &lt;attribute name="TaxType" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxTypeCodeSLN" /&gt;
 *       &lt;attribute name="BaseAmnt" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountType" /&gt;
 *       &lt;attribute name="BaseAmntCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" /&gt;
 *       &lt;attribute name="PrcntageRate" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TaxType", propOrder = {
    "value"
})
public class TaxType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected double value;
    @XmlAttribute(name = "TaxType", required = true)
    protected String taxType;
    @XmlAttribute(name = "BaseAmnt", required = true)
    protected double baseAmnt;
    @XmlAttribute(name = "BaseAmntCurr")
    protected String baseAmntCurr;
    @XmlAttribute(name = "PrcntageRate", required = true)
    protected double prcntageRate;

    /**
     * Default no-arg constructor
     * 
     */
    public TaxType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public TaxType(final double value, final String taxType, final double baseAmnt, final String baseAmntCurr, final double prcntageRate) {
        this.value = value;
        this.taxType = taxType;
        this.baseAmnt = baseAmnt;
        this.baseAmntCurr = baseAmntCurr;
        this.prcntageRate = prcntageRate;
    }

    /**
     *  Used to limit the size of the amounts in
     * 				CurrencyandAmount
     * 			
     * 
     */
    public double getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     */
    public void setValue(double value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return true;
    }

    /**
     * Gets the value of the taxType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxType() {
        return taxType;
    }

    /**
     * Sets the value of the taxType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxType(String value) {
        this.taxType = value;
    }

    public boolean isSetTaxType() {
        return (this.taxType!= null);
    }

    /**
     * Gets the value of the baseAmnt property.
     * 
     */
    public double getBaseAmnt() {
        return baseAmnt;
    }

    /**
     * Sets the value of the baseAmnt property.
     * 
     */
    public void setBaseAmnt(double value) {
        this.baseAmnt = value;
    }

    public boolean isSetBaseAmnt() {
        return true;
    }

    /**
     * Gets the value of the baseAmntCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBaseAmntCurr() {
        return baseAmntCurr;
    }

    /**
     * Sets the value of the baseAmntCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBaseAmntCurr(String value) {
        this.baseAmntCurr = value;
    }

    public boolean isSetBaseAmntCurr() {
        return (this.baseAmntCurr!= null);
    }

    /**
     * Gets the value of the prcntageRate property.
     * 
     */
    public double getPrcntageRate() {
        return prcntageRate;
    }

    /**
     * Sets the value of the prcntageRate property.
     * 
     */
    public void setPrcntageRate(double value) {
        this.prcntageRate = value;
    }

    public boolean isSetPrcntageRate() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("taxType", taxType).add("baseAmnt", baseAmnt).add("baseAmntCurr", baseAmntCurr).add("prcntageRate", prcntageRate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, taxType, baseAmnt, baseAmntCurr, prcntageRate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final TaxType o = ((TaxType) other);
        return ((((Objects.equal(value, o.value)&&Objects.equal(taxType, o.taxType))&&Objects.equal(baseAmnt, o.baseAmnt))&&Objects.equal(baseAmntCurr, o.baseAmntCurr))&&Objects.equal(prcntageRate, o.prcntageRate));
    }

}
