
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage specific scheduler data for regular
 * 				savings premium and regular savingswithdrawal specific to france
 * 			
 * 
 * <p>Java class for SpecifPeriodicSavingsSchedulerDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SpecifPeriodicSavingsSchedulerDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PrcntageIndexatnRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="TaxationMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxationOptionTypeCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecifPeriodicSavingsSchedulerDataType", propOrder = {
    "prcntageIndexatnRate",
    "taxationMode"
})
public class SpecifPeriodicSavingsSchedulerDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PrcntageIndexatnRate")
    protected Double prcntageIndexatnRate;
    @XmlElement(name = "TaxationMode")
    protected String taxationMode;

    /**
     * Default no-arg constructor
     * 
     */
    public SpecifPeriodicSavingsSchedulerDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SpecifPeriodicSavingsSchedulerDataType(final Double prcntageIndexatnRate, final String taxationMode) {
        this.prcntageIndexatnRate = prcntageIndexatnRate;
        this.taxationMode = taxationMode;
    }

    /**
     * Gets the value of the prcntageIndexatnRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPrcntageIndexatnRate() {
        return prcntageIndexatnRate;
    }

    /**
     * Sets the value of the prcntageIndexatnRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPrcntageIndexatnRate(Double value) {
        this.prcntageIndexatnRate = value;
    }

    public boolean isSetPrcntageIndexatnRate() {
        return (this.prcntageIndexatnRate!= null);
    }

    /**
     * Gets the value of the taxationMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxationMode() {
        return taxationMode;
    }

    /**
     * Sets the value of the taxationMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxationMode(String value) {
        this.taxationMode = value;
    }

    public boolean isSetTaxationMode() {
        return (this.taxationMode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("prcntageIndexatnRate", prcntageIndexatnRate).add("taxationMode", taxationMode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(prcntageIndexatnRate, taxationMode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SpecifPeriodicSavingsSchedulerDataType o = ((SpecifPeriodicSavingsSchedulerDataType) other);
        return (Objects.equal(prcntageIndexatnRate, o.prcntageIndexatnRate)&&Objects.equal(taxationMode, o.taxationMode));
    }

}
