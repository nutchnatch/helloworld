
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage fees derogation linked to a savings
 * 				policy
 * 			
 * 
 * <p>Java class for SavingsPolicyFeesDerogationInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyFeesDerogationInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PolLvl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeeDerogationInputType" minOccurs="0"/&gt;
 *         &lt;element name="FundLvl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FundFeeDerogationDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="FundClasLvl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FundClassFeeDerogationDataInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyFeesDerogationInputType", propOrder = {
    "polLvl",
    "fundLvl",
    "fundClasLvl"
})
public class SavingsPolicyFeesDerogationInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PolLvl")
    protected FeeDerogationInputType polLvl;
    @XmlElement(name = "FundLvl")
    protected FundFeeDerogationDataInputType fundLvl;
    @XmlElement(name = "FundClasLvl")
    protected FundClassFeeDerogationDataInputType fundClasLvl;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyFeesDerogationInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyFeesDerogationInputType(final FeeDerogationInputType polLvl, final FundFeeDerogationDataInputType fundLvl, final FundClassFeeDerogationDataInputType fundClasLvl) {
        this.polLvl = polLvl;
        this.fundLvl = fundLvl;
        this.fundClasLvl = fundClasLvl;
    }

    /**
     * Gets the value of the polLvl property.
     * 
     * @return
     *     possible object is
     *     {@link FeeDerogationInputType }
     *     
     */
    public FeeDerogationInputType getPolLvl() {
        return polLvl;
    }

    /**
     * Sets the value of the polLvl property.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeDerogationInputType }
     *     
     */
    public void setPolLvl(FeeDerogationInputType value) {
        this.polLvl = value;
    }

    public boolean isSetPolLvl() {
        return (this.polLvl!= null);
    }

    /**
     * Gets the value of the fundLvl property.
     * 
     * @return
     *     possible object is
     *     {@link FundFeeDerogationDataInputType }
     *     
     */
    public FundFeeDerogationDataInputType getFundLvl() {
        return fundLvl;
    }

    /**
     * Sets the value of the fundLvl property.
     * 
     * @param value
     *     allowed object is
     *     {@link FundFeeDerogationDataInputType }
     *     
     */
    public void setFundLvl(FundFeeDerogationDataInputType value) {
        this.fundLvl = value;
    }

    public boolean isSetFundLvl() {
        return (this.fundLvl!= null);
    }

    /**
     * Gets the value of the fundClasLvl property.
     * 
     * @return
     *     possible object is
     *     {@link FundClassFeeDerogationDataInputType }
     *     
     */
    public FundClassFeeDerogationDataInputType getFundClasLvl() {
        return fundClasLvl;
    }

    /**
     * Sets the value of the fundClasLvl property.
     * 
     * @param value
     *     allowed object is
     *     {@link FundClassFeeDerogationDataInputType }
     *     
     */
    public void setFundClasLvl(FundClassFeeDerogationDataInputType value) {
        this.fundClasLvl = value;
    }

    public boolean isSetFundClasLvl() {
        return (this.fundClasLvl!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("polLvl", polLvl).add("fundLvl", fundLvl).add("fundClasLvl", fundClasLvl).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(polLvl, fundLvl, fundClasLvl);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyFeesDerogationInputType o = ((SavingsPolicyFeesDerogationInputType) other);
        return ((Objects.equal(polLvl, o.polLvl)&&Objects.equal(fundLvl, o.fundLvl))&&Objects.equal(fundClasLvl, o.fundClasLvl));
    }

}
