
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Lis of profiles and related funds
 * 			
 * 
 * <p>Java class for ProfileAndFundDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProfileAndFundDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PdctProfIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="ProfType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProfileTypeCode" minOccurs="0"/&gt;
 *         &lt;element name="ProfPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="InvstmntProfType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialFundProfileTypeCode" minOccurs="0"/&gt;
 *         &lt;element name="ProfFund" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialFundIdentificationType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProfileAndFundDataType", propOrder = {
    "pdctProfIdntfctn",
    "profType",
    "profPrd",
    "invstmntProfType",
    "profFund"
})
public class ProfileAndFundDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PdctProfIdntfctn")
    protected ObjectIdentificationType pdctProfIdntfctn;
    @XmlElement(name = "ProfType")
    protected String profType;
    @XmlElement(name = "ProfPrd")
    protected OptionalDatePeriodType profPrd;
    @XmlElement(name = "InvstmntProfType")
    protected String invstmntProfType;
    @XmlElement(name = "ProfFund", required = true)
    protected List<FinancialFundIdentificationType> profFund;

    /**
     * Default no-arg constructor
     * 
     */
    public ProfileAndFundDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProfileAndFundDataType(final ObjectIdentificationType pdctProfIdntfctn, final String profType, final OptionalDatePeriodType profPrd, final String invstmntProfType, final List<FinancialFundIdentificationType> profFund) {
        this.pdctProfIdntfctn = pdctProfIdntfctn;
        this.profType = profType;
        this.profPrd = profPrd;
        this.invstmntProfType = invstmntProfType;
        this.profFund = profFund;
    }

    /**
     * Gets the value of the pdctProfIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPdctProfIdntfctn() {
        return pdctProfIdntfctn;
    }

    /**
     * Sets the value of the pdctProfIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPdctProfIdntfctn(ObjectIdentificationType value) {
        this.pdctProfIdntfctn = value;
    }

    public boolean isSetPdctProfIdntfctn() {
        return (this.pdctProfIdntfctn!= null);
    }

    /**
     * Gets the value of the profType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProfType() {
        return profType;
    }

    /**
     * Sets the value of the profType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProfType(String value) {
        this.profType = value;
    }

    public boolean isSetProfType() {
        return (this.profType!= null);
    }

    /**
     * Gets the value of the profPrd property.
     * 
     * @return
     *     possible object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public OptionalDatePeriodType getProfPrd() {
        return profPrd;
    }

    /**
     * Sets the value of the profPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public void setProfPrd(OptionalDatePeriodType value) {
        this.profPrd = value;
    }

    public boolean isSetProfPrd() {
        return (this.profPrd!= null);
    }

    /**
     * Gets the value of the invstmntProfType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvstmntProfType() {
        return invstmntProfType;
    }

    /**
     * Sets the value of the invstmntProfType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvstmntProfType(String value) {
        this.invstmntProfType = value;
    }

    public boolean isSetInvstmntProfType() {
        return (this.invstmntProfType!= null);
    }

    /**
     * Gets the value of the profFund property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the profFund property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProfFund().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FinancialFundIdentificationType }
     * 
     * 
     */
    public List<FinancialFundIdentificationType> getProfFund() {
        if (profFund == null) {
            profFund = new ArrayList<FinancialFundIdentificationType>();
        }
        return this.profFund;
    }

    public boolean isSetProfFund() {
        return ((this.profFund!= null)&&(!this.profFund.isEmpty()));
    }

    public void unsetProfFund() {
        this.profFund = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdctProfIdntfctn", pdctProfIdntfctn).add("profType", profType).add("profPrd", profPrd).add("invstmntProfType", invstmntProfType).add("profFund", profFund).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdctProfIdntfctn, profType, profPrd, invstmntProfType, profFund);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProfileAndFundDataType o = ((ProfileAndFundDataType) other);
        return ((((Objects.equal(pdctProfIdntfctn, o.pdctProfIdntfctn)&&Objects.equal(profType, o.profType))&&Objects.equal(profPrd, o.profPrd))&&Objects.equal(invstmntProfType, o.invstmntProfType))&&Objects.equal(profFund, o.profFund));
    }

}
