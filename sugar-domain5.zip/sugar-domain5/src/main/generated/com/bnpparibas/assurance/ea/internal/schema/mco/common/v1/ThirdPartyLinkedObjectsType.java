
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a third party has dependencies
 * 			
 * 
 * <p>Java class for ThirdPartyLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThirdPartyLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThirdPartyLinkedObjectsType", propOrder = {
    "prdctr"
})
public class ThirdPartyLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Prdctr", required = true)
    protected PartyRoleType prdctr;

    /**
     * Default no-arg constructor
     * 
     */
    public ThirdPartyLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ThirdPartyLinkedObjectsType(final PartyRoleType prdctr) {
        this.prdctr = prdctr;
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("prdctr", prdctr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(prdctr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ThirdPartyLinkedObjectsType o = ((ThirdPartyLinkedObjectsType) other);
        return Objects.equal(prdctr, o.prdctr);
    }

}
