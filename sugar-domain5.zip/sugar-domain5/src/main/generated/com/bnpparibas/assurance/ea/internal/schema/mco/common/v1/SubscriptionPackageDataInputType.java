
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for SubscriptionPackageDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SubscriptionPackageDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN"/&gt;
 *         &lt;element name="LvlRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubscriptionPackageDataInputType", propOrder = {
    "id",
    "fqcy",
    "lvlRate"
})
public class SubscriptionPackageDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id", required = true)
    protected String id;
    @XmlElement(name = "Fqcy", required = true)
    protected String fqcy;
    @XmlElement(name = "LvlRate")
    protected Double lvlRate;

    /**
     * Default no-arg constructor
     * 
     */
    public SubscriptionPackageDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SubscriptionPackageDataInputType(final String id, final String fqcy, final Double lvlRate) {
        this.id = id;
        this.fqcy = fqcy;
        this.lvlRate = lvlRate;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the lvlRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLvlRate() {
        return lvlRate;
    }

    /**
     * Sets the value of the lvlRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLvlRate(Double value) {
        this.lvlRate = value;
    }

    public boolean isSetLvlRate() {
        return (this.lvlRate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("fqcy", fqcy).add("lvlRate", lvlRate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, fqcy, lvlRate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SubscriptionPackageDataInputType o = ((SubscriptionPackageDataInputType) other);
        return ((Objects.equal(id, o.id)&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(lvlRate, o.lvlRate));
    }

}
