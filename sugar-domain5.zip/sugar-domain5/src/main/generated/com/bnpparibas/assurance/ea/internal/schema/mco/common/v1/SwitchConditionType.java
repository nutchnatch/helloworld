
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage condition applicable to the switch
 * 				scheduler
 * 			
 * 
 * <p>Java class for SwitchConditionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SwitchConditionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ReminngAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="PrdicSwitchAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SwitchConditionType", propOrder = {
    "reminngAmnt",
    "prdicSwitchAmnt"
})
public class SwitchConditionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ReminngAmnt")
    protected CurrencyAndAmountType reminngAmnt;
    @XmlElement(name = "PrdicSwitchAmnt")
    protected CurrencyAndAmountType prdicSwitchAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public SwitchConditionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SwitchConditionType(final CurrencyAndAmountType reminngAmnt, final CurrencyAndAmountType prdicSwitchAmnt) {
        this.reminngAmnt = reminngAmnt;
        this.prdicSwitchAmnt = prdicSwitchAmnt;
    }

    /**
     * Gets the value of the reminngAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getReminngAmnt() {
        return reminngAmnt;
    }

    /**
     * Sets the value of the reminngAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setReminngAmnt(CurrencyAndAmountType value) {
        this.reminngAmnt = value;
    }

    public boolean isSetReminngAmnt() {
        return (this.reminngAmnt!= null);
    }

    /**
     * Gets the value of the prdicSwitchAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPrdicSwitchAmnt() {
        return prdicSwitchAmnt;
    }

    /**
     * Sets the value of the prdicSwitchAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPrdicSwitchAmnt(CurrencyAndAmountType value) {
        this.prdicSwitchAmnt = value;
    }

    public boolean isSetPrdicSwitchAmnt() {
        return (this.prdicSwitchAmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("reminngAmnt", reminngAmnt).add("prdicSwitchAmnt", prdicSwitchAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(reminngAmnt, prdicSwitchAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SwitchConditionType o = ((SwitchConditionType) other);
        return (Objects.equal(reminngAmnt, o.reminngAmnt)&&Objects.equal(prdicSwitchAmnt, o.prdicSwitchAmnt));
    }

}
