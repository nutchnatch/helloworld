
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on removed standard exclusions
 * 			
 * 
 * <p>Java class for RemovedStandardExlusionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RemovedStandardExlusionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ExclsnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExclusionCodeSLN"/&gt;
 *         &lt;element name="ValdtyPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RemovedStandardExlusionType", propOrder = {
    "exclsnType",
    "valdtyPrd"
})
public class RemovedStandardExlusionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ExclsnType", required = true)
    protected String exclsnType;
    @XmlElement(name = "ValdtyPrd")
    protected DatePeriodType valdtyPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public RemovedStandardExlusionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public RemovedStandardExlusionType(final String exclsnType, final DatePeriodType valdtyPrd) {
        this.exclsnType = exclsnType;
        this.valdtyPrd = valdtyPrd;
    }

    /**
     * Gets the value of the exclsnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExclsnType() {
        return exclsnType;
    }

    /**
     * Sets the value of the exclsnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExclsnType(String value) {
        this.exclsnType = value;
    }

    public boolean isSetExclsnType() {
        return (this.exclsnType!= null);
    }

    /**
     * Gets the value of the valdtyPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getValdtyPrd() {
        return valdtyPrd;
    }

    /**
     * Sets the value of the valdtyPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setValdtyPrd(DatePeriodType value) {
        this.valdtyPrd = value;
    }

    public boolean isSetValdtyPrd() {
        return (this.valdtyPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("exclsnType", exclsnType).add("valdtyPrd", valdtyPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(exclsnType, valdtyPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final RemovedStandardExlusionType o = ((RemovedStandardExlusionType) other);
        return (Objects.equal(exclsnType, o.exclsnType)&&Objects.equal(valdtyPrd, o.valdtyPrd));
    }

}
