
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on cover linked to a protection
 * 				policy
 * 			
 * 
 * <p>Java class for ProtectionPolicyCoverDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProtectionPolicyCoverDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyCoverIdentificationType"/&gt;
 *         &lt;element name="CovStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverStatusType"/&gt;
 *         &lt;element name="LinkdObjcts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPolicyCoverLinkedObjectsType" minOccurs="0"/&gt;
 *         &lt;element name="CovData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPolicyCoverGenDataType"/&gt;
 *         &lt;element name="ClaimData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPolicyClaimOptionsDataType" minOccurs="0"/&gt;
 *         &lt;element name="PremData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPolicyCoverPremiumDataType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentMethodWithPayerType" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverBeneficiaryClauseType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FeeDerogtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeeDerogationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PartExclsn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverParticularExclusionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ExtraPrem" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExtraPremiumType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PricRtnl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProtectionPolicyCoverPricingRationaleType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="SurndrPnltyAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="SurndrPnltyRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProtectionPolicyCoverDataType", propOrder = {
    "covIdntfctn",
    "covStatus",
    "linkdObjcts",
    "covData",
    "claimData",
    "premData",
    "paymntRef",
    "benfciaryClause",
    "feeDerogtn",
    "partExclsn",
    "extraPrem",
    "pricRtnl",
    "surndrPnltyAmnt",
    "surndrPnltyRate"
})
public class ProtectionPolicyCoverDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovIdntfctn", required = true)
    protected PolicyCoverIdentificationType covIdntfctn;
    @XmlElement(name = "CovStatus", required = true)
    protected CoverStatusType covStatus;
    @XmlElement(name = "LinkdObjcts")
    protected ProtectionPolicyCoverLinkedObjectsType linkdObjcts;
    @XmlElement(name = "CovData", required = true)
    protected ProtectionPolicyCoverGenDataType covData;
    @XmlElement(name = "ClaimData")
    protected ProtectionPolicyClaimOptionsDataType claimData;
    @XmlElement(name = "PremData")
    protected ProtectionPolicyCoverPremiumDataType premData;
    @XmlElement(name = "PaymntRef")
    protected PaymentMethodWithPayerType paymntRef;
    @XmlElement(name = "BenfciaryClause")
    protected List<CoverBeneficiaryClauseType> benfciaryClause;
    @XmlElement(name = "FeeDerogtn")
    protected List<FeeDerogationType> feeDerogtn;
    @XmlElement(name = "PartExclsn")
    protected List<CoverParticularExclusionType> partExclsn;
    @XmlElement(name = "ExtraPrem")
    protected List<ExtraPremiumType> extraPrem;
    @XmlElement(name = "PricRtnl")
    protected List<ProtectionPolicyCoverPricingRationaleType> pricRtnl;
    @XmlElement(name = "SurndrPnltyAmnt")
    protected CurrencyAndAmountType surndrPnltyAmnt;
    @XmlElement(name = "SurndrPnltyRate")
    protected BasisRateType surndrPnltyRate;

    /**
     * Default no-arg constructor
     * 
     */
    public ProtectionPolicyCoverDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProtectionPolicyCoverDataType(final PolicyCoverIdentificationType covIdntfctn, final CoverStatusType covStatus, final ProtectionPolicyCoverLinkedObjectsType linkdObjcts, final ProtectionPolicyCoverGenDataType covData, final ProtectionPolicyClaimOptionsDataType claimData, final ProtectionPolicyCoverPremiumDataType premData, final PaymentMethodWithPayerType paymntRef, final List<CoverBeneficiaryClauseType> benfciaryClause, final List<FeeDerogationType> feeDerogtn, final List<CoverParticularExclusionType> partExclsn, final List<ExtraPremiumType> extraPrem, final List<ProtectionPolicyCoverPricingRationaleType> pricRtnl, final CurrencyAndAmountType surndrPnltyAmnt, final BasisRateType surndrPnltyRate) {
        this.covIdntfctn = covIdntfctn;
        this.covStatus = covStatus;
        this.linkdObjcts = linkdObjcts;
        this.covData = covData;
        this.claimData = claimData;
        this.premData = premData;
        this.paymntRef = paymntRef;
        this.benfciaryClause = benfciaryClause;
        this.feeDerogtn = feeDerogtn;
        this.partExclsn = partExclsn;
        this.extraPrem = extraPrem;
        this.pricRtnl = pricRtnl;
        this.surndrPnltyAmnt = surndrPnltyAmnt;
        this.surndrPnltyRate = surndrPnltyRate;
    }

    /**
     * Gets the value of the covIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link PolicyCoverIdentificationType }
     *     
     */
    public PolicyCoverIdentificationType getCovIdntfctn() {
        return covIdntfctn;
    }

    /**
     * Sets the value of the covIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link PolicyCoverIdentificationType }
     *     
     */
    public void setCovIdntfctn(PolicyCoverIdentificationType value) {
        this.covIdntfctn = value;
    }

    public boolean isSetCovIdntfctn() {
        return (this.covIdntfctn!= null);
    }

    /**
     * Gets the value of the covStatus property.
     * 
     * @return
     *     possible object is
     *     {@link CoverStatusType }
     *     
     */
    public CoverStatusType getCovStatus() {
        return covStatus;
    }

    /**
     * Sets the value of the covStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverStatusType }
     *     
     */
    public void setCovStatus(CoverStatusType value) {
        this.covStatus = value;
    }

    public boolean isSetCovStatus() {
        return (this.covStatus!= null);
    }

    /**
     * Gets the value of the linkdObjcts property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionPolicyCoverLinkedObjectsType }
     *     
     */
    public ProtectionPolicyCoverLinkedObjectsType getLinkdObjcts() {
        return linkdObjcts;
    }

    /**
     * Sets the value of the linkdObjcts property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionPolicyCoverLinkedObjectsType }
     *     
     */
    public void setLinkdObjcts(ProtectionPolicyCoverLinkedObjectsType value) {
        this.linkdObjcts = value;
    }

    public boolean isSetLinkdObjcts() {
        return (this.linkdObjcts!= null);
    }

    /**
     * Gets the value of the covData property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionPolicyCoverGenDataType }
     *     
     */
    public ProtectionPolicyCoverGenDataType getCovData() {
        return covData;
    }

    /**
     * Sets the value of the covData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionPolicyCoverGenDataType }
     *     
     */
    public void setCovData(ProtectionPolicyCoverGenDataType value) {
        this.covData = value;
    }

    public boolean isSetCovData() {
        return (this.covData!= null);
    }

    /**
     * Gets the value of the claimData property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionPolicyClaimOptionsDataType }
     *     
     */
    public ProtectionPolicyClaimOptionsDataType getClaimData() {
        return claimData;
    }

    /**
     * Sets the value of the claimData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionPolicyClaimOptionsDataType }
     *     
     */
    public void setClaimData(ProtectionPolicyClaimOptionsDataType value) {
        this.claimData = value;
    }

    public boolean isSetClaimData() {
        return (this.claimData!= null);
    }

    /**
     * Gets the value of the premData property.
     * 
     * @return
     *     possible object is
     *     {@link ProtectionPolicyCoverPremiumDataType }
     *     
     */
    public ProtectionPolicyCoverPremiumDataType getPremData() {
        return premData;
    }

    /**
     * Sets the value of the premData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtectionPolicyCoverPremiumDataType }
     *     
     */
    public void setPremData(ProtectionPolicyCoverPremiumDataType value) {
        this.premData = value;
    }

    public boolean isSetPremData() {
        return (this.premData!= null);
    }

    /**
     * Gets the value of the paymntRef property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodWithPayerType }
     *     
     */
    public PaymentMethodWithPayerType getPaymntRef() {
        return paymntRef;
    }

    /**
     * Sets the value of the paymntRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodWithPayerType }
     *     
     */
    public void setPaymntRef(PaymentMethodWithPayerType value) {
        this.paymntRef = value;
    }

    public boolean isSetPaymntRef() {
        return (this.paymntRef!= null);
    }

    /**
     * Gets the value of the benfciaryClause property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the benfciaryClause property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBenfciaryClause().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverBeneficiaryClauseType }
     * 
     * 
     */
    public List<CoverBeneficiaryClauseType> getBenfciaryClause() {
        if (benfciaryClause == null) {
            benfciaryClause = new ArrayList<CoverBeneficiaryClauseType>();
        }
        return this.benfciaryClause;
    }

    public boolean isSetBenfciaryClause() {
        return ((this.benfciaryClause!= null)&&(!this.benfciaryClause.isEmpty()));
    }

    public void unsetBenfciaryClause() {
        this.benfciaryClause = null;
    }

    /**
     * Gets the value of the feeDerogtn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the feeDerogtn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFeeDerogtn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeeDerogationType }
     * 
     * 
     */
    public List<FeeDerogationType> getFeeDerogtn() {
        if (feeDerogtn == null) {
            feeDerogtn = new ArrayList<FeeDerogationType>();
        }
        return this.feeDerogtn;
    }

    public boolean isSetFeeDerogtn() {
        return ((this.feeDerogtn!= null)&&(!this.feeDerogtn.isEmpty()));
    }

    public void unsetFeeDerogtn() {
        this.feeDerogtn = null;
    }

    /**
     * Gets the value of the partExclsn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partExclsn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartExclsn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverParticularExclusionType }
     * 
     * 
     */
    public List<CoverParticularExclusionType> getPartExclsn() {
        if (partExclsn == null) {
            partExclsn = new ArrayList<CoverParticularExclusionType>();
        }
        return this.partExclsn;
    }

    public boolean isSetPartExclsn() {
        return ((this.partExclsn!= null)&&(!this.partExclsn.isEmpty()));
    }

    public void unsetPartExclsn() {
        this.partExclsn = null;
    }

    /**
     * Gets the value of the extraPrem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the extraPrem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExtraPrem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExtraPremiumType }
     * 
     * 
     */
    public List<ExtraPremiumType> getExtraPrem() {
        if (extraPrem == null) {
            extraPrem = new ArrayList<ExtraPremiumType>();
        }
        return this.extraPrem;
    }

    public boolean isSetExtraPrem() {
        return ((this.extraPrem!= null)&&(!this.extraPrem.isEmpty()));
    }

    public void unsetExtraPrem() {
        this.extraPrem = null;
    }

    /**
     * Gets the value of the pricRtnl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pricRtnl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPricRtnl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProtectionPolicyCoverPricingRationaleType }
     * 
     * 
     */
    public List<ProtectionPolicyCoverPricingRationaleType> getPricRtnl() {
        if (pricRtnl == null) {
            pricRtnl = new ArrayList<ProtectionPolicyCoverPricingRationaleType>();
        }
        return this.pricRtnl;
    }

    public boolean isSetPricRtnl() {
        return ((this.pricRtnl!= null)&&(!this.pricRtnl.isEmpty()));
    }

    public void unsetPricRtnl() {
        this.pricRtnl = null;
    }

    /**
     * Gets the value of the surndrPnltyAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getSurndrPnltyAmnt() {
        return surndrPnltyAmnt;
    }

    /**
     * Sets the value of the surndrPnltyAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setSurndrPnltyAmnt(CurrencyAndAmountType value) {
        this.surndrPnltyAmnt = value;
    }

    public boolean isSetSurndrPnltyAmnt() {
        return (this.surndrPnltyAmnt!= null);
    }

    /**
     * Gets the value of the surndrPnltyRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getSurndrPnltyRate() {
        return surndrPnltyRate;
    }

    /**
     * Sets the value of the surndrPnltyRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setSurndrPnltyRate(BasisRateType value) {
        this.surndrPnltyRate = value;
    }

    public boolean isSetSurndrPnltyRate() {
        return (this.surndrPnltyRate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covIdntfctn", covIdntfctn).add("covStatus", covStatus).add("linkdObjcts", linkdObjcts).add("covData", covData).add("claimData", claimData).add("premData", premData).add("paymntRef", paymntRef).add("benfciaryClause", benfciaryClause).add("feeDerogtn", feeDerogtn).add("partExclsn", partExclsn).add("extraPrem", extraPrem).add("pricRtnl", pricRtnl).add("surndrPnltyAmnt", surndrPnltyAmnt).add("surndrPnltyRate", surndrPnltyRate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covIdntfctn, covStatus, linkdObjcts, covData, claimData, premData, paymntRef, benfciaryClause, feeDerogtn, partExclsn, extraPrem, pricRtnl, surndrPnltyAmnt, surndrPnltyRate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProtectionPolicyCoverDataType o = ((ProtectionPolicyCoverDataType) other);
        return (((((((((((((Objects.equal(covIdntfctn, o.covIdntfctn)&&Objects.equal(covStatus, o.covStatus))&&Objects.equal(linkdObjcts, o.linkdObjcts))&&Objects.equal(covData, o.covData))&&Objects.equal(claimData, o.claimData))&&Objects.equal(premData, o.premData))&&Objects.equal(paymntRef, o.paymntRef))&&Objects.equal(benfciaryClause, o.benfciaryClause))&&Objects.equal(feeDerogtn, o.feeDerogtn))&&Objects.equal(partExclsn, o.partExclsn))&&Objects.equal(extraPrem, o.extraPrem))&&Objects.equal(pricRtnl, o.pricRtnl))&&Objects.equal(surndrPnltyAmnt, o.surndrPnltyAmnt))&&Objects.equal(surndrPnltyRate, o.surndrPnltyRate));
    }

}
