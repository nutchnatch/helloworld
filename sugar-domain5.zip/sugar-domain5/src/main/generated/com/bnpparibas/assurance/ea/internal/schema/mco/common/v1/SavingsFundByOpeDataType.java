
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Détails des montants par
 * 				opération pour un support
 * 			
 * 
 * <p>Java class for SavingsFundByOpeDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsFundByOpeDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FinanclFundIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExtendedFinancialFundIdentificationType"/&gt;
 *         &lt;element name="UnitNumb" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsFundByOpeDataType", propOrder = {
    "financlFundIdntfctn",
    "unitNumb",
    "amnt"
})
public class SavingsFundByOpeDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FinanclFundIdntfctn", required = true)
    protected ExtendedFinancialFundIdentificationType financlFundIdntfctn;
    @XmlElement(name = "UnitNumb")
    protected Double unitNumb;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsFundByOpeDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsFundByOpeDataType(final ExtendedFinancialFundIdentificationType financlFundIdntfctn, final Double unitNumb, final CurrencyAndAmountType amnt) {
        this.financlFundIdntfctn = financlFundIdntfctn;
        this.unitNumb = unitNumb;
        this.amnt = amnt;
    }

    /**
     * Gets the value of the financlFundIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ExtendedFinancialFundIdentificationType }
     *     
     */
    public ExtendedFinancialFundIdentificationType getFinanclFundIdntfctn() {
        return financlFundIdntfctn;
    }

    /**
     * Sets the value of the financlFundIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtendedFinancialFundIdentificationType }
     *     
     */
    public void setFinanclFundIdntfctn(ExtendedFinancialFundIdentificationType value) {
        this.financlFundIdntfctn = value;
    }

    public boolean isSetFinanclFundIdntfctn() {
        return (this.financlFundIdntfctn!= null);
    }

    /**
     * Gets the value of the unitNumb property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getUnitNumb() {
        return unitNumb;
    }

    /**
     * Sets the value of the unitNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setUnitNumb(Double value) {
        this.unitNumb = value;
    }

    public boolean isSetUnitNumb() {
        return (this.unitNumb!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("financlFundIdntfctn", financlFundIdntfctn).add("unitNumb", unitNumb).add("amnt", amnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(financlFundIdntfctn, unitNumb, amnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsFundByOpeDataType o = ((SavingsFundByOpeDataType) other);
        return ((Objects.equal(financlFundIdntfctn, o.financlFundIdntfctn)&&Objects.equal(unitNumb, o.unitNumb))&&Objects.equal(amnt, o.amnt));
    }

}
