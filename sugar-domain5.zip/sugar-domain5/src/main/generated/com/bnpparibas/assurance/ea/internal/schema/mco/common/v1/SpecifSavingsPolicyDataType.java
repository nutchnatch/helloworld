
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage specific and global data which are
 * 				not common to all countries
 * 			
 * 
 * <p>Java class for SpecifSavingsPolicyDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SpecifSavingsPolicyDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PremClass" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsPremiumClassDataType" minOccurs="0"/&gt;
 *         &lt;element name="SpecMgmtIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="HandcpIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecifSavingsPolicyDataType", propOrder = {
    "premClass",
    "specMgmtIndic",
    "handcpIndic"
})
public class SpecifSavingsPolicyDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PremClass")
    protected SavingsPremiumClassDataType premClass;
    @XmlElement(name = "SpecMgmtIndic")
    protected String specMgmtIndic;
    @XmlElement(name = "HandcpIndic")
    protected String handcpIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public SpecifSavingsPolicyDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SpecifSavingsPolicyDataType(final SavingsPremiumClassDataType premClass, final String specMgmtIndic, final String handcpIndic) {
        this.premClass = premClass;
        this.specMgmtIndic = specMgmtIndic;
        this.handcpIndic = handcpIndic;
    }

    /**
     * Gets the value of the premClass property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsPremiumClassDataType }
     *     
     */
    public SavingsPremiumClassDataType getPremClass() {
        return premClass;
    }

    /**
     * Sets the value of the premClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsPremiumClassDataType }
     *     
     */
    public void setPremClass(SavingsPremiumClassDataType value) {
        this.premClass = value;
    }

    public boolean isSetPremClass() {
        return (this.premClass!= null);
    }

    /**
     * Gets the value of the specMgmtIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecMgmtIndic() {
        return specMgmtIndic;
    }

    /**
     * Sets the value of the specMgmtIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecMgmtIndic(String value) {
        this.specMgmtIndic = value;
    }

    public boolean isSetSpecMgmtIndic() {
        return (this.specMgmtIndic!= null);
    }

    /**
     * Gets the value of the handcpIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHandcpIndic() {
        return handcpIndic;
    }

    /**
     * Sets the value of the handcpIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHandcpIndic(String value) {
        this.handcpIndic = value;
    }

    public boolean isSetHandcpIndic() {
        return (this.handcpIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("premClass", premClass).add("specMgmtIndic", specMgmtIndic).add("handcpIndic", handcpIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(premClass, specMgmtIndic, handcpIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SpecifSavingsPolicyDataType o = ((SpecifSavingsPolicyDataType) other);
        return ((Objects.equal(premClass, o.premClass)&&Objects.equal(specMgmtIndic, o.specMgmtIndic))&&Objects.equal(handcpIndic, o.handcpIndic));
    }

}
