
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage global data for savings policy
 * 			
 * 
 * <p>Java class for SavingsPolicyDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SavingsPolicyDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SignDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ReciptDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="PolCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="PrtctnSubscrptnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="ClosngClause" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoSubscriptionClosingClauseCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="DuratnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MaturityTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CurntDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="PolPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType"/&gt;
 *         &lt;element name="TermDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="SubscrptnChnnl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommunicationChannelCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="InitPremAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="MltiInsrdIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="SigndSubscrptnDocIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SavingsPolicyDataType", propOrder = {
    "signDate",
    "reciptDate",
    "polCurr",
    "prtctnSubscrptnIndic",
    "closngClause",
    "duratn",
    "duratnType",
    "curntDuratn",
    "polPrd",
    "termDate",
    "subscrptnChnnl",
    "initPremAmnt",
    "mltiInsrdIndic",
    "signdSubscrptnDocIndic"
})
public class SavingsPolicyDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SignDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date signDate;
    @XmlElement(name = "ReciptDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date reciptDate;
    @XmlElement(name = "PolCurr")
    protected String polCurr;
    @XmlElement(name = "PrtctnSubscrptnIndic")
    protected String prtctnSubscrptnIndic;
    @XmlElement(name = "ClosngClause")
    protected String closngClause;
    @XmlElement(name = "Duratn")
    protected DurationType duratn;
    @XmlElement(name = "DuratnType")
    protected String duratnType;
    @XmlElement(name = "CurntDuratn")
    protected DurationType curntDuratn;
    @XmlElement(name = "PolPrd", required = true)
    protected DatePeriodType polPrd;
    @XmlElement(name = "TermDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date termDate;
    @XmlElement(name = "SubscrptnChnnl")
    protected String subscrptnChnnl;
    @XmlElement(name = "InitPremAmnt")
    protected CurrencyAndAmountType initPremAmnt;
    @XmlElement(name = "MltiInsrdIndic")
    protected String mltiInsrdIndic;
    @XmlElement(name = "SigndSubscrptnDocIndic")
    protected String signdSubscrptnDocIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public SavingsPolicyDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public SavingsPolicyDataType(final Date signDate, final Date reciptDate, final String polCurr, final String prtctnSubscrptnIndic, final String closngClause, final DurationType duratn, final String duratnType, final DurationType curntDuratn, final DatePeriodType polPrd, final Date termDate, final String subscrptnChnnl, final CurrencyAndAmountType initPremAmnt, final String mltiInsrdIndic, final String signdSubscrptnDocIndic) {
        this.signDate = signDate;
        this.reciptDate = reciptDate;
        this.polCurr = polCurr;
        this.prtctnSubscrptnIndic = prtctnSubscrptnIndic;
        this.closngClause = closngClause;
        this.duratn = duratn;
        this.duratnType = duratnType;
        this.curntDuratn = curntDuratn;
        this.polPrd = polPrd;
        this.termDate = termDate;
        this.subscrptnChnnl = subscrptnChnnl;
        this.initPremAmnt = initPremAmnt;
        this.mltiInsrdIndic = mltiInsrdIndic;
        this.signdSubscrptnDocIndic = signdSubscrptnDocIndic;
    }

    /**
     * Gets the value of the signDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSignDate() {
        return signDate;
    }

    /**
     * Sets the value of the signDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignDate(Date value) {
        this.signDate = value;
    }

    public boolean isSetSignDate() {
        return (this.signDate!= null);
    }

    /**
     * Gets the value of the reciptDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getReciptDate() {
        return reciptDate;
    }

    /**
     * Sets the value of the reciptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReciptDate(Date value) {
        this.reciptDate = value;
    }

    public boolean isSetReciptDate() {
        return (this.reciptDate!= null);
    }

    /**
     * Gets the value of the polCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolCurr() {
        return polCurr;
    }

    /**
     * Sets the value of the polCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolCurr(String value) {
        this.polCurr = value;
    }

    public boolean isSetPolCurr() {
        return (this.polCurr!= null);
    }

    /**
     * Gets the value of the prtctnSubscrptnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrtctnSubscrptnIndic() {
        return prtctnSubscrptnIndic;
    }

    /**
     * Sets the value of the prtctnSubscrptnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrtctnSubscrptnIndic(String value) {
        this.prtctnSubscrptnIndic = value;
    }

    public boolean isSetPrtctnSubscrptnIndic() {
        return (this.prtctnSubscrptnIndic!= null);
    }

    /**
     * Gets the value of the closngClause property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClosngClause() {
        return closngClause;
    }

    /**
     * Sets the value of the closngClause property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosngClause(String value) {
        this.closngClause = value;
    }

    public boolean isSetClosngClause() {
        return (this.closngClause!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    /**
     * Gets the value of the duratnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDuratnType() {
        return duratnType;
    }

    /**
     * Sets the value of the duratnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDuratnType(String value) {
        this.duratnType = value;
    }

    public boolean isSetDuratnType() {
        return (this.duratnType!= null);
    }

    /**
     * Gets the value of the curntDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getCurntDuratn() {
        return curntDuratn;
    }

    /**
     * Sets the value of the curntDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setCurntDuratn(DurationType value) {
        this.curntDuratn = value;
    }

    public boolean isSetCurntDuratn() {
        return (this.curntDuratn!= null);
    }

    /**
     * Gets the value of the polPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getPolPrd() {
        return polPrd;
    }

    /**
     * Sets the value of the polPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setPolPrd(DatePeriodType value) {
        this.polPrd = value;
    }

    public boolean isSetPolPrd() {
        return (this.polPrd!= null);
    }

    /**
     * Gets the value of the termDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getTermDate() {
        return termDate;
    }

    /**
     * Sets the value of the termDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTermDate(Date value) {
        this.termDate = value;
    }

    public boolean isSetTermDate() {
        return (this.termDate!= null);
    }

    /**
     * Gets the value of the subscrptnChnnl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscrptnChnnl() {
        return subscrptnChnnl;
    }

    /**
     * Sets the value of the subscrptnChnnl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscrptnChnnl(String value) {
        this.subscrptnChnnl = value;
    }

    public boolean isSetSubscrptnChnnl() {
        return (this.subscrptnChnnl!= null);
    }

    /**
     * Gets the value of the initPremAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInitPremAmnt() {
        return initPremAmnt;
    }

    /**
     * Sets the value of the initPremAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInitPremAmnt(CurrencyAndAmountType value) {
        this.initPremAmnt = value;
    }

    public boolean isSetInitPremAmnt() {
        return (this.initPremAmnt!= null);
    }

    /**
     * Gets the value of the mltiInsrdIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMltiInsrdIndic() {
        return mltiInsrdIndic;
    }

    /**
     * Sets the value of the mltiInsrdIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMltiInsrdIndic(String value) {
        this.mltiInsrdIndic = value;
    }

    public boolean isSetMltiInsrdIndic() {
        return (this.mltiInsrdIndic!= null);
    }

    /**
     * Gets the value of the signdSubscrptnDocIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSigndSubscrptnDocIndic() {
        return signdSubscrptnDocIndic;
    }

    /**
     * Sets the value of the signdSubscrptnDocIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSigndSubscrptnDocIndic(String value) {
        this.signdSubscrptnDocIndic = value;
    }

    public boolean isSetSigndSubscrptnDocIndic() {
        return (this.signdSubscrptnDocIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("signDate", signDate).add("reciptDate", reciptDate).add("polCurr", polCurr).add("prtctnSubscrptnIndic", prtctnSubscrptnIndic).add("closngClause", closngClause).add("duratn", duratn).add("duratnType", duratnType).add("curntDuratn", curntDuratn).add("polPrd", polPrd).add("termDate", termDate).add("subscrptnChnnl", subscrptnChnnl).add("initPremAmnt", initPremAmnt).add("mltiInsrdIndic", mltiInsrdIndic).add("signdSubscrptnDocIndic", signdSubscrptnDocIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(signDate, reciptDate, polCurr, prtctnSubscrptnIndic, closngClause, duratn, duratnType, curntDuratn, polPrd, termDate, subscrptnChnnl, initPremAmnt, mltiInsrdIndic, signdSubscrptnDocIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final SavingsPolicyDataType o = ((SavingsPolicyDataType) other);
        return (((((((((((((Objects.equal(signDate, o.signDate)&&Objects.equal(reciptDate, o.reciptDate))&&Objects.equal(polCurr, o.polCurr))&&Objects.equal(prtctnSubscrptnIndic, o.prtctnSubscrptnIndic))&&Objects.equal(closngClause, o.closngClause))&&Objects.equal(duratn, o.duratn))&&Objects.equal(duratnType, o.duratnType))&&Objects.equal(curntDuratn, o.curntDuratn))&&Objects.equal(polPrd, o.polPrd))&&Objects.equal(termDate, o.termDate))&&Objects.equal(subscrptnChnnl, o.subscrptnChnnl))&&Objects.equal(initPremAmnt, o.initPremAmnt))&&Objects.equal(mltiInsrdIndic, o.mltiInsrdIndic))&&Objects.equal(signdSubscrptnDocIndic, o.signdSubscrptnDocIndic));
    }

}
