
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * To mange information on policy termination
 * 			
 * 
 * <p>Java class for PolicyTerminationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyTerminationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Motiv" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsPolicyTerminationMotiveCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="EvtRcveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="BenefitType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitModeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Annty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AnnuityDataType" minOccurs="0"/&gt;
 *         &lt;element name="TransfPolIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyTerminationDataType", propOrder = {
    "motiv",
    "evtRcveDate",
    "benefitType",
    "annty",
    "transfPolIdntfctn"
})
public class PolicyTerminationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Motiv")
    protected String motiv;
    @XmlElement(name = "EvtRcveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date evtRcveDate;
    @XmlElement(name = "BenefitType")
    protected String benefitType;
    @XmlElement(name = "Annty")
    protected AnnuityDataType annty;
    @XmlElement(name = "TransfPolIdntfctn")
    protected ObjectIdentificationType transfPolIdntfctn;

    /**
     * Default no-arg constructor
     * 
     */
    public PolicyTerminationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PolicyTerminationDataType(final String motiv, final Date evtRcveDate, final String benefitType, final AnnuityDataType annty, final ObjectIdentificationType transfPolIdntfctn) {
        this.motiv = motiv;
        this.evtRcveDate = evtRcveDate;
        this.benefitType = benefitType;
        this.annty = annty;
        this.transfPolIdntfctn = transfPolIdntfctn;
    }

    /**
     * Gets the value of the motiv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotiv() {
        return motiv;
    }

    /**
     * Sets the value of the motiv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotiv(String value) {
        this.motiv = value;
    }

    public boolean isSetMotiv() {
        return (this.motiv!= null);
    }

    /**
     * Gets the value of the evtRcveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEvtRcveDate() {
        return evtRcveDate;
    }

    /**
     * Sets the value of the evtRcveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEvtRcveDate(Date value) {
        this.evtRcveDate = value;
    }

    public boolean isSetEvtRcveDate() {
        return (this.evtRcveDate!= null);
    }

    /**
     * Gets the value of the benefitType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBenefitType() {
        return benefitType;
    }

    /**
     * Sets the value of the benefitType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBenefitType(String value) {
        this.benefitType = value;
    }

    public boolean isSetBenefitType() {
        return (this.benefitType!= null);
    }

    /**
     * Gets the value of the annty property.
     * 
     * @return
     *     possible object is
     *     {@link AnnuityDataType }
     *     
     */
    public AnnuityDataType getAnnty() {
        return annty;
    }

    /**
     * Sets the value of the annty property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnnuityDataType }
     *     
     */
    public void setAnnty(AnnuityDataType value) {
        this.annty = value;
    }

    public boolean isSetAnnty() {
        return (this.annty!= null);
    }

    /**
     * Gets the value of the transfPolIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getTransfPolIdntfctn() {
        return transfPolIdntfctn;
    }

    /**
     * Sets the value of the transfPolIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setTransfPolIdntfctn(ObjectIdentificationType value) {
        this.transfPolIdntfctn = value;
    }

    public boolean isSetTransfPolIdntfctn() {
        return (this.transfPolIdntfctn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("motiv", motiv).add("evtRcveDate", evtRcveDate).add("benefitType", benefitType).add("annty", annty).add("transfPolIdntfctn", transfPolIdntfctn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(motiv, evtRcveDate, benefitType, annty, transfPolIdntfctn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PolicyTerminationDataType o = ((PolicyTerminationDataType) other);
        return ((((Objects.equal(motiv, o.motiv)&&Objects.equal(evtRcveDate, o.evtRcveDate))&&Objects.equal(benefitType, o.benefitType))&&Objects.equal(annty, o.annty))&&Objects.equal(transfPolIdntfctn, o.transfPolIdntfctn));
    }

}
