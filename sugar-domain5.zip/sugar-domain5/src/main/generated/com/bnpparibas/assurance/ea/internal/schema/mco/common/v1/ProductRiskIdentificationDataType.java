
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Risk indentification 
 * 
 * <p>Java class for ProductRiskIdentificationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductRiskIdentificationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode"/&gt;
 *         &lt;element name="LifeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LifeIndicatorCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductRiskIdentificationDataType", propOrder = {
    "id",
    "code",
    "lifeIndic"
})
public class ProductRiskIdentificationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "Code", required = true)
    protected String code;
    @XmlElement(name = "LifeIndic")
    protected String lifeIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public ProductRiskIdentificationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ProductRiskIdentificationDataType(final String id, final String code, final String lifeIndic) {
        this.id = id;
        this.code = code;
        this.lifeIndic = lifeIndic;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    public boolean isSetCode() {
        return (this.code!= null);
    }

    /**
     * Gets the value of the lifeIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifeIndic() {
        return lifeIndic;
    }

    /**
     * Sets the value of the lifeIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifeIndic(String value) {
        this.lifeIndic = value;
    }

    public boolean isSetLifeIndic() {
        return (this.lifeIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("code", code).add("lifeIndic", lifeIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, code, lifeIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ProductRiskIdentificationDataType o = ((ProductRiskIdentificationDataType) other);
        return ((Objects.equal(id, o.id)&&Objects.equal(code, o.code))&&Objects.equal(lifeIndic, o.lifeIndic));
    }

}
