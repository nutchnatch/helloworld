package com.bnpp.cardif.sugar.domain.documentfile;

import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.UUID;

import org.junit.Test;

import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

public class DocumentFileBuilderTest {
    @Test
    public void testBuildClassicDocumentFile() {
        String scope = "SYLDAVIA";
        String URI = UUID.randomUUID().toString();
        String formatCode = "PDF";
        String name = "My document ";
        Date createDate = new Date();
        DocumentFile documentFile = DocumentFileBuilder.scope(scope).URI(URI).name(name).formatCode(formatCode)
                .createDate(createDate).build();
        assertEquals(scope, documentFile.getScope());
        assertEquals(URI, documentFile.getURI());
        assertEquals(name, documentFile.getName());
        assertEquals(formatCode, documentFile.getFormatCode());
        assertEquals(createDate, documentFile.getCreateDate());
    }
}
