package com.bnpp.cardif.sugar.domain.folder.test;

import java.util.Date;
import java.util.UUID;

import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.MCOFolderType.ChildComponents;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;

/**
 * Utility class allowing to generate folders for test purposes
 * 
 * @author Romain
 * 
 */
public class FolderMockUtility {
    public static final String SCOPE = "Syldavia";

    /**
     * Build a claim folder
     * 
     * @param i
     *            uselful to never add two folder with the same name at the
     *            building a list of claim folder
     * @return the built claim folder
     */
    public static Folder buildClaimFolder(int i) {
        Folder folder = new Folder();
        FolderId id = buildFolderId();
        folder.setFolderId(id);
        folder.setScope(SCOPE);
        FolderDataType folderDataType = new FolderDataType();
        folderDataType.setName("My Folder Test " + UUID.randomUUID().toString());
        folderDataType.setOwner("Owner");
        folderDataType.setStatusCode(FolderStatusCodeType.OUT_OF_DATE);
        folderDataType.setCreatnDate(new Date());
        folderDataType.setUpdtDate(new Date());
        folderDataType.setRetentionEndDate(new Date());
        ClassId clazz = new ClassId();
        clazz.setValue("fd60a369-a6c8-4d69-a1f3-d869905f4acc");
        clazz.setIssuer("CARDIF");
        folderDataType.setClassId(clazz);
        folder.setData(folderDataType);
        Tags tags = new Tags();
        Tag beneficiaryName = new Tag();
        beneficiaryName.setName("BeneficiaryName");
        beneficiaryName.setValue("Mr Smith");
        tags.getTag().add(beneficiaryName);
        folder.setTags(tags);
        ChildComponents childComponent = new ChildComponents();
        childComponent.getDocument().add(DocumentMockUtil.buildClaimDocument());
        folder.setChildComponents(childComponent);
        return folder;
    }

    public static FolderId buildFolderId() {
        FolderId id = new FolderId();
        id.setValue(UUID.randomUUID().toString());
        id.setIssuer("CARDIF");
        id.setScheme("Sugar");
        return id;
    }
}
