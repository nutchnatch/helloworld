package com.bnpp.cardif.sugar.core.api.task;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

public interface TaskValidator {

    void validateCreation(List<Task> tasks) throws SugarTechnicalException, SugarFunctionalException;

    void validateUpdateStatus(String scope, List<TaskId> tasks, String status)
            throws SugarTechnicalException, SugarFunctionalException;

    void validateLock(String scope, List<TaskId> tasks) throws SugarTechnicalException, SugarFunctionalException;

    void validateTransfer(String scope, List<TaskId> taskIds, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException;

    void validateGetTaskInBasket(String scope, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException;

    void validateGetTaskForDocument(String scope, Id docId) throws SugarTechnicalException, SugarFunctionalException;

    void validateGet(String scope, List<TaskId> taskIds) throws SugarTechnicalException, SugarFunctionalException;

    void validateUnLock(String scope, List<TaskId> tasks) throws SugarTechnicalException, SugarFunctionalException;

}
