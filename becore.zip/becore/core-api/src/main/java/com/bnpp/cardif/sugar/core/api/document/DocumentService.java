package com.bnpp.cardif.sugar.core.api.document;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

/**
 * Manages Sugar documents
 * 
 * @author Christopher Laszczuk
 * 
 */
//TODO - Should use Collection or Iterable interfaces when applicable, instead of List<>
public interface DocumentService {
    /**
     * Stores a list of documents into Sugar DMS
     * 
     * @param documentsToStore
     *            The list of documents to store
     * @return The list of stored documents
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of documents
     * @throws SugarFunctionalException
     *             If a functional error occurred while storing the supplied
     *             list of documents
     */
    List<Document> store(List<Document> documentsToStore) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Create and launch the events after a document store. This methods is
     * separated from the store() one to separate transactions, to be sure the
     * storage is done when the events are launched.
     * 
     * @param flatDocumentsToStore
     *            The list of stored documents. Uses the return value from the
     *            "store()" methods.
     */
    void fireStoreDocEvent(List<Document> flatDocumentsToStore);

    /**
     * Get documents according to their {@link Id}
     * 
     * @param scope
     *            The business scope
     * @param ids
     *            A list of unique document identifiers
     * @return documents corresponding to the supplied ids
     * @throws SugarFunctionalException
     *             If the list of Id is null
     * @throws SugarTechnicalException
     */
    List<Document> get(String scope, List<Id> listIds, boolean isChildrenInclude, boolean isDocumentFileInclude)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Finds a list of documents according with pagination. This layer applies
     * functional search requirements then calls DAO layer
     * 
     * @param requestExpression
     * @param criteria
     *            A {@link Criteria} to apply to the search
     * @param An
     *            {@link OrderClause} to apply to the search
     * @param start
     *            The start index from which search. Indexes starts from zero.
     * @param max
     *            The maximum number of documents to fetch
     * @param orderExpression
     *            The expression describing the order to apply
     * @return The found documents according to supplied parameters
     * @throws SugarTechnicalException
     *             If a technical error occurs
     * @throws SugarFunctional
     *             If a functional error occurs
     */
    SearchResults<Document> find(Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Update documents according to their {@link Id}
     * 
     * @param documentsToUpdate
     * @return list of uploaded file
     * @throws SugarFunctionalException
     * @throws SugarTechnicalException
     */
    List<Document> update(List<Document> documentsToUpdate) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Delete documents
     * 
     * @param documentsToDelete
     * @return deleted documents
     * @throws SugarFunctionalException
     * @throws SugarTechnicalException
     */
    List<Document> delete(List<Id> documentsIdToDelete, String scope)
            throws SugarFunctionalException, SugarTechnicalException;

}
