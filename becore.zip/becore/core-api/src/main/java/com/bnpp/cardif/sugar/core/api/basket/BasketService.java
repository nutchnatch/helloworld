package com.bnpp.cardif.sugar.core.api.basket;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;

/**
 * Manage Baskets
 * 
 * @author shanthan SIVARAJAH
 * 
 */
public interface BasketService {

    List<Basket> create(List<Basket> basketsToStore) throws SugarTechnicalException, SugarFunctionalException;

    List<Basket> get(List<BasketId> basketsId, String scope) throws SugarTechnicalException, SugarFunctionalException;

    List<Basket> update(List<Basket> basketsToUpdate) throws SugarTechnicalException, SugarFunctionalException;

    void delete(List<BasketId> basketsIdToDelete, String scope)
            throws SugarTechnicalException, SugarFunctionalException;

    List<Basket> filterAllowedBasket(List<Basket> baskets);

    List<Basket> getAllUnfiltered(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkReadAccessibility(List<BasketId> ids, String scope);

}
