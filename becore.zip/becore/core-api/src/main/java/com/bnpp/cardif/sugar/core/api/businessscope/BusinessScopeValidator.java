package com.bnpp.cardif.sugar.core.api.businessscope;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;

public interface BusinessScopeValidator {

    void checkCreationValidity(List<BusinessScope> scopes) throws SugarFunctionalException, SugarTechnicalException;

    void checkExistence(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkUpdateValidity(List<BusinessScope> scopes) throws SugarFunctionalException, SugarTechnicalException;

    void checkExistence(List<String> scopes) throws SugarTechnicalException, SugarFunctionalException;

    void checkUserIsAllowedAndSetCurrentScope(String scope) throws SugarFunctionalException;
}
