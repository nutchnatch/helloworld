package com.bnpp.cardif.sugar.core.api.documentfile;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;

public interface DocumentFileValidator {

    void checkAddValidity(List<DocumentFile> documentFiles) throws SugarTechnicalException, SugarFunctionalException;

    void checkGetValidity(String scope, List<URI> uri) throws SugarTechnicalException, SugarFunctionalException;

    void checkDeleteValidity(String scope, List<URI> uri) throws SugarTechnicalException, SugarFunctionalException;
}
