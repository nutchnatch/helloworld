package com.bnpp.cardif.sugar.core.api.folder;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

/**
 * Manage Folders
 * 
 * @author Romain
 * 
 */
public interface FolderService {

    /**
     * Add (store) a list of Folders into the Sugar DMS
     * 
     * @param folderToAdd
     *            The list of folders to store
     * @return The list of stored folders
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of folders
     * @throws SugarFunctionalException
     *             If a functional error occurred while storing the supplied
     *             list of folders
     */
    List<Folder> add(List<Folder> foldersToAdd) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Update a list of Folders into the Sugar DMS
     * 
     * @param folderToUpdate
     *            The list of folders to update
     * @param scope
     *            the business scope concerned
     * @return The list of updated folders
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of folders
     * @throws SugarFunctionalException
     *             If a functional error occurred while storing the supplied
     *             list of folders
     */
    List<Folder> update(List<Folder> foldersToUpdate, String scope)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get a list of folders into the Sugar DMS
     * 
     * @param foldersIds
     *            The list of the ids of folders to get
     * @param scope
     *            the business scope concerned
     * @return the list of folders corresponding to the ids
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of folders
     * @throws SugarFunctionalException
     *             If a functional error occurred while storing the supplied
     *             list of folders
     */
    List<Folder> get(List<FolderId> foldersIds, String scope) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Finds a list of folders according with pagination. This layer applies
     * functional search requirements then calls DAO layer *
     * 
     * @param criteria
     *            A {@link Criteria} to apply to the search
     * @param A
     *            {@link OrderClause} to apply to the search
     * @param start
     *            The start index from which search. Indexes starts from zero.
     * @param max
     *            The maximum number of folders to fetch
     * @param orderExpression
     *            The expression describing the order to apply
     * @return The found folders according to supplied parameters
     * @throws SugarTechnicalException
     *             If a technical error occurs
     * @throws SugarFunctional
     *             If a functional error occurs
     */
    SearchResults<Folder> find(Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException, SugarFunctionalException;

    Folder getBySymbolicName(String scope, String symbolicName)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get all folders attached to given document
     * 
     * @param document
     * @return
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    List<Folder> getAllFoldersAttached(Document document) throws SugarTechnicalException, SugarFunctionalException;

}
