package com.bnpp.cardif.sugar.core.api.document;

import java.util.List;
import java.util.Map;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

public interface DocumentValidator {

    void checkStoreValidity(List<Document> documents) throws SugarFunctionalException, SugarTechnicalException;

    void checkUpdateValidity(List<Document> documentsToUpdate, Map<Id, Document> docIdToOldDoc)
            throws SugarTechnicalException, SugarFunctionalException;

    void checkExistence(String scope, List<Id> documentIds) throws SugarFunctionalException, SugarTechnicalException;

    void checkGetValidity(String scope) throws SugarFunctionalException, SugarTechnicalException;

    void checkDeleteValidity(String scope) throws SugarFunctionalException, SugarTechnicalException;

    void computeValidityCode(Document document, List<Document> documents)
            throws SugarTechnicalException, SugarFunctionalException;

    void checkFindValidity(String scope, Criteria criteria, OrderClause orderClause, long max)
            throws SugarFunctionalException, SugarTechnicalException;

    void computeValidityCode(Document document, Document oldDoc, List<Document> flatDocumentsToUpdate)
            throws SugarTechnicalException, SugarFunctionalException;

}
