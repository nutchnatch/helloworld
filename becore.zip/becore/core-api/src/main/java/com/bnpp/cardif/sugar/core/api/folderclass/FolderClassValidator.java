package com.bnpp.cardif.sugar.core.api.folderclass;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;

public interface FolderClassValidator {

    void checkCreationValidity(List<FolderClass> folderClasses)
            throws SugarTechnicalException, SugarFunctionalException;

    void checkUpdateValidity(List<FolderClass> folderClasses) throws SugarTechnicalException, SugarFunctionalException;

    void checkExistence(String scope, List<ClassId> classesToCheck)
            throws SugarTechnicalException, SugarFunctionalException;

    void checkGetValidity(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkGetAll(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkActivateValidity(String scope) throws SugarTechnicalException, SugarFunctionalException;

}
