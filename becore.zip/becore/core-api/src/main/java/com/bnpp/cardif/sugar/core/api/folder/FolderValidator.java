package com.bnpp.cardif.sugar.core.api.folder;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

public interface FolderValidator {

    void checkCreationValidity(List<Folder> folders) throws SugarTechnicalException, SugarFunctionalException;

    void checkUpdateValidity(List<Folder> folders) throws SugarTechnicalException, SugarFunctionalException;

    void checkGetValidity(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkGetBySymbolicName(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkFindValidity(String scope, Criteria criteria, OrderClause order, long max)
            throws SugarTechnicalException, SugarFunctionalException;

}
