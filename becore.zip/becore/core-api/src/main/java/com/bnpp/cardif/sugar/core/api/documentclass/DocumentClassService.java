package com.bnpp.cardif.sugar.core.api.documentclass;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

/**
 * Manage Sugar Document Class
 * 
 * @author Romain
 * 
 */
public interface DocumentClassService {
    /**
     * Search the list of document classes into Sugar DMS
     * 
     * @param scope
     *            The business scope
     * @param category
     *            The {@link Category} referenced by document classes
     * @param isActiveOnly
     *            Determines if all classes have to been fetched or only active
     *            ones
     * @return the list of document classes
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of documents
     * @throws SugarFunctionalException
     *             If a functional error occurred while storing the supplied
     *             list of documents
     */
    List<DocumentClass> search(String scope, Category category, boolean isActiveOnly)
            throws SugarTechnicalException, SugarFunctionalException;

    List<DocumentClass> add(List<DocumentClass> list) throws SugarTechnicalException, SugarFunctionalException;

    List<DocumentClass> update(List<DocumentClass> list, boolean changeVersion)
            throws SugarTechnicalException, SugarFunctionalException;

    List<DocumentClass> get(String scope, List<ClassId> classId)
            throws SugarTechnicalException, SugarFunctionalException;

    void activate(String scope, List<ClassId> classId, boolean activate)
            throws SugarTechnicalException, SugarFunctionalException;

}
