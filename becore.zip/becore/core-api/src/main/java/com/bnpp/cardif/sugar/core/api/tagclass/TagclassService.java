package com.bnpp.cardif.sugar.core.api.tagclass;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

/**
 * Manages TagClasses
 * 
 * @author Florian Deruette
 * 
 */
public interface TagclassService {
    /**
     * Store a list of @link{TagClass}
     * 
     * @param tagClasses
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    void store(List<TagClass> tagClasses) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get all @link{TagClass} corresponding to the Scope
     * 
     * @param scope
     * @return @link{TagClass} corresponding to the Scope
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    List<TagClass> getAll(String scope) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get a list of the @link{TagClass} corresponding to @link{TagId} within
     * Scope
     * 
     * @param scope
     * @param tagIds
     * @return
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    @Deprecated
    List<TagClass> get(String scope, List<ClassId> tagIds) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get a list of the @link{TagClass} corresponding to @link{TagId} within
     * Scope
     * 
     * @param scope
     * @param symbolicNames
     * @return
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    List<TagClass> getBySymbolicName(String scope, List<String> symbolicNames, boolean throwErrorIfNotFound)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Update @link{TagClass}
     * 
     * @param tagClasses
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    void update(List<TagClass> tagClasses) throws SugarTechnicalException, SugarFunctionalException;

}
