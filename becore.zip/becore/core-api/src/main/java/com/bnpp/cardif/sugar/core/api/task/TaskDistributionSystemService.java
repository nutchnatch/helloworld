package com.bnpp.cardif.sugar.core.api.task;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;

/**
 * System allowing to manage the distribution of tasks named <b>TDS</b>
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface TaskDistributionSystemService {
    /**
     * Pushes a object to the TDS in order to generate a task according to an
     * {@link Object}
     * 
     * @param object
     *            The object which may provokes the generation of a task
     * 
     * @throws SugarTechnicalException
     *             If a technical error occurs
     * @throws SugarFunctionalException
     *             If a functionnal error occurs
     */
    void push(Object object, Action action) throws SugarTechnicalException, SugarFunctionalException;
}
