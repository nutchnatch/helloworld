package com.bnpp.cardif.sugar.core.api.businessscope;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;

/**
 * Manages Business scopes
 * 
 * @author Florian Deruette
 * 
 */
public interface BusinessScopeService {
    /**
     * Store a list of @link{BusinessScope}
     * 
     * @param BusinessScopes
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    void store(List<BusinessScope> businessScopes) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get all @link{BusinessScope} corresponding to the Scope
     * 
     * @return all BusinessScopes
     * @throws SugarTechnicalException
     */
    List<BusinessScope> getAll() throws SugarTechnicalException;

    /**
     * Updates given businessscopes
     * 
     * @param businessScopes
     * @throws SugarTechnicalException
     */
    void update(List<BusinessScope> businessScopes) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * 
     * @param symbolicNames
     * @return business scopes corresponding to given symbolic names
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    public List<BusinessScope> getBySymbolicName(List<String> symbolicNames)
            throws SugarTechnicalException, SugarFunctionalException;

}
