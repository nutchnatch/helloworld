package com.bnpp.cardif.sugar.core.api.document;

import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

/**
 * Factory providing ability to create document id
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface IdFactory {
    /**
     * Generates an unique identifier of document.
     * 
     * @return A random document id
     */
    Id generateDocumentID();

    /**
     * Generates an unique identifier of folder.
     * 
     * @return A random folder id
     */
    FolderId generateFolderID();

    /**
     * Generates an unique identifier of basket.
     * 
     * @return A random basket id
     */
    BasketId generateBasketID();

    /**
     * Generates an unique identifier
     * 
     * @return A random classId
     */
    ClassId generateClassId();

    /**
     * Generates an unique identifier of business scope.
     * 
     * @return A random business scope id
     */
    BusinessScopeId generateBusinessScopeId();

    /**
     * Generates an unique identifier of task
     * 
     * @return A random task id
     */
    TaskId generateTaskId();
}
