package com.bnpp.cardif.sugar.core.api.basket;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;

public interface BasketValidator {

    void checkCreation(List<Basket> baskets) throws SugarTechnicalException, SugarFunctionalException;

    void checkUpdate(List<Basket> basketsToUpdate) throws SugarTechnicalException, SugarFunctionalException;

    void checkGet(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkGetAll(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkDelete(List<BasketId> ids, String scope) throws SugarTechnicalException, SugarFunctionalException;

    List<Basket> checkExistence(List<BasketId> ids, String scope)
            throws SugarTechnicalException, SugarFunctionalException;

}
