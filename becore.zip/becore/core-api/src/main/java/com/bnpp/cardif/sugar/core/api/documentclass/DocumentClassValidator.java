package com.bnpp.cardif.sugar.core.api.documentclass;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

public interface DocumentClassValidator {

    void checkCreationValidity(List<DocumentClass> documentClasses)
            throws SugarFunctionalException, SugarTechnicalException;

    void checkUpdateValidity(List<DocumentClass> documentClasses)
            throws SugarTechnicalException, SugarFunctionalException;

    void checkExistence(List<ClassId> classIdsToCheck, String scope)
            throws SugarTechnicalException, SugarFunctionalException;

    void checkSearchValidity(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkGetValidity(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkActivateValidity(String scope) throws SugarTechnicalException, SugarFunctionalException;

}
