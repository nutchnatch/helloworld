package com.bnpp.cardif.sugar.core.api.task;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;

/**
 * Service managing the generation of tasks
 * 
 * @author Christopher Laszczuk
 * 
 * @param <DATA>
 *            The data type referenced by generated tasks
 * @param <RULES>
 *            The rules type used to generate tasks
 */
public interface TaskGeneratorService<DATA, RULES_ID, RULES> {
    public static interface TaskGeneratorResolver<RULES_ID, RULES> {
        RULES resolve(RULES_ID rulesId) throws SugarFunctionalException;
    }

    /**
     * Generates a task for supplied object
     * 
     * @param object
     *            The object which may trigger the task
     * @param action
     * @param rulesFile
     *            The object which references business rules to apply
     * @throws SugarTechnicalException
     *             If a technical error occurs
     * @throws SugarFunctionalException
     *             If a functional error occurs
     */
    void generate(DATA object, RULES_ID rulesId, TaskGeneratorResolver<RULES_ID, RULES> resolver, Action action)
            throws SugarTechnicalException, SugarFunctionalException;

}
