package com.bnpp.cardif.sugar.core.api.folderclass;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;

/**
 * Manage Folder Classes
 * 
 * @author Romain
 * 
 */
public interface FolderClassService {
    /**
     * Add (store) a list of Folder classes into the Sugar DMS
     * 
     * @param folderClassesToAdd
     *            The list of folder classes to store
     * @return The list of stored folder classes
     * @throws SugarTechnicalException
     *             If a technical error occurred
     * @throws SugarFunctionalException
     *             If a functional error occurred
     */
    List<FolderClass> add(List<FolderClass> folderClassesToAdd)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * The update of folder classes create the same ones with an incremented
     * version ID into the Sugar DMS
     * 
     * @param folderClassesToUpdate
     *            The list of folder classes to update
     * @param createNewVersion
     * @return
     * @throws SugarTechnicalException
     *             If a technical error occurred
     * @throws SugarFunctionalException
     *             If a functional error occurred
     */
    List<FolderClass> update(List<FolderClass> folderClassesToUpdate, boolean createNewVersion)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get a list of folder classes into the Sugar DMS
     * 
     * @param folderClassesIds
     *            The list of folder classes id to fetch
     * @param scope
     *            the business scope concerned
     * @return
     * @throws SugarTechnicalException
     *             If a technical error occurred
     * @throws SugarFunctionalException
     *             If a functional error occurred
     */
    List<FolderClass> get(List<ClassId> folderClassesIds, String scope)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get all folder classes into the Sugar DMS
     * 
     * @param scope
     *            the business scope concerned
     * @param isActiveOnly
     *            return : if false return all folder classes, if true return
     *            only active folder classes
     * @return
     * @throws SugarTechnicalException
     *             If a technical error occurred
     * @throws SugarFunctionalException
     *             If a functional error occurred
     */
    List<FolderClass> getAll(String scope, boolean isActiveOnly)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Finds a list of folder classes according with pagination. This layer
     * applies functional search requirements then calls DAO layer
     * 
     * @param requestExpression
     * @param criteria
     *            A {@link Criteria} to apply to the search
     * @param start
     *            The start index from which search. Indexes starts from zero.
     * @param max
     *            The maximum number of folders to fetch
     * @param orderExpression
     *            The expression describing the order to apply
     * @return The found folders according to supplied parameters
     * @throws SugarTechnicalException
     *             If a technical error occurs
     * @throws SugarFunctional
     *             If a functional error occurs
     */
    SearchResults<FolderClass> find(String requestExpression, Criteria criteria, long start, long max,
            String orderExpression) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Activate or deactivate a list of folder classes into the Sugar DMS
     * 
     * @param folderClassIds
     * @param active
     *            : if true the classes wil be activated, if false they will be
     *            deactivated
     * @param scope
     *            the business scope concerned
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    void setActive(List<ClassId> folderClassIds, boolean active, String scope)
            throws SugarTechnicalException, SugarFunctionalException;

}
