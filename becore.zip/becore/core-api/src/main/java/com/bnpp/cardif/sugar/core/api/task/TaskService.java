package com.bnpp.cardif.sugar.core.api.task;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

/**
 * Manage Baskets and Tasks
 * 
 * @author shanthan SIVARAJAH
 * 
 */
public interface TaskService {
    List<Task> get(String scope, List<TaskId> tasksId) throws SugarTechnicalException, SugarFunctionalException;

    void lock(String scope, List<TaskId> tasksId, String lockerName)
            throws SugarTechnicalException, SugarFunctionalException;

    void unlock(String scope, List<TaskId> tasksId) throws SugarTechnicalException, SugarFunctionalException;

    void transfer(String scope, List<TaskId> taskId, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException;

    SearchResults<Task> getTasksInBasket(String scope, BasketId basketId, int start, int max)
            throws SugarTechnicalException, SugarFunctionalException;

    void create(List<Task> tasks) throws SugarTechnicalException, SugarFunctionalException;

    List<Task> getTasksForDocument(String scope, Id docId) throws SugarTechnicalException, SugarFunctionalException;

    String updateStatus(String scope, List<TaskId> tasksId, String status)
            throws SugarTechnicalException, SugarFunctionalException;

    void unlockAll(String scope, String userName) throws SugarTechnicalException, SugarFunctionalException;
}
