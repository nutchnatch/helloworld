package com.bnpp.cardif.sugar.core.api.acl;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

public interface AclService {
    AccessControlList getByClassId(String scope, ClassId classId, boolean isInstanceValue)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Gets an {@link AccessControlList}
     * 
     * @param scope
     *            The business scope of the ACL
     * @param id
     *            The unique id of the requested ACL
     * @return The ACL corresponding to supplied arguments
     */
    AccessControlList get(String scope, AclId id) throws SugarFunctionalException, SugarTechnicalException;

    List<AccessControlList> getAll(String scope) throws SugarFunctionalException, SugarTechnicalException;

    AccessControlList assignToClass(String scope, AclId aclId, ClassId classId, boolean isInstanceValue)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Assigns default ACL to the supplied {@link ClassId}. The default ACL
     * should be determined according to a business scope
     * 
     * @param scope
     *            The business scope
     * @param classId
     *            The unique id of a class either {@link DocumentClass} or
     *            {@link FolderClass}
     * @throws SugarTechnicalException
     *             If a technical error occurs
     * @throws SugarFunctionalException
     */
    void assignDefault(String scope, ClassId classId) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Assign an ACL to a document in business scope
     * 
     * @param scope
     * @param aclId
     * @param id
     * @return
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    AccessControlList assignToDocument(String scope, AclId aclId, Id id, boolean isReasign)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Fetch ACL according to a scope and and an basket id
     * 
     * @param scope
     * @param id
     * @return
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    AccessControlList getByBasketId(String scope, BasketId id) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Assign an ACL to a basket
     * 
     * @param scope
     * @param aclId
     * @param basketId
     * @return
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    AccessControlList assignToBasket(String scope, AclId aclId, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Assign default ACL to a basket
     * 
     * @param scope
     * @param basketId
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    void assignDefault(String scope, BasketId basketId) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Remove ACL assigned to a basket
     * 
     * @param scope
     * @param basketId
     * @throws SugarTechnicalException
     */
    void remove(String scope, BasketId basketId) throws SugarTechnicalException;

    /**
     * Get a ACL from a documentId
     * 
     * @param scope
     * @param id
     * @return
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    AccessControlList getByDocumentId(String scope, Id id) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get the ACL of a scope. This ACL should be used to check authorizations
     * for scope operations
     * 
     * @param scope
     *            The scope
     * @return The scope ACL
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    AccessControlList getByScope(String scope) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get the default ACL for a scope to apply on
     * {@link ValdtyCode#UNDER_CONSTRUCTION} documents. <br/>
     * <br/>
     * 
     * @param scope
     *            The scope
     * @return The scope ACL
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    AccessControlList getDefault(String scope) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get a ACL from a folderId
     * 
     * @param scope
     * @param folderId
     * @return
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    AccessControlList getByFolderId(String scope, FolderId folderId)
            throws SugarTechnicalException, SugarFunctionalException;

    AccessControlList assignToFolder(String scope, AclId aclId, FolderId folderId)
            throws SugarTechnicalException, SugarFunctionalException;

    AccessControlList setDefaultACL(String scope, AclId aclId) throws SugarTechnicalException, SugarFunctionalException;
}
