package com.bnpp.cardif.sugar.core.api.fact;

import java.util.Date;
import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;

/**
 * Service dedicated to the reporting of Sugar backend application. Part of
 * backend, this service should insure the report of all facts of the
 * application.
 * 
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface ReportingService {
    /**
     * Reports a fact which occurred on an object in Sugar application
     * 
     * @param scope
     *            The business scope
     * @param type
     *            The type of object
     * @param action
     *            The action applied on supplied object
     * @param object
     *            The object concerned by the reported fact
     * @throws SugarTechnicalException
     *             If a technical error occurs
     * @throws SugarFunctionalException
     */
    void report(String scope, ObjectType type, Action action, Object object)
            throws SugarTechnicalException, SugarFunctionalException;

    List<EnvelopeFlows> getEnvelopeFlowsByPeriod(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

    DocumentFile getEnvelopeFlowsReport(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

    List<BasketRatio> getBasketRatio(String scope, Date startDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

    DocumentFile getBasketRatioReport(String scope, Date startDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

    List<DocumentStock> getDocumentStockIndicators(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

    List<FolderStock> getFolderStockIndicators(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

    Summary getReportingSummary(String scope) throws SugarTechnicalException;

    DocumentFile getFolderStockReport(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

    DocumentFile getDocumentStockReport(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

}
