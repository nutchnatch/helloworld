package com.bnpp.cardif.sugar.core.api.fact;

import java.util.Date;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;

public interface ReportingValidator {

    void validateScope(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void validateScopeAndDates(String scope, Date startDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException;

}
