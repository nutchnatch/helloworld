package com.bnpp.cardif.sugar.core.api.documentfile;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;

/**
 * Manages document files
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface DocumentFileService {
    /**
     * Adds a list of document files into Sugar DMS. This method is responsible
     * to insure consistency of data as creation date or unique identifier so if
     * these parameters are set, this method does not take care of those.
     * 
     * @param documentFiles
     *            The files to add
     * @return The added document files. This list and its files are the same
     *         instance as supplied in parameter. These files are returned as
     *         identifiers which implies no content is returned.
     * @throws SugarTechnicalException
     *             If a technical error occurred while adding the supplied files
     * @throws SugarFunctionalException
     */
    List<DocumentFile> add(List<DocumentFile> documentFiles) throws SugarTechnicalException, SugarFunctionalException;

    List<DocumentFile> get(String scope, List<URI> uri) throws SugarTechnicalException, SugarFunctionalException;

    List<URI> delete(String scope, List<URI> uris) throws SugarTechnicalException, SugarFunctionalException;
}
