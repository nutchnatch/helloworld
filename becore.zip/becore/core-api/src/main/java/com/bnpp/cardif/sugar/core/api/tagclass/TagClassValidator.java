package com.bnpp.cardif.sugar.core.api.tagclass;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

public interface TagClassValidator {

    void checkCreationValidity(List<TagClass> tagClasses) throws SugarFunctionalException, SugarTechnicalException;

    void checkUpdateValidity(List<TagClass> tagClasses) throws SugarTechnicalException, SugarFunctionalException;

    void checkExistence(String scope, List<String> symbolicNames)
            throws SugarTechnicalException, SugarFunctionalException;

    void checkGetAllValidity(String scope) throws SugarTechnicalException, SugarFunctionalException;

    void checkGetBySymbolicNameValidity(String scope) throws SugarTechnicalException, SugarFunctionalException;
}
