package com.bnpp.cardif.sugar.core.api.documentannotation;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.DocumentAnnotation;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.Id;

/**
 * Manage Sugar Document Class
 * 
 * @author Romain
 * 
 */
public interface DocumentAnnotationService {
    /**
     * Add (store) a list of DocumentAnnotation into the Sugar DMS.
     * 
     * @param documentAnnotation
     *            : The list of DocumentAnnotation to store
     * @return List<DocumentAnnotation> : The list of sucessfull stored
     *         DocumentAnnotation
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    List<DocumentAnnotation> create(List<DocumentAnnotation> documentAnnotations)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get the list of all DocumentAnnotation related to the List of
     * documentFileId passed as parameter.
     * 
     * @param documentFileId
     *            : the List of documentFileId for DocumentAnnotation retrieval.
     * @return List<DocumentAnnotation> : the List of DocumentAnnotation
     *         matching the passed documentFileIds.
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    List<DocumentAnnotation> findByDocumentFileId(List<String> documentFileIds)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Get the list of all DocumentAnnotation related to the List of id passed
     * as parameter.
     * 
     * NOT USED. DOES NOT MAKES SENSE
     * 
     * @param id
     *            : List<EDMS2IdentificationType> the list of annotation
     *            identifier.
     * @return List<DocumentAnnotation> : the List of DocumentAnnotation
     *         matching the passed ids.
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    List<DocumentAnnotation> get(List<Id> ids) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Delete all DocumentAnnotation related to the List of id passed as
     * parameter.
     * 
     * @param id
     *            : List<EDMS2IdentificationType> the list of annotation
     *            identifier.
     * @return List<? extends Boolean> : the list of indicator that tells if the
     *         deletion was done or not.
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    List<? extends Boolean> delete(List<DocumentAnnotation> ids)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Update (store) a list of DocumentAnnotation into the Sugar DMS.
     * 
     * @param documentAnnotation
     *            : The list of DocumentAnnotation to store
     * @return List<DocumentAnnotation> : The list of successfull stored
     *         DocumentAnnotation
     * @throws SugarTechnicalException
     * @throws SugarFunctionalException
     */
    List<DocumentAnnotation> update(List<DocumentAnnotation> documentAnnotations)
            throws SugarTechnicalException, SugarFunctionalException;

}
