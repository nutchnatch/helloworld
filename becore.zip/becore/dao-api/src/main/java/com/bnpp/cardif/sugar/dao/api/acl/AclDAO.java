package com.bnpp.cardif.sugar.dao.api.acl;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

/**
 * 
 * @author Florian Deruette
 * 
 */
public interface AclDAO {
    /**
     * Acl Usage for class
     * 
     * @author Francois Barre
     * 
     */
    public enum AclContext {
        /**
         * ACL for a Document
         */
        DOCUMENT,

        /**
         * ACL for a Folder
         */
        FOLDER,

        /**
         * ACL for this Class
         */
        CLASS,

        /**
         * Default ACL for a new instance of a Class
         */
        INSTANCE,

        /**
         * ACL for a businessScope
         */
        BUSINESSSCOPE,

        /**
         * ACL for a basket
         */
        BASKET,
        /**
         * Default ACL for Business Scope
         */
        DEFAULT,
    }

    /**
     * Store a new AccessControlList Object
     * 
     * @param acl
     * @throws SugarTechnicalException
     */
    void store(AccessControlList acl) throws SugarTechnicalException;

    /**
     * Get an ACL Object from its unique Id
     * 
     * @param aclId
     * @return the previously stored AccessControlList for this element
     * @throws SugarTechnicalException
     */
    AccessControlList get(AclId aclId, String scope) throws SugarTechnicalException;

    /**
     * Store documentId with corresponding aclId
     * 
     * @param aclId
     * @param documentId
     * @throws SugarTechnicalException
     */
    void assign(AclId aclId, Id documentId, String scope) throws SugarTechnicalException;

    /**
     * Store folderId with corresponding aclId
     * 
     * @param aclId
     * @param folderId
     * @throws SugarTechnicalException
     */
    void assign(AclId aclId, FolderId folderId, String scope) throws SugarTechnicalException;

    /**
     * Store classId with corresponding aclId
     * 
     * @param aclId
     * @param classId
     * @throws SugarTechnicalException
     */
    void assign(AclId aclId, ClassId classId, AclContext context, String scope) throws SugarTechnicalException;

    /**
     * Retrieve {@link AclId} for a {@link Document}
     * 
     * @see {@link AccessControlList}
     * @see {@link Document}
     * @param documentId
     * @return aclId corresponding to documentId
     * @throws SugarTechnicalException
     */
    AclId searchAcl(Id documentId, String scope) throws SugarTechnicalException;

    /**
     * Retrieve {@link AclId} for a {@link Folder}
     * 
     * @see {@link AccessControlList}
     * @see {@link Folder}
     * @param folderId
     * @return aclId corresponding to documentId
     * @throws SugarTechnicalException
     */
    AclId searchAcl(FolderId folderId, String scope) throws SugarTechnicalException;

    /**
     * Retrieve {@link AclId} for a {@link ClassId} filtered by scope
     * 
     * @see AclContext
     * @see ClassId
     * @see {@link AccessControlList}
     * @param classId
     * @return aclId corresponding to classId
     * @throws SugarTechnicalException
     */
    AclId searchAcl(ClassId classId, AclContext context, String scope) throws SugarTechnicalException;

    List<AccessControlList> getAll(String scope) throws SugarTechnicalException;

    /**
     * Searching for an ACL related to a businessScope
     * 
     * @param context
     * @param scope
     * @return
     * @throws SugarTechnicalException
     */

    void assign(AclId aclId, BusinessScopeId scopeId, String scope, AclContext context) throws SugarTechnicalException;

    AclId searchAcl(BusinessScopeId businessScopeId, String scope, AclContext context) throws SugarTechnicalException;

    AclId searchAcl(BasketId basketId, String scope) throws SugarTechnicalException;

    void assign(AclId aclId, BasketId basketId, String scope) throws SugarTechnicalException;

    void remove(BasketId basketId, String scope) throws SugarTechnicalException;

    void remove(String scope, ClassId classId, AclContext context) throws SugarTechnicalException;

    /**
     * Update given ACL
     * 
     * @param acl
     * @throws SugarTechnicalException
     */
    public void update(AccessControlList acl) throws SugarTechnicalException;

    void remove(Id documentId, String scope) throws SugarTechnicalException;

    void remove(String scope, BusinessScopeId businessScopeId, AclContext context) throws SugarTechnicalException;
}
