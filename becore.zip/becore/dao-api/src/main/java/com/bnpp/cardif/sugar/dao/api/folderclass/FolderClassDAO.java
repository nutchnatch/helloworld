package com.bnpp.cardif.sugar.dao.api.folderclass;

import java.util.Date;
import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;

public interface FolderClassDAO {
    /**
     * Add (store) a list of Folder classes into the Sugar DMS
     * 
     * @param folderClassesToAdd
     *            The list of folders to store
     * @throws SugarTechnicalException
     *             If a technical error occurred
     * @throws SugarFunctionalException
     *             If a functional error occured
     */
    void add(List<FolderClass> folderClassesToAdd) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Update a list of Folder classes into the Sugar DMS
     * 
     * @param folderClassesToUpdate
     *            The list of folder classes to update
     * @param scope
     *            The Business scope concerned
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of folders
     */
    void update(List<FolderClass> folderClassesToUpdate) throws SugarTechnicalException;

    /**
     * Get a list of Folder classes from the Sugar DMS
     * 
     * @param idsOfFolderclassesToGet
     *            The list of id of folder class ids to get
     * @param scope
     *            The Business scope concerned
     * @return The list of fetched folder classes
     * @throws SugarTechnicalException
     *             If a technical error occurred
     */
    List<FolderClass> get(List<ClassId> idsOfFolderclassesToGet, String scope) throws SugarTechnicalException;

    /**
     * Get all Folder classes from the Sugar DMS
     * 
     * @param scope
     *            The Business scope concerned
     * @param isActiveOnly
     *            : if false return all folder classes, if true return only
     *            active folder classes
     * @return
     * @throws SugarTechnicalException
     *             If a technical error occurred
     * @throws SugarFunctionalException
     *             If a functionnal error occurred
     */
    List<FolderClass> getAll(String scope, Boolean isActiveOnly)
            throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Activate or deactivate a list of Folder classes in the Sugar DMS
     * 
     * @param folderClassIds
     *            : the list of folder class ids to (de)activate
     * @param active
     *            : true will activate the list of folder classes, false will
     *            deactivate them
     * @param scope
     *            : The Business scope concerned
     * @param updateDate
     *            : last update date
     * @throws SugarTechnicalException
     */
    void setActive(List<ClassId> folderClassIds, Boolean active, String scope, Date updateDate)
            throws SugarTechnicalException;

    /**
     * Fetch all versions of specific folder classes
     * 
     * @param ids
     * @param scope
     * @return
     * @throws SugarTechnicalException
     */
    List<FolderClass> getAllVersions(List<ClassId> ids, String scope) throws SugarTechnicalException;

}
