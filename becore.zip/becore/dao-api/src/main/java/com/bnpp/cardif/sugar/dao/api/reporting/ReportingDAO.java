package com.bnpp.cardif.sugar.dao.api.reporting;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;

public interface ReportingDAO {

    List<EnvelopeFlows> getEnvelopesAndDocumentFlow(String scope, String formatedStartDate, String formatedEndDate)
            throws SugarTechnicalException;

    List<BasketRatio> getBasketClosedRatios(String scope, String formatedStartDate, String formatedEndDate)
            throws SugarTechnicalException;

    List<DocumentStock> getDocumentStockIndicators(String scope, String startingDate, String endingDate)
            throws SugarTechnicalException;

    List<FolderStock> getFolderStockIndicators(String scope, String startingDate, String endingDate)
            throws SugarTechnicalException;

    Summary getReportingSummary(String scope) throws SugarTechnicalException;

}
