package com.bnpp.cardif.sugar.dao.api.tagclass;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

public interface TagClassDAO {
    void store(List<TagClass> tagClasses) throws SugarTechnicalException, SugarFunctionalException;

    List<TagClass> getAll(String scope) throws SugarTechnicalException;

    List<TagClass> get(String scope, List<ClassId> tagIds) throws SugarTechnicalException;

    List<TagClass> getBySymbolicName(String scope, List<String> symbolicNames) throws SugarTechnicalException;

    void update(List<TagClass> tagClasses) throws SugarTechnicalException;

}
