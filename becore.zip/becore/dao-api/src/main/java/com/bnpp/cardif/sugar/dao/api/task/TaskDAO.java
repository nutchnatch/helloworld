package com.bnpp.cardif.sugar.dao.api.task;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

/**
 * Task Backend implementation
 * 
 */
public interface TaskDAO {
    /**
     * Get the list of tasks matching id in parameter
     * 
     * @param scope
     *            scope name
     * @param tasksId
     *            list of task ids
     * @return
     * @throws SugarTechnicalException
     */
    List<Task> get(String scope, List<TaskId> tasksId) throws SugarTechnicalException;

    /**
     * Task persistence
     * 
     * @param task
     *            bean
     * @throws SugarTechnicalException
     */
    void storeTasks(List<Task> tasks) throws SugarTechnicalException;

    /**
     * Update a list of tasks status
     * 
     * @param scope
     *            scope name
     * @param tasksId
     *            list of task ids
     * @param status
     *            new status
     * @throws SugarTechnicalException
     */
    void updateStatus(String scope, List<TaskId> tasksId, String status) throws SugarTechnicalException;

    /**
     * Lock a list of tasks for concurrent access
     * 
     * @param scope
     *            scope name
     * @param tasksId
     *            list of task ids
     * @param lockerName
     *            lock owner
     * @throws SugarTechnicalException
     */
    void lock(String scope, List<TaskId> tasksId, String lockerName) throws SugarTechnicalException;

    /**
     * Unlock a list of tasks for concurrent access
     * 
     * @param scope
     *            scope name
     * @param tasksId
     *            list of task ids
     * @throws SugarTechnicalException
     */
    void unlock(String scope, List<TaskId> tasksId) throws SugarTechnicalException;

    /**
     * 
     * @param scope
     *            scope name
     * @param tasksId
     *            list of task ids
     * @param basketId
     *            the basket id in which tasks have to be transfered
     * @throws SugarTechnicalException
     */
    void transfer(String scope, List<TaskId> tasksId, BasketId basketId) throws SugarTechnicalException;

    /**
     * Get all tasks contained in a basket
     * 
     * @param scope
     *            scope name
     * @param basketId
     *            the id of the basket containing the researched tasks
     * @param start
     *            start row number
     * @param max
     *            max row number
     * @return search object with list of tasks
     * @throws SugarTechnicalException
     */
    SearchResults<Task> getTasksInBasket(String scope, BasketId basketId, int start, int max, Boolean includeClosed)
            throws SugarTechnicalException;

    /**
     * Get tasks for specified document
     * 
     * @param scope
     * @param docId
     * @return tasks attached to document
     * @throws SugarTechnicalException
     */
    List<Task> getTasksForDoc(String scope, Id docId) throws SugarTechnicalException;

    void update(List<Task> tasksToUpdate) throws SugarTechnicalException;

    List<TaskId> fetchIdsByScope(String scope) throws SugarTechnicalException;

    List<Task> getByUser(String scope, String userName) throws SugarTechnicalException;

}
