package com.bnpp.cardif.sugar.dao.api.fact;

import java.util.Date;
import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Fact;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

/**
 * Data Access Object dedicated to {@link Fact}
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface FactDAO {

    public enum FACT_OBJECT {

        DOCUMENT("doc:Id", "xmlns:doc=\"http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1\""), FOLDER(
                "folder:FolderId",
                "xmlns:folder=\"http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1\"");

        private FACT_OBJECT(String nameId, String namespace) {
            this.nameId = nameId;
            this.namespace = namespace;
        }

        private String nameId;

        private String namespace;

        public String getNameId() {
            return nameId;
        }

        public String getNamespace() {
            return namespace;
        }

    }

    /**
     * Stores a fact
     * 
     * @param scope
     *            The business scope
     * @param fact
     *            The fact to store
     * @throws SugarTechnicalException
     *             If a technical error occurs
     */
    void store(String scope, Fact fact) throws SugarTechnicalException;

    /**
     * Gets all fact
     * 
     * @param scope
     *            The business scope
     * @return The whole facts for a business socpe
     * @throws SugarTechnicalException
     *             If a technical error occurs
     */
    List<Fact> getAll(String scope) throws SugarTechnicalException;

    String getUserObjectAction(FACT_OBJECT object, String action, String id) throws SugarTechnicalException;

    Date getTaskUpdateDate(String string, TaskId taskId) throws SugarTechnicalException;

}
