package com.bnpp.cardif.sugar.dao.api.document;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.domain.model.criteria.CriteriaHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

/**
 * Data Acess Object dedicated to {@link Document} which allows to manipulate
 * document data from a referential as database
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface DocumentDAO {
    /**
     * Stores a list of documents
     * 
     * @param documentsToStore
     *            The documents to store as
     * @throws SugarTechnicalException
     *             If a error occurred while storing
     */
    void store(List<Document> documentsToStore) throws SugarTechnicalException;

    /**
     * Finds documents with pagination. This method may use
     * {@link CriteriaHelper} to allow serialization of supplied criteria.
     * 
     * @param scope
     *            The business scope
     * 
     * @param criteria
     *            Set of criterion allowing to restrict search results
     * @param The
     *            order allowing to sort fetched results
     * @param start
     *            The start index to search from. Index starts at 0.
     * @param max
     *            The max number of results to fetch
     * @return The found documents as search results object according to
     *         supplied parameters
     * @throws SugarTechnicalException
     *             If a technical error occurs
     */
    SearchResults<Document> find(String scope, Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException;

    /**
     * Fetches a list of documents
     * 
     * @param scope
     *            The business scope
     * @param ids
     *            The unique identifies of documents to fetch
     * @return The fetch documents
     * @throws SugarTechnicalException
     *             If an error occurred while fetching
     */
    List<Document> fetch(String scope, List<Id> ids) throws SugarTechnicalException;

    List<Id> fetchIdsByScope(String scope) throws SugarTechnicalException;

    List<Document> update(List<Document> documentsToUpdate) throws SugarTechnicalException;

    void delete(String scope, List<Id> docIdsToDelete) throws SugarTechnicalException;

    void deleteAll(List<String> ids) throws SugarTechnicalException;

    List<String> getUnlinkedDocument() throws SugarTechnicalException;

    List<String> getUnlinkedEnveloppe() throws SugarTechnicalException;

}
