package com.bnpp.cardif.sugar.dao.api.businessscope;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;

/**
 * 
 * @author Florian Deruette
 * 
 */

public interface BusinessScopeDAO {
    void store(List<BusinessScope> businessScope) throws SugarTechnicalException, SugarFunctionalException;

    List<BusinessScope> getAll() throws SugarTechnicalException;

    void update(List<BusinessScope> businessScopes) throws SugarTechnicalException, SugarFunctionalException;

    public List<BusinessScope> getBySymbolicName(List<String> symbolicNames) throws SugarTechnicalException;
}
