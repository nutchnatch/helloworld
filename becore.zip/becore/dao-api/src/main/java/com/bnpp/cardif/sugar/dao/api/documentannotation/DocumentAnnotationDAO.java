package com.bnpp.cardif.sugar.dao.api.documentannotation;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.DocumentAnnotation;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

public interface DocumentAnnotationDAO {
    /**
     * Saves a new list of annotations
     * 
     * @param documentAnnotations
     *            list of {@link DocumentAnnotation} to be saved
     * @return the list of created {@link DocumentAnnotation}
     * @throws SugarTechnicalException
     *             if one or more {@link DocumentAnnotation} fail to save; each
     *             {@link DocumentAnnotation} creation is treated as an
     *             transaction
     */
    List<DocumentAnnotation> create(List<DocumentAnnotation> documentAnnotations) throws SugarTechnicalException;

    /**
     * Updates a list of annotations
     * 
     * @param documentAnnotation
     *            the list of updated {@link DocumentAnnotation}
     * @return the list of updated {@link DocumentAnnotation}
     * @throws SugarTechnicalException
     *             if one or more {@link DocumentAnnotation} fail to save; each
     *             {@link DocumentAnnotation} update is treated as an
     *             transaction
     */
    List<DocumentAnnotation> update(List<DocumentAnnotation> documentAnnotation) throws SugarTechnicalException;

    /**
     * Finds annotations by the associated document URI
     * 
     * @param documentFileIds
     *            the list of {@link DocumentFile#getURI()} to be fetched
     * @return the list fetched of {@link DocumentAnnotation}
     * @throws SugarTechnicalException
     */
    List<DocumentAnnotation> findByDocumentFileId(List<String> documentFileIds) throws SugarTechnicalException;

    /**
     * Gets annotations directly by their identifier (ID)
     * 
     * @param ids
     *            the list of {@link DocumentAnnotation#getId()} to be fetched
     * @return the list fetched of {@link DocumentAnnotation}
     * @throws SugarTechnicalException
     */
    List<DocumentAnnotation> get(List<Id> ids) throws SugarTechnicalException;

    /**
     * Deletes annotations by their identifier (ID)
     * 
     * @param ids
     *            the list of {@link DocumentAnnotation#getId()} to be deleted
     * @return the list of boolean representing the success or failure of the
     *         operation{@link DocumentAnnotation}
     * @throws SugarTechnicalException
     */
    List<? extends Boolean> delete(List<DocumentAnnotation> ids);

}
