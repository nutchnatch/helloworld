package com.bnpp.cardif.sugar.dao.api.folder;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.domain.model.criteria.CriteriaHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

public interface FolderDAO {
    /**
     * Add (store) a list of Folders into the Sugar DMS. Careful the name is a
     * primary key
     * 
     * @param folderToAdd
     *            The list of folders to store
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of folders
     * @throws SugarFunctionalException
     *             If a functional error occured while storing the supplied list
     *             of folders (example : try to store two folder with the same
     *             name)
     */
    void add(List<Folder> foldersToAdd) throws SugarTechnicalException, SugarFunctionalException;

    /**
     * Update a list of Folders into the Sugar DMS
     * 
     * @param foldersToUpdate
     *            The list of folders to update
     * @param scope
     *            The Business scope concerned
     * @return the list of updated folder
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of folders
     */
    List<Folder> update(List<Folder> foldersToUpdate, String scope) throws SugarTechnicalException;

    /**
     * Get a list of Folders from the Sugar DMS
     * 
     * @param idsOfFolderToGet
     *            The list of id of folders to get
     * @param scope
     *            The Business scope concerned
     * @return The list of get folders
     * @throws SugarTechnicalException
     *             If a technical error occurred while storing the supplied list
     *             of folders
     */
    List<Folder> get(List<FolderId> idsOfFolderToGet, String scope) throws SugarTechnicalException;

    /**
     * Finds folders with pagination. This method may use {@link CriteriaHelper}
     * to allow serialization of supplied criteria.
     * 
     * @param scope
     *            The business scope
     * @param criteria
     *            Set of criterion allowing to restrict search results
     * @param order
     *            The order clause
     * @param start
     *            The start index to search from. Index starts at 0.
     * @param max
     *            The max number of results to fetch
     * @return The found folders as search results object according to supplied
     *         parameters
     * @throws SugarTechnicalException
     *             If a technical error occurs
     */
    SearchResults<Folder> find(String scope, Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException;

    List<FolderId> fetchIdsByScope(String scope) throws SugarTechnicalException;

    Folder getBySymbolicName(String scope, String symbolicName) throws SugarTechnicalException;

}
