package com.bnpp.cardif.sugar.dao.api.documentclass;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

/**
 * Data Acess Object dedicated to {@link DocumentClass}
 * 
 * @author Romain
 * 
 */
public interface DocumentClassDAO {
    /**
     * Store a DocumentClass
     * 
     * @param classes
     *            The class to store
     * @throws SugarTechnicalException
     *             If a technical error occurs
     */
    public void store(List<DocumentClass> classes) throws SugarTechnicalException;

    /**
     * Search all the stored classes according to supplied parameters
     * 
     * @param scope
     *            The business scope
     * @param category
     *            The {@link Category} referenced by classes
     * @param isActiveOnly
     *            Determines if classes must be active or not
     * @return the list of found classes
     * @throws SugarTechnicalException
     *             If a technical error occurs
     */
    public List<DocumentClass> search(String scope, Category category, Boolean isActiveOnly)
            throws SugarTechnicalException;

    public void update(List<DocumentClass> classes) throws SugarTechnicalException;

    public List<DocumentClass> get(String scope, List<ClassId> classId) throws SugarTechnicalException;

    public void setActive(String scope, List<ClassId> classId, boolean activate) throws SugarTechnicalException;

    void remove(String scope, List<ClassId> classId) throws SugarTechnicalException;

    List<DocumentClass> getAllVersions(String scope, List<ClassId> ids) throws SugarTechnicalException;

}
