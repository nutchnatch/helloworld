package com.bnpp.cardif.sugar.dao.api.documentclass;

import java.util.List;

import com.arondor.flower.model.fields.FieldDefinition;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;

@Deprecated
public interface DocumentTagsDAO {
    public void store(String scope, List<FieldDefinition> fieldDefinitions) throws SugarTechnicalException;

    public List<FieldDefinition> get(String scope, List<String> fieldNames) throws SugarTechnicalException;
}
