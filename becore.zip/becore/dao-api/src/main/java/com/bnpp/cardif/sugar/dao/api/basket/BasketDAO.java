package com.bnpp.cardif.sugar.dao.api.basket;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;

/**
 * Basket Backend implementation
 * 
 */
public interface BasketDAO {

    /**
     * Get all baskets by scope
     * 
     * @param scope
     *            scope name
     * @return list of baskets
     * @throws SugarTechnicalException
     */
    List<Basket> getAll(String scope) throws SugarTechnicalException;

    /**
     * Store a list of Baskets
     * 
     * @param basketsToStore
     *            : the list of basket to store
     */
    void store(List<Basket> basketsToStore) throws SugarTechnicalException;

    /**
     * Fetch a list of Baskets
     * 
     * @param basketId
     *            : the list of baskets to fetch
     * @param scope
     * @return the list of fetched baskets
     */
    List<Basket> get(List<BasketId> basketId, String scope) throws SugarTechnicalException;

    /**
     * Update a list of basket
     * 
     * @param basketsToUpdate
     *            : the list of basket to update
     */
    void update(List<Basket> basketsToUpdate) throws SugarTechnicalException;

    /**
     * Delete a list of basket
     * 
     * @param basketsIdToDelete
     *            : the list of basket id to delete
     */
    /**
     * Delete a list of basket
     * 
     * @param basketsIdToDelete
     *            : the list of basket id to delete
     * @param scope
     *            scope name
     * @throws SugarTechnicalException
     */
    void delete(List<BasketId> basketsIdToDelete, String scope) throws SugarTechnicalException;

}
