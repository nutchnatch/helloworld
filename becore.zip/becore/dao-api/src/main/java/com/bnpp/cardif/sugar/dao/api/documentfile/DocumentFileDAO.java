package com.bnpp.cardif.sugar.dao.api.documentfile;

import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;

/**
 * Data Access Object dedicated to {@link DocumentFile}
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface DocumentFileDAO {
    /**
     * Stores a list of document files
     * 
     * @param filesToStore
     *            The files to store. They must have a set content
     * @throws SugarTechnicalException
     *             If a technical error occurred during storage
     */
    void store(List<DocumentFile> filesToStore) throws SugarTechnicalException;

    List<DocumentFile> get(String scope, List<URI> uri) throws SugarTechnicalException;

    void delete(String scope, String uri) throws SugarTechnicalException;

    List<String> getUnlinkedDocumentFile(String scope) throws SugarTechnicalException;

    void deleteAll(List<String> uris, String scopeName) throws SugarTechnicalException;
}
