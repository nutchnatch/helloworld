package com.bnpp.cardif.yourapplication.beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Super class for all the datatransfer beans.
 * 
 * @author 831743
 *
 */
@MappedSuperclass
public class GenericBean implements Serializable
{
    /**
     * ID for serialization
     */
    private static final long serialVersionUID = -4227307358964738729L;

    /**
     * Default column creationDate
     */
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;

    /**
     * Default column creationUser
     */
    @Column(name = "CREATION_USER", length = 80)
    private String creationUser;

    /**
     * Default column modificationDate
     */
    @Column(name = "MODIFICATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modificationDate;

    /**
     * Default column modificationUser
     */
    @Column(name = "MODIFICATION_USER", length = 80)
    private String modificationUser;

    /**
     * Default column identifier
     */
    @Column(name = "IDENTIFIER", length = 48, unique = true)
    private String identifier;

    /**
     * @return the creationDate
     */
    public Date getCreationDate()
    {
        return creationDate;
    }

    /**
     * @param creationDate
     *            the creationDate to set
     */
    public void setCreationDate(Date creationDate)
    {
        this.creationDate = creationDate;
    }

    /**
     * @return the creationUser
     */
    public String getCreationUser()
    {
        return creationUser;
    }

    /**
     * @param creationUser
     *            the creationUser to set
     */
    public void setCreationUser(String creationUser)
    {
        this.creationUser = creationUser;
    }

    /**
     * @return the modificationDate
     */
    public Date getModificationDate()
    {
        return modificationDate;
    }

    /**
     * @param modificationDate
     *            the modificationDate to set
     */
    public void setModificationDate(Date modificationDate)
    {
        this.modificationDate = modificationDate;
    }

    /**
     * @return the modificationUser
     */
    public String getModificationUser()
    {
        return modificationUser;
    }

    /**
     * @param modificationUser
     *            the modificationUser to set
     */
    public void setModificationUser(String modificationUser)
    {
        this.modificationUser = modificationUser;
    }

    /**
     * @return the identifier
     */
    public String getIdentifier()
    {
        return identifier;
    }

    /**
     * @param identifier
     *            the identifier to set
     */
    public void setIdentifier(String identifier)
    {
        this.identifier = identifier;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
        result = prime * result + ((creationUser == null) ? 0 : creationUser.hashCode());
        result = prime * result + ((identifier == null) ? 0 : identifier.hashCode());
        result = prime * result + ((modificationDate == null) ? 0 : modificationDate.hashCode());
        result = prime * result + ((modificationUser == null) ? 0 : modificationUser.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        GenericBean other = (GenericBean) obj;
        if (creationDate == null)
        {
            if (other.creationDate != null)
            {
                return false;
            }
        }
        else if (!creationDate.equals(other.creationDate))
        {
            return false;
        }
        if (creationUser == null)
        {
            if (other.creationUser != null)
            {
                return false;
            }
        }
        else if (!creationUser.equals(other.creationUser))
        {
            return false;
        }
        if (identifier == null)
        {
            if (other.identifier != null)
            {
                return false;
            }
        }
        else if (!identifier.equals(other.identifier))
        {
            return false;
        }
        if (modificationDate == null)
        {
            if (other.modificationDate != null)
            {
                return false;
            }
        }
        else if (!modificationDate.equals(other.modificationDate))
        {
            return false;
        }
        if (modificationUser == null)
        {
            if (other.modificationUser != null)
            {
                return false;
            }
        }
        else if (!modificationUser.equals(other.modificationUser))
        {
            return false;
        }
        return true;
    }

}
