package com.bnpp.cardif.sesame.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.bnppa.sesame.services.common.model.Joining;

public class AuthenticatedUser implements UserDetails
{
    private static final long serialVersionUID = 5237607032448693079L;

    private final String password;

    private final String username;

    private final String firstName;

    private final String lastName;

    private final String token;

    private String requestId;

    private long timeToSpentOnAuthentication;

    private Collection<? extends GrantedAuthority> authorities;

    private List<Joining> joinings;

    private List<String> permissions;

    /**
     * Constructor
     * 
     * @param userName
     * @param password
     * @param token
     * @param firstName
     * @param lastName
     * @param grantedAuthorities
     */
    public AuthenticatedUser(String userName, String password, String token, String firstName, String lastName,
            Collection<? extends GrantedAuthority> grantedAuthorities)
    {
        this.username = userName;
        this.password = password;
        this.token = token;
        this.firstName = firstName;
        this.lastName = lastName;
        this.authorities = grantedAuthorities;
        this.joinings = new ArrayList<Joining>();
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.security.core.userdetails.UserDetails#getUsername()
     */
    @Override
    public String getUsername()
    {
        return username;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.security.core.userdetails.UserDetails#getPassword()
     */
    @Override
    public String getPassword()
    {
        return password;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.security.core.userdetails.UserDetails#isAccountNonExpired
     * ()
     */
    @Override
    public boolean isAccountNonExpired()
    {
        // TODO Auto-generated method stub
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.security.core.userdetails.UserDetails#isAccountNonLocked
     * ()
     */
    @Override
    public boolean isAccountNonLocked()
    {
        // TODO Auto-generated method stub
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.security.core.userdetails.UserDetails#
     * isCredentialsNonExpired()
     */
    @Override
    public boolean isCredentialsNonExpired()
    {
        // TODO Auto-generated method stub
        return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.security.core.userdetails.UserDetails#isEnabled()
     */
    @Override
    public boolean isEnabled()
    {
        // TODO Auto-generated method stub
        return false;
    }

    /**
     * @return the requestId
     */
    public String getRequestId()
    {
        return requestId;
    }

    /**
     * @param requestId
     *            the requestId to set
     */
    public void setRequestId(String requestId)
    {
        this.requestId = requestId;
    }

    /**
     * @return the timeToSpentOnAuthentication
     */
    public long getTimeToSpentOnAuthentication()
    {
        return timeToSpentOnAuthentication;
    }

    /**
     * @param timeToSpentOnAuthentication
     *            the timeToSpentOnAuthentication to set
     */
    public void setTimeToSpentOnAuthentication(long timeToSpentOnAuthentication)
    {
        this.timeToSpentOnAuthentication = timeToSpentOnAuthentication;
    }

    /**
     * @return the authorities
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities()
    {
        return authorities;
    }

    /**
     * @param authorities
     *            the authorities to set
     */
    public void setAuthorities(Collection<? extends GrantedAuthority> authorities)
    {
        this.authorities = authorities;
    }

    /**
     * @return the joinings
     */
    public List<Joining> getJoinings()
    {
        return joinings;
    }

    /**
     * @param joinings
     *            the joinings to set
     */
    public void setJoinings(List<Joining> joinings)
    {
        this.joinings = joinings;
    }

    /**
     * @return the permissions
     */
    public List<String> getPermissions()
    {
        return permissions;
    }

    /**
     * @param permissions
     *            the permissions to set
     */
    public void setPermissions(List<String> permissions)
    {
        this.permissions = permissions;
    }

    /**
     * @return the firstName
     */
    public String getFirstName()
    {
        return firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName()
    {
        return lastName;
    }

    /**
     * @return the token
     */
    public String getToken()
    {
        return token;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("AuthenticatedUser [password=");
        builder.append(password);
        builder.append(", username=");
        builder.append(username);
        builder.append(", firstName=");
        builder.append(firstName);
        builder.append(", lastName=");
        builder.append(lastName);
        builder.append(", token=");
        builder.append(token);
        builder.append(", authorities=");
        builder.append(authorities);
        builder.append(", joinings=");
        builder.append(joinings);
        builder.append(", permissions=");
        builder.append(permissions);
        builder.append("]");
        return builder.toString();
    }

}