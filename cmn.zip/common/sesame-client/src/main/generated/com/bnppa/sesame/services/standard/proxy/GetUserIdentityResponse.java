
package com.bnppa.sesame.services.standard.proxy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnppa.sesame.services.common.model.UserIdentity;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="getUserIdentityReturn" type="{http://model.common.services.sesame.bnppa.com}UserIdentity"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getUserIdentityReturn"
})
@XmlRootElement(name = "getUserIdentityResponse")
public class GetUserIdentityResponse {

    @XmlElement(required = true, nillable = true)
    protected UserIdentity getUserIdentityReturn;

    /**
     * Gets the value of the getUserIdentityReturn property.
     * 
     * @return
     *     possible object is
     *     {@link UserIdentity }
     *     
     */
    public UserIdentity getGetUserIdentityReturn() {
        return getUserIdentityReturn;
    }

    /**
     * Sets the value of the getUserIdentityReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserIdentity }
     *     
     */
    public void setGetUserIdentityReturn(UserIdentity value) {
        this.getUserIdentityReturn = value;
    }

}
