
package com.bnppa.sesame.services.common.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UserExtendedIdentity complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UserExtendedIdentity"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="extendedAttributes" type="{http://model.common.services.sesame.bnppa.com}ArrayOfKeyValue"/&gt;
 *         &lt;element name="userIdentity" type="{http://model.common.services.sesame.bnppa.com}UserIdentity"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UserExtendedIdentity", propOrder = {
    "extendedAttributes",
    "userIdentity"
})
public class UserExtendedIdentity {

    @XmlElement(required = true, nillable = true)
    protected ArrayOfKeyValue extendedAttributes;
    @XmlElement(required = true, nillable = true)
    protected UserIdentity userIdentity;

    /**
     * Gets the value of the extendedAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfKeyValue }
     *     
     */
    public ArrayOfKeyValue getExtendedAttributes() {
        return extendedAttributes;
    }

    /**
     * Sets the value of the extendedAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfKeyValue }
     *     
     */
    public void setExtendedAttributes(ArrayOfKeyValue value) {
        this.extendedAttributes = value;
    }

    /**
     * Gets the value of the userIdentity property.
     * 
     * @return
     *     possible object is
     *     {@link UserIdentity }
     *     
     */
    public UserIdentity getUserIdentity() {
        return userIdentity;
    }

    /**
     * Sets the value of the userIdentity property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserIdentity }
     *     
     */
    public void setUserIdentity(UserIdentity value) {
        this.userIdentity = value;
    }

}
