
package com.bnppa.sesame.services.common.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UsingRight complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UsingRight"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="contractView" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="productView" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="rescom" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="sadr" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="topGroup" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="userType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UsingRight", propOrder = {
    "contractView",
    "productView",
    "rescom",
    "sadr",
    "topGroup",
    "userType"
})
public class UsingRight {

    @XmlElement(required = true, nillable = true)
    protected String contractView;
    @XmlElement(required = true, nillable = true)
    protected String productView;
    @XmlElement(required = true, nillable = true)
    protected String rescom;
    @XmlElement(required = true, nillable = true)
    protected String sadr;
    protected boolean topGroup;
    @XmlElement(required = true, nillable = true)
    protected String userType;

    /**
     * Gets the value of the contractView property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractView() {
        return contractView;
    }

    /**
     * Sets the value of the contractView property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractView(String value) {
        this.contractView = value;
    }

    /**
     * Gets the value of the productView property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductView() {
        return productView;
    }

    /**
     * Sets the value of the productView property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductView(String value) {
        this.productView = value;
    }

    /**
     * Gets the value of the rescom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRescom() {
        return rescom;
    }

    /**
     * Sets the value of the rescom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRescom(String value) {
        this.rescom = value;
    }

    /**
     * Gets the value of the sadr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSadr() {
        return sadr;
    }

    /**
     * Sets the value of the sadr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSadr(String value) {
        this.sadr = value;
    }

    /**
     * Gets the value of the topGroup property.
     * 
     */
    public boolean isTopGroup() {
        return topGroup;
    }

    /**
     * Sets the value of the topGroup property.
     * 
     */
    public void setTopGroup(boolean value) {
        this.topGroup = value;
    }

    /**
     * Gets the value of the userType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Sets the value of the userType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserType(String value) {
        this.userType = value;
    }

}
