
package com.bnppa.sesame.services.common.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Joining complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Joining"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="subsidiary" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="interv" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="joiningType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="source" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Joining", propOrder = {
    "subsidiary",
    "interv",
    "joiningType",
    "source"
})
public class Joining {

    @XmlElement(required = true, nillable = true)
    protected String subsidiary;
    @XmlElement(required = true, nillable = true)
    protected String interv;
    @XmlElement(required = true, nillable = true)
    protected String joiningType;
    @XmlElement(required = true, nillable = true)
    protected String source;

    /**
     * Gets the value of the subsidiary property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubsidiary() {
        return subsidiary;
    }

    /**
     * Sets the value of the subsidiary property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubsidiary(String value) {
        this.subsidiary = value;
    }

    /**
     * Gets the value of the interv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterv() {
        return interv;
    }

    /**
     * Sets the value of the interv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterv(String value) {
        this.interv = value;
    }

    /**
     * Gets the value of the joiningType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJoiningType() {
        return joiningType;
    }

    /**
     * Sets the value of the joiningType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJoiningType(String value) {
        this.joiningType = value;
    }

    /**
     * Gets the value of the source property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSource(String value) {
        this.source = value;
    }

}
