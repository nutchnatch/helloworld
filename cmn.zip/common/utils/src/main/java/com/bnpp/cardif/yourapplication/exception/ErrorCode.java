/**
 * 
 */
package com.bnpp.cardif.yourapplication.exception;

/**
 * @author Eric Le Bail
 *
 */
public enum ErrorCode
{

    TE001("TE001", "One result expected and many returned"), TE002("TE002", "One result expected and zero returned"),

    IIE003("IIE003", "Token cannot be null"), IIE002("IIE002", "Email and password cannot be null"), IIE001("IIE001",
            "loginParameters cannot be null");

    private final String code;

    private final String message; // error message

    private ErrorCode(String errorCode, String errorMessage)
    {
        this.code = errorCode;
        this.message = errorMessage;
    }

    /**
     * @return the code
     */
    public String getCode()
    {
        return code;
    }

    /**
     * @return the message
     */
    public String getMessage()
    {
        return message;
    }
}
