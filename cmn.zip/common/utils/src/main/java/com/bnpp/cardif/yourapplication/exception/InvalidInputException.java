package com.bnpp.cardif.yourapplication.exception;

public class InvalidInputException extends TechnicalException
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * Empty constructor
     */
    public InvalidInputException()
    {
    }

    /**
     * constructor
     * 
     * @param code
     *            ErrorCode
     */
    public InvalidInputException(ErrorCode code)
    {
        this(code.getCode(), code.getMessage());
    }

    /**
     * constructor
     * 
     * @param message
     */
    public InvalidInputException(String message)
    {
        super(message);
    }

    /**
     * constructor
     * 
     * @param code
     * @param message
     */
    public InvalidInputException(String code, String message)
    {
        super(code, message);
    }

    /**
     * constructor
     * 
     * @param message
     * @param cause
     */
    public InvalidInputException(String message, Throwable cause)
    {
        super(message, cause);
    }

    /**
     * constructor
     * 
     * @param code
     * @param message
     * @param cause
     */
    public InvalidInputException(String code, String message, Throwable cause)
    {
        super(code, message, cause);
    }

}
