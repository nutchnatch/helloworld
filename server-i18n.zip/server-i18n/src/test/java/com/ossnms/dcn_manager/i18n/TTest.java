package com.ossnms.dcn_manager.i18n;

import org.junit.Test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class TTest {

    @Test
    public void testTrMessage() {
        assertThat(T.tr(Message.ERR_DUPLICATED_GLOBAL_NE_ID), is("{0} has the same Global NE Identifier ({1}) as {2}"));
    }

    @Test
    public void testTrMessageObjectArray() {
        assertThat(
            T.tr(Message.ERR_DUPLICATED_GLOBAL_NE_ID, "A", "B", "C"),
            is("A has the same Global NE Identifier (B) as C"));
    }
    
    @Test
    public void testTrMessageObjectArrayWithSimpleQuotes() {
        assertThat(
            T.tr(Message.DUPLICATED_MEDIATOR_HOST, "A", "B", "C"),
            is("A Mediator 'C' of type 'A' already exists on host 'B'."));
    }
}
