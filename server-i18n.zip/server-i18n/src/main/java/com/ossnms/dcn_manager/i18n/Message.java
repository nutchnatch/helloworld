package com.ossnms.dcn_manager.i18n;

/**
 * Enumerates all messages supported for internationalization.
 */
public enum Message {

    IP_PORT("IP/Port"),

    ERR_DUPLICATED_GLOBAL_NE_ID("{0} has the same Global NE Identifier ({1}) as {2}"),

    SYSTEM("System"),

    /*
     * Statuses
     */

    CONNECTED("Connected"),
    DISCONNECTED("Disconnected"),
    CONNECTING("Connecting"),
    DISCONNECTING("Disconnecting"),
    INITIALIZED("Initialized"),
    INITIALIZING("Initializing"),
    STARTING_UP("Activating"),

    ACTIVE("Active"),
    INACTIVE("Inactive"),
    ACTIVATING("Activating"),
    DEACTIVATING("Deactivating"),
    SHUTTING_DOWN("Deactivating"),

    FAILED("Failed"),

    CONNECTION_PENDING("Waiting to Connect"),
    INITIALIZATION_PENDING("Waiting to Initialize"),
    DEACTIVATION_PENDING("Deactivation Pending"),
    
    /*
     * NE Routes
     */

    WORKING("Working Path"),
    PROTECTING("Protecting Path"),
    DIRECT_CONNECTION("Direct connection"),
    DIRECT_CONNECTION_BY_FLAT_IP("Direct connection (Flat IP)"),

    DUPLICATED_ROUTES("Duplicated gateway NE routes are not allowed."),
    DUPLICATED_ROUTES_INFO("''{0}'' has duplicated routes with ''{1}''."),
    DUPLICATED_DIRECT_ROUTE_INFO("''{0}'' has the same direct connection address as ''{1}''."),
    DUPLICATED_DIRECT_ROUTE("Duplicated direct connection information is not allowed."),
    INITIALIZATION_UPDATE_FAILED("NE information update failed."),

    MISMATCHED_NE_PROXY_TYPE("Mismatched NE proxy type."),

    /*
     * NE
     */

    NE_DOES_NOT_EXIST("NE {0} does not exist."),
    NE_ACTIVATION_REQUIRED("NE {0} is managed."),
    NE_NOT_INITIALIZED("NE {0} is not active."),

    NE_ACTIVATION("NE activation required"),
    NE_DEACTIVATION("NE deactivation required"),
    NE_ALREADY_ACTIVE("Trying to activate an already activated NE"),
    NE_ALREADY_INACTIVE("Trying to deactivate an already deactivated NE"),
    NE_UNKNOWN_TYPE("NE {0} has unknown type {1}"),
    NE_STATE_CHANGED("NE state changed to {0}."),

    NE_STILL_ACTIVE("NE still active"),

    NE_INIT_TIMEOUT("Initialization timeout."),
    NE_DUPLICATED_NAME("A Network Element already exists with the name ''{0}''."),
    NE_DATATRANSFER_PROPERTIES_CHANGED("NE data transfer settings changed"),
    NE_DATATRANSFER_PROPERTIES_CHANGE_FAILED("NE data transfer settings could not be changed."),
    NE_MISSING_NAME("A Network Element should have a name {0}"),
    DUPLICATED_NETWORK_ID_NAME("A Network Element already exists with network identification name ''{0}''."),
    
    /*
     * Mediator
     */

    MEDIATOR("Mediator"),
    MEDIATOR_ACTIVATION("Mediator activation required"),
    MEDIATOR_DEACTIVATION("Mediator deactivation required"),
    MEDIATOR_ALREADY_ACTIVE("Trying to activate an already activated mediator"),
    MEDIATOR_ALREADY_INACTIVE("Trying to deactivate an already deactivated mediator"),
    MEDIATOR_WITH_ACTIVE_CHANNELS("Deactivating a mediator with activated channels is not supported"),
    MEDIATOR_FAILED("Mediator failure."),
    UNKNOWN_MEDIATOR_TYPE("Unknown mediator type ''{0}''."),
    MEDIATOR_DOES_NOT_EXIST("Mediator {0} does not exist."),
    DUPLICATED_MEDIATOR_NAME("A Mediator already exists with the name ''{0}''."),
    DUPLICATED_MEDIATOR_HOST("A Mediator ''{2}'' of type ''{0}'' already exists on host ''{1}''."),
    MEDIATOR_HOST_EMPTY("Mediator Host cannot be empty"),
    MEDIATOR_STATE_CHANGED("Mediator state changed to {0}."),
    RETRYING_MEDIATOR_NUMBER("Mediator activation retry #{0}."),
    MEDIATOR_TYPE_INCOMPATIBILITY("Incompatible mediator type"),
    MEDIATOR_ACTIVE_CANT_BE_REMOVED("It is not possible to delete an active mediator connection."),
    MEDIATOR_CONNECTION_ALREADY_ACTIVE("Connection already active in ''{0}''. Move channels if desired."),

    /*
     * Channel
     */

    CHANNEL_FAILED("Channel failure."),
    CHANNEL_ACTIVATION("Channel activation required"),
    CHANNEL_DEACTIVATION("Channel deactivation required"),
    CHANNEL_ALREADY_ACTIVE("Trying to activate an already activated channel"),
    CHANNEL_ALREADY_INACTIVE("Trying to deactivate an already deactivated channel"),
    CHANNEL("Channel"),
    CHANNEL_UNKNOWN_TYPE("Unknown channel type ''{0}''."),

    CHANNEL_STILL_ACTIVE("Channel still active"),

    CHANNEL_DOES_NOT_EXIST("Channel {0} does not exist."),

    CHANNEL_STATE_CHANGED("Channel state changed to {0}."),

    CHANNEL_TYPE_INCOMPATIBLE("Incompatible channels type."),

    CHANNEL_ALREADY_EXISTS("A Channel already exists with the name ''{0}''."),

    CHANNEL_MOVED("Channel {0} moved from {1} to {2}"),

    SOME_CHANNEL_MOVES_FAILED("Some Channel moving operations have failed. See the Command Log for details."),

    /*
     * Container
     */

    CANNOT_DELETE_DEFAULT_ASSOCIATION("Deleting the default assignment is not allowed, because it is the last available assignment."),
    CONTAINER_DOES_NOT_EXIST("NE Container {0} does not exist."),
    CONTAINER_NAME_EMPTY("NE Container must have a name!"),
    DUPLICATED_CONTAINER_NAME("An NE Container already exists with the name ''{0}''."),
    CONTAINER_CREATED("NE Container object created."),
    CONTAINER_DELETED("NE Container object deleted."),
    CONTAINER("NE Container"),

    CONTAINER_ADDED_ASSIGNMENT("Added assignment to {0} ''{1}''."),
    CONTAINER_REMOVED_ASSIGNMENT("Removed assignment to {0} ''{1}''."),
    CONTAINER_UPDATED_ASSIGNMENT("Updated assignment to {0} ''{1}''."),

    /*
     * Domains
     */
    DOMAIN_DOES_NOT_EXIST("Domain {0} does not exist."),
    DOMAIN("AS/EON/Domain"),
    DOMAIN_CHANGED("Domain configuration changed."),
    DOMAIN_CHANGE_FAILED("Domain configuration could not be changed."),
    SOME_DOMAIN_CHANGES_FAILED("Some Domain configurations could not be changed."),

    DOMAIN_RENAMED_TO("Domain renamed to ''{0}''."),
    DOMAIN_DELETED("Domain deleted."),

    /*
     * Operations
     */
    NETWORK_NAME_COPIED("Copied network name ''{0}'' into NE name."),
    NETWORK_NAME_COPY_FAILED("Could not copy network name into NE name. Check if an NE with that name already exists."),
    SOME_NETWORK_NAME_COPIES_FAILED("Some network name copies have failed. See the Command Log for details."),

    NE_MOVED("NE {0} moved from {1} to {2}."),
    NE_MOVE_FAILED("Could not move NE. {0}"),
    SOME_NE_MOVES_FAILED("Some NE moving operations have failed. See the Command Log for details."),

    RESYNCHRONIZATION_REQUESTED("Resynchronization was requested for NE."),
    RESYNCHRONIZATION_FAILED("Could not resynchronize."),
    SOME_RESYNCHRONIZATIONS_FAILED("Some NE resynchronizations have failed. See the Command Log for details."),

    CONTAINER_CHANGED("NE container changed."),
    CONTAINER_CHANGE_FAILED("NE Container could not be changed."),
    SOME_CONTAINER_CHANGES_FAILED("Some NE Containers could not be changed."),

    /*
     * System Containers
     */
    SYSTEM_CREATED("System Container object created"),
    SYSTEM_DELETED("System Container object deleted."),
    SYSTEM_NAME_EMPTY("System Container must have a name!"),
    DUPLICATED_SYSTEM_NAME("A System Container already exists with the name ''{0}''"),
    DUPLICATED_SYSTEM_NAME_BETWEEN_SYSTEM("A System Container named ''{0}'' already exists.\n You must change the name, for example to ''{1}''."),
    DUPLICATED_SYSTEM_NAME_BETWEEN_NE("An Network Element named ''{0}'' already exists.\n You must change the name, for example to ''{1}''."),
    DUPLICATED_SYSTEM_NAME_BETWEEN_CONTAINER("An NE Container named ''{0}'' already exists.\n You must change the name, for example to ''{1}''."),

    SYSTEM_CHANGED("System Container changed."),
    SYSTEM_CHANGE_FAILED("System Container could not be changed."),
    SOME_SYSTEM_CHANGES_FAILED("Some System Containers could not be changed."),


    /*
     * Import/Export Configuration
     */
    CHANNEL_INVALID_PROPERTIES("Failed to import Channel. Channel=''{0}'' Invalid properties."),
    CHANNEL_ERROR_TO_IMPORT("Failed to import Channel. Channel=''{0}'' cannot be saved."),
    CHANNEL_IMPORTED("Channel ''{0}'' imported."),

    MEDIATOR_INVALID_PROPERTIES("Failed to import. Mediator=''{0}'' has invalid properties."),
    MEDIATOR_ERROR_TO_IMPORT("Failed to import. Mediator=''{0}'' cannot be saved."),
    MEDIATOR_IMPORTED("Mediator ''{0}'' imported."),

    NE_INVALID_PROPERTIES("Failed to import. NE=''{0}'' has invalid properties."),
    NE_ERROR_TO_IMPORT("Failed to import. NE=''{0}'' cannot be saved."),
    NE_IMPORT_UNKNOWN_TYPE("Failed to import. NE=''{0}'' has unsupported type."),
    NE_IMPORTED("NE ''{0}'' imported."),
    NE_EXISTS("NE ''{0}'' already exists."),

    /*
     * Global settings.
     */
    GLOBAL_CONFIG("System Preferences"),
    GLOBAL_CONFIG_UPDATED("''{0}'' updated with a new value: ''{1}''"),

    GLOBAL_CONFIG_RETRY_MEDIATOR("Mediator retry"),
    GLOBAL_CONFIG_RETRY_CHANNEL("Channel retry"),
    GLOBAL_CONFIG_RETRY_NE("NE retry"),
    GLOBAL_CONFIG_RETRY_INTERVAL("Retry interval"),
    GLOBAL_CONFIG_SCALED_STARTUP_LIMIT("Scaled startup limit"),
    GLOBAL_CONFIG_DISCOVERY_POLICY("Discovery policy"),
    GLOBAL_CONFIG_ENABLE_SCHEDULED_STARTUP("Enable scheduled startup"),
    GLOBAL_CONFIG_ENABLE_NATIVE_NE_NAMING("Show native NE naming in locations"),
    GLOBAL_CONFIG_DEFAULT_CONTAINER_NAME("Default NE Container name")
    ;

    private final String message;

    Message(final String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return message;
    }
}
