package com.ossnms.dcn_manager.i18n;

import java.text.MessageFormat;

/**
 * Basic internationalization support.
 */
public final class T {

    private T() {

    }

    /**
     * Should translate a message.
     * @param msg The message, from the supported set of messages for internationalization.
     * @return Translated message.
     */
    public static String tr(Message msg) {
        return msg.toString();
    }

    /**
     * Should translate a message which uses dynamic place holders.
     * @param msg The message, from the supported set of messages for internationalization.
     * @param args Place holder replacements.
     * @return Translated message.
     * @see MessageFormat#format(String,Object[])
     */
    public static String tr(Message msg, Object... args) {
        return MessageFormat.format(msg.toString(), args);
    }
}
