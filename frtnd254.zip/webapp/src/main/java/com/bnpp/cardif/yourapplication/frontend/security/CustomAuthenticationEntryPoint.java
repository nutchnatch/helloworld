package com.bnpp.cardif.yourapplication.frontend.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.yourapplication.beans.RestResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The authentication entry point is called when the client makes a call to a
 * resource without proper authentication. In other words, the client has not
 * logged in.
 * 
 * @author 831743
 *
 */
@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint
{
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomAuthenticationEntryPoint.class);

    private ObjectMapper mapper = new ObjectMapper();

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException
    {
        RestResponse restResponse = new RestResponse();
        restResponse.setErrorCode("401");
        restResponse.setErrorMessage("Access Denied : " + authException.getMessage());

        String content = mapper.writeValueAsString(restResponse);

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Access is denied for request: [" + request.getRequestURI() + "] and queryString [" + request.getQueryString() + "]");
            LOGGER.debug("Send following json response: " + content);
        }

        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.getWriter().print(content);
    }

}
