package com.bnpp.cardif.yourapplication.frontend.security;

import java.io.Serializable;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import oasis.names.tc.saml._2_0.assertion.AssertionType;
import oasis.names.tc.saml._2_0.assertion.AttributeStatementType;
import oasis.names.tc.saml._2_0.assertion.AttributeType;
import oasis.names.tc.saml._2_0.assertion.StatementAbstractType;

import org.opensaml.saml2.core.Assertion;
import org.opensaml.ws.message.encoder.MessageEncodingException;
import org.opensaml.xml.util.XMLHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.security.saml.userdetails.SAMLUserDetailsService;
import org.springframework.security.saml.util.SAMLUtil;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.w3._2000._09.xmldsig_.SignatureType;

import com.bnpp.cardif.sesame.security.AuthenticatedUser;
import com.bnppa.sesame.services.common.model.Joining;
import com.bnppa.sesame.services.common.model.UserIdentity;
import com.bnppa.sesame.services.common.model.UsingRight;

/**
 * This class is in charge of creating and returning a AuthenticatedUser object
 * filled with the data that are inculded into the SAMl authentication response.
 * 
 * @author 831743
 *
 */
@Service
public class SAMLUserDetailsServiceImpl implements SAMLUserDetailsService
{

    // Logger
    private static final Logger LOGGER = LoggerFactory.getLogger(SAMLUserDetailsServiceImpl.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.security.saml.userdetails.SAMLUserDetailsService#
     * loadUserBySAML(org.springframework.security.saml.SAMLCredential)
     */
    @Override
    public Object loadUserBySAML(SAMLCredential credential) throws UsernameNotFoundException
    {
        // Needed variables to create the AuthenticatedUser object
        String userName = null;
        String password = null;
        String token = null;
        String firstName = null;
        String lastName = null;
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        List<Joining> joinings = new ArrayList<Joining>();
        List<String> permissions = new ArrayList<String>();

        Assertion assertion = credential.getAuthenticationAssertion();
        try
        {
            String assertionString = XMLHelper.prettyPrintXML(SAMLUtil.marshallMessage(assertion));
            JAXBContext context = JAXBContext.newInstance(AssertionType.class, SignatureType.class, Joining.class, UserIdentity.class, UsingRight.class);
            Unmarshaller jaxbUnmarshaller = context.createUnmarshaller();
            StringReader reader = new StringReader(assertionString);
            @SuppressWarnings("unchecked")
            JAXBElement<AssertionType> el = (JAXBElement<AssertionType>) jaxbUnmarshaller.unmarshal(reader);
            AssertionType as = el.getValue();
            List<StatementAbstractType> statementList = as.getStatementOrAuthnStatementOrAuthzDecisionStatement();
            for (StatementAbstractType statementAbstractType : statementList)
            {
                if (statementAbstractType instanceof AttributeStatementType)
                {
                    AttributeStatementType attributes = (AttributeStatementType) statementAbstractType;
                    List<Serializable> attributeList = attributes.getAttributeOrEncryptedAttribute();
                    for (Serializable serializable : attributeList)
                    {
                        AttributeType attribut = (AttributeType) serializable;
                        String attributeName = attribut.getName();
                        LOGGER.debug("attributeName = " + attributeName);
                        if ("urn:bnpparibas:cardif:saml:sesame:attribute:user-identity".equals(attributeName))
                        {
                            List<Object> attributeValueList = attribut.getAttributeValue();
                            for (Object object : attributeValueList)
                            {
                                LOGGER.debug("attributeValue = " + object);
                                UserIdentity userIdentity = (UserIdentity) object;
                                if (userIdentity != null)
                                {
                                    firstName = userIdentity.getFirstName();
                                    lastName = userIdentity.getLastName();
                                    userName = userIdentity.getLogin();
                                }
                                else
                                {
                                    LOGGER.warn("UserIdentity is null");
                                    throw new UsernameNotFoundException("Error reading the UserIdentity in assertion");
                                }
                            }

                        }
                        else if ("urn:bnpparibas:cardif:saml:sesame:attribute:roles-id".equals(attributeName))
                        {
                            List<Object> attributeValueList = attribut.getAttributeValue();
                            for (Object object : attributeValueList)
                            {
                                LOGGER.debug("attributeValue = " + object);
                                String role = (String) object;
                                if (!StringUtils.isEmpty(role))
                                {
                                    GrantedAuthority authority = new SimpleGrantedAuthority(role);
                                    authorities.add(authority);
                                }
                                else
                                {
                                    LOGGER.warn("Cannot create SimpleGrantedAuthority from a nul or empty role.");
                                }
                            }
                        }
                        else if ("urn:bnpparibas:cardif:saml:sesame:attribute:token".equals(attributeName))
                        {
                            List<Object> attributeValueList = attribut.getAttributeValue();
                            for (Object object : attributeValueList)
                            {
                                LOGGER.debug("attributeValue = " + object);
                                token = (String) object;
                                if (StringUtils.isEmpty(token))
                                {
                                    LOGGER.warn("Empty token detected");
                                    throw new UsernameNotFoundException("Error reading the Token in assertion");
                                }
                            }
                        }
                        else if ("urn:bnpparibas:cardif:saml:sesame:attribute:joinings".equals(attributeName))
                        {
                            List<Object> attributeValueList = attribut.getAttributeValue();
                            for (Object object : attributeValueList)
                            {
                                LOGGER.debug("attributeValue = " + object);
                                Joining joining = (Joining) object;
                                if (joining != null)
                                {
                                    joinings.add(joining);
                                }
                                else
                                {
                                    LOGGER.warn("Empty Joining detected");
                                }
                            }
                        }
                        else if ("urn:bnpparibas:cardif:saml:sesame:attribute:permissions-id".equals(attributeName))
                        {
                            List<Object> attributeValueList = attribut.getAttributeValue();
                            for (Object object : attributeValueList)
                            {
                                LOGGER.debug("attributeValue = " + object);
                                String permission = (String) object;
                                if (!StringUtils.isEmpty(permission))
                                {
                                    permissions.add(permission);
                                }
                                else
                                {
                                    LOGGER.warn("Cannot create permission from a null or empty value.");
                                }
                            }
                        }
                    }
                }
            }

        }
        catch (MessageEncodingException e1)
        {
            throw new UsernameNotFoundException("Error reading the SAML assertion : ", e1);
        }
        catch (JAXBException e)
        {
            throw new UsernameNotFoundException("Error reading the SAML assertion : ", e);
        }
        // create the AuthenticatedUser object and return it.
        AuthenticatedUser user = new AuthenticatedUser(userName, password, token, firstName, lastName, authorities);
        user.setJoinings(joinings);
        user.setPermissions(permissions);
        return user;
    }

}
