package com.bnpp.cardif.yourapplication.frontend.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.yourapplication.beans.RestResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The access denied handler is called when authorization fails. This means the
 * client is passing in a correct token but the permissions associated with the
 * role of this user does not allow the client the access.
 * 
 * @author 831743
 *
 */
@Component
public class CustomAccessDeniedHandler implements AccessDeniedHandler
{
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomAccessDeniedHandler.class);

    private ObjectMapper mapper = new ObjectMapper();

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException,
            ServletException
    {
        RestResponse restResponse = new RestResponse();
        restResponse.setErrorCode("403");
        restResponse.setErrorMessage("Access Denied : " + accessDeniedException.getMessage());

        String content = mapper.writeValueAsString(restResponse);

        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("AccessDenied for request: [" + request.getRequestURI() + "] and queryString [" + request.getQueryString() + "]");
            LOGGER.debug("Send following json response: " + content);
        }

        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.getWriter().print(content);

    }

}
