package com.ossnms.web.api.notifications.atmosphere;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationEntityMapper;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;
import com.ossnms.web.provider.common.api.notification.NotificationService;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.Broadcaster;
import org.atmosphere.cpr.BroadcasterFactory;
import org.atmosphere.cpr.BroadcasterListener;
import org.atmosphere.cpr.Deliver;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Any;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.IOException;
import java.io.Serializable;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 */
@Singleton
public class TheGreatBroadcaster implements AtmosphereBroadcasterService {

    /**
     *
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(TheGreatBroadcaster.class);

    /**
     *
     */
    private BroadcasterFactory broadcasterFactory;

    /**
     *
     */
    private Instance<NotificationService> notificationServices;

    /**
     *
     */
    private Instance<NotificationEntityMapper> entityMappers;

    /**
     *
     */
    private final ObjectMapper mapper;

    /**
     *
     */
    private final Lock lock;

    private final NotificationHandler notificationHandler;
    private final BroadcasterListener broadcasterListener;

    public TheGreatBroadcaster() {
        this.mapper = new ObjectMapper();
        this.lock = new ReentrantLock();
        this.notificationHandler = this::handle;
        this.broadcasterListener = new GreatBroadcasterListener();
        LOGGER.info("The Great Broadcaster instance was created: {}", broadcasterFactory);
    }

    @Inject
    public TheGreatBroadcaster(
            BroadcasterFactory broadcasterFactory,
            @Default Instance<NotificationService> notificationService,
            @Any Instance<NotificationEntityMapper> entityMappers
    ) {
        this();
        this.broadcasterFactory = broadcasterFactory;
        this.notificationServices = notificationService;
        this.entityMappers = entityMappers;
    }

    @Override
    public void subscribe(AtmosphereResource resource, String channel) {
        lock.lock();
        try {
            unsafeSubscribe(resource, new NotificationChannel(channel));
        } finally {
            lock.unlock();
        }
        LOGGER.info("Client on {} subscribed {}", resource.uuid(), channel);
    }

    @Override
    public void unsubscribe(AtmosphereResource resource, String channel) {
        lock.lock();
        try {
            unsafeUnsubscribeChannel(resource, new NotificationChannel(channel));
        } finally {
            lock.unlock();
        }
        LOGGER.info("Client on {} unsubscribed {}", resource.uuid(), channel);
    }

    @Override
    public void subscribe(AtmosphereResource resource, NotificationChannel channel) {
        lock.lock();
        try {
            unsafeSubscribe(resource, channel);
        } finally {
            lock.unlock();
        }
        LOGGER.info("Client on {} subscribed {}", resource.uuid(), channel);
    }

    @Override
    public void unsubscribe(AtmosphereResource resource, NotificationChannel channel) {
        lock.lock();
        try {
            unsafeUnsubscribeChannel(resource, channel);
        } finally {
            lock.unlock();
        }
        LOGGER.info("Client on {} unsubscribed {}", resource.uuid(), channel);
    }

    void handle(Notification notification) throws NotificationHandlerException {
        LOGGER.trace("Broadcast {}", notification);
        String channel = notification.getChannel().getChannelId();
        if (channel == null) {
            throw new IllegalChannelException(notification);
        }
        broadcastOnChannel(notification, channel);
    }

    private void unsafeSubscribe(AtmosphereResource resource, NotificationChannel notificationChannel) {
        String channelId = notificationChannel.getChannelId();
        Broadcaster broadcaster = broadcasterFactory.lookup(channelId);
        if (broadcaster == null) {
            // for every available NotificationService, subscribe
            for(NotificationService service : notificationServices) {
                service.subscribe(notificationChannel, notificationHandler);
            }
            broadcaster = broadcasterFactory.get(channelId);
            broadcaster.addBroadcasterListener(broadcasterListener);
        }
        broadcaster.addAtmosphereResource(resource);
    }

    /**
     *
     * @param resource
     * @param notificationChannel
     */
    private void unsafeUnsubscribeChannel(AtmosphereResource resource, NotificationChannel notificationChannel) {
        String channelId = notificationChannel.getChannelId();
        Broadcaster broadcaster = broadcasterFactory.lookup(channelId);
        if (broadcaster != null) {

            // unsubscribe the channel
            for(NotificationService service : notificationServices) {
                unsubscribe(broadcaster.getID(), service);
            }

            broadcaster.removeAtmosphereResource(resource);
        }
    }


    /**
     *
     * @param broadcasterID
     * @param service
     */
    private void unsubscribe(String broadcasterID, NotificationService service) {
        try {
            service.unsubscribe(new NotificationChannel(broadcasterID), notificationHandler);
        }catch(Exception e) {
            LOGGER.warn("Exception while unsubscribing notification service", e);
        }
    }


    private void broadcastOnChannel(Notification notification, String channel) throws MapperNotFoundException {
        Broadcaster broadcaster = broadcasterFactory.lookup(channel);
        if (broadcaster != null) {
            Serializable entity = mapEntity(notification);
            try {
                String notificationString = createNotification(channel,
                        notification.getNotificationType().name(),
                        entity);
                broadcastOnBroadcaster(broadcaster, notificationString);
            } catch (IOException e) {
                LOGGER.error("Failed to mapper Rest API Object to JSON. {}", entity, e);
            }
        } else {
            LOGGER.debug("Nobody listening to {}", channel);
        }
    }

    private void broadcastOnBroadcaster(Broadcaster broadcaster, String notification) {
        lock.lock();
        try {
            if (!broadcaster.isDestroyed()) {
                LOGGER.trace("Broadcasting {}", notification);
                broadcaster.broadcast(notification);
            } else {
                LOGGER.info("Broadcaster was destroyed {}, notification dropped {}", broadcaster.getID(), notification);
            }
        } finally {
            lock.unlock();
        }
    }

    private String createNotification(String channel, String type, Serializable entity) throws IOException {
        SocketMessage message = SocketMessage.build(SocketMessage.NOTIFICATION, channel, type, entity);
        return mapper.writeValueAsString(message);
    }

    /**
     * Before broadcasting the entity, search for the corresponding mappers
     *
     * @param notification the notification to serialize
     * @return an instance of the serializable entity
     * @throws MapperNotFoundException if no mapper was found for this notification
     */
    private Serializable mapEntity(Notification notification) throws MapperNotFoundException {
        for (NotificationEntityMapper entityMapper : entityMappers) {
            if (entityMapper.accept(notification)) {
                return entityMapper.map(notification);
            }
        }
        EntityBase entity = notification.getEntity();
        throw new MapperNotFoundException(entity);
    }

    private static class IllegalChannelException extends NotificationHandlerException {
        private static final long serialVersionUID = 2621356313477166765L;

        public IllegalChannelException(Notification notification) {
            super(String.format("Channel: %s Entity: %s", notification.getChannel(), notification.getEntity()));
        }
    }

    private static class MapperNotFoundException extends NotificationHandlerException {
        private static final long serialVersionUID = 7673312961459483541L;

        public MapperNotFoundException(EntityBase entity) {
            super(String.format("Entity: %s", entity));
        }
    }

    private class GreatBroadcasterListener implements BroadcasterListener {

        @Override
        public void onRemoveAtmosphereResource(Broadcaster broadcaster, AtmosphereResource resource) {
            String broadcasterID = broadcaster.getID();
            LOGGER.debug("Called onRemoveAtmosphereResource on broadcaster {}, resource {}", broadcasterID, resource.uuid());
            if (broadcaster.getAtmosphereResources().isEmpty()) {
                LOGGER.info("Unsubscribe broadcaster {}: [{}]", broadcasterID, broadcaster);

                broadcasterFactory.remove(broadcasterID);
                broadcaster.destroy();
            }
        }

        @Override
        public void onPostCreate(Broadcaster b) {
        }

        @Override
        public void onComplete(Broadcaster b) {
        }

        @Override
        public void onPreDestroy(Broadcaster b) {
        }

        @Override
        public void onAddAtmosphereResource(Broadcaster b, AtmosphereResource r) {
        }

        @Override
        public void onMessage(Broadcaster b, Deliver deliver) {
        }
    }
}
