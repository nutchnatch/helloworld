package com.ossnms.web.api.notifications.atmosphere;

import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import org.atmosphere.cpr.AtmosphereResource;

/**
 *
 */
public interface AtmosphereBroadcasterService {

    /**
     *
     * @param resource
     * @param channelId
     */
    void subscribe(AtmosphereResource resource, String channelId);

    /**
     *
     * @param resource
     * @param channelId
     */
    void unsubscribe(AtmosphereResource resource, String channelId);

    /**
     *
     * @param resource
     * @param channel
     */
    void subscribe(AtmosphereResource resource, NotificationChannel channel);

    /**
     *
     * @param resource
     * @param channel
     */
    void unsubscribe(AtmosphereResource resource, NotificationChannel channel);
}
