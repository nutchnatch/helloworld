package com.ossnms.web.api.notifications.atmosphere;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import org.atmosphere.config.service.WebSocketHandlerService;
import org.atmosphere.websocket.WebSocket;
import org.atmosphere.websocket.WebSocketHandlerAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

import java.io.IOException;

import static org.atmosphere.cpr.ApplicationConfig.WEBSOCKET_IDLETIME;

//@WebSocketHandlerService(path = "/events/*", atmosphereConfig = {WEBSOCKET_IDLETIME + "=120000"})
public class NotificationsWebSocketHandler extends WebSocketHandlerAdapter {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationsWebSocketHandler.class);

    private final ObjectMapper mapper = new ObjectMapper();

    @Inject
    private AtmosphereBroadcasterService broadcasterService;

    public void onTextMessage(WebSocket webSocket, String message) throws IOException {

        if (message == null || message.length() == 0) {
            return;
        }
        LOGGER.info("message received: {}", message);
        try {
            SocketMessage socketMessage = mapper.readValue(message, SocketMessage.class);

            NotificationChannel notificationChannel = socketMessage.toNotificationChannel();

            String type = socketMessage.getName();
            LOGGER.debug("{}: {} {}", type, webSocket.resource().uuid(), notificationChannel.getChannelId());
            if (SocketMessage.SUBSCRIBE.equals(type)) {
                broadcasterService.subscribe(webSocket.resource(), notificationChannel);
            } else if (SocketMessage.UNSUBSCRIBE.equals(type)) {
                broadcasterService.unsubscribe(webSocket.resource(), notificationChannel);
            }
        } catch (IOException e) {
            LOGGER.error("", e);
        }
    }
}
