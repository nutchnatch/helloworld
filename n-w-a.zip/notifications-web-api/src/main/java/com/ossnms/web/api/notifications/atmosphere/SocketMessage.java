package com.ossnms.web.api.notifications.atmosphere;

import com.ossnms.web.provider.common.api.notification.NotificationChannel;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;

/**
 * Socket.io message.
 */
public class SocketMessage implements Serializable {
    public static final String SUBSCRIBE = "subscribe";
    public static final String UNSUBSCRIBE = "unsubscribe";
    public static final String NOTIFICATION = "notification";

    private static final long serialVersionUID = 2430050350996918166L;

    private String name;
    private Collection<?> args;

    /**
     * Builder method.
     *
     * @param name The message name (e.g. notification, subscribe, unsubscribe)
     * @param args Any serializable argument to send on the message
     * @return a new SocketMessage with name and arguments.
     */
    public static SocketMessage build(String name, Serializable... args) {
        SocketMessage message = new SocketMessage();
        message.setName(name);
        message.setArgs(Arrays.asList(args));
        return message;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Collection<?> getArgs() {
        return args;
    }

    public void setArgs(Collection<?> args) {
        this.args = args;
    }

    @Override
    public String toString() {
        return "SocketMessage{" +
                "name='" + name + '\'' +
                ", args=" + args +
                '}';
    }

    public NotificationChannel toNotificationChannel() {
        Object[] arguments = getArgs().toArray();
        String channel = (String) arguments[0];
        String authorization = arguments.length > 1 ? (String) arguments[1] : null;
        return new NotificationChannel(channel, authorization);
    }
}
