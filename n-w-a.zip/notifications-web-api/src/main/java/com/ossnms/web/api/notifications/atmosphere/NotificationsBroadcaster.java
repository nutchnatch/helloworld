/*
 * Copyright 2014 Sebastien Dionne
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.ossnms.web.api.notifications.atmosphere;

import org.atmosphere.config.service.BroadcasterService;
import org.atmosphere.cpr.DefaultBroadcaster;
import org.atmosphere.socketio.transport.SocketIOPacketImpl;

import java.util.concurrent.Future;

@BroadcasterService
public class NotificationsBroadcaster extends DefaultBroadcaster {

    @Override
    public Future<Object> broadcast(Object m) {
        return super.broadcast(parseMessage(m));
    }

    private Object parseMessage(Object m) {
        return new SocketIOPacketImpl(SocketIOPacketImpl.PacketType.EVENT, m.toString()).toString();
//        return m;
    }
}
