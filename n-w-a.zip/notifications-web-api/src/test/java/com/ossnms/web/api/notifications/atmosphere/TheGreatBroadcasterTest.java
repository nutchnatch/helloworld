package com.ossnms.web.api.notifications.atmosphere;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationEntityMapper;
import com.ossnms.web.provider.common.api.notification.NotificationService;
import com.ossnms.web.provider.common.api.notification.NotificationType;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.Broadcaster;
import org.atmosphere.cpr.BroadcasterFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.enterprise.inject.Instance;
import javax.enterprise.util.TypeLiteral;
import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Spliterator;
import java.util.function.Consumer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TheGreatBroadcasterTest {

    @Mock
    BroadcasterFactory broadcasterFactory;

    @Mock
    NotificationService notificationService;

    TheGreatBroadcaster theGreatBroadcaster;

    @Before
    public void setUp() throws Exception {

        Instance<NotificationEntityMapper> entityMappers = getMappersMock();
        Instance<NotificationService> notificationServices = getNotificationServicesMock();
        theGreatBroadcaster = new TheGreatBroadcaster(broadcasterFactory, notificationServices, entityMappers);
    }

    private Instance<NotificationService> getNotificationServicesMock() {
        return new Instance<NotificationService>() {
            @Override
            public Instance<NotificationService> select(Annotation... qualifiers) {
                return null;
            }

            @Override
            public <U extends NotificationService> Instance<U> select(TypeLiteral<U> subtype, Annotation... qualifiers) {
                return null;
            }

            @Override
            public <U extends NotificationService> Instance<U> select(Class<U> subtype, Annotation... qualifiers) {
                return null;
            }


            @Override
            public boolean isUnsatisfied() {
                return false;
            }

            @Override
            public boolean isAmbiguous() {
                return false;
            }

            @Override
            public void destroy(NotificationService instance) {

            }

            @Override
            public Iterator<NotificationService> iterator() {
                return Collections.singletonList(notificationService).iterator();
            }

            @Override
            public void forEach(Consumer<? super NotificationService> action) {

            }

            @Override
            public Spliterator<NotificationService> spliterator() {
                return null;
            }

            @Override
            public NotificationService get() {
                return null;
            }
        };
    }

    private Instance<NotificationEntityMapper> getMappersMock() {
        return new Instance<NotificationEntityMapper>() {
            @Override
            public Instance<NotificationEntityMapper> select(Annotation... annotations) {
                return null;
            }

            @Override
            public <U extends NotificationEntityMapper> Instance<U> select(Class<U> aClass, Annotation... annotations) {
                return null;
            }

            @Override
            public <U extends NotificationEntityMapper> Instance<U> select(TypeLiteral<U> typeLiteral, Annotation... annotations) {
                return null;
            }

            @Override
            public boolean isUnsatisfied() {
                return false;
            }

            @Override
            public boolean isAmbiguous() {
                return false;
            }

            @Override
            public void destroy(NotificationEntityMapper notificationEntityMapper) {

            }

            @Override
            public Iterator<NotificationEntityMapper> iterator() {
                NotificationEntityMapper mapper = new NotificationEntityMapper() {
                    @Override
                    public boolean accept(EntityBase entity) {
                        return true;
                    }

                    @Override
                    public Serializable map(EntityBase entity) {
                        return "";
                    }
                };
                return Collections.singletonList(mapper).iterator();
            }

            @Override
            public NotificationEntityMapper get() {
                return null;
            }
        };
    }

    @Test
    public void subscribeChannelFirstTime() throws Exception {
        String channel = "";
        Broadcaster broadcaster = mock(Broadcaster.class);
        when(broadcasterFactory.lookup(channel)).thenReturn(null);
        when(broadcasterFactory.get(channel)).thenReturn(broadcaster);
        AtmosphereResource resource = mock(AtmosphereResource.class);
        theGreatBroadcaster.subscribe(resource, channel);
        verify(broadcaster, times(1)).addAtmosphereResource(resource);
    }

    @Test
    public void subscribeChannel() throws Exception {
        String channel = "";
        Broadcaster broadcaster = mock(Broadcaster.class);
        when(broadcasterFactory.lookup(channel)).thenReturn(broadcaster);
        AtmosphereResource resource = mock(AtmosphereResource.class);
        theGreatBroadcaster.subscribe(resource, channel);
        verify(broadcaster, times(1)).addAtmosphereResource(resource);
    }

    @Test
    public void unsubscribe() throws Exception {
        String channel = "";
        Broadcaster broadcaster = mock(Broadcaster.class);
        when(broadcasterFactory.lookup(channel)).thenReturn(broadcaster);
        AtmosphereResource resource = mock(AtmosphereResource.class);
        theGreatBroadcaster.unsubscribe(resource, channel);
        verify(broadcaster, times(1)).removeAtmosphereResource(resource);
    }

    @Test
    public void unsubscribeWithoutSubscription() throws Exception {
        String channel = "";
        Broadcaster broadcaster = mock(Broadcaster.class);
        when(broadcasterFactory.lookup(channel)).thenReturn(null);
        AtmosphereResource resource = mock(AtmosphereResource.class);
        theGreatBroadcaster.unsubscribe(resource, channel);
        verify(broadcaster, never()).removeAtmosphereResource(any());
    }

    @Test
    public void broadcastEmptyChannel() throws Exception {
        String channel = "channel1";
        EntityBase nodeDto = mock(EntityBase.class);
        Notification notification = new Notification.NotificationBuilder()
                .setChannel(new NotificationChannel(channel))
                .setEntitySupplier(()->nodeDto)
                .setNotificationType(NotificationType.CHANGE)
                .build();
        EntityBase rao = mock(EntityBase.class);
        when(broadcasterFactory.lookup(channel)).thenReturn(null);
        theGreatBroadcaster.handle(notification);
    }

    @Test
    public void broadcastOnChannel() throws Exception {
        String channel = "channel1";
        EntityBase nodeDto = mock(EntityBase.class);
        Notification notification = new Notification.NotificationBuilder()
                .setChannel(new NotificationChannel(channel))
                .setEntitySupplier(()->nodeDto)
                .setNotificationType(NotificationType.CHANGE)
                .build();

        EntityBase rao = mock(EntityBase.class);
        Broadcaster broadcaster = mock(Broadcaster.class);
        when(broadcasterFactory.lookup(channel)).thenReturn(broadcaster);
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        theGreatBroadcaster.handle(notification);
        verify(broadcaster).broadcast(captor.capture());
        String message = captor.getValue();
        ObjectMapper mapper = new ObjectMapper();
        SocketMessage socketMessage = mapper.readValue(message, SocketMessage.class);
        assertThat(socketMessage.getName()).isEqualTo(SocketMessage.NOTIFICATION);
        assertThat((Collection<String>) socketMessage.getArgs()).contains(channel);
    }

}