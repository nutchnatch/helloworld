package com.ossnms.web.api.notifications.atmosphere;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by catarino on 07-09-2016.
 */
public class SocketMessageTest {

    private SocketMessage socketMessage;

    private Object[] args = new Object[1];

    @Before
    public void setUp() throws Exception {
        args[0] = new Object();
        socketMessage = SocketMessage.build(null, args);
    }

    @Test
    public void testBuild() throws Exception {
        assertThat(socketMessage).isNotNull();
        assertThat(SocketMessage.build(null, args)).isNotNull();
    }

    @Test
    public void testName() throws Exception {
        assertThat(socketMessage.getName()).isNull();
        final String NAME = "NAME";
        socketMessage.setName(NAME);
        assertThat(socketMessage.getName()).isNotNull().isEqualTo(NAME);
        socketMessage.setName(null);
        assertThat(socketMessage.getName()).isNull();
    }

    @Test
    public void testArgs() throws Exception {
        assertThat(socketMessage.getArgs()).isNotNull().hasSize(args.length);
        Collection argList = Collections.emptyList();
        socketMessage.setArgs(argList);
        assertThat(socketMessage.getArgs()).isNotNull().isEmpty();
        argList = new ArrayList<>();
        argList.add(new Object());
        socketMessage.setArgs(argList);
        assertThat(socketMessage.getArgs()).isNotNull().isNotEmpty().hasSize(argList.size());
        socketMessage.setArgs(null);
        assertThat(socketMessage.getArgs()).isNull();
    }

    @Test
    public void testToString() throws Exception {
        assertThat(socketMessage.toString()).isNotNull().contains("SocketMessage");
    }

}
