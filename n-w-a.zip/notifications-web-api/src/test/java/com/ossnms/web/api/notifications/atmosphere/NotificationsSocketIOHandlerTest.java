package com.ossnms.web.api.notifications.atmosphere;

import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.socketio.SocketIOSessionOutbound;
import org.atmosphere.socketio.transport.DisconnectReason;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.same;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class NotificationsSocketIOHandlerTest {

    @Mock
    TheGreatBroadcaster broadcaster;

    @InjectMocks
    NotificationsSocketIOHandler handler;

    @Test
    public void onConnect() throws Exception {
        AtmosphereResource resource = mock(AtmosphereResource.class);
        SocketIOSessionOutbound outbound = mock(SocketIOSessionOutbound.class);
        handler.onConnect(resource, outbound);
    }

    @Test
    public void onSubscribeMessage() throws Exception {
        AtmosphereResource resource = mock(AtmosphereResource.class);
        SocketIOSessionOutbound outbound = mock(SocketIOSessionOutbound.class);
        SocketMessage socketMessage = new SocketMessage();
        socketMessage.setName(SocketMessage.SUBSCRIBE);
        String channel = "channel1";
        socketMessage.setArgs(Collections.singletonList(channel));
        String message = new ObjectMapper().writeValueAsString(socketMessage);
        handler.onMessage(resource, outbound, message);
        verify(broadcaster, times(1)).subscribe(resource, new NotificationChannel(channel));
    }

    @Test
    public void onUnSubscribeMessage() throws Exception {
        AtmosphereResource resource = mock(AtmosphereResource.class);
        SocketIOSessionOutbound outbound = mock(SocketIOSessionOutbound.class);
        SocketMessage socketMessage = new SocketMessage();
        socketMessage.setName(SocketMessage.UNSUBSCRIBE);
        String channel = "channel1";
        socketMessage.setArgs(Collections.singletonList(channel));
        String message = new ObjectMapper().writeValueAsString(socketMessage);
        handler.onMessage(resource, outbound, message);
        verify(broadcaster, times(1)).unsubscribe(resource, new NotificationChannel(channel));
    }

    @Test
    public void onInvalidMessage() throws Exception {
        AtmosphereResource resource = mock(AtmosphereResource.class);
        SocketIOSessionOutbound outbound = mock(SocketIOSessionOutbound.class);
        String message = "any invalid message";
        handler.onMessage(resource, outbound, message);
        verify(broadcaster, never()).handle(any());
        verify(broadcaster, never()).subscribe(same(resource), any(String.class));
        verify(broadcaster, never()).unsubscribe(same(resource), any(String.class));
        handler.onMessage(null, outbound, message);
        verify(broadcaster, never()).handle(any());
        verify(broadcaster, never()).subscribe(same(resource), any(String.class));
        verify(broadcaster, never()).unsubscribe(same(resource), any(String.class));
        handler.onMessage(resource, null, message);
        verify(broadcaster, never()).handle(any());
        verify(broadcaster, never()).subscribe(same(resource), any(String.class));
        verify(broadcaster, never()).unsubscribe(same(resource), any(String.class));
        handler.onMessage(resource, outbound, null);
        verify(broadcaster, never()).handle(any());
        verify(broadcaster, never()).subscribe(same(resource), any(String.class));
        verify(broadcaster, never()).unsubscribe(same(resource), any(String.class));
        handler.onMessage(resource, outbound, "");
        verify(broadcaster, never()).handle(any());
        verify(broadcaster, never()).subscribe(same(resource), any(String.class));
        verify(broadcaster, never()).unsubscribe(same(resource), any(String.class));
    }

    @Test
    public void onDisconnect() throws Exception {
        AtmosphereResource resource = mock(AtmosphereResource.class);
        SocketIOSessionOutbound outbound = mock(SocketIOSessionOutbound.class);
        DisconnectReason reason = DisconnectReason.CLOSED;
        handler.onDisconnect(resource, outbound, reason);
    }
}