package com.bnpp.cardif.yourapplication.backend.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * The SecurityWebApplicationInitializer will do the following things:
 * Automatically register the springSecurityFilterChain Filter for every URL in
 * your application. If Filters are added within other WebApplicationInitializer
 * instances we can use @Order to control the ordering of the Filter instances.
 * 
 * @author 831743
 *
 */
public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer
{
}