/**
 * 
 */
package com.bnpp.cardif.yourapplication.backend.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.hibernate5.HibernateExceptionTranslator;
import org.springframework.orm.jpa.JpaDialect;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaDialect;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * @author 831743
 *
 */
@EnableTransactionManagement(proxyTargetClass = true)
@EnableJpaRepositories("com.bnpp.cardif.yourapplication.dao")
@Configuration
public class DBConfig
{
    private static final Logger LOGGER = LoggerFactory.getLogger(DBConfig.class);

    @Autowired
    private Environment env;

    @Value("${spring.datasource.url}")
    private String datasourceUrl;

    @Value("${spring.datasource.driver-class-name}")
    private String datasourceDriverClassName;

    @Value("${spring.datasource.username}")
    private String datasourceUsername;

    @Value("${spring.datasource.password}")
    private String datasourcePassword;

    @Value("${spring.datasource.tomcat.default-auto-commit}")
    private Boolean defaultAutoCommit;

    @Value("${spring.datasource.tomcat.max-active}")
    private int maxActive;

    @Value("${spring.datasource.tomcat.max-idle}")
    private int maxIdle;

    @Value("${spring.datasource.tomcat.min-idle}")
    private int minIdle;

    @Value("${spring.datasource.tomcat.initial-size}")
    private int initialSize;

    @Value("${spring.datasource.tomcat.max-wait}")
    private int maxWait;

    @Value("${spring.datasource.tomcat.test-on-borrow}")
    private Boolean testOnBorrow;

    @Value("${spring.datasource.tomcat.test-on-return}")
    private Boolean testOnReturn;

    @Value("${spring.datasource.tomcat.test-while-idle}")
    private Boolean testWhileIdle;

    @Value("${spring.datasource.tomcat.validation-query}")
    private String validationQuery;

    @Value("${spring.datasource.tomcat.validation-query-timeout}")
    private int validationQueryTimeout;

    @Value("${spring.datasource.tomcat.time-between-eviction-runs-millis}")
    private int timeBetweenEvictionRunsMillis;

    @Value("${spring.datasource.tomcat.validation-interval}")
    private long validationInterval;

    @Value("${spring.datasource.tomcat.remove-abandoned}")
    private Boolean removeAbandoned;

    @Value("${spring.datasource.tomcat.remove-abandoned-timeout}")
    private int removeAbandonedTimeout;

    @Value("${spring.datasource.tomcat.log-abandoned}")
    private Boolean logAbandoned;

    @Value("${spring.datasource.hibernate.dialect}")
    private String hibernateDialect;

    @Value("${spring.datasource.hibernate.show_sql}")
    private String hibernateShowSql;

    @Value("${spring.datasource.hibernate.format_sql}")
    private String hibernateFormatSql;

    @Value("${spring.datasource.hibernate.generate_statistics}")
    private String hibernateGenerateStatistics;

    @Bean
    public HibernateExceptionTranslator hibernateExceptionTranslator()
    {
        return new HibernateExceptionTranslator();
    }

    @Bean
    public DataSource dataSource()
    {
        org.apache.tomcat.jdbc.pool.DataSource datasource = new org.apache.tomcat.jdbc.pool.DataSource();
        // basic settings
        datasource.setUrl(this.datasourceUrl);
        datasource.setDriverClassName(this.datasourceDriverClassName);
        datasource.setUsername(this.datasourceUsername);
        datasource.setPassword(this.datasourcePassword);
        // apache pool settings
        datasource.setDefaultAutoCommit(defaultAutoCommit);
        datasource.setMaxActive(this.maxActive);
        datasource.setMaxIdle(this.maxIdle);
        datasource.setMinIdle(this.minIdle);
        datasource.setInitialSize(this.initialSize);
        datasource.setMaxWait(this.maxWait);
        datasource.setTestOnBorrow(this.testOnBorrow);
        datasource.setTestOnReturn(this.testOnReturn);
        datasource.setTestWhileIdle(this.testWhileIdle);
        datasource.setValidationQuery(this.validationQuery);
        datasource.setValidationQueryTimeout(this.validationQueryTimeout);
        datasource.setTimeBetweenEvictionRunsMillis(this.timeBetweenEvictionRunsMillis);
        datasource.setValidationInterval(this.validationInterval);
        datasource.setRemoveAbandoned(this.removeAbandoned);
        datasource.setRemoveAbandonedTimeout(this.removeAbandonedTimeout);
        datasource.setLogAbandoned(this.logAbandoned);

        return datasource;
    }

    /**
     * Configure the EntityManagerFactory used by the application.
     * 
     * @param dataSource
     *            DataSource : the datasource to connect to the DB.
     * @return EntityManagerFactory
     */
    @Bean
    @Autowired
    public EntityManagerFactory entityManagerFactory(DataSource dataSource)
    {
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setGenerateDdl(false);
        vendorAdapter.setShowSql(false);
        vendorAdapter.setDatabasePlatform(hibernateDialect);

        LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
        factory.setJpaVendorAdapter(vendorAdapter);
        factory.setPackagesToScan("com.bnpp.cardif.yourapplication.beans");
        factory.setDataSource(dataSource);

        Properties properties = new Properties();
        properties.setProperty("hibernate.dialect", hibernateDialect);
        properties.setProperty("hibernate.show_sql", hibernateShowSql);
        properties.setProperty("hibernate.format_sql", hibernateFormatSql);
        properties.setProperty("hibernate.cache.use_second_level_cache", "false");
        properties.setProperty("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.EhCacheRegionFactory");
        properties.setProperty("hibernate.cache.use_query_cache", "false");
        properties.setProperty("hibernate.generate_statistics", hibernateGenerateStatistics);

        factory.setJpaProperties(properties);
        factory.afterPropertiesSet();
        return factory.getObject();
    }

    /**
     * Configure the transaction manager used by the application.
     * 
     * @param entityManagerFactory
     *            EntityManagerFactory : the factory used.
     * @return JpaTransactionManager.
     */
    @Bean
    @Autowired
    public JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory)
    {
        JpaTransactionManager txManager = new JpaTransactionManager();
        JpaDialect jpaDialect = new HibernateJpaDialect();
        txManager.setEntityManagerFactory(entityManagerFactory);
        txManager.setJpaDialect(jpaDialect);
        return txManager;
    }

    /**
     * Configure the TransactionTemplate used by the application. (required for @transactional
     * annotations.
     * 
     * @param txManager
     *            TransactionManager : the transaction manager.
     * @return TransactionTemplate.
     */
    @Bean
    @Autowired
    public TransactionTemplate transactionTemplate(JpaTransactionManager txManager)
    {
        TransactionTemplate transactionTemplate = new TransactionTemplate();
        transactionTemplate.setTransactionManager(txManager);
        return transactionTemplate;
    }

}
