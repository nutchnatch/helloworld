package com.bnpp.cardif.yourapplication.backend.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;

/**
 * Configuration object for Spring Security. The SecurityConfig will:
 * 
 * - Require authentication to every URL in your application
 * 
 * - Generate a login form for you
 * 
 * - Allow the user with the Username user and the Password password to
 * authenticate with form based authentication
 * 
 * - Allow the user to logout
 * 
 * - CSRF attack prevention
 * 
 * - Session Fixation protection
 * 
 * - Security Header integration
 * 
 * -- HTTP Strict Transport Security for secure requests
 * 
 * -- X-Content-Type-Options integration
 * 
 * -- Cache Control (can be overridden later by your application to allow
 * caching of your static resources)
 * 
 * -- X-XSS-Protection integration
 * 
 * -- X-Frame-Options integration to help prevent Clickjacking
 * 
 * -Integrate with the following Servlet API methods
 * 
 * -- HttpServletRequest#getRemoteUser()
 * 
 * -- HttpServletRequest.html#getUserPrincipal()
 * 
 * -- HttpServletRequest.html#isUserInRole(java.lang.String)
 * 
 * -- HttpServletRequest.html#login(java.lang.String, java.lang.String)
 * 
 * -- HttpServletRequest.html#logout()
 * 
 * @author 831743
 *
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter
{
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityConfig.class);

    @Autowired
    AuthenticationProvider backendAuthenticationProvider;

    @Autowired
    AccessDeniedHandler customAccessDeniedHandler;

    @Autowired
    AuthenticationEntryPoint customAuthenticationEntryPoint;

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception
    {
        LOGGER.debug("configureGlobal");
        auth.authenticationProvider(backendAuthenticationProvider);
    }

    /**
     * Configuring the global Web security to ignore some directories.
     */
    @Override
    public void configure(WebSecurity web) throws Exception
    {
        LOGGER.debug("configure WebSecurity");
        // Spring Security should completely ignore URLs starting with
        // /static/js/
        web.ignoring().antMatchers("/static/js/**").and();
        // Spring Security should completely ignore URLs starting with
        // /static/css/
        web.ignoring().antMatchers("/static/css/**").and();
        web.ignoring().antMatchers("/static/font/**").and();
        web.ignoring().antMatchers("/static/font-awesome/**").and();
    }

    /**
     * Configuring the security to specify the various access level of resources
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception
    {
        LOGGER.debug("configure HttpSecurity");
        // Set Http basic authentication
        http.httpBasic().and();
        // Set custom accessDenied
        http.exceptionHandling().accessDeniedHandler(customAccessDeniedHandler);
        http.exceptionHandling().authenticationEntryPoint(customAuthenticationEntryPoint);
        // Set the authorized pages for unAuthenticated users
        http.authorizeRequests().antMatchers("/static/index.html", "/static/login.html", "/static/", "/").permitAll().and();
        // Set all other requests requires authentication.
        http.authorizeRequests().anyRequest().authenticated().and();
        // disable csrf
        http.csrf().disable();
    }

}
