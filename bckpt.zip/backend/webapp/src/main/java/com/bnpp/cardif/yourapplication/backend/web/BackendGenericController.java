package com.bnpp.cardif.yourapplication.backend.web;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnpp.cardif.yourapplication.backend.services.BaseService;
import com.bnpp.cardif.yourapplication.beans.RestResponse;
import com.bnpp.cardif.yourapplication.exception.ErrorCode;
import com.bnpp.cardif.yourapplication.exception.FunctionalException;
import com.bnpp.cardif.yourapplication.exception.TechnicalException;

/**
 * Super class for all Controllers
 * 
 * @author 831743
 *
 */
public abstract class BackendGenericController<E> extends SpringBeanAutowiringSupport
{
    private static final Logger LOGGER = LoggerFactory.getLogger(BackendGenericController.class);

    public abstract BaseService<E> getService();

    /**
     * REST Operation : < create >
     * 
     * @param entity
     *            E : the object to create.
     * @return E : the updated object.
     */
    public ResponseEntity<RestResponse<E>> createEntity(@RequestBody E entity)
    {
        LOGGER.debug("createEntity start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            E createdEntity = this.getService().create(entity);
            if (createdEntity != null)
            {
                restResponse.setContentNumber(1);
                List<E> content = new ArrayList<E>();
                content.add(createdEntity);
                restResponse.setContent(content);
            }
            else
            {
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechnicalException e)
        {
            LOGGER.error("createEntity error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("createEntity end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < createList > [LIST]
     * 
     * @param entityList
     *            List<E> : the list of object to create in DB.
     * @return List<E> : the list of created objects.
     */
    public ResponseEntity<RestResponse<E>> createEntityList(@RequestBody List<E> entityList)
    {
        LOGGER.debug("createEntityList start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            List<E> createdEList = this.getService().create(entityList);
            if (createdEList != null)
            {
                restResponse.setContentNumber(createdEList.size());
                restResponse.setContent(createdEList);
            }
            else
            {
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechnicalException e)
        {
            LOGGER.error("createEntityList error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("createEntityList end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < read >
     * 
     * @param identifier
     *            Integer : the object identifier
     * @return E : the object found in the DB.
     */
    public ResponseEntity<RestResponse<E>> readEntity(@PathVariable Long identifier)
    {
        LOGGER.debug("readEntity start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            E resultEntity = this.getService().findOne(identifier);
            if (resultEntity != null)
            {
                restResponse.setContentNumber(1);
                List<E> content = new ArrayList<E>();
                content.add(resultEntity);
                restResponse.setContent(content);
            }
            else
            {
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechnicalException e)
        {
            LOGGER.error("readEntity error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("readEntity end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < ReadList >
     * 
     * @param identifierList
     *            List<Integer> : the list of object identifiers.
     * @return List<E> : the list of found objects.
     */
    public ResponseEntity<RestResponse<E>> readEntityList(@RequestBody List<Long> identifierList)
    {
        LOGGER.debug("readEntityList start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            List<E> resultEntityList = this.getService().findAll(identifierList);
            if (resultEntityList != null)
            {
                restResponse.setContentNumber(resultEntityList.size());
                restResponse.setContent(resultEntityList);
            }
            else
            {
                restResponse.setContentNumber(0);
            }
        }
        catch (TechnicalException e)
        {
            LOGGER.error("readEntityList error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("readEntityList end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < list >
     * 
     * @return List<E> : the list of all object from the DB.
     */
    public ResponseEntity<RestResponse<E>> listEntity()
    {
        LOGGER.debug("listEntity start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            List<E> entityList = this.getService().findAll();
            if (entityList != null)
            {
                restResponse.setContentNumber(entityList.size());
                restResponse.setContent(entityList);
            }
            else
            {
                restResponse.setContentNumber(0);
            }
        }
        catch (TechnicalException e)
        {
            LOGGER.error("listEntity error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("listEntity end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < update >
     * 
     * @param entity
     *            E : the object to update
     * @return E : the updated object.
     */
    public ResponseEntity<RestResponse<E>> updateEntity(@RequestBody E entity)
    {
        LOGGER.debug("updateEntity start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            E createdEntity = this.getService().update(entity);
            if (createdEntity != null)
            {
                restResponse.setContentNumber(1);
                List<E> content = new ArrayList<E>();
                content.add(createdEntity);
                restResponse.setContent(content);
            }
            else
            {
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechnicalException e)
        {
            LOGGER.error("updateEntity error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateEntity end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < updateList > [LIST]
     * 
     * @param entityList
     *            List<E> : the list of object to update in DB.
     * @return List<E> : the list of updated objects.
     */
    public ResponseEntity<RestResponse<E>> updateEntityList(@RequestBody List<E> entityList)
    {
        LOGGER.debug("updateEntityList start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            List<E> createdEList = this.getService().update(entityList);
            if (createdEList != null)
            {
                restResponse.setContentNumber(createdEList.size());
                restResponse.setContent(createdEList);
            }
            else
            {
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechnicalException e)
        {
            LOGGER.error("updateEntityList error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateEntityList end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < delete > [ONE]
     * 
     * @param identifier
     *            Integer : the identifier of the object to be deleted.
     */
    public ResponseEntity<RestResponse<E>> deleteEntity(@PathVariable Long identifier)
    {
        LOGGER.debug("deleteEntity start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            this.getService().delete(identifier);
            restResponse.setContentNumber(0);
        }
        catch (TechnicalException e)
        {
            LOGGER.error("deleteEntity error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("deleteEntity end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < deleteList > [LIST]
     * 
     * @param entityList
     *            List<E> : the list of objects to be deleted.
     */
    public ResponseEntity<RestResponse<E>> deleteEntityList(@RequestBody List<E> entityList)
    {
        LOGGER.debug("deleteEntityList start");
        RestResponse<E> restResponse = new RestResponse<E>();
        try
        {
            this.getService().delete(entityList);
            restResponse.setContentNumber(0);
        }
        catch (TechnicalException e)
        {
            LOGGER.error("deleteEntityList error : ", e);
            restResponse = generateTechnicalExceptionResponse(e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("deleteEntityList end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < exists >
     * 
     * @param identifier
     *            Integer : the object identifier
     * @return boolean : true if the object exists, false otherwise.
     */
    public ResponseEntity<RestResponse<Boolean>> exist(@PathVariable Long identifier)
    {
        LOGGER.debug("exist start");
        RestResponse<Boolean> restResponse = new RestResponse<Boolean>();
        try
        {
            boolean result = this.getService().exists(identifier);
            restResponse.setContentNumber(1);
            List<Boolean> content = new ArrayList<Boolean>();
            content.add(new Boolean(result));
            restResponse.setContent(content);
        }
        catch (TechnicalException e)
        {
            LOGGER.error("exist error : ", e);
            restResponse = new RestResponse<Boolean>();
            restResponse.setErrorCode(e.getCode());
            restResponse.setErrorMessage(e.getMessage());
            restResponse.setContentNumber(0);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("exist end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * REST Operation : < count >
     * 
     * @return long : the number of object found.
     */
    public ResponseEntity<RestResponse<Long>> countEntities()
    {
        LOGGER.debug("countEntities start");
        RestResponse<Long> restResponse = new RestResponse<Long>();
        try
        {
            long result = this.getService().count();
            restResponse.setContentNumber(1);
            List<Long> content = new ArrayList<Long>();
            content.add(new Long(result));
            restResponse.setContent(content);
        }
        catch (TechnicalException e)
        {
            LOGGER.error("countEntities error : ", e);
            restResponse = new RestResponse<Long>();
            restResponse.setErrorCode(e.getCode());
            restResponse.setErrorMessage(e.getMessage());
            restResponse.setContentNumber(0);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("countEntities end");
        return ResponseEntity.ok(restResponse);
    }

    /**
     * Generate a RestResponse<E> object based on the exception.
     * 
     * @param exception
     *            TechnicalException : the original exception.
     * @return RestResponse<E> : the error response.
     */
    protected RestResponse<E> generateTechnicalExceptionResponse(TechnicalException exception)
    {
        RestResponse<E> restResponse = new RestResponse<E>();
        restResponse.setErrorCode(exception.getCode());
        restResponse.setErrorMessage(exception.getMessage());
        restResponse.setContentNumber(0);
        return restResponse;
    }

    /**
     * Generate a RestResponse<E> object based on the exception.
     * 
     * @param exception
     *            FunctionalException : the original exception.
     * @return RestResponse<E> : the error response.
     */
    protected RestResponse<E> generateFunctionalExceptionResponse(FunctionalException exception)
    {
        RestResponse<E> restResponse = new RestResponse<E>();
        restResponse.setErrorCode(exception.getCode());
        restResponse.setErrorMessage(exception.getMessage());
        restResponse.setContentNumber(0);
        return restResponse;
    }

}
