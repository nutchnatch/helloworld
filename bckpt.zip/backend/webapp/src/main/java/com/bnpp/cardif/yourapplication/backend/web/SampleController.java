package com.bnpp.cardif.yourapplication.backend.web;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.yourapplication.backend.services.BaseService;
import com.bnpp.cardif.yourapplication.backend.services.SampleService;
import com.bnpp.cardif.yourapplication.beans.RestResponse;
import com.bnpp.cardif.yourapplication.beans.Sample;

/**
 * Controller for the REST API related to "Sample" objects.
 * 
 * @author 831743
 *
 */
@RestController
@RequestMapping("/v1/samples/json")
public class SampleController extends BackendGenericController<Sample>
{
    private static final Logger LOGGER = LoggerFactory.getLogger(SampleController.class);

    @Autowired
    private SampleService sampleService;

    @Override
    public BaseService<Sample> getService()
    {
        return sampleService;
    }

    /**
     * @return the sampleService
     */
    public SampleService getSampleService()
    {
        return sampleService;
    }

    /**
     * @param sampleService
     *            the sampleService to set
     */
    public void setSampleService(SampleService sampleService)
    {
        this.sampleService = sampleService;
    }

    /**
     * REST Operation : < create >
     * 
     * @param entity
     *            E : the object to create.
     * @return E : the updated object.
     */
    @Override
    @RequestMapping(method = RequestMethod.PUT, value = "/create/single", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RestResponse<Sample>> createEntity(@RequestBody Sample entity)
    {
        return super.createEntity(entity);
    }

    /**
     * REST Operation : < create >
     * 
     * @param entity
     *            E : the object to create.
     * @return E : the updated object.
     */
    @Override
    @RequestMapping(method = RequestMethod.PUT, value = "/create/list", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RestResponse<Sample>> createEntityList(@RequestBody List<Sample> entityList)
    {
        return super.createEntityList(entityList);
    }

    /**
     * REST Operation : < read >
     * 
     * @param identifier
     *            Integer : the object identifier
     * @return E : the object found in the DB.
     */
    @Override
    @RequestMapping(method = RequestMethod.GET, value = "/get" + "/{identifier}")
    public ResponseEntity<RestResponse<Sample>> readEntity(@PathVariable Long identifier)
    {
        return super.readEntity(identifier);
    }

    /**
     * REST Operation : < ReadList >
     * 
     * @param identifierList
     *            List<Integer> : the list of object identifiers.
     * @return List<Sample> : the list of found objects.
     */
    @Override
    @RequestMapping(method = RequestMethod.POST, value = "/search", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RestResponse<Sample>> readEntityList(@RequestBody List<Long> identifierList)
    {
        return super.readEntityList(identifierList);
    }

    /**
     * REST Operation : < list >
     * 
     * @return List<Sample> : the list of all object from the DB.
     */
    @Override
    @RequestMapping(method = RequestMethod.GET, value = "/list")
    public ResponseEntity<RestResponse<Sample>> listEntity()
    {
        return super.listEntity();
    }

    /**
     * REST Operation : < update >
     * 
     * @param entity
     *            E : the object to update
     * @return E : the updated object.
     */
    @Override
    @RequestMapping(method = RequestMethod.PUT, value = "/update/single", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RestResponse<Sample>> updateEntity(@RequestBody Sample entity)
    {
        return super.updateEntity(entity);
    }

    /**
     * REST Operation : < updateList > [LIST]
     * 
     * @param entityList
     *            List<Sample> : the list of object to update in DB.
     * @return List<Sample> : the list of updated objects.
     */
    @Override
    @RequestMapping(method = RequestMethod.PUT, value = "/update/list", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RestResponse<Sample>> updateEntityList(@RequestBody List<Sample> entityList)
    {
        return super.updateEntityList(entityList);
    }

    /**
     * REST Operation : < delete > [ONE]
     * 
     * @param identifier
     *            Integer : the identifier of the object to be deleted.
     */
    @Override
    @RequestMapping(method = RequestMethod.DELETE, value = "/delete" + "/{identifier}")
    public ResponseEntity<RestResponse<Sample>> deleteEntity(@PathVariable Long identifier)
    {
        return super.deleteEntity(identifier);
    }

    /**
     * REST Operation : < deleteList > [LIST]
     * 
     * @param entityList
     *            List<Sample> : the list of objects to be deleted.
     */
    @Override
    @RequestMapping(method = RequestMethod.POST, value = "/delete", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<RestResponse<Sample>> deleteEntityList(@RequestBody List<Sample> entityList)
    {
        return super.deleteEntityList(entityList);
    }

    /**
     * REST Operation : < exists >
     * 
     * @param identifier
     *            Integer : the object identifier
     * @return boolean : true if the object exists, false otherwise.
     */
    @Override
    @RequestMapping(method = RequestMethod.GET, value = "/exists" + "/{identifier}")
    public ResponseEntity<RestResponse<Boolean>> exist(@PathVariable Long identifier)
    {
        return super.exist(identifier);
    }

    /**
     * REST Operation : < count >
     * 
     * @return long : the number of object found.
     */
    @Override
    @RequestMapping(method = RequestMethod.GET, value = "/count")
    public ResponseEntity<RestResponse<Long>> countEntities()
    {
        return super.countEntities();
    }

}
