package com.bnpp.cardif.yourapplication.dao;

import org.springframework.data.repository.CrudRepository;

import com.bnpp.cardif.yourapplication.beans.Sample;

/**
 * Interface for the DAO related to Sample entities
 * 
 * @author 831743
 *
 */
public interface SampleDAO extends CrudRepository<Sample, Long>, SampleDAOCustom
{

}
