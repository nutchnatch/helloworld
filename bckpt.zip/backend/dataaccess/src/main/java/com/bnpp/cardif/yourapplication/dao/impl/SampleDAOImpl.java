package com.bnpp.cardif.yourapplication.dao.impl;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.bnpp.cardif.yourapplication.beans.Sample;
import com.bnpp.cardif.yourapplication.dao.SampleDAOCustom;

/**
 * Implementation class for the custom methods of the SampleDAO
 * 
 * @see com.bnpp.cardif.yourapplication.dao.SampleDAO.class
 * 
 * @author 831743
 *
 */
@Repository("sampleDAO")
@Scope("singleton")
// default value specified to be obvious.
public class SampleDAOImpl implements SampleDAOCustom
{
    @Override
    public void someCustomMethod(Sample sample)
    {
        // Your custom implementation
    }

}
