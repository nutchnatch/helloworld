package com.bnpp.cardif.yourapplication.dao;

import com.bnpp.cardif.yourapplication.beans.Sample;

/**
 * Interface for Custom methods of the SampleDAO
 * 
 * @see com.bnpp.cardif.yourapplication.dao.SampleDAO.class
 * 
 * @author 831743
 *
 */
public interface SampleDAOCustom
{
    public void someCustomMethod(Sample sample);

}
