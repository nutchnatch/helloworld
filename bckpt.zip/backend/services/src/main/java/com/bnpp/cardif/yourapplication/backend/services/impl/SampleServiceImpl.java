package com.bnpp.cardif.yourapplication.backend.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.yourapplication.backend.services.SampleService;
import com.bnpp.cardif.yourapplication.beans.Sample;
import com.bnpp.cardif.yourapplication.dao.SampleDAO;

/**
 * Implementation of service related to Sample Entities.
 * 
 * @author 831743
 *
 */
@Service("sampleService")
@Scope("singleton")
// default value specified to be obvious.
public class SampleServiceImpl extends AbstractService<Sample> implements SampleService
{
    @Autowired
    private SampleDAO sampleDAO;

    @Override
    public CrudRepository<Sample, Long> getDAO()
    {
        return getSampleDAO();
    }

    public SampleDAO getSampleDAO()
    {
        return sampleDAO;
    }

    public void setSampleDAO(SampleDAO sampleDAO)
    {
        this.sampleDAO = sampleDAO;
    }
}
