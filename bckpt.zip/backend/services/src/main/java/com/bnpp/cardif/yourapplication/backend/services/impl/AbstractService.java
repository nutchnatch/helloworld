package com.bnpp.cardif.yourapplication.backend.services.impl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bnpp.cardif.yourapplication.backend.services.BaseService;
import com.bnpp.cardif.yourapplication.beans.GenericBean;
import com.bnpp.cardif.yourapplication.exception.InvalidInputException;
import com.bnpp.cardif.yourapplication.exception.TechnicalException;
import com.bnpp.cardif.yourapplication.utils.CollectionUtils;

/**
 * This class contains generic methods for services.
 * 
 * @author Eric Le Bail
 */
public abstract class AbstractService<E extends GenericBean> implements BaseService<E>
{
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractService.class);

    /**
     * Get the DAO for the given entity.
     * 
     * @return the DAO (crud repository)
     */
    public abstract CrudRepository<E, Long> getDAO();

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#create(java
     * .util.List)
     */
    @Override
    public List<E> create(List<E> entities) throws TechnicalException
    {
        LOGGER.debug("Creating list: " + entities);

        List<E> savedList = null;

        if (entities != null && !entities.isEmpty())
        {
            for (E entity : entities)
            {
                applyCreationValues(entity);
            }
            // Save
            Iterable<E> saveIteratorList = getDAO().save(entities);

            // Convert to list
            savedList = CollectionUtils.makeCollection(saveIteratorList);
        }
        else
        {
            LOGGER.error("Entity list may not be null or empty");
        }

        LOGGER.debug("Created list: " + savedList);

        return savedList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#update(java
     * .util.List)
     */
    @Override
    public List<E> update(List<E> entities) throws TechnicalException
    {
        LOGGER.debug("Updating list: " + entities);

        List<E> savedList = null;

        if (entities != null && !entities.isEmpty())
        {
            for (E entity : entities)
            {
                applymodificationValues(entity);
            }
            // Save
            Iterable<E> saveIteratorList = getDAO().save(entities);
            // Convert to list
            savedList = CollectionUtils.makeCollection(saveIteratorList);
        }
        else
        {
            LOGGER.error("Entity list may not be null or empty");
        }

        LOGGER.debug("Updated  list: " + savedList);

        return savedList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#create(java
     * .lang.Object)
     */
    @Override
    public E create(E entity) throws TechnicalException
    {
        LOGGER.debug("Creating entity " + entity);
        E savedEntity;
        if (entity != null)
        {
            applyCreationValues(entity);
            // save entity
            savedEntity = getDAO().save(entity);
        }
        else
        {
            throw new InvalidInputException("Entity to save cannot be null.");
        }
        LOGGER.debug("Created entity " + savedEntity);
        return savedEntity;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#update(java
     * .lang.Object)
     */
    @Override
    public E update(E entity) throws TechnicalException
    {
        LOGGER.debug("Updating entity " + entity);
        E savedEntity;
        if (entity != null)
        {
            applymodificationValues(entity);
            // save entity
            savedEntity = getDAO().save(entity);
        }
        else
        {
            throw new InvalidInputException("Entity to save cannot be null.");
        }
        LOGGER.debug("Updated entity " + savedEntity);
        return savedEntity;
    }

    private void applyCreationValues(E entity)
    {
        // Get current user:
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        // apply default values
        entity.setCreationDate(new Date());
        entity.setCreationUser(currentPrincipalName);
        entity.setModificationDate(new Date());
        entity.setModificationUser(currentPrincipalName);
    }

    private void applymodificationValues(E entity)
    {
        // Get current user:
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        // apply default values
        entity.setModificationDate(new Date());
        entity.setModificationUser(currentPrincipalName);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#findOne(
     * java.lang.Long)
     */
    @Override
    public E findOne(Long id) throws TechnicalException
    {
        LOGGER.debug("Finding entity with id " + id);
        E foundEntity;
        if (id != null)
        {
            foundEntity = getDAO().findOne(id);
        }
        else
        {
            throw new InvalidInputException("Id is mandatory to find one entity");
        }
        LOGGER.debug("Found entity " + foundEntity);
        return foundEntity;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#exists(java
     * .lang.Long)
     */
    @Override
    public boolean exists(Long id) throws TechnicalException
    {
        LOGGER.debug("Check if id " + id + " exists.");
        boolean exists;
        if (id != null)
        {
            exists = getDAO().exists(id);
        }
        else
        {
            throw new InvalidInputException("Id is mandatory to check if entity exists.");
        }
        LOGGER.debug("Founded entity? " + exists);
        return exists;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#findAll()
     */
    @Override
    public List<E> findAll() throws TechnicalException
    {
        LOGGER.debug("Find all entities");
        List<E> findAllList;
        Iterable<E> findAllIterator = getDAO().findAll();
        findAllList = CollectionUtils.makeCollection(findAllIterator);
        LOGGER.debug("Found " + (findAllList != null ? findAllList.size() : 0) + " entities.");
        return findAllList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#findAll(
     * java.util.List)
     */
    @Override
    public List<E> findAll(List<Long> ids) throws TechnicalException
    {
        LOGGER.debug("Find by ids " + ids);
        List<E> findByIdList;
        if (ids != null)
        {
            Iterable<E> findAllByIdsIterator = getDAO().findAll(ids);
            findByIdList = CollectionUtils.makeCollection(findAllByIdsIterator);
        }
        else
        {
            throw new InvalidInputException("Id list is mandatory to search by id.");
        }
        LOGGER.debug("Found " + (findByIdList != null ? findByIdList.size() : 0) + " entities.");
        return findByIdList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.yourapplication.backend.services.BaseService#count()
     */
    @Override
    public long count() throws TechnicalException
    {
        LOGGER.debug("Counting number of entities.");
        long count;
        count = getDAO().count();
        LOGGER.debug("Found " + count + " entities.");
        return 0;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#delete(java
     * .lang.Long)
     */
    @Override
    public void delete(Long id) throws TechnicalException
    {
        LOGGER.debug("Deleting entity with id " + id);
        if (id != null)
        {
            getDAO().delete(id);
        }
        else
        {
            throw new InvalidInputException("Id is mandatory to delete one entity.");
        }
        LOGGER.debug("Deleted entity with id " + id);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#delete(java
     * .lang.Object)
     */
    @Override
    public void delete(E entity) throws TechnicalException
    {
        LOGGER.debug("Deleting entity " + entity);
        if (entity != null)
        {
            getDAO().delete(entity);
        }
        else
        {
            throw new InvalidInputException("Entity to delete cannot be null.");
        }
        LOGGER.debug("Deleted entity " + entity);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.yourapplication.backend.services.BaseService#delete(java
     * .util.List)
     */
    @Override
    public void delete(List<E> entities) throws TechnicalException
    {
        LOGGER.debug("Deleting entity list " + entities);
        if (entities != null)
        {
            getDAO().delete(entities);
        }
        else
        {
            throw new InvalidInputException("Entity list to delete cannot be null.");
        }
        LOGGER.debug("Deleted entity list " + entities);
    }
}
