"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var Subject_1 = require("rxjs/Subject");
require("rxjs/add/observable/of");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/debounceTime");
require("rxjs/add/operator/distinctUntilChanged");
var hero_search_service_1 = require("./hero-search.service");
var HeroSearchComponent = (function () {
    function HeroSearchComponent() {
    }
    return HeroSearchComponent;
}());
HeroSearchComponent = __decorate([
    core_1.Component({
        selector: 'hero-search',
        templateUrl: './hero-search.component.html',
        styleUrls: ['./hero-search.component.css'],
        providers: [hero_search_service_1.HeroSearchService]
    })
], HeroSearchComponent);
exports.HeroSearchComponent = HeroSearchComponent;
 > ;
searchTerms = new Subject_1.Subject();
constructor(private, heroSearchService, hero_search_service_1.HeroSearchService, private, router, router_1.Router);
{ }
search(term, string);
void {
    this: .searchTerms.next(term)
};
ngOnInit();
void {
    this: .heroes = this.searchTerms
};
//# sourceMappingURL=hero-search.component.js.map