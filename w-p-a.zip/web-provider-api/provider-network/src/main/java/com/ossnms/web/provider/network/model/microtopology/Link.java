package com.ossnms.web.provider.network.model.microtopology;

import java.io.Serializable;

/**
 * Created on 20-09-2016.
 */
public class Link implements Serializable {

    private static final long serialVersionUID = 4725558696342337463L;
    private String id;
    private String name;
    private String node;
    private String type;
    private String directionality;
    private String aEnd;
    private String zEnd;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNode() {
        return node;
    }

    public void setNode(String node) {
        this.node = node;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDirectionality() {
        return directionality;
    }

    public void setDirectionality(String directionality) {
        this.directionality = directionality;
    }

    public String getaEnd() {
        return aEnd;
    }

    public void setaEnd(String aEnd) {
        this.aEnd = aEnd;
    }

    public String getzEnd() {
        return zEnd;
    }

    public void setzEnd(String zEnd) {
        this.zEnd = zEnd;
    }

}
