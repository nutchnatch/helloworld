package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.SystemContainerID;

/**
 * Created on 08-09-2016.
 */
public class SystemContainer extends BaseEntity<SystemContainer, SystemContainerID, SystemContainer.Builder> implements Entity<SystemContainerID> {

    private static final long serialVersionUID = -5741588654876086743L;
    private String description;

    public String getDescription() {
        return description;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<SystemContainer, SystemContainerID, SystemContainer.Builder> {

        private String description;

        /**
         * @param systemContainerID
         */
        public Builder(SystemContainerID systemContainerID) {
            super(systemContainerID, EntityType.SYSTEM_CONTAINER);
        }

        public SystemContainer.Builder description(String description) {
            this.description = description;
            return this;
        }

        /**
         * @return
         */
        public SystemContainer build() {
            return new SystemContainer(this);
        }
    }

    /**
     * @param builder
     */
    private SystemContainer(SystemContainer.Builder builder) {
        super(builder);
        this.description = builder.description;
    }

}
