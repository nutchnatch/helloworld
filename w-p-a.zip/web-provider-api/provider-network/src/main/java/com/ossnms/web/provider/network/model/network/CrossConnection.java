package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.CcProtectionStateType;
import com.ossnms.web.provider.network.model.network.enumerable.CcStateType;
import com.ossnms.web.provider.network.model.network.enumerable.CcType;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.CrossConnectionID;

/**
 * Created on 08-09-2016.
 */
public class CrossConnection extends BaseEntity<CrossConnection, CrossConnectionID, CrossConnection.Builder> implements Entity<CrossConnectionID> {

    private static final long serialVersionUID = -3582433838583202822L;
    private OperationalState operationalState;
    private CcType ccType;
    private CcStateType state;
    private CcProtectionStateType protectionState;

    public OperationalState getOperationalState() {
        return operationalState;
    }

    public CcType getCcType() {
        return ccType;
    }

    public CcStateType getState() {
        return state;
    }

    public CcProtectionStateType getProtectionState() {
        return protectionState;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<CrossConnection, CrossConnectionID, CrossConnection.Builder> {

        private OperationalState operationalState;
        private CcType ccType;
        private CcStateType state;
        private CcProtectionStateType protectionState;

        /**
         * @param crossConnectionID
         */
        public Builder(CrossConnectionID crossConnectionID) {
            super(crossConnectionID, EntityType.CROSS_CONNECTION);
        }

        public CrossConnection.Builder operationalState(OperationalState operationalState) {
            this.operationalState = operationalState;
            return this;
        }

        public CrossConnection.Builder ccType(CcType ccType) {
            this.ccType = ccType;
            return this;
        }

        public CrossConnection.Builder state(CcStateType state) {
            this.state = state;
            return this;
        }

        public CrossConnection.Builder protectionState(CcProtectionStateType protectionState) {
            this.protectionState = protectionState;
            return this;
        }

        public CrossConnection build() {
            return new CrossConnection(this);
        }
    }

    /**
     * @param builder
     */
    private CrossConnection(CrossConnection.Builder builder) {
        super(builder);
        this.operationalState = builder.operationalState;
        this.ccType = builder.ccType;
        this.state = builder.state;
        this.protectionState = builder.protectionState;
    }
}
