package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created on 14-09-2016.
 */
public enum TpDirectionType implements BaseEnum {

    NONE("none", 0),
    SINK("sink", 1),
    SOURCE("source", 2),
    BIDIRECTIONAL("bidirectional", 3);

    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    TpDirectionType(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link TpDirectionType}; null if no match
     */
    public static TpDirectionType fromName(String name) {
        return name != null ?
                getValue(
                        TpDirectionType.values(),
                        candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
                ) : null;
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link TpDirectionType}; null if no match
     */
    public static TpDirectionType fromOrdinal(int ordinal) {
        return getValue(
                TpDirectionType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
