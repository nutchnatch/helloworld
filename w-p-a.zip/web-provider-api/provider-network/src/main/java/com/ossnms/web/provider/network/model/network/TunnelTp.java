package com.ossnms.web.provider.network.model.network;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.AdministrativeStateType;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.TunnelTpID;

public class TunnelTp extends BaseEntity<TunnelTp, TunnelTpID, TunnelTp.Builder> {
    private static final long serialVersionUID = 1606627664843182613L;

    private final String description;
    private final Long bandwidth;
    private final OperationalState operationalState;
    private final AdministrativeStateType adminState;

    /**
     * @param builder
     */
    private TunnelTp(Builder builder) {
        super(builder);
        this.description = builder.description;
        this.bandwidth = builder.bandwidth;
        this.operationalState = builder.operationalState;
        this.adminState = builder.adminState;
    }

    public String getDescription() {
        return description;
    }

    public Long getBandwidth() {
        return bandwidth;
    }

    public OperationalState getOperationalState() {
        return operationalState;
    }

    public AdministrativeStateType getAdminState() {
        return adminState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        TunnelTp tunnelTp = (TunnelTp) o;
        return Objects.equals(description, tunnelTp.description) &&
                Objects.equals(bandwidth, tunnelTp.bandwidth) &&
                operationalState == tunnelTp.operationalState &&
                adminState == tunnelTp.adminState;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), description, bandwidth, operationalState, adminState);
    }

    @Override
    public String toString() {
        return "TunnelTp{" +
                "description='" + description + '\'' +
                ", bandwidth=" + bandwidth +
                ", operationalState=" + operationalState +
                ", adminState=" + adminState +
                '}';
    }

    public static class Builder extends BaseEntity.Builder<TunnelTp, TunnelTpID, TunnelTp.Builder> {
        private String description;
        private Long bandwidth;
        private OperationalState operationalState;
        private AdministrativeStateType adminState;

        /**
         * @param entityID
         */
        public Builder(TunnelTpID entityID) {
            super(entityID, EntityType.TUNNEL_TP);
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder bandwidth(Long bandwidth) {
            this.bandwidth = bandwidth;
            return this;
        }

        public Builder operationalState(OperationalState operationalState) {
            this.operationalState = operationalState;
            return this;
        }

        public Builder adminState(AdministrativeStateType adminState) {
            this.adminState = adminState;
            return this;
        }

        @Override
        public TunnelTp build() {
            return new TunnelTp(this);
        }
    }
}
