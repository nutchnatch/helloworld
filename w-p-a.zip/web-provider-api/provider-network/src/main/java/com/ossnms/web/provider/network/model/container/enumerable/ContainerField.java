package com.ossnms.web.provider.network.model.container.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum ContainerField {

    ID                  ("id", 0),
    PARENT_CONTAINER    ("parentContainer", 1),
    TYPE                ("type", 2),
    NAME                ("name", 3),
    SERVICE_LEVEL       ("serviceLevel", 4);

    private final String name;
    private final int ordinal;

    ContainerField(String name, int ordinal){

        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link ContainerField}; null if no match
     */
    public static ContainerField fromName(String name){
        return getValue(
                ContainerField.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link ContainerField}; null if no match
     */
    public static ContainerField fromOrdinal(int ordinal){
        return getValue(
                ContainerField.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
