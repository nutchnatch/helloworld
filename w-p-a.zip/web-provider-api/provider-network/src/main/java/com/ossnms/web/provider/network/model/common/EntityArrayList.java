package com.ossnms.web.provider.network.model.common;

import com.ossnms.web.provider.common.api.model.EntityCollection;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created on 16-09-2016.
 */
public class EntityArrayList<T> extends ArrayList<T> implements EntityCollection<T> {
    private static final long serialVersionUID = 8606398603825055603L;

    private String notificationsChannel;

    public EntityArrayList(int initialCapacity) {
        super(initialCapacity);
    }

    public EntityArrayList() {
    }

    public EntityArrayList(Collection<? extends T> c) {
        super(c);
    }

    public String getNotificationsChannel() {
        return notificationsChannel;
    }

    public void setNotificationsChannel(String notificationsChannel) {
        this.notificationsChannel = notificationsChannel;
    }
}

