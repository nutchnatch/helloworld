package com.ossnms.web.provider.network.model.path.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum PathProtection {

    UNPROTECTED                     ("Unprotected", 0),
    DSR                             ("DSR", 1),
    PERMANENT_RESTORATION_PLUS_DSR  ("PermanentRestorationPlusDSR", 2),
    PERMANENT_ONE_PLUS_ONE_PLUS_DSR ("PermanentOnePlusOnePlusDSR", 3),
    UNPROTECTED_PREEMPTABLE         ("UnprotectedPreemptable", 4),
    ONE_PLUS_ONE                    ("OnePlusOne", 5),
    ONE_TO_ONE                      ("OneToOne", 6),
    RESTORATION                     ("Restoration", 7),
    PARTLY_PROTECTED                ("PartlyProtected", 8),
    END_TO_END_PROTECTED            ("EndToEndProtected", 9),
    LSP_ONE_TO_ONE                  ("LSP_OneToOne", 10),
    ERP                             ("ERP", 11);

    private final String name;
    private final int ordinal;

    PathProtection(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link PathProtection}; null if no match
     */
    public static PathProtection fromName(String name){
        return getValue(
                PathProtection.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link PathProtection}; null if no match
     */
    public static PathProtection fromOrdinal(int ordinal){
        return getValue(
                PathProtection.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
