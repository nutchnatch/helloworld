package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.Direction;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.TopologicalLinkID;

/**
 * Created on 13-09-2016.
 */
public class TopologicalLink extends BaseEntity<TopologicalLink, TopologicalLinkID, TopologicalLink.Builder> implements Entity<TopologicalLinkID> {

    private static final long serialVersionUID = 1099040934180009000L;
    private Direction direction;
    private OperationalState linkState;
    private OperationalState aEndOperationalState;
    private OperationalState zEndOperationalState;
    private String aEndName;
    private String zEndName;
    private boolean aEndInvisible;
    private boolean zEndInvisible;

    public Direction getDirection() {
        return direction;
    }

    public OperationalState getLinkState() {
        return linkState;
    }

    public OperationalState getaEndOperationalState() {
        return aEndOperationalState;
    }

    public OperationalState getzEndOperationalState() {
        return zEndOperationalState;
    }

    public String getaEndName() {
        return aEndName;
    }

    public String getzEndName() {
        return zEndName;
    }

    public boolean isaEndInvisible() {
        return aEndInvisible;
    }

    public boolean iszEndInvisible() {
        return zEndInvisible;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<TopologicalLink, TopologicalLinkID, TopologicalLink.Builder> {
        private Direction direction;
        private OperationalState linkState;
        private OperationalState aEndOperationalState;
        private OperationalState zEndOperationalState;
        private String aEndName;
        private String zEndName;
        private boolean aEndInvisible;
        private boolean zEndInvisible;

        /**
         * @param topologicalLinkID
         */
        public Builder(TopologicalLinkID topologicalLinkID) {
            super(topologicalLinkID, EntityType.TOPOLOGICAL_LINK);
        }

        public TopologicalLink.Builder direction(Direction direction) {
            this.direction = direction;
            return this;
        }

        public TopologicalLink.Builder linkState(OperationalState operationalState) {
            this.linkState = operationalState;
            return this;
        }

        public TopologicalLink.Builder aEndOperationalState(OperationalState operationalState) {
            this.aEndOperationalState = operationalState;
            return this;
        }

        public TopologicalLink.Builder zEndOperationalState(OperationalState operationalState) {
            this.zEndOperationalState = operationalState;
            return this;
        }

        public TopologicalLink.Builder aEndName(String name) {
            this.aEndName = name;
            return this;
        }

        public TopologicalLink.Builder zEndName(String name) {
            this.zEndName = name;
            return this;
        }

        public TopologicalLink.Builder aEndInvisible(boolean aEndInvisible) {
            this.aEndInvisible = aEndInvisible;
            return this;
        }

        public TopologicalLink.Builder zEndInvisible(boolean zEndInvisible) {
            this.zEndInvisible = zEndInvisible;
            return this;
        }

        public TopologicalLink build() {
            return new TopologicalLink(this);
        }
    }

    /**
     * @param builder
     */
    private TopologicalLink(TopologicalLink.Builder builder) {
        super(builder);
        this.direction = builder.direction;
        this.linkState = builder.linkState;
        this.aEndOperationalState = builder.aEndOperationalState;
        this.zEndOperationalState = builder.zEndOperationalState;
        this.aEndName = builder.aEndName;
        this.zEndName = builder.zEndName;
        this.aEndInvisible = builder.aEndInvisible;
        this.zEndInvisible = builder.zEndInvisible;
    }
}
