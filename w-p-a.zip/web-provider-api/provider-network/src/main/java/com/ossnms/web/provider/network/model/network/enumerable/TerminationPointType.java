package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 * Created on 14-09-2016.
 */
public enum TerminationPointType {

    Y_CABLE(2300),
    LAG_PORT(9199),

    UNKNOWN(-1);

    private final int ordinal;

    TerminationPointType(int value) {
        this.ordinal = value;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from an value
     *
     * @param value the ordinal to search for
     * @return an instance of {@link TerminationPointType}; UNKNOWN if no match
     */
    public static TerminationPointType fromOrdinal(int value) {
        TerminationPointType result = getValue(
                TerminationPointType.values(),
                candidate -> candidate.getOrdinal() == value
        );

         return result != null ? result : UNKNOWN;
    }

}
