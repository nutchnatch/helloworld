package com.ossnms.web.provider.network.model.network;

import java.io.Serializable;

/**
 * Created on 30-09-2016.
 */
public class GeoLocation implements Serializable {

    private static final long serialVersionUID = 617628475479323921L;
    private final Double latitude;
    private final Double longitude;

    public GeoLocation(Double longitude, Double latitude) {
        this.longitude = longitude;
        this.latitude = latitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }
}
