package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.ContainerID;

/**
 * Created on 08-09-2016.
 */
public class Container extends BaseEntity<Container, ContainerID, Container.Builder> implements Entity<ContainerID> {

    private static final long serialVersionUID = 215140245126174532L;
    private String description;
    private Integer parentContainerId;

    public String getDescription() {
        return description;
    }

    public Integer getParentContainerId() {
        return parentContainerId;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<Container, ContainerID, Container.Builder> {

        private Integer parentContainerId;
        private String description;

        /**
         * @param containerID
         */
        public Builder(ContainerID containerID) {
            super(containerID, EntityType.CONTAINER);
        }

        public Container.Builder parentContainerId(Integer parentContainerId) {
            this.parentContainerId = parentContainerId;
            return this;
        }

        public Container.Builder description(String description) {
            this.description = description;
            return this;
        }

        public Container build() {
            return new Container(this);
        }
    }

    /**
     * @param builder
     */
    private Container(Container.Builder builder) {
        super(builder);
        this.parentContainerId = builder.parentContainerId;
        this.description = builder.description;
    }

}
