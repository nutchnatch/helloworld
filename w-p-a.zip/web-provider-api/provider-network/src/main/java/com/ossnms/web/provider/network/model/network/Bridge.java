package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.BridgeID;

import java.util.Collection;

/**
 * Created on 08-09-2016.
 */
public class Bridge extends BaseEntity<Bridge, BridgeID, Bridge.Builder> implements Entity<BridgeID> {

    private static final long serialVersionUID = 6446765565342794856L;
    private final String nativeLocation;
    private final Long contextId;
    private Collection<MaintenanceDomain> maintenanceDomains;

    public Long getContextId() {
        return contextId;
    }

    public String getNativeLocation() {
        return nativeLocation;
    }

    public Collection<MaintenanceDomain> getMaintenanceDomains() {
        return maintenanceDomains;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<Bridge, BridgeID, Bridge.Builder> {

        private String nativeLocation;
        private Long contextId;
        private Collection<MaintenanceDomain> maintenanceDomains;

        /**
         * @param bridgeID
         */
        public Builder(BridgeID bridgeID) {
            super(bridgeID, EntityType.BRIDGE);
        }

        public Bridge.Builder contextId(Long contextId) {
            this.contextId = contextId;
            return this;
        }

        public Bridge.Builder nativeLocation(String nativeLocation) {
            this.nativeLocation = nativeLocation;
            return this;
        }

        public Bridge.Builder maintenanceDomains(Collection<MaintenanceDomain> maintenanceDomains) {
            this.maintenanceDomains = maintenanceDomains;
            return this;
        }

        public Bridge build() {
            return new Bridge(this);
        }
    }

    /**
     * @param builder
     */
    private Bridge(Bridge.Builder builder) {
        super(builder);
        this.contextId = builder.contextId;
        this.nativeLocation = builder.nativeLocation;
        this.maintenanceDomains = builder.maintenanceDomains;
    }
}
