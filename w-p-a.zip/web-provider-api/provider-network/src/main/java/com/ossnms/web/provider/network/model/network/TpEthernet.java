package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.PacketInterfaceType;

import java.io.Serializable;

/**
 * Created on 14-09-2016.
 */
public class TpEthernet implements Serializable {

    private static final long serialVersionUID = -1476842777063123991L;
    private Integer subsysId;
    private Integer bridgeId;
    private final Integer mtuSize;
    private final Integer ethernetType;
    private final String policyMapIN;
    private final String policyMapOUT;
    private final String macAddress;
    private final PacketInterfaceType interfaceType;
    private final Float bandwidth;
    private final Boolean allToOneBundling;

    public Integer getMtuSize() {
        return mtuSize;
    }

    public Integer getEthernetType() {
        return ethernetType;
    }

    public String getPolicyMapIN() {
        return policyMapIN;
    }

    public String getPolicyMapOUT() {
        return policyMapOUT;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public PacketInterfaceType getInterfaceType() {
        return interfaceType;
    }

    public Float getBandwidth() {
        return bandwidth;
    }

    public Integer getSubsysId() {
        return subsysId;
    }

    public Integer getBridgeId() {
        return bridgeId;
    }

    public Boolean getAllToOneBundling() {
        return allToOneBundling;
    }

    public void setSubsysId(Integer subsysId) {
        this.subsysId = subsysId;
    }

    public void setBridgeId(Integer bridgeId) {
        this.bridgeId = bridgeId;
    }

    /**
     *
     */
    public static class Builder {
        private Integer subsysId;
        private Integer bridgeId;
        private Integer mtuSize;
        private Integer ethernetType;
        private String policyMapIN;
        private String policyMapOUT;
        private String macAddress;
        private PacketInterfaceType interfaceType;
        private Float bandwidth;
        private Boolean allToOneBundling;

        public Builder() {
        }

        public TpEthernet.Builder subsysId(Integer subsysId) {
            this.subsysId = subsysId;
            return this;
        }

        public TpEthernet.Builder bridgeId(Integer bridgeId) {
            this.bridgeId = bridgeId;
            return this;
        }

        public TpEthernet.Builder mtuSize(Integer mtuSize) {
            this.mtuSize = mtuSize;
            return this;
        }

        public TpEthernet.Builder ethernetType(Integer ethernetType) {
            this.ethernetType = ethernetType;
            return this;
        }

        public TpEthernet.Builder policyMapIN(String policyMap) {
            this.policyMapIN = policyMap;
            return this;
        }

        public TpEthernet.Builder policyMapOUT(String policyMap) {
            this.policyMapOUT = policyMap;
            return this;
        }

        public TpEthernet.Builder macAddress(String macAddress) {
            this.macAddress = macAddress;
            return this;
        }

        public TpEthernet.Builder interfaceType(PacketInterfaceType interfaceType) {
            this.interfaceType = interfaceType;
            return this;
        }

        public TpEthernet.Builder bandwidth(Float bandwidth) {
            this.bandwidth = bandwidth;
            return this;
        }

        public TpEthernet.Builder allToOneBundling(Boolean allToOneBundling) {
            this.allToOneBundling = allToOneBundling;
            return this;
        }

        /**
         * @return
         */
        public TpEthernet build() {
            return new TpEthernet(this);
        }
    }

    /**
     * @param builder
     */
    private TpEthernet(TpEthernet.Builder builder) {
        this.subsysId = builder.subsysId;
        this.bridgeId = builder.bridgeId;
        this.mtuSize = builder.mtuSize;
        this.ethernetType = builder.ethernetType;
        this.policyMapIN = builder.policyMapIN;
        this.policyMapOUT = builder.policyMapOUT;
        this.macAddress = builder.macAddress;
        this.interfaceType = builder.interfaceType;
        this.bandwidth = builder.bandwidth;
        this.allToOneBundling = builder.allToOneBundling;
    }

}
