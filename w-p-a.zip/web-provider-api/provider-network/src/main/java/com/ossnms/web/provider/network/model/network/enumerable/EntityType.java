package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created on 12-09-2016.
 */
public enum EntityType implements BaseEnum {

    ENTITY("Entity", 0),
    CONTAINER("Container", 1),
    SYSTEM_CONTAINER("SystemContainer", 2),
    NETWORK_ELEMENT("NetworkElement", 3),
    EQUIPMENT_HOLDER("EquipmentHolder", 4),
    EQUIPMENT("Equipment", 5),
    MAINTENANCE_DOMAIN("MaintenanceDomain", 6),
    PHYSICAL_TERMINATION_POINT("PhysicalTerminationPoint", 7),
    TERMINATION_POINT("TerminationPoint", 8),
    BRIDGE("Bridge", 9),
    VLAN("Vlan", 10),
    CROSS_CONNECTION("CrossConnection", 11),
    INTERNAL_PORT_CONNECTION("InternalPortConnection", 12),
    TOPOLOGICAL_LINK("TopologicalLink", 13),
    ALARMS_SUMMARY("AlarmsSummary", 14),
    SERVICE("Service", 15),
    ATTACHMENT_CIRCUIT_TP("AttachmentCircuitTp", 16),
    PAYLOAD_CTP("PayloadCtp", 17),
    PSEUDO_WIRE_TP("PseudoWireTp", 18),
    TUNNEL_TP("TunnelTp", 19),
    LSP_TP("LspTp", 20),
    SWITCH_POINT("SwitchingPoint", 21);


    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    EntityType(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link EntityType}; null if no match
     */
    public static EntityType fromName(String name) {
        return getValue(
                EntityType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link EntityType}; null if no match
     */
    public static EntityType fromOrdinal(int ordinal) {
        return getValue(
                EntityType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
