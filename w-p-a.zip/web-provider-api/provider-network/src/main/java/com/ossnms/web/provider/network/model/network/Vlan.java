package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.VlanID;

/**
 * Created by catarino on 09-09-2016.
 */
public class Vlan extends BaseEntity<Vlan, VlanID, Vlan.Builder> implements Entity<VlanID> {

    private static final long serialVersionUID = -5576155459828757204L;
    private Integer customerCVlan;
    private Integer customerSVlan;

    public Integer getCustomerCVlan() {
        return customerCVlan;
    }

    public Integer getCustomerSVlan() {
        return customerSVlan;
    }


    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<Vlan, VlanID, Vlan.Builder> {

        private Integer customerCVlan;
        private Integer customerSVlan;

        /**
         * @param vlanID
         */
        public Builder(VlanID vlanID) {
            super(vlanID, EntityType.VLAN);
        }

        public Vlan.Builder customerCVlan(Integer customerCVlan) {
            this.customerCVlan = customerCVlan;
            return this;
        }

        public Vlan.Builder customerSVlan(Integer customerSVlan) {
            this.customerSVlan = customerSVlan;
            return this;
        }

        public Vlan build() {
            return new Vlan(this);
        }
    }

    /**
     * @param builder
     */
    private Vlan(Vlan.Builder builder) {
        super(builder);
        this.customerCVlan = builder.customerCVlan;
        this.customerSVlan = builder.customerSVlan;
    }

}
