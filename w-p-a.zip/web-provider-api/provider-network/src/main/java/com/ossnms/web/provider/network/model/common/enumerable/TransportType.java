package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum TransportType implements BaseEnum {

    ETHERNET     ("Ethernet", 0),
    OVER_MPLS_TP ("OverMPLS-TP", 1);

    private final String name;
    private final int ordinal;

    /**
     *
     * @param name
     * @param ordinal
     */
    TransportType(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link TransportType}; null if no match
     */
    public static TransportType fromName(String name){
        return getValue(
                TransportType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link TransportType}; null if no match
     */
    public static TransportType fromOrdinal(int ordinal){
        return getValue(
                TransportType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
