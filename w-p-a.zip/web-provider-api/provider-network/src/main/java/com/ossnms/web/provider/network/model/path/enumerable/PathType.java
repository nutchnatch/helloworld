package com.ossnms.web.provider.network.model.path.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum PathType {

    PATH                ("Path", 0),
    CALL                ("Call", 1),
    SERVICE             ("Service", 2),
    TUNNEL              ("Tunnel", 3),
    LSP                 ("LSP", 4),
    EXTERNAL_SERVICE    ("ExternalService", 5);

    private final String name;
    private final int ordinal;

    PathType(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public int getOrdinal() {
        return ordinal;
    }

    public String getName() {
        return name;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link PathType}; null if no match
     */
    public static PathType fromName(String name){
        return getValue(
                PathType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link PathType}; null if no match
     */
    public static PathType fromOrdinal(int ordinal){
        return getValue(
                PathType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
