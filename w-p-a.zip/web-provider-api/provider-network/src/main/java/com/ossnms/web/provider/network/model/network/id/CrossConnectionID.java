package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class CrossConnectionID extends BaseEntityID implements EntityID {

    static final String EXCEPTION_MESSAGE_TP_END_A = "CrossConnectionID is invalid since the tpEndA is null.";
    static final String EXCEPTION_MESSAGE_TP_END_Z = "CrossConnectionID is invalid since the tpEndZ is null.";
    static final String EXCEPTION_MESSAGE_NE_ID = "CrossConnectionID is invalid since the neIDs are not the same.";
    private static final long serialVersionUID = 4972320745049421437L;
    private final TerminationPointID tpEndA;
    private final TerminationPointID tpEndZ;
    private TerminationPointID tpEndP;

    public CrossConnectionID(String id,
                             TerminationPointID tpEndA,
                             TerminationPointID tpEndZ) {
        this(id, tpEndA, tpEndZ, null);
    }

    public CrossConnectionID(String id,
                             TerminationPointID tpEndA,
                             TerminationPointID tpEndZ,
                             TerminationPointID tpEndP) {
        super(id);
        if (tpEndA == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_TP_END_A);
        }

        if (tpEndZ == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_TP_END_Z);
        }

        if (!tpEndA.getNeId().equals(tpEndZ.getNeId())) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }
        this.tpEndA = tpEndA;
        this.tpEndZ = tpEndZ;
        this.tpEndP = tpEndP;
    }

    public TerminationPointID getTpEndA() {
        return tpEndA;
    }

    public TerminationPointID getTpEndZ() {
        return tpEndZ;
    }

    public TerminationPointID getTpEndP() {
        return tpEndP;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof CrossConnectionID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        CrossConnectionID that = (CrossConnectionID) o;

        if (!tpEndA.equals(that.tpEndA)) {
            return false;
        }
        if (!tpEndZ.equals(that.tpEndZ)) {
            return false;
        }
        return tpEndP != null ? tpEndP.equals(that.tpEndP) : that.tpEndP == null;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + tpEndA.hashCode();
        result = 31 * result + tpEndZ.hashCode();
        result = 31 * result + (tpEndP != null ? tpEndP.hashCode() : 0);
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private CrossConnectionID(CrossConnectionID.Builder builder) {
        super(builder);
        this.tpEndA = builder.tpEndA;
        this.tpEndZ = builder.tpEndZ;
        this.tpEndP = builder.tpEndP;
    }


    /**
     * Builder class for CrossConnectionIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<CrossConnectionID> implements
            ObjectBuilder<CrossConnectionID> {
        static final String EXCEPTION_MESSAGE_TP_END_A = "Builder is invalid since the tpEndA is null.";
        static final String EXCEPTION_MESSAGE_TP_END_Z = "Builder is invalid since the tpEndZ is null.";
        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neIDs are not the same.";

        private TerminationPointID tpEndA;
        private TerminationPointID tpEndZ;
        private TerminationPointID tpEndP;

        public Builder(String key, TerminationPointID tpEndA, TerminationPointID tpEndZ) {
            super(key);
            this.tpEndA = tpEndA;
            this.tpEndZ = tpEndZ;
        }

        public Builder tpEndP(TerminationPointID tpEndP) {
            this.tpEndP = tpEndP;
            return this;
        }

        public CrossConnectionID build() {
            CrossConnectionID crossConnectionID = new CrossConnectionID(this);

            if (this.tpEndA == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_TP_END_A);
            }

            if (this.tpEndZ == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_TP_END_Z);
            }

            if (!this.tpEndA.getNeId().equals(this.tpEndZ.getNeId())) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            return crossConnectionID;
        }
    }
}
