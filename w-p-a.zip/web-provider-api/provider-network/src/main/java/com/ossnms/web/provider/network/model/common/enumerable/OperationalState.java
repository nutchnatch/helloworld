package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum OperationalState implements BaseEnum {

    NOT_APPLICABLE("notApplicable", 0),
    /**
     * <div>The resource is unable to provide service to its clients and there is some correction required.</div>
     */
    DISABLED("disabled", 1),
    /**
     * <div>The resource is fully operational and available for use.</div>
     */
    ENABLED("enabled", 2),
    PROTECTION_DISTURBED("protectionDisturbed", 3),
    SERVER_DISABLED("serverDisabled", 4),
    SERVER_DISTURBED("serverDisturbed", 5),
    /**
     * <div>The resource is partially operational and available for use, but with some problems.</div>
     */
    DEGRADED("degraded", 6),
    /**
     * <div>The resource has some problem that is external to managed network.</div>
     */
    DISABLED_LOCAL("disabledLocal", 7),
    /**
     * <div>The resource has some problem that is inside the managed network.</div>
     */
    DISABLED_TRANSPORT("disabledTransport", 8),
    /**
     * <div>The resource has some problem that is both inside and outside the managed network.</div>
     */
    DISABLED_LOCAL_TRANSPORT("disabledLocalTransport", 9);


    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    OperationalState(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link OperationalState}; null if no match
     */
    public static OperationalState fromName(String name) {
        return name != null ?
                getValue(
                        OperationalState.values(),
                        candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
                ) : null;
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link OperationalState}; null if no match
     */
    public static OperationalState fromOrdinal(int ordinal) {
        return getValue(
                OperationalState.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
