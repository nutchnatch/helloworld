package com.ossnms.web.provider.network.model.path.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum PathField {

    PATH_TYPE               ("pathType", 0),
    PATH_SUB_TYPE           ("pathSubType", 1),
    NAME                    ("name", 2),
    STATUS                  ("pathStatus", 3),
    ALARM_SEVERITY          ("alarmSeverity", 4),
    OPERATIONAL_STATE       ("operationalState", 5),
    ADMINISTRATIVE_STATE    ("administrativeState", 6),
    ACTUAL_CREATION_STATE   ("actualCreationState", 7),
    REQUIRED_CREATION_STATE ("requiredCreationState", 8),
    MANAGED_STATE           ("managedState", 9),
    TYPE                    ("type", 10),
    A_NODE                  ("aNode", 11),
    Z_NODE                  ("zNode", 12),
    PROTECTION              ("protection", 13),
    BANDWIDTH               ("bandwidth", 14),
    V_LAN_ID                ("vLanId", 15),
    DESCRIPTION             ("description", 16),
    ACTIVE_ROUTE            ("activeRoute", 17),
    ROUTE_STATE             ("routeState", 18),
    CREATED_BY              ("createdBy", 19),
    DIRECTION               ("direction", 20),
    NUMBER_OF_NES           ("numberOfNEs", 21),
    A_PTP_TP                ("aPtpTp", 22),
    Z_PTP_TP                ("zPtpTp", 23),
    TP_CONFIGURATION        ("tpConfiguration", 24),
    LAST_DISABLED_TIME      ("lastDisabledTime", 25),
    LAYER                   ("layer", 26),
    PAYLOAD_CLFI            ("payloadCLFI", 27),
    PROJECT_ID              ("projectId", 28),
    S_VLAN_ID               ("sVlanId", 29),
    TRANSPORT_TYPE          ("transportType", 30),
    CORRELATION_MODE        ("correlationMode", 31),
    ALARM_MASK              ("alarmMask", 32),
    ACKNOWLEDGED_BY         ("acknowledgedBy", 33),
    COMMON_CONTAINER        ("commonContainer", 34),
    OCCUPANCY_AZ            ("occupancyAz", 35),
    OCCUPANCY_ZA            ("occupancyZa", 36),
    SUBSCRIBER_NAME         ("subscriberName", 37),
    SERVICE_NAME            ("serviceName", 38),
    //SERVICE_ID            ("subscriberId", 39),
    //WRITE_PROTECTED       ("writeProtected", 40),
    CONNECTION_CLASS        ("connectionClass", 99);

    private final String name;
    private final int ordinal;

    /**
     *
     * @param name
     * @param ordinal
     */
    PathField(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link PathField}; null if no match
     */
    public static PathField fromName(String name){
        return getValue(
                PathField.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link PathField}; null if no match
     */
    public static PathField fromOrdinal(int ordinal){
        return getValue(
                PathField.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
