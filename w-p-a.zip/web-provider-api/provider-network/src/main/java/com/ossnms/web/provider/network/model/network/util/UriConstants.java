package com.ossnms.web.provider.network.model.network.util;

public abstract class UriConstants {
    static final String CONTAINERS = "/containers";
    static final String SYSTEM_CONTAINERS = "/system-containers";
    static final String NES = "/nes";
    static final String EHS = "/ehs";
    static final String EQS = "/eqs";
    static final String PTPS = "/ptps";
    static final String TPS = "/tps";
    static final String TLS = "/tls";
    static final String IPCS = "/ipcs";
    static final String CCS = "/ccs";
    static final String SNCS = "/sncs";
    static final String BRIDGES = "/bridges";
    static final String VLANS = "/vlans";
    static final String LAGS = "/lags";
    static final String MACS = "/macs";
    static final String AC_TPS = "/actps";
    static final String LSP_TPS = "/lsptps";
    static final String PW_TPS = "/pwtps";
    static final String SW_POINTS = "/swpoints";
    static final String TUNNELS = "/tunnels";
    static final String PAYLOADS = "/payloads";

    public static final String USING_NE = "using-ne";
    public static final String EMBED = "embed";
    // SUB-RESOURCES \\
    public static final String SR_ALARMS_SUMMARY = "alarms-summary";
    // NE
    public static final String SR_NE_GEO_LOCATION = "geo-location";
    public static final String SR_NE_SOFTWARE_VERSION = "software-version";
    // \\
    public static final String CONTAINS_NE = "contains-ne";
    public static final String CONTAINS_SYSTEM_CONTAINER = "contains-system-container";
    public static final String DEPTH = "depth";
    public static final String NODE_DETAIL = "node-detail";
    public static final String NAME = "name";
    public static final String TYPE = "type";
    public static final String ND_FULL = "full";
    public static final String ND_MIN = "minimum";
    public static final String DEPTH_ALL = "all";
    public static final String LAG = "lag";
    public static final String LAG_MEMBER = "lag-member";
    public static final String TEMPLATE = "template";
    public static final String IN_SERVICES = "in-services";
    public static final String BOOLEAN_TRUE = "true";

    public static final String LIMIT = "limit";
    public static final String OFFSET = "offset";

    public static final String HIERARCHY = "/hierarchy";
    public static final String JAXRS_HIERARCHY = HIERARCHY;
    public static final String ALARMS_SUMMARY = "/alarms-summary";
    public static final String JAXRS_ALARMS_SUMMARY = ALARMS_SUMMARY;
    public static final String ENTITY_ALARMS_SUMMARY_FORMAT = "%s" + JAXRS_ALARMS_SUMMARY;

    public static final String JAXRS_CONTAINER_ID = "containerId";
    public static final String JAXRS_SYSTEM_CONTAINER_ID = "systemContainerId";
    public static final String JAXRS_NE_ID = "neId";
    public static final String JAXRS_NEA_ID = "aNeId";
    public static final String JAXRS_NEZ_ID = "zNeId";
    public static final String JAXRS_EH_ID = "ehId";
    public static final String JAXRS_EQ_ID = "eqId";
    public static final String JAXRS_PTP_ID = "ptpId";
    public static final String JAXRS_PTP_A_ID = "aPtpId";
    public static final String JAXRS_PTP_Z_ID = "zPtpId";
    public static final String JAXRS_PTP_P_ID = "pPtpId";
    public static final String JAXRS_TP_ID = "tpId";
    public static final String JAXRS_TP_A_ID = "aTpId";
    public static final String JAXRS_TP_Z_ID = "zTpId";
    public static final String JAXRS_TP_P_ID = "pTpId";
    public static final String JAXRS_SNC_ID = "sncId";
    public static final String JAXRS_SNC_TYPE = "sncType";
    public static final String JAXRS_SUB_SYS_ID = "subsysId";
    public static final String JAXRS_BRIDGE_ID = "bridgeId";
    public static final String JAXRS_LAG_PTP_ID = "lagPtpId";
    public static final String JAXRS_LAG_TP_ID = "lagTpId";
    public static final String JAXRS_AC_TP_ID = "acTpId";
    public static final String JAXRS_LSP_TP_ID = "lspTpId";
    public static final String JAXRS_PW_TP_ID = "pwTpId";
    public static final String JAXRS_SW_POINT_ID = "swPointId";
    public static final String JAXRS_TUNNEL_ID = "tunnelId";
    public static final String JAXRS_PAYLOAD_ID = "payloadId";

    private static final String INT_FORMAT = "/%d";
    private static final String INT_REGEX = "/(\\d+)";

    public static final String CONTAINER_LIST_FORMAT = CONTAINERS;
    public static final String CONTAINER_FORMAT = CONTAINER_LIST_FORMAT + INT_FORMAT;
    public static final String CONTAINER_CONTAINER_LIST_FORMAT = CONTAINER_FORMAT + CONTAINERS;
    public static final String CONTAINER_NE_LIST_FORMAT = CONTAINER_FORMAT + NES;
    public static final String CONTAINER_SYSTEM_CONTAINER_LIST_FORMAT = CONTAINER_FORMAT + SYSTEM_CONTAINERS;
    public static final String CONTAINER_REGEX = CONTAINER_LIST_FORMAT + INT_REGEX;

    private static final String EQUAL = "=";
    private static final String FILTER = "?";
    public static final String CONTAINER_LIST_NE_FORMAT = CONTAINERS + FILTER + CONTAINS_NE + EQUAL + "%d";
    public static final String CONTAINER_LIST_SYSTEM_CONTAINER_FORMAT = CONTAINERS + FILTER +
            CONTAINS_SYSTEM_CONTAINER + EQUAL + "%d";

    public static final String JAXRS_CONTAINER_LIST = CONTAINERS;
    public static final String JAXRS_CONTAINER = JAXRS_CONTAINER_LIST + "/{" + JAXRS_CONTAINER_ID + "}";
    public static final String JAXRS_CONTAINER_CONTAINER_LIST = JAXRS_CONTAINER + CONTAINERS;
    public static final String JAXRS_CONTAINER_NE_LIST = JAXRS_CONTAINER + NES;
    public static final String JAXRS_CONTAINER_SYSTEM_CONTAINER_LIST = JAXRS_CONTAINER + SYSTEM_CONTAINERS;

    public static final String SYSTEM_CONTAINER_LIST_FORMAT = SYSTEM_CONTAINERS;
    public static final String SYSTEM_CONTAINER_FORMAT = SYSTEM_CONTAINER_LIST_FORMAT + INT_FORMAT;
    public static final String SYSTEM_CONTAINER_NE_LIST_FORMAT = SYSTEM_CONTAINER_FORMAT + NES;
    public static final String JAXRS_SYSTEM_CONTAINER_LIST = SYSTEM_CONTAINERS;
    public static final String JAXRS_SYSTEM_CONTAINER = JAXRS_SYSTEM_CONTAINER_LIST + "/{" +
            JAXRS_SYSTEM_CONTAINER_ID + "}";
    public static final String JAXRS_SYSTEM_CONTAINER_NE_LIST = JAXRS_SYSTEM_CONTAINER + NES;
    public static final String SYSTEM_CONTAINER_REGEX = SYSTEM_CONTAINER_LIST_FORMAT + INT_REGEX;

    public static final String NE_LIST_FORMAT = NES;
    public static final String NE_FORMAT = NE_LIST_FORMAT + INT_FORMAT;
    public static final String JAXRS_NE_LIST = NES;
    public static final String JAXRS_NE = JAXRS_NE_LIST + "/{" + JAXRS_NE_ID + "}";
    public static final String NE_REGEX = NE_LIST_FORMAT + INT_REGEX;

    public static final String EH_LIST_FORMAT = NES + INT_FORMAT + EHS;
    public static final String EH_FORMAT = EH_LIST_FORMAT + INT_FORMAT;
    public static final String EH_EH_LIST_FORMAT = EH_FORMAT + EHS;
    public static final String JAXRS_EH_LIST = NES + "/{" + JAXRS_NE_ID + "}" + EHS;
    public static final String JAXRS_EH = JAXRS_EH_LIST + "/{" + JAXRS_EH_ID + "}";
    public static final String JAXRS_EH_EH_LIST = JAXRS_EH + EHS;
    public static final String EH_REGEX = NE_REGEX + EHS + INT_REGEX;

    public static final String NE_EQ_LIST_FORMAT = NES + INT_FORMAT + EQS;
    public static final String EQ_LIST_FORMAT = NES + INT_FORMAT + EHS + INT_FORMAT + EQS;
    public static final String EQ_FORMAT = NES + INT_FORMAT + EQS + INT_FORMAT;
    public static final String EQ_SIMPLE_FORMAT = NES + INT_FORMAT + EQS + INT_FORMAT;
    public static final String EQ_REGEX = NE_REGEX + EQS + INT_REGEX;

    public static final String EQ_EQ_LIST_FORMAT = EQ_FORMAT + EQS;
    public static final String EQ_PTP_LIST_FORMAT = EQ_FORMAT + PTPS;
    public static final String JAXRS_NE_EQ_LIST = NES + "/{" + JAXRS_NE_ID + "}" + EQS;
    public static final String JAXRS_EQ_LIST = NES + "/{" + JAXRS_NE_ID + "}" + EHS + "/{" + JAXRS_EH_ID + "}" + EQS;
    private static final String BRACET_HYPHEN_BRACET = "}-{";
    public static final String JAXRS_BRIDGE_EQ_LIST = NES + "/{" + JAXRS_NE_ID + "}" + BRIDGES + "/{" +
            JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET + JAXRS_BRIDGE_ID + "}" + EQS;
    public static final String JAXRS_BRIDGE_LAG_LIST = NES + "/{" + JAXRS_NE_ID + "}" + BRIDGES + "/{" +
            JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET + JAXRS_BRIDGE_ID + "}" + LAGS;
    public static final String JAXRS_BRIDGE_MAC_LIST = NES + "/{" + JAXRS_NE_ID + "}" + BRIDGES + "/{" +
            JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET + JAXRS_BRIDGE_ID + "}" + MACS;
    public static final String JAXRS_EQ = NES + "/{" + JAXRS_NE_ID + "}" + EQS + "/{" + JAXRS_EQ_ID + "}";
    public static final String JAXRS_EQ_EQ_LIST = JAXRS_EQ + EQS;
    public static final String JAXRS_EQ_PTP_LIST = JAXRS_EQ + PTPS;
    public static final String JAXRS_EQ_PTP = JAXRS_EQ_PTP_LIST + "/{" + JAXRS_PTP_ID + "}";

    public static final String PTP_LIST_FORMAT = NES + INT_FORMAT + PTPS;
    public static final String PTP_FORMAT = PTP_LIST_FORMAT + INT_FORMAT;
    public static final String PTP_TP_LIST_FORMAT = PTP_FORMAT + TPS;
    public static final String PTP_REGEX = NE_REGEX + PTPS + INT_REGEX;

    public static final String JAXRS_PTP_LIST = NES + "/{" + JAXRS_NE_ID + "}" + PTPS;
    public static final String JAXRS_PTP = JAXRS_PTP_LIST + "/{" + JAXRS_PTP_ID + "}";

    public static final String TP_LIST_EQ_FORMAT = EQ_FORMAT + TPS;
    public static final String TP_LIST_FORMAT = NES + INT_FORMAT + PTPS + INT_FORMAT + TPS;
    public static final String TP_FORMAT = TP_LIST_FORMAT + INT_FORMAT;
    public static final String TP_TP_LIST_FORMAT = TP_FORMAT + TPS;
    public static final String LAG_MAC_LIST_FORMAT = TP_FORMAT + MACS;
    public static final String TP_REGEX = PTP_REGEX + TPS + INT_REGEX;

    public static final String JAXRS_TP_LIST = NES + "/{" + JAXRS_NE_ID + "}" + PTPS + "/{" + JAXRS_PTP_ID + "}" + TPS;
    public static final String JAXRS_TP = JAXRS_TP_LIST + "/{" + JAXRS_TP_ID + "}";
    public static final String JAXRS_TP_TP_LIST = JAXRS_TP + TPS;
    public static final String JAXRS_TP_MAC_LIST = JAXRS_TP + MACS;
    public static final String JAXRS_TP_PW_TP_LIST = JAXRS_TP + PW_TPS;
    public static final String JAXRS_TP_SW_POINT_LIST = JAXRS_TP + SW_POINTS;
    public static final String JAXRS_TP_TUNNEL_LIST = JAXRS_TP + TUNNELS;

    public static final String JAXRS_TP_AC_TP_LIST = JAXRS_TP + AC_TPS;
    public static final String JAXRS_AC_TP = JAXRS_NE + AC_TPS + "/{" + JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET +
            JAXRS_AC_TP_ID + "}";
    public static final String TP_AC_TP_LIST_FORMAT = TP_FORMAT + AC_TPS;
    public static final String AC_TP_FORMAT = NE_FORMAT + AC_TPS + "/%d-%d";

    public static final String JAXRS_TP_LSP_TP_LIST = JAXRS_TP + LSP_TPS;
    public static final String JAXRS_LSP_TP = JAXRS_NE + LSP_TPS + "/{" + JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET +
            JAXRS_LSP_TP_ID + "}";
    public static final String TP_LSP_TP_LIST_FORMAT = TP_FORMAT + LSP_TPS;
    public static final String LSP_TP_FORMAT = NE_FORMAT + LSP_TPS + "/%d-%d";

    public static final String JAXRS_PW_TP_LIST = JAXRS_PTP + PW_TPS;
    public static final String JAXRS_PW_TP = JAXRS_NE + PW_TPS + "/{" + JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET +
            JAXRS_PW_TP_ID + "}";
    public static final String TP_PW_TP_LIST_FORMAT = TP_FORMAT + PW_TPS;
    public static final String PW_TP_FORMAT = NE_FORMAT + PW_TPS + "/%d-%d";

    public static final String JAXRS_SW_POINT_LIST = JAXRS_PTP + SW_POINTS;
    public static final String JAXRS_SW_POINT = JAXRS_NE + SW_POINTS + "/{" + JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET +
            JAXRS_SW_POINT_ID + "}";
    public static final String TP_SW_POINT_LIST_FORMAT = TP_FORMAT + SW_POINTS;
    public static final String SW_POINT_FORMAT = NE_FORMAT + SW_POINTS + "/%d-%d";

    public static final String JAXRS_TUNNEL_LIST = JAXRS_PTP + TUNNELS;
    public static final String JAXRS_TUNNEL = JAXRS_NE + TUNNELS + "/{" + JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET +
            JAXRS_TUNNEL_ID + "}";
    public static final String TP_TUNNEL_LIST_FORMAT = TP_FORMAT + TUNNELS;
    public static final String TUNNEL_FORMAT = NE_FORMAT + TUNNELS + "/%d-%d";

    public static final String JAXRS_PAYLOAD_LIST = JAXRS_PTP + PAYLOADS;
    public static final String JAXRS_PAYLOAD = JAXRS_NE + PAYLOADS + "/{" + JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET +
            JAXRS_PAYLOAD_ID + "}";
    public static final String TP_PAYLOAD_LIST_FORMAT = TP_FORMAT + PAYLOADS;
    public static final String PAYLOAD_FORMAT = NE_FORMAT + PAYLOADS + "/%d-%d";

    public static final String JAXRS_EQ_TP_LIST = NES + "/{" + JAXRS_NE_ID + "}" + EQS + "/{" + JAXRS_EQ_ID + "}" + TPS;

    public static final String TL_LIST_BY_PTP_FORMAT = PTP_FORMAT + TLS;
    public static final String TL_LIST_FORMAT = TLS;
    public static final String TL_FORMAT = TL_LIST_FORMAT + "/%d-%d,%d-%d";
    public static final String JAXRS_TL_LIST = TLS;
    public static final String JAXRS_PTP_TL_LIST = JAXRS_PTP + TLS;
    public static final String JAXRS_TL = JAXRS_TL_LIST + "/{" + JAXRS_NEA_ID + BRACET_HYPHEN_BRACET + JAXRS_PTP_A_ID
            + "},{" + JAXRS_NEZ_ID + BRACET_HYPHEN_BRACET + JAXRS_PTP_Z_ID + "}";

    public static final String CC_LIST_FORMAT = NES + INT_FORMAT + CCS;
    public static final String CC_LIST_BY_TP_FORMAT = TP_FORMAT + CCS;

    public static final String VLAN_LIST_BY_TP_FORMAT = TP_FORMAT + VLANS;
    public static final String VLAN_FORMAT = VLAN_LIST_BY_TP_FORMAT + "/%d-%d";

    public static final String CC_FORMAT = CC_LIST_FORMAT + "/%d-%d,%d-%d";
    public static final String CC_WP_FORMAT = CC_LIST_FORMAT + "/%d-%d,%d-%d,%d-%d";
    public static final String JAXRS_CC_LIST = NES + "/{" + JAXRS_NE_ID + "}" + CCS;

    public static final String JAXRS_NE_CC_TP_LIST = JAXRS_TP + CCS;

    public static final String JAXRS_TP_VLAN_LIST = JAXRS_TP + VLANS;

    public static final String JAXRS_CC = JAXRS_CC_LIST + "/{" + JAXRS_PTP_A_ID + BRACET_HYPHEN_BRACET +
            JAXRS_TP_A_ID + "},{" +
            JAXRS_PTP_Z_ID + BRACET_HYPHEN_BRACET + JAXRS_TP_Z_ID + "}";
    public static final String JAXRS_PROTECTION_CC = JAXRS_CC + ",{" + JAXRS_PTP_P_ID + BRACET_HYPHEN_BRACET +
            JAXRS_TP_P_ID + "}";

    public static final String IPC_LIST_FORMAT = NE_FORMAT + IPCS;

    public static final String IPC_LIST_BY_PTP_FORMAT = PTP_FORMAT + IPCS;
    public static final String IPC_FORMAT = IPC_LIST_FORMAT + "/%d,%d";
    public static final String JAXRS_IPC_LIST = JAXRS_NE + IPCS;
    public static final String JAXRS_PTP_IPC_LIST = JAXRS_PTP + IPCS;
    public static final String JAXRS_IPC = JAXRS_IPC_LIST + "/{" + JAXRS_PTP_A_ID + "},{" + JAXRS_PTP_Z_ID + "}";

    public static final String SNC_LIST_FORMAT = SNCS;
    public static final String SNC_FORMAT = SNC_LIST_FORMAT + "/%d-%s";
    public static final String JAXRS_SNC_LIST = SNCS;
    public static final String JAXRS_SNC = JAXRS_SNC_LIST + "/{" + JAXRS_SNC_ID + BRACET_HYPHEN_BRACET +
            JAXRS_SNC_TYPE + "}";

    public static final String BRIDGE_LIST_FORMAT = NES + INT_FORMAT + BRIDGES;
    public static final String BRIDGE_FORMAT = BRIDGE_LIST_FORMAT + "/%d-%d";
    public static final String BRIDGE_EQS_FORMAT = BRIDGE_LIST_FORMAT + "/%d-%d" + EQS;
    public static final String BRIDGE_REGEX = NE_REGEX + BRIDGES + "/(\\d+)-(\\d+)";
    public static final String LAG_LIST_BRIDGE_FORMAT = BRIDGE_FORMAT + LAGS;
    public static final String MAC_LIST_BRIDGE_FORMAT = BRIDGE_FORMAT + MACS;
    public static final String AVAILABLE_MAC_LIST_BRIDGE_FORMAT = BRIDGE_FORMAT + MACS;

    public static final String JAXRS_BRIDGE_LIST = NES + "/{" + JAXRS_NE_ID + "}" + BRIDGES;
    public static final String JAXRS_BRIDGE = JAXRS_BRIDGE_LIST + "/{" + JAXRS_SUB_SYS_ID + BRACET_HYPHEN_BRACET +
            JAXRS_BRIDGE_ID + "}";

    public static final String ALARM_SEVERITIES_COLORS_FORMAT = "/alarm-severities-colors";
    public static final String JAXRS_ALARM_SEVERITIES_COLORS = ALARM_SEVERITIES_COLORS_FORMAT;

}
