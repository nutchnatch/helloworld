package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.LAGModeType;

import java.io.Serializable;

/**
 * Created on 14-09-2016.
 */
public class TpLag implements Serializable {

    private static final long serialVersionUID = -7415115498866888355L;
    private Integer activeMembersThreshold;
    private Integer allowedActiveMembers;
    private Integer currentActiveMembers;
    private Integer allowedStandbyMembers;
    private Integer currentStandbyMembers;
    private LAGModeType lagMode;
    private Integer numberOfMembers;
    private Integer lagId;
    private String systemId;
    private Integer systemPriority;

    private final LagLacp lagLacpRemote;
    private final LacpLocal lacp;

    public LAGModeType getLagMode() {
        return lagMode;
    }

    public Integer getActiveMembersThreshold() {
        return activeMembersThreshold;
    }

    public Integer getAllowedActiveMembers() {
        return allowedActiveMembers;
    }

    public Integer getCurrentActiveMembers() {
        return currentActiveMembers;
    }

    public Integer getAllowedStandbyMembers() {
        return allowedStandbyMembers;
    }

    public Integer getCurrentStandbyMembers() {
        return currentStandbyMembers;
    }

    public Integer getNumberOfMembers() {
        return numberOfMembers;
    }

    public Integer getLagId() {
        return lagId;
    }

    public String getSystemId() {
        return systemId;
    }

    public Integer getSystemPriority() {
        return systemPriority;
    }

    public LagLacp getLagLacpRemote() {
        return lagLacpRemote;
    }

    public LacpLocal getLacp() {
        return lacp;
    }

    /**
     *
     */
    public static class Builder {
        private Integer activeMembersThreshold;
        private Integer allowedActiveMembers;
        private Integer currentActiveMembers;
        private Integer allowedStandbyMembers;
        private Integer currentStandbyMembers;
        private LAGModeType lagMode;
        private Integer numberOfMembers;
        private Integer lagId;
        private String systemId;
        private Integer systemPriority;
        private LagLacp lagLacpRemote;
        private LacpLocal lacp;

        public Builder() {
        }

        public TpLag.Builder activeMembersThreshold(Integer activeMembersThreshold) {
            this.activeMembersThreshold = activeMembersThreshold;
            return this;
        }

        public TpLag.Builder allowedActiveMembers(Integer allowedActiveMembers) {
            this.allowedActiveMembers = allowedActiveMembers;
            return this;
        }

        public TpLag.Builder currentActiveMembers(Integer currentActiveMembers) {
            this.currentActiveMembers = currentActiveMembers;
            return this;
        }

        public TpLag.Builder allowedStandbyMembers(Integer allowedStandbyMembers) {
            this.allowedStandbyMembers = allowedStandbyMembers;
            return this;
        }

        public TpLag.Builder currentStandbyMembers(Integer currentStandbyMembers) {
            this.currentStandbyMembers = currentStandbyMembers;
            return this;
        }

        public TpLag.Builder lagMode(LAGModeType lagMode) {
            this.lagMode = lagMode;
            return this;
        }

        public TpLag.Builder numberOfMembers(Integer numberOfMembers) {
            this.numberOfMembers = numberOfMembers;
            return this;
        }

        public TpLag.Builder lagId(Integer lagId) {
            this.lagId = lagId;
            return this;
        }

        public TpLag.Builder systemId(String systemId) {
            this.systemId = systemId;
            return this;
        }

        public TpLag.Builder systemPriority(Integer systemPriority) {
            this.systemPriority = systemPriority;
            return this;
        }

        public TpLag.Builder lagLacpRemote(LagLacp lagLacpRemote) {
            this.lagLacpRemote = lagLacpRemote;
            return this;
        }

        public TpLag.Builder lacp(LacpLocal lacp) {
            this.lacp = lacp;
            return this;
        }

        /**
         * @return
         */
        public TpLag build() {
            return new TpLag(this);
        }
    }

    /**
     * @param builder
     */
    private TpLag(TpLag.Builder builder) {
        this.activeMembersThreshold = builder.activeMembersThreshold;
        this.allowedActiveMembers = builder.allowedActiveMembers;
        this.currentActiveMembers = builder.currentActiveMembers;
        this.allowedStandbyMembers = builder.allowedStandbyMembers;
        this.currentStandbyMembers = builder.currentStandbyMembers;
        this.lagMode = builder.lagMode;
        this.numberOfMembers = builder.numberOfMembers;
        this.lagId = builder.lagId;
        this.systemId = builder.systemId;
        this.systemPriority = builder.systemPriority;
        this.lagLacpRemote = builder.lagLacpRemote;
        this.lacp = builder.lacp;
    }
}
