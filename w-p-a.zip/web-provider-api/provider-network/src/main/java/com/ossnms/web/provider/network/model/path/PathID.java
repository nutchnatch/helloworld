package com.ossnms.web.provider.network.model.path;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.path.enumerable.PathType;

/**
 *
 */
public final class PathID implements EntityID {
    private static final long serialVersionUID = -1256666346681588927L;

    private final long id;
    private final PathType pathType;

    public long getId() {
        return id;
    }

    public PathType getPathType() {
        return pathType;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<PathID> {
        private long id;
        private PathType pathType;

        public Builder(long id, PathType pathType) {
            this.id = id;
            this.pathType = pathType;
        }

        public PathID build(){
            PathID pathId = new PathID(this);

            if(pathType == null){
                throw new IllegalStateException("Builder is invalid since the pathType is null.");
            }

            return pathId;
        }
    }

    /**
     *
     * @param builder
     */
    private PathID(Builder builder) {
        this.id = builder.id;
        this.pathType = builder.pathType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        PathID pathID = (PathID) o;

        if (getId() != pathID.getId()){
            return false;
        }
        return getPathType() == pathID.getPathType();

    }

    @Override
    public int hashCode() {
        int result = (int) (getId() ^ (getId() >>> 32));
        result = 31 * result + getPathType().hashCode();
        return result;
    }
}
