package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.id.TerminationPointID;

import java.io.Serializable;

/**
 * Created on 14-09-2016.
 */
public class TpLagMember implements Serializable {

    private static final long serialVersionUID = 2991517103815540598L;
    private final TerminationPointID tpLagId;
    private final LacpLocal lacp;
    private final LacpRemote lacpRemote;

    public TerminationPointID getTpLagId() {
        return tpLagId;
    }

    public LacpLocal getLacp() {
        return lacp;
    }

    public LacpRemote getLacpRemote() {
        return lacpRemote;
    }

    /**
     *
     */
    public static class Builder {
        private TerminationPointID tpLagId;
        private LacpLocal lacp;
        private LacpRemote lacpRemote;

        public Builder(TerminationPointID tpLagId) {
            this.tpLagId = tpLagId;
        }

        public TpLagMember.Builder lacp(LacpLocal lacp) {
            this.lacp = lacp;
            return this;
        }

        public TpLagMember.Builder lacpRemote(LacpRemote lacpRemote) {
            this.lacpRemote = lacpRemote;
            return this;
        }

        /**
         * @return
         */
        public TpLagMember build() {
            return new TpLagMember(this);
        }
    }

    /**
     * @param builder
     */
    private TpLagMember(TpLagMember.Builder builder) {
        this.tpLagId = builder.tpLagId;
        this.lacp = builder.lacp;
        this.lacpRemote = builder.lacpRemote;
    }
}
