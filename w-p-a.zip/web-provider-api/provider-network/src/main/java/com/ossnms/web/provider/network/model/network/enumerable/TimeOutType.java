package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created by catarino on 14-09-2016.
 */
public enum TimeOutType implements BaseEnum {
    LONG("long", 0),
    SHORT("short", 1);

    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    TimeOutType(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link TimeOutType}; null if no match
     */
    public static TimeOutType fromName(String name) {
        return getValue(
                TimeOutType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link TimeOutType}; null if no match
     */
    public static TimeOutType fromOrdinal(int ordinal) {
        return getValue(
                TimeOutType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
