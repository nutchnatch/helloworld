package com.ossnms.web.provider.network.model.network;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.AdministrativeStateType;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.SwitchingPointID;

public class SwitchingPoint extends BaseEntity<SwitchingPoint, SwitchingPointID, SwitchingPoint.Builder> {

    private static final long serialVersionUID = -7430063286319538799L;

    private final String serviceType;
    private final AdministrativeStateType adminState;
    private final OperationalState operationalState;

    /**
     * @param builder
     */
    private SwitchingPoint(Builder builder) {
        super(builder);
        this.serviceType = builder.serviceType;
        this.adminState = builder.adminState;
        this.operationalState = builder.operationalState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        SwitchingPoint that = (SwitchingPoint) o;
        return Objects.equals(serviceType, that.serviceType) &&
                adminState == that.adminState &&
                operationalState == that.operationalState;
    }

    public String getServiceType() {
        return serviceType;
    }

    public AdministrativeStateType getAdminState() {
        return adminState;
    }

    public OperationalState getOperationalState() {
        return operationalState;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), serviceType, adminState, operationalState);
    }

    @Override
    public String toString() {
        return "SwitchingPoint{" +
                "serviceType='" + serviceType + '\'' +
                ", adminState=" + adminState +
                ", operationalState=" + operationalState +
                '}';
    }

    public static class Builder extends BaseEntity.Builder<SwitchingPoint, SwitchingPointID, SwitchingPoint.Builder> {
        private String serviceType;
        private AdministrativeStateType adminState;
        private OperationalState operationalState;

        /**
         * @param entityID
         */
        public Builder(SwitchingPointID entityID) {
            super(entityID, EntityType.SWITCH_POINT);
        }

        public Builder serviceType(String serviceType) {
            this.serviceType = serviceType;
            return this;
        }

        public Builder adminState(AdministrativeStateType adminState) {
            this.adminState = adminState;
            return this;
        }

        public Builder operationalState(OperationalState operationalState) {
            this.operationalState = operationalState;
            return this;
        }

        @Override
        public SwitchingPoint build() {
            return new SwitchingPoint(this);
        }
    }
}
