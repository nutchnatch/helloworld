package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.fault.enumerable.FaultCondition;
import com.ossnms.web.provider.network.model.fault.enumerable.TrafficDirection;

import java.util.Date;

/**
 *
 */
public final class Alarm implements Entity<AlarmID> {

    private static final long serialVersionUID = 6118708149905558934L;

    private final AlarmID id;
    private final Date timestamp;
    private final Date raiseTime;
    private final Date acknowledgeTime;
    private final String acknowledgedBy;
    private final TrafficDirection trafficDirection;
    private final AlarmSeverity alarmSeverity;
    private final String alarmClass;
    private final String probableCause;
    private final FaultCondition faultCondition;
    private final String affectedObjectLocation;
    private final String affectedNEName;


    @Override
    public AlarmID getID() {
        return id;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public AlarmSeverity getAlarmSeverity() {
        return alarmSeverity;
    }

    public String getAlarmClass() {
        return alarmClass;
    }

    public String getProbableCause() {
        return probableCause;
    }

    public FaultCondition getFaultCondition() {
        return faultCondition;
    }

    public String getAffectedObjectLocation() {
        return affectedObjectLocation;
    }

    public String getAffectedNEName() {
        return affectedNEName;
    }

    public Date getRaiseTime() {
        return raiseTime;
    }

    public Date getAcknowledgeTime() {
        return acknowledgeTime;
    }

    public String getAcknowledgedBy() {
        return acknowledgedBy;
    }

    public TrafficDirection getTrafficDirection() {
        return trafficDirection;
    }

    /**
     *
     */
    public static class Builder {

        private AlarmID id;
        private Date timestamp;
        private Date raiseTime;
        private Date acknowledgeTime;
        private String acknowledgedBy;
        private TrafficDirection trafficDirection;
        private AlarmSeverity alarmSeverity;
        private String alarmClass;
        private String probableCause;
        private FaultCondition faultCondition;
        private String affectedObjectLocation;
        private String affectedNEName;

        /**
         *
         * @param alarmID
         */
        public Builder(AlarmID alarmID) {
            this.id = alarmID;
        }

        public Builder timestamp(Date timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public Builder alarmSeverity(AlarmSeverity alarmSeverity) {
            this.alarmSeverity = alarmSeverity;
            return this;
        }

        public Builder alarmClass(String alarmClass) {
            this.alarmClass = alarmClass;
            return this;
        }

        public Builder probableCause(String probableCause) {
            this.probableCause = probableCause;
            return this;
        }

        public Builder faultCondition(FaultCondition faultCondition) {
            this.faultCondition = faultCondition;
            return this;
        }

        public Builder affectedObjectLocation(String affectedObjectLocation) {
            this.affectedObjectLocation = affectedObjectLocation;
            return this;
        }

        public Builder affectedNEName(String affectedNEName) {
            this.affectedNEName = affectedNEName;
            return this;
        }

        public Builder setRaiseTime(Date raiseTime) {
            this.raiseTime = raiseTime;
            return this;
        }

        public Builder setAcknowledgeTime(Date acknowledgeTime) {
            this.acknowledgeTime = acknowledgeTime;
            return this;
        }

        public Builder setAcknowledgedBy(String acknowledgedBy) {
            this.acknowledgedBy = acknowledgedBy;
            return this;
        }

        public Builder setTrafficDirection(TrafficDirection trafficDirection) {
            this.trafficDirection = trafficDirection;
            return this;
        }

        /**
         *
         * @return
         */
        public Alarm build(){
            Alarm alarm = new Alarm(this);

            if(alarm.getID() == null){
                throw new IllegalStateException("Builder is invalid, since the alarmID is null");
            }

            return alarm;
        }
    }

    /**
     * @param builder
     */
    private Alarm(Builder builder) {
        this.id = builder.id;
        this.timestamp = builder.timestamp;
        this.alarmSeverity = builder.alarmSeverity;
        this.alarmClass = builder.alarmClass;
        this.probableCause = builder.probableCause;
        this.faultCondition = builder.faultCondition;
        this.affectedObjectLocation = builder.affectedObjectLocation;
        this.affectedNEName = builder.affectedNEName;
        this.raiseTime = builder.raiseTime;
        this.acknowledgeTime = builder.acknowledgeTime;
        this.acknowledgedBy = builder.acknowledgedBy;
        this.trafficDirection = builder.trafficDirection;
    }
}
