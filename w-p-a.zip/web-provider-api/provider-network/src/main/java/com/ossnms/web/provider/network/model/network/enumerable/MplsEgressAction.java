package com.ossnms.web.provider.network.model.network.enumerable;

public enum MplsEgressAction {
    NONE,
    ADD_VLAN,
    MODIFY_VLAN,
    DELETE_VLAN,
    MODIFY_ADD_VLAN;
}
