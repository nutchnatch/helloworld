package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created on 13-09-2016.
 */
public enum FECModeType implements BaseEnum {

    NOFEC("NOFEC", 0),
    FECG709("FECG709", 1),
    SFEC_LEGACY_SUPER("sfecLegacySuper", 2),
    SFEC07_G9751_I7("SFEC07_G9751_I7", 3),
    SFEC10_G9751_I7("SFEC10_G9751_I7", 4),
    SFEC13_G9751_I7("SFEC13_G9751_I7", 5),
    SFEC07_G9751_I4("SFEC07_G9751_I4", 6),
    EFEC15_SDFEC("EFEC15_SDFEC", 7),
    EFEC21_SDHDFEC("EFEC21_SDHDFEC", 8),
    EFEC21_SDHDEFEC7("EFEC21_SDHDEFEC7", 9),
    EFEC1925("EFEC1925", 10),
    VENDOR_SPECIFIC("VENDOR_SPECIFIC", 11),
    EFEC21_SDHDEFEC7_WSSOPT("EFEC21_SDHDEFEC7_WSSOPT", 12),
    EFEC25_SDFEC("EFEC25_SDFEC", 13),
    EFEC15_SDFEC_AC100("EFEC15_SDFEC_AC100", 14),
    EFEC15_SDFEC_REGULAR("EFEC15_SDFEC_REGULAR", 15),
    SFEC067_945D_B("SFEC067_945dB", 16);

    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    FECModeType(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link FECModeType}; null if no match
     */
    public static FECModeType fromName(String name) {
        return getValue(
                FECModeType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link FECModeType}; null if no match
     */
    public static FECModeType fromOrdinal(int ordinal) {
        return getValue(
                FECModeType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
    
}
