package com.ossnms.web.provider.network.model.fault.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 *
 */
public enum FaultCondition implements BaseEnum {

    NEUTRAL                       ("neutral", 0),
    DISABLING_UNPROTECTED_TRAFFIC ("disablingUnprotectedTraffic", 1),
    DISABLING_ALL_TRAFFIC         ("disablingAllTraffic", 2);

    private final String name;
    private final int ordinal;

    FaultCondition(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link FaultCondition}; null if no match
     */
    public static FaultCondition fromName(String name){
        return getValue(
                FaultCondition.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link FaultCondition}; null if no match
     */
    public static FaultCondition fromOrdinal(int ordinal){
        return getValue(
                FaultCondition.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
