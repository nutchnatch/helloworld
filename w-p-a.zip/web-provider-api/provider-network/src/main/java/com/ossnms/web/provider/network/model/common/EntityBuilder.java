package com.ossnms.web.provider.network.model.common;

import java.io.Serializable;

/**
 * Created by catarino on 19-09-2016.
 */
public class EntityBuilder<E extends BaseEntity, B extends BaseEntity.Builder> implements Serializable {

    private static final long serialVersionUID = 6812877824792107812L;
    private E entity;
    private B builder;


    public EntityBuilder(E entity, B builder) {
        this.entity = entity;
        this.builder = builder;
    }

    public E getEntity() {
        return entity;
    }

    public B getBuilder() {
        return builder;
    }

    public void build() {
        entity = (E) builder.build();
    }

    public E buildAndReturnEntity() {
        this.build();
        return entity;
    }
}
