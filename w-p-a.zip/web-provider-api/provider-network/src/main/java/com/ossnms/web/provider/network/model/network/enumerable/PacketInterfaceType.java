package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created on 14-09-2016.
 */
public enum PacketInterfaceType implements BaseEnum {

    NONE("none", 0),
    UNI("uni", 1),
    NNI("nni", 2),
    INNI("inni", 3),
    ENNI("enni", 4);

    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    PacketInterfaceType(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link PacketInterfaceType}; null if no match
     */
    public static PacketInterfaceType fromName(String name) {
        return getValue(
                PacketInterfaceType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link PacketInterfaceType}; null if no match
     */
    public static PacketInterfaceType fromOrdinal(int ordinal) {
        return getValue(
                PacketInterfaceType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
