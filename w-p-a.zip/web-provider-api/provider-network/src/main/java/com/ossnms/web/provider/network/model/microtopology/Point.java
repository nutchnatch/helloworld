package com.ossnms.web.provider.network.model.microtopology;

import java.io.Serializable;

/**
 * Created on 20-09-2016.
 */
public class Point implements Serializable {

    private static final long serialVersionUID = 1546225209113089190L;
    private String entity;
    private String id;
    private String name;
    private String layer;

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLayer() {
        return layer;
    }

    public void setLayer(String layer) {
        this.layer = layer;
    }

}
