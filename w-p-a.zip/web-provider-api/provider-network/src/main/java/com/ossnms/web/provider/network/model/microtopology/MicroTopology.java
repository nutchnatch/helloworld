package com.ossnms.web.provider.network.model.microtopology;

import com.ossnms.web.provider.network.model.common.BaseEntity;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 * Created on 20-09-2016.
 */
public class MicroTopology implements Serializable {

    private static final long serialVersionUID = 6419511074218420675L;
    private String startNode;
    private Collection<BaseEntity> nodes;
    private Collection<Point> points;
    private Collection<Link> links;
    private Collection<SupportGroup> supportGroups;
    private Collection<Path> paths;
    private List<String> layers;

    public String getStartNode() {
        return startNode;
    }

    public void setStartNode(String startNode) {
        this.startNode = startNode;
    }

    public Collection<BaseEntity> getNodes() {
        return nodes;
    }

    public void setNodes(Collection<BaseEntity> nodes) {
        this.nodes = nodes;
    }

    public Collection<Point> getPoints() {
        return points;
    }

    public void setPoints(Collection<Point> points) {
        this.points = points;
    }

    public Collection<Link> getLinks() {
        return links;
    }

    public void setLinks(Collection<Link> links) {
        this.links = links;
    }

    public Collection<SupportGroup> getSupportGroups() {
        return supportGroups;
    }

    public void setSupportGroups(Collection<SupportGroup> supportGroups) {
        this.supportGroups = supportGroups;
    }

    public Collection<Path> getPaths() {
        return paths;
    }

    public void setPaths(Collection<Path> paths) {
        this.paths = paths;
    }

    public List<String> getLayers() {
        return layers;
    }

    public void setLayers(List<String> layers) {
        this.layers = layers;
    }
}
