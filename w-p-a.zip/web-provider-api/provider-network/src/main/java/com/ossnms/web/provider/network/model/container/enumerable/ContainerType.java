package com.ossnms.web.provider.network.model.container.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum ContainerType {

    DEFAULT     ("Default", 0),
    SUBSCRIBER  ("Subscriber", 1),
    SERVICE     ("Service", 2),
    GENERIC     ("Generic", 3);

    private final String name;
    private final int ordinal;

    ContainerType(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link ContainerType}; null if no match
     */
    public static ContainerType fromName(String name){
        return getValue(
                ContainerType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link ContainerType}; null if no match
     */
    public static ContainerType fromOrdinal(int ordinal){
        return getValue(
                ContainerType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
