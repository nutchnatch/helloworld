package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.network.enumerable.VlanType;

/**
 * Created on 09-09-2016.
 */
public class VlanID extends BaseEntityID implements EntityID {

    private static final String EXCEPTION_MESSAGE_TP_END_ID = "VlanID is invalid since the tpEndId is null.";
    private static final String EXCEPTION_MESSAGE_SUBSYS_ID = "VlanID is invalid since the subsysId is null.";
    private static final String EXCEPTION_MESSAGE_NETWORK_SV_LAN = "VlanID is invalid since the networkSVlan is null.";
    private static final String EXCEPTION_MESSAGE_NETWORK_CV_LAN = "VlanID is invalid since the networkCVlan is null.";
    private static final String EXCEPTION_MESSAGE_VLAN_TYPE = "VlanID is invalid since the vlanType is null.";
    private static final long serialVersionUID = 6652126105166678338L;
    private final TerminationPointID tpEndId;
    private final Integer subsysId;
    private final Integer networkSVlan;
    private final Integer networkCVlan;
    private final VlanType vlanType;

    public VlanID(String id,
                  TerminationPointID tpEndId,
                  Integer subsysId,
                  Integer networkSVlan,
                  Integer networkCVlan, VlanType vlanType) {
        super(id);
        if (tpEndId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_TP_END_ID);
        }

        if (subsysId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
        }

        if (networkSVlan == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NETWORK_SV_LAN);
        }

        if (networkCVlan == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NETWORK_CV_LAN);
        }

        if (vlanType == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_VLAN_TYPE);
        }
        this.tpEndId = tpEndId;
        this.subsysId = subsysId;
        this.networkSVlan = networkSVlan;
        this.networkCVlan = networkCVlan;
        this.vlanType = vlanType;
    }

    public TerminationPointID getTpEndId() {
        return tpEndId;
    }

    public Integer getSubsysId() {
        return subsysId;
    }

    public Integer getNetworkSVlan() {
        return networkSVlan;
    }

    public Integer getNetworkCVlan() {
        return networkCVlan;
    }

    public VlanType getVlanType() {
        return vlanType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof VlanID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        VlanID vlanID = (VlanID) o;

        if (!tpEndId.equals(vlanID.tpEndId)) {
            return false;
        }
        if (!subsysId.equals(vlanID.subsysId)) {
            return false;
        }
        if (!networkSVlan.equals(vlanID.networkSVlan)) {
            return false;
        }
        if (!networkCVlan.equals(vlanID.networkCVlan)) {
            return false;
        }
        return vlanType == vlanID.vlanType;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + tpEndId.hashCode();
        result = 31 * result + subsysId.hashCode();
        result = 31 * result + networkSVlan.hashCode();
        result = 31 * result + networkCVlan.hashCode();
        result = 31 * result + vlanType.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private VlanID(VlanID.Builder builder) {
        super(builder);
        this.tpEndId = builder.tpEndId;
        this.subsysId = builder.subsysId;
        this.networkSVlan = builder.networkSVlan;
        this.networkCVlan = builder.networkCVlan;
        this.vlanType = builder.vlanType;
    }

    /**
     * Builder class for VlanIDs
     */
    public static class Builder extends BaseEntityID.Builder<VlanID> implements ObjectBuilder<VlanID> {
        static final String EXCEPTION_MESSAGE_TP_END_ID = "Builder is invalid since the tpEndId is null.";
        static final String EXCEPTION_MESSAGE_SUBSYS_ID = "Builder is invalid since the subsysId is null.";
        static final String EXCEPTION_MESSAGE_NETWORK_SV_LAN = "Builder is invalid since the networkSVlan is null.";
        static final String EXCEPTION_MESSAGE_NETWORK_CV_LAN = "Builder is invalid since the networkCVlan is null.";
        static final String EXCEPTION_MESSAGE_VLAN_TYPE = "Builder is invalid since the vlanType is null.";
        private TerminationPointID tpEndId;
        private Integer subsysId;
        private Integer networkSVlan;
        private Integer networkCVlan;
        private VlanType vlanType;

        public Builder(String key,
                       TerminationPointID tpEndId,
                       Integer subsysId,
                       Integer networkSVlan,
                       Integer networkCVlan,
                       VlanType type) {
            super(key);
            this.tpEndId = tpEndId;
            this.subsysId = subsysId;
            this.networkSVlan = networkSVlan;
            this.networkCVlan = networkCVlan;
            this.vlanType = type;
        }

        public VlanID build() {
            VlanID vlanID = new VlanID(this);

            if (this.tpEndId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_TP_END_ID);
            }

            if (this.subsysId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
            }

            if (this.networkSVlan == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NETWORK_SV_LAN);
            }

            if (this.networkCVlan == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NETWORK_CV_LAN);
            }

            if (this.vlanType == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_VLAN_TYPE);
            }

            return vlanID;
        }
    }
}
