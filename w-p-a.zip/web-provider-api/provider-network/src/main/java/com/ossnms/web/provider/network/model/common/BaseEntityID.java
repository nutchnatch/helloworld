package com.ossnms.web.provider.network.model.common;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

/**
 * Created on 08-09-2016.
 */
public class BaseEntityID implements EntityID {

    private static final long serialVersionUID = -7745025750584936641L;
    private final String id;

    public String getId() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BaseEntityID)) {
            return false;
        }

        BaseEntityID that = (BaseEntityID) o;

        return id != null ? id.equals(that.id) : that.id == null;

    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "BaseEntityID{" +
                "id='" + id + '\'' +
                '}';
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    @Deprecated
    protected BaseEntityID(BaseEntityID.Builder builder) {
        this.id = builder.id;
    }

    /**
     * Protected constructor for classes extending this class.
     *
     * @param id the Id for the object
     */
    public BaseEntityID(String id) {
        this.id = id;
    }



    /**
     * Builder class for BaseEntityIDs
     * {@link Deprecated} use the {@link BaseEntityID} constructor instead.
     */
    @Deprecated
    public static class Builder<ID extends BaseEntityID> implements ObjectBuilder<ID> {
        private String id;

        public Builder(String id) {
            this.id = id;
        }

        public ID build() {
            return (ID) new BaseEntityID(this);
        }
    }

}
