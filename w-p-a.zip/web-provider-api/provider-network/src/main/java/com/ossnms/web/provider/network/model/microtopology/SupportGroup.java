package com.ossnms.web.provider.network.model.microtopology;

import java.io.Serializable;
import java.util.Collection;

/**
 * Created on 20-09-2016.
 */
public class SupportGroup implements Serializable {

    private static final long serialVersionUID = 8482448653240417797L;
    private String id;
    private String parent;
    private Collection<String> points;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public Collection<String> getPoints() {
        return points;
    }

    public void setPoints(Collection<String> points) {
        this.points = points;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SupportGroup that = (SupportGroup) o;

        if (!id.equals(that.id)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

}
