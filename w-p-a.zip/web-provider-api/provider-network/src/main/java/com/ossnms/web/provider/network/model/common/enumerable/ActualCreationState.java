package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum ActualCreationState implements BaseEnum {

    ACTIVE              ("active", 0),
    INACTIVE            ("inactive", 1),
    INCONSISTENT        ("inconsistent", 2),
    INCOMPLETE          ("incomplete", 3),
    PLANNED             ("planned", 4),
    IN_TEST             ("inTest", 5),
    ACTIVATING          ("activating", 6),
    DEACTIVATING        ("deactivating", 7),
    ACTIVATION_FAILED   ("activationFailed", 8),
    DEACTIVATION_FAILED ("deactivationFailed", 9);


    private final String name;
    private final int ordinal;

    /**
     *
     * @param name
     * @param ordinal
     */
    ActualCreationState(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link ActualCreationState}; null if no match
     */
    public static ActualCreationState fromName(String name){
        return getValue(
                ActualCreationState.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link ActualCreationState}; null if no match
     */
    public static ActualCreationState fromOrdinal(int ordinal){
        return getValue(
                ActualCreationState.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
