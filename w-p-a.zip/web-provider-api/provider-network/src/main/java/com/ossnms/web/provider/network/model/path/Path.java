package com.ossnms.web.provider.network.model.path;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.enumerable.ActiveRoute;
import com.ossnms.web.provider.network.model.common.enumerable.ActualCreationState;
import com.ossnms.web.provider.network.model.common.enumerable.AlarmCorrelationMode;
import com.ossnms.web.provider.network.model.common.enumerable.AlarmMask;
import com.ossnms.web.provider.network.model.common.enumerable.ConnectionClass;
import com.ossnms.web.provider.network.model.common.enumerable.ManagedState;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.common.enumerable.RequiredCreationState;
import com.ossnms.web.provider.network.model.common.enumerable.RouteState;
import com.ossnms.web.provider.network.model.common.enumerable.ServiceAdminState;
import com.ossnms.web.provider.network.model.common.enumerable.TransportType;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.network.enumerable.Direction;
import com.ossnms.web.provider.network.model.path.enumerable.PathProtection;
import com.ossnms.web.provider.network.model.path.enumerable.WriteProtectedState;

import java.util.Date;
import java.util.Objects;

/**
 * Specialization of the Entity type for Paths
 */
public final class Path extends PathSummary implements Entity<PathID> {

    private static final long serialVersionUID = -6236596535634440758L;

    private final AlarmSeverity alarmSeverity;
    private final OperationalState operationalState;
    private final ServiceAdminState administrativeState;
    private final ActualCreationState actualCreationState;
    private final RequiredCreationState requiredCreationState;
    private final ManagedState managedState;
    private final String type;
    private final String aNode;
    private final String zNode;
    private final PathProtection protection;
    private final String bandwidth;
    private final String description;
    private final ActiveRoute activeRoute;
    private final ConnectionClass connectionClass;
    private final RouteState routeState;
    private final String createdBy;
    private final Direction direction;
    private final int numberOfNes;
    private final String aPtpTp;
    private final String zPtpTp;
    private final String tpConfiguration;
    private final Date lastDisabledTime;
    private final String layer;
    private final String payloadCLFI;
    private final String projectId;
    private final int sVlanId;
    private final TransportType transportType;
    private final AlarmCorrelationMode correlationMode;
    private final AlarmMask alarmMask;
    private final String acknowledgedBy;
    private final Date acknowledgedTime;
    private final long commonContainerId;
    private final float occupancyAz;
    private final float occupancyZa;
    private final String subscriberName;
    private final String serviceName;
    private final WriteProtectedState writeProtectedState;

    public AlarmSeverity getAlarmSeverity() {
        return alarmSeverity;
    }

    public OperationalState getOperationalState() {
        return operationalState;
    }

    public ServiceAdminState getAdministrativeState() {
        return administrativeState;
    }

    public ActualCreationState getActualCreationState() {
        return actualCreationState;
    }

    public RequiredCreationState getRequiredCreationState() {
        return requiredCreationState;
    }

    public ManagedState getManagedState() {
        return managedState;
    }

    public String getType() {
        return type;
    }

    public String getaNode() {
        return aNode;
    }

    public String getzNode() {
        return zNode;
    }

    public PathProtection getProtection() {
        return protection;
    }

    public String getBandwidth() {
        return bandwidth;
    }

    public String getDescription() {
        return description;
    }

    public ActiveRoute getActiveRoute() {
        return activeRoute;
    }

    public ConnectionClass getConnectionClass() {
        return connectionClass;
    }

    public RouteState getRouteState() {
        return routeState;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Direction getDirection() {
        return direction;
    }

    public int getNumberOfNes() {
        return numberOfNes;
    }

    public String getaPtpTp() {
        return aPtpTp;
    }

    public String getzPtpTp() {
        return zPtpTp;
    }

    public String getTpConfiguration() {
        return tpConfiguration;
    }

    public Date getLastDisabledTime() {
        return lastDisabledTime == null ? null : (Date) lastDisabledTime.clone();
    }

    public String getLayer() {
        return layer;
    }

    public String getPayloadCLFI() {
        return payloadCLFI;
    }

    public String getProjectId() {
        return projectId;
    }

    public int getSVLanId() {
        return sVlanId;
    }

    public TransportType getTransportType() {
        return transportType;
    }

    public AlarmCorrelationMode getCorrelationMode() {
        return correlationMode;
    }

    public AlarmMask getAlarmMask() {
        return alarmMask;
    }

    public String getAcknowledgedBy() {
        return acknowledgedBy;
    }

    public Date getAcknowledgedTime() {
        return acknowledgedTime == null ? null : (Date) acknowledgedTime.clone();
    }

    public long getCommonContainerId() {
        return commonContainerId;
    }

    public float getOccupancyAz() {
        return occupancyAz;
    }

    public float getOccupancyZa() {
        return occupancyZa;
    }

    public String getSubscriberName() {
        return subscriberName;
    }

    public String getServiceName() {
        return serviceName;
    }

    public WriteProtectedState getWriteProtectedState() {
        return writeProtectedState;
    }

    /**
     *
     */
    public static class Builder extends PathSummary.Prototype<Builder> {
        private AlarmSeverity alarmSeverity;
        private OperationalState operationalState;
        private ServiceAdminState administrativeState;
        private ActualCreationState actualCreationState;
        private RequiredCreationState requiredCreationState;
        private ManagedState managedState;
        private String type;
        private String aNode;
        private String zNode;
        private PathProtection protection;
        private String bandwidth;
        private String description;
        private ActiveRoute activeRoute;
        private ConnectionClass connectionClass;
        private RouteState routeState;
        private String createdBy;
        private Direction direction;
        private int numberOfNes;
        private String aPtpTp;
        private String zPtpTp;
        private String tpConfiguration;
        private Date lastDisabledTime;
        private String layer;
        private String payloadCLFI;
        private String projectId;
        private int sVlanId;
        private TransportType transportType;
        private AlarmCorrelationMode correlationMode;
        private AlarmMask alarmMask;
        private String acknowledgedBy;
        private Date acknowledgedTime;
        private long commonContainerId;
        private float occupancyAz;
        private float occupancyZa;
        private String subscriberName;
        private String serviceName;
        private WriteProtectedState writeProtectedState;

        @Override
        protected Builder self() {
            return this;
        }

        public Builder(PathID pathID) {
            super(pathID);
        }


        public Builder alarmSeverity(AlarmSeverity alarmSeverity) {
            this.alarmSeverity = alarmSeverity;
            return this;
        }

        public Builder operationalState(OperationalState operationalState) {
            this.operationalState = operationalState;
            return this;
        }

        public Builder administrativeState(ServiceAdminState administrativeState) {
            this.administrativeState = administrativeState;
            return this;
        }

        public Builder actualCreationState(ActualCreationState actualCreationState) {
            this.actualCreationState = actualCreationState;
            return this;
        }

        public Builder requiredCreationState(RequiredCreationState requiredCreationState) {
            this.requiredCreationState = requiredCreationState;
            return this;
        }

        public Builder managedState(ManagedState managedState) {
            this.managedState = managedState;
            return this;
        }

        public Builder type(String type) {
            this.type = type;
            return this;
        }

        public Builder aNode(String aNode) {
            this.aNode = aNode;
            return this;
        }

        public Builder zNode(String zNode) {
            this.zNode = zNode;
            return this;
        }

        public Builder protection(PathProtection protection) {
            this.protection = protection;
            return this;
        }

        public Builder bandwidth(String bandwidth) {
            this.bandwidth = bandwidth;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder activeRoute(ActiveRoute activeRoute) {
            this.activeRoute = activeRoute;
            return this;
        }

        public Builder connectionClass(ConnectionClass connectionClass) {
            this.connectionClass = connectionClass;
            return this;
        }

        public Builder routeState(RouteState routeState) {
            this.routeState = routeState;
            return this;
        }

        public Builder createdBy(String createdBy) {
            this.createdBy = createdBy;
            return this;
        }

        public Builder direction(Direction direction) {
            this.direction = direction;
            return this;
        }

        public Builder numberOfNes(int numberOfNes) {
            this.numberOfNes = numberOfNes;
            return this;
        }

        public Builder aPtpTp(String aPtpTp) {
            this.aPtpTp = aPtpTp;
            return this;
        }

        public Builder zPtpTp(String zPtpTp) {
            this.zPtpTp = zPtpTp;
            return this;
        }

        public Builder tpConfiguration(String tpConfiguration) {
            this.tpConfiguration = tpConfiguration;
            return this;
        }

        public Builder lastDisabledTime(Date lastDisabledTime) {
            this.lastDisabledTime = lastDisabledTime == null ? null : (Date) lastDisabledTime.clone();
            return this;
        }

        public Builder layer(String layer) {
            this.layer = layer;
            return this;
        }

        public Builder payloadCLFI(String payloadCLFI) {
            this.payloadCLFI = payloadCLFI;
            return this;
        }

        public Builder projectId(String projectId) {
            this.projectId = projectId;
            return this;
        }

        public Builder sVlanId(int sVlanId) {
            this.sVlanId = sVlanId;
            return this;
        }

        public Builder transportType(TransportType transportType) {
            this.transportType = transportType;
            return this;
        }

        public Builder correlationMode(AlarmCorrelationMode correlationMode) {
            this.correlationMode = correlationMode;
            return this;
        }

        public Builder alarmMask(AlarmMask alarmMask) {
            this.alarmMask = alarmMask;
            return this;
        }

        public Builder acknowledgedBy(String acknowledgedBy) {
            this.acknowledgedBy = acknowledgedBy;
            return this;
        }

        public Builder acknowledgedTime(Date acknowledgedTime) {
            this.acknowledgedTime = acknowledgedTime == null ? null : (Date) acknowledgedTime.clone();
            return this;
        }

        public Builder commonContainerId(long commonContainerId) {
            this.commonContainerId = commonContainerId;
            return this;
        }

        public Builder occupancyAz(float occupancyAz) {
            this.occupancyAz = occupancyAz;
            return this;
        }

        public Builder occupancyZa(float occupancyZa) {
            this.occupancyZa = occupancyZa;
            return this;
        }

        public Builder subscriberName(String subscriberName){
            this.subscriberName = subscriberName;
            return this;
        }

        public Builder serviceName(String serviceName){
            this.serviceName = serviceName;
            return this;
        }

        public Builder writeProtectedState(WriteProtectedState writeProtectedState){
            this.writeProtectedState = writeProtectedState;
            return this;
        }

        @Override
        public Path build() {
            if(this.getPathID() == null){
                throw new IllegalStateException("Builder is invalid since the PathID is null");
            }

            return new Path(self());
        }
    }

    /**
     *
     * @param builder
     */
    private Path(Builder builder) {
        super(builder);

        this.alarmSeverity = builder.alarmSeverity;
        this.operationalState = builder.operationalState;
        this.administrativeState = builder.administrativeState;
        this.actualCreationState = builder.actualCreationState;
        this.requiredCreationState = builder.requiredCreationState;
        this.managedState = builder.managedState;
        this.type = builder.type;
        this.aNode = builder.aNode;
        this.zNode = builder.zNode;
        this.protection = builder.protection;
        this.bandwidth = builder.bandwidth;
        this.description = builder.description;
        this.activeRoute = builder.activeRoute;
        this.connectionClass = builder.connectionClass;
        this.routeState = builder.routeState;
        this.createdBy = builder.createdBy;
        this.direction = builder.direction;
        this.numberOfNes = builder.numberOfNes;
        this.aPtpTp = builder.aPtpTp;
        this.zPtpTp = builder.zPtpTp;
        this.tpConfiguration = builder.tpConfiguration;
        this.lastDisabledTime = builder.lastDisabledTime == null ? null : (Date) builder.lastDisabledTime.clone();
        this.layer = builder.layer;
        this.payloadCLFI = builder.payloadCLFI;
        this.projectId = builder.projectId;
        this.sVlanId = builder.sVlanId;
        this.transportType = builder.transportType;
        this.correlationMode = builder.correlationMode;
        this.alarmMask = builder.alarmMask;
        this.acknowledgedBy = builder.acknowledgedBy;
        this.acknowledgedTime = builder.acknowledgedTime == null ? null : (Date) builder.acknowledgedTime.clone();
        this.commonContainerId = builder.commonContainerId;
        this.occupancyAz = builder.occupancyAz;
        this.occupancyZa = builder.occupancyZa;
        this.subscriberName = builder.subscriberName;
        this.serviceName = builder.serviceName;
        this.writeProtectedState = builder.writeProtectedState;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        if (!super.equals(o)){
            return false;
        }
        Path path = (Path) o;
        return getNumberOfNes() == path.getNumberOfNes() &&
                sVlanId == path.sVlanId &&
                getCommonContainerId() == path.getCommonContainerId() &&
                Float.compare(path.getOccupancyAz(), getOccupancyAz()) == 0 &&
                Float.compare(path.getOccupancyZa(), getOccupancyZa()) == 0 &&
                getAlarmSeverity() == path.getAlarmSeverity() &&
                getOperationalState() == path.getOperationalState() &&
                getAdministrativeState() == path.getAdministrativeState() &&
                getActualCreationState() == path.getActualCreationState() &&
                getRequiredCreationState() == path.getRequiredCreationState() &&
                getManagedState() == path.getManagedState() &&
                Objects.equals(getType(), path.getType()) &&
                Objects.equals(getaNode(), path.getaNode()) &&
                Objects.equals(getzNode(), path.getzNode()) &&
                getProtection() == path.getProtection() &&
                Objects.equals(getBandwidth(), path.getBandwidth()) &&
                Objects.equals(getDescription(), path.getDescription()) &&
                getActiveRoute() == path.getActiveRoute() &&
                getConnectionClass() == path.getConnectionClass() &&
                getRouteState() == path.getRouteState() &&
                Objects.equals(getCreatedBy(), path.getCreatedBy()) &&
                getDirection() == path.getDirection() &&
                Objects.equals(getaPtpTp(), path.getaPtpTp()) &&
                Objects.equals(getzPtpTp(), path.getzPtpTp()) &&
                Objects.equals(getTpConfiguration(), path.getTpConfiguration()) &&
                Objects.equals(getLastDisabledTime(), path.getLastDisabledTime()) &&
                Objects.equals(getLayer(), path.getLayer()) &&
                Objects.equals(getPayloadCLFI(), path.getPayloadCLFI()) &&
                Objects.equals(getProjectId(), path.getProjectId()) &&
                getTransportType() == path.getTransportType() &&
                getCorrelationMode() == path.getCorrelationMode() &&
                getAlarmMask() == path.getAlarmMask() &&
                Objects.equals(getAcknowledgedBy(), path.getAcknowledgedBy()) &&
                Objects.equals(getAcknowledgedTime(), path.getAcknowledgedTime()) &&
                Objects.equals(getSubscriberName(), path.getSubscriberName()) &&
                Objects.equals(getWriteProtectedState(), path.getWriteProtectedState()) &&
                Objects.equals(getServiceName(), path.getServiceName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                super.hashCode(),
                getAlarmSeverity(),
                getOperationalState(),
                getAdministrativeState(),
                getActualCreationState(),
                getRequiredCreationState(),
                getManagedState(),
                getType(),
                getaNode(),
                getzNode(),
                getProtection(),
                getBandwidth(),
                getDescription(),
                getActiveRoute(),
                getConnectionClass(),
                getRouteState(),
                getCreatedBy(),
                getDirection(),
                getNumberOfNes(),
                getaPtpTp(),
                getzPtpTp(),
                getTpConfiguration(),
                getLastDisabledTime(),
                getLayer(),
                getPayloadCLFI(),
                getProjectId(),
                sVlanId,
                getTransportType(),
                getCorrelationMode(),
                getAlarmMask(),
                getAcknowledgedBy(),
                getAcknowledgedTime(),
                getCommonContainerId(),
                getOccupancyAz(),
                getOccupancyZa(),
                getSubscriberName(),
                getWriteProtectedState(),
                getServiceName()
        );
    }
}
