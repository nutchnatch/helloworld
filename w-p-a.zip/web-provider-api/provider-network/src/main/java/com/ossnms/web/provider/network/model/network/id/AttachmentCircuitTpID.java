package com.ossnms.web.provider.network.model.network.id;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntityID;

public class AttachmentCircuitTpID extends BaseEntityID {
    private static final long serialVersionUID = -4997366534004798368L;
    private static final String EXCEPTION_MESSAGE_NE_ID = "AttachmentCircuitTpID is invalid since the neId is null.";
    private static final String EXCEPTION_MESSAGE_SUBSYS_ID = "AttachmentCircuitTpID is invalid since the subsysId is null.";
    private static final String EXCEPTION_MESSAGE_TP_ID = "AttachmentCircuitTpID is invalid since the tpId is null.";
    private final Integer neId;
    private final Integer subsysId;
    private final Long tpId;

    public AttachmentCircuitTpID(String id, Integer neId, Integer subsysId, Long tpId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }
        if (subsysId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
        }
        if (tpId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_TP_ID);
        }
        this.neId = neId;
        this.subsysId = subsysId;
        this.tpId = tpId;
    }

    public Integer getNeId() {
        return neId;
    }

    public Integer getSubsysId() {
        return subsysId;
    }

    public Long getTpId() {
        return tpId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        AttachmentCircuitTpID that = (AttachmentCircuitTpID) o;
        return Objects.equals(neId, that.neId) &&
                Objects.equals(subsysId, that.subsysId) &&
                Objects.equals(tpId, that.tpId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), neId, subsysId, tpId);
    }

    @Override
    public String toString() {
        return "AttachmentCircuitTpID{" +
                "neId=" + neId +
                ", subsysId=" + subsysId +
                ", tpId=" + tpId +
                '}';
    }
}
