package com.ossnms.web.provider.network.model.path;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.path.enumerable.PathStatus;

import java.util.Objects;

/**
 *
 */
public class PathSummary implements EntitySummary<PathID> {

    private static final long serialVersionUID = -5093337191920966925L;

    private final PathID pathID;
    private final String pathSubType;
    private final String name;
    private final PathStatus pathStatus;


    public PathID getID() {
        return pathID;
    }

    public String getPathSubType() {
        return pathSubType;
    }

    public String getName() {
        return name;
    }

    public PathStatus getPathStatus() {
        return pathStatus;
    }

    /**
     *
     */
    public static class Builder extends Prototype<Builder> {

        public Builder(PathID pathID) {
            super(pathID);
        }

        @Override
        protected Builder self() {
            return this;
        }

        public PathSummary build() {
            if(this.getPathID() == null){
                throw new IllegalStateException("Builder is invalid since the PathID is null");
            }
            
            return new PathSummary(this);
        }
    }


    /**
     *
     */
    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<PathSummary> {
        private PathID pathID;
        private String pathSubType;
        private String name;
        private PathStatus pathStatus;

        Prototype(PathID pathID) {
            this.pathID = pathID;
        }

        public E pathSubType(String pathSubType) {
            this.pathSubType = pathSubType;
            return self();
        }

        public E name(String name) {
            this.name = name;
            return self();
        }

        public E pathStatus(PathStatus pathStatus) {
            this.pathStatus = pathStatus;
            return self();
        }

        public PathID getPathID() {
            return pathID;
        }

        public String getPathSubType() {
            return pathSubType;
        }

        public String getName() {
            return name;
        }

        public PathStatus getPathStatus() {
            return pathStatus;
        }

        protected abstract E self();
    }

    /**
     *
     * @param builder
     */
    PathSummary(Prototype<?> builder) {
        this.pathID = builder.pathID;
        this.pathSubType = builder.pathSubType;
        this.name = builder.name;
        this.pathStatus = builder.pathStatus;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        PathSummary that = (PathSummary) o;
        return Objects.equals(pathID, that.pathID) &&
                Objects.equals(getPathSubType(), that.getPathSubType()) &&
                Objects.equals(getName(), that.getName()) &&
                getPathStatus() == that.getPathStatus();
    }

    @Override
    public int hashCode() {
        return Objects.hash(pathID, getPathSubType(), getName(), getPathStatus());
    }
}
