package com.ossnms.web.provider.network.model.path.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum PathStatus {

    UNKNOWN                     ("Unknown", 0),
    UNMANAGED                   ("Unmanaged", 1),
    PROCESSING                  ("Processing", 2),
    ATTENTION_REQUIRED          ("AttentionRequired", 3),
    INACTIVE                    ("Inactive", 4),
    NOT_OPERATIONAL_UNPROTECTED ("NotOperationalUnprotected", 5),
    ACTIVE_UNPROTECTED          ("ActiveUnprotected", 6),
    ACTIVE_DEGRADED             ("ActiveDegraded", 7),
    SWITCHED                    ("Switched", 8),
    SWITCH_DEGRADED             ("SwitchDegraded", 9),
    IN_TEST                     ("InTest", 10),
    NOT_OPERATIONAL_PROTECTED   ("NotOperationalProtected", 11),
    ACTIVE_PROTECTED            ("ActiveProtected", 12);

    private final String name;
    private final int ordinal;

    PathStatus(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link PathStatus}; null if no match
     */
    public static PathStatus fromName(String name){
        return getValue(
                PathStatus.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link PathStatus}; null if no match
     */
    public static PathStatus fromOrdinal(int ordinal){
        return getValue(
                PathStatus.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
