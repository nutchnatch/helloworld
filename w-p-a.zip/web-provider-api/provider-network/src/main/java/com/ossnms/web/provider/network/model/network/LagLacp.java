package com.ossnms.web.provider.network.model.network;


import java.io.Serializable;

/**
 * Created on 14-09-2016.
 */
public class LagLacp implements Serializable {

    private static final long serialVersionUID = 1934768751400808620L;
    private final Integer lagId;
    private final String systemId;
    private final Integer systemPriority;

    public Integer getLagId() {
        return lagId;
    }

    public String getSystemId() {
        return systemId;
    }

    public Integer getSystemPriority() {
        return systemPriority;
    }

    /**
     *
     */
    public static class Builder {
        private Integer lagId;
        private String systemId;
        private Integer systemPriority;

        public Builder() {
        }

        public LagLacp.Builder lagId(Integer lagId) {
            this.lagId = lagId;
            return this;
        }

        public LagLacp.Builder systemId(String systemId) {
            this.systemId = systemId;
            return this;
        }

        public LagLacp.Builder systemPriority(Integer systemPriority) {
            this.systemPriority = systemPriority;
            return this;
        }

        /**
         * @return
         */
        public LagLacp build() {
            return new LagLacp(this);
        }
    }

    /**
     * @param builder
     */
    private LagLacp(LagLacp.Builder builder) {
        this.lagId = builder.lagId;
        this.systemId = builder.systemId;
        this.systemPriority = builder.systemPriority;
    }
}
