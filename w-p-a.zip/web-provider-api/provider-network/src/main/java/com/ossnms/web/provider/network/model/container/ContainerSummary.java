package com.ossnms.web.provider.network.model.container;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

/**
 * Container Summary type
 */
public class ContainerSummary implements EntitySummary<ContainerID> {

    private static final long serialVersionUID = 8787035467278525552L;

    private final ContainerID containerID;

    public ContainerID getID() {
        return this.containerID;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<ContainerSummary> {
        private ContainerID containerID;

        public Builder(ContainerID containerID) {
            this.containerID = containerID;
        }

        public ContainerSummary build(){
            ContainerSummary summary = new ContainerSummary(this);

            if(summary.containerID == null){
                throw new IllegalStateException("Builder is in an invalid state, container ID cannot be null");
            }

            return summary;
        }
    }

    /**
     *
     * @param builder
     */
    ContainerSummary(Builder builder) {
        this.containerID = builder.containerID;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        ContainerSummary that = (ContainerSummary) o;

        return containerID.equals(that.containerID);

    }

    @Override
    public int hashCode() {
        return containerID.hashCode();
    }
}
