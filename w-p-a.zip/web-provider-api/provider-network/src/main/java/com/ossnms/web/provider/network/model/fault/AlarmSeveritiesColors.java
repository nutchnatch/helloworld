package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.common.api.model.Color;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;


/**
 * Created on 20-10-2016.
 */
public class AlarmSeveritiesColors extends BaseEntity<AlarmSeveritiesColors, BaseEntityID, AlarmSeveritiesColors
        .Builder> {

    private static final long serialVersionUID = 1683684783158905853L;
    private final AlarmSeverityColor critical;
    private final AlarmSeverityColor indeterminate;
    private final AlarmSeverityColor major;
    private final AlarmSeverityColor minor;
    private final AlarmSeverityColor cleared;
    private final AlarmSeverityColor nonAlarmed;
    private final AlarmSeverityColor notAlarmed;
    private final AlarmSeverityColor notExistent;
    private final AlarmSeverityColor warning;

    public AlarmSeverityColor getCritical() {
        return critical;
    }

    public AlarmSeverityColor getIndeterminate() {
        return indeterminate;
    }

    public AlarmSeverityColor getMajor() {
        return major;
    }

    public AlarmSeverityColor getMinor() {
        return minor;
    }

    public AlarmSeverityColor getCleared() {
        return cleared;
    }

    public AlarmSeverityColor getNonAlarmed() {
        return nonAlarmed;
    }

    public AlarmSeverityColor getNotAlarmed() {
        return notAlarmed;
    }

    public AlarmSeverityColor getNotExistent() {
        return notExistent;
    }

    public AlarmSeverityColor getWarning() {
        return warning;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<AlarmSeveritiesColors, BaseEntityID, AlarmSeveritiesColors.Builder> {
        private AlarmSeverityColor critical;
        private AlarmSeverityColor indeterminate;
        private AlarmSeverityColor major;
        private AlarmSeverityColor minor;
        private AlarmSeverityColor cleared;
        private AlarmSeverityColor nonAlarmed;
        private AlarmSeverityColor notAlarmed;
        private AlarmSeverityColor notExistent;
        private AlarmSeverityColor warning;

        public Builder(BaseEntityID baseEntityID) {
            super(baseEntityID, EntityType.ENTITY);
        }

        public AlarmSeveritiesColors.Builder critical(Color color) {
            this.critical = new AlarmSeverityColor(AlarmSeverity.CRITICAL, color);
            return this;
        }

        public AlarmSeveritiesColors.Builder indeterminate(Color color) {
            this.indeterminate = new AlarmSeverityColor(AlarmSeverity.INDETERMINATE, color);
            return this;
        }

        public AlarmSeveritiesColors.Builder major(Color color) {
            this.major = new AlarmSeverityColor(AlarmSeverity.MAJOR, color);
            return this;
        }

        public AlarmSeveritiesColors.Builder minor(Color color) {
            this.minor = new AlarmSeverityColor(AlarmSeverity.MINOR, color);
            return this;
        }

        public AlarmSeveritiesColors.Builder cleared(Color color) {
            this.cleared = new AlarmSeverityColor(AlarmSeverity.CLEARED, color);
            return this;
        }

        public AlarmSeveritiesColors.Builder nonAlarmed(Color color) {
            this.nonAlarmed = new AlarmSeverityColor(AlarmSeverity.NON_ALARMED, color);
            return this;
        }

        public AlarmSeveritiesColors.Builder notAlarmed(Color color) {
            this.notAlarmed = new AlarmSeverityColor(AlarmSeverity.NOT_ALARMED, color);
            return this;
        }

        public AlarmSeveritiesColors.Builder notExistent(Color color) {
            this.notExistent = new AlarmSeverityColor(AlarmSeverity.NOT_EXISTENT, color);
            return this;
        }

        public AlarmSeveritiesColors.Builder warning(Color color) {
            this.warning = new AlarmSeverityColor(AlarmSeverity.WARNING, color);
            return this;
        }

        /**
         * @return AlarmSeveritiesColors
         */
        public AlarmSeveritiesColors build() {
            return new AlarmSeveritiesColors(this);
        }
    }

    /**
     * @param builder
     */
    private AlarmSeveritiesColors(AlarmSeveritiesColors.Builder builder) {
        super(builder);
        this.critical = builder.critical;
        this.indeterminate = builder.indeterminate;
        this.major = builder.major;
        this.minor = builder.minor;
        this.cleared = builder.cleared;
        this.nonAlarmed = builder.nonAlarmed;
        this.notAlarmed = builder.notAlarmed;
        this.notExistent = builder.notExistent;
        this.warning = builder.warning;
    }

}
