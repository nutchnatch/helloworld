package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class EquipmentID extends BaseEntityID implements EntityID {
    private static final String EXCEPTION_MESSAGE_NE_ID = "EquipmentID is invalid since the neId is null.";
    private static final String EXCEPTION_MESSAGE_EQ_ID = "EquipmentID is invalid since the eqId is null.";
    private static final long serialVersionUID = 1030122130780288125L;
    private final Integer neId;
    private final Integer eqId;

    public EquipmentID(String id, Integer neId, Integer eqId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }

        if (eqId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_EQ_ID);
        }
        this.neId = neId;
        this.eqId = eqId;
    }

    public Integer getNeId() {
        return neId;
    }

    public Integer getEqId() {
        return eqId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {return true;}
        if (!(o instanceof EquipmentID)) {return false;}
        if (!super.equals(o)) {return false;}

        EquipmentID that = (EquipmentID) o;

        if (!neId.equals(that.neId)) {return false;}
        return eqId.equals(that.eqId);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + neId.hashCode();
        result = 31 * result + eqId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private EquipmentID(EquipmentID.Builder builder) {
        super(builder);
        this.neId = builder.neId;
        this.eqId = builder.eqId;
    }


    /**
     * Builder class for EquipmentIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<EquipmentID> implements ObjectBuilder<EquipmentID> {
        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neId is null.";
        static final String EXCEPTION_MESSAGE_EQ_ID = "Builder is invalid since the eqId is null.";

        private Integer neId;
        private Integer eqId;

        public Builder(String key, Integer neId, Integer eqId) {
            super(key);
            this.neId = neId;
            this.eqId = eqId;
        }

        public EquipmentID build() {
            EquipmentID equipmentID = new EquipmentID(this);

            if (this.neId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            if (this.eqId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_EQ_ID);
            }

            return equipmentID;
        }
    }
}
