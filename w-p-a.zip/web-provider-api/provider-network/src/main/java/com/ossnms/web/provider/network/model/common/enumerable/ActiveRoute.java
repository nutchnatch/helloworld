package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.BaseEntity;

/**
 *
 */
public enum ActiveRoute implements BaseEnum {

    WORKING    ("working", 0),
    PROTECTING ("protecting", 1),
    INCOMPLETE ("incomplete", 2);

    private final String name;
    private final int ordinal;

    /**
     *
     * @param name
     * @param ordinal
     */
    ActiveRoute(String name, int ordinal){


        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link ActiveRoute}; null if no match
     */
    public static ActiveRoute fromName(String name){
        return getValue(
                ActiveRoute.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link ActiveRoute}; null if no match
     */
    public static ActiveRoute fromOrdinal(int ordinal){
        return getValue(
                ActiveRoute.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
