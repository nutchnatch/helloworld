package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created on 13-09-2016.
 */
public enum PresenceState implements BaseEnum {

    REQUIRED("required", 0),
    PLANNED("planned", 1),
    AUTO_IN_SERVICE("autoInService", 2);

    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    PresenceState(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link PresenceState}; null if no match
     */
    public static PresenceState fromName(String name) {
        return getValue(
                PresenceState.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link PresenceState}; null if no match
     */
    public static PresenceState fromOrdinal(int ordinal) {
        return getValue(
                PresenceState.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
    
}
