package com.ossnms.web.provider.network.model.common;

import java.util.Objects;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;

/**
 * Created on 08-09-2016.
 */
public class BaseEntity<E extends BaseEntity<E, ID, EB>, ID extends BaseEntityID, EB extends BaseEntity.Builder<E,
        ID, EB>> implements Entity<ID> {

    static final String EXCEPTION_MESSAGE_ID = "Builder is invalid since the ID is null";
    static final String EXCEPTION_MESSAGE_TYPE = "Builder is invalid since the type is null";
    private static final long serialVersionUID = -5030872070586060365L;
    private final String containedObject;
    private ID id;
    private final EntityType type;
    private final String name;
    private final String customLabel;
    private String notificationsChannel;

    /**
     * @param builder
     */
    protected BaseEntity(Builder<E, ID, EB> builder) {
        if (builder.id == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_ID);
        }

        if (builder.type == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_TYPE);
        }
        this.id = builder.id;
        this.containedObject = builder.containedObject;
        this.type = builder.type;
        this.name = builder.name;
        this.customLabel = builder.customLabel;
        this.notificationsChannel = builder.notificationsChannel;
    }

    public String getContainedObject() {
        return containedObject;
    }

    @Override
    public ID getID() {
        return id;
    }

    public void setID(ID id) {
        this.id = id;
    }

    public final EntityType getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public String getCustomLabel() {
        return customLabel;
    }

    public String getNotificationsChannel() {
        return notificationsChannel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BaseEntity<?, ?, ?> that = (BaseEntity<?, ?, ?>) o;
        return Objects.equals(containedObject, that.containedObject) &&
                Objects.equals(id, that.id) &&
                type == that.type &&
                Objects.equals(name, that.name) &&
                Objects.equals(notificationsChannel, that.notificationsChannel) &&
				Objects.equals(customLabel, that.customLabel);
       
    }

    @Override
    public int hashCode() {
        return Objects.hash(containedObject, id, type, name, customLabel, notificationsChannel);
    }

    @Override
    public String toString() {
        return "BaseEntity{" +
                "id=" + id +
                ", type=" + type +
                ", name='" + name + '\'' +
                ", customLabel='" + customLabel + '\'' +
                ", notificationsChannel='" + notificationsChannel + '\'' +
                '}';
    }

    /**
     *
     */
    public static class Builder<E extends BaseEntity<E, ID, EB>, ID extends BaseEntityID, EB extends Builder<E, ID, EB>> {
        private String containedObject;
        private ID id;
        private EntityType type;
        private String name;
        private String notificationsChannel;
        private String customLabel;

        /**
         * @param entityID
         */
        public Builder(ID entityID, EntityType type) {
            this.id = entityID;
            this.type = type;
        }

        public EB containedObject(String containedObject) {
            this.containedObject = containedObject;
            return (EB) this;
        }

        public EB name(String name) {
            this.name = name;
            return (EB) this;
        }

        public EB notificationsChannel(String notificationsChannel) {
            this.notificationsChannel = notificationsChannel;
            return (EB) this;
        }

        public EB customLabel(String customLabel) {
            this.customLabel = customLabel;
            return (EB) this;
        }

        public E build() {
            return (E) new BaseEntity(this);
        }
    }
}
