package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.EquipmentID;

/**
 * Created on 08-09-2016.
 */
public class Equipment extends BaseEntity<Equipment, EquipmentID, Equipment.Builder> implements Entity<EquipmentID> {

    private static final long serialVersionUID = 3009339607396399003L;
    private Integer equipmentHolderId;
    private Integer parentEquipmentId;
    private String actualCardType;
    private String requiredCardType;
    private String direction;
    private String firmwareSoftwareVersion;
    private OperationalState operationalState;
    private String partNumber;
    private String nativeLocation;

    public Integer getEquipmentHolderId() {
        return equipmentHolderId;
    }

    public Integer getParentEquipmentId() {
        return parentEquipmentId;
    }

    public OperationalState getOperationalState() {
        return operationalState;
    }

    public String getDirection() {
        return direction;
    }

    public String getFirmwareSoftwareVersion() {
        return firmwareSoftwareVersion;
    }

    public String getPartNumber() {
        return partNumber;
    }

    public String getActualCardType() {
        return actualCardType;
    }

    public String getRequiredCardType() {
        return requiredCardType;
    }

    public String getNativeLocation() {
        return nativeLocation;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<Equipment, EquipmentID, Equipment.Builder> {
        private Integer equipmentHolderId;
        private Integer parentEquipmentId;
        private String actualCardType;
        private String requiredCardType;
        private String direction;
        private String firmwareSoftwareVersion;
        private OperationalState operationalState;
        private String partNumber;
        private String nativeLocation;

        /**
         * @param equipmentID
         */
        public Builder(EquipmentID equipmentID) {
            super(equipmentID, EntityType.EQUIPMENT);
        }

        public Equipment.Builder equipmentHolderId(Integer equipmentHolderId) {
            this.equipmentHolderId = equipmentHolderId;
            return this;
        }

        public Equipment.Builder parentEquipmentId(Integer parentEquipmentId) {
            this.parentEquipmentId = parentEquipmentId;
            return this;
        }

        public Equipment.Builder actualCardType(String actualCardType) {
            this.actualCardType = actualCardType;
            return this;
        }

        public Equipment.Builder requiredCardType(String requiredCardType) {
            this.requiredCardType = requiredCardType;
            return this;
        }

        public Equipment.Builder direction(String direction) {
            this.direction = direction;
            return this;
        }

        public Equipment.Builder firmwareSoftwareVersion(String firmwareSoftwareVersion) {
            this.firmwareSoftwareVersion = firmwareSoftwareVersion;
            return this;
        }

        public Equipment.Builder operationalState(OperationalState operationalState) {
            this.operationalState = operationalState;
            return this;
        }

        public Equipment.Builder partNumber(String partNumber) {
            this.partNumber = partNumber;
            return this;
        }

        public Equipment.Builder nativeLocation(String nativeLocation) {
            this.nativeLocation = nativeLocation;
            return this;
        }

        public Equipment build() {
            return new Equipment(this);
        }
    }

    /**
     * @param builder
     */
    private Equipment(Equipment.Builder builder) {
        super(builder);
        this.equipmentHolderId = builder.equipmentHolderId;
        this.parentEquipmentId = builder.parentEquipmentId;
        this.actualCardType = builder.actualCardType;
        this.requiredCardType = builder.requiredCardType;
        this.direction = builder.direction;
        this.firmwareSoftwareVersion = builder.firmwareSoftwareVersion;
        this.operationalState = builder.operationalState;
        this.partNumber = builder.partNumber;
        this.nativeLocation = builder.nativeLocation;
    }
}
