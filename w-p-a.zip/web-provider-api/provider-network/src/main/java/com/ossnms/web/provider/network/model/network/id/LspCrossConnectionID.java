package com.ossnms.web.provider.network.model.network.id;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntityID;

public class LspCrossConnectionID extends BaseEntityID {

    private static final String EXCEPTION_MESSAGE_A_TP_ID = "LspCrossConnectionID is invalid since the zTpId is null.";
    private static final String EXCEPTION_MESSAGE_Z_TP_ID = "LspCrossConnectionID is invalid since the aTpId is null.";
    private static final long serialVersionUID = 5197765963968004389L;
    private final LspTpID aTpId;
    private final LspTpID zTpId;

    public LspCrossConnectionID(String id, LspTpID aTpId, LspTpID zTpId) {
        super(id);
        if (aTpId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_A_TP_ID);
        }
        if (zTpId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_Z_TP_ID);
        }
        this.aTpId = aTpId;
        this.zTpId = zTpId;
    }

    public LspTpID getaTpId() {
        return aTpId;
    }

    public LspTpID getzTpId() {
        return zTpId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        LspCrossConnectionID that = (LspCrossConnectionID) o;
        return Objects.equals(aTpId, that.aTpId) &&
                Objects.equals(zTpId, that.zTpId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), aTpId, zTpId);
    }

    @Override
    public String toString() {
        return "LspCrossConnectionID{" +
                "aTpId=" + aTpId +
                ", zTpId=" + zTpId +
                '}';
    }
}
