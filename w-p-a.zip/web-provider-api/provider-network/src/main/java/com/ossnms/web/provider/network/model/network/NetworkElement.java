package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.enumerable.InitStateType;
import com.ossnms.web.provider.network.model.network.enumerable.NeActivationStateType;
import com.ossnms.web.provider.network.model.network.enumerable.NeFamilyType;
import com.ossnms.web.provider.network.model.network.id.NetworkElementID;

/**
 * Created on 08-09-2016.
 */
public class NetworkElement extends BaseEntity<NetworkElement, NetworkElementID, NetworkElement.Builder> implements Entity<NetworkElementID> {

    private static final long serialVersionUID = -6893073167790457851L;
    private Integer systemContainerId;
    private String neType;
    private String communicationState;
    private Boolean isGateway;
    private InitStateType activationState;
    private NeActivationStateType neActivationState;
    private String maintenanceMode;
    private String softwareVersion;
    private NeFamilyType neFamily;
    private String neTypeIcon;
    private Boolean lagManagement;
    private GeoLocation geoLocation;

    public Integer getSystemContainerId() {
        return systemContainerId;
    }

    public String getNeType() {
        return neType;
    }

    public String getCommunicationState() {
        return communicationState;
    }

    public Boolean getIsGateway() {
        return isGateway;
    }

    public InitStateType getActivationState() {
        return activationState;
    }

    public NeActivationStateType getNeActivationState() {
        return neActivationState;
    }

    public String getMaintenanceMode() {
        return maintenanceMode;
    }

    public String getSoftwareVersion() {
        return softwareVersion;
    }

    public NeFamilyType getNeFamily() {
        return neFamily;
    }

    public String getNeTypeIcon() {
        return neTypeIcon;
    }

    public Boolean getLagManagement() {
        return lagManagement;
    }

    public GeoLocation getGeoLocation() {
        return geoLocation;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<NetworkElement, NetworkElementID, NetworkElement.Builder> {

        private Integer systemContainerId;
        private String neType;
        private String communicationState;
        private Boolean isGateway;
        private InitStateType activationState;
        private NeActivationStateType neActivationState;
        private String maintenanceMode;
        private String softwareVersion;
        private NeFamilyType neFamily;
        private String neTypeIcon;
        private Boolean lagManagement;
        private GeoLocation geoLocation;

        /**
         * @param networkElementID
         */
        public Builder(NetworkElementID networkElementID) {
            super(networkElementID, EntityType.NETWORK_ELEMENT);
        }

        public NetworkElement.Builder systemContainerId(Integer systemContainerId) {
            this.systemContainerId = systemContainerId;
            return this;
        }

        public NetworkElement.Builder neType(String neType) {
            this.neType = neType;
            return this;
        }

        public NetworkElement.Builder communicationState(String communicationState) {
            this.communicationState = communicationState;
            return this;
        }

        public NetworkElement.Builder isGateway(Boolean isGateway) {
            this.isGateway = isGateway;
            return this;
        }

        public NetworkElement.Builder activationState(InitStateType activationState) {
            this.activationState = activationState;
            return this;
        }

        public NetworkElement.Builder neActivationState(NeActivationStateType neActivationState) {
            this.neActivationState = neActivationState;
            return this;
        }


        public NetworkElement.Builder maintenanceMode(String maintenanceMode) {
            this.maintenanceMode = maintenanceMode;
            return this;
        }

        public NetworkElement.Builder softwareVersion(String softwareVersion) {
            this.softwareVersion = softwareVersion;
            return this;
        }

        public NetworkElement.Builder neFamily(NeFamilyType neFamily) {
            this.neFamily = neFamily;
            return this;
        }

        public NetworkElement.Builder neTypeIcon(String neTypeIcon) {
            this.neTypeIcon = neTypeIcon;
            return this;
        }

        public NetworkElement.Builder lagManagement(Boolean lagManagement) {
            this.lagManagement = lagManagement;
            return this;
        }

        public NetworkElement.Builder geoLocation(GeoLocation geoLocation) {
            this.geoLocation = geoLocation;
            return this;
        }

        public NetworkElement build() {
            return new NetworkElement(this);
        }
    }

    /**
     * @param builder
     */
    private NetworkElement(NetworkElement.Builder builder) {
        super(builder);
        this.systemContainerId = builder.systemContainerId;
        this.neType = builder.neType;
        this.communicationState = builder.communicationState;
        this.isGateway = builder.isGateway;
        this.activationState = builder.activationState;
        this.neActivationState = builder.neActivationState;
        this.maintenanceMode = builder.maintenanceMode;
        this.softwareVersion = builder.softwareVersion;
        this.neFamily = builder.neFamily;
        this.neTypeIcon = builder.neTypeIcon;
        this.lagManagement = builder.lagManagement;
        this.softwareVersion = builder.softwareVersion;
        this.geoLocation = builder.geoLocation;
    }

}
