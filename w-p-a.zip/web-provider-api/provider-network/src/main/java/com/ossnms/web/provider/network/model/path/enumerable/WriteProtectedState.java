/*
 * Copyright (C) Coriant - 2016
 *
 * The reproduction, transmission or use of this document or its contents is not
 * permitted without express written authorization. All rights, including rights
 * created by patent grant or registration of a utility model or design, are
 * reserved. Modifications made to this document are restricted to authorized
 * personnel only. Technical specifications and features are binding only when
 * specifically and expressly agreed upon in a written contract.
 */

package com.ossnms.web.provider.network.model.path.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum WriteProtectedState {

    NOT_APPLICABLE         ("notApplicable", 0),
    ENABLED                ("Enabled", 1),
    DISABLED               ("Disabled", 2);

    private final String name;
    private final int ordinal;

    WriteProtectedState(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public int getOrdinal() {
        return ordinal;
    }

    public String getName() {
        return name;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link WriteProtectedState}; null if no match
     */
    public static WriteProtectedState fromName(String name){
        return getValue(
                WriteProtectedState.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link WriteProtectedState}; null if no match
     */
    public static WriteProtectedState fromOrdinal(int ordinal){
        return getValue(
                WriteProtectedState.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
