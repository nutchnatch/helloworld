package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.MaintenanceDomainID;

/**
 * Created on 08-09-2016.
 */
public class MaintenanceDomain extends BaseEntity<MaintenanceDomain, MaintenanceDomainID, MaintenanceDomain.Builder> implements Entity<MaintenanceDomainID> {

    private static final long serialVersionUID = 3463101300061384663L;

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<MaintenanceDomain, MaintenanceDomainID, MaintenanceDomain.Builder> {

        /**
         * @param maintenanceDomainID
         */
        public Builder(MaintenanceDomainID maintenanceDomainID) {
            super(maintenanceDomainID, EntityType.MAINTENANCE_DOMAIN);
        }

        public MaintenanceDomain build() {
            return new MaintenanceDomain(this);
        }
    }

    /**
     * @param builder
     */
    private MaintenanceDomain(MaintenanceDomain.Builder builder) {
        super(builder);
    }
}
