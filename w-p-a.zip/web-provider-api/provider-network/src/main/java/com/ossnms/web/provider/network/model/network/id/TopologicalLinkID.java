package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 13-09-2016.
 */
public class TopologicalLinkID extends BaseEntityID implements EntityID {

    static final String EXCEPTION_MESSAGE_PTP_END_A = "TopologicalLinkID is invalid since the ptpEndA is null.";
    static final String EXCEPTION_MESSAGE_PTP_END_Z = "TopologicalLinkID is invalid since the ptpEndZ is null.";
    static final String EXCEPTION_MESSAGE_NE_ID = "TopologicalLinkID is invalid since the neIDs are the same.";
    private static final long serialVersionUID = -6926283183147274881L;
    private final PhysicalTerminationPointID ptpEndA;
    private final PhysicalTerminationPointID ptpEndZ;

    public TopologicalLinkID(String id,
                             PhysicalTerminationPointID ptpEndA,
                             PhysicalTerminationPointID ptpEndZ) {
        super(id);
        if (ptpEndA == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_END_A);
        }

        if (ptpEndZ == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_END_Z);
        }

        if (ptpEndA.getNeId().equals(ptpEndZ.getNeId())) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }
        this.ptpEndA = ptpEndA;
        this.ptpEndZ = ptpEndZ;
    }

    public PhysicalTerminationPointID getPtpEndA() {
        return ptpEndA;
    }

    public PhysicalTerminationPointID getPtpEndZ() {
        return ptpEndZ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TopologicalLinkID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        TopologicalLinkID that = (TopologicalLinkID) o;

        if (!ptpEndA.equals(that.ptpEndA)) {
            return false;
        }
        return ptpEndZ.equals(that.ptpEndZ);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + ptpEndA.hashCode();
        result = 31 * result + ptpEndZ.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private TopologicalLinkID(TopologicalLinkID.Builder builder) {
        super(builder);
        this.ptpEndA = builder.ptpEndA;
        this.ptpEndZ = builder.ptpEndZ;
    }


    /**
     * Builder class for TopologicalLinkIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<TopologicalLinkID> implements
            ObjectBuilder<TopologicalLinkID> {
        static final String EXCEPTION_MESSAGE_PTP_END_A = "Builder is invalid since the ptpEndA is null.";
        static final String EXCEPTION_MESSAGE_PTP_END_Z = "Builder is invalid since the ptpEndZ is null.";
        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neIDs are the same.";

        private PhysicalTerminationPointID ptpEndA;
        private PhysicalTerminationPointID ptpEndZ;

        public Builder(String key, PhysicalTerminationPointID ptpEndA, PhysicalTerminationPointID ptpEndZ) {
            super(key);
            this.ptpEndA = ptpEndA;
            this.ptpEndZ = ptpEndZ;
        }

        public TopologicalLinkID build() {
            TopologicalLinkID topologicalLinkID = new TopologicalLinkID(this);

            if (this.ptpEndA == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_END_A);
            }

            if (this.ptpEndZ == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_END_Z);
            }

            if (this.ptpEndA.getNeId().equals(this.ptpEndZ.getNeId())) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            return topologicalLinkID;
        }
    }
}
