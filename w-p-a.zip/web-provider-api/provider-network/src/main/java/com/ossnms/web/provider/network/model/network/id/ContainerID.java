package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class ContainerID extends BaseEntityID implements EntityID {

    private static final String EXCEPTION_MESSAGE_CONTAINER_ID = "ContainerID is invalid since the containerId is null.";
    private static final long serialVersionUID = 6562581855407145214L;
    private final Integer containerId;

    public ContainerID(String id, Integer containerId) {
        super(id);
        if (containerId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_CONTAINER_ID);
        }
        this.containerId = containerId;
    }

    public Integer getContainerId() {
        return containerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ContainerID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        ContainerID that = (ContainerID) o;

        return containerId.equals(that.containerId);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + containerId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private ContainerID(ContainerID.Builder builder) {
        super(builder);
        this.containerId = builder.containerId;
    }


    /**
     * Builder class for ContainerIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<ContainerID> implements ObjectBuilder<ContainerID> {

        static final String EXCEPTION_MESSAGE_CONTAINER_ID = "Builder is invalid since the containerId is null.";
        private Integer containerId;

        public Builder(String key, Integer id) {
            super(key);
            this.containerId = id;
        }

        public ContainerID build() {
            ContainerID containerID = new ContainerID(this);

            if (this.containerId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_CONTAINER_ID);
            }

            return containerID;
        }
    }

}
