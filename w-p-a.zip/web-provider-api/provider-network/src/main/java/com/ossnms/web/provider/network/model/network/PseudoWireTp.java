package com.ossnms.web.provider.network.model.network;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.AdministrativeStateType;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.PseudoWireTpID;

public class PseudoWireTp extends BaseEntity<PseudoWireTp, PseudoWireTpID, PseudoWireTp.Builder> {
    private static final long serialVersionUID = -1977458731847261374L;

    private final Integer inputLabel;
    private final Integer outputLabel;
    private final String qosId;
    private final String description;
    private final Long tunnelId;
    private final String remoteNodeIdentifier;
    private final AdministrativeStateType adminState;
    private final OperationalState operationalState;

    /**
     * @param builder
     */
    protected PseudoWireTp(Builder builder) {
        super(builder);
        this.inputLabel = builder.inputLabel;
        this.outputLabel = builder.outputLabel;
        this.qosId = builder.qosId;
        this.description = builder.description;
        this.tunnelId = builder.tunnelId;
        this.remoteNodeIdentifier = builder.remoteNodeIdentifier;
        this.adminState = builder.adminState;
        this.operationalState = builder.operationalState;
    }

    public Integer getInputLabel() {
        return inputLabel;
    }

    public Integer getOutputLabel() {
        return outputLabel;
    }

    public String getQosId() {
        return qosId;
    }

    public String getDescription() {
        return description;
    }

    public Long getTunnelId() {
        return tunnelId;
    }

    public String getRemoteNodeIdentifier() {
        return remoteNodeIdentifier;
    }

    public AdministrativeStateType getAdminState() {
        return adminState;
    }

    public OperationalState getOperationalState() {
        return operationalState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        PseudoWireTp that = (PseudoWireTp) o;
        return Objects.equals(inputLabel, that.inputLabel) &&
                Objects.equals(outputLabel, that.outputLabel) &&
                Objects.equals(qosId, that.qosId) &&
                Objects.equals(description, that.description) &&
                Objects.equals(tunnelId, that.tunnelId) &&
                Objects.equals(remoteNodeIdentifier, that.remoteNodeIdentifier) &&
                adminState == that.adminState &&
                operationalState == that.operationalState;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(),
                            inputLabel,
                            outputLabel,
                            qosId,
                            description,
                            tunnelId,
                            remoteNodeIdentifier,
                            adminState,
                            operationalState);
    }

    public static class Builder extends BaseEntity.Builder<PseudoWireTp, PseudoWireTpID, PseudoWireTp.Builder> {
        private Integer inputLabel;
        private Integer outputLabel;
        private String qosId;
        private String description;
        private Long tunnelId;
        private String remoteNodeIdentifier;
        private AdministrativeStateType adminState;
        private OperationalState operationalState;

        /**
         * @param entityID
         */
        public Builder(PseudoWireTpID entityID) {
            super(entityID, EntityType.PSEUDO_WIRE_TP);
        }

        public Builder inputLabel(Integer inputLabel) {
            this.inputLabel = inputLabel;
            return this;
        }

        public Builder outputLabel(Integer outputLabel) {
            this.outputLabel = outputLabel;
            return this;
        }

        public Builder qosId(String qosId) {
            this.qosId = qosId;
            return this;
        }

        public Builder description(String description) {
            this.description = description;
            return this;
        }

        public Builder tunnelId(Long tunnelId) {
            this.tunnelId = tunnelId;
            return this;
        }

        public Builder remoteNodeIdentifier(String remoteNodeIdentifier) {
            this.remoteNodeIdentifier = remoteNodeIdentifier;
            return this;
        }

        public Builder adminState(AdministrativeStateType adminState) {
            this.adminState = adminState;
            return this;
        }

        public Builder operationalState(OperationalState operationalState) {
            this.operationalState = operationalState;
            return this;
        }

        @Override
        public PseudoWireTp build() {
            return new PseudoWireTp(this);
        }
    }
}
