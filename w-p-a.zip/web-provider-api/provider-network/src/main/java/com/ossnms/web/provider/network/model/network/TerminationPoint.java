package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.*;
import com.ossnms.web.provider.network.model.network.id.TerminationPointID;

import java.util.List;

/**
 * Created on 13-09-2016.
 */
public class TerminationPoint extends BaseEntity<TerminationPoint, TerminationPointID, TerminationPoint.Builder> implements Entity<TerminationPointID> {

    private static final long serialVersionUID = -7303461323902870465L;
    private final TerminationModeType terminationMode;
    private final OperationalState operationalState;
    private final List<String> terminatedLayers;
    private final List<String> nonTerminatedLayers;
    private final Long index;
    private final Integer channel;
    private final String objectType;

    private final ResourceUsageType resourceUsageSink;
    private final ResourceUsageType resourceUsageSource;
    private final String trailIdentifierSink;
    private final String trailIdentifierSource;
    private final Boolean fecEnabled;
    private final FECModeType fecMode;
    private final String nativeLocation;
    private final PresenceState presenceState;
    private final AdministrativeStateType administrativeState;
    private final Boolean template;

    private final TpEthernet ethernet;
    private final TpLag lag;
    private final TpLagMember lagMember;

    public TerminationModeType getTerminationMode() {
        return terminationMode;
    }

    public OperationalState getOperationalState() {
        return operationalState;
    }

    public List<String> getTerminatedLayers() {
        return terminatedLayers;
    }

    public List<String> getNonTerminatedLayers() {
        return nonTerminatedLayers;
    }

    public Long getIndex() {
        return index;
    }

    public Integer getChannel() {
        return channel;
    }

    public String getObjectType() {
        return objectType;
    }

    public ResourceUsageType getResourceUsageSink() {
        return resourceUsageSink;
    }

    public ResourceUsageType getResourceUsageSource() {
        return resourceUsageSource;
    }

    public String getTrailIdentifierSink() {
        return trailIdentifierSink;
    }

    public String getTrailIdentifierSource() {
        return trailIdentifierSource;
    }

    public Boolean getFecEnabled() {
        return fecEnabled;
    }

    public FECModeType getFecMode() {
        return fecMode;
    }

    public String getNativeLocation() {
        return nativeLocation;
    }

    public PresenceState getPresenceState() {
        return presenceState;
    }

    public AdministrativeStateType getAdministrativeState() {
        return administrativeState;
    }

    public Boolean getTemplate() {
        return template;
    }

    public TpEthernet getEthernet() {
        return ethernet;
    }

    public TpLag getLag() {
        return lag;
    }

    public TpLagMember getLagMember() {
        return lagMember;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<TerminationPoint, TerminationPointID, TerminationPoint.Builder> {
        private TerminationModeType terminationMode;
        private OperationalState operationalState;
        private List<String> terminatedLayers;
        private List<String> nonTerminatedLayers;
        private Long index;
        private Integer channel;
        private String objectType;
        private ResourceUsageType resourceUsageSink;
        private ResourceUsageType resourceUsageSource;
        private String trailIdentifierSink;
        private String trailIdentifierSource;
        private Boolean fecEnabled;
        private FECModeType fecMode;
        private String nativeLocation;
        private PresenceState presenceState;
        private AdministrativeStateType administrativeState;
        private Boolean template;

        private TpEthernet ethernet;
        private TpLag lag;
        private TpLagMember lagMember;

        /**
         * @param terminationPointID
         */
        public Builder(TerminationPointID terminationPointID) {
            super(terminationPointID, EntityType.TERMINATION_POINT);
        }

        public Builder copy(TerminationPoint terminationPoint) {
            terminationMode = terminationPoint.terminationMode;
            operationalState = terminationPoint.operationalState;
            terminatedLayers = terminationPoint.terminatedLayers;
            nonTerminatedLayers = terminationPoint.nonTerminatedLayers;
            index = terminationPoint.index;
            channel = terminationPoint.channel;
            objectType = terminationPoint.objectType;
            resourceUsageSink = terminationPoint.resourceUsageSink;
            resourceUsageSource = terminationPoint.resourceUsageSource;
            trailIdentifierSink = terminationPoint.trailIdentifierSink;
            trailIdentifierSource = terminationPoint.trailIdentifierSource;
            fecEnabled = terminationPoint.fecEnabled;
            fecMode = terminationPoint.fecMode;
            nativeLocation = terminationPoint.nativeLocation;
            presenceState = terminationPoint.presenceState;
            administrativeState = terminationPoint.administrativeState;
            template = terminationPoint.template;
            ethernet = terminationPoint.ethernet;
            lag = terminationPoint.lag;
            lagMember = terminationPoint.lagMember;
            return this;
        }

        public TerminationPoint.Builder terminationMode(TerminationModeType terminationMode) {
            this.terminationMode = terminationMode;
            return this;
        }

        public TerminationPoint.Builder operationalState(OperationalState operationalState) {
            this.operationalState = operationalState;
            return this;
        }

        public TerminationPoint.Builder terminatedLayers(List<String> terminatedLayers) {
            this.terminatedLayers = terminatedLayers;
            return this;
        }

        public TerminationPoint.Builder nonTerminatedLayers(List<String> nonTerminatedLayers) {
            this.nonTerminatedLayers = nonTerminatedLayers;
            return this;
        }

        public TerminationPoint.Builder index(Long index) {
            this.index = index;
            return this;
        }

        public TerminationPoint.Builder channel(Integer channel) {
            this.channel = channel;
            return this;
        }

        public TerminationPoint.Builder objectType(String objectType) {
            this.objectType = objectType;
            return this;
        }

        public TerminationPoint.Builder resourceUsageSink(ResourceUsageType resourceUsage) {
            this.resourceUsageSink = resourceUsage;
            return this;
        }

        public TerminationPoint.Builder resourceUsageSource(ResourceUsageType resourceUsage) {
            this.resourceUsageSource = resourceUsage;
            return this;
        }

        public TerminationPoint.Builder trailIdentifierSink(String trailIdentifier) {
            this.trailIdentifierSink = trailIdentifier;
            return this;
        }

        public TerminationPoint.Builder trailIdentifierSource(String trailIdentifier) {
            this.trailIdentifierSource = trailIdentifier;
            return this;
        }

        public TerminationPoint.Builder fecEnabled(Boolean fecEnabled) {
            this.fecEnabled = fecEnabled;
            return this;
        }

        public TerminationPoint.Builder fecMode(FECModeType fecMode) {
            this.fecMode = fecMode;
            return this;
        }

        public TerminationPoint.Builder nativeLocation(String nativeLocation) {
            this.nativeLocation = nativeLocation;
            return this;
        }

        public TerminationPoint.Builder presenceState(PresenceState presenceState) {
            this.presenceState = presenceState;
            return this;
        }

        public TerminationPoint.Builder administrativeState(AdministrativeStateType administrativeState) {
            this.administrativeState = administrativeState;
            return this;
        }

        public TerminationPoint.Builder template(Boolean template) {
            this.template = template;
            return this;
        }

        public TerminationPoint.Builder ethernet(TpEthernet ethernet) {
            this.ethernet = ethernet;
            return this;
        }

        public TerminationPoint.Builder lag(TpLag lag) {
            this.lag = lag;
            return this;
        }

        public TerminationPoint.Builder lagMember(TpLagMember lagMember) {
            this.lagMember = lagMember;
            return this;
        }

        public TerminationPoint build() {
            return new TerminationPoint(this);
        }
    }

    /**
     * @param builder
     */
    private TerminationPoint(TerminationPoint.Builder builder) {
        super(builder);
        this.terminationMode = builder.terminationMode;
        this.operationalState = builder.operationalState;
        this.terminatedLayers = builder.terminatedLayers;
        this.nonTerminatedLayers = builder.nonTerminatedLayers;
        this.index = builder.index;
        this.channel = builder.channel;
        this.objectType = builder.objectType;
        this.resourceUsageSink = builder.resourceUsageSink;
        this.resourceUsageSource = builder.resourceUsageSource;
        this.trailIdentifierSink = builder.trailIdentifierSink;
        this.trailIdentifierSource = builder.trailIdentifierSource;
        this.fecEnabled = builder.fecEnabled;
        this.fecMode = builder.fecMode;
        this.nativeLocation = builder.nativeLocation;
        this.presenceState = builder.presenceState;
        this.administrativeState = builder.administrativeState;
        this.template = builder.template;

        this.ethernet = builder.ethernet;
        this.lag = builder.lag;
        this.lagMember = builder.lagMember;
    }
}
