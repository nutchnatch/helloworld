package com.ossnms.web.provider.network.model.container;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerType;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 *
 */
public final class Container extends ContainerSummary implements Entity<ContainerID> {

    private static final long serialVersionUID = 3126034356427463991L;

    private final long parentContainerId;
    private final ContainerType containerType;
    private final String serviceLevel;
    private final Map<ContainerInfo, String> info;
    private final String name;

    public long getParentContainerId() {
        return parentContainerId;
    }

    public ContainerType getContainerType() {
        return containerType;
    }

    public String getName() {
        return name;
    }

    public Map<ContainerInfo, String> getInfo() {
        return info;
    }

    public String getServiceLevel() {
        return serviceLevel;
    }

    /**
     *
     */
    public static class Builder extends ContainerSummary.Builder {
        private long parentContainerId;
        private ContainerType containerType;
        private String name;
        private String serviceLevel;
        private Map<ContainerInfo, String> infoMap;

        /**
         *
         * @param containerID
         */
        public Builder(ContainerID containerID) {
            super(containerID);
            infoMap = new HashMap<>();
        }

        public Builder parentContainerId(long parentContainerId) {
            this.parentContainerId = parentContainerId;
            return this;
        }

        public Builder containerType(ContainerType containerType) {
            this.containerType = containerType;
            return this;
        }

        public Builder putInfo(ContainerInfo info, String value) {
            this.infoMap.put(info, value);
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder serviceLevel(String serviceLevel) {
            this.serviceLevel = serviceLevel;
            return this;
        }

        /**
         *
         * @return
         */
        public Container build(){
            Container container = new Container(this);

            if(container.getID() == null){
                throw new IllegalStateException("Builder is invalid, since the containerID is null");
            }

            return container;
        }
    }

    /**
     * @param builder
     */
    private Container(Builder builder) {
        super(builder);

        this.parentContainerId = builder.parentContainerId;
        this.containerType = builder.containerType;
        this.name = builder.name;
        this.serviceLevel = builder.serviceLevel;
        this.info = builder.infoMap;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        if (!super.equals(o)) { return false; }
        Container container = (Container) o;
        return getParentContainerId() == container.getParentContainerId() &&
                getContainerType() == container.getContainerType() &&
                Objects.equals(getServiceLevel(), container.getServiceLevel()) &&
                Objects.equals(getInfo(), container.getInfo()) &&
                Objects.equals(getName(), container.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getParentContainerId(), getContainerType(), getServiceLevel(), getInfo(), getName());
    }
}
