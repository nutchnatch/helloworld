package com.ossnms.web.provider.network.model.fault.enumerable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public enum TrafficDirection {

    NONE ("none"),
    UNIDIRECTIONAL_IN ("unidirectional_in"),
    UNIDIRECTIONAL_OUT ("unidirectional_out"),
    BIDIRECTIONAL ("bidirectional"),
    UNIDIRECTIONAL_OUT_CLIENT_TO_LINE ("unidirectionalOutClientToLine"),
    UNIDIRECTIONAL_OUT_LINE_TO_CLIENT ("unidirectionalOutLineToClient");

    /**
     *
     */
    private static final Map<String, TrafficDirection> privateSet = new HashMap<>();

    static {
        Arrays.stream(TrafficDirection.values())
                .forEach(trafficDirection -> privateSet.put(trafficDirection.getUiLabel(), trafficDirection));
    }

    private String uiLabel;

    TrafficDirection(String uiLabel) {
        this.uiLabel = uiLabel;
    }

    /**
     *
     */
    public String getUiLabel() {
        return uiLabel;
    }

    /**
     *
     * @param name
     * @return
     */
    public static TrafficDirection fromName(String name) {
        TrafficDirection trafficDirection = privateSet.get(name);
        if(trafficDirection != null) {
            return trafficDirection;
        }

        return NONE;
    }
}
