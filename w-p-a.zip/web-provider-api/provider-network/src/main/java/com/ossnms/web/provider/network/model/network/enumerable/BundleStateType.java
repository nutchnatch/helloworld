package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created on 14-09-2016.
 */
public enum BundleStateType implements BaseEnum {

    UP("up", 0),
    STANDBY("standby", 1),
    DOWN("down", 2);

    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    BundleStateType(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link BundleStateType}; null if no match
     */
    public static BundleStateType fromName(String name) {
        return getValue(
                BundleStateType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link BundleStateType}; null if no match
     */
    public static BundleStateType fromOrdinal(int ordinal) {
        return getValue(
                BundleStateType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
    
}
