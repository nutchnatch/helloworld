package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum RequiredCreationState implements BaseEnum {

    NOT_APPLICABLE  ("notApplicable", 0),
    ACTIVE          ("active", 1),
    INACTIVE        ("inactive", 2),
    IN_DELETION     ("inDeletion", 3),
    DISCOVERED      ("discovered", 4);

    private final String name;
    private final int ordinal;

    /**
     *
     * @param name
     * @param ordinal
     */
    RequiredCreationState(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link RequiredCreationState}; null if no match
     */
    public static RequiredCreationState fromName(String name){
        return getValue(
                RequiredCreationState.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link RequiredCreationState}; null if no match
     */
    public static RequiredCreationState fromOrdinal(int ordinal){
        return getValue(
                RequiredCreationState.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
