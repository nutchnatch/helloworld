package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum ServiceAdminState implements BaseEnum {

    NOT_APPLICABLE  ("notApplicable", 0),
    ENABLED         ("enabled", 1),
    DISABLED        ("disabled", 2);

    private final String name;
    private final int ordinal;

    /**
     * Enum constructor
     *
     * @param name the name of the enum value
     * @param ordinal the ordinal of the enum value
     */
    ServiceAdminState(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link ServiceAdminState}; null if no match
     */
    public static ServiceAdminState fromName(String name){
        return getValue(
                ServiceAdminState.values(),
                serviceAdminState -> serviceAdminState.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link ServiceAdminState}; null if no match
     */
    public static ServiceAdminState fromOrdinal(int ordinal){
        return getValue(
                ServiceAdminState.values(),
                serviceAdminState -> serviceAdminState.getOrdinal() == ordinal
        );
    }
}
