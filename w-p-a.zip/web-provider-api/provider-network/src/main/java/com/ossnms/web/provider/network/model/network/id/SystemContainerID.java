package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class SystemContainerID extends BaseEntityID implements EntityID {

    private static final String EXCEPTION_MESSAGE_SYSTEM_CONTAINER_ID = "SystemContainerID is invalid since the " +
            "systemContainerId is null.";
    private static final long serialVersionUID = 6506057320717892140L;
    private final Integer systemContainerId;

    public SystemContainerID(String id, Integer systemContainerId) {
        super(id);
        if (systemContainerId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_SYSTEM_CONTAINER_ID);
        }
        this.systemContainerId = systemContainerId;
    }

    public Integer getSystemContainerId() {
        return systemContainerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof SystemContainerID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        SystemContainerID that = (SystemContainerID) o;

        return systemContainerId.equals(that.systemContainerId);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + systemContainerId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private SystemContainerID(SystemContainerID.Builder builder) {
        super(builder);
        this.systemContainerId = builder.systemContainerId;
    }


    /**
     * Builder class for SystemContainerIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<SystemContainerID> implements
            ObjectBuilder<SystemContainerID> {
        static final String EXCEPTION_MESSAGE_SYSTEM_CONTAINER_ID = "Builder is invalid since the systemContainerId " +
                "is null.";
        private Integer systemContainerId;

        public Builder(String key, Integer systemContainerId) {
            super(key);
            this.systemContainerId = systemContainerId;
        }

        public SystemContainerID build() {
            SystemContainerID systemContainerID = new SystemContainerID(this);

            if (this.systemContainerId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_SYSTEM_CONTAINER_ID);
            }

            return systemContainerID;
        }
    }
}
