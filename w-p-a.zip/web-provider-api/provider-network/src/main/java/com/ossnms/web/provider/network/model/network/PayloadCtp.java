package com.ossnms.web.provider.network.model.network;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.PayloadCtpID;
import com.ossnms.web.provider.network.model.network.id.PseudoWireTpID;

public class PayloadCtp extends BaseEntity<PayloadCtp, PayloadCtpID, PayloadCtp.Builder> {

    private static final long serialVersionUID = -4227816607453263858L;

    private final PseudoWireTpID pwId;
    private final Integer svlan;
    private final Long spId;

    /**
     * @param builder
     */
    private PayloadCtp(Builder builder) {
        super(builder);
        this.pwId = builder.pwId;
        this.svlan = builder.svlan;
        this.spId = builder.spId;
    }

    public PseudoWireTpID getPwId() {
        return pwId;
    }

    public Integer getSvlan() {
        return svlan;
    }

    public Long getSpId() {
        return spId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        PayloadCtp that = (PayloadCtp) o;
        return Objects.equals(pwId, that.pwId) &&
                Objects.equals(svlan, that.svlan) &&
                Objects.equals(spId, that.spId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), pwId, svlan, spId);
    }

    @Override
    public String toString() {
        return "PayloadCtp{" +
                "pwId=" + pwId +
                ", svlan=" + svlan +
                ", spId=" + spId +
                '}';
    }

    public static class Builder extends BaseEntity.Builder<PayloadCtp, PayloadCtpID, PayloadCtp.Builder> {
        private PseudoWireTpID pwId;
        private Integer svlan;
        private Long spId;

        /**
         * @param entityID
         */
        public Builder(PayloadCtpID entityID) {
            super(entityID, EntityType.PAYLOAD_CTP);
        }

        public Builder pwId(PseudoWireTpID pwId) {
            this.pwId = pwId;
            return this;
        }

        public Builder svlan(Integer svlan) {
            this.svlan = svlan;
            return this;
        }

        public Builder spId(Long spId) {
            this.spId = spId;
            return this;
        }

        @Override
        public PayloadCtp build() {
            return new PayloadCtp(this);
        }
    }
}
