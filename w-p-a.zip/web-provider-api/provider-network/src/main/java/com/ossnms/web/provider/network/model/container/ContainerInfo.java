package com.ossnms.web.provider.network.model.container;

/**
 *
 */
public enum ContainerInfo {

    DESCRIPTION         ("Description"),
    ORGANIZATION        ("Organization"),
    CONTACT_PERSON      ("Contact Person"),
    ADDRESS             ("Address"),
    PHONE               ("Phone"),
    FAX                 ("Fax"),
    EMAIL               ("Email"),
    EXTERNAL_REFERENCE  ("External Reference"),
    URL                 ("URL");

    private String label;

    /**
     *
     * @param label
     */
    private ContainerInfo(String label) {
        this.label = label;
    }

    /**
     * Returns the label
     * @return a String containing the label to be used
     */
    public String getLabel() {
        return label;
    }
}
