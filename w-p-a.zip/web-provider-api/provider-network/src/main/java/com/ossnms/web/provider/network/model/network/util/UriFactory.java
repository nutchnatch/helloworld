package com.ossnms.web.provider.network.model.network.util;

import static com.ossnms.web.provider.network.model.network.util.UriConstants.*;

public class UriFactory {

    public String createContainersUri() {
        return CONTAINER_LIST_FORMAT;
    }

    public String createContainerUri(int containerId) {
        return String.format(CONTAINER_FORMAT, containerId);
    }

    public String createContainersUri(int containerId) {
        return String.format(CONTAINER_CONTAINER_LIST_FORMAT, containerId);
    }

    public String createContainersOfNeUri(Integer neId) {
        return String.format(CONTAINER_LIST_NE_FORMAT, neId);
    }

    public String createSystemContainerUri(int systemContainerId) {
        return String.format(SYSTEM_CONTAINER_FORMAT, systemContainerId);
    }

    public String createContainersOfSystemContainerUri(int systemContainerId) {
        return String.format(CONTAINER_LIST_SYSTEM_CONTAINER_FORMAT, systemContainerId);
    }

    public String createNeUri(int neId) {
        return String.format(NE_FORMAT, neId);
    }

    public String createContainerNesUri() {
        return NE_LIST_FORMAT;
    }

    public String createContainerNesUri(int containerId) {
        return String.format(CONTAINER_NE_LIST_FORMAT, containerId);
    }

    public String createContainerSystemContainersUri(int containerId) {
        return String.format(CONTAINER_SYSTEM_CONTAINER_LIST_FORMAT, containerId);
    }

    public String createSystemContainerNesUri(int containerId) {
        return String.format(SYSTEM_CONTAINER_NE_LIST_FORMAT, containerId);
    }

    public String createEhUri(int neId, int ehId) {
        return String.format(EH_FORMAT, neId, ehId);
    }

    public String createEhsUri(int neId) {
        return String.format(EH_LIST_FORMAT, neId);
    }

    public String createEhsUri(int neId, int ehId) {
        return String.format(EH_EH_LIST_FORMAT, neId, ehId);
    }

    public String createEqTpsUri(Integer neId, Integer eqId) {
        return String.format(TP_LIST_EQ_FORMAT, neId, eqId);
    }

    public String createEqUri(Integer neId, Integer eqId) {
        return String.format(EQ_SIMPLE_FORMAT, neId, eqId);
    }

    public String createEqsUri(int neId, int ehId) {
        return String.format(EQ_LIST_FORMAT, neId, ehId);
    }

    public String createEqsUri(int neId) {
        return String.format(NE_EQ_LIST_FORMAT, neId);
    }

    public String createEqEqsUri(int neId, int eqId) {
        return String.format(EQ_EQ_LIST_FORMAT, neId, eqId);
    }

    public String createPtpUri(int neId, int ptpId) {
        return String.format(PTP_FORMAT, neId, ptpId);
    }

    public String createPtpsUri(int neId, int eqId) {
        return String.format(EQ_PTP_LIST_FORMAT, neId, eqId);
    }

    public String createPtpsUri(int neId) {
        return String.format(PTP_LIST_FORMAT, neId);
    }

    public String createTpUri(int neId, int ptpId, long tpId) {
        return String.format(TP_FORMAT, neId, ptpId, tpId);
    }

    public String createTpsUri(int neId, int ptpId) {
        return String.format(TP_LIST_FORMAT, neId, ptpId);
    }

    public String createTpsUri(int neId, int ptpId, long tpId) {
        return String.format(TP_TP_LIST_FORMAT, neId, ptpId, tpId);
    }

    public String createTlUri(int aEndNeId, int aEndPtpId, int zEndNeId, int zEndPtpId) {
        return String.format(TL_FORMAT, aEndNeId, aEndPtpId, zEndNeId, zEndPtpId);
    }

    public String createTlsUri() {
        return TL_LIST_FORMAT;
    }

    public String createCcUri(int neId, int aEndPtpId, long aEndTpId, int zEndPtpId, long zEndTpId) {
        return String.format(CC_FORMAT, neId, aEndPtpId, aEndTpId, zEndPtpId, zEndTpId);
    }

    public String createCcUri(int neId, int aEndPtpId, long aEndTpId, int zEndPtpId, long zEndTpId, int pEndPtpId, long pEndTpId) {
        return String.format(CC_WP_FORMAT, neId, aEndPtpId, aEndTpId, zEndPtpId, zEndTpId, pEndPtpId, pEndTpId);
    }

    public String createCcsByTpUri(int neId, int ptpId, long tpId) {
        return String.format(CC_LIST_BY_TP_FORMAT, neId, ptpId, tpId);
    }

    public String createCcsUri(int neId) {
        return String.format(CC_LIST_FORMAT, neId);
    }

    public String createSncUri(long id, String type) {
        return String.format(SNC_FORMAT, id, type);
    }

    public String createSncsUri() {
        return SNC_LIST_FORMAT;
    }

    public String createIpcUri(int neId, int aEndPtpId, int zEndPtpId) {
        return String.format(IPC_FORMAT, neId, aEndPtpId, zEndPtpId);
    }

    public String createIpcsByPtpUri(Integer neId, Integer ptpId) {
        return String.format(IPC_LIST_BY_PTP_FORMAT, neId, ptpId);
    }

    public String createIpcsUri(int neId) {
        return String.format(IPC_LIST_FORMAT, neId);
    }

    public String createBridgesUri(int neId) {
        return String.format(BRIDGE_LIST_FORMAT, neId);
    }

    public String createBridgeUri(int neId, int subSysId, int bridgeId) {
        return String.format(BRIDGE_FORMAT, neId, subSysId, bridgeId);
    }

    public String createBridgeEqsUri(int neId, int subSysId, int bridgeId) {
        return String.format(BRIDGE_EQS_FORMAT, neId, subSysId, bridgeId);
    }

    public String createTlsByPtpUri(Integer neId, Integer ptpId) {
        return String.format(TL_LIST_BY_PTP_FORMAT, neId, ptpId);
    }

    public String createVlansUri(int neId, int ptpId, long tpId) {
        return String.format(VLAN_LIST_BY_TP_FORMAT, neId, ptpId, tpId);
    }

    public String createVlanUri(int neId, int ptpId, long tpId, int internalCVlan, int internalSVlan) {
        return String.format(VLAN_FORMAT, neId, ptpId, tpId, internalCVlan, internalSVlan);
    }

    public String createEntityAlarmSummary(String entityUri) {
        return String.format(ENTITY_ALARMS_SUMMARY_FORMAT, entityUri);
    }

    public String createSystemContainersUri() {
        return SYSTEM_CONTAINER_LIST_FORMAT;
    }

    public String createBridgeLAGsUri(Integer neId, Integer subsysId, Integer bridgeId) {
        return String.format(LAG_LIST_BRIDGE_FORMAT, neId, subsysId, bridgeId);
    }

    public String createBridgeMACsUri(Integer neId, Integer subsysId, Integer bridgeId) {
        return String.format(MAC_LIST_BRIDGE_FORMAT, neId, subsysId, bridgeId);
    }

    public String createBridgeAvailableMACsUri(Integer neId, Integer subsysId, Integer bridgeId) {
        return String.format(AVAILABLE_MAC_LIST_BRIDGE_FORMAT, neId, subsysId, bridgeId);
    }

    public String createLagMacsUri(int neId, int ptpId, long tpId) {
        return String.format(LAG_MAC_LIST_FORMAT, neId, ptpId, tpId);
    }

    public String createTpAcTpsUri(int neId, int subsysId, long tpId) {
        return String.format(TP_AC_TP_LIST_FORMAT, neId, subsysId, tpId);
    }

    public String createAcTpUri(int neId, int subsysId, long acTpId) {
        return String.format(AC_TP_FORMAT, neId, subsysId, acTpId);
    }

    public String createTpPayloadCtpsUri(int neId, int subsysId, long tpId) {
        return String.format(TP_PAYLOAD_LIST_FORMAT, neId, subsysId, tpId);
    }

    public String createPayloadCtpUri(int neId, int subsysId, long payloadCtpId) {
        return String.format(PAYLOAD_FORMAT, neId, subsysId, payloadCtpId);
    }

    public String createTpLspTpsUri(int neId, int ptpId, long tpId) {
        return String.format(TP_LSP_TP_LIST_FORMAT, neId, ptpId, tpId);
    }

    public String createLspTpUri(int neId, int subsysId, long lspId) {
        return String.format(LSP_TP_FORMAT, neId, subsysId, lspId);
    }

    public String createTpPwTpsUri(int neId, int ptpId, long tpId) {
        return String.format(TP_PW_TP_LIST_FORMAT, neId, ptpId, tpId);
    }

    public String createPwTpUri(int neId, int subsysId, long pwTpId) {
        return String.format(PW_TP_FORMAT, neId, subsysId, pwTpId);
    }

    public String createTpSwPointsUri(int neId, int ptpId, long tpId) {
        return String.format(TP_SW_POINT_LIST_FORMAT, neId, ptpId, tpId);
    }

    public String createSwPointUri(int neId, int subsysId, long swPointId) {
        return String.format(SW_POINT_FORMAT, neId, subsysId, swPointId);
    }

    public String createTpTunnelsUri(int neId, int ptpId, long tpId) {
        return String.format(TP_TUNNEL_LIST_FORMAT, neId, ptpId, tpId);
    }

    public String createTunnelUri(int neId, int subsysId, long tunnelId) {
        return String.format(TUNNEL_FORMAT, neId, subsysId, tunnelId);
    }

    public String createAlarmSeveritiesColorsUri() {
        return ALARM_SEVERITIES_COLORS_FORMAT;
    }
}
