package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.common.api.model.Color;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;

import java.io.Serializable;

/**
 * Created on 20-10-2016.
 */
public class AlarmSeverityColor implements Serializable {

    private static final long serialVersionUID = -455688778540877983L;
    private final AlarmSeverity alarmSeverity;
    private final Color color;

    public AlarmSeverityColor(AlarmSeverity alarmSeverity, Color color) {
        this.alarmSeverity = alarmSeverity;
        this.color = color;
    }

    public AlarmSeverity getAlarmSeverity() {
        return alarmSeverity;
    }

    public Color getColor() {
        return color;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AlarmSeverityColor)) {
            return false;
        }

        AlarmSeverityColor that = (AlarmSeverityColor) o;

        if (alarmSeverity != that.alarmSeverity) {
            return false;
        }
        return color.equals(that.color);
    }

    @Override
    public int hashCode() {
        int result = alarmSeverity.hashCode();
        result = 31 * result + color.hashCode();
        return result;
    }
}
