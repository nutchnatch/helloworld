package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created on 12-09-2016.
 */
public enum NeFamilyType implements BaseEnum {

    HI_T7100("hiT7100", 0),
    HI_T7300("hiT7300", 1),
    HI_T7500("hiT7500", 2),
    ADVA("ADVA", 3),
    OPTRA("OPTRA", 4),
    MSI("MSI", 5),
    NOT_APPLICABLE("notApplicable", 6),
    JUNIPER("JUNIPER", 7),
    _7100("_7100", 9),
    MTERA("MTERA", 10),
    _7090_M("_7090_M", 11),
    _7090_CE("_7090_CE", 12),
    UNO("UNO", 13),
    OEM("OEM", 14),
    HI_T7550("hiT7550", 15),
    _7100_RAMAN("_7100_Raman", 16),
    GROOVE("Groove", 17),
    SL("SL", 18),
    SLD("SLD", 19),
    SMA("SMA", 20),
    WLS("WLS", 21);

    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    NeFamilyType(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link NeFamilyType}; null if no match
     */
    public static NeFamilyType fromName(String name) {
        return name != null ?
                getValue(
                        NeFamilyType.values(),
                        candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
                ) : null;
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link NeFamilyType}; null if no match
     */
    public static NeFamilyType fromOrdinal(int ordinal) {
        return getValue(
                NeFamilyType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
