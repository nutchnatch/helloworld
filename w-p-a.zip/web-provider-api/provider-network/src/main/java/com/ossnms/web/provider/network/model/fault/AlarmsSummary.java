package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;

/**
 * Created on 13-09-2016.
 */
public class AlarmsSummary extends BaseEntity<AlarmsSummary, AlarmsSummaryID, AlarmsSummary.Builder> {

    private static final long serialVersionUID = -2815654970556140936L;
    private final AlarmSeverity highestAlarmSeverity;
    private final Boolean alarmsAcknowledged;

    public AlarmSeverity getHighestAlarmSeverity() {
        return highestAlarmSeverity;
    }

    public Boolean getAlarmsAcknowledged() {
        return alarmsAcknowledged;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<AlarmsSummary, AlarmsSummaryID, AlarmsSummary.Builder> {
        private AlarmSeverity highestAlarmSeverity;
        private Boolean alarmsAcknowledged;

        /**
         * @param alarmsSummaryID
         */
        public Builder(AlarmsSummaryID alarmsSummaryID) {
            super(alarmsSummaryID, EntityType.ALARMS_SUMMARY);
        }

        public AlarmsSummary.Builder highestAlarmSeverity(AlarmSeverity alarmSeverity) {
            this.highestAlarmSeverity = alarmSeverity;
            return this;
        }

        public AlarmsSummary.Builder alarmsAcknowledged(Boolean alarmsAcknowledged) {
            this.alarmsAcknowledged = alarmsAcknowledged;
            return this;
        }

        /**
         * @return
         */
        public AlarmsSummary build() {
            return new AlarmsSummary(this);
        }
    }

    /**
     * @param builder
     */
    private AlarmsSummary(AlarmsSummary.Builder builder) {
        super(builder);
        this.highestAlarmSeverity = builder.highestAlarmSeverity;
        this.alarmsAcknowledged = builder.alarmsAcknowledged;
    }


}
