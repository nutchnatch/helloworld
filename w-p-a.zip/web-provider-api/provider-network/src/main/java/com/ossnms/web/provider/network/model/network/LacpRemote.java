package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.LACPModeType;
import com.ossnms.web.provider.network.model.network.enumerable.TimeOutType;

import java.io.Serializable;

/**
 * Created on 14-09-2016.
 */
public class LacpRemote implements Serializable {

    private static final long serialVersionUID = -3911931932039800649L;
    private Integer portPriority;
    private LACPModeType lacpMode;
    private TimeOutType timeOut;

    public Integer getPortPriority() {
        return portPriority;
    }

    public void setPortPriority(Integer portPriority) {
        this.portPriority = portPriority;
    }

    public LACPModeType getLacpMode() {
        return lacpMode;
    }

    public void setLacpMode(LACPModeType lacpMode) {
        this.lacpMode = lacpMode;
    }

    public TimeOutType getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(TimeOutType timeOut) {
        this.timeOut = timeOut;
    }

}
