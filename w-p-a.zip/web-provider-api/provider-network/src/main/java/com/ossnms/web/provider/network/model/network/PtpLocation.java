package com.ossnms.web.provider.network.model.network;

import java.io.Serializable;

/**
 * Created on 11-10-2016.
 */
public class PtpLocation implements Serializable {

    private static final long serialVersionUID = 8158721227175905782L;
    private final String rack;
    private final String shelf;
    private final String slot;
    private final String subSlot;
    private final String port;

    public String getRack() {
        return rack;
    }

    public String getShelf() {
        return shelf;
    }

    public String getSlot() {
        return slot;
    }

    public String getSubSlot() {
        return subSlot;
    }

    public String getPort() {
        return port;
    }

    /**
     *
     */
    public static class Builder {
        private String rack;
        private String shelf;
        private String slot;
        private String subSlot;
        private String port;

        public Builder() {
        }

        public PtpLocation.Builder rack(String rack) {
            this.rack = rack;
            return this;
        }

        public PtpLocation.Builder shelf(String shelf) {
            this.shelf = shelf;
            return this;
        }

        public PtpLocation.Builder slot(String slot) {
            this.slot = slot;
            return this;
        }

        public PtpLocation.Builder subSlot(String subSlot) {
            this.subSlot = subSlot;
            return this;
        }

        public PtpLocation.Builder port(String port) {
            this.port = port;
            return this;
        }

        /**
         * @return
         */
        public PtpLocation build() {
            return new PtpLocation(this);
        }
    }

    /**
     * @param builder
     */
    private PtpLocation(PtpLocation.Builder builder) {
        this.rack = builder.rack;
        this.shelf = builder.shelf;
        this.slot = builder.slot;
        this.subSlot = builder.subSlot;
        this.port = builder.port;
    }


}
