package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum ConnectionClass implements BaseEnum {

    /**
     * <div>the endpoints of this connection edge form an illegal combination of termination modes and/or transport layers.</div>
     */
    INCONSISTENT            ("inconsistent", 0),
    /**
     * <div>both endpoints have one or several commom terminated layers.
     In case of several terminated layers these layers form a client/server layer stack.
     The nonterminated layers attribute of this connection contains either the common
     set of nonterminated layers of both endpoints if the uppermost terminated layer of
     both endpoints coincided with the uppermost terminated layer of this connection.
     Otherwise (this connection's terminated layers do not include the uppermost terminated layer of both endpoints)
     the nonterminated layers of this connection consist of the single direct client layer of the connection's
     uppermost terminated layer in both endpoints.
     In any case, the nonterminated layers are not an integral part of this connection,
     but they indicate the set of layers on which this trail provides client connectivity (link connections).</div>
     */
    TRAIL                   ("trail", 1),
    /**
     * <div>there is a single layer which is terminated in one endpoint and not terminated in the other endpoint.
     This layer is contained in the nonterminatedLayers attribute of this connection.
     The terminatedLayers attribute of this connection is an empty list.</div>
     */
    HALF_OPEN_SNC           ("halfOpenSnc", 2),
    /**
     * <div>both endpoints have one or several commom nonterminated layers.
     In case of several nonterminated layers these layers form a layer choice,
     which means that the termination points along this connection edge are
     capable of automatically supporting different signal rates.</div>
     */
    OPEN_SNC                ("openSnc", 3),
    /**
     * <div>union of trail and halfOpenSnc. </div>
     */
    TRAIL_AND_HALF_OPEN_SNC ("trailAndHalfOpenSnc", 4),
    /**
     * <div>union of trail and openSnc. </div>
     */
    TRAIL_AND_OPEN_SNC      ("trailAndOpenSnc", 5),
    /**
     * <div>similar to a 'trail', but differs with respect to the client connectivity (link-connections)
     which is provided by this trail. Several fragment trails provide one group trail (virtual concatenation).</div>
     */
    FRAGMENT_TRAIL          ("fragmentTrail", 6),
    /**
     * <div>similar to a 'halfOpenSnc'. Several fragment half-open SNCs provide one group half-open SNC (virtual concatenation).</div>
     */
    FRAGMENT_HALF_OPEN_SNC  ("fragmentHalfOpenSnc", 7),
    /**
     * <div>similar to an 'openSnc'. Several fragment open SNCs provide one group half-open SNC (virtual concatenation).</div>
     */
    FRAGMENT_OPEN_SNC       ("fragmentOpenSnc", 8);


    private final String name;
    private final int ordinal;

    /**
     *
     * @param name
     * @param ordinal
     */
    ConnectionClass(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link ConnectionClass}; null if no match
     */
    public static ConnectionClass fromName(String name){
        return getValue(
                ConnectionClass.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link ConnectionClass}; null if no match
     */
    public static ConnectionClass fromOrdinal(int ordinal){
        return getValue(
                ConnectionClass.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
