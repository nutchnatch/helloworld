package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class NetworkElementID extends BaseEntityID implements EntityID {

    static final String EXCEPTION_MESSAGE_NE_ID = "NetworkElementID is invalid since the neId is null.";
    private static final long serialVersionUID = -6853841261729063456L;
    private final Integer neId;

    public NetworkElementID(String id, Integer neId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }
        this.neId = neId;
    }

    public Integer getNeId() {
        return neId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof NetworkElementID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        NetworkElementID that = (NetworkElementID) o;

        return neId.equals(that.neId);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + neId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private NetworkElementID(NetworkElementID.Builder builder) {
        super(builder);
        this.neId = builder.neId;
    }


    /**
     * Builder class for NetworkElementIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<NetworkElementID> implements ObjectBuilder<NetworkElementID> {

        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neId is null.";
        private Integer neId;

        public Builder(String key, Integer id) {
            super(key);
            this.neId = id;
        }

        public NetworkElementID build() {
            NetworkElementID networkElementID = new NetworkElementID(this);

            if (this.neId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            return networkElementID;
        }
    }

}
