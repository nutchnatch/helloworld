package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 * 
 */
public enum AlarmMask implements BaseEnum {

    NOT_APPLICABLE                         ("notApplicable", 0),
    ALL_PRIMARY                            ("allPrimary", 1),
    ALL_PRIMARY_AND_SECONDARY_AT_ENDPOINTS ("allPrimaryAndSecondaryAtEndpoints", 2),
    DISABLE_ALL                            ("disableAll", 3),
    NO_MASK                                ("noMask", 4);

    private final String name;
    private final int ordinal;

    /**
     *
     * @param name
     * @param ordinal
     */
    AlarmMask(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link AlarmMask}; null if no match
     */
    public static AlarmMask fromName(String name){
        return getValue(
                AlarmMask.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link AlarmMask}; null if no match
     */
    public static AlarmMask fromOrdinal(int ordinal){
        return getValue(
                AlarmMask.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
