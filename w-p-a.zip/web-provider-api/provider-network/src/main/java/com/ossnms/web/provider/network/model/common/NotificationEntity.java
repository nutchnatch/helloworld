package com.ossnms.web.provider.network.model.common;

import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationType;

import java.io.Serializable;

/**
 * Created on 16-09-2016.
 */
public class NotificationEntity implements Serializable {

    private static final long serialVersionUID = 6207004089695284134L;
    private final BaseEntity entity;
    private final NotificationType notificationType;
    private final NotificationChannel channel;

    /**
     * Entity being notified.
     *
     * @return BaseEntity.
     */
    public BaseEntity getEntity() {
        return entity;
    }

    /**
     * Type of notification.
     *
     * @return Type of notification.
     */
    public NotificationType getNotificationType() {
        return notificationType;
    }

    public NotificationChannel getChannel() {
        return channel;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof NotificationEntity)) {
            return false;
        }

        NotificationEntity that = (NotificationEntity) o;

        if (!entity.equals(that.entity)) {
            return false;
        }
        if (notificationType != that.notificationType) {
            return false;
        }
        return channel.equals(that.channel);

    }

    @Override
    public int hashCode() {
        int result = entity.hashCode();
        result = 31 * result + notificationType.hashCode();
        result = 31 * result + channel.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "NotificationNode{" +
                "entity=" + entity +
                ", notificationType=" + notificationType +
                ", channel='" + channel + '\'' +
                '}';
    }

    /**
     *
     */
    public static class Builder {
        static final String EXCEPTION_MESSAGE_ENTITY = "Builder is invalid since the entity is null";
        static final String EXCEPTION_MESSAGE_TYPE = "Builder is invalid since the type is null";
        static final String EXCEPTION_MESSAGE_CHANNEL = "Builder is invalid since the channel is null";

        private BaseEntity entity;
        private NotificationType notificationType;
        private NotificationChannel channel;

        /**
         * @param entity,
         */
        public Builder(BaseEntity entity, NotificationType type, NotificationChannel channel) {
            this.entity = entity;
            this.notificationType = type;
            this.channel = channel;
        }

        /**
         * @return
         */
        public NotificationEntity build() {
            NotificationEntity notificationEntity = new NotificationEntity(this);

            if (notificationEntity.getEntity() == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_ENTITY);
            }

            if (notificationEntity.getNotificationType() == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_TYPE);
            }

            if (notificationEntity.getChannel() == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_CHANNEL);
            }

            return notificationEntity;
        }
    }

    /**
     * @param builder
     */
    private NotificationEntity(NotificationEntity.Builder builder) {
        this.entity = builder.entity;
        this.notificationType = builder.notificationType;
        this.channel = builder.channel;
    }

}
