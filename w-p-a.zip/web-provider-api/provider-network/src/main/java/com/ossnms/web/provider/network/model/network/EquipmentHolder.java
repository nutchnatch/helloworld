package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.EquipmentHolderID;

/**
 * Created on 08-09-2016.
 */
public class EquipmentHolder extends BaseEntity<EquipmentHolder, EquipmentHolderID, EquipmentHolder.Builder> implements Entity<EquipmentHolderID> {

    private static final long serialVersionUID = 7277206786535631098L;
    private String actualShelfType;
    private Integer bayShelf;
    private Integer shelfId;
    private String nativeLocation;

    public String getActualShelfType() {
        return actualShelfType;
    }

    public Integer getShelfId() {
        return shelfId;
    }

    public Integer getBayShelf() {
        return bayShelf;
    }

    public String getNativeLocation() {
        return nativeLocation;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<EquipmentHolder, EquipmentHolderID, EquipmentHolder.Builder> {

        private String actualShelfType;
        private Integer bayShelf;
        private Integer shelfId;
        private String nativeLocation;

        /**
         * @param equipmentHolderID
         */
        public Builder(EquipmentHolderID equipmentHolderID) {
            super(equipmentHolderID, EntityType.EQUIPMENT_HOLDER);
        }

        public EquipmentHolder.Builder actualShelfType(String actualShelfType) {
            this.actualShelfType = actualShelfType;
            return this;
        }

        public EquipmentHolder.Builder bayShelf(Integer bayShelf) {
            this.bayShelf = bayShelf;
            return this;
        }

        public EquipmentHolder.Builder shelfId(Integer shelfId) {
            this.shelfId = shelfId;
            return this;
        }

        public EquipmentHolder.Builder nativeLocation(String nativeLocation) {
            this.nativeLocation = nativeLocation;
            return this;
        }

        public EquipmentHolder build() {
            return new EquipmentHolder(this);
        }
    }

    /**
     * @param builder
     */
    private EquipmentHolder(EquipmentHolder.Builder builder) {
        super(builder);
        this.actualShelfType = builder.actualShelfType;
        this.bayShelf = builder.bayShelf;
        this.shelfId = builder.shelfId;
        this.nativeLocation = builder.nativeLocation;
    }
}
