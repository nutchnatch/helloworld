package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 13-09-2016.
 */
public class AlarmsSummaryID extends BaseEntityID implements EntityID {

    private static final long serialVersionUID = 7283844157159682081L;
    private static final String EXCEPTION_MESSAGE_ALARMS_SUMMARY_ID = "AlarmsSummaryID is invalid since the alarmsSummaryId " +
            "is null.";
    private final Integer alarmsSummaryId;

    public AlarmsSummaryID(String id, Integer alarmsSummaryId) {
        super(id);
        if (alarmsSummaryId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_ALARMS_SUMMARY_ID);
        }
        this.alarmsSummaryId = alarmsSummaryId;
    }

    public Integer getAlarmsSummaryId() {
        return alarmsSummaryId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AlarmsSummaryID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        AlarmsSummaryID that = (AlarmsSummaryID) o;

        return alarmsSummaryId.equals(that.alarmsSummaryId);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + alarmsSummaryId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private AlarmsSummaryID(AlarmsSummaryID.Builder builder) {
        super(builder);
        this.alarmsSummaryId = builder.alarmsSummaryId;
    }


    /**
     * Builder class for AlarmsSummaryIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<AlarmsSummaryID> implements
            ObjectBuilder<AlarmsSummaryID> {

        static final String EXCEPTION_MESSAGE_ALARMS_SUMMARY_ID = "Builder is invalid since the alarmsSummaryId is " +
                "null.";
        private Integer alarmsSummaryId;

        public Builder(String key, Integer alarmsSummaryId) {
            super(key);
            this.alarmsSummaryId = alarmsSummaryId;
        }

        public AlarmsSummaryID build() {
            AlarmsSummaryID alarmsSummaryID = new AlarmsSummaryID(this);

            if (this.alarmsSummaryId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_ALARMS_SUMMARY_ID);
            }

            return alarmsSummaryID;
        }
    }

}
