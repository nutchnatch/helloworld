package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.Direction;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.InternalPortConnectionID;

/**
 * Created on 13-09-2016.
 */
public class InternalPortConnection extends BaseEntity<InternalPortConnection, InternalPortConnectionID, InternalPortConnection.Builder> implements Entity<InternalPortConnectionID> {

    private static final long serialVersionUID = 542851339880934050L;
    private Direction direction;
    private OperationalState aEndOperationalState;
    private OperationalState zEndOperationalState;
    private String aEndName;
    private String zEndName;

    public Direction getDirection() {
        return direction;
    }

    public OperationalState getaEndOperationalState() {
        return aEndOperationalState;
    }

    public OperationalState getzEndOperationalState() {
        return zEndOperationalState;
    }

    public String getaEndName() {
        return aEndName;
    }

    public String getzEndName() {
        return zEndName;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<InternalPortConnection, InternalPortConnectionID, InternalPortConnection.Builder> {
        private Direction direction;
        private OperationalState aEndOperationalState;
        private OperationalState zEndOperationalState;
        private String aEndName;
        private String zEndName;

        /**
         * @param internalPortConnectionID
         */
        public Builder(InternalPortConnectionID internalPortConnectionID) {
            super(internalPortConnectionID, EntityType.INTERNAL_PORT_CONNECTION);
        }

        public InternalPortConnection.Builder direction(Direction direction) {
            this.direction = direction;
            return this;
        }

        public InternalPortConnection.Builder aEndOperationalState(OperationalState operationalState) {
            this.aEndOperationalState = operationalState;
            return this;
        }

        public InternalPortConnection.Builder zEndOperationalState(OperationalState operationalState) {
            this.zEndOperationalState = operationalState;
            return this;
        }

        public InternalPortConnection.Builder aEndName(String name) {
            this.aEndName = name;
            return this;
        }

        public InternalPortConnection.Builder zEndName(String name) {
            this.zEndName = name;
            return this;
        }

        public InternalPortConnection build() {
            return new InternalPortConnection(this);
        }
    }

    /**
     * @param builder
     */
    private InternalPortConnection(InternalPortConnection.Builder builder) {
        super(builder);
        this.direction = builder.direction;
        this.aEndOperationalState = builder.aEndOperationalState;
        this.zEndOperationalState = builder.zEndOperationalState;
        this.aEndName = builder.aEndName;
        this.zEndName = builder.zEndName;
    }

}
