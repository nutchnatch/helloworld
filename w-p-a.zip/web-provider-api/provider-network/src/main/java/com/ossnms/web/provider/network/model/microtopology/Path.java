package com.ossnms.web.provider.network.model.microtopology;

import java.io.Serializable;
import java.util.Collection;

/**
 * Created on 20-09-2016.
 */
public class Path implements Serializable {

    private static final long serialVersionUID = 1367047544183180023L;
    private String id;
    private String name;
    private Collection<String> supportGroups;
    private Collection<String> links;
    private String directionality;
    private String protection;
    private Boolean active;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Collection<String> getSupportGroups() {
        return supportGroups;
    }

    public void setSupportGroups(Collection<String> supportGroups) {
        this.supportGroups = supportGroups;
    }

    public Collection<String> getLinks() {
        return links;
    }

    public void setLinks(Collection<String> links) {
        this.links = links;
    }

    public String getDirectionality() {
        return directionality;
    }

    public void setDirectionality(String directionality) {
        this.directionality = directionality;
    }

    public String getProtection() {
        return protection;
    }

    public void setProtection(String protection) {
        this.protection = protection;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}
