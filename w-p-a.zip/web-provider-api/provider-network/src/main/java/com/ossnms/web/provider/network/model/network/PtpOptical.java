package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.LoopbackType;
import com.ossnms.web.provider.network.model.network.enumerable.ProvisioningModeType;
import com.ossnms.web.provider.network.model.network.enumerable.TpDirectionType;

import java.io.Serializable;
import java.util.List;

/**
 * Created on 14-09-2016.
 */
public class PtpOptical implements Serializable {

    private static final long serialVersionUID = 6862072726183749020L;
    private final ProvisioningModeType provisioningMode;
    private final TpDirectionType direction;
    private final List<String> terminatedLayers;
    private final List<String> nonTerminatedLayers;
    private final LoopbackType loopBack;

    public ProvisioningModeType getProvisioningMode() {
        return provisioningMode;
    }

    public TpDirectionType getDirection() {
        return direction;
    }

    public List<String> getTerminatedLayers() {
        return terminatedLayers;
    }

    public List<String> getNonTerminatedLayers() {
        return nonTerminatedLayers;
    }

    public LoopbackType getLoopBack() {
        return loopBack;
    }

    /**
     *
     */
    public static class Builder {
        private ProvisioningModeType provisioningMode;
        private TpDirectionType direction;
        private List<String> terminatedLayers;
        private List<String> nonTerminatedLayers;
        private LoopbackType loopBack;

        public Builder() {
        }

        public PtpOptical.Builder provisioningMode(ProvisioningModeType provisioningMode) {
            this.provisioningMode = provisioningMode;
            return this;
        }

        public PtpOptical.Builder direction(TpDirectionType direction) {
            this.direction = direction;
            return this;
        }

        public PtpOptical.Builder terminatedLayers(List<String> terminatedLayers) {
            this.terminatedLayers = terminatedLayers;
            return this;
        }

        public PtpOptical.Builder nonTerminatedLayers(List<String> nonTerminatedLayers) {
            this.nonTerminatedLayers = nonTerminatedLayers;
            return this;
        }

        public PtpOptical.Builder loopBack(LoopbackType loopBack) {
            this.loopBack = loopBack;
            return this;
        }

        /**
         * @return
         */
        public PtpOptical build() {
            return new PtpOptical(this);
        }
    }

    /**
     * @param builder
     */
    private PtpOptical(PtpOptical.Builder builder) {
        this.provisioningMode = builder.provisioningMode;
        this.direction = builder.direction;
        this.terminatedLayers = builder.terminatedLayers;
        this.nonTerminatedLayers = builder.nonTerminatedLayers;
        this.loopBack = builder.loopBack;
    }

}
