package com.ossnms.web.provider.network.model.network.id;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntityID;

public class SwitchingPointID extends BaseEntityID {

    private static final String EXCEPTION_MESSAGE_NE_ID = "SwitchingPointID is invalid since the neId is null.";
    private static final String EXCEPTION_MESSAGE_SUBSYS_ID = "SwitchingPointID is invalid since the subsysId is null.";
    private static final String EXCEPTION_MESSAGE_SP_ID = "SwitchingPointID is invalid since the spId is null.";
    private static final long serialVersionUID = -6087566367123062159L;

    private final Integer neId;
    private final Integer subsysId;
    private final Long spId;

    public SwitchingPointID(String id, Integer neId, Integer subsysId, Long spId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }
        if (subsysId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
        }
        if (spId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_SP_ID);
        }
        this.neId = neId;
        this.subsysId = subsysId;
        this.spId = spId;
    }


    public Integer getNeId() {
        return neId;
    }

    public Integer getSubsysId() {
        return subsysId;
    }

    public Long getSpId() {
        return spId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        SwitchingPointID that = (SwitchingPointID) o;
        return Objects.equals(neId, that.neId) &&
                Objects.equals(subsysId, that.subsysId) &&
                Objects.equals(spId, that.spId);
    }

    @Override
    public String toString() {
        return "SwitchingPointID{" +
                "neId=" + neId +
                ", subsysId=" + subsysId +
                ", spId=" + spId +
                '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), neId, subsysId, spId);
    }
}
