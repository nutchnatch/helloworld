package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class PhysicalTerminationPointID extends BaseEntityID implements EntityID {
    private static final String EXCEPTION_MESSAGE_NE_ID = "PhysicalTerminationPointID is invalid since the neId is null.";
    private static final String EXCEPTION_MESSAGE_PTP_ID = "PhysicalTerminationPointID is invalid since the ptpId is null.";
    private static final long serialVersionUID = -1687637036969202937L;
    private final Integer neId;
    private final Integer eqId;
    private final Integer ptpId;

    public PhysicalTerminationPointID(String id, Integer neId, Integer eqId, Integer ptpId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }

        if (ptpId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_ID);
        }
        this.neId = neId;
        this.eqId = eqId;
        this.ptpId = ptpId;
    }

    public Integer getNeId() {
        return neId;
    }

    public Integer getEqId() {
        return eqId;
    }

    public Integer getPtpId() {
        return ptpId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PhysicalTerminationPointID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        PhysicalTerminationPointID that = (PhysicalTerminationPointID) o;

        if (!neId.equals(that.neId)) {
            return false;
        }
        if (eqId != null ? !eqId.equals(that.eqId) : that.eqId != null) {
            return false;
        }
        return ptpId.equals(that.ptpId);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + neId.hashCode();
        result = 31 * result + (eqId != null ? eqId.hashCode() : 0);
        result = 31 * result + ptpId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    @Deprecated
    private PhysicalTerminationPointID(PhysicalTerminationPointID.Builder builder) {
        super(builder);
        this.neId = builder.neId;
        this.ptpId = builder.ptpId;
        this.eqId = builder.eqId;
    }

    /**
     * Builder class for PhysicalTerminationPointIDs
     */
    public static class Builder extends BaseEntityID.Builder<PhysicalTerminationPointID> implements ObjectBuilder<PhysicalTerminationPointID> {
        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neId is null.";
        static final String EXCEPTION_MESSAGE_PTP_ID = "Builder is invalid since the ptpId is null.";

        private Integer neId;
        private Integer eqId;
        private Integer ptpId;

        public Builder(String key, Integer neId, Integer ptpId) {
            super(key);
            this.neId = neId;
            this.ptpId = ptpId;
        }

        public Builder eqId(Integer eqId) {
            this.eqId = eqId;
            return this;
        }

        public PhysicalTerminationPointID build() {
            PhysicalTerminationPointID physicalTerminationPointID = new PhysicalTerminationPointID(this);

            if (this.neId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            if (this.ptpId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_ID);
            }

            return physicalTerminationPointID;
        }
    }
}
