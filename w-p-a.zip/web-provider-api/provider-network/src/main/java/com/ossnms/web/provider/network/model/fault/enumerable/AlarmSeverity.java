package com.ossnms.web.provider.network.model.fault.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 *
 */
public enum AlarmSeverity implements BaseEnum {

    CLEARED         ("cleared",0),
    WARNING         ("warning",1),
    MINOR           ("minor",2),
    MAJOR           ("major",3),
    CRITICAL        ("critical",4),
    INDETERMINATE   ("indeterminate",5),
    NOT_EXISTENT    ("notExistent",6),
    NON_ALARMED     ("nonAlarmed", 7),
    NOT_ALARMED     ("notAlarmed", 8);

    private final String name;
    private final int ordinal;

    AlarmSeverity(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link AlarmSeverity}; null if no match
     */
    public static AlarmSeverity fromName(String name){
        return getValue(
                AlarmSeverity.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link AlarmSeverity}; null if no match
     */
    public static AlarmSeverity fromOrdinal(int ordinal){
        return getValue(
                AlarmSeverity.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }
}
