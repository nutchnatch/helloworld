package com.ossnms.web.provider.network.model.network;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.AdministrativeStateType;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.LspTpID;
import com.ossnms.web.provider.network.model.network.id.TerminationPointID;

public class LspTp extends BaseEntity<LspTp, LspTpID, LspTp.Builder> {
    private static final long serialVersionUID = 2424148783731724995L;

    private final Long tunnelId;
    private final Long incomingLabel;
    private final Long outgoingLabel;
    private final TerminationPointID incomingInterface;
    private final TerminationPointID outgoingInterface;
    private final String interfaceName;
    private final Integer tunnelNum;
    private final Integer lspNum;
    private final OperationalState operationalState;
    private final AdministrativeStateType adminState;

    /**
     * @param builder
     */
    private LspTp(Builder builder) {
        super(builder);
        tunnelId = builder.tunnelId;
        incomingLabel = builder.incomingLabel;
        outgoingLabel = builder.outgoingLabel;
        incomingInterface = builder.incomingInterface;
        outgoingInterface = builder.outgoingInterface;
        interfaceName = builder.interfaceName;
        tunnelNum = builder.tunnelNum;
        lspNum = builder.lspNum;
        operationalState = builder.operationalState;
        adminState = builder.adminState;
    }

    public Long getTunnelId() {
        return tunnelId;
    }

    public Long getIncomingLabel() {
        return incomingLabel;
    }

    public Long getOutgoingLabel() {
        return outgoingLabel;
    }

    public TerminationPointID getIncomingInterface() {
        return incomingInterface;
    }

    public TerminationPointID getOutgoingInterface() {
        return outgoingInterface;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public Integer getTunnelNum() {
        return tunnelNum;
    }

    public Integer getLspNum() {
        return lspNum;
    }

    public OperationalState getOperationalState() {
        return operationalState;
    }

    public AdministrativeStateType getAdminState() {
        return adminState;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        LspTp lspTp = (LspTp) o;
        return Objects.equals(tunnelId, lspTp.tunnelId) &&
                Objects.equals(incomingLabel, lspTp.incomingLabel) &&
                Objects.equals(outgoingLabel, lspTp.outgoingLabel) &&
                Objects.equals(incomingInterface, lspTp.incomingInterface) &&
                Objects.equals(outgoingInterface, lspTp.outgoingInterface) &&
                Objects.equals(interfaceName, lspTp.interfaceName) &&
                Objects.equals(tunnelNum, lspTp.tunnelNum) &&
                Objects.equals(lspNum, lspTp.lspNum) &&
                operationalState == lspTp.operationalState &&
                adminState == lspTp.adminState;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(),
                            tunnelId,
                            incomingLabel,
                            outgoingLabel,
                            incomingInterface,
                            outgoingInterface,
                            interfaceName,
                            tunnelNum,
                            lspNum,
                            operationalState,
                            adminState);
    }

    @Override
    public String toString() {
        return "LspTp{" +
                "tunnelId=" + tunnelId +
                ", incomingLabel=" + incomingLabel +
                ", outgoingLabel=" + outgoingLabel +
                ", incomingInterface=" + incomingInterface +
                ", outgoingInterface=" + outgoingInterface +
                ", interfaceName='" + interfaceName + '\'' +
                ", tunnelNum=" + tunnelNum +
                ", lspNum=" + lspNum +
                ", operationalState=" + operationalState +
                ", adminState=" + adminState +
                '}';
    }

    public static class Builder extends BaseEntity.Builder<LspTp, LspTpID, LspTp.Builder> {
        private Long tunnelId;
        private Long incomingLabel;
        private Long outgoingLabel;
        private TerminationPointID incomingInterface;
        private TerminationPointID outgoingInterface;
        private String interfaceName;
        private Integer tunnelNum;
        private Integer lspNum;
        private OperationalState operationalState;
        private AdministrativeStateType adminState;

        /**
         * @param entityID
         */
        public Builder(LspTpID entityID) {
            super(entityID, EntityType.LSP_TP);
        }

        public Builder tunnelId(Long tunnelId) {
            this.tunnelId = tunnelId;
            return this;
        }

        public Builder incomingLabel(Long incomingLabel) {
            this.incomingLabel = incomingLabel;
            return this;
        }

        public Builder outgoingLabel(Long outgoingLabel) {
            this.outgoingLabel = outgoingLabel;
            return this;
        }

        public Builder incomingInterface(TerminationPointID incomingInterface) {
            this.incomingInterface = incomingInterface;
            return this;
        }

        public Builder outgoingInterface(TerminationPointID outgoingInterface) {
            this.outgoingInterface = outgoingInterface;
            return this;
        }

        public Builder interfaceName(String interfaceName) {
            this.interfaceName = interfaceName;
            return this;
        }

        public Builder tunnelNum(Integer tunnelNum) {
            this.tunnelNum = tunnelNum;
            return this;
        }

        public Builder lspNum(Integer lspNum) {
            this.lspNum = lspNum;
            return this;
        }

        public Builder operationalState(OperationalState operationalState) {
            this.operationalState = operationalState;
            return this;
        }

        public Builder adminState(AdministrativeStateType adminState) {
            this.adminState = adminState;
            return this;
        }

        @Override
        public LspTp build() {
            return new LspTp(this);
        }
    }
}
