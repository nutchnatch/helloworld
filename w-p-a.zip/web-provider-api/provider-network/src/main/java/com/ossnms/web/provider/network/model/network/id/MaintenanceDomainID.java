package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class MaintenanceDomainID extends BaseEntityID implements EntityID {
    private static final String EXCEPTION_MESSAGE_NE_ID = "MaintenanceDomainID is invalid since the neId is null.";
    private static final String EXCEPTION_MESSAGE_SUBSYS_ID = "MaintenanceDomainID is invalid since the subsysId is null.";
    private static final String EXCEPTION_MESSAGE_CONTEXT_ID = "MaintenanceDomainID is invalid since the contextId is null.";
    private static final long serialVersionUID = -664073839450454517L;
    private final Integer neId;
    private final Integer subsysId;
    private final Long contextId;

    public MaintenanceDomainID(String id, Integer neId, Integer subsysId, Long contextId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }

        if (subsysId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
        }

        if (contextId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_CONTEXT_ID);
        }
        this.neId = neId;
        this.subsysId = subsysId;
        this.contextId = contextId;
    }

    public Integer getNeId() {
        return neId;
    }

    public Integer getSubsysId() {
        return subsysId;
    }

    public Long getContextId() {
        return contextId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MaintenanceDomainID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        MaintenanceDomainID that = (MaintenanceDomainID) o;

        if (!neId.equals(that.neId)) {
            return false;
        }
        if (!subsysId.equals(that.subsysId)) {
            return false;
        }
        return contextId.equals(that.contextId);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + neId.hashCode();
        result = 31 * result + subsysId.hashCode();
        result = 31 * result + contextId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private MaintenanceDomainID(MaintenanceDomainID.Builder builder) {
        super(builder);
        this.neId = builder.neId;
        this.subsysId = builder.subsysId;
        this.contextId = builder.contextId;
    }


    /**
     * Builder class for MaintenanceDomainIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<MaintenanceDomainID> implements ObjectBuilder<MaintenanceDomainID> {
        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neId is null.";
        static final String EXCEPTION_MESSAGE_SUBSYS_ID = "Builder is invalid since the subsysId is null.";
        static final String EXCEPTION_MESSAGE_CONTEXT_ID = "Builder is invalid since the contextId is null.";

        private Integer neId;
        private Integer subsysId;
        private Long contextId;

        public Builder(String key, Integer neId, Integer subsysId, Long contextId) {
            super(key);
            this.neId = neId;
            this.subsysId = subsysId;
            this.contextId = contextId;
        }

        public MaintenanceDomainID build() {
            MaintenanceDomainID maintenanceDomainID = new MaintenanceDomainID(this);

            if (neId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            if (subsysId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
            }

            if (contextId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_CONTEXT_ID);
            }

            return maintenanceDomainID;
        }
    }
}
