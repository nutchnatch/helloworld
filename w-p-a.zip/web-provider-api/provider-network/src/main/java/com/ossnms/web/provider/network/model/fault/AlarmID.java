package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

/**
 * ID class which identifies Alarms
 */
public final class AlarmID implements EntityID {

    private static final long serialVersionUID = 6998841436487039312L;

    private final long id;

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private AlarmID(Builder builder) {
        this.id = builder.id;
    }

    /**
     *
     * @return
     */
    public long getId() {
        return id;
    }

    /**
     * Builder class for AlarmIDs
     */
    public static class Builder implements ObjectBuilder<AlarmID> {
        private long id;

        public Builder(long id){
            this.id = id;
        }

        public AlarmID build() {
            return new AlarmID(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        AlarmID that = (AlarmID) o;

        return id == that.id;

    }

    @Override
    public int hashCode() {
        return (int) (id ^ (id >>> 32));
    }
}
