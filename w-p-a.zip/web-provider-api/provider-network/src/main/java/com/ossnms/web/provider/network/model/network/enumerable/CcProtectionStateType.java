package com.ossnms.web.provider.network.model.network.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

import com.ossnms.web.provider.network.model.common.enumerable.BaseEnum;

/**
 * Created on 13-09-2016.
 */
public enum CcProtectionStateType implements BaseEnum {

    WORKING("working", 0),
    PROTECTING("protecting", 1);

    private final String name;
    private final int ordinal;

    /**
     * @param name
     * @param ordinal
     */
    CcProtectionStateType(String name, int ordinal) {
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link CcProtectionStateType}; null if no match
     */
    public static CcProtectionStateType fromName(String name) {
        return name != null ?
                getValue(
                        CcProtectionStateType.values(),
                        candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
                ) : null;
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link CcProtectionStateType}; null if no match
     */
    public static CcProtectionStateType fromOrdinal(int ordinal) {
        return getValue(
                CcProtectionStateType.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
