package com.ossnms.web.provider.network.model.network.id;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntityID;

public class LspTpID extends BaseEntityID {

    private static final long serialVersionUID = -8067325645752429612L;
    private static final String EXCEPTION_MESSAGE_NE_ID = "LspTpID is invalid since the neId is null.";
    private static final String EXCEPTION_MESSAGE_SUBSYS_ID = "LspTpID is invalid since the subsysId is null.";
    private static final String EXCEPTION_MESSAGE_TP_ID = "LspTpID is invalid since the tpId is null.";
    private final Integer neId;
    private final Integer subsysId;
    private final Long tpId;

    public LspTpID(String id, Integer neId, Integer subsysId, Long tpId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }
        if (subsysId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
        }
        if (tpId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_TP_ID);
        }
        this.neId = neId;
        this.subsysId = subsysId;
        this.tpId = tpId;
    }

    public Integer getNeId() {
        return neId;
    }

    public Integer getSubsysId() {
        return subsysId;
    }

    public Long getTpId() {
        return tpId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        LspTpID lspTpID = (LspTpID) o;
        return Objects.equals(neId, lspTpID.neId) &&
                Objects.equals(subsysId, lspTpID.subsysId) &&
                Objects.equals(tpId, lspTpID.tpId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), neId, subsysId, tpId);
    }

    @Override
    public String toString() {
        return "LspTpID{" +
                "neId=" + neId +
                ", subsysId=" + subsysId +
                ", tpId=" + tpId +
                '}';
    }
}
