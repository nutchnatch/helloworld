package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class TerminationPointID extends BaseEntityID implements EntityID {

    private static final String EXCEPTION_MESSAGE_NE_ID = "TerminationPointID is invalid since the neId is null.";
    private static final String EXCEPTION_MESSAGE_PTP_ID = "TerminationPointID is invalid since the ptpId is null.";
    private static final String EXCEPTION_MESSAGE_TP_ID = "TerminationPointID is invalid since the tpId is null.";
    private static final long serialVersionUID = 2277922720276447162L;
    private final Integer neId;
    private final Integer ptpId;
    private final Long tpId;

    public TerminationPointID(String id, Integer neId, Integer ptpId, Long tpId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }

        if (ptpId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_ID);
        }

        if (tpId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_TP_ID);
        }
        this.neId = neId;
        this.ptpId = ptpId;
        this.tpId = tpId;
    }

    public Integer getNeId() {
        return neId;
    }

    public Long getTpId() {
        return tpId;
    }

    public Integer getPtpId() {
        return ptpId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TerminationPointID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        TerminationPointID that = (TerminationPointID) o;

        if (!neId.equals(that.neId)) {
            return false;
        }
        if (!ptpId.equals(that.ptpId)) {
            return false;
        }
        return tpId.equals(that.tpId);
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + neId.hashCode();
        result = 31 * result + ptpId.hashCode();
        result = 31 * result + tpId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private TerminationPointID(TerminationPointID.Builder builder) {
        super(builder);
        this.neId = builder.neId;
        this.ptpId = builder.ptpId;
        this.tpId = builder.tpId;
    }

    /**
     * Builder class for TerminationPointIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<TerminationPointID> implements ObjectBuilder<TerminationPointID> {
        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neId is null.";
        static final String EXCEPTION_MESSAGE_PTP_ID = "Builder is invalid since the ptpId is null.";
        static final String EXCEPTION_MESSAGE_TP_ID = "Builder is invalid since the tpId is null.";

        private Integer neId;
        private Integer ptpId;
        private Long tpId;

        public Builder(String key, Integer neId, Integer ptpId, Long tpId) {
            super(key);
            this.neId = neId;
            this.ptpId = ptpId;
            this.tpId = tpId;
        }

        public TerminationPointID build() {
            TerminationPointID terminationPointID = new TerminationPointID(this);

            if (this.neId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            if (this.ptpId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_ID);
            }

            if (this.tpId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_TP_ID);
            }

            return terminationPointID;
        }
    }
}
