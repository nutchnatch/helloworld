package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.BundleStateType;

/**
 * Created by catarino on 14-09-2016.
 */
public class LacpLocal extends LacpRemote {

    private static final long serialVersionUID = 8957398298824491750L;
    private Integer waitTime;
    private BundleStateType bundleState;

    public Integer getWaitTime() {
        return waitTime;
    }

    public void setWaitTime(Integer waitTime) {
        this.waitTime = waitTime;
    }

    public BundleStateType getBundleState() {
        return bundleState;
    }

    public void setBundleState(BundleStateType bundleState) {
        this.bundleState = bundleState;
    }

}
