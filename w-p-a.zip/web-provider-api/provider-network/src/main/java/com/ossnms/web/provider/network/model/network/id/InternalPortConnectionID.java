package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 13-09-2016.
 */
public class InternalPortConnectionID extends BaseEntityID implements EntityID {
    static final String EXCEPTION_MESSAGE_PTP_END_A = "InternalPortConnectionID is invalid since the ptpEndA is null.";
    static final String EXCEPTION_MESSAGE_PTP_END_Z = "InternalPortConnectionID is invalid since the ptpEndZ is null.";
    static final String EXCEPTION_MESSAGE_NE_ID = "InternalPortConnectionID is invalid since the neIDs are not the same.";
    private static final long serialVersionUID = 6439895316119289589L;
    private final PhysicalTerminationPointID ptpEndA;
    private final PhysicalTerminationPointID ptpEndZ;

    public InternalPortConnectionID(String id,
                                    PhysicalTerminationPointID ptpEndA,
                                    PhysicalTerminationPointID ptpEndZ) {
        super(id);
        if (ptpEndA == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_END_A);
        }

        if (ptpEndZ == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_END_Z);
        }

        if (!ptpEndA.getNeId().equals(ptpEndZ.getNeId())) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }

        this.ptpEndA = ptpEndA;
        this.ptpEndZ = ptpEndZ;
    }

    public PhysicalTerminationPointID getPtpEndA() {
        return ptpEndA;
    }

    public PhysicalTerminationPointID getPtpEndZ() {
        return ptpEndZ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof InternalPortConnectionID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        InternalPortConnectionID that = (InternalPortConnectionID) o;

        if (!ptpEndA.equals(that.ptpEndA)) {
            return false;
        }
        return ptpEndZ.equals(that.ptpEndZ);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + ptpEndA.hashCode();
        result = 31 * result + ptpEndZ.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private InternalPortConnectionID(InternalPortConnectionID.Builder builder) {
        super(builder);
        this.ptpEndA = builder.ptpEndA;
        this.ptpEndZ = builder.ptpEndZ;
    }


    /**
     * Builder class for InternalPortConnectionIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<InternalPortConnectionID> implements
            ObjectBuilder<InternalPortConnectionID> {
        static final String EXCEPTION_MESSAGE_PTP_END_A = "Builder is invalid since the ptpEndA is null.";
        static final String EXCEPTION_MESSAGE_PTP_END_Z = "Builder is invalid since the ptpEndZ is null.";
        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neIDs are not the same.";

        private PhysicalTerminationPointID ptpEndA;
        private PhysicalTerminationPointID ptpEndZ;

        public Builder(String key, PhysicalTerminationPointID ptpEndA, PhysicalTerminationPointID ptpEndZ) {
            super(key);
            this.ptpEndA = ptpEndA;
            this.ptpEndZ = ptpEndZ;
        }

        public InternalPortConnectionID build() {
            InternalPortConnectionID internalPortConnectionID = new InternalPortConnectionID(this);

            if (this.ptpEndA == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_END_A);
            }

            if (this.ptpEndZ == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_PTP_END_Z);
            }

            if (!this.ptpEndA.getNeId().equals(this.ptpEndZ.getNeId())) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            return internalPortConnectionID;
        }
    }

}
