package com.ossnms.web.provider.network.model.container;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

/**
 * ID class which identifies Containers
 */
public final class ContainerID implements EntityID {

    private static final long serialVersionUID = 5861726560019873618L;

    private final long id;

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private ContainerID(Builder builder) {
        this.id = builder.id;
    }

    /**
     *
     * @return
     */
    public long getId() {
        return id;
    }

    /**
     * Builder class for ContainerIDs
     */
    public static class Builder implements ObjectBuilder<ContainerID>{
        private long id;

        public Builder(long id){
            this.id = id;
        }

        public ContainerID build() {
            return new ContainerID(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        ContainerID that = (ContainerID) o;

        return id == that.id;

    }

    @Override
    public int hashCode() {
        return (int) (id ^ (id >>> 32));
    }
}
