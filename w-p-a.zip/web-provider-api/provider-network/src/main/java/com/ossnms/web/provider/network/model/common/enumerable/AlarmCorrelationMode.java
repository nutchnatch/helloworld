package com.ossnms.web.provider.network.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum AlarmCorrelationMode implements BaseEnum {

    /**
     * <div>The alarm state is not applicable</div>
     */
    NOT_APPLICABLE                  ("notApplicable", 0),
    /**
     * <div>The alarm state is not correlated</div>
     */
    DISABLED                        ("disabled", 1),
    /**
     * <div>The alarm state is correlated using all the affecting alarms in all the route points</div>
     */
    ENABLED                         ("enabled", 2),
    /**
     * <div>The alarm state is correlated not using the alarm state of the end points</div>
     */
    ENABLED_EXCLUDING_END_POINTS    ("enabledExcludingEndPoints", 3);


    private final String name;
    private final int ordinal;

    /**
     *
     * @param name
     * @param ordinal
     */
    AlarmCorrelationMode(String name, int ordinal){
        this.name = name;
        this.ordinal = ordinal;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link AlarmCorrelationMode}; null if no match
     */
    public static AlarmCorrelationMode fromName(String name){
        return getValue(
                AlarmCorrelationMode.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }

    /**
     * Retrieves the enum value from an ordinal
     *
     * @param ordinal the ordinal to search for
     * @return an instance of {@link AlarmCorrelationMode}; null if no match
     */
    public static AlarmCorrelationMode fromOrdinal(int ordinal){
        return getValue(
                AlarmCorrelationMode.values(),
                candidate -> candidate.getOrdinal() == ordinal
        );
    }

}
