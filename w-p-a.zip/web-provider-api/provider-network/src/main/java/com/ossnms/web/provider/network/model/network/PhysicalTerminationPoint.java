package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.AdministrativeStateType;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.enumerable.PhysicalInterfaceType;
import com.ossnms.web.provider.network.model.network.enumerable.TerminationPointType;
import com.ossnms.web.provider.network.model.network.id.PhysicalTerminationPointID;

/**
 * Created on 13-09-2016.
 */
public class PhysicalTerminationPoint extends BaseEntity<PhysicalTerminationPoint, PhysicalTerminationPointID,
        PhysicalTerminationPoint.Builder> implements Entity<PhysicalTerminationPointID> {

    private static final long serialVersionUID = -6656075871878544199L;
    private final PhysicalInterfaceType interfaceType;
    private final TerminationPointType pointType;
    private final OperationalState operationalStateSink;
    private final OperationalState operationalStateSource;
    private final AdministrativeStateType administrativeState;
    private final String portMode;
    private final String nativeLocation;

    private final PtpOptical optical;
    private final PtpLocation location;

    public PhysicalInterfaceType getInterfaceType() {
        return interfaceType;
    }

    public TerminationPointType getPointType() {
        return pointType;
    }

    public OperationalState getOperationalStateSink() {
        return operationalStateSink;
    }

    public OperationalState getOperationalStateSource() {
        return operationalStateSource;
    }

    public AdministrativeStateType getAdministrativeState() {
        return administrativeState;
    }

    public String getPortMode() {
        return portMode;
    }

    public String getNativeLocation() {
        return nativeLocation;
    }

    public PtpOptical getOptical() {
        return optical;
    }

    public PtpLocation getLocation() {
        return location;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<PhysicalTerminationPoint, PhysicalTerminationPointID,
            PhysicalTerminationPoint.Builder> {
        private PhysicalInterfaceType interfaceType;
        private TerminationPointType pointType;
        private OperationalState operationalStateSink;
        private OperationalState operationalStateSource;
        private AdministrativeStateType administrativeState;
        private String portMode;
        private String nativeLocation;
        private PtpOptical optical;
        private PtpLocation location;

        /**
         * @param physicalTerminationPointID
         */
        public Builder(PhysicalTerminationPointID physicalTerminationPointID) {
            super(physicalTerminationPointID, EntityType.PHYSICAL_TERMINATION_POINT);
        }

        public PhysicalTerminationPoint.Builder interfaceType(PhysicalInterfaceType interfaceType) {
            this.interfaceType = interfaceType;
            return this;
        }

        public PhysicalTerminationPoint.Builder pointType(TerminationPointType pointType) {
            this.pointType = pointType;
            return this;
        }

        public PhysicalTerminationPoint.Builder operationalStateSink(OperationalState operationalState) {
            this.operationalStateSink = operationalState;
            return this;
        }

        public PhysicalTerminationPoint.Builder operationalStateSource(OperationalState operationalState) {
            this.operationalStateSource = operationalState;
            return this;
        }

        public PhysicalTerminationPoint.Builder administrativeState(AdministrativeStateType administrativeState) {
            this.administrativeState = administrativeState;
            return this;
        }

        public PhysicalTerminationPoint.Builder portMode(String portMode) {
            this.portMode = portMode;
            return this;
        }

        public PhysicalTerminationPoint.Builder nativeLocation(String nativeLocation) {
            this.nativeLocation = nativeLocation;
            return this;
        }

        public PhysicalTerminationPoint.Builder optical(PtpOptical optical) {
            this.optical = optical;
            return this;
        }

        public PhysicalTerminationPoint.Builder location(PtpLocation location) {
            this.location = location;
            return this;
        }

        public PhysicalTerminationPoint build() {
            return new PhysicalTerminationPoint(this);
        }
    }

    /**
     * @param builder
     */
    private PhysicalTerminationPoint(PhysicalTerminationPoint.Builder builder) {
        super(builder);
        this.interfaceType = builder.interfaceType;
        this.pointType = builder.pointType;
        this.operationalStateSink = builder.operationalStateSink;
        this.operationalStateSource = builder.operationalStateSource;
        this.administrativeState = builder.administrativeState;
        this.portMode = builder.portMode;
        this.nativeLocation = builder.nativeLocation;
        this.optical = builder.optical;
        this.location = builder.location;
    }
}
