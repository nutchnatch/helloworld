package com.ossnms.web.provider.network.model.microtopology;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;

/**
 * @deprecated This class is not necessary. You can use a generic BaseEntity to represente the service.
 */
@Deprecated
public final class Service extends BaseEntity<Service, BaseEntityID, Service.Builder> implements Entity<BaseEntityID> {

    private static final long serialVersionUID = 288452004393190687L;
    private Point start;

    public Point getStart() {
        return start;
    }

    /**
     *
     */
    public static class Builder extends BaseEntity.Builder<Service, BaseEntityID, Service.Builder> {
        private Point start;

        /**
         * @param baseEntityID
         */
        public Builder(BaseEntityID baseEntityID) {
            super(baseEntityID, EntityType.SERVICE);
        }

        public Service.Builder start(Point start) {
            this.start = start;
            return this;
        }

        public Service build() {
            return new Service(this);
        }
    }

    /**
     * @param builder
     */
    private Service(Service.Builder builder) {
        super(builder);
        this.start = builder.start;
    }

}
