package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.network.model.common.BaseEntityID;

/**
 * Created on 08-09-2016.
 */
public class BridgeID extends BaseEntityID implements EntityID {

    private static final String EXCEPTION_MESSAGE_NE_ID = "BridgeID is invalid since the neId is null.";
    private static final String EXCEPTION_MESSAGE_SUBSYS_ID = "BridgeID is invalid since the subsysId is null.";
    private static final String EXCEPTION_MESSAGE_BRIDGE_ID = "BridgeID is invalid since the bridgeId is null.";
    private static final long serialVersionUID = 304425176993337101L;
    private final Integer neId;
    private final Integer subsysId;
    private final Integer bridgeId;

    public BridgeID(String id, Integer neId, Integer subsysId, Integer bridgeId) {
        super(id);
        if (neId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
        }

        if (subsysId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
        }

        if (bridgeId == null) {
            throw new IllegalStateException(EXCEPTION_MESSAGE_BRIDGE_ID);
        }
        this.neId = neId;
        this.subsysId = subsysId;
        this.bridgeId = bridgeId;
    }

    public Integer getNeId() {
        return neId;
    }

    public Integer getBridgeId() {
        return bridgeId;
    }

    public Integer getSubsysId() {
        return subsysId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BridgeID)) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        BridgeID bridgeID = (BridgeID) o;

        if (!neId.equals(bridgeID.neId)) {
            return false;
        }
        if (!subsysId.equals(bridgeID.subsysId)) {
            return false;
        }
        return bridgeId.equals(bridgeID.bridgeId);

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + neId.hashCode();
        result = 31 * result + subsysId.hashCode();
        result = 31 * result + bridgeId.hashCode();
        return result;
    }

    /**
     * Private builder constructor
     *
     * @param builder
     */
    private BridgeID(BridgeID.Builder builder) {
        super(builder);
        this.neId = builder.neId;
        this.subsysId = builder.subsysId;
        this.bridgeId = builder.bridgeId;
    }


    /**
     * Builder class for BridgeIDs
     */
    @Deprecated
    public static class Builder extends BaseEntityID.Builder<BridgeID> implements ObjectBuilder<BridgeID> {
        static final String EXCEPTION_MESSAGE_NE_ID = "Builder is invalid since the neId is null.";
        static final String EXCEPTION_MESSAGE_SUBSYS_ID = "Builder is invalid since the subsysId is null.";
        static final String EXCEPTION_MESSAGE_BRIDGE_ID = "Builder is invalid since the bridgeId is null.";
        private Integer neId;
        private Integer subsysId;
        private Integer bridgeId;

        public Builder(String key, Integer neId, Integer subsysId, Integer bridgeId) {
            super(key);
            this.neId = neId;
            this.subsysId = subsysId;
            this.bridgeId = bridgeId;
        }

        public BridgeID build() {
            BridgeID bridgeID = new BridgeID(this);

            if (neId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_NE_ID);
            }

            if (subsysId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_SUBSYS_ID);
            }

            if (bridgeId == null) {
                throw new IllegalStateException(EXCEPTION_MESSAGE_BRIDGE_ID);
            }

            return bridgeID;
        }
    }
}
