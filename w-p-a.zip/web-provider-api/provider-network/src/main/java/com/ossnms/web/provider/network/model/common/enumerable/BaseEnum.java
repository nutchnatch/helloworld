package com.ossnms.web.provider.network.model.common.enumerable;

public interface BaseEnum {
    String getName();
    int getOrdinal();
}
