package com.ossnms.web.provider.network.model.network;

import java.util.Objects;

import com.ossnms.web.provider.network.model.common.BaseEntity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.AttachmentCircuitTpID;

public class AttachmentCircuitTp extends BaseEntity<AttachmentCircuitTp, AttachmentCircuitTpID, AttachmentCircuitTp.Builder> {

    private static final long serialVersionUID = 6380437145421791952L;
    private final Integer svid;
    private final Integer cvid;
    private final Long spId;

    /**
     * @param builder
     */
    private AttachmentCircuitTp(Builder builder) {
        super(builder);
        svid = builder.svid;
        cvid = builder.cvid;
        spId = builder.spId;
    }

    public Integer getSvid() {
        return svid;
    }

    public Integer getCvid() {
        return cvid;
    }

    public Long getSpId() {
        return spId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        AttachmentCircuitTp that = (AttachmentCircuitTp) o;
        return Objects.equals(svid, that.svid) &&
                Objects.equals(cvid, that.cvid) &&
                Objects.equals(spId, that.spId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), svid, cvid, spId);
    }

    @Override
    public String toString() {
        return "AttachmentCircuitTp{" +
                "svid=" + svid +
                ", cvid=" + cvid +
                ", spId=" + spId +
                '}';
    }

    public static class Builder extends BaseEntity.Builder<AttachmentCircuitTp, AttachmentCircuitTpID, AttachmentCircuitTp.Builder> {
        private Integer svid;
        private Integer cvid;
        private Long spId;

        /**
         * @param entityID
         */
        public Builder(AttachmentCircuitTpID entityID) {
            super(entityID, EntityType.ATTACHMENT_CIRCUIT_TP);
        }

        public Builder svid(Integer svid) {
            this.svid = svid;
            return this;
        }

        public Builder cvid(Integer cvid) {
            this.cvid = cvid;
            return this;
        }

        public Builder spId(Long spId) {
            this.spId = spId;
            return this;
        }

        @Override
        public AttachmentCircuitTp build() {
            return new AttachmentCircuitTp(this);
        }
    }
}
