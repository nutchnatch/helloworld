package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.BundleStateType;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 14-09-2016.
 */
public class LacpLocalTest extends LacpRemoteTest<LacpLocal> {

    @Before
    public void setUp() throws Exception {
        entity = new LacpLocal();
        assertThat(entity).isNotNull();
    }

    @Test
    public void testGetWaitTime() throws Exception {
        assertThat(entity.getWaitTime()).isNull();
        Integer waitTime = 120;
        entity.setWaitTime(waitTime);
        assertThat(entity.getWaitTime()).isNotNull().isEqualTo(waitTime);
    }

    @Test
    public void testGetBundleState() throws Exception {
        assertThat(entity.getBundleState()).isNull();
        BundleStateType bundleState = BundleStateType.STANDBY;
        entity.setBundleState(bundleState);
        assertThat(entity.getBundleState()).isNotNull().isEqualTo(bundleState);
    }

}
