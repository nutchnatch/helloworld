package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.common.api.model.Color;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 21-10-2016.
 */
public class AlarmSeverityColorTest {

    @Test
    public void testGetAlarmSeverity() throws Exception {
        AlarmSeverity alarmSeverity = AlarmSeverity.CRITICAL;
        AlarmSeverityColor alarmSeverityColor = new AlarmSeverityColor(alarmSeverity, null);
        assertThat(alarmSeverityColor.getAlarmSeverity()).isNotNull().isEqualTo(alarmSeverity);
    }

    @Test
    public void testGetColor() throws Exception {
        Color color = new Color(100, 100, 100);
        AlarmSeverityColor alarmSeverityColor = new AlarmSeverityColor(null, color);
        assertThat(alarmSeverityColor.getColor()).isNotNull().isEqualTo(color);
    }

}
