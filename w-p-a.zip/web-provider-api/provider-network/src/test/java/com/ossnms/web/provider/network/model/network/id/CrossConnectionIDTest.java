package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by catarino on 12-09-2016.
 */
public class CrossConnectionIDTest extends BaseEntityIDTest<CrossConnectionID, CrossConnectionID.Builder> {

    @Before
    public void setUp() throws Exception {
        builder = new CrossConnectionID.Builder(KEY, TP_END_A, TP_END_Z);
        id = builder.build();
    }

    @Test
    public void testGetTpEndA() throws Exception {
        assertThat(id.getTpEndA()).isNotNull().isEqualTo(TP_END_A);
    }

    @Test
    public void testGetTpEndZ() throws Exception {
        assertThat(id.getTpEndZ()).isNotNull().isEqualTo(TP_END_Z);
    }

    @Test
    public void testGetTpEndP() throws Exception {
        assertThat(id.getTpEndP()).isNull();
        builder = builder.tpEndP(TP_END_P);
        id = builder.build();
        assertThat(id.getTpEndP()).isNotNull().isEqualTo(TP_END_P);
    }

    @Test
    public void testBuildWithExceptionDueTP_END_A() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(CrossConnectionID.Builder.EXCEPTION_MESSAGE_TP_END_A);
        new CrossConnectionID.Builder(KEY, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueTP_END_Z() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(CrossConnectionID.Builder.EXCEPTION_MESSAGE_TP_END_Z);
        new CrossConnectionID.Builder(KEY, TP_END_A, null).build();
    }

    @Test
    public void testBuildWithExceptionDueNE_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(CrossConnectionID.Builder.EXCEPTION_MESSAGE_NE_ID);
        TerminationPointID tpInvalid = new TerminationPointID.Builder("", (TP_END_A.getNeId() + 1), PTP_ID, TP_ID).build();
        new CrossConnectionID.Builder(KEY, TP_END_A, tpInvalid).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(NE_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new ContainerID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new EquipmentHolderID.Builder(KEY, NE_ID, EQ_ID).build())).isFalse();

        CrossConnectionID.Builder ccBuilder = new CrossConnectionID.Builder(KEY, TP_END_A, TP_END_Z);
        assertThat(id.equals(ccBuilder.build())).isTrue();

        builder = builder.tpEndP(TP_END_P);
        id = builder.build();
        assertThat(id.equals(ccBuilder.build())).isFalse();
        assertThat(id.equals(ccBuilder.tpEndP(TP_END_P).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
