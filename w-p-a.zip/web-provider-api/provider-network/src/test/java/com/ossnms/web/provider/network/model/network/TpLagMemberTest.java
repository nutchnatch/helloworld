package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.id.TerminationPointID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 14-09-2016.
 */
public class TpLagMemberTest {

    private TpLagMember entity;
    private static final TpLagMember.Builder builder = new TpLagMember.Builder(null);

    @Before
    public void setUp() throws Exception {
        entity = builder.build();
        assertThat(builder).isNotNull();
        assertThat(entity).isNotNull();
    }

    @Test
    public void testGetTpLagId() throws Exception {
        assertThat(entity.getTpLagId()).isNull();
        TerminationPointID tpID = new TerminationPointID.Builder("", 1, 100, 10000L).build();
        entity = new TpLagMember.Builder(tpID).build();
        assertThat(entity.getTpLagId()).isNotNull().isEqualTo(tpID);
    }

    @Test
    public void testGetLacp() throws Exception {
        assertThat(entity.getLacp()).isNull();
        LacpLocal lacp = new LacpLocal();
        lacp.setWaitTime(120);
        entity = builder.lacp(lacp).build();
        assertThat(entity.getLacp()).isNotNull().isEqualTo(lacp);
    }

    @Test
    public void testGetLacpRemote() throws Exception {
        assertThat(entity.getLacpRemote()).isNull();
        LacpRemote lacpRemote = new LacpRemote();
        lacpRemote.setPortPriority(10);
        entity = builder.lacpRemote(lacpRemote).build();
        assertThat(entity.getLacpRemote()).isNotNull().isEqualTo(lacpRemote);
    }

}
