package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.SystemContainerID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class SystemContainerTest extends BaseEntityTest<SystemContainerID, SystemContainer, SystemContainer.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.SYSTEM_CONTAINER;
        id = new SystemContainerID.Builder(KEY, SYSTEM_CONTAINER_ID).build();
        builder = new SystemContainer.Builder(id);
        entity = builder.build();

        invalidBuilder = new SystemContainer.Builder(null);
    }

    @Test
    public void testGetDescription() throws Exception {
        assertThat(entity.getDescription()).isNull();
        String description = "Description";
        entity = builder.description(description).build();
        assertThat(entity.getDescription()).isNotNull().isEqualTo(description);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
