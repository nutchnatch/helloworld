package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.fault.enumerable.FaultCondition;
import java.util.Date;
import org.junit.Test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
public class AlarmTest {

    @Test
    public void shouldCreateAlarm(){
        AlarmID alarmId = new AlarmID.Builder(1L).build();
        Alarm alarm = new Alarm.Builder(alarmId).build();

        assertNotNull(alarm);
        assertEquals(1L, alarm.getID().getId());
    }

    @Test
    public void shouldCreateAlarmWithFields(){
        Date now = new Date();

        AlarmID alarmId = new AlarmID.Builder(1L).build();
        Alarm alarm = new Alarm.Builder(alarmId)
                .alarmClass("AlarmClass")
                .alarmSeverity(AlarmSeverity.CRITICAL)
                .faultCondition(FaultCondition.DISABLING_ALL_TRAFFIC)
                .probableCause("LOC")
                .timestamp(now)
                .build();

        assertNotNull(alarm);
        assertEquals(1L, alarm.getID().getId());
        assertEquals("AlarmClass", alarm.getAlarmClass());
        assertEquals(AlarmSeverity.CRITICAL, alarm.getAlarmSeverity());
        assertEquals(FaultCondition.DISABLING_ALL_TRAFFIC, alarm.getFaultCondition());
        assertEquals("LOC", alarm.getProbableCause());
        assertEquals(now, alarm.getTimestamp());


    }

}
