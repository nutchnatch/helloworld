package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.LAGModeType;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 14-09-2016.
 */
public class TpLagTest {

    private TpLag entity;
    private static final TpLag.Builder builder = new TpLag.Builder();

    @Before
    public void setUp() throws Exception {
        entity = builder.build();
        assertThat(builder).isNotNull();
        assertThat(entity).isNotNull();
    }

    @Test
    public void testGetLagMode() throws Exception {
        assertThat(entity.getLagMode()).isNull();
        LAGModeType lagMode = LAGModeType.LACP;
        entity = builder.lagMode(lagMode).build();
        assertThat(entity.getLagMode()).isNotNull().isEqualTo(lagMode);
    }

    @Test
    public void testGetActiveMembersThreshold() throws Exception {
        assertThat(entity.getActiveMembersThreshold()).isNull();
        Integer activeMembersThreshold = 2;
        entity = builder.activeMembersThreshold(activeMembersThreshold).build();
        assertThat(entity.getActiveMembersThreshold()).isNotNull().isEqualTo(activeMembersThreshold);
    }

    @Test
    public void testGetAllowedActiveMembers() throws Exception {
        assertThat(entity.getAllowedActiveMembers()).isNull();
        Integer allowedActiveMembers = 12;
        entity = builder.allowedActiveMembers(allowedActiveMembers).build();
        assertThat(entity.getAllowedActiveMembers()).isNotNull().isEqualTo(allowedActiveMembers);
    }

    @Test
    public void testGetCurrentActiveMembers() throws Exception {
        assertThat(entity.getCurrentActiveMembers()).isNull();
        Integer currentActiveMembers = 5;
        entity = builder.currentActiveMembers(currentActiveMembers).build();
        assertThat(entity.getCurrentActiveMembers()).isNotNull().isEqualTo(currentActiveMembers);
    }

    @Test
    public void testGetAllowedStandbyMembers() throws Exception {
        assertThat(entity.getAllowedStandbyMembers()).isNull();
        Integer allowedStandbyMembers = 3;
        entity = builder.allowedStandbyMembers(allowedStandbyMembers).build();
        assertThat(entity.getAllowedStandbyMembers()).isNotNull().isEqualTo(allowedStandbyMembers);
    }

    @Test
    public void testGetCurrentStandbyMembers() throws Exception {
        assertThat(entity.getCurrentStandbyMembers()).isNull();
        Integer currentStandbyMembers = 4;
        entity = builder.currentStandbyMembers(currentStandbyMembers).build();
        assertThat(entity.getCurrentStandbyMembers()).isNotNull().isEqualTo(currentStandbyMembers);
    }

    @Test
    public void testGetNumberOfMembers() throws Exception {
        assertThat(entity.getNumberOfMembers()).isNull();
        Integer numberOfMembers = 8;
        entity = builder.numberOfMembers(numberOfMembers).build();
        assertThat(entity.getNumberOfMembers()).isNotNull().isEqualTo(numberOfMembers);
    }

    @Test
    public void testGetLagId() throws Exception {
        assertThat(entity.getLagId()).isNull();
        Integer lagId = 201;
        entity = builder.lagId(lagId).build();
        assertThat(entity.getLagId()).isNotNull().isEqualTo(lagId);
    }

    @Test
    public void testGetSystemId() throws Exception {
        assertThat(entity.getSystemId()).isNull();
        String systemId = "System-ID";
        entity = builder.systemId(systemId).build();
        assertThat(entity.getSystemId()).isNotNull().isEqualTo(systemId);
    }

    @Test
    public void testGetSystemPriority() throws Exception {
        assertThat(entity.getSystemPriority()).isNull();
        Integer systemPriority = 1;
        entity = builder.systemPriority(systemPriority).build();
        assertThat(entity.getSystemPriority()).isNotNull().isEqualTo(systemPriority);
    }


    @Test
    public void testGetLagLacpRemote() throws Exception {
        assertThat(entity.getLagLacpRemote()).isNull();
        LagLacp lagLacpRemote = new LagLacp.Builder().build();
        entity = builder.lagLacpRemote(lagLacpRemote).build();
        assertThat(entity.getLagLacpRemote()).isNotNull().isEqualTo(lagLacpRemote);
    }

    @Test
    public void testGetLacp() throws Exception {
        assertThat(entity.getLacp()).isNull();
        LacpLocal lacp = new LacpLocal();
        entity = builder.lacp(lacp).build();
        assertThat(entity.getLacp()).isNotNull().isEqualTo(lacp);

    }
}
