package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.PacketInterfaceType;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 14-09-2016.
 */
public class TpEthernetTest {

    private TpEthernet entity;
    private static final TpEthernet.Builder builder = new TpEthernet.Builder();

    @Before
    public void setUp() throws Exception {
        entity = builder.build();
        assertThat(builder).isNotNull();
        assertThat(entity).isNotNull();
    }

    @Test
    public void testGetMtuSize() throws Exception {
        assertThat(entity.getMtuSize()).isNull();
        Integer mtuSize = 10;
        entity = builder.mtuSize(mtuSize).build();
        assertThat(entity.getMtuSize()).isNotNull().isEqualTo(mtuSize);
    }

    @Test
    public void testGetEthernetType() throws Exception {
        assertThat(entity.getEthernetType()).isNull();
        Integer ethernetType = 10;
        entity = builder.ethernetType(ethernetType).build();
        assertThat(entity.getEthernetType()).isNotNull().isEqualTo(ethernetType);
    }

    @Test
    public void testGetPolicyMapIN() throws Exception {
        assertThat(entity.getPolicyMapIN()).isNull();
        String policyMapIN = "Policy-Map-IN";
        entity = builder.policyMapIN(policyMapIN).build();
        assertThat(entity.getPolicyMapIN()).isNotNull().isEqualTo(policyMapIN);
    }

    @Test
    public void testGetPolicyMapOUT() throws Exception {
        assertThat(entity.getPolicyMapOUT()).isNull();
        String policyMapOUT = "Policy-Map-OUT";
        entity = builder.policyMapOUT(policyMapOUT).build();
        assertThat(entity.getPolicyMapOUT()).isNotNull().isEqualTo(policyMapOUT);
    }

    @Test
    public void testGetMacAddress() throws Exception {
        assertThat(entity.getMacAddress()).isNull();
        String macAddress = "MAC-Address";
        entity = builder.macAddress(macAddress).build();
        assertThat(entity.getMacAddress()).isNotNull().isEqualTo(macAddress);
    }

    @Test
    public void testGetInterfaceType() throws Exception {
        assertThat(entity.getInterfaceType()).isNull();
        PacketInterfaceType interfaceType = PacketInterfaceType.ENNI;
        entity = builder.interfaceType(interfaceType).build();
        assertThat(entity.getInterfaceType()).isNotNull().isEqualTo(interfaceType);
    }

    @Test
    public void testGetBandwidth() throws Exception {
        assertThat(entity.getBandwidth()).isNull();
        Float bandwidth = 196.100f;
        entity = builder.bandwidth(bandwidth).build();
        assertThat(entity.getBandwidth()).isNotNull().isEqualTo(bandwidth);
    }

    @Test
    public void testGetSubsysId() throws Exception {
        assertThat(entity.getSubsysId()).isNull();
        Integer subsysId = 10;
        entity = builder.subsysId(subsysId).build();
        assertThat(entity.getSubsysId()).isNotNull().isEqualTo(subsysId);
    }

    @Test
    public void testGetBridgeId() throws Exception {
        assertThat(entity.getBridgeId()).isNull();
        Integer bridgeId = 100;
        entity = builder.bridgeId(bridgeId).build();
        assertThat(entity.getBridgeId()).isNotNull().isEqualTo(bridgeId);
    }

    @Test
    public void testGetAllToOneBundling() throws Exception {
        assertThat(entity.getAllToOneBundling()).isNull();
        Boolean allToOneBundling = Boolean.FALSE;
        entity = builder.allToOneBundling(allToOneBundling).build();
        assertThat(entity.getAllToOneBundling()).isNotNull().isEqualTo(allToOneBundling);
    }

}
