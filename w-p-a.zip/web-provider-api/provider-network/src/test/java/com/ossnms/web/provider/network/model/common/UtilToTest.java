package com.ossnms.web.provider.network.model.common;

import com.ossnms.web.provider.network.model.network.id.PhysicalTerminationPointID;
import com.ossnms.web.provider.network.model.network.id.TerminationPointID;

/**
 * Created on 12-09-2016.
 */
public abstract class UtilToTest {

    protected static final String KEY = "KEY";
    protected static final Integer CONTAINER_ID = 12;
    protected static final Integer SYSTEM_CONTAINER_ID = 2;
    protected static final Integer NE_ID = 2000;
    protected static final Integer EH_ID = 101;
    protected static final Integer EQ_ID = 10101;
    protected static final Integer PTP_ID = 10101001;
    protected static final Long TP_ID = 101010010001L;

    protected static final Integer SUBSYS_ID = 7;
    protected static final Long CONTEXT_ID = 700000007L;
    protected static final Integer BRIDGE_ID = 70;
    protected static final Integer NETWORK_SV_LAN = 100;
    protected static final Integer NETWORK_CV_LAN = 600;

    protected static final PhysicalTerminationPointID PTP_END_A = new PhysicalTerminationPointID.Builder("", NE_ID, PTP_ID).build();
    protected static final PhysicalTerminationPointID PTP_END_Z = new PhysicalTerminationPointID.Builder("", NE_ID, PTP_ID * 5).build();

    protected static final TerminationPointID TP_END_A = new TerminationPointID.Builder("", NE_ID, PTP_ID, TP_ID).build();
    protected static final TerminationPointID TP_END_Z = new TerminationPointID.Builder("", NE_ID, PTP_ID * 2, TP_ID * 2).build();
    protected static final TerminationPointID TP_END_P = new TerminationPointID.Builder("", NE_ID, PTP_ID * 3, TP_ID * 3).build();

    protected static final Integer ALARMS_SUMMARY_ID = 10203040;

}
