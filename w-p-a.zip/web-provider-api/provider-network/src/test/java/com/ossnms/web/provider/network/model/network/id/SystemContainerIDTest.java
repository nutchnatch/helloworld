package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 09-09-2016.
 */
public class SystemContainerIDTest extends BaseEntityIDTest<SystemContainerID, SystemContainerID.Builder> {

    @Before
    public void setUp() throws Exception {
        builder = new SystemContainerID.Builder(KEY, SYSTEM_CONTAINER_ID);
        id = builder.build();
    }

    @Test
    public void testGetSystemContainerId() throws Exception {
        assertThat(id.getSystemContainerId()).isNotNull().isEqualTo(SYSTEM_CONTAINER_ID);
    }

    @Test
    public void testBuildWithExceptionDueSYSTEM_CONTAINER_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(SystemContainerID.Builder.EXCEPTION_MESSAGE_SYSTEM_CONTAINER_ID);
        new SystemContainerID.Builder(KEY, null).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(SYSTEM_CONTAINER_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, SYSTEM_CONTAINER_ID).build())).isFalse();
        assertThat(id.equals(new ContainerID.Builder(KEY, SYSTEM_CONTAINER_ID).build())).isFalse();
        assertThat(id.equals(new SystemContainerID.Builder(KEY, SYSTEM_CONTAINER_ID).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
