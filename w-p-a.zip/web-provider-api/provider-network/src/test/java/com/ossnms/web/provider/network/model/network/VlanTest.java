package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.enumerable.VlanType;
import com.ossnms.web.provider.network.model.network.id.VlanID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class VlanTest extends BaseEntityTest<VlanID, Vlan, Vlan.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.VLAN;
        id = new VlanID.Builder(KEY, TP_END_A, SUBSYS_ID, NETWORK_SV_LAN, NETWORK_CV_LAN, VlanType.BRIDGING).build();
        builder = new Vlan.Builder(id);
        entity = builder.build();

        invalidBuilder = new Vlan.Builder(null);
    }

    @Test
    public void testGetCustomerSVlan() throws Exception {
        assertThat(entity.getCustomerSVlan()).isNull();
        Integer customerSVlan = 200;
        entity = builder.customerSVlan(customerSVlan).build();
        assertThat(entity.getCustomerSVlan()).isNotNull().isEqualTo(customerSVlan);
    }

    @Test
    public void testGetCustomerCVlan() throws Exception {
        assertThat(entity.getCustomerCVlan()).isNull();
        Integer customerCVlan = 500;
        entity = builder.customerCVlan(customerCVlan).build();
        assertThat(entity.getCustomerCVlan()).isNotNull().isEqualTo(customerCVlan);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
