package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 13-09-2016.
 */
public class TopologicalLinkIDTest extends BaseEntityIDTest<TopologicalLinkID, TopologicalLinkID.Builder> {

    private static final PhysicalTerminationPointID PTP_END_Z = new PhysicalTerminationPointID.Builder("", PTP_END_A.getNeId() + 1, PTP_ID * 5).build();

    @Before
    public void setUp() throws Exception {
        builder = new TopologicalLinkID.Builder(KEY, PTP_END_A, PTP_END_Z);
        id = builder.build();
    }

    @Test
    public void testGetPtpEndA() throws Exception {
        assertThat(id.getPtpEndA()).isNotNull().isEqualTo(PTP_END_A);
    }

    @Test
    public void testGetPtpEndZ() throws Exception {
        assertThat(id.getPtpEndZ()).isNotNull().isEqualTo(PTP_END_Z);
    }

    @Test
    public void testBuildWithExceptionDuePTP_END_A() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(TopologicalLinkID.Builder.EXCEPTION_MESSAGE_PTP_END_A);
        new TopologicalLinkID.Builder(KEY, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDuePTP_END_Z() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(TopologicalLinkID.Builder.EXCEPTION_MESSAGE_PTP_END_Z);
        new TopologicalLinkID.Builder(KEY, PTP_END_A, null).build();
    }

    @Test
    public void testBuildWithExceptionDueNE_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(TopologicalLinkID.Builder.EXCEPTION_MESSAGE_NE_ID);
        new TopologicalLinkID.Builder(KEY, PTP_END_A, PTP_END_A).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(NE_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new ContainerID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new EquipmentHolderID.Builder(KEY, NE_ID, EQ_ID).build())).isFalse();
        assertThat(id.equals(new TopologicalLinkID.Builder(KEY, PTP_END_A, PTP_END_Z).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
