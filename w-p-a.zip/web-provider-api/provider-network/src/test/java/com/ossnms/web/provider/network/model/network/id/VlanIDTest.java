package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import com.ossnms.web.provider.network.model.network.enumerable.VlanType;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class VlanIDTest extends BaseEntityIDTest<VlanID, VlanID.Builder> {

    private static final VlanType TYPE = VlanType.BRIDGING;

    @Before
    public void setUp() throws Exception {
        builder = new VlanID.Builder(KEY, TP_END_A, SUBSYS_ID, NETWORK_SV_LAN, NETWORK_CV_LAN, TYPE);
        id = builder.build();
    }

    @Test
    public void testGetTpEndId() throws Exception {
        assertThat(id.getTpEndId()).isNotNull().isEqualTo(TP_END_A);
    }

    @Test
    public void testGetSubsysId() throws Exception {
        assertThat(id.getSubsysId()).isNotNull().isEqualTo(SUBSYS_ID);
    }

    @Test
    public void testGetNetworkSVlan() throws Exception {
        assertThat(id.getNetworkSVlan()).isNotNull().isEqualTo(NETWORK_SV_LAN);
    }

    @Test
    public void testGetNetworkCVlan() throws Exception {
        assertThat(id.getNetworkCVlan()).isNotNull().isEqualTo(NETWORK_CV_LAN);
    }

    @Test
    public void testGetVlanType() throws Exception {
        assertThat(id.getVlanType()).isNotNull().isEqualTo(TYPE);
    }

    @Test
    public void testBuildWithExceptionDueTP_END_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(VlanID.Builder.EXCEPTION_MESSAGE_TP_END_ID);
        new VlanID.Builder(KEY, null, null, null, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueSUBSYS_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(VlanID.Builder.EXCEPTION_MESSAGE_SUBSYS_ID);
        new VlanID.Builder(KEY, TP_END_A, null, null, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueNETWORK_SV_LAN() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(VlanID.Builder.EXCEPTION_MESSAGE_NETWORK_SV_LAN);
        new VlanID.Builder(KEY, TP_END_A, SUBSYS_ID, null, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueNETWORK_CV_LAN() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(VlanID.Builder.EXCEPTION_MESSAGE_NETWORK_CV_LAN);
        new VlanID.Builder(KEY, TP_END_A, SUBSYS_ID, NETWORK_SV_LAN, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueVLAN_TYPE() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(VlanID.Builder.EXCEPTION_MESSAGE_VLAN_TYPE);
        new VlanID.Builder(KEY, TP_END_A, SUBSYS_ID, NETWORK_SV_LAN, NETWORK_CV_LAN, null).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(NE_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new ContainerID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new EquipmentHolderID.Builder(KEY, NE_ID, EQ_ID).build())).isFalse();
        assertThat(id.equals(new PhysicalTerminationPointID.Builder(KEY, NE_ID, PTP_ID).eqId(EQ_ID).build())).isFalse();
        assertThat(id.equals(new TerminationPointID.Builder(KEY, NE_ID, PTP_ID, TP_ID).build())).isFalse();


        assertThat(id.equals(new VlanID.Builder(KEY, TP_END_A, SUBSYS_ID, NETWORK_SV_LAN, NETWORK_CV_LAN, TYPE).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
