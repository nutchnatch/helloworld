package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.*;
import com.ossnms.web.provider.network.model.network.id.TerminationPointID;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 13-09-2016.
 */
public class TerminationPointTest extends BaseEntityTest<TerminationPointID, TerminationPoint, TerminationPoint.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.TERMINATION_POINT;
        id = new TerminationPointID.Builder(KEY, NE_ID, PTP_ID, TP_ID).build();
        builder = new TerminationPoint.Builder(id);
        entity = builder.build();

        invalidBuilder = new TerminationPoint.Builder(null);
    }

    @Test
    public void testGetTerminationMode() throws Exception {
        assertThat(entity.getTerminationMode()).isNull();
        TerminationModeType terminationMode = TerminationModeType.TERMINATED;
        entity = builder.terminationMode(terminationMode).build();
        assertThat(entity.getTerminationMode()).isNotNull().isEqualTo(terminationMode);
    }

    @Test
    public void testGetOperationalState() throws Exception {
        assertThat(entity.getOperationalState()).isNull();
        OperationalState operationalState = OperationalState.PROTECTION_DISTURBED;
        entity = builder.operationalState(operationalState).build();
        assertThat(entity.getOperationalState()).isNotNull().isEqualTo(operationalState);
    }

    @Test
    public void testGetAdministrativeState() throws Exception {
        assertThat(entity.getAdministrativeState()).isNull();
        AdministrativeStateType administrativeState = AdministrativeStateType.UNLOCKED;
        entity = builder.administrativeState(administrativeState).build();
        assertThat(entity.getAdministrativeState()).isNotNull().isEqualTo(administrativeState);
    }

    @Test
    public void testGetTerminatedLayers() throws Exception {
        assertThat(entity.getTerminatedLayers()).isNull();
        List<String> terminatedLayers = new ArrayList<>();
        terminatedLayers.add("TL_1");
        terminatedLayers.add("TL_2");
        entity = builder.terminatedLayers(terminatedLayers).build();
        assertThat(entity.getTerminatedLayers()).isNotNull().isNotEmpty().hasSize(terminatedLayers.size()).containsAll(terminatedLayers);
    }

    @Test
    public void testGetNonTerminatedLayers() throws Exception {
        assertThat(entity.getNonTerminatedLayers()).isNull();
        List<String> nonTerminatedLayers = new ArrayList<>();
        nonTerminatedLayers.add("TL_5");
        nonTerminatedLayers.add("TL_4");
        entity = builder.nonTerminatedLayers(nonTerminatedLayers).build();
        assertThat(entity.getNonTerminatedLayers()).isNotNull().isNotEmpty().hasSize(nonTerminatedLayers.size()).containsAll(nonTerminatedLayers);
    }

    @Test
    public void testGetIndex() throws Exception {
        assertThat(entity.getIndex()).isNull();
        Long index = 1000000L;
        entity = builder.index(index).build();
        assertThat(entity.getIndex()).isNotNull().isEqualTo(index);
    }

    @Test
    public void testGetChannel() throws Exception {
        assertThat(entity.getChannel()).isNull();
        Integer channel = 86;
        entity = builder.channel(channel).build();
        assertThat(entity.getChannel()).isNotNull().isEqualTo(channel);
    }

    @Test
    public void testGetObjectType() throws Exception {
        assertThat(entity.getObjectType()).isNull();
        String objectType = "Object-Type";
        entity = builder.objectType(objectType).build();
        assertThat(entity.getObjectType()).isNotNull().isEqualTo(objectType);
    }

    @Test
    public void testGetResourceUsageSink() throws Exception {
        assertThat(entity.getResourceUsageSink()).isNull();
        ResourceUsageType resourceUsage = ResourceUsageType.UNUSED;
        entity = builder.resourceUsageSink(resourceUsage).build();
        assertThat(entity.getResourceUsageSink()).isNotNull().isEqualTo(resourceUsage);
    }

    @Test
    public void testGetResourceUsageSource() throws Exception {
        assertThat(entity.getResourceUsageSource()).isNull();
        ResourceUsageType resourceUsage = ResourceUsageType.USED;
        entity = builder.resourceUsageSource(resourceUsage).build();
        assertThat(entity.getResourceUsageSource()).isNotNull().isEqualTo(resourceUsage);
    }

    @Test
    public void testGetTrailIdentifierSink() throws Exception {
        assertThat(entity.getTrailIdentifierSink()).isNull();
        String trailIdentifier = "Trail-Identifier-Sink";
        entity = builder.trailIdentifierSink(trailIdentifier).build();
        assertThat(entity.getTrailIdentifierSink()).isNotNull().isEqualTo(trailIdentifier);
    }

    @Test
    public void testGetTrailIdentifierSource() throws Exception {
        assertThat(entity.getTrailIdentifierSource()).isNull();
        String trailIdentifier = "Trail-Identifier-Source";
        entity = builder.trailIdentifierSource(trailIdentifier).build();
        assertThat(entity.getTrailIdentifierSource()).isNotNull().isEqualTo(trailIdentifier);
    }

    @Test
    public void testGetFecEnabled() throws Exception {
        assertThat(entity.getFecEnabled()).isNull();
        Boolean fecEnabled = Boolean.TRUE;
        entity = builder.fecEnabled(fecEnabled).build();
        assertThat(entity.getFecEnabled()).isNotNull().isEqualTo(fecEnabled);
    }

    @Test
    public void testGetFecMode() throws Exception {
        assertThat(entity.getFecMode()).isNull();
        FECModeType fecMode = FECModeType.NOFEC;
        entity = builder.fecMode(fecMode).build();
        assertThat(entity.getFecMode()).isNotNull().isEqualTo(fecMode);
    }

    @Test
    public void testGetNativeLocation() throws Exception {
        assertThat(entity.getNativeLocation()).isNull();
        String nativeLocation = "Native-Location";
        entity = builder.nativeLocation(nativeLocation).build();
        assertThat(entity.getNativeLocation()).isNotNull().isEqualTo(nativeLocation);
    }

    @Test
    public void testGetPresenceState() throws Exception {
        assertThat(entity.getPresenceState()).isNull();
        PresenceState presenceState = PresenceState.AUTO_IN_SERVICE;
        entity = builder.presenceState(presenceState).build();
        assertThat(entity.getPresenceState()).isNotNull().isEqualTo(presenceState);
    }

    @Test
    public void testGetTemplate() throws Exception {
        assertThat(entity.getTemplate()).isNull();
        Boolean template = Boolean.FALSE;
        entity = builder.template(template).build();
        assertThat(entity.getTemplate()).isNotNull().isEqualTo(template);
    }

    @Test
    public void testGetEthernet() throws Exception {
        assertThat(entity.getEthernet()).isNull();
        TpEthernet ethernet = new TpEthernet.Builder().subsysId(1).build();
        entity = builder.ethernet(ethernet).build();
        assertThat(entity.getEthernet()).isNotNull().isEqualTo(ethernet);
    }

    @Test
    public void testGetLag() throws Exception {
        assertThat(entity.getLag()).isNull();
        TpLag lag = new TpLag.Builder().lagId(101).build();
        entity = builder.lag(lag).build();
        assertThat(entity.getLag()).isNotNull().isEqualTo(lag);
    }

    @Test
    public void testGetLagMember() throws Exception {
        assertThat(entity.getLagMember()).isNull();
        TpLagMember lagMember = new TpLagMember.Builder(null).build();
        entity = builder.lagMember(lagMember).build();
        assertThat(entity.getLagMember()).isNotNull().isEqualTo(lagMember);
    }

    @Test
    public void testCopy() throws Exception {
        TerminationPoint.Builder tpBuilder = builder.copy(entity);
        TerminationPoint copyEntity = tpBuilder.build();
        assertThat(copyEntity).isNotNull().isEqualTo(entity);
        assertThat(copyEntity).isNotNull().isNotSameAs(entity);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
