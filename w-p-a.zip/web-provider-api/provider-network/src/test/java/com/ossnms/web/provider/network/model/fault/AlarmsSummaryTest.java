package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 13-09-2016.
 */
public class AlarmsSummaryTest extends BaseEntityTest<AlarmsSummaryID, AlarmsSummary, AlarmsSummary.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.ALARMS_SUMMARY;
        id = new AlarmsSummaryID.Builder(KEY, ALARMS_SUMMARY_ID).build();
        builder = new AlarmsSummary.Builder(id);
        entity = builder.build();

        invalidBuilder = new AlarmsSummary.Builder(null);
    }

    @Test
    public void testGetHighestAlarmSeverity() throws Exception {
        assertThat(entity.getHighestAlarmSeverity()).isNull();
        AlarmSeverity alarmSeverity = AlarmSeverity.MAJOR;
        entity = builder.highestAlarmSeverity(alarmSeverity).build();
        assertThat(entity.getHighestAlarmSeverity()).isNotNull().isEqualTo(alarmSeverity);
    }

    @Test
    public void testGetAlarmsAcknowledged() throws Exception {
        assertThat(entity.getAlarmsAcknowledged()).isNull();
        Boolean alarmsAcknowledged = Boolean.TRUE;
        entity = builder.alarmsAcknowledged(alarmsAcknowledged).build();
        assertThat(entity.getAlarmsAcknowledged()).isNotNull().isEqualTo(alarmsAcknowledged);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
