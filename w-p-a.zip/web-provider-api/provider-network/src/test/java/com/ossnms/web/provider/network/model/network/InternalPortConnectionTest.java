package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.Direction;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.InternalPortConnectionID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 13-09-2016.
 */
public class InternalPortConnectionTest extends BaseEntityTest<InternalPortConnectionID, InternalPortConnection, InternalPortConnection.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.INTERNAL_PORT_CONNECTION;
        id = new InternalPortConnectionID.Builder(KEY, PTP_END_A, PTP_END_Z).build();
        builder = new InternalPortConnection.Builder(id);
        entity = builder.build();

        invalidBuilder = new InternalPortConnection.Builder(null);
    }

    @Test
    public void testGetDirection() throws Exception {
        assertThat(entity.getDirection()).isNull();
        Direction direction = Direction.BIDIRECTIONAL;
        entity = builder.direction(direction).build();
        assertThat(entity.getDirection()).isNotNull().isEqualTo(direction);
    }

    @Test
    public void testGetaEndOperationalState() throws Exception {
        assertThat(entity.getaEndOperationalState()).isNull();
        OperationalState operationalState = OperationalState.DEGRADED;
        entity = builder.aEndOperationalState(operationalState).build();
        assertThat(entity.getaEndOperationalState()).isNotNull().isEqualTo(operationalState);
    }

    @Test
    public void testGetzEndOperationalState() throws Exception {
        assertThat(entity.getzEndOperationalState()).isNull();
        OperationalState operationalState = OperationalState.NOT_APPLICABLE;
        entity = builder.zEndOperationalState(operationalState).build();
        assertThat(entity.getzEndOperationalState()).isNotNull().isEqualTo(operationalState);
    }

    @Test
    public void testGetaEndName() throws Exception {
        assertThat(entity.getaEndName()).isNull();
        String name = "A-End-Name";
        entity = builder.aEndName(name).build();
        assertThat(entity.getaEndName()).isNotNull().isEqualTo(name);
    }

    @Test
    public void testGetzEndName() throws Exception {
        assertThat(entity.getzEndName()).isNull();
        String name = "Z-End-Name";
        entity = builder.zEndName(name).build();
        assertThat(entity.getzEndName()).isNotNull().isEqualTo(name);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
