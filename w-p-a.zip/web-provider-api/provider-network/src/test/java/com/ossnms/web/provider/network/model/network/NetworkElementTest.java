package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.enumerable.InitStateType;
import com.ossnms.web.provider.network.model.network.enumerable.NeActivationStateType;
import com.ossnms.web.provider.network.model.network.enumerable.NeFamilyType;
import com.ossnms.web.provider.network.model.network.id.NetworkElementID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class NetworkElementTest extends BaseEntityTest<NetworkElementID, NetworkElement, NetworkElement.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.NETWORK_ELEMENT;
        id = new NetworkElementID.Builder(KEY, NE_ID).build();
        builder = new NetworkElement.Builder(id);
        entity = builder.build();

        invalidBuilder = new NetworkElement.Builder(null);
    }

    @Test
    public void testGetSystemContainerId() {
        assertThat(entity.getSystemContainerId()).isNull();
        entity = builder.systemContainerId(SYSTEM_CONTAINER_ID).build();
        assertThat(entity.getSystemContainerId()).isNotNull().isEqualTo(SYSTEM_CONTAINER_ID);
    }

    @Test
    public void testGetNeType() throws Exception {
        assertThat(entity.getNeType()).isNull();
        String neType = "NE-Type";
        entity = builder.neType(neType).build();
        assertThat(entity.getNeType()).isNotNull().isEqualTo(neType);
    }

    @Test
    public void testGetCommunicationState() throws Exception {
        assertThat(entity.getCommunicationState()).isNull();
        String communicationState = "Communication-State";
        entity = builder.communicationState(communicationState).build();
        assertThat(entity.getCommunicationState()).isNotNull().isEqualTo(communicationState);
    }

    @Test
    public void testGetIsGateway() throws Exception {
        assertThat(entity.getIsGateway()).isNull();
        Boolean isGateway = Boolean.FALSE;
        entity = builder.isGateway(isGateway).build();
        assertThat(entity.getIsGateway()).isNotNull().isEqualTo(isGateway);
    }

    @Test
    public void testGetActivationState() throws Exception {
        assertThat(entity.getActivationState()).isNull();
        InitStateType activationState = InitStateType.INITIALIZED;
        entity = builder.activationState(activationState).build();
        assertThat(entity.getActivationState()).isNotNull().isEqualTo(activationState);
    }

    @Test
    public void testGetNeActivationState() throws Exception {
        assertThat(entity.getNeActivationState()).isNull();
        NeActivationStateType neActivationState = NeActivationStateType.ACTIVE;
        entity = builder.neActivationState(neActivationState).build();
        assertThat(entity.getNeActivationState()).isNotNull().isEqualTo(neActivationState);
    }

    @Test
    public void testGetMaintenanceMode() throws Exception {
        assertThat(entity.getMaintenanceMode()).isNull();
        String maintenanceMode = "Maintenance-Mode";
        entity = builder.maintenanceMode(maintenanceMode).build();
        assertThat(entity.getMaintenanceMode()).isNotNull().isEqualTo(maintenanceMode);
    }

    @Test
    public void testGetSoftwareVersion() throws Exception {
        assertThat(entity.getSoftwareVersion()).isNull();
        String softwareVersion = "Software-Version";
        entity = builder.softwareVersion(softwareVersion).build();
        assertThat(entity.getSoftwareVersion()).isNotNull().isEqualTo(softwareVersion);
    }

    @Test
    public void testGetNeFamily() throws Exception {
        assertThat(entity.getNeFamily()).isNull();
        NeFamilyType neFamily = NeFamilyType.MTERA;
        entity = builder.neFamily(neFamily).build();
        assertThat(entity.getNeFamily()).isNotNull().isEqualTo(neFamily);
    }

    @Test
    public void testGetNeTypeIcon() throws Exception {
        assertThat(entity.getNeTypeIcon()).isNull();
        String neTypeIcon = "NE-Type-Icon";
        entity = builder.neTypeIcon(neTypeIcon).build();
        assertThat(entity.getNeTypeIcon()).isNotNull().isEqualTo(neTypeIcon);
    }

    @Test
    public void testGetLagManagement() throws Exception {
        assertThat(entity.getLagManagement()).isNull();
        Boolean lagManagement = Boolean.TRUE;
        entity = builder.lagManagement(lagManagement).build();
        assertThat(entity.getLagManagement()).isNotNull().isEqualTo(lagManagement);
    }

    @Test
    public void testGetGeoLocation() throws Exception {
        assertThat(entity.getGeoLocation()).isNull();
        GeoLocation geoLocation = new GeoLocation(12.00, 2.00);
        entity = builder.geoLocation(geoLocation).build();
        assertThat(entity.getGeoLocation()).isNotNull().isEqualTo(geoLocation);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
