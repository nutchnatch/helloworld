package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.ContainerID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class ContainerTest extends BaseEntityTest<ContainerID, Container, Container.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.CONTAINER;
        id = new ContainerID.Builder(KEY, CONTAINER_ID).build();
        builder = new Container.Builder(id);
        entity = builder.build();

        invalidBuilder = new Container.Builder(null);
    }

    @Test
    public void testGetDescription() throws Exception {
        assertThat(entity.getDescription()).isNull();
        String description = "Description";
        entity = builder.description(description).build();
        assertThat(entity.getDescription()).isNotNull().isEqualTo(description);
    }

    @Test
    public void testGetParentContainerId() throws Exception {
        assertThat(entity.getParentContainerId()).isNull();
        entity = builder.parentContainerId(CONTAINER_ID).build();
        assertThat(entity.getParentContainerId()).isNotNull().isEqualTo(CONTAINER_ID);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
