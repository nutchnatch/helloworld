package com.ossnms.web.provider.network.model.network;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 14-09-2016.
 */
public class LagLacpTest {

    private LagLacp entity;
    private static final LagLacp.Builder builder = new LagLacp.Builder();

    @Before
    public void setUp() throws Exception {
        entity = builder.build();
        assertThat(builder).isNotNull();
        assertThat(entity).isNotNull();
    }

    @Test
    public void testGetLagId() throws Exception {
        assertThat(entity.getLagId()).isNull();
        Integer lagId = 201;
        entity = builder.lagId(lagId).build();
        assertThat(entity.getLagId()).isNotNull().isEqualTo(lagId);
    }

    @Test
    public void testGetSystemId() throws Exception {
        assertThat(entity.getSystemId()).isNull();
        String systemId = "System-ID";
        entity = builder.systemId(systemId).build();
        assertThat(entity.getSystemId()).isNotNull().isEqualTo(systemId);
    }

    @Test
    public void testGetSystemPriority() throws Exception {
        assertThat(entity.getSystemPriority()).isNull();
        Integer systemPriority = 1;
        entity = builder.systemPriority(systemPriority).build();
        assertThat(entity.getSystemPriority()).isNotNull().isEqualTo(systemPriority);
    }

}
