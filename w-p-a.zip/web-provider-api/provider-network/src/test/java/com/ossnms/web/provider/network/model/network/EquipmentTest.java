package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.EquipmentID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class EquipmentTest extends BaseEntityTest<EquipmentID, Equipment, Equipment.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.EQUIPMENT;
        id = new EquipmentID.Builder(KEY, NE_ID, EQ_ID).build();
        builder = new Equipment.Builder(id);
        entity = builder.build();

        invalidBuilder = new Equipment.Builder(null);
    }

    @Test
    public void testGetEquipmentHolderId() throws Exception {
        assertThat(entity.getEquipmentHolderId()).isNull();
        entity = builder.equipmentHolderId(EH_ID).build();
        assertThat(entity.getEquipmentHolderId()).isNotNull().isEqualTo(EH_ID);
    }

    @Test
    public void testGetParentEquipmentId() throws Exception {
        assertThat(entity.getParentEquipmentId()).isNull();
        entity = builder.parentEquipmentId(EQ_ID).build();
        assertThat(entity.getParentEquipmentId()).isNotNull().isEqualTo(EQ_ID);
    }

    @Test
    public void testGetActualShelfType() throws Exception {
        assertThat(entity.getActualCardType()).isNull();
        String actualCardType = "Actual-Card-Type";
        entity = builder.actualCardType(actualCardType).build();
        assertThat(entity.getActualCardType()).isNotNull().isEqualTo(actualCardType);
    }

    @Test
    public void testGetRequiredShelfType() throws Exception {
        assertThat(entity.getRequiredCardType()).isNull();
        String requiredCardType = "Required-Card-Type";
        entity = builder.requiredCardType(requiredCardType).build();
        assertThat(entity.getRequiredCardType()).isNotNull().isEqualTo(requiredCardType);
    }

    @Test
    public void testGetPartNumber() throws Exception {
        assertThat(entity.getPartNumber()).isNull();
        String partNumber = "Part-Number";
        entity = builder.partNumber(partNumber).build();
        assertThat(entity.getPartNumber()).isNotNull().isEqualTo(partNumber);
    }

    @Test
    public void testGetOperationalState() throws Exception {
        assertThat(entity.getOperationalState()).isNull();
        OperationalState operationalState = OperationalState.ENABLED;
        entity = builder.operationalState(operationalState).build();
        assertThat(entity.getOperationalState()).isNotNull().isEqualTo(operationalState);
    }

    @Test
    public void testGetDirection() throws Exception {
        assertThat(entity.getDirection()).isNull();
        String direction = "Direction";
        entity = builder.direction(direction).build();
        assertThat(entity.getDirection()).isNotNull().isEqualTo(direction);
    }

    @Test
    public void getFirmwareSoftwareVersion() throws Exception {
        assertThat(entity.getFirmwareSoftwareVersion()).isNull();
        String firmwareSoftwareVersion = "Firmware-Software-Version";
        entity = builder.firmwareSoftwareVersion(firmwareSoftwareVersion).build();
        assertThat(entity.getFirmwareSoftwareVersion()).isNotNull().isEqualTo(firmwareSoftwareVersion);
    }

    @Test
    public void testGetNativeLocation() throws Exception {
        assertThat(entity.getNativeLocation()).isNull();
        String nativeLocation = "Native-Location";
        entity = builder.nativeLocation(nativeLocation).build();
        assertThat(entity.getNativeLocation()).isNotNull().isEqualTo(nativeLocation);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
