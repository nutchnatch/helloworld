package com.ossnms.web.provider.network.model.path;

import com.ossnms.web.provider.network.model.path.enumerable.PathType;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
public class PathIDTest {

    @Test(expected = IllegalStateException.class)
    public void shouldNotCreatePathID(){
        new PathID.Builder(1L, null).build();
    }

    @Test
    public void shouldCreatePathID(){
        PathID pathId = new PathID.Builder(1L, PathType.EXTERNAL_SERVICE).build();

        assertNotNull(pathId);
        assertEquals(1L, pathId.getId());
        assertEquals(PathType.EXTERNAL_SERVICE, pathId.getPathType());
    }
}
