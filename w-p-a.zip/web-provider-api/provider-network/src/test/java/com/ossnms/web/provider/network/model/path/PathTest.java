package com.ossnms.web.provider.network.model.path;

import com.ossnms.web.provider.network.model.common.enumerable.ActiveRoute;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.path.enumerable.PathStatus;
import com.ossnms.web.provider.network.model.path.enumerable.PathType;
import com.ossnms.web.provider.network.model.path.enumerable.WriteProtectedState;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
public class PathTest {

    @Test(expected = IllegalStateException.class)
    public void shouldNotCreatePath(){
        new Path.Builder(null).build();
    }

    @Test
    public void shouldCreatePath(){
        PathID pathId = new PathID.Builder(1L, PathType.EXTERNAL_SERVICE).build();
        Path path = new Path.Builder(pathId).build();

        assertNotNull(path);
        assertEquals(1L, path.getID().getId());
        assertEquals(PathType.EXTERNAL_SERVICE, path.getID().getPathType());
    }

    @Test
    public void shouldCreatePathWithFields(){
        Date now = new Date();

        PathID pathId = new PathID.Builder(1L, PathType.EXTERNAL_SERVICE).build();
        Path path = new Path.Builder(pathId)
                .name("name")
                .pathSubType("subtype")
                .pathStatus(PathStatus.IN_TEST)
                .acknowledgedBy("user1")
                .activeRoute(ActiveRoute.WORKING)
                .alarmSeverity(AlarmSeverity.INDETERMINATE)
                .lastDisabledTime(now)
                .acknowledgedTime(now)
                .writeProtectedState(WriteProtectedState.NOT_APPLICABLE)
                .build();

        assertNotNull(path);
        assertEquals("name", path.getName());
        assertEquals("subtype", path.getPathSubType());
        assertEquals(PathStatus.IN_TEST, path.getPathStatus());
        assertEquals("user1", path.getAcknowledgedBy());
        assertEquals(ActiveRoute.WORKING, path.getActiveRoute());
        assertEquals(AlarmSeverity.INDETERMINATE, path.getAlarmSeverity());
        assertEquals(WriteProtectedState.NOT_APPLICABLE, path.getWriteProtectedState());
        assertEquals(now, path.getLastDisabledTime());
        assertEquals(now, path.getAcknowledgedTime());


    }

}
