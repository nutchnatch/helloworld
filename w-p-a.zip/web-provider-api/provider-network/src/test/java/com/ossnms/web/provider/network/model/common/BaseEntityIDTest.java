package com.ossnms.web.provider.network.model.common;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 09-09-2016.
 */
public class BaseEntityIDTest<ID extends BaseEntityID, B extends BaseEntityID.Builder> extends UtilToTest {

    protected ID id;
    protected B builder;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void setUp() throws Exception {
        builder = (B) new BaseEntityID.Builder(KEY);
        id = (ID) builder.build();
    }

    @Test
    public void testGetId() throws Exception {
        assertThat(id.getId()).isNotNull().isEqualTo(KEY);
        id = (ID) new BaseEntityID.Builder(null).build();
        assertThat(id.getId()).isNull();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(null).build())).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull().isEqualTo(id.getId().hashCode());
    }

}
