package com.ossnms.web.provider.network.model.common;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.ossnms.web.provider.network.model.network.enumerable.EntityType;

/**
 * Created on 12-09-2016.
 */
public class BaseEntityTest<ID extends BaseEntityID, E extends BaseEntity, B extends BaseEntity.Builder> extends UtilToTest {

    protected ID id;
    protected E entity;
    protected B builder;
    protected B invalidBuilder;
    protected EntityType entityType;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.ENTITY;
        id = (ID) new BaseEntityID(KEY);
        builder = (B) new BaseEntity.Builder(id,entityType) {
            @Override
            public E build() {
                return (E) new BaseEntity<>(this);
            }
        };
        entity = (E) builder.build();

        invalidBuilder = (B) new BaseEntity.Builder(null,null) {
            @Override
            public E build() {
                return (E) new BaseEntity<>(this);
            }
        };
    }

    @Test
    public void testGetID() throws Exception {
        assertThat(entity.getID()).isNotNull().isEqualTo(id);
    }

    @Test
    public void testGetType() throws Exception {
        assertThat(entity.getType()).isNotNull().isEqualTo(entityType);
    }

    @Test
    public void testGetName() throws Exception {
        assertThat(entity.getName()).isNull();
        String name = "Entity-Name";
        entity = (E) builder.name(name).build();
        assertThat(entity.getName()).isNotNull().isEqualTo(name);
    }

    @Test
    public void testGetLabel() throws Exception {
        assertThat(entity.getCustomLabel()).isNull();
        String label = "label";
        entity = (E) builder.customLabel(label).build();
        assertThat(entity.getCustomLabel()).isNotNull().isEqualTo(label);
    }

    @Test
    public void testGetNotificationsChannel() throws Exception {
        assertThat(entity.getNotificationsChannel()).isNull();
        String notificationsChannel = "Notifications-Channel";
        entity = (E) builder.notificationsChannel(notificationsChannel).build();
        assertThat(entity.getNotificationsChannel()).isNotNull().isEqualTo(notificationsChannel);
    }

    @Test
    public void testGetContainedObject() throws Exception {
        assertThat(entity.getContainedObject()).isNull();
        String containedObject = "gdlasjgdasdasjdfçasjhdasjdhasçjkdaskç";
        entity = (E) builder.containedObject(containedObject).build();
        assertThat(entity.getContainedObject()).isNotNull().isEqualTo(containedObject);
    }

    @Test
    public void testBuildWithExceptionDueID() throws Exception {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(BaseEntity.EXCEPTION_MESSAGE_ID);
        invalidBuilder.build();
    }

    @Test
    public void testBuildWithExceptionDueType() throws Exception {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(BaseEntity.EXCEPTION_MESSAGE_TYPE);
        new BaseEntity.Builder(id, null){
            @Override
            public BaseEntity build() {
                return new BaseEntity(this);
            }
        }.build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(entity.equals(entity)).isTrue();

        assertThat(entity.equals(null)).isFalse();
        assertThat(entity.equals(new Object())).isFalse();
        assertThat(entity.equals(new BaseEntity.Builder(new BaseEntityID(""), EntityType.ENTITY) {
            @Override
            public BaseEntity build() {
                return new BaseEntity(this);
            }
        }.build())).isFalse();

        BaseEntity.Builder beBuilder = new BaseEntity.Builder(id, EntityType.ENTITY) {
            @Override
            public BaseEntity build() {
                return new BaseEntity(this);
            }
        };
        assertThat(entity.equals(beBuilder.build())).isTrue();

        String object = "asgldgasdhasjk";
        entity = (E) builder.containedObject(object).build();
        assertThat(entity.equals(beBuilder.build())).isFalse();
        assertThat(entity.equals(beBuilder.containedObject(object).build())).isTrue();

        String name = "Entity-Name";
        entity = (E) builder.name(name).build();
        assertThat(entity.equals(beBuilder.build())).isFalse();
        assertThat(entity.equals(beBuilder.name(name).build())).isTrue();

        String notificationsChannel = "NotificationsChannel";
        entity = (E) builder.notificationsChannel(notificationsChannel).build();
        assertThat(entity.equals(beBuilder.build())).isFalse();
        assertThat(entity.equals(beBuilder.notificationsChannel(notificationsChannel).build())).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(entity.hashCode()).isNotNull();
    }

}
