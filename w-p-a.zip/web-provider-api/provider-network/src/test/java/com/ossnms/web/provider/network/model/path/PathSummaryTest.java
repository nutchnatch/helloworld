package com.ossnms.web.provider.network.model.path;

import com.ossnms.web.provider.network.model.path.enumerable.PathStatus;
import com.ossnms.web.provider.network.model.path.enumerable.PathType;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
public class PathSummaryTest {

    @Test(expected = IllegalStateException.class)
    public void shouldNotCreatePathSummary(){
        new PathSummary.Builder(null).build();
    }

    @Test
    public void shouldCreatePathSummaryWithID(){
        PathID pathId = new PathID.Builder(1L, PathType.EXTERNAL_SERVICE).build();
        PathSummary summary = new PathSummary.Builder(pathId).build();

        assertNotNull(summary);
        assertEquals(1L, summary.getID().getId());
        assertEquals(PathType.EXTERNAL_SERVICE, summary.getID().getPathType());
    }

    @Test
    public void shouldCreatePathSummaryWithFields(){
        PathID pathId = new PathID.Builder(1L, PathType.EXTERNAL_SERVICE).build();
        PathSummary summary = new PathSummary.Builder(pathId)
                .name("Test Path Summary")
                .pathStatus(PathStatus.IN_TEST)
                .pathSubType("Test subtype")
                .build();

        assertNotNull(summary);

        assertEquals("Test Path Summary", summary.getName());
        assertEquals(PathStatus.IN_TEST, summary.getPathStatus());
        assertEquals("Test subtype", summary.getPathSubType());
    }
}
