package com.ossnms.web.provider.network.model.network;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 11-10-2016.
 */
public class PtpLocationTest {

    private PtpLocation entity;
    private static final PtpLocation.Builder builder = new PtpLocation.Builder();


    @Before
    public void setUp() throws Exception {
        entity = builder.build();
        assertThat(builder).isNotNull();
        assertThat(entity).isNotNull();
    }

    @Test
    public void testGetRack() throws Exception {
        assertThat(entity.getRack()).isNull();
        String rack = "RACK";
        entity = builder.rack(rack).build();
        assertThat(entity.getRack()).isNotNull().isEqualTo(rack);
    }

    @Test
    public void testGetShelf() throws Exception {
        assertThat(entity.getShelf()).isNull();
        String shelf = "SHELF";
        entity = builder.shelf(shelf).build();
        assertThat(entity.getShelf()).isNotNull().isEqualTo(shelf);
    }

    @Test
    public void testGetSlot() throws Exception {
        assertThat(entity.getSlot()).isNull();
        String slot = "SLOT";
        entity = builder.slot(slot).build();
        assertThat(entity.getSlot()).isNotNull().isEqualTo(slot);
    }

    @Test
    public void testGetSubSlot() throws Exception {
        assertThat(entity.getSubSlot()).isNull();
        String subSlot = "SUB-SLOT";
        entity = builder.subSlot(subSlot).build();
        assertThat(entity.getSubSlot()).isNotNull().isEqualTo(subSlot);
    }

    @Test
    public void testGetPort() throws Exception {
        assertThat(entity.getPort()).isNull();
        String port = "PORT";
        entity = builder.port(port).build();
        assertThat(entity.getPort()).isNotNull().isEqualTo(port);
    }

}
