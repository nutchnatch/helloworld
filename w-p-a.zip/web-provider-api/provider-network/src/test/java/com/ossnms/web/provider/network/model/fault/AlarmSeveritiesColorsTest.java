package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.common.api.model.Color;
import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 21-10-2016.
 */
public class AlarmSeveritiesColorsTest extends BaseEntityTest<BaseEntityID, AlarmSeveritiesColors, AlarmSeveritiesColors.Builder> {

    private static final Color COLOR = new Color(50, 100, 50);

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.ENTITY;
        id = new BaseEntityID(KEY);
        builder = new AlarmSeveritiesColors.Builder(id);
        entity = builder.build();

        invalidBuilder = new AlarmSeveritiesColors.Builder(null);
    }

    @Test
    public void testGetCritical() throws Exception {
        assertThat(entity.getCritical()).isNull();
        entity = builder.critical(COLOR).build();
        assertThat(entity.getCritical()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.CRITICAL, COLOR));
    }

    @Test
    public void testGetIndeterminate() throws Exception {
        assertThat(entity.getIndeterminate()).isNull();
        entity = builder.indeterminate(COLOR).build();
        assertThat(entity.getIndeterminate()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.INDETERMINATE, COLOR));
    }

    @Test
    public void testGetMajor() throws Exception {
        assertThat(entity.getMajor()).isNull();
        entity = builder.major(COLOR).build();
        assertThat(entity.getMajor()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.MAJOR, COLOR));
    }

    @Test
    public void testGetMinor() throws Exception {
        assertThat(entity.getMinor()).isNull();
        entity = builder.minor(COLOR).build();
        assertThat(entity.getMinor()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.MINOR, COLOR));
    }

    @Test
    public void testGetCleared() throws Exception {
        assertThat(entity.getCleared()).isNull();
        entity = builder.cleared(COLOR).build();
        assertThat(entity.getCleared()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.CLEARED, COLOR));
    }

    @Test
    public void testGetNonAlarmed() throws Exception {
        assertThat(entity.getNonAlarmed()).isNull();
        entity = builder.nonAlarmed(COLOR).build();
        assertThat(entity.getNonAlarmed()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.NON_ALARMED, COLOR));
    }

    @Test
    public void testGetNotAlarmed() throws Exception {
        assertThat(entity.getNotAlarmed()).isNull();
        entity = builder.notAlarmed(COLOR).build();
        assertThat(entity.getNotAlarmed()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.NOT_ALARMED, COLOR));
    }

    @Test
    public void testGetNotExistent() throws Exception {
        assertThat(entity.getNotExistent()).isNull();
        entity = builder.notExistent(COLOR).build();
        assertThat(entity.getNotExistent()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.NOT_EXISTENT, COLOR));
    }

    @Test
    public void testGetWarning() throws Exception {
        assertThat(entity.getWarning()).isNull();
        entity = builder.warning(COLOR).build();
        assertThat(entity.getWarning()).isNotNull().isEqualTo(new AlarmSeverityColor(AlarmSeverity.WARNING, COLOR));
    }

    @Override
    @Test
    public void testEquals() throws Exception {

    }
}
