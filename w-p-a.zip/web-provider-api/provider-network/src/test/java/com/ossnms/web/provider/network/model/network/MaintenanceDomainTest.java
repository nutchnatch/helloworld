package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.MaintenanceDomainID;
import org.junit.Before;
import org.junit.Test;

/**
 * Created on 12-09-2016.
 */
public class MaintenanceDomainTest extends BaseEntityTest<MaintenanceDomainID, MaintenanceDomain, MaintenanceDomain.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.MAINTENANCE_DOMAIN;
        id = new MaintenanceDomainID.Builder(KEY, NE_ID, SUBSYS_ID, CONTEXT_ID).build();
        builder = new MaintenanceDomain.Builder(id);
        entity = builder.build();

        invalidBuilder = new MaintenanceDomain.Builder(null);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
