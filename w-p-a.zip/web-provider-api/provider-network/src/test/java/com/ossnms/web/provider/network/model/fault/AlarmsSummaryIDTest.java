package com.ossnms.web.provider.network.model.fault;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import com.ossnms.web.provider.network.model.network.id.NetworkElementID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 13-09-2016.
 */
public class AlarmsSummaryIDTest extends BaseEntityIDTest<AlarmsSummaryID, AlarmsSummaryID.Builder> {

    @Before
    public void setUp() throws Exception {
        builder = new AlarmsSummaryID.Builder(KEY, ALARMS_SUMMARY_ID);
        id = builder.build();
    }

    @Test
    public void testGetAlarmsSummaryId() throws Exception {
        assertThat(id.getAlarmsSummaryId()).isNotNull().isEqualTo(ALARMS_SUMMARY_ID);
    }

    @Test
    public void testBuildWithExceptionDueALARMS_SUMMARY_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(AlarmsSummaryID.Builder.EXCEPTION_MESSAGE_ALARMS_SUMMARY_ID);
        new AlarmsSummaryID.Builder(KEY, null).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(CONTAINER_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, CONTAINER_ID).build())).isFalse();
        assertThat(id.equals(new AlarmsSummaryID.Builder(KEY, ALARMS_SUMMARY_ID).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
