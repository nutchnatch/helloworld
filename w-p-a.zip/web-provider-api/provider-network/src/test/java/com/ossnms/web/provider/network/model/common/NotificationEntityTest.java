package com.ossnms.web.provider.network.model.common;

import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationType;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Created by catarino on 16-09-2016.
 */
public class NotificationEntityTest {

    private NotificationEntity entity;
    private NotificationEntity.Builder builder;


    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private BaseEntity baseEntity = mock(BaseEntity.class);
    private NotificationType NOTIF_TYPE = NotificationType.CREATION;
    private String CHANNEL_ID = "CHANNEL_ID";

    @Before
    public void setUp() throws Exception {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID);
        builder = new NotificationEntity.Builder(baseEntity, NOTIF_TYPE, channel);
        entity = builder.build();
    }

    @Test
    public void testGetEntity() throws Exception {
        assertThat(entity.getEntity()).isNotNull().isEqualTo(baseEntity);
    }

    @Test
    public void testGetNotificationType() throws Exception {
        assertThat(entity.getNotificationType()).isNotNull().isEqualTo(NOTIF_TYPE);
    }

    @Test
    public void testGetChannel() throws Exception {
        assertThat(entity.getChannel()).isNotNull().isEqualTo(new NotificationChannel(CHANNEL_ID));
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(entity.equals(entity)).isTrue();

        assertThat(entity.equals(null)).isFalse();
        assertThat(entity.equals(new Object())).isFalse();
        NotificationChannel channel = new NotificationChannel("");
        assertThat(entity.equals(new NotificationEntity.Builder(baseEntity, NOTIF_TYPE, channel).build())).isFalse();
        channel = new NotificationChannel(CHANNEL_ID);
        assertThat(entity.equals(new NotificationEntity.Builder(baseEntity, NOTIF_TYPE, channel).build())).isTrue();

        assertThat(entity.equals(new NotificationEntity.Builder(baseEntity, NotificationType.CHANGE, channel).build())).isFalse();
        assertThat(entity.equals(new NotificationEntity.Builder(baseEntity, NotificationType.DELETION, channel).build())).isFalse();
        assertThat(entity.equals(new NotificationEntity.Builder(baseEntity, NotificationType.RESYNC, channel).build())).isFalse();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(entity.hashCode()).isNotNull();
    }

    @Test
    public void testToString() {
        assertThat(entity.toString()).isNotEmpty();
    }

}
