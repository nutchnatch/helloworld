package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.LACPModeType;
import com.ossnms.web.provider.network.model.network.enumerable.TimeOutType;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 14-09-2016.
 */
public class LacpRemoteTest<E extends LacpRemote> {

    protected E entity;

    @Before
    public void setUp() throws Exception {
        entity = (E) new LacpRemote();
        assertThat(entity).isNotNull();
    }

    @Test
    public void testGetPortPriority() throws Exception {
        assertThat(entity.getPortPriority()).isNull();
        Integer portPriority = 1;
        entity.setPortPriority(portPriority);
        assertThat(entity.getPortPriority()).isNotNull().isEqualTo(portPriority);
    }

    @Test
    public void testGetLacpMode() throws Exception {
        assertThat(entity.getLacpMode()).isNull();
        LACPModeType lacpMode = LACPModeType.ACTIVE;
        entity.setLacpMode(lacpMode);
        assertThat(entity.getLacpMode()).isNotNull().isEqualTo(lacpMode);
    }

    @Test
    public void testGetTimeOut() throws Exception {
        assertThat(entity.getTimeOut()).isNull();
        TimeOutType timeOut = TimeOutType.LONG;
        entity.setTimeOut(timeOut);
        assertThat(entity.getTimeOut()).isNotNull().isEqualTo(timeOut);
    }

}
