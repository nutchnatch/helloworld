package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.CcProtectionStateType;
import com.ossnms.web.provider.network.model.network.enumerable.CcStateType;
import com.ossnms.web.provider.network.model.network.enumerable.CcType;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.CrossConnectionID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 13-09-2016.
 */
public class CrossConnectionTest extends BaseEntityTest<CrossConnectionID, CrossConnection, CrossConnection.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.CROSS_CONNECTION;
        id = new CrossConnectionID.Builder(KEY, TP_END_A, TP_END_Z).build();
        builder = new CrossConnection.Builder(id);
        entity = builder.build();

        invalidBuilder = new CrossConnection.Builder(null);
    }

    @Test
    public void testGetOperationalState() throws Exception {
        assertThat(entity.getOperationalState()).isNull();
        OperationalState operationalState = OperationalState.DISABLED;
        entity = builder.operationalState(operationalState).build();
        assertThat(entity.getOperationalState()).isNotNull().isEqualTo(operationalState);
    }

    @Test
    public void testGetCcType() throws Exception {
        assertThat(entity.getCcType()).isNull();
        CcType ccType = CcType.UNPROTECTED_BI;
        entity = builder.ccType(ccType).build();
        assertThat(entity.getCcType()).isNotNull().isEqualTo(ccType);
    }

    @Test
    public void testGetState() throws Exception {
        assertThat(entity.getState()).isNull();
        CcStateType state = CcStateType.ACTIVE;
        entity = builder.state(state).build();
        assertThat(entity.getState()).isNotNull().isEqualTo(state);
    }

    @Test
    public void testGetProtectionState() throws Exception {
        assertThat(entity.getProtectionState()).isNull();
        CcProtectionStateType protectionState = CcProtectionStateType.PROTECTING;
        entity = builder.protectionState(protectionState).build();
        assertThat(entity.getProtectionState()).isNotNull().isEqualTo(protectionState);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
