package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class MaintenanceDomainIDTest extends BaseEntityIDTest<MaintenanceDomainID, MaintenanceDomainID.Builder> {
    @Before
    public void setUp() throws Exception {
        builder = new MaintenanceDomainID.Builder(KEY, NE_ID, SUBSYS_ID, CONTEXT_ID);
        id = builder.build();
    }

    @Test
    public void testGetNeId() throws Exception {
        assertThat(id.getNeId()).isNotNull().isEqualTo(NE_ID);
    }

    @Test
    public void testGetSubsysId() throws Exception {
        assertThat(id.getSubsysId()).isNotNull().isEqualTo(SUBSYS_ID);
    }

    @Test
    public void testGetContextId() throws Exception {
        assertThat(id.getContextId()).isNotNull().isEqualTo(CONTEXT_ID);
    }

    @Test
    public void testBuildWithExceptionDueNE_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(MaintenanceDomainID.Builder.EXCEPTION_MESSAGE_NE_ID);
        new MaintenanceDomainID.Builder(KEY, null, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueSUBSYS_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(MaintenanceDomainID.Builder.EXCEPTION_MESSAGE_SUBSYS_ID);
        new MaintenanceDomainID.Builder(KEY, NE_ID, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueCONTEXT_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(MaintenanceDomainID.Builder.EXCEPTION_MESSAGE_CONTEXT_ID);
        new MaintenanceDomainID.Builder(KEY, NE_ID, SUBSYS_ID, null).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(NE_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new ContainerID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new EquipmentHolderID.Builder(KEY, NE_ID, EH_ID).build())).isFalse();
        assertThat(id.equals(new BridgeID.Builder(KEY, NE_ID, SUBSYS_ID, BRIDGE_ID).build())).isFalse();

        assertThat(id.equals(new MaintenanceDomainID.Builder(KEY, NE_ID, SUBSYS_ID, CONTEXT_ID).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
