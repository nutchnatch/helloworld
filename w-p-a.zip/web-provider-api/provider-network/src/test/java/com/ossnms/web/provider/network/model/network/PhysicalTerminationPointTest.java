package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.network.enumerable.*;
import com.ossnms.web.provider.network.model.network.id.PhysicalTerminationPointID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 13-09-2016.
 */
public class PhysicalTerminationPointTest extends BaseEntityTest<PhysicalTerminationPointID, PhysicalTerminationPoint, PhysicalTerminationPoint.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.PHYSICAL_TERMINATION_POINT;
        id = new PhysicalTerminationPointID.Builder(KEY, NE_ID, PTP_ID).build();
        builder = new PhysicalTerminationPoint.Builder(id);
        entity = builder.build();

        invalidBuilder = new PhysicalTerminationPoint.Builder(null);
    }

    @Test
    public void testGetInterfaceType() throws Exception {
        assertThat(entity.getInterfaceType()).isNull();
        PhysicalInterfaceType interfaceType = PhysicalInterfaceType.OPTICAL;
        entity = builder.interfaceType(interfaceType).build();
        assertThat(entity.getInterfaceType()).isNotNull().isEqualTo(interfaceType);
    }

    @Test
    public void testGetPointType() throws Exception {
        assertThat(entity.getPointType()).isNull();
        TerminationPointType pointType = TerminationPointType.LAG_PORT;
        entity = builder.pointType(pointType).build();
        assertThat(entity.getPointType()).isNotNull().isEqualTo(pointType);
    }

    @Test
    public void testGetOperationalStateSink() throws Exception {
        assertThat(entity.getOperationalStateSink()).isNull();
        OperationalState operationalState = OperationalState.ENABLED;
        entity = builder.operationalStateSink(operationalState).build();
        assertThat(entity.getOperationalStateSink()).isNotNull().isEqualTo(operationalState);
    }

    @Test
    public void testGetOperationalStateSource() throws Exception {
        assertThat(entity.getOperationalStateSource()).isNull();
        OperationalState operationalState = OperationalState.DISABLED;
        entity = builder.operationalStateSource(operationalState).build();
        assertThat(entity.getOperationalStateSource()).isNotNull().isEqualTo(operationalState);
    }

    @Test
    public void testGetAdministrativeState() throws Exception {
        assertThat(entity.getAdministrativeState()).isNull();
        AdministrativeStateType administrativeState = AdministrativeStateType.UNLOCKED;
        entity = builder.administrativeState(administrativeState).build();
        assertThat(entity.getAdministrativeState()).isNotNull().isEqualTo(administrativeState);
    }

    @Test
    public void testGetPortMode() throws Exception {
        assertThat(entity.getPortMode()).isNull();
        String portMode = "Port-Mode";
        entity = builder.portMode(portMode).build();
        assertThat(entity.getPortMode()).isNotNull().isEqualTo(portMode);
    }

    @Test
    public void testGetNativeLocation() throws Exception {
        assertThat(entity.getNativeLocation()).isNull();
        String nativeLocation = "Native-Location";
        entity = builder.nativeLocation(nativeLocation).build();
        assertThat(entity.getNativeLocation()).isNotNull().isEqualTo(nativeLocation);
    }

    @Test
    public void testGetOptical() throws Exception {
        assertThat(entity.getOptical()).isNull();
        PtpOptical optical = new PtpOptical.Builder().direction(TpDirectionType.BIDIRECTIONAL).build();
        entity = builder.optical(optical).build();
        assertThat(entity.getOptical()).isNotNull().isEqualTo(optical);
    }

    @Test
    public void testGetLocation() throws Exception {
        assertThat(entity.getLocation()).isNull();
        PtpLocation location = new PtpLocation.Builder().rack("RACK").build();
        entity = builder.location(location).build();
        assertThat(entity.getLocation()).isNotNull().isEqualTo(location);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
