package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.EquipmentHolderID;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class EquipmentHolderTest extends BaseEntityTest<EquipmentHolderID, EquipmentHolder, EquipmentHolder.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.EQUIPMENT_HOLDER;
        id = new EquipmentHolderID.Builder(KEY, NE_ID, EH_ID).build();
        builder = new EquipmentHolder.Builder(id);
        entity = builder.build();

        invalidBuilder = new EquipmentHolder.Builder(null);
    }

    @Test
    public void testGetActualShelfType() throws Exception {
        assertThat(entity.getActualShelfType()).isNull();
        String actualShelfType = "Actual-Shelf-Type";
        entity = builder.actualShelfType(actualShelfType).build();
        assertThat(entity.getActualShelfType()).isNotNull().isEqualTo(actualShelfType);
    }

    @Test
    public void testGetShelfId() throws Exception {
        assertThat(entity.getShelfId()).isNull();
        Integer shelfId = EH_ID;
        entity = builder.shelfId(shelfId).build();
        assertThat(entity.getShelfId()).isNotNull().isEqualTo(shelfId);
    }

    @Test
    public void testGetBayShelf() throws Exception {
        assertThat(entity.getBayShelf()).isNull();
        Integer bayShelf = 1000;
        entity = builder.bayShelf(bayShelf).build();
        assertThat(entity.getBayShelf()).isNotNull().isEqualTo(bayShelf);
    }

    @Test
    public void testGetNativeLocation() throws Exception {
        assertThat(entity.getNativeLocation()).isNull();
        String nativeLocation = "Native-Location";
        entity = builder.nativeLocation(nativeLocation).build();
        assertThat(entity.getNativeLocation()).isNotNull().isEqualTo(nativeLocation);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
