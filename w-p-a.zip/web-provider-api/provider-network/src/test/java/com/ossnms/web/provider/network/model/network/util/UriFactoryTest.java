package com.ossnms.web.provider.network.model.network.util;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class UriFactoryTest {

    private UriFactory uriFactory;

    @Before
    public void setUp() throws Exception {
        uriFactory = new UriFactory();
    }

    @Test
    public void testContainerUri() {
        String uri = uriFactory.createContainersUri();
        assertThat(uri).isNotNull().contains(UriConstants.CONTAINERS);

        uri = uriFactory.createContainersUri(1);
        assertThat(uri).isNotNull().startsWith(UriConstants.CONTAINERS).endsWith(UriConstants.CONTAINERS);

        uri = uriFactory.createContainerUri(1);
        assertThat(uri).isNotNull().contains(UriConstants.CONTAINERS);

        uri = uriFactory.createContainerNesUri();
        assertThat(uri).isNotNull().isEqualTo(UriConstants.NES);

        uri = uriFactory.createContainerNesUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.CONTAINERS)
                .endsWith(UriConstants.NES);

        uri = uriFactory.createContainersOfNeUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.CONTAINERS)
                .contains(UriConstants.CONTAINS_NE);

        uri = uriFactory.createContainerSystemContainersUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.CONTAINERS)
                .endsWith(UriConstants.SYSTEM_CONTAINERS);

        uri = uriFactory.createContainersOfSystemContainerUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.CONTAINERS)
                .contains(UriConstants.CONTAINS_SYSTEM_CONTAINER);
    }

    @Test
    public void testSystemContainerUri() {
        String uri = uriFactory.createSystemContainersUri();
        assertThat(uri).isNotNull().startsWith(UriConstants.SYSTEM_CONTAINERS);

        uri = uriFactory.createSystemContainerUri(1);
        assertThat(uri).isNotNull().startsWith(UriConstants.SYSTEM_CONTAINERS);

        uri = uriFactory.createSystemContainerNesUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.SYSTEM_CONTAINERS)
                .endsWith(UriConstants.NES);
    }

    @Test
    public void testNeUri() {
        String uri = uriFactory.createNeUri(1);
        assertThat(uri).isNotNull().startsWith(UriConstants.NES);
    }

    @Test
    public void testEhUri() {
        String uri = uriFactory.createEhsUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.EHS);

        uri = uriFactory.createEhsUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.EHS);

        uri = uriFactory.createEhUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.EHS);
    }

    @Test
    public void testEqUri() {
        String uri = uriFactory.createEqsUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.EQS);

        uri = uriFactory.createEqsUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.EQS);

        uri = uriFactory.createEqUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.EQS);

        uri = uriFactory.createEqEqsUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.EQS);

        uri = uriFactory.createEqTpsUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.TPS);
    }

    @Test
    public void testPtpUri() {
        String uri = uriFactory.createPtpsUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.PTPS);

        uri = uriFactory.createPtpsUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.EQS)
                .endsWith(UriConstants.PTPS);

        uri = uriFactory.createPtpUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS);
    }

    @Test
    public void testTpUri() {
        String uri = uriFactory.createTpsUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .endsWith(UriConstants.TPS);

        uri = uriFactory.createTpsUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .endsWith(UriConstants.TPS);

        uri = uriFactory.createTpUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .contains(UriConstants.TPS);
    }

    @Test
    public void testBridgeUri() {
        String uri = uriFactory.createBridgesUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.BRIDGES);

        uri = uriFactory.createBridgeUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.BRIDGES);

        uri = uriFactory.createBridgeEqsUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.BRIDGES)
                .endsWith(UriConstants.EQS);

        uri = uriFactory.createBridgeLAGsUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.BRIDGES)
                .endsWith(UriConstants.LAGS);

        uri = uriFactory.createBridgeMACsUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.BRIDGES)
                .endsWith(UriConstants.MACS);

        uri = uriFactory.createBridgeAvailableMACsUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.BRIDGES)
                .endsWith(UriConstants.MACS);
    }

    @Test
    public void testVlanUri() {
        String uri = uriFactory.createVlansUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .contains(UriConstants.TPS)
                .endsWith(UriConstants.VLANS);

        uri = uriFactory.createVlanUri(1, 1, 1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .contains(UriConstants.TPS)
                .contains(UriConstants.VLANS);
    }

    @Test
    public void testCcUri() {
        String uri = uriFactory.createCcsUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.CCS);

        uri = uriFactory.createCcUri(1, 1, 1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.CCS);

        uri = uriFactory.createCcUri(1, 1, 1, 1, 1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.CCS);

        uri = uriFactory.createCcsByTpUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .contains(UriConstants.TPS)
                .endsWith(UriConstants.CCS);
    }

    @Test
    public void testIpcUri() {
        String uri = uriFactory.createIpcsUri(1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .endsWith(UriConstants.IPCS);

        uri = uriFactory.createIpcUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.IPCS);

        uri = uriFactory.createIpcsByPtpUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .endsWith(UriConstants.IPCS);
    }

    @Test
    public void testTlUri() {
        String uri = uriFactory.createTlsUri();
        assertThat(uri).isNotNull()
                .isEqualTo(UriConstants.TLS);

        uri = uriFactory.createTlUri(1, 1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.TLS);

        uri = uriFactory.createTlsByPtpUri(1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .endsWith(UriConstants.TLS);
    }

    @Test
    public void testLAGUri() {
        String uri = uriFactory.createLagMacsUri(1, 1, 1);
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.NES)
                .contains(UriConstants.PTPS)
                .contains(UriConstants.TPS)
                .endsWith(UriConstants.MACS);
    }

    @Test
    public void testSNCUri() {
        String uri = uriFactory.createSncsUri();
        assertThat(uri).isNotNull()
                .isEqualTo(UriConstants.SNCS);

        uri = uriFactory.createSncUri(1, "type");
        assertThat(uri).isNotNull()
                .startsWith(UriConstants.SNCS);
    }

    @Test
    public void testAlarmSummaryUri() {
        String entityUri = "entityUri";
        String uri = uriFactory.createEntityAlarmSummary(entityUri);
        assertThat(uri).isNotNull()
                .startsWith(entityUri)
                .endsWith(UriConstants.JAXRS_ALARMS_SUMMARY);
    }
}
