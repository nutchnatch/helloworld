package com.ossnms.web.provider.network.model.network;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 30-09-2016.
 */
public class GeoLocationTest {

    private GeoLocation entity;

    @Before
    public void setUp() throws Exception {
        entity = new GeoLocation(null, null);
        assertThat(entity).isNotNull();
        assertThat(entity.getLatitude()).isNull();
        assertThat(entity.getLongitude()).isNull();
    }

    @Test
    public void testGetLatitude() throws Exception {
        Double latitude = 12.00;
        entity = new GeoLocation(null, latitude);
        assertThat(entity.getLatitude()).isNotNull().isEqualTo(latitude);
    }

    @Test
    public void testGetLongitude() throws Exception {
        Double longitude = 2.00;
        entity = new GeoLocation(longitude, null);
        assertThat(entity.getLongitude()).isNotNull().isEqualTo(longitude);
    }

}
