package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.network.enumerable.LoopbackType;
import com.ossnms.web.provider.network.model.network.enumerable.ProvisioningModeType;
import com.ossnms.web.provider.network.model.network.enumerable.TpDirectionType;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 14-09-2016.
 */
public class PtpOpticalTest {

    private PtpOptical entity;
    private static final PtpOptical.Builder builder = new PtpOptical.Builder();


    @Before
    public void setUp() throws Exception {
        entity = builder.build();
        assertThat(builder).isNotNull();
        assertThat(entity).isNotNull();
    }

    @Test
    public void testGetProvisioningMode() throws Exception {
        assertThat(entity.getProvisioningMode()).isNull();
        ProvisioningModeType provisioningMode = ProvisioningModeType.EMPTY;
        entity = builder.provisioningMode(provisioningMode).build();
        assertThat(entity.getProvisioningMode()).isNotNull().isEqualTo(provisioningMode);
    }

    @Test
    public void testGetDirection() throws Exception {
        assertThat(entity.getDirection()).isNull();
        TpDirectionType direction = TpDirectionType.BIDIRECTIONAL;
        entity = builder.direction(direction).build();
        assertThat(entity.getDirection()).isNotNull().isEqualTo(direction);
    }

    @Test
    public void testGetTerminatedLayers() throws Exception {
        assertThat(entity.getTerminatedLayers()).isNull();
        List<String> terminatedLayers = new ArrayList<>();
        terminatedLayers.add("TL_1");
        terminatedLayers.add("TL_2");
        entity = builder.terminatedLayers(terminatedLayers).build();
        assertThat(entity.getTerminatedLayers()).isNotNull().isNotEmpty().hasSize(terminatedLayers.size()).containsAll(terminatedLayers);
    }

    @Test
    public void testGetNonTerminatedLayers() throws Exception {
        assertThat(entity.getNonTerminatedLayers()).isNull();
        List<String> nonTerminatedLayers = new ArrayList<>();
        nonTerminatedLayers.add("TL_5");
        nonTerminatedLayers.add("TL_4");
        entity = builder.nonTerminatedLayers(nonTerminatedLayers).build();
        assertThat(entity.getNonTerminatedLayers()).isNotNull().isNotEmpty().hasSize(nonTerminatedLayers.size()).containsAll(nonTerminatedLayers);
    }

    @Test
    public void testGetLoopBack() throws Exception {
        assertThat(entity.getLoopBack()).isNull();
        LoopbackType loopBack = LoopbackType.NO_LOOP;
        entity = builder.loopBack(loopBack).build();
        assertThat(entity.getLoopBack()).isNotNull().isEqualTo(loopBack);
    }

}
