package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by catarino on 09-09-2016.
 */
public class TerminationPointIDTest extends BaseEntityIDTest<TerminationPointID, TerminationPointID.Builder> {

    @Before
    public void setUp() throws Exception {
        builder = new TerminationPointID.Builder(KEY, NE_ID, PTP_ID, TP_ID);
        id = builder.build();
    }

    @Test
    public void testGetNeId() throws Exception {
        assertThat(id.getNeId()).isNotNull().isEqualTo(NE_ID);
    }

    @Test
    public void testGetPtpId() throws Exception {
        assertThat(id.getPtpId()).isNotNull().isEqualTo(PTP_ID);
    }

    @Test
    public void testGetTpId() throws Exception {
        assertThat(id.getTpId()).isNotNull().isEqualTo(TP_ID);
    }

    @Test
    public void testBuildWithExceptionDueNE_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(TerminationPointID.Builder.EXCEPTION_MESSAGE_NE_ID);
        new TerminationPointID.Builder(KEY, null, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDuePTP_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(TerminationPointID.Builder.EXCEPTION_MESSAGE_PTP_ID);
        new TerminationPointID.Builder(KEY, NE_ID, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueTP_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(TerminationPointID.Builder.EXCEPTION_MESSAGE_TP_ID);
        new TerminationPointID.Builder(KEY, NE_ID, PTP_ID, null).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(NE_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new ContainerID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new EquipmentHolderID.Builder(KEY, NE_ID, EQ_ID).build())).isFalse();

        assertThat(id.equals(new PhysicalTerminationPointID.Builder(KEY, NE_ID, PTP_ID).eqId(EQ_ID).build())).isFalse();

        assertThat(id.equals(new TerminationPointID.Builder(KEY, NE_ID, PTP_ID, TP_ID).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
