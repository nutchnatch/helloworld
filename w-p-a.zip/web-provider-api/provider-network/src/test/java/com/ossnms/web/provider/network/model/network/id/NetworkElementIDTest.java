package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 09-09-2016.
 */
public class NetworkElementIDTest extends BaseEntityIDTest<NetworkElementID, NetworkElementID.Builder> {

    @Before
    public void setUp() throws Exception {
        builder = new NetworkElementID.Builder(KEY, NE_ID);
        id = builder.build();
    }

    @Test
    public void testGetNeId() throws Exception {
        assertThat(id.getNeId()).isNotNull().isEqualTo(NE_ID);
    }

    @Test
    public void testBuildWithExceptionDueNE_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(NetworkElementID.Builder.EXCEPTION_MESSAGE_NE_ID);
        new NetworkElementID.Builder(KEY, null).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(NE_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new ContainerID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, NE_ID).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
