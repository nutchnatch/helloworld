package com.ossnms.web.provider.network.model.fault;


import org.junit.Test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
public class AlarmIDTest {

    @Test
    public void shouldCreateAlarmID(){
        AlarmID alarmId = new AlarmID.Builder(1L).build();

        assertNotNull(alarmId);
        assertEquals(1L, alarmId.getId());
    }

}
