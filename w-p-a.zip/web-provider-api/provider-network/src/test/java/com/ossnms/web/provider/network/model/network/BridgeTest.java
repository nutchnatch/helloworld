package com.ossnms.web.provider.network.model.network;

import com.ossnms.web.provider.network.model.common.BaseEntityTest;
import com.ossnms.web.provider.network.model.network.enumerable.EntityType;
import com.ossnms.web.provider.network.model.network.id.BridgeID;
import com.ossnms.web.provider.network.model.network.id.MaintenanceDomainID;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 12-09-2016.
 */
public class BridgeTest extends BaseEntityTest<BridgeID, Bridge, Bridge.Builder> {

    @Before
    public void setUp() throws Exception {
        entityType = EntityType.BRIDGE;
        id = new BridgeID.Builder(KEY, NE_ID, SUBSYS_ID, BRIDGE_ID).build();
        builder = new Bridge.Builder(id);
        entity = builder.build();

        invalidBuilder = new Bridge.Builder(null);
    }

    @Test
    public void testGetContextId() throws Exception {
        assertThat(entity.getContextId()).isNull();
        entity = builder.contextId(CONTEXT_ID).build();
        assertThat(entity.getContextId()).isNotNull().isEqualTo(CONTEXT_ID);
    }

    @Test
    public void testGetNativeLocation() throws Exception {
        assertThat(entity.getNativeLocation()).isNull();
        String nativeLocation = "Native-Location";
        entity = builder.nativeLocation(nativeLocation).build();
        assertThat(entity.getNativeLocation()).isNotNull().isEqualTo(nativeLocation);
    }

    @Test
    public void testGetMaintenanceDomains() throws Exception {
        assertThat(entity.getMaintenanceDomains()).isNull();
        Collection<MaintenanceDomain> maintenanceDomains = new ArrayList<>();
        maintenanceDomains.add(new MaintenanceDomain.Builder(new MaintenanceDomainID.Builder(KEY, NE_ID, SUBSYS_ID, CONTEXT_ID).build()).build());
        entity = builder.maintenanceDomains(maintenanceDomains).build();
        assertThat(entity.getMaintenanceDomains()).isNotNull().isEqualTo(maintenanceDomains);
    }

    @Test
    public void testEquals() throws Exception {

    }

}
