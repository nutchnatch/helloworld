package com.ossnms.web.provider.network.model.network.id;

import com.ossnms.web.provider.network.model.common.BaseEntityID;
import com.ossnms.web.provider.network.model.common.BaseEntityIDTest;
import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 09-09-2016.
 */
public class EquipmentHolderIDTest extends BaseEntityIDTest<EquipmentHolderID, EquipmentHolderID.Builder> {

    @Before
    public void setUp() throws Exception {
        builder = new EquipmentHolderID.Builder(KEY, NE_ID, EH_ID);
        id = builder.build();
    }

    @Test
    public void testGetNeId() throws Exception {
        assertThat(id.getNeId()).isNotNull().isEqualTo(NE_ID);
    }

    @Test
    public void testGetEhId() throws Exception {
        assertThat(id.getEhId()).isNotNull().isEqualTo(EH_ID);
    }

    @Test
    public void testBuildWithExceptionDueNE_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(EquipmentHolderID.Builder.EXCEPTION_MESSAGE_NE_ID);
        new EquipmentHolderID.Builder(KEY, null, null).build();
    }

    @Test
    public void testBuildWithExceptionDueEH_ID() {
        thrown.expect(IllegalStateException.class);
        thrown.expectMessage(EquipmentHolderID.Builder.EXCEPTION_MESSAGE_EH_ID);
        new EquipmentHolderID.Builder(KEY, NE_ID, null).build();
    }

    @Test
    public void testEquals() throws Exception {
        assertThat(id.equals(null)).isFalse();
        assertThat(id.equals(KEY)).isFalse();
        assertThat(id.equals(NE_ID)).isFalse();
        assertThat(id.equals(new BaseEntityID.Builder(KEY).build())).isFalse();
        assertThat(id.equals(new ContainerID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new NetworkElementID.Builder(KEY, NE_ID).build())).isFalse();
        assertThat(id.equals(new EquipmentHolderID.Builder(KEY, NE_ID, EH_ID).build())).isTrue();
        assertThat(id.equals(id)).isTrue();
    }

    @Test
    public void testHashCode() throws Exception {
        assertThat(id.hashCode()).isNotNull();
    }

}
