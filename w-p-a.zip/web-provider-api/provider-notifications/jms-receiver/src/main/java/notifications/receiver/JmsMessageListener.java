package notifications.receiver;

import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

import static notifications.receiver.JmsMessageListener.TOPIC;

@MessageDriven(
        name = "JmsMessageListenerMDB",
        activationConfig = {
            @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
            @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Topic"),
            @ActivationConfigProperty(propertyName = "destination",     propertyValue = TOPIC)
        }
)
public class JmsMessageListener implements MessageListener {

    public static final String TOPIC = "java:global/jms/web-api-events-topic";
    private static final Logger LOGGER = LoggerFactory.getLogger(JmsMessageListener.class);

    @Inject
    private NotificationHandler handler;

    /**
     * Constructor to use when CDI is available.
     */
    public JmsMessageListener() {

    }

    public JmsMessageListener(NotificationHandler handler) {
        this.handler = handler;
    }

    @Override
    public void onMessage(Message message) {
        LOGGER.trace("message received: {}", message);

        try {
            Notification dto = message.getBody(Notification.class);
            handler.handle(dto);
        } catch (JMSException e) {
            LOGGER.error("Invalid message object: {}", message, e);
        } catch (NotificationHandlerException e) {
            LOGGER.error("Message handling failed: {}", message, e);
        }
    }
}
