package notifications.receiver;

import com.ossnms.web.provider.common.api.notification.LocalNotificationService;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationService;

import javax.naming.Context;

import java.util.Collection;
import java.util.Hashtable;

/**
 *
 */
@LocalNotificationService
public class JmsRemoteNotificationService implements NotificationService {

    private static final String APP_NAME = "bicnet";
    private static final String COMPONENT_NAME = "element-management";
    private static final String BEAN = "JmsNotificationService";
    private static final String BEAN_CLASS = NotificationService.class.getCanonicalName();

    private static final String PACKAGE_PREFIXS = "org.jboss.ejb.client.naming";
    private static final String EJB_LOOKUP = new StringBuilder("ejb:").append(APP_NAME)
            .append("/")
            .append(COMPONENT_NAME)
            .append("/")
            .append(BEAN)
            .append("!")
            .append(BEAN_CLASS)
            .toString();


    private NotificationService remoteNotificationService;

    public JmsRemoteNotificationService() {
        try {
            final Hashtable props = new Hashtable();
            // setup the ejb: namespace URL factory
            props.put(Context.URL_PKG_PREFIXES, PACKAGE_PREFIXS);
            // create the InitialContext
            final Context context = new javax.naming.InitialContext(props);
            // Lookup the Greeter bean using the ejb: namespace syntax which is
            // explained here https://docs.jboss.org/author/display/AS71/EJB+invocations+from+a+remote+client+using+JNDI
            remoteNotificationService =  (NotificationService) context.lookup(EJB_LOOKUP);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public JmsRemoteNotificationService(NotificationService remoteNotificationService) {
        this.remoteNotificationService = remoteNotificationService;
    }

    @Override
    public void subscribe(NotificationChannel channel, NotificationHandler handler) {
        remoteNotificationService.subscribe(channel, null);
    }

    @Override
    public void unsubscribe(NotificationChannel channel, NotificationHandler handler) {
        remoteNotificationService.unsubscribe(channel, null);
    }

    @Override
    public void subscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        remoteNotificationService.subscribe(channels, null);
    }

    @Override
    public void unsubscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        remoteNotificationService.unsubscribe(channels, null);
    }
}
