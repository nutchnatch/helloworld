package notifications.receiver;

import com.ossnms.web.provider.common.api.notification.DispatcherNotificationService;

import javax.inject.Singleton;


/* TODO: This should be replaced by moving "DispatcherNotificationService.java" to a provider-notifications-receiver
common module
*/
@Singleton
public class JmsDispatcherNotificationService extends DispatcherNotificationService {
}
