package notifications.receiver;

import com.ossnms.web.api.notifications.sender.JmsService;
import org.assertj.core.api.Assertions;
import org.junit.Test;

/**
 * Created by pt104502 on 24-Jun-16.
 */
public class JmsMessageListenerTest {

    @Test
    public void testQueueName() throws Exception {
        Assertions.assertThat(JmsMessageListener.TOPIC).isEqualTo(JmsService.TOPIC);
    }
}