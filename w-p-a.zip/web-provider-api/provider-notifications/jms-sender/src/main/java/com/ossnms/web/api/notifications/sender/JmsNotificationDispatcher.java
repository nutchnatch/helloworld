package com.ossnms.web.api.notifications.sender;


import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationDispatcher;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Topic;

import static com.ossnms.web.api.notifications.sender.JmsService.TOPIC;

@Stateless
@JMSDispatcher
public class JmsNotificationDispatcher implements NotificationDispatcher<Notification> {

    @Inject
    @JMSConnectionFactory("java:jboss/exported/FrontendConnectionFactory")
    private Instance<JMSContext> context;

    @Resource(mappedName = TOPIC)
    private Topic topic;

    @Override
    public void send(Notification notification) {
        JMSContext jmsContext = context.get();
        jmsContext.createProducer().send(topic, notification);
    }

}