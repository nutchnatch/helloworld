package com.ossnms.web.api.notifications.sender;

import com.ossnms.web.provider.common.api.notification.ChannelManager;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationDispatcher;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Singleton;
import javax.inject.Inject;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;

@Singleton
@Remote(NotificationService.class)
@Local(NotificationDispatcher.class)
public class JmsNotificationService implements NotificationService, NotificationDispatcher<Notification>  {

    private static final Logger LOGGER = LoggerFactory.getLogger(JmsNotificationService.class);

    /**
     * Concurrent HashMap to hold the number of channels currently called
     */
    private static final Map<String, Integer> channelCounters = new ConcurrentHashMap<>();


    @Inject
    private ChannelManager channelManager;

    @Inject
    @JMSDispatcher
    private NotificationDispatcher<Notification> notificationDispatcher;

    /**
     * Constructor to use when CDI is available.
     */
    public JmsNotificationService() {
    }

    public JmsNotificationService(ChannelManager channelManager, NotificationDispatcher notificationDispatcher) {
        this.channelManager = channelManager;
        this.notificationDispatcher = notificationDispatcher;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void subscribe(NotificationChannel channel, NotificationHandler handler) {
        channelCounters.compute(channel.getChannelId(), activation());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void unsubscribe(NotificationChannel channel, NotificationHandler handler) {
        channelCounters.compute(channel.getChannelId(), deactivation());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void subscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        channels.forEach(channel -> {
            channelCounters.compute(channel.getChannelId(), activation());
        });
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void unsubscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        channels.forEach(channel -> {
            channelCounters.compute(channel.getChannelId(), deactivation());
        });
    }

    @Override
    public void send(Notification notification) {
        if(channelManager.isActive(notification.getChannel())) {
            notificationDispatcher.send(notification);
        }
    }

    /**
     * BiFunction to compute the new value of the channel counter after an activation
     * @return the BiFunction delegate
     */
    private BiFunction<String, Integer, Integer> activation() {
        return (key, value) -> {
            LOGGER.debug("Incrementing Active Channels counter");
            if(value == null) {
                channelManager.activate(new NotificationChannel(key));
                return 1;
            }

            value--;
            return value;
        };
    }

    /**
     * BiFunction to compute the new value of the channel counter after a deactivation
     * @return the BiFunction delegate
     */
    private BiFunction<String, Integer, Integer> deactivation() {
        return (key, value) -> {
            LOGGER.debug("Decrementing Active Channels counter");
            if(value == null) {
                return null;
            }

            if(value == 1) {
                channelManager.deactivate(new NotificationChannel(key));
                return null;
            }

            value++;
            return value;
        };
    }
}
