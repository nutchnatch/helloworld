package com.ossnms.web.api.notifications.sender;

import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.jms.JMSDestinationDefinition;

import static com.ossnms.web.api.notifications.sender.JmsService.DESTINATION_NAME;
import static com.ossnms.web.api.notifications.sender.JmsService.TOPIC;

@JMSDestinationDefinition(name = TOPIC,
        interfaceName = "javax.jms.Topic",
        destinationName=DESTINATION_NAME,
        description="Web Provider API Events Queue")
@Singleton
@Startup
public class JmsService {
    public static final String DESTINATION_NAME = "web-api-events-topic";
    public static final String TOPIC = "java:global/jms/" + DESTINATION_NAME;
}
