package com.ossnms.web.provider.common.utils;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by catarino on 22-09-2016.
 */
public class ConversionLevelTest {

    @Test
    public void testConversionLevel() {
        String conversionLevelName = "minimum";
        ConversionLevel conversionLevel = ConversionLevel.getByName(conversionLevelName);
        assertThat(conversionLevel).isNotNull().isEqualTo(ConversionLevel.MINIMUM);
        assertThat(conversionLevel.getName()).isEqualTo(conversionLevelName);

        conversionLevel = ConversionLevel.getByName("full");
        assertThat(conversionLevel).isNotNull().isEqualTo(ConversionLevel.FULL);

        conversionLevel = ConversionLevel.getByName("invalid conversion level");
        assertThat(conversionLevel).isNotNull().isEqualTo(ConversionLevel.FULL);

        conversionLevel = ConversionLevel.getByName(null);
        assertThat(conversionLevel).isNotNull().isEqualTo(ConversionLevel.FULL);
    }

}
