package com.ossnms.web.provider.common.utils;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class CoderTest {

    private static final String TEXT = "Convert to MD5";
    private static final String TEXT_MD5 = "efc9ea91f5252767621c75048ff361db";

    @Test
    public void testMd5() {
        String md5 = Coder.toMD5(TEXT);
        assertThat(md5).isNotNull().isEqualTo(TEXT_MD5);

        assertThat(Coder.toMD5(null)).isNull();
    }

    @Test
    public void testEncodeDecode() {
        String encoded = Coder.encode(TEXT);
        assertThat(encoded).isNotNull();
        Object decoded = Coder.decode(encoded);
        assertThat(decoded).isNotNull().isEqualTo(TEXT);

        encoded = Coder.encode(null);
        assertThat(encoded).isNotNull();
        decoded = Coder.decode(encoded);
        assertThat(decoded).isNull();
    }

    @Test(expected = ObjectEncodeException.class)
    public void testEncodeNotSerializable() {
        Coder.encode(new MyObject());
    }

    @Test(expected = ObjectEncodeException.class)
    public void testDecodeNotValid() {
        Coder.decode("abc");
    }

    @Test(expected = ObjectEncodeException.class)
    public void testDecodeClassNotFound() {
        Coder.decode("rO0ABXNyADBjb20uY29yaWFudC5ubWNvbW1vbi5hcGkudXRpbC5VdGlsVGVzdCRNeU9iamVjdDJnyhaLZqwFzQIAAUwABWZpZWxkdAASTGphdmEvbGFuZy9TdHJpbmc7eHBw");
    }

    private static final class MyObject {

        private String field;

        public String getField() {
            return field;
        }

        public void setField(String field) {
            this.field = field;
        }
    }
}
