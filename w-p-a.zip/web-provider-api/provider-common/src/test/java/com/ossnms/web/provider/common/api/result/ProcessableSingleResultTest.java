package com.ossnms.web.provider.common.api.result;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.result.enumerable.GenericErrorCode;
import com.ossnms.web.provider.common.api.result.enumerable.Status;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

/**
 *
 */
public class ProcessableSingleResultTest {


    @Test
    public void shouldCreateOkProcessableSingleResult() {
        ProcessableSingleResult.Builder<TestEntity, GenericErrorCode> result = new ProcessableSingleResult.Builder<>();

        ProcessableSingleResult<TestEntity, GenericErrorCode> build = result.ok(new TestEntity()).build();

        final boolean[] success = {false};
        build.onSuccess(entity -> {
            assertNotNull(entity);
            success[0] = true;
        });

        if(!success[0]) {
            fail();
        }
    }

    @Test
    public void shouldCreateServerErrorProcessableSingleResult() {
        ProcessableSingleResult.Builder<TestEntity, GenericErrorCode> result = new ProcessableSingleResult.Builder<>();

        ProcessableSingleResult<TestEntity, GenericErrorCode> build = result
                .operationStatus(Status.SERVER_ERROR)
                .errorCode(GenericErrorCode.GENERIC)
                .errorMessage("error-key")
                .build();

        final boolean[] success = {false};
        build
                .onSuccess(entity -> fail())
                .onServerError((errorCode, s) -> {
                    assertEquals(errorCode,GenericErrorCode.GENERIC);
                    assertEquals(s, "error-key");
                    success[0] = true;
                });

        if(!success[0]) {
            fail();
        }
    }


    public static class TestEntity implements EntityBase {

    }
}
