package com.ossnms.web.provider.common.utils;

import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 18-02-2016.
 */
public class TimeWatchTest {

    private TimeWatch timeWatch;

    @Before
    public void setUp() {
        timeWatch = TimeWatch.start();
    }

    @Test
    public void testStart() {
        assertThat(TimeWatch.start()).isNotNull().isInstanceOf(TimeWatch.class);
    }

    @Test
    public void testReset() {
        assertThat(timeWatch.reset()).isNotNull().isInstanceOf(TimeWatch.class);
    }

    @Test
    public void testTime() {
        assertThat(timeWatch.time()).isNotNull().isInstanceOf(Long.class).isGreaterThan(0L);
    }

    @Test
    public void testTimeWithTimeUnit() {
        assertThat(timeWatch.time(TimeUnit.MINUTES)).isNotNull().isInstanceOf(Long.class).isEqualTo(0L);
    }

}
