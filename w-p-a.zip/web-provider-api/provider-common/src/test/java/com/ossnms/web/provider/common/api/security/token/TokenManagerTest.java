package com.ossnms.web.provider.common.api.security.token;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import io.jsonwebtoken.CompressionCodecs;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.crypto.MacProvider;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.Key;
import java.util.Date;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 *
 */
public class TokenManagerTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(TokenManagerTest.class);

    private static final String KEY_ISS = "iss";

    private static final String VALUE_ISS = "testIssuer";
    private static final String KEY_SEC_TOKEN = "secToken";

    private static final Key KEY = MacProvider.generateKey();
    public static final String VALUE_USERNAME = "username";

    private static String jwToken;
    private static SecurityToken securityToken;

    @BeforeClass
    public static void beforeClass() {
        securityToken = new SecurityToken.Builder("username", "test-token").build();
        String encodedToken = TokenManager.base64Encode(securityToken).get();

        JwtBuilder builder = Jwts.builder()
                .setIssuedAt(new Date())
                // set the unique id
                .setSubject(securityToken.getUsername())
                .setIssuer("testIssuer")
                .claim(KEY_SEC_TOKEN, encodedToken)
                .compressWith(CompressionCodecs.DEFLATE)
                .signWith(SignatureAlgorithm.HS512, KEY);

        jwToken = builder.compact();
        LOGGER.info("Generated test token >> {}", jwToken);
    }

    @Test
    public void shouldExtractClaim() {
        Optional<String> iss = TokenManager.retrieveClaim(jwToken, SecurityClaim.ISSUER);
        assertTrue(iss.isPresent());
        assertEquals(VALUE_ISS, iss.get());
    }

    @Test
    public void shouldExtractClaimWithKey() {
        Optional<String> iss = TokenManager.retrieveClaim(jwToken, KEY, SecurityClaim.ISSUER);
        assertTrue(iss.isPresent());
        assertEquals(VALUE_ISS, iss.get());
    }

    @Test
    public void shouldExtractEncodedClaim() {
        Optional<SecurityToken> token = TokenManager.retrieveEncodedClaim(jwToken, SecurityClaim.SECURITY_TOKEN, SecurityToken.class);

        assertTrue(token.isPresent());
        assertEquals(VALUE_USERNAME, token.get().getUsername());
    }

    @Test
    public void shouldExtractEncodedClaimWithValidSignature() {
        Optional<SecurityToken> token = TokenManager.retrieveEncodedClaim(jwToken, KEY, SecurityClaim.SECURITY_TOKEN, SecurityToken.class);

        assertTrue(token.isPresent());
        assertEquals(VALUE_USERNAME, token.get().getUsername());
    }
}
