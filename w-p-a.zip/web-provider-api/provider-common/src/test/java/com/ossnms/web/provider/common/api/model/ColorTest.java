package com.ossnms.web.provider.common.api.model;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created on 21-10-2016.
 */
public class ColorTest {

    private Color color;

    private static final int RED = 100;
    private static final int GREEN = 150;
    private static final int BLUE = 200;

    @Before
    public void setUp() throws Exception {
        color = new Color(RED, GREEN, BLUE);
    }

    @Test
    public void testGetRed() throws Exception {
        assertThat(color.getRed()).isNotNull().isEqualTo(RED);
    }

    @Test
    public void testGetGreen() throws Exception {
        assertThat(color.getGreen()).isNotNull().isEqualTo(GREEN);
    }

    @Test
    public void testGetBlue() throws Exception {
        assertThat(color.getBlue()).isNotNull().isEqualTo(BLUE);
    }

}
