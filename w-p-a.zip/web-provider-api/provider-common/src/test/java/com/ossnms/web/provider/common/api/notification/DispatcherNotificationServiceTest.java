package com.ossnms.web.provider.common.api.notification;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import static org.mockito.Mockito.*;


/**
 * Created by jfalcao on 08-06-2016.
 */

@RunWith(MockitoJUnitRunner.class)
public class DispatcherNotificationServiceTest {
    @Mock
    private NotificationService remoteNotificationService;
    private NotificationChannel channel1 = new NotificationChannel("channel1");
    private NotificationChannel channel2 = new NotificationChannel("channel2");
    private DispatcherNotificationService dns;
    private List<NotificationChannel> channels = Arrays.asList(channel1, channel2);
    private NotificationHandler nh;
    private NotificationHandler nh1;
    private NotificationHandler nhException;
    private Notification notification1 = new Notification.NotificationBuilder().setChannel(channel1).build();
    private Notification notification2 = new Notification.NotificationBuilder().setChannel(channel1).build();

    @Before
    public void setup() throws NotificationHandlerException {
//        dns = new DispatcherNotificationService(remoteNotificationService);
        nh = mock(NotificationHandler.class);
        nh1 = mock(NotificationHandler.class);
        nhException = mock(NotificationHandler.class);
        doThrow(NotificationHandlerException.class).when(nhException).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldNotifyOneListenerForAChannelOnNotification() throws Exception {
        dns.subscribe(channel1, nh);

        dns.handle(notification1);
        verify(remoteNotificationService, times(1)).subscribe(channel1, dns);
        verify(nh, times(1)).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldNotifyMoreThanOneListenerForAChannelOnNotification() throws Exception {
        dns.subscribe(channel1, nh);
        dns.subscribe(channel1, nh1);

        dns.handle(notification1);

        verify(remoteNotificationService, times(1)).subscribe(channel1, dns);
        verify(nh, times(1)).handle(notification1);
        verify(nh1, times(1)).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldNotNotifyListenersForAUnsubscribedChannel() throws Exception {
        subscribeChannel(channel1, nh, nh1);

        unsubscribeChannel(channel1, nh, nh1);
        dns.handle(notification1);


        verify(nh, never()).handle(notification1);
        verify(nh1, never()).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldNotCallUnsubscribeOnRemoteServiceIfThereAreRegisteredHandlersForAChannel() throws Exception {
        subscribeChannel(channel1, nh, nh1);

        unsubscribeChannel(channel1, nh1);
        dns.handle(notification1);

        verify(remoteNotificationService, times(0)).unsubscribe(channel1, dns);
        verify(nh, times(1)).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldCallUnsubscribeOnRemoteServiceIfThereAreNoRegisteredHandlersForAChannel() {
        subscribeChannel(channel1, nh, nh1);
        unsubscribeChannel(channel1, nh1, nh);
        dns.handle(notification1);

        verify(remoteNotificationService, times(1)).unsubscribe(channel1, dns);
    }

    @Test
    @Ignore
    public void shouldCallAllRegisteredNotificationHandlersWhenExceptionIsThrownCallingOne() throws Exception {
        subscribeChannel(channel1, nh, nhException, nh1);

        dns.handle(notification1);

        verify(nh, times(1)).handle(notification1);
        verify(nh1, times(1)).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldDeliveryNotificationsToAHandlerEvenIfPreviouslyThrownException() throws Exception {
        NotificationHandler nhConditionalException = mock(NotificationHandler.class);
        doThrow(NotificationHandlerException.class).when(nhConditionalException).handle(notification1);
        subscribeChannel(channel1, nh, nhConditionalException);

        dns.handle(notification1);
        dns.handle(notification2);

        verify(nh, times(2)).handle(any(Notification.class));
        verify(nhConditionalException, times(1)).handle(notification2);
        verify(nhConditionalException, times(1)).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldNotHandleNotificationsForChannelWithNoRegisteredHandlers() throws Exception {
        subscribeChannel(channel2, nh);

        dns.handle(notification1);

        verify(nh, times(0)).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldIgnoreNotificationHandlerForSameRegisteredChannels() throws Exception {
        subscribeChannel(channel1, nh);
        subscribeChannel(channel1, nh);

        dns.handle(notification1);

        verify(remoteNotificationService, times(1)).subscribe(channel1, dns);
        verify(nh, times(1)).handle(notification1);
    }

    @Test
    @Ignore
    public void shouldIgnoreUnsubscribeForUnregisteredHandler() throws Exception {
        unsubscribeChannel(channel1, nh);

        dns.handle(notification1);

        verify(remoteNotificationService, times(0)).subscribe(channel1, dns);
    }

    @Test
    @Ignore
    public void shouldIgnoreNotificationsFromUnregisteredChannels() throws Exception {
        dns.handle(notification1);

        verify(remoteNotificationService, times(0)).subscribe(channel1, dns);
    }

    @Test
    @Ignore
    public void shouldStillNotifyHandlerWhenUnregisterOccursOnNotification() throws Exception {
        subscribeChannel(channel1, nh, nh1);

        doAnswer(invocation -> {
            dns.unsubscribe(channel1, nh);
            return null;
        }).when(nh1).handle(notification1);

        doAnswer(invocation -> {
            dns.unsubscribe(channel1, nh1);
            return null;
        }).when(nh).handle(notification1);


        dns.handle(notification1);

        verify(nh, times(1)).handle(notification1);
        verify(nh1, times(1)).handle(notification1);
    }


    private void subscribeChannel(NotificationChannel channel, NotificationHandler ... notificationHandlers){
        Stream.of(notificationHandlers).forEach(handler -> dns.subscribe(channel, handler));
    }

    private void unsubscribeChannel(NotificationChannel channel, NotificationHandler ... notificationHandlers){
        Stream.of(notificationHandlers).forEach(handler -> dns.unsubscribe(channel, handler));
    }
}
