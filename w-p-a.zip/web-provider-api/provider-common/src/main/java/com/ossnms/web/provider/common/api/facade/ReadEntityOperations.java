package com.ossnms.web.provider.common.api.facade;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;

import java.util.Collection;

/**
 * Base interface that defines read operations possible to perform on a given entity.
 *
 * @param <EID> type of the entity ID
 * @param <E> type of the entity
 * @param <ES> type of the entity summary
 * @param <F> type of the entity fields
 */
public interface ReadEntityOperations <EID extends EntityID, E extends Entity<EID>, ES extends EntitySummary<EID>, F extends Enum<F>> extends BaseEntityOperations{

    /**
     * Retrieves an instance of the summary, given the ID.
     *
     * @param securityToken the security token which will authorize the current user the security token which will authorize the current user
     * @param id an instance of the ID, which identifies the entity to retrieve.
     *
     * @return an instance of the summary if the entity is found, or null otherwise
     */
    ES getSummary(SecurityToken securityToken, EID id);

    /**
     * Retrieves an instance of the entity, which contains the details of the object identified by the instance of the ID
     *
     * @param securityToken the security token which will authorize the current user
     * @param id an instance of the ID, which identifies the entity to retrieve.
     * @return an instance of the entity if it exists, otherwise returns null
     */
    E getDetails(SecurityToken securityToken, EID id);

    /**
     * Retrieves all the instances of the summary, which represent the summary of a given entity, identified by the instances
     * of the ID
     *
     * @param securityToken the security token which will authorize the current user
     * @param ids instances of the ID, which identify the entities to retrieve.
     * @return an instance of <code>OperationResult</code>, containing the result collection of retrieving the summaries of
     * the entities identified by the <code>Collection</code> of the ID
     */
    OperationResult<ES, F> getAllSummary(SecurityToken securityToken, Collection<EID> ids);

    /**
     *
     * @param securityToken the security token which will authorize the current user
     * @param filterBy a <code>Collection</code> of instances of <code>Filter</code>, which represent all the filters to
     *                 apply to the current query
     * @param sortBy an instance of <code>Sort</code>, which defines the parameter and direction of the sort
     * @param page an instance of <code>Page</code>, which defines pagination parameters. If none is specified, the
     *             default will be page 1, with a result size of 10 elements.
     * @return an instance of <code>OperationResult</code>, containing the result collection of retrieving the summaries of
     * the entities identified by the specified query parameters.
     */
    OperationResult<ES, F> getAllSummary(SecurityToken securityToken, Collection<Filter<F>> filterBy, Sort<F> sortBy, Page page);

    /**
     *
     * @param securityToken the security token which will authorize the current user
     * @param ids instances of the ID, which identify the entities to retrieve.
     * @return an instance of <code>OperationResult</code>, containing the result collection of retrieving the summaries of
     * the entities identified by the <code>Collection</code> of the ID
     */
    OperationResult<E, F> getAll(SecurityToken securityToken, Collection<EID> ids);

    /**
     *
     * @param securityToken the security token which will authorize the current user
     * @param filterBy a <code>Collection</code> of instances of <code>Filter</code>, which represent all the filters to
     *                 apply to the current query
     * @param sortBy an instance of <code>Sort</code>, which defines the parameter and direction of the sort
     * @param page an instance of <code>Page</code>, which defines pagination parameters. If none is specified, the
     *             default will be page 1, with a result size of 10 elements.
     * @return an instance of <code>OperationResult</code>, containing the result collection of retrieving the summaries of
     * the entities identified by the specified query parameters.
     */
    OperationResult<E, F> getAll(SecurityToken securityToken, Collection<Filter<F>> filterBy, Sort<F> sortBy, Page page);

    /**
     *
     * @param securityToken the security token which will authorize the current user
     * @param filterBy a <code>Collection</code> of instances of <code>Filter</code>, which represent all the filters to
     *                 apply to the current query
     * @param sortBy an instance of <code>Sort</code>, which defines the parameter and direction of the sort
     * @param page an instance of <code>Page</code>, which defines pagination parameters. If none is specified, the
     *             default will be page 1, with a result size of 10 elements.
     * @return an instance of <code>OperationResult</code>, containing the result collection of retrieving the summaries of
     * the entities identified by the specified query parameters.
     */
    OperationResult<EID, F> getAllIds(SecurityToken securityToken, Collection<Filter<F>> filterBy, Sort<F> sortBy, Page page);

}
