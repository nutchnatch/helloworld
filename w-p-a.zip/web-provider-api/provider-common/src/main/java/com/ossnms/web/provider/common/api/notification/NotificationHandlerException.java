package com.ossnms.web.provider.common.api.notification;

/**
 * Created by pt104502 on 28-Jun-16.
 */
public class NotificationHandlerException extends Exception {
    private static final long serialVersionUID = -4536328821704408067L;

    public NotificationHandlerException() {
    }

    public NotificationHandlerException(String message) {
        super(message);
    }

    public NotificationHandlerException(String message, Throwable cause) {
        super(message, cause);
    }
}
