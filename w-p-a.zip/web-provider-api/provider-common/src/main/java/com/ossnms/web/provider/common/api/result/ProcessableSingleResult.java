package com.ossnms.web.provider.common.api.result;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.common.api.result.enumerable.Status;

import java.io.Serializable;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import static com.ossnms.web.provider.common.api.result.enumerable.Status.ALREADY_EXISTS;
import static com.ossnms.web.provider.common.api.result.enumerable.Status.BAD_REQUEST;
import static com.ossnms.web.provider.common.api.result.enumerable.Status.NOT_FOUND;
import static com.ossnms.web.provider.common.api.result.enumerable.Status.OK;
import static com.ossnms.web.provider.common.api.result.enumerable.Status.SERVER_ERROR;

/**
 *
 */
public final class ProcessableSingleResult<ENTITY extends Serializable, ERROR_CODE extends Enum<ERROR_CODE>> implements Serializable {

    private static final long serialVersionUID = -6092573161078168860L;

    private final ENTITY entity;
    private final Status operationStatus;
    private final ERROR_CODE errorCode;
    private final String errorMessage;

    /**
     * Builder compatible constructor
     * @param builder the {@link Builder} instance which will allow to construct the object
     */
    private ProcessableSingleResult(Builder<ENTITY, ERROR_CODE> builder) {
        this.entity = builder.entity;
        this.operationStatus = builder.operationStatus;
        this.errorCode = builder.errorCode;
        this.errorMessage = builder.errorMessage;
    }

    /**
     *
     */
    public ENTITY getEntity() {
        return entity;
    }

    /**
     *
     */
    public Status getOperationStatus() {
        return operationStatus;
    }

    /**
     *
     */
    public ERROR_CODE getErrorCode() {
        return errorCode;
    }

    /**
     *
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * If the operation which
     */
    public ProcessableSingleResult<ENTITY, ERROR_CODE> onSuccess(Consumer<ENTITY> onSuccess) {
        if(getOperationStatus().equals(OK)) {
            onSuccess.accept(getEntity());
        }
        return this;
    }

    /**
     *
     * @param onNotFound
     * @return
     */
    public ProcessableSingleResult<ENTITY, ERROR_CODE> onNotFound(Runnable onNotFound) {
        if(getOperationStatus().equals(NOT_FOUND)) {
            onNotFound.run();
        }
        return this;
    }

    /**
     *
     * @param onAlreadyExists
     * @return
     */
    public ProcessableSingleResult<ENTITY, ERROR_CODE> onAlreadyExists(Runnable onAlreadyExists) {
        if(getOperationStatus().equals(ALREADY_EXISTS)) {
            onAlreadyExists.run();
        }
        return this;
    }

    /**
     *
     * @param onBadRequest
     * @return
     */
    public ProcessableSingleResult<ENTITY, ERROR_CODE> onBadRequest(BiConsumer<ERROR_CODE, String> onBadRequest) {
        if(getOperationStatus().equals(BAD_REQUEST)) {
            onBadRequest.accept(getErrorCode(), getErrorMessage());
        }
        return this;
    }

    /**
     *
     * @param onServerError
     * @return
     */
    public ProcessableSingleResult<ENTITY, ERROR_CODE> onServerError(BiConsumer<ERROR_CODE, String> onServerError) {
        if(getOperationStatus().equals(SERVER_ERROR)) {
            onServerError.accept(getErrorCode(), getErrorMessage());
        }
        return this;
    }

    /**
     *
     */
    public static class Builder<ENTITY extends Serializable, ERROR_CODE extends Enum<ERROR_CODE>>
            implements ObjectBuilder<ProcessableSingleResult<ENTITY, ERROR_CODE>> {

        private ENTITY entity;
        private Status operationStatus;
        private ERROR_CODE errorCode;
        private String errorMessage;

        /**
         *
         * @param entity
         * @return
         */
        public Builder<ENTITY, ERROR_CODE> ok(ENTITY entity) {
            this.operationStatus = OK;
            this.entity = entity;
            return this;
        }

        /**
         *
         * @param operationStatus
         * @return
         */
        public Builder<ENTITY, ERROR_CODE> operationStatus(Status operationStatus) {
            this.operationStatus = operationStatus;
            return this;
        }

        /**
         *
         * @param errorCode
         * @return
         */
        public Builder<ENTITY, ERROR_CODE> errorCode(ERROR_CODE errorCode) {
            this.errorCode = errorCode;
            return this;
        }

        /**
         *
         * @param errorMessage
         * @return
         */
        public Builder<ENTITY, ERROR_CODE> errorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }

        /**
         *
         * @return
         */
        @Override
        public ProcessableSingleResult<ENTITY, ERROR_CODE> build() {
            return new ProcessableSingleResult<>(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        ProcessableSingleResult<?, ?> that = (ProcessableSingleResult<?, ?>) o;
        return Objects.equals(getEntity(), that.getEntity()) &&
                getOperationStatus() == that.getOperationStatus() &&
                Objects.equals(getErrorCode(), that.getErrorCode()) &&
                Objects.equals(getErrorMessage(), that.getErrorMessage());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEntity(), getOperationStatus(), getErrorCode(), getErrorMessage());
    }
}
