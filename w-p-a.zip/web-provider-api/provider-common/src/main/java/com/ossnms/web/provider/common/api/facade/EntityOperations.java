package com.ossnms.web.provider.common.api.facade;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.security.SecurityToken;

/**
 * Base interface that defines operations possible to perform on a given entity.
 *
 * extends from ReadEntityOperations
 *
 * @param <EID> type of the entity ID
 * @param <E> type of the entity
 * @param <ES> type of the entity summary
 * @param <F> type of the entity fields
 */
public interface EntityOperations<EID extends EntityID, E extends Entity<EID>, ES extends EntitySummary<EID>, F extends Enum<F>>
    extends ReadEntityOperations<EID, E, ES, F>
{
    /**
     * Creates the instance.
     *
     * @param securityToken the security token which will authorize the current user
     * @param entity the instance to persist.
     * @return the instance which represents the persisted object.
     */
    EID insert(SecurityToken securityToken, E entity);

    /**
     * Updates the instance.
     *
     * @param securityToken the security token which will authorize the current user
     * @param entity the instance to update.
     * @return the instance which represents the updated object.
     */
    EID update(SecurityToken securityToken, E entity);

    /**
     * Deletes the record identified
     *
     * @param securityToken the security token which will authorize the current user
     * @param id identifies the entity to retrieve.
     */
    void delete(SecurityToken securityToken, EID id);
}
