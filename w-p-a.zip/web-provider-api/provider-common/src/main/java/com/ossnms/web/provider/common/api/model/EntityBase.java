package com.ossnms.web.provider.common.api.model;

import java.io.Serializable;

/**
 * Base interface that defines a base entity class
 */
public interface EntityBase extends Serializable {
}