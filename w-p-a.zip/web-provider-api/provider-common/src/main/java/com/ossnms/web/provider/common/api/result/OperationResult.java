package com.ossnms.web.provider.common.api.result;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.model.EntityBase;

import java.io.Serializable;
import java.util.Collection;
import java.util.Objects;

/**
 * Represents the outcome of a query operation.
 *
 * @param <ENTITY> the type of the entity
 * @param <FIELD> the type of the field enumerable for the said entity
 */
public final class OperationResult<ENTITY extends EntityBase, FIELD extends Enum<FIELD>> implements Serializable {

    private static final long serialVersionUID = -5204663593793279809L;

    // Result Stream
    private final Collection<ENTITY> resultCollection;

    // query parameters
    private final Page page;
    private final Sort<FIELD> sortBy;
    private final Collection<Filter<FIELD>> filterBy;

    // statistics
    private final int totalElements;
    private final int totalFilteredElements;

    /**
     *
     * @return
     */
    public Collection<ENTITY> getResultCollection() {
        return resultCollection;
    }

    /**
     *
     * @return
     */
    public Collection<Filter<FIELD>> getFilterBy() {
        return filterBy;
    }

    /**
     *
     * @return
     */
    public Page getPage() {
        return page;
    }

    /**
     *
     * @return
     */
    public Sort<FIELD> getSortBy() {
        return sortBy;
    }

    /**
     *
     * @return
     */
    public int getTotalElements() {
        return totalElements;
    }

    /**
     *
     * @return
     */
    public int getTotalFilteredElements() {
        return totalFilteredElements;
    }


    /**
     * Builder class for {@link OperationResult}</code>
     */
    public static class Builder<ENTITY extends EntityBase, FIELD extends Enum<FIELD>>
            implements ObjectBuilder<OperationResult<ENTITY, FIELD>> {
        private Collection<ENTITY> resultCollection;
        private Page page;
        private Sort<FIELD> sortBy;
        private Collection<Filter<FIELD>> filterBy;
        private int totalElements;
        private int totalFilteredElements;

        /**
         * Builder constructor, with obligatory field definition
         * @param resultCollection the collection of objects which form the result
         * @param totalElements the total number of results
         */
        public Builder(Collection<ENTITY> resultCollection, int totalElements) {
            this.resultCollection = resultCollection;
            this.totalElements = totalElements;
        }

        public Builder<ENTITY, FIELD> setPage(Page page) {
            this.page = page;
            return this;
        }

        public Builder<ENTITY, FIELD> setSortBy(Sort<FIELD> sortBy) {
            this.sortBy = sortBy;
            return this;
        }

        public Builder<ENTITY, FIELD> setFilterBy(Collection<Filter<FIELD>> filterBy) {
            this.filterBy = filterBy;
            return this;
        }

        public Builder<ENTITY, FIELD> setTotalFilteredElements(int totalFilteredElements) {
            this.totalFilteredElements = totalFilteredElements;
            return this;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public OperationResult<ENTITY, FIELD> build() {
            OperationResult<ENTITY, FIELD> operationResult = new OperationResult<>(this);

            if(operationResult.resultCollection == null || operationResult.totalElements < 0){
                throw new IllegalStateException("OperationResult builder is in an invalid state, since either " +
                        "resultCollection is null or totalElements is less than 0");
            }

            return operationResult;
        }
    }


    /**
     *
     * @param builder
     */
    private OperationResult(Builder<ENTITY, FIELD> builder) {
        this.resultCollection       = builder.resultCollection;
        this.page                   = builder.page;
        this.sortBy                 = builder.sortBy;
        this.filterBy               = builder.filterBy;
        this.totalElements          = builder.totalElements;
        this.totalFilteredElements  = builder.totalFilteredElements;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        OperationResult<?, ?> that = (OperationResult<?, ?>) o;
        return totalElements == that.totalElements &&
                totalFilteredElements == that.totalFilteredElements &&
                Objects.equals(resultCollection, that.resultCollection) &&
                Objects.equals(page, that.page) &&
                Objects.equals(sortBy, that.sortBy) &&
                Objects.equals(filterBy, that.filterBy);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                resultCollection,
                page,
                sortBy,
                filterBy,
                totalElements,
                totalFilteredElements
        );
    }
}
