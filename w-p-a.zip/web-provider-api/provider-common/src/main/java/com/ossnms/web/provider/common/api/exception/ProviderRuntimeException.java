package com.ossnms.web.provider.common.api.exception;

public class ProviderRuntimeException extends RuntimeException {

    private static final long serialVersionUID = -6542504580896180493L;

}
