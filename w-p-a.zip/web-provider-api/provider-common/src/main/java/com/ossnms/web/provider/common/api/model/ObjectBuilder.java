package com.ossnms.web.provider.common.api.model;

/**
 * ObjectBuilder interface, which defines the contract for builder objects
 */
public interface ObjectBuilder<TYPE> {

    /**
     * {@link ObjectBuilder} implementation shall implement a build method.
     * This method is responsible for:
     * - evaluating current builder state;
     * - constructing the object;
     * - throwing IllegalStateException on invalid state
     * - returning the object on success
     *
     * @return an instance of {@link TYPE}
     * @throws IllegalStateException if the Builder state is not valid on build.
     */
    TYPE build();
}
