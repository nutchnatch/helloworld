package com.ossnms.web.provider.common.api.model;

/**
 * Typification interface for entities which can be identified by an {@link ID}
 */
public interface Entity<ID extends EntityID> extends EntitySummary<ID> {
}
