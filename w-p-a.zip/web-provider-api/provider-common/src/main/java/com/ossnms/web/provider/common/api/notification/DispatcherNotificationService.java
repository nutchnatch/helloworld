package com.ossnms.web.provider.common.api.notification;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Instances of this class are {@link NotificationService} instances, keeping the provided {@link NotificationHandler}
 * internally. They are also {@link NotificationDispatcher} for {@link Notification}, calling all subscribed {@link
 * NotificationHandler} for the notification channel ({@link Notification#getChannel()}).
 */
public abstract class DispatcherNotificationService implements NotificationService, NotificationHandler {
    private final Logger LOGGER = LoggerFactory.getLogger(DispatcherNotificationService.class);

    @Inject
    @LocalNotificationService
    private NotificationService delegateNotificationService;

    private final Map<NotificationChannel, List<NotificationHandler>> channelHandlers = new HashMap<>();

    /**
     * Constructor to be used with CDI.
     */
    public DispatcherNotificationService() {
    }

    public DispatcherNotificationService(NotificationService remoteNotificationService) {
        this.delegateNotificationService = remoteNotificationService;
    }

    @Override
    public void subscribe(NotificationChannel channel, NotificationHandler handler) {
        synchronized (channelHandlers) {
            List<NotificationHandler> notificationHandlers = getNotificationHandlers(channel);
            if (notificationHandlers.isEmpty()) {
                delegateNotificationService.subscribe(channel, this);
            }
            if (!notificationHandlers.contains(handler)) {
                notificationHandlers.add(handler);
            } else {
                LOGGER.warn("Handler already subscribed.");
            }
        }
    }

    @Override
    public void unsubscribe(NotificationChannel channel, NotificationHandler handler) {
        synchronized (channelHandlers) {
            List<NotificationHandler> notificationHandlers = channelHandlers.get(channel);
            if (notificationHandlers != null) {
                // If was only created so that the message logger below is reported properly
                if (notificationHandlers.remove(handler) && notificationHandlers.size() == 0) {
                    delegateNotificationService.unsubscribe(channel, this);
                }
            } else {
                LOGGER.warn("Handler not subscribed.");
            }
        }
    }

    @Override
    public void subscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        channels.forEach(c -> subscribe(c, handler));
    }

    @Override
    public void unsubscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        channels.forEach(c -> unsubscribe(c, handler));
    }

    @Override
    public void handle(Notification notification) {
        List<NotificationHandler> notificationHandlersCopy = null;
        NotificationChannel channel = notification.getChannel();

        synchronized (channelHandlers) {
            List<NotificationHandler> notificationHandlers = channelHandlers.get(channel);
            if (notificationHandlers != null) {
                notificationHandlersCopy = new ArrayList<>(notificationHandlers);
            } else {
                LOGGER.warn("No handlers found for the specified notification channel {}", channel.getChannelId());
            }
        }
        if (notificationHandlersCopy != null) {
            notificationHandlersCopy.forEach(nh -> handleNotification(nh, notification));
        }
    }

    /**
     *
     * @param channel
     * @return
     */
    private List<NotificationHandler> getNotificationHandlers(NotificationChannel channel) {
        return channelHandlers.computeIfAbsent(channel, k -> new ArrayList<>());
    }

    /**
     * Handles the notification with the specified notification handler.
     *
     * @param nh the notification handler
     * @param notification the notification to be handled
     */
    private void handleNotification(NotificationHandler nh, Notification notification) {
        try {
            nh.handle(notification);
        } catch (NotificationHandlerException e) {
            // Something happened in this handler.
            LOGGER.error("Something happened when notification handler {}, processing the notification {}", nh,
                    notification, e);
        }
    }
}
