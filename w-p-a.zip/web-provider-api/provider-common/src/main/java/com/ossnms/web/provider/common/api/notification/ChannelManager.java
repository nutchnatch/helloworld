package com.ossnms.web.provider.common.api.notification;

import java.util.Collection;

/**
 * Created by jfalcao on 08-06-2016.
 */
public interface ChannelManager {
    void activate(NotificationChannel channel);

    void deactivate(NotificationChannel channel);

    void activate(Collection<NotificationChannel> channels);

    void deactivate(Collection<NotificationChannel> channels);

    boolean isActive(NotificationChannel channel);
}
