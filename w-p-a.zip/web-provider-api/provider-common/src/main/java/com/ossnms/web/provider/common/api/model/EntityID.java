package com.ossnms.web.provider.common.api.model;

/**
 *
 */
public interface EntityID extends EntityBase {

}
