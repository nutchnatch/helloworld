package com.ossnms.web.provider.common.api.security;

/**
 *
 */

public @interface Secure {
}
