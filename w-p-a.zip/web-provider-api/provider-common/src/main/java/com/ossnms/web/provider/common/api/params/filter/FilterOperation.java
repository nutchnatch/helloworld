package com.ossnms.web.provider.common.api.params.filter;

import java.util.HashMap;
import java.util.Map;

/**
 * Enumerates all the Filter Operations available to be used with a Filter.
 */
public enum FilterOperation {

    /**
     * Matches the value
     */
    EQUALS              ("="),

    /**
     * Should be greater than the value
     */
    GREATER_THAN        (">"),

    /**
     * Should be less than the value
     */
    LESS_THAN           ("<"),

    /**
     * Should be greater than or equals
     */
    GREATER_OR_EQUALS   (">="),

    /**
     * Should be less than or equals
     */
    LESS_OR_EQUALS      ("<="),

    /**
     * Should be similar to the value
     */
    SIMILAR             ("~"),

    /**
     * Should contain the value
     */
    CONTAINS            ("()"),

    /**
     * Should start with the value
     */
    STARTS_WITH         ("^"),

    /**
     * Should end with the value
     */
    ENDS_WITH           ("$");


    public static final int INITIAL_CAPACITY = 10;

    private static Map<String, FilterOperation> operationsMap = new HashMap<>(INITIAL_CAPACITY);

    private String operand;

    /**
     * Constructor for FilterOperation enumeration items
     * @param operand the operand which represents the value
     */
    FilterOperation(String operand){
        this.operand = operand;
    }

    /**
     * Initializes the OperationsMap of this FilterOperation enum. This will map the operand to the corresponding
     * <code>FilterOperation</code>
     */
    private static void initOperationsMap(){
        for(FilterOperation operation : FilterOperation.values()){
            operationsMap.put(operation.getOperand(), operation);
        }
    }

    /**
     * Retrieves the FilterOperation instance from the enum, matching the specified operand
     *
     * @param operand the operand to get FilterOperation with
     * @return if <code>operand</code> is not null, and if it matches an instance of <code>FilterOperation</code>,
     * returns the instance; otherwise returns null.
     */
    public static FilterOperation fromOperand(String operand){
        if(operationsMap.size() == 0){
            initOperationsMap();
        }

        return operationsMap.get(operand);
    }

    /**
     * @return the operand String
     */
    public String getOperand() {
        return operand;
    }
}
