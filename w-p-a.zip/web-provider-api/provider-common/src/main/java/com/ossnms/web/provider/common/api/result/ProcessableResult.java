package com.ossnms.web.provider.common.api.result;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.enumerable.Status;

import java.io.Serializable;
import java.util.Collection;
import java.util.Objects;
import java.util.function.BiConsumer;

import static com.ossnms.web.provider.common.api.result.enumerable.Status.ALREADY_EXISTS;
import static com.ossnms.web.provider.common.api.result.enumerable.Status.BAD_REQUEST;
import static com.ossnms.web.provider.common.api.result.enumerable.Status.NOT_FOUND;
import static com.ossnms.web.provider.common.api.result.enumerable.Status.OK;
import static com.ossnms.web.provider.common.api.result.enumerable.Status.SERVER_ERROR;

/**
 *
 */
public final class ProcessableResult<ENTITY extends Serializable, FIELD extends Enum<FIELD>, ERROR_CODE extends Enum<ERROR_CODE>> implements Serializable {

    private static final long serialVersionUID = -2986640006331563574L;

    // ProcessableResult Stream
    private final Collection<ENTITY> resultCollection;

    // query parameters
    private final Page page;
    private final Sort<FIELD> sortBy;
    private final Collection<Filter<FIELD>> filterBy;

    // statistics
    private final int totalElements;
    private final int totalFilteredElements;

    // error handling
    private final Status operationStatus;
    private final ERROR_CODE errorCode;
    private final String errorMessage;

    /**
     *
     * @return
     */
    public Collection<ENTITY> getResultCollection() {
        return resultCollection;
    }

    /**
     *
     * @return
     */
    public Collection<Filter<FIELD>> getFilterBy() {
        return filterBy;
    }

    /**
     *
     * @return
     */
    public Page getPage() {
        return page;
    }

    /**
     *
     * @return
     */
    public Sort<FIELD> getSortBy() {
        return sortBy;
    }

    /**
     *
     * @return
     */
    public int getTotalElements() {
        return totalElements;
    }

    /**
     *
     * @return
     */
    public int getTotalFilteredElements() {
        return totalFilteredElements;
    }

    /**
     *
     * @return
     */
    public Status getOperationStatus() {
        return operationStatus;
    }

    /**
     *
     * @return
     */
    public ERROR_CODE getErrorCode() {
        return errorCode;
    }

    /**
     *
     * @return
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     *
     */
    public ProcessableResult<ENTITY, FIELD, ERROR_CODE> onSuccess(BiConsumer<Collection<ENTITY>, Integer> onSuccess) {
        if(getOperationStatus().equals(OK)) {
            onSuccess.accept(getResultCollection(), getTotalElements());
        }
        return this;
    }

    /**
     *
     * @param onNotFound
     * @return
     */
    public ProcessableResult<ENTITY, FIELD, ERROR_CODE> onNotFound(Runnable onNotFound) {
        if(getOperationStatus().equals(NOT_FOUND)) {
            onNotFound.run();
        }
        return this;
    }

    /**
     *
     * @param onAlreadyExists
     * @return
     */
    public ProcessableResult<ENTITY, FIELD, ERROR_CODE> onAlreadyExists(Runnable onAlreadyExists) {
        if(getOperationStatus().equals(ALREADY_EXISTS)) {
            onAlreadyExists.run();
        }
        return this;
    }

    /**
     *
     * @param onBadRequest
     * @return
     */
    public ProcessableResult<ENTITY, FIELD, ERROR_CODE> onBadRequest(BiConsumer<ERROR_CODE, String> onBadRequest) {
        if(getOperationStatus().equals(BAD_REQUEST)) {
            onBadRequest.accept(getErrorCode(), getErrorMessage());
        }
        return this;
    }

    /**
     *
     * @param onServerError
     * @return
     */
    public ProcessableResult<ENTITY, FIELD, ERROR_CODE> onServerError(BiConsumer<ERROR_CODE, String> onServerError) {
        if(getOperationStatus().equals(SERVER_ERROR)) {
            onServerError.accept(getErrorCode(), getErrorMessage());
        }
        return this;
    }

    /**
     * Builder class for {@link OperationResult}</code>
     */
    public static class Builder<ENTITY extends Serializable, FIELD extends Enum<FIELD>, ERROR_CODE extends Enum<ERROR_CODE>>
            implements ObjectBuilder<ProcessableResult<ENTITY, FIELD, ERROR_CODE>> {

        private Collection<ENTITY> resultCollection;
        private Page page;
        private Sort<FIELD> sortBy;
        private Collection<Filter<FIELD>> filterBy;
        private int totalElements;
        private int totalFilteredElements;

        private Status operationStatus;
        private ERROR_CODE errorCode;
        private String errorMessage;

        /**
         * Builder constructor, with obligatory field definition
         * @param resultCollection the collection of objects which form the result
         * @param totalElements the total number of results
         */
        public Builder(Collection<ENTITY> resultCollection, int totalElements) {
            this.resultCollection = resultCollection;
            this.totalElements = totalElements;
        }

        public Builder<ENTITY, FIELD, ERROR_CODE> setPage(Page page) {
            this.page = page;
            return this;
        }

        public Builder<ENTITY, FIELD, ERROR_CODE> setSortBy(Sort<FIELD> sortBy) {
            this.sortBy = sortBy;
            return this;
        }

        public Builder<ENTITY, FIELD, ERROR_CODE> setFilterBy(Collection<Filter<FIELD>> filterBy) {
            this.filterBy = filterBy;
            return this;
        }

        public Builder<ENTITY, FIELD, ERROR_CODE> setTotalFilteredElements(int totalFilteredElements) {
            this.totalFilteredElements = totalFilteredElements;
            return this;
        }

        public Builder<ENTITY, FIELD, ERROR_CODE> setOperationStatus(Status operationStatus) {
            this.operationStatus = operationStatus;
            return this;
        }

        public Builder<ENTITY, FIELD, ERROR_CODE> setErrorCode(ERROR_CODE errorCode) {
            this.errorCode = errorCode;
            return this;
        }

        public Builder<ENTITY, FIELD, ERROR_CODE> setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
            return this;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public ProcessableResult<ENTITY, FIELD, ERROR_CODE> build() {
            ProcessableResult<ENTITY, FIELD, ERROR_CODE> operationResult = new ProcessableResult<>(this);

            if(operationResult.resultCollection == null || operationResult.totalElements < 0){
                throw new IllegalStateException("OperationResult builder is in an invalid state, since either " +
                        "resultCollection is null or totalElements is less than 0");
            }

            return operationResult;
        }
    }


    /**
     *
     * @param builder
     */
    private ProcessableResult(Builder<ENTITY, FIELD, ERROR_CODE> builder) {
        this.resultCollection       = builder.resultCollection;

        this.page                   = builder.page;
        this.sortBy                 = builder.sortBy;
        this.filterBy               = builder.filterBy;

        this.totalElements          = builder.totalElements;
        this.totalFilteredElements  = builder.totalFilteredElements;

        this.operationStatus        = builder.operationStatus;
        this.errorCode              = builder.errorCode;
        this.errorMessage           = builder.errorMessage;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ProcessableResult<?, ?, ?> that = (ProcessableResult<?, ?, ?>) o;
        return totalElements == that.totalElements &&
                totalFilteredElements == that.totalFilteredElements &&
                Objects.equals(resultCollection, that.resultCollection) &&
                Objects.equals(page, that.page) &&
                Objects.equals(sortBy, that.sortBy) &&
                Objects.equals(filterBy, that.filterBy);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                resultCollection,
                page,
                sortBy,
                filterBy,
                totalElements,
                totalFilteredElements
        );
    }
}
