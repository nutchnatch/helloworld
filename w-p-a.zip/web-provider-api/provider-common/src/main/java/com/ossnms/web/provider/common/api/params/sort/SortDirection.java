package com.ossnms.web.provider.common.api.params.sort;

/**
 * Defines all the possible directions for Sorting
 */
public enum SortDirection {
    ASC,
    DSC;
}
