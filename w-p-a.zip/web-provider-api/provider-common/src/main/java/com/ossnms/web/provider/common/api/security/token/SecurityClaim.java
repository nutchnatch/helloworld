package com.ossnms.web.provider.common.api.security.token;

/**
 * Enumerable which holds the supported values for Security Claims
 */
public enum SecurityClaim {

    /**
     * Claim which contains the security token
     */
    SECURITY_TOKEN  ("secToken"),

    /**
     * Claim which should represent the issuer
     */
    ISSUER          ("iss"),

    /**
     * Claim with uniquely identifies the JSON Web Token
     */
    JTI             ("jti"),

    /**
     * The subject (user) that is authenticated by the JWT
     */
    SUBJECT         ("sub"),

    /**
     * The expiration date of the JWT
     */
    EXPIRATION      ("exp");

    /**
     * The name of the claim
     */
    private final String claim;

    /**
     * Enum constructor
     *
     * @param claimName
     */
    SecurityClaim(String claimName) {
        this.claim = claimName;
    }

    /**
     * Returns the name of the claim
     */
    public String getClaim() {
        return claim;
    }
}
