package com.ossnms.web.provider.common.utils;

/**
 * Created on 22-09-2016.
 */
public class ObjectEncodeException extends RuntimeException {
    public ObjectEncodeException(Throwable cause) {
        super(cause);
    }
}
