package com.ossnms.web.provider.common.api.security.token;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Header;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.util.Base64;
import java.util.Optional;

import static io.jsonwebtoken.Jwts.parser;

/**
 * Utility class to manage JSON Web Tokens
 */
public final class TokenManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(TokenManager.class);
    private static final String CHARSET = "UTF-8";

    // Hidden private constructor
    private TokenManager() {}

    /**
     * Given a JWT token (jws), retrieve the claim identified by claimName
     *
     * @param jws the JWT
     * @param claim the name of the claim
     * @return a String instance with the value of the claim; null if it does not exist
     */
    public static Optional<String> retrieveClaim(String jws, SecurityClaim claim){
        return retrieveClaim(jws, null, claim, String.class);
    }

    /**
     * Given a JWT token (jws), retrieve the claim identified by claimName. Retrieval will fail
     * if the provided key does not match the one used to sign the JSON Web Token.
     *
     * @see #retrieveClaim(String, SecurityClaim) to obtain the same information without using a key
     *
     * @param jws the JWT
     * @param key the cryptographic key to be used for token signature validation
     * @param claim the name of the claim
     * @return a String instance with the value of the claim; null if it does not exist or if the signature
     * validation failed.
     */
    public static Optional<String> retrieveClaim(String jws, Key key, SecurityClaim claim) {
        return retrieveClaim(jws, key, claim, String.class);
    }

    /**
     * Given a JWT token (jws), retrieve the claim identified by claimName, if the claim is a Base64 encoded object
     * which matches the type passed as parameter. Otherwise, retrieval will fail.
     *
     * @param jws the JWT
     * @param claim the name of the claim
     * @param type the type of object to retrieve
     * @param <E> the type parameter of what will be returned.
     *
     * @return an instance of <E> if the retrieval is successful; null otherwise.
     */
    public static <E> Optional<E> retrieveEncodedClaim(String jws, SecurityClaim claim, Class<E> type){
        return retrieveEncodedClaim(jws, null, claim, type);
    }

    /**
     * Given a JWT token (jws), retrieve the claim identified by claimName, if the claim is a Base64 encoded object
     * which matches the type passed as parameter. Otherwise, retrieval will fail.
     *
     * @param jws the JWT
     * @param key the cryptographic key to be used for token signature validation
     * @param claim the name of the claim
     * @param type the type of object to retrieve
     * @param <E> the type parameter of what will be returned.
     *
      @@return an instance of <E> if the retrieval is successful; null otherwise.
     */
    public static <E> Optional<E> retrieveEncodedClaim(String jws, Key key, SecurityClaim claim, Class<E> type) {
        // retrieve the Base64 encoded claim
        return retrieveClaim(jws, key, claim, String.class)
                .flatMap(value -> base64Decode(value, type));
    }

    /**
     * Given a JWT token (jws), retrieve the claim identified by claimName. Retrieval will fail
     * if the provided key does not match the one used to sign the JSON Web Token.
     *
     * @param jws the JWT
     * @param key the cryptographic key to be used for token signature validation
     * @param claim the name of the claim
     * @param type the type of object to retrieve
     * @param <E> the type parameter of what will be returned.
     *
     * @return an instance of <E> if the retrieval is successful; null otherwise.
     */
    public static <E> Optional<E> retrieveClaim(String jws, Key key, SecurityClaim claim, Class<E> type) {
        LOGGER.debug("Retrieving claim {}, required parse to type {} with secret key {}",
                claim.getClaim(),
                type.getClass().getSimpleName(),
                key != null ? "available" : "not available (validation will be skipped).");

        String jwt;
        JwtParser parser = parser();
        Jwt<Header, Claims> parsedJWT;

        try {
            if(key != null) {
                jwt = jws;
                parser.setSigningKey(key);
            } else {
                jwt = getJWT(jws);
            }
            parsedJWT = parser.parse(jwt);
        } catch(ExpiredJwtException | UnsupportedJwtException | MalformedJwtException | SignatureException | IllegalArgumentException e) {
            LOGGER.error("Parsing of JWT claims failed with an exception.", e);
            return Optional.empty();
        }

        return Optional.ofNullable(parsedJWT.getBody().get(claim.getClaim(), type));
    }

    /**
     * Encode the object into Base64
     *
     * @param object the object to encode.
     *
     * @return the Base64 encoded object's String; null in a failure scenario
     */
    public static Optional<String> base64Encode(Object object) {
        String result = null;
        try {
            ByteArrayOutputStream bStream = new ByteArrayOutputStream();
            ObjectOutputStream oStream = new ObjectOutputStream(bStream);
            oStream.writeObject (object);
            byte[] tokenBytes = Base64.getEncoder().encode(bStream.toByteArray());
            result = new String(tokenBytes, CHARSET);
        } catch (IOException e) {
            LOGGER.error("An error occurred while encoding the element.", e);
        }
        return Optional.ofNullable(result);
    }

    /**
     * Encode an object from a Base64 encoded String
     *
     * @param encodedElement the encoded element
     * @param type the type of object encoded
     *
     * @param <E> the type parameter of the encoded element
     *
     * @return a decoded object's instance, if successful; null otherwise.
     */
    public static <E> Optional<E> base64Decode(String encodedElement, Class<E> type) {
        byte[] decodedBytes = Base64.getDecoder().decode(encodedElement);
        E object = null;
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(decodedBytes);
            ObjectInputStream is = new ObjectInputStream(in);
            Object readObject = is.readObject();
            object = (E) readObject;

        } catch (IOException | ClassNotFoundException e) {
            LOGGER.error("An error occurred while decoding the element.", e);
        }

        return Optional.ofNullable(object);
    }

    /**
     * Obtains the token without the signature, which allows for the data to be parsed
     *
     * @param jws the JWT token (with signature)
     *
     * @return the String with the token (without signature, terminated with a '.')
     */
    private static String getJWT(String jws) {
        int i = jws.lastIndexOf('.');
        return jws.substring(0, i+1);
    }
}
