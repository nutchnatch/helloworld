package com.ossnms.web.provider.common.utils;

/**
 * Environment context information.
 */
public interface Context {

    /**
     * Gives the context user.
     * @return User name.
     */
    String getUser();
}
