package com.ossnms.web.provider.common.api.exception;

/**
 * {@inheritDoc}
 */
public class ProviderException extends Exception {

    private static final long serialVersionUID = 4567981065300433859L;

    /**
     * {@inheritDoc}
     */
    public ProviderException() {
    }

    /**
     * {@inheritDoc}
     */
    public ProviderException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public ProviderException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public ProviderException(Throwable cause) {
        super(cause);
    }

    /**
     * {@inheritDoc}
     */
    public ProviderException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
