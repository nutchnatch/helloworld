package com.ossnms.web.provider.common.utils;

/**
 * Created on 23-02-2016.
 */
public enum ConversionLevel {

    MINIMUM("minimum"),
    FULL("full");

    private final String name;

    ConversionLevel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static ConversionLevel getByName(String name) {
        for (ConversionLevel level : ConversionLevel.values()) {
            if (level.getName().equals(name)) {
                return level;
            }
        }
        return FULL;
    }
}
