package com.ossnms.web.provider.common.api.notification;

/**
 * Handles notifications.
 */

@FunctionalInterface
public interface NotificationHandler {
    /**
     * Handle a notification.
     *
     * @param notification
     *         the notified object
     */
    void handle(Notification notification) throws NotificationHandlerException;


}
