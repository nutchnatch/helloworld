package com.ossnms.web.provider.common.api.notification;

import java.util.Collection;

/**
 * Notification service.
 */
public interface NotificationService {
    /**
     * Subscribe notifications for a specific channel.
     *  @param channel
     *         the channel to be subscribed
     * @param handler
     */
    void subscribe(NotificationChannel channel, NotificationHandler handler);

    /**
     * Unsubscribe notifications from a specific channel.
     *  @param channel
     *         the channel to be unsubscribed
     * @param handler
     */
    void unsubscribe(NotificationChannel channel, NotificationHandler handler);

    /**
     * Subscribe notifications from each of the specific channel in the request collection.
     *  @param channels
     *         the collection of channels to be subscribed
     * @param handler
     */
    void subscribe(Collection<NotificationChannel> channels, NotificationHandler handler);

    /**
     * Unsubscribe notifications from each of the specific channel in the request collection.
     *  @param channels
     *         the collection of channels to be unsubscribed
     * @param handler
     */
    void unsubscribe(Collection<NotificationChannel> channels, NotificationHandler handler);
}
