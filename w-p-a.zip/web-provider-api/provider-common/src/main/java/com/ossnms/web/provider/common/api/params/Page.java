package com.ossnms.web.provider.common.api.params;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;

/**
 * Defines the paging configuration for a query
 */
public final class Page implements Serializable {

    private static final long serialVersionUID = 800033137983769834L;

    private final int page;
    private final int pageSize;

    public int getPage() {
        return page;
    }

    public int getPageSize() {
        return pageSize;
    }

    /**
     * Private constructor which takes an instance of <code>Builder</code>
     * @param builder
     */
    private Page(Builder builder) {
        this.page       = builder.page;
        this.pageSize   = builder.pageSize;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        Page page1 = (Page) o;

        return getPage() == page1.getPage() && getPageSize() == page1.getPageSize();

    }

    @Override
    public int hashCode() {
        int result = getPage();
        result = 31 * result + getPageSize();
        return result;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<Page> {
        private int page;
        private int pageSize;

        /**
         *
         * @param page
         * @param pageSize
         * @return
         */
        public Builder(int page, int pageSize) {
            this.page = page;
            this.pageSize = pageSize;
        }

        /**
         *
         * @return
         */
        @Override
        public Page build() {
            Page pageObj = new Page(this);

            if((page <= 0) || (pageSize <= 0)){
                throw new IllegalStateException(
                        "Page Builder is in an illegal state, since either page or page size " +
                        "are less or equal to 0"
                );
            }

            return pageObj;
        }
    }
}
