package com.ossnms.web.provider.common.api.result.enumerable;

/**
 *
 */
public enum GenericErrorCode {

    /**
     * Placeholder for any failed operation error explanation
     */
    GENERIC

}
