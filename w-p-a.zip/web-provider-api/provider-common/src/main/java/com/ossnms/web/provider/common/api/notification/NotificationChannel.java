package com.ossnms.web.provider.common.api.notification;

import java.io.Serializable;
import java.util.Objects;

public class NotificationChannel implements Serializable {

    private static final long serialVersionUID = 6250942483645574869L;

    private final String channelId;
    private final String authorization;

    /**
     *
     * @param channelId
     */
    public NotificationChannel(String channelId) {
        this.channelId = channelId;
        this.authorization = null;
    }

    /**
     *
     * @param channelId
     */
    public NotificationChannel(String channelId, String authorization) {
        this.channelId = channelId;
        this.authorization = authorization;
    }

    /**
     *
     * @return
     */
    public String getChannelId() {
        return channelId;
    }

    /**
     *
     */
    public String getAuthorization() {
        return authorization;
    }

    /**
     * Equals method which only compares the channel id. Other fields, if they exist, should be ignored
     *
     * @param o the object to compare against this instance
     * @return true if both object are equal; false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        NotificationChannel that = (NotificationChannel) o;
        return Objects.equals(getChannelId(), that.getChannelId());
    }

    /**
     * Returns a hash code value for the object.
     * Parameters other than the channel id will be ignored
     *
     * @return an integer with the hash code value
     */
    @Override
    public int hashCode() {
        return Objects.hash(getChannelId());
    }
}
