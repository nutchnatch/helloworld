package com.ossnms.web.provider.common.api.security.exception;

import com.ossnms.web.provider.common.api.exception.ProviderException;

/**
 *
 */
public class SecurityProviderException extends ProviderException {

    private static final long serialVersionUID = 7458822500394177385L;

    /**
     * {@inheritDoc}
     */
    public SecurityProviderException() {
    }

    /**
     * {@inheritDoc}
     */
    public SecurityProviderException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public SecurityProviderException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public SecurityProviderException(Throwable cause) {
        super(cause);
    }

    /**
     * {@inheritDoc}
     */
    public SecurityProviderException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
