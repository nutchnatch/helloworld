package com.ossnms.web.provider.common.api.model;

import java.io.Serializable;

/**
 * Created on 20-10-2016.
 */
public class Color implements Serializable {

    private static final long serialVersionUID = 8617749276309740360L;
    private final Integer red;
    private final Integer green;
    private final Integer blue;

    public Color(Integer red, Integer green, Integer blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    public Integer getRed() {
        return red;
    }

    public Integer getGreen() {
        return green;
    }

    public Integer getBlue() {
        return blue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Color)) {
            return false;
        }

        Color color = (Color) o;

        if (!red.equals(color.red)) {
            return false;
        }
        if (!green.equals(color.green)) {
            return false;
        }
        return blue.equals(color.blue);
    }

    @Override
    public int hashCode() {
        int result = red.hashCode();
        result = 31 * result + green.hashCode();
        result = 31 * result + blue.hashCode();
        return result;
    }
}
