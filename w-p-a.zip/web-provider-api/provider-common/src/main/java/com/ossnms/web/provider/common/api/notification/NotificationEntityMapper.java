package com.ossnms.web.provider.common.api.notification;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.io.Serializable;

/**
 * Provide conversion from Entity (DTO) to a java representation of the object that will be notified.
 */
public interface NotificationEntityMapper {

    /**
     * Check if the mapper can convert the requested entity.
     *
     * @param entity
     *         The entity that should be checked.
     * @return true if the entity can be converted by the mapper, false otherwise
     */
    default boolean accept(EntityBase entity) {
        return false;
    }

    /**
     * Check if the mapper can convert the requested entity.
     *
     * @param notification The notification that should be checked.
     * @return true if the notification can be converted by the mapper, false otherwise
     */
    default boolean accept(Notification notification) {
        return accept(notification.getEntity());
    }

    /**
     * Converts the provided entity into a text representation.
     *
     * @param entity
     *         the entity to convert
     * @return the text representation of the provided entity
     */
    default Serializable map(EntityBase entity){
        return entity;
    }

    /**
     * Converts the provided entity into a text representation.
     *
     * @param notification the notification to convert
     * @return the text representation of the entity provided by the notification
     */
    default Serializable map(Notification notification) {
        return map(notification.getEntity());
    }
}
