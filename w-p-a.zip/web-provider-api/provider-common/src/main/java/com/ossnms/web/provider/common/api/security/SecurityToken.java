package com.ossnms.web.provider.common.api.security;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;
import java.util.Date;

/**
 * Defines a security token.
 */
public final class SecurityToken implements Serializable {

    private static final long serialVersionUID = -3846345789321036746L;

    private final String username;
    private final String token;
    private final Date creationDate;

    public String getUsername() {
        return username;
    }

    public String getToken() {
        return token;
    }

    public Date getCreationDate() {
        return (Date) creationDate.clone();
    }

    /**
     *
     * @param builder
     */
    private SecurityToken(Builder builder){
        this.username = builder.username;
        this.token = builder.token;
        this.creationDate = new Date();
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<SecurityToken> {

        private String username;
        private String token;

        /**
         *
         * @param username
         * @param token
         */
        public Builder(String username, String token){
            this.username = username;
            this.token = token;
        }

        /**
         *
         * @return
         */
        @Override
        public SecurityToken build() {
            SecurityToken securityToken = new SecurityToken(this);

            if(securityToken.username == null || securityToken.token == null){
                throw new IllegalStateException("SecurityToken is not valid, for either the username or the token are null.");
            }

            return securityToken;
        }
    }
}
