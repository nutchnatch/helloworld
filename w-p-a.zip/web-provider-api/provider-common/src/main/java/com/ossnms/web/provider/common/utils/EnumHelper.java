package com.ossnms.web.provider.common.utils;

import java.util.Arrays;
import java.util.Optional;
import java.util.function.Predicate;

/**
 *
 */
public final class EnumHelper {

    /**
     * Utility class private constructor
     */
    private EnumHelper(){}

    /**
     * Helper class to retrieve a value given a predicate
     *
     * @param predicate the filter to apply
     *
     * @return an instance of {@link T} is matches; null otherwise
     */
    public static <T> T getValue(T[] values, Predicate<T> predicate){
        Optional<T> optValue = Arrays.stream(values)
                .filter(predicate)
                .findAny();

        if(optValue.isPresent()){
            return optValue.get();
        }

        return null;
    }

}
