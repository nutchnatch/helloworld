package com.ossnms.web.provider.common.api.model;

/**
 *
 */
public interface EntitySummary<ID extends EntityID> extends EntityBase {

    /**
     *
     * @return
     */
    ID getID();
}
