package com.ossnms.web.provider.common.api.notification;



/**
 * Dispatch notifications.
 */
public interface NotificationDispatcher<T> {
    /**
     * Send a notification to the receivers.
     *
     * @param notification
     *         the notified object
     */
    void send(T notification);
}
