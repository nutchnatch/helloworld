package com.ossnms.web.provider.common.api.notification;

/**
 * All notification types.
 */
public enum NotificationType {

    CREATION,
    DELETION,
    CHANGE,
    RESYNC
}
