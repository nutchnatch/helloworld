package com.ossnms.web.provider.common.api.params.filter;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;

/**
 * Represents a filter. Type <code>FIELD</code> should represent an enumerable of all the possible fields
 *
 * Implemented using the builder pattern. All fields are obligatory.
 */
public final class Filter<FIELD extends Enum<FIELD>> implements Serializable {

    private static final long serialVersionUID = -424134472553096480L;

    private final FIELD field;
    private final FilterOperation operation;
    private final String value;

    public FIELD getField() {
        return field;
    }

    public FilterOperation getOperation() {
        return operation;
    }

    public String getValue() {
        return value;
    }

    /**
     * Private constructor for an instance of Filter
     *
     * @param builder the instance of Filter.Builder to use
     */
    private Filter(Builder<FIELD> builder){
        this.field      = builder.field;
        this.operation  = builder.operation;
        this.value      = builder.value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        Filter<?> filter = (Filter<?>) o;

        if (!getField().equals(filter.getField())){
            return false;
        }

        if (getOperation() != filter.getOperation()){
            return false;
        }

        return getValue().equals(filter.getValue());

    }

    @Override
    public int hashCode() {
        int result = getField().hashCode();
        result = 31 * result + getOperation().hashCode();
        result = 31 * result + getValue().hashCode();
        return result;
    }


    /**
     * Builder class. All fields are obligatory. Allows for the use of a fluent syntax.
     */
    public static class Builder<FIELD extends Enum<FIELD>> implements ObjectBuilder<Filter<FIELD>> {
        private FIELD field;
        private FilterOperation operation;
        private String value;

        /**
         * Constructor for Filter.Builder class, where constructor paramenters are the obligatory fields
         *
         * @param field the field for which to filter by
         * @param operation the operation to apply (see <code>FilterOperations</code>)
         * @param value the value of the filter
         */
        public Builder(FIELD field, FilterOperation operation, String value) {
            this.field = field;
            this.operation = operation;
            this.value = value;
        }

        /**
         * Builder method. Will check for the state integrity of the Builder. If any of the obligatory fields are not
         * valid, an IllegalStateException will be thrown.
         *
         * @return an instance of Filter, if all the obligatory fields are present.
         */
        @Override
        public Filter<FIELD> build() {
            Filter<FIELD> filter = new Filter<>(this);

            if(filter.getField() == null || filter.getOperation() == null || filter.getValue() == null){
                throw new IllegalStateException("Either field, operation or value were set to null.");
            }

            return filter;
        }
    }

}
