package com.ossnms.web.provider.common.api.facade;

/**
 *
 */
public interface BaseEntityOperations {
}
