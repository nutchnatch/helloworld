package com.ossnms.web.provider.common.api.model;

import java.util.Collection;

/**
 * Created on 16-09-2016.
 */
public interface EntityCollection<T> extends Collection<T> {
    String getNotificationsChannel();

    void setNotificationsChannel(String channel);
}
