package com.ossnms.web.provider.common.api.notification;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.function.Supplier;

public class Notification implements EntityBase {
    private static final long serialVersionUID = 3977131940486620243L;


    private final NotificationType notificationType;
    private final NotificationChannel channel;
    private EntityBase entity;

    private transient final Supplier<? extends EntityBase> entitySupplier;


    private void writeObject(ObjectOutputStream oos) throws IOException {
        getEntity();
        oos.defaultWriteObject();
    }


    private Notification(NotificationChannel channel, Supplier<? extends EntityBase> entitySupplier, NotificationType notificationType) {
        this.channel = channel;
        this.entitySupplier = entitySupplier;
        this.notificationType = notificationType;
    }

    public NotificationChannel getChannel() {
        return channel;
    }

    public NotificationType getNotificationType() {
        return notificationType;
    }

    public EntityBase getEntity() {
        if(entity == null) {
            entity = entitySupplier.get();
        }
        return entity;
    }

    @Override
    public String toString() {
        return "Notification{" +
                "channel=" + channel +
                ", entitySupplier=" + entitySupplier +
                '}';
    }

    public static class NotificationBuilder {
        private NotificationChannel channel = null;
        private Supplier<? extends EntityBase> entitySupplier;
        private NotificationType notificationType;

        public NotificationBuilder setChannel(NotificationChannel channel) {
            this.channel = channel;
            return this;
        }

        public NotificationBuilder setEntitySupplier(Supplier<? extends EntityBase> entitySupplier) {
            this.entitySupplier = entitySupplier;
            return this;
        }

        public NotificationBuilder setNotificationType(NotificationType notificationType) {
            this.notificationType = notificationType;
            return this;
        }

        public Notification build() {
            return new Notification(channel, entitySupplier, notificationType);
        }
    }
}
