package com.ossnms.web.provider.common.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/**
 * Created on 22-09-2016.
 */
public abstract class Coder {

    private static final int OXFF = 0xff;
    private static final int OX100 = 0x100;
    private static final int _16 = 16;

    public static String encode(Object object) throws ObjectEncodeException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ObjectOutputStream objectOutputStream;
        try {
            objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(object);
            objectOutputStream.close();
        } catch (IOException e) {
            throw new ObjectEncodeException(e);
        }
        return new String(Base64.getEncoder().encode(outputStream.toByteArray()));
    }

    public static Object decode(String encoded) {
        byte[] data = Base64.getDecoder().decode(encoded);
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data))) {
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new ObjectEncodeException(e);
        }
    }

    public static String toMD5(String msg) {
        if (msg == null) {
            return null;
        }

        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(msg.getBytes());

            byte byteData[] = md.digest();

            //convert the byte to hex format method 1
            StringBuilder sb = new StringBuilder();
            for (byte aByteData : byteData) {
                sb.append(Integer.toString((aByteData & OXFF) + OX100, _16).substring(1));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return msg;
        }
    }
}
