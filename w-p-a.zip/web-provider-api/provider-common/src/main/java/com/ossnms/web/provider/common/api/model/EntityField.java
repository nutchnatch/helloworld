package com.ossnms.web.provider.common.api.model;

/**
 *
 */
public interface EntityField<T> extends EntityBase {

}
