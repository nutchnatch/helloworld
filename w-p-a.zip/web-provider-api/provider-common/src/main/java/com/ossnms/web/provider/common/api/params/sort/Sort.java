package com.ossnms.web.provider.common.api.params.sort;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;

/**
 * Parameterizes a Sort operation for the given field enum type
 */
public final class Sort<FIELD extends Enum<FIELD>> implements Serializable {

    private static final long serialVersionUID = -9079547141408583890L;

    private final FIELD field;
    private final SortDirection direction;

    /**
     * Gets the field of type <code>FIELD</code>
     *
     * @return an instance of <code>FIELD</code>
     */
    public FIELD getField() {
        return field;
    }

    /**
     * Retrieves the <code>SortDirection</code> for this <code>Sort</code> instance.
     *
     * @return an instance of <code>SortDirection</code>
     */
    public SortDirection getDirection() {
        return direction;
    }

    /**
     * Private constructor, which takes an instance of builder.
     * @param builder the instance of <code>Builder</code>
     */
    private Sort(Builder<FIELD> builder){
        this.field      = builder.field;
        this.direction  = builder.direction;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Sort<?> sort = (Sort<?>) o;
        return getField().equals(sort.getField()) && getDirection() == sort.getDirection();
    }

    @Override
    public int hashCode() {
        int result = getField().hashCode();
        result = 31 * result + getDirection().hashCode();
        return result;
    }

    /**
     * Builder class <code>Sort</code>.
     */
    public static class Builder<FIELD extends Enum<FIELD>> implements ObjectBuilder<Sort<FIELD>> {
        private FIELD field;
        private SortDirection direction;

        /**
         * Constructor for the Builder class. All parameters define the obligatory fields.
         *
         * @param field the instance of <FIELD>
         * @param direction the <code>SortDirection</code>
         */
        public Builder(FIELD field, SortDirection direction) {
            this.field = field;
            this.direction = direction;
        }

        /**
         * Builds the object as configured with the builder.
         *
         * @return an instance of <code>Sort</code>; otherwise throws <code>IllegalStateException</code>
         */
        @Override
        public Sort<FIELD> build() {
            Sort<FIELD> sort = new Sort<>(this);

            if(sort.field == null || sort.direction == null) {
                throw new IllegalStateException("Builder is in an invalid state, since either field or direction are null.");
            }

            return new Sort<>(this);
        }
    }
}
