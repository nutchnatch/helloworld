package com.ossnms.web.provider.common.api.result.enumerable;

/**
 *
 */
public enum Status {

    OK,
    NOT_FOUND,
    ALREADY_EXISTS,
    BAD_REQUEST,
    SERVER_ERROR

}
