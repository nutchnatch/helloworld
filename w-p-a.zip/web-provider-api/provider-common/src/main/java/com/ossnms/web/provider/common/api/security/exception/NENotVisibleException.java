package com.ossnms.web.provider.common.api.security.exception;

import com.ossnms.web.provider.common.api.exception.ProviderRuntimeException;

public class NENotVisibleException extends ProviderRuntimeException {

    private static final long serialVersionUID = -3919677100211370723L;

    private final int neId;

    public NENotVisibleException(int neId) {
        super();
        this.neId = neId;
    }

    public int getNeId() {
        return neId;
    }
}
