package com.ossnms.web.provider.security.model.domain;

import com.ossnms.web.provider.security.model.element.SecurableElementID;
import com.ossnms.web.provider.security.model.element.enumerable.SecurableElementType;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
public class SecurityDomainTest {

    @Test
    public void shouldCreateSecurityDomainID() {
        SecurityDomainID domainID = new SecurityDomainID.Builder(12).build();
        assertNotNull(domainID);
        assertEquals(12, domainID.getId());
    }

    @Test
    public void shouldCreateSecurityDomainSummary() {
        SecurityDomainID domainID = new SecurityDomainID.Builder(12).build();

        SecurityDomainSummary domainSummary = new SecurityDomainSummary.Builder(domainID)
                .name("name 12")
                .description("description 12")
                .build();

        assertNotNull(domainSummary);
        assertEquals("name 12", domainSummary.getName());
        assertEquals("description 12", domainSummary.getDescription());
    }

    @Test
    public void shouldCreateSecurityDomain() {
        SecurityDomainID domainID = new SecurityDomainID.Builder(12).build();

        SecurityDomain domain = new SecurityDomain.Builder(domainID)
                .name("name 12")
                .description("description 12")
                .addSecurableElement(new SecurableElementID.Builder().setId(12).setType(SecurableElementType.COMMON_CONTAINER).build())
                .build();

        assertNotNull(domain);
        assertEquals("name 12", domain.getName());
        assertEquals("description 12", domain.getDescription());
        assertEquals(1, domain.getSecurableElementIDList().size());
    }
}
