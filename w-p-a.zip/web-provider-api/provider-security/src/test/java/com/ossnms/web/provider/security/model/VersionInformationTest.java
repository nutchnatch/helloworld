package com.ossnms.web.provider.security.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 *
 */
public class VersionInformationTest {

    @Test(expected = IllegalStateException.class)
    public void shouldNotCreateVersionInformationWithMissingData() {
        new VersionInformation.Builder(null, null).build();
    }

    @Test
    public void shouldCreateVersionInformation() {
        VersionInformation version = new VersionInformation.Builder("TNMS", "123.0.0.0").build();

        assertEquals("TNMS"     , version.getProductName());
        assertEquals("123.0.0.0", version.getProductVersion());
    }

    @Test
    public void shouldBeEqual() {
        VersionInformation version = new VersionInformation.Builder("TNMS", "123.0.0.0").build();

        assertTrue(version.equals(version));
    }

    @Test
    public void shouldNotBeEqual() {
        VersionInformation version = new VersionInformation.Builder("TNMS", "123.0.0.0").build();
        VersionInformation version1 = new VersionInformation.Builder("TNMS", "124.0.0.0").build();

        assertFalse(version.equals(version1));
    }
}
