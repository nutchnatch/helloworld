package com.ossnms.web.provider.security.api.result;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.security.api.params.Permission;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public class PermissionReply implements Serializable {

    private static final long serialVersionUID = 7294468641689857909L;

    private final List<Permission> permissionsGranted;

    /**
     *
     * @param builder
     */
    private PermissionReply(Builder builder) {
        ArrayList<Permission> permissionsToClone = (ArrayList<Permission>) builder.permissionsGranted;
        permissionsGranted = (List<Permission>) permissionsToClone.clone();
    }

    /**
     *
     */
    public List<Permission> getPermissionsGranted() {
        return permissionsGranted;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<PermissionReply> {

        private List<Permission> permissionsGranted;

        public Builder() {
            this.permissionsGranted = new ArrayList<>();
        }

        /**
         *
         * @param permissionGranted
         * @return
         */
        public Builder addPermissionGranted(Permission permissionGranted) {
            this.permissionsGranted.add(permissionGranted);
            return this;
        }

        /**
         *
         * @param permissionsGranted
         * @return
         */
        public Builder addAllPermissionsGranted(List<Permission> permissionsGranted) {
            this.permissionsGranted.addAll(permissionsGranted);
            return this;
        }


        @Override
        public PermissionReply build() {
            return new PermissionReply(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){ return true; }
        if (o == null || getClass() != o.getClass()){ return false; }
        PermissionReply that = (PermissionReply) o;
        return Objects.equals(permissionsGranted, that.permissionsGranted);
    }

    @Override
    public int hashCode() {
        return Objects.hash(permissionsGranted);
    }
}
