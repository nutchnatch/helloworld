package com.ossnms.web.provider.security.model.domain;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class SecurityDomainSummary implements EntitySummary<SecurityDomainID>{

    private static final long serialVersionUID = -2616818371665089156L;

    private final SecurityDomainID securityDomainID;
    private final String name;
    private final String description;

    SecurityDomainSummary(Prototype<?> builder) {
        this.securityDomainID = builder.securityDomainID;
        this.description =      builder.description;
        this.name =             builder.name;
    }

    /**
     *
     * @return
     */
    @Override
    public SecurityDomainID getID() {
        return securityDomainID;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    /**
     *
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     */
    public static class Builder extends Prototype<Builder> {

        public Builder(SecurityDomainID securityDomainID) {
            super(securityDomainID);
        }

        @Override
        protected Builder self() {
            return this;
        }

        @Override
        public SecurityDomainSummary build() {
            return new SecurityDomainSummary(this);
        }
    }

    /**
     *
     * @param <E>
     */
    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<SecurityDomainSummary> {

        private SecurityDomainID securityDomainID;
        private String description;
        private String name;

        Prototype(SecurityDomainID securityDomainID) {
            this.securityDomainID = securityDomainID;
        }

        public E description(String description) {
            this.description = description;
            return self();
        }

        public E name(String name) {
            this.name = name;
            return self();
        }

        protected abstract E self();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        SecurityDomainSummary that = (SecurityDomainSummary) o;
        return Objects.equals(securityDomainID, that.securityDomainID) &&
                Objects.equals(getName(), that.getName()) &&
                Objects.equals(getDescription(), that.getDescription());
    }

    @Override
    public int hashCode() {
        return Objects.hash(securityDomainID, getName(), getDescription());
    }
}
