package com.ossnms.web.provider.security.model.user;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

/**
 *
 */
public class User implements EntityBase {

    private static final long serialVersionUID = 4908404922783902040L;

    private final String username;

    public User(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        User that = (User) o;
        return Objects.equals(getUsername(), that.getUsername());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getUsername());
    }

}
