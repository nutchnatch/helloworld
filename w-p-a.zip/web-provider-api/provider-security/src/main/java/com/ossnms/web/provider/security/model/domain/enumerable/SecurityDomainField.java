package com.ossnms.web.provider.security.model.domain.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum SecurityDomainField {
    NAME        ("name"),
    DESCRIPTION ("description");


    private final String name;

    /**
     *
     * @param name
     */
    SecurityDomainField(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }


    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link SecurityDomainField}; null if no match
     */
    public static SecurityDomainField fromName(String name){
        return getValue(
                SecurityDomainField.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }
}
