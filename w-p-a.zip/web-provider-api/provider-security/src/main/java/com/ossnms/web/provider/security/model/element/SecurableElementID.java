package com.ossnms.web.provider.security.model.element;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.security.model.element.enumerable.SecurableElementType;

import java.util.Objects;

/**
 *
 */
public class SecurableElementID implements EntityID {

    private static final long serialVersionUID = -6273601498988767105L;

    private final long id;
    private final SecurableElementType type;


    public SecurableElementID(Builder builder) {
        this.id = builder.id;
        this.type = builder.type;
    }

    /**
     *
     */
    public long getId() {
        return id;
    }

    /**
     *
     */
    public SecurableElementType getType() {
        return type;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<SecurableElementID> {

        private long id;
        private SecurableElementType type;

        /**
         *
         * @param id
         * @return
         */
        public Builder setId(long id) {
            this.id = id;
            return this;
        }

        /**
         *
         * @param type
         * @return
         */
        public Builder setType(SecurableElementType type) {
            this.type = type;
            return this;
        }

        @Override
        public SecurableElementID build() {
            return new SecurableElementID(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SecurableElementID that = (SecurableElementID) o;
        return getId() == that.getId() &&
                getType() == that.getType();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getType());
    }
}
