package com.ossnms.web.provider.security.model.element.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 * Securable Element Type Enum.
 */
public enum SecurableElementType {
    NE ("NE"),
    COMMON_CONTAINER ("CommonContainer");

    private final String name;

    /**
     *
     * @param name
     */
    SecurableElementType(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /**
     * Retrieves the enum value from a name
     *
     * @param name the name to search for
     * @return an instance of {@link SecurableElementType}; null if no match
     */
    public static SecurableElementType fromName(String name){
        return getValue(
                SecurableElementType.values(),
                candidate -> candidate.getName().toLowerCase().equals(name.toLowerCase())
        );
    }
}
