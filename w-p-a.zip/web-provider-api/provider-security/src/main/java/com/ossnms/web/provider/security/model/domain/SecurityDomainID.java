package com.ossnms.web.provider.security.model.domain;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class SecurityDomainID implements EntityID {

    private static final long serialVersionUID = 8421640142462196484L;

    private final long id;

    private SecurityDomainID(Builder builder) {
        this.id = builder.id;
    }

    /**
     *
     */
    public long getId() {
        return id;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<SecurityDomainID> {

        private long id;

        public Builder(long id) {
            this.id = id;
        }

        @Override
        public SecurityDomainID build() {
            return new SecurityDomainID(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        SecurityDomainID that = (SecurityDomainID) o;
        return getId() == that.getId();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }
}
