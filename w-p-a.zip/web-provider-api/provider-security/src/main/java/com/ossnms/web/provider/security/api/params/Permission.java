package com.ossnms.web.provider.security.api.params;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 */
public class Permission implements Serializable {

    private static final long serialVersionUID = 3356543165617317403L;

    private final String permission;

    private Permission(Builder builder) {
        this.permission = builder.permission;
    }

    /**
     *
     */
    public String getPermission() {
        return permission;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<Permission> {

        private String permission;

        /**
         *
         * @param permission
         * @return
         */
        public Builder setPermission(String permission) {
            this.permission = permission;
            return this;
        }

        @Override
        public Permission build() {
            return new Permission(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){ return true;}
        if (o == null || getClass() != o.getClass()){ return false;}
        Permission that = (Permission) o;
        return Objects.equals(getPermission(), that.getPermission());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getPermission());
    }
}