package com.ossnms.web.provider.security.model;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;
import java.util.Objects;

/**
 * DTO to transport version information from a Web Provider API implementation
 */
public final class VersionInformation implements Serializable {
    private static final long serialVersionUID = -3215238028714180482L;

    private final String productName;
    private final String productVersion;

    /**
     * Private constructor for the builder class
     * @param builder instance of VersionInformation Builder
     */
    private VersionInformation(Builder builder) {
        this.productName = builder.productName;
        this.productVersion = builder.productVersion;
    }

    /**
     *
     * @return
     */
    public String getProductName() {
        return productName;
    }

    /**
     *
     * @return
     */
    public String getProductVersion() {
        return productVersion;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<VersionInformation> {

        private String productName;
        private String productVersion;

        public Builder(String productName, String productVersion){
            this.productName = productName;
            this.productVersion = productVersion;
        }

        @Override
        public VersionInformation build() {
            if(this.productName == null || this.productName.isEmpty() || this.productVersion == null || this.productVersion.isEmpty()) {
                throw new IllegalStateException("Builder is in an invalid state, product name or version are null or empty");
            }

            return new VersionInformation(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        VersionInformation that = (VersionInformation) o;
        return Objects.equals(getProductName(), that.getProductName()) &&
                Objects.equals(getProductVersion(), that.getProductVersion());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getProductName(), getProductVersion());
    }
}
