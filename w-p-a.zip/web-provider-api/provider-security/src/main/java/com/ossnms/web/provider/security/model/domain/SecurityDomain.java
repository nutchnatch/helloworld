package com.ossnms.web.provider.security.model.domain;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.security.model.element.SecurableElementID;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public class SecurityDomain extends SecurityDomainSummary implements Entity<SecurityDomainID> {

    private static final long serialVersionUID = -6915139734434836563L;

    private final List<SecurableElementID> securableElementIDList;

    /**
     * Builder enabled private constructor
     * @param builder
     */
    private SecurityDomain(Builder builder) {
        super(builder);
        securableElementIDList = new ArrayList<>(builder.securableElementIDList);
    }

    /**
     *
     */
    public List<SecurableElementID> getSecurableElementIDList() {
        return securableElementIDList;
    }

    /**
     *
     */
    public static class Builder extends SecurityDomainSummary.Prototype<Builder> {
        private List<SecurableElementID> securableElementIDList;

        public Builder(SecurityDomainID securityDomainID) {
            super(securityDomainID);
            securableElementIDList = new ArrayList<>();
        }

        /**
         *
         * @param elementID
         * @return
         */
        public Builder addSecurableElement(SecurableElementID elementID) {
            securableElementIDList.add(elementID);
            return this;
        }

        /**
         *
         * @param elementIDs
         * @return
         */
        public Builder addSecurableElements(List<SecurableElementID> elementIDs) {
            securableElementIDList.addAll(elementIDs);
            return this;
        }

        @Override
        protected Builder self() {
            return this;
        }

        @Override
        public SecurityDomain build() {
            return new SecurityDomain(self());
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        if (!super.equals(o)){
            return false;
        }
        SecurityDomain that = (SecurityDomain) o;
        return Objects.equals(securableElementIDList, that.securableElementIDList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), securableElementIDList);
    }
}
