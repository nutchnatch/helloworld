package com.ossnms.web.provider.service.operations;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.container.Container;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.path.PathID;

/**
 * {@inheritDoc}
 */
public interface ContainerEntityOperations extends EntityOperations<ContainerID, Container, ContainerSummary, ContainerField> {

    /**
     * Associates the identified path to the identified container
     *
     * @param token security token, the user authentication
     * @param container the identification of the container to assign the asset to
     * @param path the identification of the asset (Path)
     */
    ContainerID assignToContainer(SecurityToken token, ContainerID container, PathID path);

    /**
     * Associates the path, identified by name, to the identified container
     *
     * @param token security token, the user authentication
     * @param container the identification of the container to assign the asset to
     * @param pathName the name of the path
     * @return the id of the container if successful; null otherwise;
     */
    ContainerID assignToContainer(SecurityToken token, ContainerID container, String pathName);
}
