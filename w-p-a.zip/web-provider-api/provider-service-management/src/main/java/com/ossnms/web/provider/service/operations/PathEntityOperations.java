package com.ossnms.web.provider.service.operations;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.fault.Alarm;
import com.ossnms.web.provider.network.model.path.Path;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;

import java.util.Collection;
import java.util.List;

/**
 * {@inheritDoc}
 */
public interface PathEntityOperations extends EntityOperations<PathID,Path, PathSummary, PathField> {

    /**
     * Retrieves Paths which belong to a Container, identified by ContainerID
     *
     * @param token the security token
     * @param containerID the id of the container
     * @param page the pagination parameters
     * @param sortBy the sort parameters
     * @param filterBy the filter parameters
     *
     * @return the operation result, which contains the result of the given query, together with the specified query
     * parameters
     */
    OperationResult<Path, PathField> getPaths(SecurityToken token, ContainerID containerID, Page page, Sort<PathField> sortBy, Collection<Filter<PathField>> filterBy);

    /**
     * Returns the alarms currently affecting the given path.
     *
     * @param token token to authorise the operation.
     * @param pathID the id of the path.
     *
     * @return List of alarm objects that currently affect the given pathId.
     */
    List<Alarm> getPathAlarms(SecurityToken token, PathID pathID, boolean endpointsOnly, boolean extended);
}
