package com.ossnms.web.provider.element.operations;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.network.*;

import java.util.Collection;

/**
 * Created on 12-05-2016.
 */
public interface SearchService {

    // Search
    Collection<NetworkElement> getNetworkElements(SecurityToken securityToken, String nameFragment, String level);

    Collection<EquipmentHolder> getEquipmentHolders(SecurityToken securityToken, Collection<Integer> neIds, String nameFragment, String level);

    Collection<Bridge> getBridges(SecurityToken securityToken, Collection<Integer> neIds, String nameFragment, String level);

    Collection<Equipment> getEquipments(SecurityToken securityToken, Collection<Integer> neIds, String nameFragment, String level);

    Collection<PhysicalTerminationPoint> getPhysicalTerminationPoints(SecurityToken securityToken, Collection<Integer> neIds, String nameFragment, String level);

    Collection<TerminationPoint> getTerminationPoints(SecurityToken securityToken, Collection<Integer> neIds, String nameFragment, String level);

}
