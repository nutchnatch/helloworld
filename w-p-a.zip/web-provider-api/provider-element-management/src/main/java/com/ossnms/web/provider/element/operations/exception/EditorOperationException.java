package com.ossnms.web.provider.element.operations.exception;

/**
 * Created on 31-05-2016.
 */
public class EditorOperationException extends Exception {

    private static final long serialVersionUID = -3209589492745104057L;
    private final String operation;
    private String stackTraceEncoded;

    public EditorOperationException(String message, Throwable cause, String operation) {
        super(message, cause);
        this.operation = operation;
    }

    public String getOperation() {
        return operation;
    }

    public String getStackTraceEncoded() {
        return stackTraceEncoded;
    }

    public void setStackTraceEncoded(String stackTraceEncoded) {
        this.stackTraceEncoded = stackTraceEncoded;
    }
}
