package com.ossnms.web.provider.element.microtopology.operations;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.microtopology.MicroTopology;

import java.util.List;

/**
 * MicroTopology computation service.
 */
public interface MicroTopologyService {

    /**
     * Compute MicroTopology given the triple neId/ptpId/tpId that identifies the start TerminationPoint.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start TerminationPoint
     * @param ptpId
     *         the ptpId of the start TerminationPoint
     * @param tpId
     *         the tpId of the start TerminationPoint
     * @return A MicroTopology data containing all the paths that can be found from the TerminationPoint identified by
     * the triple neId/ptpId/tpId
     */
    MicroTopology computeTpMicroTopology(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId);

    /**
     * Compute MicroTopology given triple neId/ptpId/tpId and the Vlan subscription identificated with internal CVLAN
     * and SVLAN and external CVLAN and STag that identifies the start TerminationPoint Vlan Subscription.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start TerminationPoint
     * @param ptpId
     *         the ptpId of the start TerminationPoint
     * @param tpId
     *         the tpId of the start TerminationPoint
     * @param internalCVlan
     *         the internal client tag vlan id
     * @param internalSVlan
     *         the internal service tag vlan id
     * @return A MicroTopology data containing all the paths that can be found from the TerminationPoint identified by
     * the duple neId/ptpId
     */
    MicroTopology computeVlanMicroTopology(SecurityToken securityToken,
                                           Integer neId,
                                           Integer ptpId,
                                           Long tpId,
                                           Integer internalCVlan,
                                           Integer internalSVlan);

    /**
     * Compute MicroTopology given the duple neId/ptpId that identifies the start PhysicalTerminationPoint.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start PhysicalTerminationPoint
     * @param ptpId
     *         the ptpId of the start PhysicalTerminationPoint
     * @return A MicroTopology data containning all the paths that can be found from the PhysicalTerminationPoint
     * identified by the duple neId/ptpId
     */
    MicroTopology computePtpMicroTopology(SecurityToken securityToken, Integer neId, Integer ptpId);

    /**
     * Compute MicroTopology given the identifiers of the endpoints of a TopologicalLink.
     *
     * @param securityToken
     *         user context
     * @param neIdA
     *         the neId of the end point A of the start TopologicalLink
     * @param ptpIdA
     *         the ptpId of the end point A of the start TopologicalLink
     * @param neIdZ
     *         the neId of the end point Z of the start TopologicalLink
     * @param ptpIdZ
     *         the ptpId of the end point Z of the start TopologicalLink
     * @return A MicroTopology data containing all the paths that can be found from the TopologicalLink identified by
     * the neIdA/ptpIdA/neIdZ/ptpIdZ
     */
    MicroTopology computeTlMicroTopology(SecurityToken securityToken, Integer neIdA, Integer ptpIdA, Integer neIdZ,
                                         Integer ptpIdZ);


    /**
     * Compute MicroTopology given the identifiers of the endpoints of a CrossConnection.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start CrossConnection
     * @param ptpIdA
     *         the ptpId of the end point A of the start CrossConnection
     * @param tpIdA
     *         the tpId of the end point A of the start CrossConnection
     * @param ptpIdZ
     *         the ptpId of the end point Z of the start CrossConnection
     * @param tpIdZ
     *         the tpId of the end point Z of the start CrossConnection
     * @return A MicroTopology data containing all the paths that can be found from the CrossConnection identified by
     * the neId/ptpIdA/tpIdA/ptpIdZ/tpIdZ
     */
    MicroTopology computeCcMicroTopology(SecurityToken securityToken, Integer neId, Integer ptpIdA, Long tpIdA,
                                         Integer ptpIdZ,
                                         Long tpIdZ);

    /**
     * Compute MicroTopology given the identifiers of the endpoints of a CrossConnection.
     *
     * @param securityToken
     *         user context
     * @param serviceId
     *         the name of the service to compute the microtopology
     * @param type
     * @return A MicroTopology data containing all the paths that can be found from the service identified by the
     * serviceName
     */
    MicroTopology computeServiceMicroTopology(SecurityToken securityToken, long serviceId, String type);

    /**
     * Compute MicroTopology given the triple neId/ptpId/acTpId that identifies the start Attachment Circuit TP.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start Attachment Circuit TP
     * @param ptpId
     *         the ptpId of the start Attachment Circuit TP
     * @param acTpId
     *         the acTpId of the start Attachment Circuit TP
     * @return A MicroTopology data containing all the paths that can be found from the Attachment Circuit TP identified by
     * the triple neId/ptpId/acTpId
     */
    MicroTopology computeAcTpMicroTopology(SecurityToken securityToken, int neId, int ptpId, long acTpId);

    /**
     * Compute MicroTopology given the triple neId/ptpId/pwTpId that identifies the start Pseudo-wire TP.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start Pseudo-wire TP
     * @param ptpId
     *         the ptpId of the start Pseudo-wire TP
     * @param pwTpId
     *         the acTpId of the start Pseudo-wire TP
     * @return A MicroTopology data containing all the paths that can be found from the Pseudo-wire TP identified by
     * the triple neId/ptpId/pwTpId
     */
    MicroTopology computePwTpMicroTopology(SecurityToken securityToken, int neId, int ptpId, long pwTpId);

    /**
     * Compute MicroTopology given the triple neId/ptpId/lspTpId that identifies the start LSP TP.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start LSP TP
     * @param ptpId
     *         the ptpId of the start LSP TP
     * @param lspTpId
     *         the lspTpId of the start LSP TP
     * @return A MicroTopology data containing all the paths that can be found from the LSP TP identified by
     * the triple neId/ptpId/pwTpId
     */
    MicroTopology computeLspTpMicroTopology(SecurityToken securityToken, int neId, int ptpId, long lspTpId);

    /**
     * Compute MicroTopology given the triple neId/ptpId/TunnelId that identifies the start Tunnel.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start Tunnel
     * @param ptpId
     *         the ptpId of the start Tunnel
     * @param tunnelId
     *         the tunnelId of the start Tunnel
     * @return A MicroTopology data containing all the paths that can be found from the Tunnel identified by
     * the triple neId/ptpId/TunnelId
     */
    MicroTopology computeTunnelMicroTopology(SecurityToken securityToken, int neId, int ptpId, long tunnelId);

    /**
     * Compute MicroTopology given the triple neId/ptpId/payloadId that identifies the start Payload.
     *
     * @param securityToken
     *         user context
     * @param neId
     *         the neId of the start Payload
     * @param ptpId
     *         the ptpId of the start Payload
     * @param payloadId
     *         the payloadId of the start Payload
     * @return A MicroTopology data containing all the paths that can be found from the Payload identified by
     * the triple neId/ptpId/payloadId
     */
    MicroTopology computePayloadMicroTopology(SecurityToken securityToken, int neId, int ptpId, long payloadId);

    /**
     * Gets all the layers that can be present in (Physical)TerminationPoints.
     *
     * @param securityToken
     *         user context
     * @return Ordered list containing all the layers
     */
    List<String> getAllLayers(SecurityToken securityToken);





    /* Deprecated methods */

    @Deprecated
    MicroTopology computeMicroTopology(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId);

    @Deprecated
    MicroTopology computeMicroTopology(SecurityToken securityToken,
                                       Integer neId,
                                       Integer ptpId,
                                       Long tpId,
                                       Integer internalCVlan,
                                       Integer internalSVlan);

    @Deprecated
    MicroTopology computeMicroTopology(SecurityToken securityToken, Integer neId, Integer ptpId);

    @Deprecated
    MicroTopology computeMicroTopology(SecurityToken securityToken, Integer neIdA, Integer ptpIdA, Integer neIdZ,
                                       Integer ptpIdZ);


    @Deprecated
    MicroTopology computeMicroTopology(SecurityToken securityToken, Integer neId, Integer ptpIdA, Long tpIdA,
                                       Integer ptpIdZ,
                                       Long tpIdZ);

    @Deprecated
    MicroTopology computeMicroTopology(SecurityToken securityToken, long serviceId, String type);

}
