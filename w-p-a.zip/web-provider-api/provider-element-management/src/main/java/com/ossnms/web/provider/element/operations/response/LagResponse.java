package com.ossnms.web.provider.element.operations.response;


import com.ossnms.web.provider.common.api.model.EntityCollection;
import com.ossnms.web.provider.element.operations.exception.EditorOperationException;
import com.ossnms.web.provider.network.model.network.TerminationPoint;

import java.io.Serializable;
import java.util.Collection;

/**
 * Created on 27-06-2016.
 */
public class LagResponse implements Serializable {

    private static final long serialVersionUID = 6315459410195533944L;
    private TerminationPoint lag;
    private EntityCollection<TerminationPoint> lagMembers;
    private Collection<EditorOperationException> problemInMembers;

    public TerminationPoint getLag() {
        return lag;
    }

    public void setLag(TerminationPoint lag) {
        this.lag = lag;
    }

    public EntityCollection<TerminationPoint> getLagMembers() {
        return lagMembers;
    }

    public void setLagMembers(EntityCollection<TerminationPoint> lagMembers) {
        this.lagMembers = lagMembers;
    }

    public Collection<EditorOperationException> getProblemInMembers() {
        return problemInMembers;
    }

    public void setProblemInMembers(Collection<EditorOperationException> problemInMembers) {
        this.problemInMembers = problemInMembers;
    }
}
