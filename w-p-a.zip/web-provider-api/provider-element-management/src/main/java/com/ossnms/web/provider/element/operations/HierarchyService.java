package com.ossnms.web.provider.element.operations;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.common.BaseEntity;

import java.util.Collection;

/**
 * Created on 12-05-2016.
 */
public interface HierarchyService {

    Collection<BaseEntity> getContainerHierarchy(SecurityToken securityToken, Integer id, String level);

    Collection<BaseEntity> getSystemContainerHierarchy(SecurityToken securityToken, Integer containerId, Integer sysCtId, String level);

    Collection<BaseEntity> getNetworkElementHierarchy(SecurityToken securityToken, Integer containerId, Integer neId, String level);

    Collection<BaseEntity> getEquipmentHolderHierarchy(SecurityToken securityToken, Integer containerId, Integer neId, Integer ehId, String level);

    Collection<BaseEntity> getBridgeHierarchy(SecurityToken securityToken, Integer containerId, Integer neId, Integer subsysId, Integer bridgeId, String level);

    Collection<BaseEntity> getEquipmentHierarchy(SecurityToken securityToken, Integer containerId, Integer neId, Integer eqId, String level, Integer subsysId, Integer bridgeId);

    Collection<BaseEntity> getPhysicalTerminationPointHierarchy(SecurityToken securityToken, Integer containerId, Integer neId, Integer eqId, Integer ptpId, String level, Integer subsysId, Integer bridgeId);

    Collection<BaseEntity> getTerminationPointHierarchy(SecurityToken securityToken, Integer containerId, Integer neId, Integer ptpId, Long tpId, String level, Integer subsysId, Integer bridgeId, Integer lagPtpId, Long lagTpId);

}
