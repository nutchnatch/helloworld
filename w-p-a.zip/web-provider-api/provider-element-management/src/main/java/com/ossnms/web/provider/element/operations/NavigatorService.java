package com.ossnms.web.provider.element.operations;

import com.ossnms.web.provider.common.api.model.EntityCollection;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.network.*;

import java.util.List;

/**
 * Mashup of CNB services.
 */
public interface NavigatorService {

    EntityCollection<Container> getAllContainers(SecurityToken securityToken, String level);

    EntityCollection<Container> getContainersOnFirstLevel(SecurityToken securityToken, String level);

    EntityCollection<Container> getContainersOfNetworkElement(SecurityToken securityToken, Integer neId, String level);

    Container getContainer(SecurityToken securityToken, Integer id);

    EntityCollection<Container> getContainersInContainer(SecurityToken securityToken, Integer id, String level);


    EntityCollection<NetworkElement> getNetworkElements(SecurityToken securityToken, String level, List<String> subResources);

    EntityCollection<NetworkElement> getNetworkElementsOnContainer(SecurityToken securityToken, Integer ctId, String level, List<String> subResources);

    NetworkElement getNetworkElement(SecurityToken securityToken, Integer neId, List<String> subResources);


    EntityCollection<EquipmentHolder> getEquipmentHolders(SecurityToken securityToken, Integer neId, String level);

    EquipmentHolder getEquipmentHolder(SecurityToken securityToken, Integer neId, Integer ehId);

    EntityCollection<EquipmentHolder> getEquipmentHolders(SecurityToken securityToken, Integer neId, Integer ehId, String level);


    EntityCollection<Equipment> getEquipments(SecurityToken securityToken, Integer neId, Integer ehId, String level);

    EntityCollection<Equipment> getNeEquipments(SecurityToken securityToken, Integer neId, String level);

    Equipment getEquipment(SecurityToken securityToken, Integer neId, Integer eqId);

    EntityCollection<Equipment> getEquipmentsOnEquipment(SecurityToken securityToken, Integer neId, Integer eqId, String level);

    EntityCollection<PhysicalTerminationPoint> getPhysicalTerminationPoints(SecurityToken securityToken, Integer neId, Integer eqId, String level);

    PhysicalTerminationPoint getPhysicalTerminationPoint(SecurityToken securityToken, Integer neId, Integer ptpId);

    EntityCollection<TerminationPoint> getTerminationPoints(SecurityToken securityToken, Integer neId, Integer ptpId, String level);

    EntityCollection<TerminationPoint> getEqTerminationPoints(SecurityToken securityToken, Integer neId, Integer eqId, String level);

    EntityCollection<TerminationPoint> getTerminationPoints(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId, String level);

    TerminationPoint getTerminationPoint(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId);

    EntityCollection<CrossConnection> getCrossConnections(SecurityToken securityToken, Integer neId);

    EntityCollection<CrossConnection> getCrossConnections(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId);

    CrossConnection getCrossConnection(SecurityToken securityToken, Integer neId, Integer ptpIdA, Long tpIdA, Integer ptpIdZ, Long tpIdZ);

    CrossConnection getCrossConnection(SecurityToken securityToken, Integer neId, Integer ptpIdA, Long tpIdA, Integer ptpIdZ, Long tpIdZ, Integer ptpIdP, Long tpIdP);


    EntityCollection<InternalPortConnection> getInternalPortConnections(SecurityToken securityToken, Integer neId);

    EntityCollection<InternalPortConnection> getInternalPortConnections(SecurityToken securityToken, Integer neId, Integer ptpId);

    InternalPortConnection getInternalPortConnection(SecurityToken securityToken, Integer neId, Integer ptpIdA, Integer ptpIdZ);


    EntityCollection<TopologicalLink> getAllTopologicalLinks(SecurityToken securityToken);

    EntityCollection<TopologicalLink> getTopologicalLinksUsingNe(SecurityToken securityToken, Integer neId);

    EntityCollection<TopologicalLink> getTopologicalLinks(SecurityToken securityToken, Integer neId, Integer ptpId);

    TopologicalLink getTopologicalLink(SecurityToken securityToken, Integer neIdA, Integer ptpIdA, Integer neIdZ, Integer ptpIdZ);

    EntityCollection<Bridge> getBridges(SecurityToken securityToken, Integer neId, String level);

    Bridge getBridge(SecurityToken securityToken, Integer neId, Integer subsysId, Integer bridgeId);

    EntityCollection<Equipment> getEquipments(SecurityToken securityToken, Integer neId, Integer subsysId, Integer bridgeId, String level);

    EntityCollection<Vlan> getVlans(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId);

    EntityCollection<SystemContainer> getSystemContainers(SecurityToken securityToken, String level);

    SystemContainer getSystemContainer(SecurityToken securityToken, Integer sysContainerId);

    EntityCollection<NetworkElement> getNetworkElementsOnSystemContainer(SecurityToken securityToken, Integer sysContainerId, String level, List<String> subResources);

    EntityCollection<SystemContainer> getSystemContainers(SecurityToken securityToken, Integer ctId, String level);

    EntityCollection<Container> getContainersOfSystemContainer(SecurityToken securityToken, Integer integer, String level);

    EntityCollection<TerminationPoint> getBridgeTerminationPointLAGs(SecurityToken securityToken, Integer neId, Integer subsysId, Integer bridgeId, String level);

    EntityCollection<TerminationPoint> getBridgeTerminationPointEthItfs(SecurityToken securityToken, Integer neId, Integer subsysId, Integer bridgeId, Boolean template, Boolean lag, Boolean lagMember, Boolean inServices, String level);

    EntityCollection<TerminationPoint> getEthernetInterfacesOfLAG(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId, String level);
}
