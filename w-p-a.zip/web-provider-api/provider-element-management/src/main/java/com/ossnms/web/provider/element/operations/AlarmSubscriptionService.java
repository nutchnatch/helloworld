package com.ossnms.web.provider.element.operations;

import com.ossnms.web.provider.network.model.fault.AlarmsSummary;

/**
 * Created on 22-04-2016.
 */
public interface AlarmSubscriptionService {

    AlarmsSummary createCounter(String channel);

    Boolean destroyCounter(Integer alarmsSummaryId);
}
