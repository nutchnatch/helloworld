package com.ossnms.web.provider.element.operations;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.fault.AlarmSeveritiesColors;
import com.ossnms.web.provider.network.model.fault.AlarmsSummary;

/**
 * Created on 07-03-2016.
 */
public interface FaultService {

    AlarmSeveritiesColors getAlarmSeveritiesColors(SecurityToken securityToken);

    AlarmsSummary getContainerFault(SecurityToken securityToken, Integer id);

    AlarmsSummary getSystemContainerFault(SecurityToken securityToken, Integer sysCtId);

    AlarmsSummary getNetworkElementFault(SecurityToken securityToken, Integer neId);

    AlarmsSummary getEquipmentHolderFault(SecurityToken securityToken, Integer neId, Integer ehId);

    AlarmsSummary getEquipmentFault(SecurityToken securityToken, Integer neId, Integer eqId);

    AlarmsSummary getPhysicalTerminationPointFault(SecurityToken securityToken, Integer neId, Integer eqId, Integer ptpId);

    AlarmsSummary getTerminationPointFault(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId);

    AlarmsSummary getBridgeFault(SecurityToken securityToken, Integer neId, Integer subsysId, Integer bridgeId);

}
