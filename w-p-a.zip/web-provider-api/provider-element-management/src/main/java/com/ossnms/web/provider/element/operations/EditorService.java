package com.ossnms.web.provider.element.operations;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.element.operations.exception.EditorOperationException;
import com.ossnms.web.provider.element.operations.response.LagResponse;
import com.ossnms.web.provider.network.model.network.TerminationPoint;

import java.util.Collection;

/**
 * Created on 20-05-2016.
 */
public interface EditorService {

    LagResponse createLAG(SecurityToken securityToken, Integer neId, Integer subsysId, Integer bridgeId,
                          TerminationPoint lag, Collection<TerminationPoint> lagMembers) throws EditorOperationException;

    void deleteLAG(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId) throws EditorOperationException;

    void updateLabel(SecurityToken securityToken, Integer neId, Integer ptpId, Long tpId, String label) throws EditorOperationException;
}
