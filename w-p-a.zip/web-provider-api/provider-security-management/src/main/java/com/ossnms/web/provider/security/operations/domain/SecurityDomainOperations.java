package com.ossnms.web.provider.security.operations.domain;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.model.domain.SecurityDomain;
import com.ossnms.web.provider.security.model.domain.SecurityDomainID;
import com.ossnms.web.provider.security.model.domain.SecurityDomainSummary;
import com.ossnms.web.provider.security.model.domain.enumerable.SecurityDomainField;
import com.ossnms.web.provider.security.model.element.SecurableElementID;

import java.util.List;

/**
 * Includes operations possible for Security Domains
 */
public interface SecurityDomainOperations extends EntityOperations<SecurityDomainID, SecurityDomain, SecurityDomainSummary, SecurityDomainField> {

    /**
     * Assigns one securable element to a security domain
     * @param securityToken the security token which identifies the user and the underlying session
     * @param domainID the security domain
     * @param element the element to assign
     */
    SecurableElementID assign(SecurityToken securityToken, SecurityDomainID domainID, SecurableElementID element);

    /**
     * Assigns a list of securable elements to a security domain
     * @param securityToken the security token which identifies the user and the underlying session
     * @param domainID the security domain
     * @param elements the list of elements to assign
     */
    List<SecurableElementID> assign(SecurityToken securityToken, SecurityDomainID domainID, List<SecurableElementID> elements);

    /**
     * Get security domain details by name.
     * @param securityToken the security token which identifies the user and the underlying session
     * @param domainName the domain name used to find the security domain details
     */
    SecurityDomain getDetailsByName(SecurityToken securityToken, String domainName);
}
