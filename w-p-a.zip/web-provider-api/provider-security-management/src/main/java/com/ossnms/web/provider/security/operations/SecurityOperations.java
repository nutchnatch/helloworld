package com.ossnms.web.provider.security.operations;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.api.params.Permission;
import com.ossnms.web.provider.security.api.result.PermissionReply;
import com.ossnms.web.provider.security.model.VersionInformation;

/**
 * Implements security operations performed by a provider
 */
public interface SecurityOperations {

    /**
     * Logs the user in the provider system, using username and password
     *
     * @param username the username (mandatory)
     * @param password the matching password (mandatory)
     * @param sourceAddress the address (or any additional information) that might be used to identify the source
     *                      of the authentication. (optional)
     *
     * @return a {@link SecurityToken} instance if the login was successful; null otherwise;
     */
    SecurityToken login(String username, String password, String sourceAddress);

    /**
     * Validates the Base64 SessionContext, and returns a valid {@link SecurityToken}
     *
     * @param token the base 64 SessionContext
     *
     * @return a valid and verified {@link SecurityToken}
     */
    SecurityToken validateToken(String token);

    /**
     * Validates the current security token
     *
     * @param securityToken the instance of {@link SecurityToken}
     * @return the same instance, if valid; null otherwise
     */
    SecurityToken validateToken(SecurityToken securityToken);

    /**
     * Logs the user out of the current session
     *
     * @param securityToken the security token representing the current session
     */
    void logout(SecurityToken securityToken);

    /**
     * Returns the version information of the implementing application
     *
     * @param securityToken the security token with the user authentication
     * @return an instance of {@link VersionInformation} with the version
     */
    VersionInformation getVersionInformation(SecurityToken securityToken);

    /**
     * Checks if the user has permission to execute the specified action
     *
     * @param securityToken the security token which identifies the user and the current session
     * @param permission the action to check access to
     * @return true if the user has access; false otherwise;
     */
    PermissionReply hasPermission(SecurityToken securityToken, Permission... permission);
}
