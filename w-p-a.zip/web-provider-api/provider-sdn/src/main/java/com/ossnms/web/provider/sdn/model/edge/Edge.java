package com.ossnms.web.provider.sdn.model.edge;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.sdn.model.common.attributes.SrgDetail;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public final class Edge extends EdgeSummary implements Entity<EdgeID> {

    private static final long serialVersionUID = 1002418714326740374L;

    private final String onfOtwgImLayerList;
    private final int coriantLatency;
    private final List<SrgDetail> coriantSrgDetails;

    /**
     * @param builder
     */
    private Edge(Builder builder) {
        super(builder);

        this.onfOtwgImLayerList = builder.onfOtwgImLayerList;
        this.coriantLatency = builder.coriantLatency;
        this.coriantSrgDetails = new ArrayList<>(builder.coriantSrgDetails);
    }

    /**
     *
     * @return
     */
    public String getOnfOtwgImLayerList() {
        return onfOtwgImLayerList;
    }

    /**
     *
     * @return
     */
    public int getCoriantLatency() {
        return coriantLatency;
    }

    /**
     *
     * @return
     */
    public List<SrgDetail> getCoriantSrgDetails() {
        return coriantSrgDetails;
    }

    /**
     *
     */
    public static class Builder extends EdgeSummary.Builder {

        private String onfOtwgImLayerList;
        private int coriantLatency;
        private List<SrgDetail> coriantSrgDetails;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(EdgeID id) {
            super(id);

            coriantSrgDetails = new ArrayList<>();
        }

        /**
         *
         * @param onfOtwgImLayerList
         * @return
         */
        public Builder setOnfOtwgImLayerList(String onfOtwgImLayerList) {
            this.onfOtwgImLayerList = onfOtwgImLayerList;
            return this;
        }

        /**
         *
         * @param coriantLatency
         * @return
         */
        public Builder setCoriantLatency(int coriantLatency) {
            this.coriantLatency = coriantLatency;
            return this;
        }

        /**
         *
         * @param coriantSrgDetails
         * @return
         */
        public Builder addCoriantSrgDetails(List<SrgDetail> coriantSrgDetails) {
            this.coriantSrgDetails.addAll(coriantSrgDetails);
            return this;
        }

        /**
         *
         * @param coriantSrgDetail
         * @return
         */
        public Builder addCoriantSrgDetail(SrgDetail coriantSrgDetail) {
            this.coriantSrgDetails.add(coriantSrgDetail);
            return this;
        }

        /**
         * Overriden method to build a {@link Edge} instance
         *
         * @return a {@link Edge} instance, if every mandatory field was correctly filled
         */
        @Override
        public Edge build() {
            return new Edge(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        if (!super.equals(o)) { return false; }
        Edge edge = (Edge) o;
        return getCoriantLatency() == edge.getCoriantLatency() &&
                Objects.equals(getOnfOtwgImLayerList(), edge.getOnfOtwgImLayerList()) &&
                Objects.equals(getCoriantSrgDetails(), edge.getCoriantSrgDetails());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getOnfOtwgImLayerList(), getCoriantLatency(), getCoriantSrgDetails());
    }
}
