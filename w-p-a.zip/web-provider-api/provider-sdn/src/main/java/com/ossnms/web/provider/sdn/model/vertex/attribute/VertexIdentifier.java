package com.ossnms.web.provider.sdn.model.vertex.attribute;

import com.ossnms.web.provider.common.api.model.EntityField;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class VertexIdentifier implements EntityField<VertexIdentifier>{

    private static final long serialVersionUID = -4745346899990067840L;

    private final String coriantCoordLatitude;
    private final String coriantCoordLongitude;
    private final String coriantNodeType;
    private final String coriantDescription;

    /**
     * Private builder constructor
     * @param builder an instance of {@link Builder}
     */
    private VertexIdentifier(Builder builder) {
        this.coriantDescription = builder.coriantDescription;
        this.coriantNodeType = builder.coriantNodeType;
        this.coriantCoordLongitude = builder.coriantCoordLongitude;
        this.coriantCoordLatitude = builder.coriantCoordLatitude;
    }

    /**
     *
     * @return
     */
    public String getCoriantCoordLatitude() {
        return coriantCoordLatitude;
    }

    /**
     *
     * @return
     */
    public String getCoriantCoordLongitude() {
        return coriantCoordLongitude;
    }

    /**
     *
     * @return
     */
    public String getCoriantNodeType() {
        return coriantNodeType;
    }

    /**
     *
     * @return
     */
    public String getCoriantDescription() {
        return coriantDescription;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<VertexIdentifier> {

        private String coriantCoordLatitude;
        private String coriantCoordLongitude;
        private String coriantNodeType;
        private String coriantDescription;

        /**
         *
         * @param coriantCoordLatitude
         * @return
         */
        public Builder setCoriantCoordLatitude(String coriantCoordLatitude) {
            this.coriantCoordLatitude = coriantCoordLatitude;
            return this;
        }

        /**
         *
         * @param coriantCoordLongitude
         * @return
         */
        public Builder setCoriantCoordLongitude(String coriantCoordLongitude) {
            this.coriantCoordLongitude = coriantCoordLongitude;
            return this;
        }

        /**
         *
         * @param coriantNodeType
         * @return
         */
        public Builder setCoriantNodeType(String coriantNodeType) {
            this.coriantNodeType = coriantNodeType;
            return this;
        }

        /**
         *
         * @param coriantDescription
         * @return
         */
        public Builder setCoriantDescription(String coriantDescription) {
            this.coriantDescription = coriantDescription;
            return this;
        }

        @Override
        public VertexIdentifier build() {
            return new VertexIdentifier(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        VertexIdentifier that = (VertexIdentifier) o;
        return Objects.equals(getCoriantCoordLatitude(), that.getCoriantCoordLatitude()) &&
                Objects.equals(getCoriantCoordLongitude(), that.getCoriantCoordLongitude()) &&
                Objects.equals(getCoriantNodeType(), that.getCoriantNodeType()) &&
                Objects.equals(getCoriantDescription(), that.getCoriantDescription());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCoriantCoordLatitude(), getCoriantCoordLongitude(), getCoriantNodeType(), getCoriantDescription());
    }
}
