package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 */
public class RoutingFailureDetail implements Serializable {

   private static final long serialVersionUID = 7934437749643389334L;

   private final String failureCode;
   private final String failureDescription;


   private RoutingFailureDetail( Builder builder ) {

      this.failureCode = builder.failureCode;
      this.failureDescription = builder.failureDescription;
   }

   /**
    *
    * @return
    */
   public String getFailureCode() {

      return failureCode;
   }

   /**
    *
    * @return
    */
   public String getFailureDescription() {

      return failureDescription;
   }

   public static final class Builder implements ObjectBuilder<RoutingFailureDetail> {

      private String failureCode;
      private String failureDescription;

      /**
       *
       * @param failureCode
       * @return
       */
      public Builder setFailureCode( String failureCode ) {

         this.failureCode = failureCode;
         return this;
      }

      /**
       *
       * @param failureDescription
       * @return
       */
      public Builder setFailureDescription( String failureDescription ) {

         this.failureDescription = failureDescription;
         return this;
      }

      /**
       *
       * @return
       */
      public RoutingFailureDetail build() {

         return new RoutingFailureDetail( this );
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      RoutingFailureDetail that = (RoutingFailureDetail) o;
      return Objects.equals( failureCode, that.failureCode ) &&
             Objects.equals( failureDescription, that.failureDescription );
   }

   @Override
   public int hashCode() {

      return Objects.hash( failureCode, failureDescription );
   }
}