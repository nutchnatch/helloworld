package com.ossnms.web.provider.sdn.model.call;

/**
 *
 */
public enum CallField {
   NAME
}