package com.ossnms.web.provider.sdn.operations.topology;

import com.ossnms.web.provider.common.api.facade.ReadEntityOperations;
import com.ossnms.web.provider.sdn.model.topology.Topology;
import com.ossnms.web.provider.sdn.model.topology.TopologyField;
import com.ossnms.web.provider.sdn.model.topology.TopologyID;
import com.ossnms.web.provider.sdn.model.topology.TopologySummary;

/**
 *
 */
public interface TopologyEntityOperations extends ReadEntityOperations<TopologyID, Topology, TopologySummary, TopologyField> {
}
