package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.EntityID;

import java.util.Objects;

/**
 *
 */
public class ConnectionID implements EntityID {

   private static final long serialVersionUID = -3436071720856141826L;

   private final String domainId;
   private final String id;

   private ConnectionID( Builder builder ) {

      this.domainId = builder.domainId;
      this.id = builder.id;
   }

   public String getDomainId() {

      return domainId;
   }

   public String getId() {

      return id;
   }

   public static final class Builder {

      private String domainId;
      private String id;


      public Builder( String domainId, String id ) {

         this.domainId = domainId;
         this.id = id;
      }

      public Builder setDomainId( String domainId ) {

         this.domainId = domainId;
         return this;
      }

      public Builder setId( String id ) {

         this.id = id;
         return this;
      }

      public ConnectionID build() {

         return new ConnectionID( this );
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      ConnectionID that = (ConnectionID) o;
      return Objects.equals( domainId, that.domainId ) &&
             Objects.equals( id, that.id );
   }

   @Override
   public int hashCode() {

      return Objects.hash( domainId, id );
   }
}