package com.ossnms.web.provider.sdn.operations.endpoint;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.sdn.model.endpoint.Endpoint;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointField;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointID;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;

/**
 *
 */
public interface EndpointEntityOperations extends EntityOperations<EndpointID, Endpoint, EndpointSummary, EndpointField> {
}
