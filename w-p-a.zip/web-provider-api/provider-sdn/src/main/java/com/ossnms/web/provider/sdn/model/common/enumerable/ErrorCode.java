package com.ossnms.web.provider.sdn.model.common.enumerable;

/**
 *
 */
public enum ErrorCode {

    /**
     * Domain #X cannot be removed.
     */
    NBI01001,

    /**
     * Domain #X contains #N calls and therefore can't be removed.
     */
    NBI01002,

    /**
     * Domain #X contains #N endpoints and therefore can't be removed.
     */
    NBI01003,

    /**
     * Domain #X contains #N paths and therefore can't be removed.
     */
    NBI01004,

    /**
     * Domain #X must support at least one protocol.
     */
    NBI01005,

    /**
     * Domain does not support this protocol
     */
    NBI01006,

    /**
     * Endpoint attributes [switchingType: #A, encoding: #B, sigType: #C, adaptation: #D, bandwidth: #E] are unsupported for end #N
     */
    NBI06001,

    /**
     * Invalid layer attributes specification, sigType #A, switchingType #B, encoding #C, adaptation #D
     */
    NBI06002,

    /**
     * Invalid combination of layerId and layer attributes.
     */
    NBI06003,

    /**
     * Invalid portMode #N for provided layer definition.
     */
    NBI06004,

    /**
     * End #N already has Endpoint #M assigned
     */
    NBI06005,

    /**
     * Endpoint #N already in use by a Call
     */
    NBI06006,

    /**
     * Endpoint #N already in use by a PathRequest
     */
    NBI06007,

    /**
     * Invalid bandwidth #A for provided layer definition.
     */
    NBI06008,

    /**
     * Endpoint #N with pending operation in progress.
     */
    NBI06009,

    /**
     * Endpoint #N under invalid state #M for required operation.
     */
    NBI06010,

    /**
     * Invalid layerId #A.
     */
    NBI06011,

    /**
     * PathRequest #N in domain #M can not be administered now, since it has other operation #T under execution. Please try again later...
     */
    NBI07001,

    /**
     * PathRequest #N not found in domain #M
     */
    NBI07002,

    /**
     * Endpoint #N does not belong to same domain of the service. All endpoints of this service must belong to domain #M
     */
    NBI07003,

    /**
     * PathRequest #N in domain #M cannot be upgraded. Only reservation path requests are allowed for upgrade.
     */
    NBI07004,

    /**
     * PathRequest #N in domain #M cannot be upgraded. The path request has a calculation status not allowed for upgrade.
     */
    NBI07005,

    /**
     * PathRequest has a constraint risk #N in a domain #M different from the request domain. All constraint risks of this path request must belong to domain #R
     */
    NBI07006,

    /**
     * Invalid multiplier specified.
     */
    NBI08001,

    /**
     * Call #N in domain #M can not be administered now, since it has other operation #R under execution. Please try again later...
     */
    NBI08002,

    /**
     * Endpoint #N does not belong to same domain of the call. All endpoints of this call must belong to domain #M
     */
    NBI08003,

    /**
     * Call has a constraint risk #N in a domain #M different from the request domain. All constraint risks of this call must belong to domain #R
     */
    NBI08004,

    /**
     * Constraint Call #N in domain #M was not found.
     */
    NBI08005,

    /**
     * Constraint Call #N in domain #M has no valid route.
     */
    NBI08006,

    /**
     * Call SLA's throughput must be a value between 0 and 1.
     */
    NBI08007,

    /**
     * Call order number length exceeded.
     */
    NBI08008,

    /**
     * No protection group #N was found in call #M of domain #R.
     */
    NBI08009,

    /**
     * Protection group parameters are missing to execute request.
     */
    NBI08010,

    /**
     * No protection group was found in call #M of domain #R.
     */
    NBI08011,

    /**
     * Cannot change protection group of call #M in domain #R because active segment and nominal segment are not the same.
     */
    NBI08012,

    /**
     * Connection #N not found in domain #M
     */
    NBI09001,

    /**
     * Call #N not found in domain #M
     */
    NBI10001,

    /**
     * Call with status #N not ready to enforce.
     */
    NBI10002,

    /**
     * Enforce #N not found.
     */
    NBI10003,

    /**
     * Enforce #N in domain #M can not be administered now, since it has other operation #R under execution. Please try again later...
     */
    NBI10004,

    /**
     * Risk #N not found in domain #M
     */
    NBI11001,

    /**
     * Domain #N not found.
     */
    NBI13001,

    /**
     * End #N not found in domain #M
     */
    NBI13002,

    /**
     * End #N in vertex #M is inaccessible
     */
    NBI13003,

    /**
     * End #N not found in vertex #M
     */
    NBI13004,

    /**
     * Endpoint #N not found in domain #M
     */
    NBI13005,

    /**
     * Vertex #N not found in domain #M
     */
    NBI13006,

    /**
     * Edge #N not found in domain #M
     */
    NBI13007,

    /**
     * Attribute #N is malformed.
     */
    NBI13008,

    /**
     * Mandatory attribute #N is absent.
     */
    NBI13009,

    /**
     * Updatable attributes not provided.
     */
    NBI13010,

    /**
     * Attribute #N not valid for the request.
     */
    NBI13011,

    /**
     * Internal server error, exception without a mapper.
     */
    NBI13012,

    /**
     * Vertex #N not found
     */
    NBI13013,

    /**
     * Entity content is absent
     */
    NBI13017,

    /**
     * Request has invalid parameters. Reason: #N
     */
    NBI13018,

    /**
     * The class of risk #N in domain #M is not supported as a include constraint.
     */
    NBI13019,

    /**
     * Operation is not allowed. Resource cannot be used due to lack of ownership.
     */
    NBI13020,

    /**
     * End #N is not owned by SDN.
     */
    NBI13021,

    /**
     * Name already in use.
     */
    NBI13022,

    /**
     * Topology #N not found.
     */
    NBI13023,

    /**
     * The attributes #N and #M cannot coexist in the same request.
     */
    NBI13024,

    /**
     * Name attribute length exceeded.
     */
    NBI13025,

    /**
     * Target entity not found in the network.
     */
    NBI13026,

    /**
     * Resources, associated with target entity, not found in the network.
     */
    NBI13027,

    /**
     * largestTimestamp has to be equal or greater than 0
     */
    NBI14001,

    /**
     * smallestTimestamp has to be equal or greater than 0
     */
    NBI14002,

    /**
     * timestampSecond has to be equal or greater than 0
     */
    NBI14003,

    /**
     * timestampMinute has to be equal or greater than 0
     */
    NBI14004,

    /**
     * timestampHour has to be equal or greater than 0
     */
    NBI14005,

    /**
     * timestampDay has to be equal or greater than 0
     */
    NBI14006,

    /**
     * offset has to be equal or greater than 0
     */
    NBI14007,

    /**
     * limit has to be equal or greater than 0
     */
    NBI14008,

    /**
     * Vertex description length exceeded.
     */
    NBI15001,

    /**
     * Vertex latitude length exceeded.
     */
    NBI15002,

    /**
     * Vertex longitude length exceeded.
     */
    NBI15003,

    /**
     * Unable to decode error message. Please check the application logs for more detail on the error.
     */
    NBI16001,

    /**
     * A valid entity must be provided.
     */
    NBI16002,

    /**
     * Segment number #N not found in domain #R.
     */
    NBI17001,

    /**
     * Protection Group Action still in progress for the Segment #N in domain #R.
     */
    NBI17002,

    /**
     * Other 
     */
    GENERIC
}