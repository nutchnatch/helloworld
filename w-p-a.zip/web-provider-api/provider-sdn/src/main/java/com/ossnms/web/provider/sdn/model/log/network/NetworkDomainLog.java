package com.ossnms.web.provider.sdn.model.log.network;

import com.ossnms.web.provider.common.api.model.Entity;

/**
 *
 */
public final class NetworkDomainLog extends NetworkDomainLogSummary implements Entity<NetworkDomainLogID> {

    private static final long serialVersionUID = 7405978189940082460L;

    /**
     * @param builder
     */
    private NetworkDomainLog(Builder builder) {
        super(builder);
    }

    /**
     *
     */
    public static class Builder extends NetworkDomainLogSummary.Builder {
        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(NetworkDomainLogID id) {
            super(id);
        }

        /**
         * Overriden method to build a {@link NetworkDomainLog} instance
         *
         * @return a {@link NetworkDomainLog} instance, if every mandatory field was correctly filled
         */
        @Override
        public NetworkDomainLog build() {
            return new NetworkDomainLog(this);
        }
    }
}
