package com.ossnms.web.provider.sdn.operations.call;

import com.ossnms.web.provider.common.api.facade.ProcessableResultEntityOperations;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;

/**
 *
 */
public interface ProcessableCallEntityOperations extends ProcessableResultEntityOperations<CallID, Call, CallSummary, CallField, ErrorCode> {


    /**
     * enforce the instance.
     *
     * @param securityToken the security token which will authorize the current user
     * @return the instance which represents the updated object.
     */
    ProcessableSingleResult<CallID, ErrorCode> enforce(SecurityToken securityToken, CallID id);

}