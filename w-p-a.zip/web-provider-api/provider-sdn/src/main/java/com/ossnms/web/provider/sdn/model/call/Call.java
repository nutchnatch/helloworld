package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.sdn.model.common.attributes.SrgDetail;
import com.ossnms.web.provider.sdn.model.common.attributes.TrafficParam;
import com.ossnms.web.provider.sdn.model.edge.EdgeSummary;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public final class Call extends CallSummary implements Entity<CallID> {

   private static final long serialVersionUID = 6598467777696114062L;

   private final String pathRequestId;

   private final TrafficParam trafficParam;

   private final String adminStatus;

   private final String callProvisioningStatus;
   private final String callConfigStatus;
   private final String networkSyncStatus;
   private final Integer callLatency;

   private final RoutingFailureDetail routingFailureDetail;

   private final Integer switchingType;
   private final Integer encoding;
   private final String directionality;

   private final List<Connection> connections;

   private final List<EdgeSummary> path;

   //private final Constraints constraints;

   private final List<Long> serviceLatency;

   private final Boolean routingOverExistingServicesOnly;
   private final Boolean routingOverEnabledResourcesOnly;
   private final Boolean routingOverNotReservedResourcesOnly;
   private final String orderNumber;

   private final SLA sla;

   private final List<SrgDetail> srgDetails;

   //private final Schedule[] schedule;

   private final Boolean restorable;

   // Protection group for OFC
   private List<ProtectionGroup> protectionGroups;


   /**
    * @param builder
    */
   private Call( Builder builder ) {

      super( builder );
      this.pathRequestId = builder.pathRequestId;

      this.trafficParam = builder.trafficParam;

      this.adminStatus = builder.adminStatus;

      this.callProvisioningStatus = builder.callProvisioningStatus;
      this.callConfigStatus = builder.callConfigStatus;
      this.networkSyncStatus = builder.networkSyncStatus;
      this.callLatency = builder.callLatency;

      this.routingFailureDetail = builder.routingFailureDetail;

      this.switchingType = builder.switchingType;
      this.encoding = builder.encoding;
      this.directionality = builder.directionality;

      this.connections = new ArrayList<>( builder.connections );

      this.path = new ArrayList<>( builder.path );

      //this.constraints = builder.constraints;

      this.serviceLatency = new ArrayList<>( builder.serviceLatency );

      this.routingOverExistingServicesOnly = builder.routingOverExistingServicesOnly;
      this.routingOverEnabledResourcesOnly = builder.routingOverEnabledResourcesOnly;
      this.routingOverNotReservedResourcesOnly = builder.routingOverNotReservedResourcesOnly;
      this.orderNumber = builder.orderNumber;

      this.sla = builder.sla;

      this.srgDetails = new ArrayList<>( builder.srgDetails );

      //this.schedule = builder.schedule;

      this.restorable = builder.restorable;
      this.protectionGroups = new ArrayList<>( builder.protectionGroups );
   }


   public String getPathRequestId() {

      return pathRequestId;
   }

   public String getAdminStatus() {

      return adminStatus;
   }

   public String getCallProvisioningStatus() {

      return callProvisioningStatus;
   }

   public String getCallConfigStatus() {

      return callConfigStatus;
   }

   public String getNetworkSyncStatus() {

      return networkSyncStatus;
   }

   public Integer getCallLatency() {

      return callLatency;
   }

   public Integer getSwitchingType() {

      return switchingType;
   }

   public Integer getEncoding() {

      return encoding;
   }

   public String getDirectionality() {

      return directionality;
   }

   public List<Long> getServiceLatency() {

      return serviceLatency;
   }

   public Boolean getRoutingOverExistingServicesOnly() {

      return routingOverExistingServicesOnly;
   }

   public Boolean getRoutingOverEnabledResourcesOnly() {

      return routingOverEnabledResourcesOnly;
   }

   public Boolean getRoutingOverNotReservedResourcesOnly() {

      return routingOverNotReservedResourcesOnly;
   }

   public String getOrderNumber() {

      return orderNumber;
   }

   public Boolean isRestorable() {

      return restorable;
   }

   public TrafficParam getTrafficParam() {

      return trafficParam;
   }

   public RoutingFailureDetail getRoutingFailureDetail() {

      return routingFailureDetail;
   }

   public SLA getSla() {

      return sla;
   }

   public List<EdgeSummary> getPath() {

      return path;
   }

   public List<SrgDetail> getSrgDetails() {

      return srgDetails;
   }

   public List<Connection> getConnections() {

      return connections;
   }

   public List<ProtectionGroup> getProtectionGroups() {

      return protectionGroups;
   }

   /**
    *
    */
   public static class Builder extends CallSummaryPrototype<Builder> {

      private String pathRequestId;

      private TrafficParam trafficParam;

      private String adminStatus;
      private String callProvisioningStatus;
      private String callConfigStatus;
      private String networkSyncStatus;

      private Integer callLatency;

      private RoutingFailureDetail routingFailureDetail;

      private Integer switchingType;
      private Integer encoding;
      private String directionality;

      private List<Connection> connections;

      private List<EdgeSummary> path;

      //private Constraints constraints;

      private List<Long> serviceLatency;

      private Boolean routingOverExistingServicesOnly;
      private Boolean routingOverEnabledResourcesOnly;
      private Boolean routingOverNotReservedResourcesOnly;

      private String orderNumber;

      private SLA sla;

      private List<SrgDetail> srgDetails;

      //private Schedule[] schedule;

      private Boolean restorable;

      private List<ProtectionGroup> protectionGroups;


      /**
       * Builder constructor
       *
       * @param id mandatory field, id
       */
      public Builder( CallID id ) {

         super( id );

         this.connections = new ArrayList<>();
         this.path = new ArrayList<>();
         this.srgDetails = new ArrayList<>();
         this.serviceLatency = new ArrayList<>();
         this.protectionGroups = new ArrayList<>();
      }

      /**
       * @return
       */
      @Override
      protected Builder self() {

         return this;
      }

      /**
       * Overriden method to build a {@link Call} instance
       *
       * @return a {@link Call} instance, if every mandatory field was correctly filled
       */
      @Override
      public Call build() {

         return new Call( this );
      }

      /**
       * @param pathRequestId
       * @return
       */
      public Builder setPathRequestId( String pathRequestId ) {

         this.pathRequestId = pathRequestId;
         return this;
      }

      /**
       * @param adminStatus
       * @return
       */
      public Builder setAdminStatus( String adminStatus ) {

         this.adminStatus = adminStatus;
         return this;
      }

      /**
       * @param callProvisioningStatus
       * @return
       */
      public Builder setCallProvisioningStatus( String callProvisioningStatus ) {

         this.callProvisioningStatus = callProvisioningStatus;
         return this;
      }

      /**
       * @param callConfigStatus
       * @return
       */
      public Builder setCallConfigStatus( String callConfigStatus ) {

         this.callConfigStatus = callConfigStatus;
         return this;
      }

      /**
       * @param networkSyncStatus
       * @return
       */
      public Builder setNetworkSyncStatus( String networkSyncStatus ) {

         this.networkSyncStatus = networkSyncStatus;
         return this;
      }

      /**
       * @param callLatency
       * @return
       */
      public Builder setCallLatency( Integer callLatency ) {

         this.callLatency = callLatency;
         return this;
      }

      /**
       * @param switchingType
       * @return
       */
      public Builder setSwitchingType( Integer switchingType ) {

         this.switchingType = switchingType;
         return this;
      }

      /**
       * @param encoding
       * @return
       */
      public Builder setEncoding( Integer encoding ) {

         this.encoding = encoding;
         return this;
      }

      /**
       * @param directionality
       * @return
       */
      public Builder setDirectionality( String directionality ) {

         this.directionality = directionality;
         return this;
      }

      /**
       * @param serviceLatency
       * @return
       */
      public Builder setServiceLatency( List<Long> serviceLatency ) {

         if ( serviceLatency != null ) {

            this.serviceLatency = new ArrayList<>( serviceLatency );
         }

         return this;
      }

      /**
       * @param routingOverExistingServicesOnly
       * @return
       */
      public Builder setRoutingOverExistingServicesOnly( Boolean routingOverExistingServicesOnly ) {

         this.routingOverExistingServicesOnly = routingOverExistingServicesOnly;
         return this;
      }

      /**
       * @param routingOverEnabledResourcesOnly
       * @return
       */
      public Builder setRoutingOverEnabledResourcesOnly( Boolean routingOverEnabledResourcesOnly ) {

         this.routingOverEnabledResourcesOnly = routingOverEnabledResourcesOnly;
         return this;
      }

      /**
       * @param routingOverNotReservedResourcesOnly
       * @return
       */
      public Builder setRoutingOverNotReservedResourcesOnly( Boolean routingOverNotReservedResourcesOnly ) {

         this.routingOverNotReservedResourcesOnly = routingOverNotReservedResourcesOnly;
         return this;
      }

      /**
       * @param orderNumber
       * @return
       */
      public Builder setOrderNumber( String orderNumber ) {

         this.orderNumber = orderNumber;
         return this;
      }

      /**
       * @param restorable
       * @return
       */
      public Builder setRestorable( Boolean restorable ) {

         this.restorable = restorable;
         return this;
      }

      /**
       * @param trafficParam
       * @return
       */
      public Builder setTrafficParam( TrafficParam trafficParam ) {

         this.trafficParam = trafficParam;
         return this;
      }

      /**
       * @param routingFailureDetail
       * @return
       */
      public Builder setRoutingFailureDetail( RoutingFailureDetail routingFailureDetail ) {

         this.routingFailureDetail = routingFailureDetail;
         return this;
      }

      /**
       * @param sla
       * @return
       */
      public Builder setSla( SLA sla ) {

         this.sla = sla;
         return this;
      }

      /**
       * @param path
       * @return
       */
      public Builder addPath( List<EdgeSummary> path ) {

         this.path.addAll( path );
         return this;
      }

      /**
       * @param edge
       * @return
       */
      public Builder addEdge( EdgeSummary edge ) {

         this.path.add( edge );
         return this;
      }

      /**
       * @param srgDetails
       * @return
       */
      public Builder addSrgDetails( List<SrgDetail> srgDetails ) {

         this.srgDetails.addAll( srgDetails );
         return this;
      }

      /**
       * @param srgDetail
       * @return
       */
      public Builder addSrgDetail( SrgDetail srgDetail ) {

         this.srgDetails.add( srgDetail );
         return this;
      }

      /**
       * @param connections
       * @return
       */
      public Builder addConnections( List<Connection> connections ) {

         this.connections.addAll( connections );
         return this;
      }

      /**
       * @param connection
       * @return
       */
      public Builder addConnection( Connection connection ) {

         this.connections.add( connection );
         return this;
      }

      /**
       * @param protectionGroups
       * @return
       */
      public Builder addProtectionGroups( List<ProtectionGroup> protectionGroups ) {

         this.protectionGroups.addAll( protectionGroups );
         return this;
      }

      /**
       * @param protectionGroup
       * @return
       */
      public Builder addProtectionGroup( ProtectionGroup protectionGroup ) {

         this.protectionGroups.add( protectionGroup );
         return this;
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      if ( !super.equals( o ) ) {
         return false;
      }
      Call call = (Call) o;
      return Objects.equals( pathRequestId, call.pathRequestId ) &&
             Objects.equals( trafficParam, call.trafficParam ) &&
             Objects.equals( adminStatus, call.adminStatus ) &&
             Objects.equals( callProvisioningStatus, call.callProvisioningStatus ) &&
             Objects.equals( callConfigStatus, call.callConfigStatus ) &&
             Objects.equals( networkSyncStatus, call.networkSyncStatus ) &&
             Objects.equals( callLatency, call.callLatency ) &&
             Objects.equals( routingFailureDetail, call.routingFailureDetail ) &&
             Objects.equals( switchingType, call.switchingType ) &&
             Objects.equals( encoding, call.encoding ) &&
             Objects.equals( directionality, call.directionality ) &&
             Objects.equals( connections, call.connections ) &&
             Objects.equals( path, call.path ) &&
             Objects.equals( serviceLatency, call.serviceLatency ) &&
             Objects.equals( routingOverExistingServicesOnly, call.routingOverExistingServicesOnly ) &&
             Objects.equals( routingOverEnabledResourcesOnly, call.routingOverEnabledResourcesOnly ) &&
             Objects.equals( routingOverNotReservedResourcesOnly, call.routingOverNotReservedResourcesOnly ) &&
             Objects.equals( orderNumber, call.orderNumber ) &&
             Objects.equals( sla, call.sla ) &&
             Objects.equals( srgDetails, call.srgDetails ) &&
             Objects.equals( restorable, call.restorable );
   }

   @Override
   public int hashCode() {

      return Objects.hash( super.hashCode(), pathRequestId, trafficParam, adminStatus, callProvisioningStatus, callConfigStatus, networkSyncStatus, callLatency, routingFailureDetail, switchingType, encoding, directionality, connections, path, serviceLatency, routingOverExistingServicesOnly, routingOverEnabledResourcesOnly, routingOverNotReservedResourcesOnly, orderNumber, sla, srgDetails, restorable );
   }
}