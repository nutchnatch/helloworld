package com.ossnms.web.provider.sdn.operations.link;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.sdn.model.link.Link;
import com.ossnms.web.provider.sdn.model.link.LinkField;
import com.ossnms.web.provider.sdn.model.link.LinkID;
import com.ossnms.web.provider.sdn.model.link.LinkSummary;

/**
 *
 */
public interface LinkEntityOperations extends EntityOperations<LinkID, Link, LinkSummary, LinkField> {
}
