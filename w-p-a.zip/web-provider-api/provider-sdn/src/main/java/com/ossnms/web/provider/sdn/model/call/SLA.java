package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;
import java.util.Objects;

public class SLA implements Serializable {

    private static final long serialVersionUID = 2088999296702528L;

    private final Boolean slaMonitoring;
    private final Double throughput;
    private final String callImpairmentStatus;
    private final String callLastImpairmentStatusTimestamp;


    private SLA( Builder builder ) {

        this.throughput = builder.throughput;
        this.callLastImpairmentStatusTimestamp = builder.callLastImpairmentStatusTimestamp;
        this.callImpairmentStatus = builder.callImpairmentStatus;
        this.slaMonitoring = builder.slaMonitoring;
    }

    /**
     *
     * @return
     */
    public Boolean isSLAMonitoring() {

        return slaMonitoring;
    }

    /**
     *
     * @return
     */
    public Double getThroughput() {

        return throughput;
    }

    /**
     *
     * @return
     */
    public String getCallImpairmentStatus() {

        return callImpairmentStatus;
    }

    /**
     *
     * @return
     */
    public String getCallLastImpairmentStatusTimestamp() {

        return callLastImpairmentStatusTimestamp;
    }


    public static final class Builder implements ObjectBuilder<SLA> {

        private Boolean slaMonitoring;
        private Double throughput;
        private String callImpairmentStatus;
        private String callLastImpairmentStatusTimestamp;

        /**
         *
         * @param slaMonitoring
         * @return
         */
        public Builder setSLAMonitoring( Boolean slaMonitoring ) {

            this.slaMonitoring = slaMonitoring;
            return this;
        }

        /**
         *
         * @param throughput
         * @return
         */
        public Builder setThroughput( Double throughput ) {

            this.throughput = throughput;
            return this;
        }

        /**
         *
         * @param callImpairmentStatus
         * @return
         */
        public Builder setCallImpairmentStatus( String callImpairmentStatus ) {

            this.callImpairmentStatus = callImpairmentStatus;
            return this;
        }

        /**
         *
         * @param callLastImpairmentStatusTimestamp
         * @return
         */
        public Builder setCallLastImpairmentStatusTimestamp( String callLastImpairmentStatusTimestamp ) {

            this.callLastImpairmentStatusTimestamp = callLastImpairmentStatusTimestamp;
            return this;
        }

        /**
         *
         * @return
         */
        public SLA build() {

            return new SLA( this );
        }
    }


    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        SLA sla = (SLA) o;
        return Objects.equals( slaMonitoring, sla.slaMonitoring ) &&
               Objects.equals( throughput, sla.throughput ) &&
               Objects.equals( callImpairmentStatus, sla.callImpairmentStatus ) &&
               Objects.equals( callLastImpairmentStatusTimestamp, sla.callLastImpairmentStatusTimestamp );
    }

    @Override
    public int hashCode() {

        return Objects.hash( slaMonitoring, throughput, callImpairmentStatus, callLastImpairmentStatusTimestamp );
    }
}