package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 * {@link CallID}
 */
public final class CallID implements EntityID {

   private static final long serialVersionUID = 4128390037909683457L;

   private final String id;
   private final String domainId;


   /**
    * @return
    */
   public String getID() {

      return this.id;
   }

   /**
    * @return
    */
   public String getDomainId() {

      return this.domainId;
   }

   /**
    * Private builder constructor
    *
    * @param builder the builder
    */
   private CallID( Builder builder ) {

      this.id = builder.id;
      this.domainId = builder.domainId;
   }

   /**
    * Builder of {@link CallID} instances
    */
   public static class Builder implements ObjectBuilder<CallID> {

      private String id;
      private String domainId;

      /**
       * Builder constructor
       *
       * @param domainId
       * @param id
       */
      public Builder( String domainId, String id ) {

         this.id = id;
         this.domainId = domainId;
      }

      /**
       * Builds the object
       *
       * @return instance of {@link CallID}
       */
      @Override
      public CallID build() {

         return new CallID( this );
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      CallID callID = (CallID) o;
      return
            Objects.equals( this.id, callID.id ) &&
            Objects.equals( this.domainId, callID.domainId );
   }

   @Override
   public int hashCode() {

      return Objects.hash( this.id, this.domainId );
   }
}