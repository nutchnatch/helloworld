package com.ossnms.web.provider.sdn.model.vertex;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 * {@link VertexID}
 */
public final class VertexID implements EntityID {

    private static final long serialVersionUID = 4128390037909683457L;

    private final String domainId;
    private final String id;

    /**
     * @return
     */
    public String getDomainId() {

        return domainId;
    }

    /**
     * @return
     */
    public String getID() {

        return id;
    }

    /**
     * Private builder constructor
     *
     * @param builder the builder
     */
    private VertexID( Builder builder ) {

        this.domainId = builder.domainId;
        this.id = builder.id;
    }

    /**
     * Builder of {@link VertexID} instances
     */
    public static class Builder implements ObjectBuilder<VertexID> {

        private String domainId;
        private String id;

        /**
         * Builder constructor
         *
         * @param id the id parameter
         */
        public Builder( String domainId, String id ) {

            this.domainId = domainId;
            this.id = id;
        }

        /**
         * Builds the object
         *
         * @return instance of {@link VertexID}
         */
        @Override
        public VertexID build() {

            return new VertexID( this );
        }
    }

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        VertexID vertexID = (VertexID) o;
        return Objects.equals( this.id, vertexID.id ) && Objects.equals( this.domainId, vertexID.domainId );
    }

    @Override
    public int hashCode() {

        return Objects.hash( this.domainId, this.id );
    }
}