package com.ossnms.web.provider.sdn.model.link;

import com.ossnms.web.provider.common.api.model.Entity;

/**
 *
 */
public final class Link extends LinkSummary implements Entity<LinkID> {

    private static final long serialVersionUID = 2928982275375624558L;

    /**
     * @param builder
     */
    private Link(Builder builder) {
        super(builder);
    }

    /**
     *
     */
    public static class Builder extends LinkSummary.Builder {
        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(LinkID id) {
            super(id);
        }

        /**
         * Overriden method to build a {@link Link} instance
         *
         * @return a {@link Link} instance, if every mandatory field was correctly filled
         */
        @Override
        public Link build() {
            return new Link(this);
        }
    }
}
