package com.ossnms.web.provider.sdn.operations.network;

import com.ossnms.web.provider.common.api.facade.ProcessableResultEntityOperations;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkField;
import com.ossnms.web.provider.sdn.model.network.NetworkID;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;

/**
 *
 */
public interface ProcessableNetworkEntityOperations
        extends ProcessableResultEntityOperations<NetworkID, Network, NetworkSummary, NetworkField, ErrorCode> {
}
