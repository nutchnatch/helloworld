package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.sdn.model.edge.EdgeID;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 */
public class ConnectionTopoComponent implements Serializable {

   private static final long serialVersionUID = 31827026717966341L;

   private EdgeID edgeId;
   private ConnectionID connectionId;


   private ConnectionTopoComponent( Builder builder ) {

      this.connectionId = builder.connectionId;
      this.edgeId = builder.edgeId;
   }

   public EntityID getID() {

      if ( connectionId != null ) {

         return this.connectionId;
      }
      else {

         return this.edgeId;
      }
   }


   public static final class Builder {
      private EdgeID edgeId;
      private ConnectionID connectionId;


      public Builder( EdgeID edgeId ) {

         this.edgeId = edgeId;
      }

      public Builder( ConnectionID connectionId ) {

         this.connectionId = connectionId;
      }

      public ConnectionTopoComponent build() {

         return new ConnectionTopoComponent( this );
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      ConnectionTopoComponent that = (ConnectionTopoComponent) o;
      return Objects.equals( edgeId, that.edgeId ) &&
             Objects.equals( connectionId, that.connectionId );
   }

   @Override
   public int hashCode() {

      return Objects.hash( edgeId, connectionId );
   }
}