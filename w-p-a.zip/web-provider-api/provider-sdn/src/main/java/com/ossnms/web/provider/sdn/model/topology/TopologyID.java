package com.ossnms.web.provider.sdn.model.topology;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 * {@link TopologyID}
 */
public final class TopologyID implements EntityID {

    private static final long serialVersionUID = 4128390037909683457L;

    private final String id;

    /**
     *
     */
    public String getID() {
        return id;
    }

    /**
     * Private builder constructor
     *
     * @param builder the builder
     */
    private TopologyID(Builder builder) {
        this.id = builder.id;
    }

    /**
     * Builder of {@link TopologyID} instances
     */
    public static class Builder implements ObjectBuilder<TopologyID> {

        private String id;

        /**
         * Builder constructor
         *
         * @param id the id parameter
         */
        public Builder(String id) {
            this.id = id;
        }

        /**
         * Builds the object
         *
         * @return instance of {@link TopologyID}
         */
        @Override
        public TopologyID build() {
            return new TopologyID(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        TopologyID that = (TopologyID) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}