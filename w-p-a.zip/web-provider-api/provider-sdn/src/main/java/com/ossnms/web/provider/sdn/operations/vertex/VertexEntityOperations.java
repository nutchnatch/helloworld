package com.ossnms.web.provider.sdn.operations.vertex;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.sdn.model.vertex.Vertex;
import com.ossnms.web.provider.sdn.model.vertex.VertexField;
import com.ossnms.web.provider.sdn.model.vertex.VertexID;
import com.ossnms.web.provider.sdn.model.vertex.VertexSummary;

/**
 *
 */
public interface VertexEntityOperations extends EntityOperations<VertexID, Vertex, VertexSummary, VertexField> {
}
