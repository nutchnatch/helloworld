package com.ossnms.web.provider.sdn.model.log.network;

/**
 *
 */
public enum NetworkDomainLogField {
}
