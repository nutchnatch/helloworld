package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;
import java.util.Objects;

/**
 * Created by 68500245 on 31-01-2017.
 */
public class ProtectionGroup implements Serializable {

   private static final long serialVersionUID = 8621085625363513216L;

   private String id;

   private String protectionMode;
   private String protectionState;
   private String protectionType;
   private String restorationGate;


   private ProtectionGroup( ProtectionGroup.Builder builder ) {

      this.protectionMode = builder.protectionMode;
      this.protectionState = builder.protectionState;
      this.protectionType = builder.protectionType;
      this.restorationGate = builder.restorationGate;
   }

   public String getId() {

      return id;
   }

   public String getProtectionMode() {

      return protectionMode;
   }

   public String getProtectionState() {

      return protectionState;
   }

   public String getProtectionType() {

      return protectionType;
   }

   public String getRestorationGate() {

      return restorationGate;
   }

   public static final class Builder implements ObjectBuilder<ProtectionGroup> {

      private String id;

      private String protectionMode;
      private String protectionState;
      private String protectionType;
      private String restorationGate;

      public ProtectionGroup build() {

         return new ProtectionGroup( this );
      }

      public Builder setId( String id ) {

         this.id = id;
         return this;
      }

      public Builder setProtectionMode( String protectionMode ) {

         this.protectionMode = protectionMode;
         return this;
      }

      public Builder setProtectionState( String protectionState ) {

         this.protectionState = protectionState;
         return this;
      }

      public Builder setProtectionType( String protectionType ) {

         this.protectionType = protectionType;
         return this;
      }

      public Builder setRestorationGate( String restorationGate ) {

         this.restorationGate = restorationGate;
         return this;
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      ProtectionGroup that = (ProtectionGroup) o;
      return Objects.equals( id, that.id ) &&
             Objects.equals( protectionMode, that.protectionMode ) &&
             Objects.equals( protectionState, that.protectionState ) &&
             Objects.equals( protectionType, that.protectionType ) &&
             Objects.equals( restorationGate, that.restorationGate );
   }

   @Override
   public int hashCode() {

      return Objects.hash( id, protectionMode, protectionState, protectionType, restorationGate );
   }
}