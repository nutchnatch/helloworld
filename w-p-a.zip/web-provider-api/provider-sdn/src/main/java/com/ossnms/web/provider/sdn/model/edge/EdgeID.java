package com.ossnms.web.provider.sdn.model.edge;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 * {@link EdgeID}
 */
public final class EdgeID implements EntityID {

    private static final long serialVersionUID = 4128390037909683457L;

    private final String domainId;
    private final String id;

    /**
     *
     * @return
     */
    public String getDomainId() {

        return domainId;
    }

    /**
     *
     * @return
     */
    public String getID() {
        return id;
    }

    /**
     * Private builder constructor
     *
     * @param builder the builder
     */
    private EdgeID( Builder builder ) {

        this.domainId = builder.domainId;
        this.id = builder.id;
    }

    /**
     * Builder of {@link EdgeID} instances
     */
    public static class Builder implements ObjectBuilder<EdgeID> {

        private String domainId;
        private String id;

        /**
         * Builder constructor
         *
         * @param id the id parameter
         */
        public Builder( String domainId, String id ) {

            this.domainId = domainId;
            this.id = id;
        }

        /**
         * Builds the object
         *
         * @return instance of {@link EdgeID}
         */
        @Override
        public EdgeID build() {
            return new EdgeID(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        EdgeID edgeID = (EdgeID) o;
        return Objects.equals( this.id, edgeID.id ) && Objects.equals( this.domainId, edgeID.domainId );
    }

    @Override
    public int hashCode() { return Objects.hash( this.domainId, this.id ); }
}