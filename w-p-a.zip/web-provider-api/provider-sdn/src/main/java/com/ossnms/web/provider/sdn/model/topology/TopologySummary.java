package com.ossnms.web.provider.sdn.model.topology;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class TopologySummary implements EntitySummary<TopologyID> {

    private static final long serialVersionUID = -1359834486753229141L;

    private final TopologyID id;

    /**
     * @param builder
     */
    protected TopologySummary(Builder builder) {
        this.id = builder.id;
    }

    /**
     * Returns an instance of {@link TopologyID} representing an identifier
     *
     * @return the identifier
     */
    @Override
    public TopologyID getID() {
        return this.id;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<TopologySummary> {

        private TopologyID id;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(TopologyID id) {
            this.id = id;
        }

        /**
         * Constructs an instance of {@link TopologySummary}
         *
         * @return the object instance
         */
        @Override
        public TopologySummary build() {
            return new TopologySummary(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        TopologySummary that = (TopologySummary) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
