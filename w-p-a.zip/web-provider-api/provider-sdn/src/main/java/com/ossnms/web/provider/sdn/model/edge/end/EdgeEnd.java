package com.ossnms.web.provider.sdn.model.edge.end;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.sdn.model.common.attributes.ActualLayer;
import com.ossnms.web.provider.sdn.model.common.attributes.LayerAttribute;
import com.ossnms.web.provider.sdn.model.common.attributes.SrgDetail;
import com.ossnms.web.provider.sdn.model.edge.end.attribute.EdgeEndIdentifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public final class EdgeEnd extends EdgeEndSummary implements Entity<EdgeEndID> {

    private static final long serialVersionUID = 4536324655954525227L;

    private final List<LayerAttribute> oifENNIv2LayerAttribs;

    private final List<ActualLayer> coriantActualLayers;

    private final EdgeEndIdentifier coriantEndIdentifiers;

    private final List<SrgDetail> coriantSrgDetails;

    /**
     * @param builder
     */
    private EdgeEnd(Builder builder) {
        super(builder);

        this.coriantSrgDetails      = new ArrayList<>(builder.coriantSrgDetails);
        this.oifENNIv2LayerAttribs  = new ArrayList<>(builder.oifENNIv2LayerAttribs);
        this.coriantActualLayers    = new ArrayList<>(builder.coriantActualLayers);
        this.coriantEndIdentifiers  = builder.coriantEndIdentifiers;
    }

    /**
     *
     */
    public List<LayerAttribute> getOifENNIv2LayerAttribs() {
        return oifENNIv2LayerAttribs;
    }

    /**
     *
     */
    public List<ActualLayer> getCoriantActualLayers() {
        return coriantActualLayers;
    }

    /**
     *
     * @return
     */
    public List<SrgDetail> getCoriantSrgDetails() {
        return coriantSrgDetails;
    }

    /**
     *
     * @return
     */
    public EdgeEndIdentifier getCoriantEndIdentifiers() {
        return coriantEndIdentifiers;
    }

    /**
     *
     */
    public static class Builder extends EdgeEndSummary.Builder {

        private List<SrgDetail> coriantSrgDetails;
        private EdgeEndIdentifier coriantEndIdentifiers;
        private List<LayerAttribute> oifENNIv2LayerAttribs;
        private List<ActualLayer> coriantActualLayers;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(EdgeEndID id) {
            super(id);
            this.coriantSrgDetails = new ArrayList<>();
            this.oifENNIv2LayerAttribs = new ArrayList<>();
            this.coriantActualLayers = new ArrayList<>();
        }

        /**
         *
         * @param coriantSrgDetails
         * @return
         */
        public Builder addCoriantSrgDetails(List<SrgDetail> coriantSrgDetails) {
            this.coriantSrgDetails.addAll(coriantSrgDetails);
            return this;
        }

        /**
         *
         * @param coriantSrgDetail
         * @return
         */
        public Builder addCoriantSrgDetail(SrgDetail coriantSrgDetail) {
            this.coriantSrgDetails.add(coriantSrgDetail);
            return this;
        }

        /**
         *
         * @param coriantEndIdentifiers
         * @return
         */
        public Builder setCoriantEndIdentifiers(EdgeEndIdentifier coriantEndIdentifiers) {
            this.coriantEndIdentifiers = coriantEndIdentifiers;
            return this;
        }

        /**
         *
         * @param oifENNIv2LayerAttribs
         * @return
         */
        public Builder addOifENNIv2LayerAttribs(List<LayerAttribute> oifENNIv2LayerAttribs) {
            this.oifENNIv2LayerAttribs.addAll(oifENNIv2LayerAttribs);
            return this;
        }

        /**
         *
         * @param coriantActualLayers
         * @return
         */
        public Builder addCoriantActualLayers(List<ActualLayer> coriantActualLayers) {
            this.coriantActualLayers.addAll(coriantActualLayers);
            return this;
        }

        /**
         *
         * @param oifENNIv2LayerAttrib
         * @return
         */
        public Builder addOifENNIv2LayerAttrib(LayerAttribute oifENNIv2LayerAttrib) {
            this.oifENNIv2LayerAttribs.add(oifENNIv2LayerAttrib);
            return this;
        }

        /**
         *
         * @param coriantActualLayer
         * @return
         */
        public Builder addCoriantActualLayer(ActualLayer coriantActualLayer) {
            this.coriantActualLayers.add(coriantActualLayer);
            return this;
        }

        /**
         * Overriden method to build a {@link EdgeEnd} instance
         *
         * @return a {@link EdgeEnd} instance, if every mandatory field was correctly filled
         */
        @Override
        public EdgeEnd build() {
            return new EdgeEnd(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        if (!super.equals(o)) { return false; }
        EdgeEnd edgeEnd = (EdgeEnd) o;
        return Objects.equals(getOifENNIv2LayerAttribs(), edgeEnd.getOifENNIv2LayerAttribs()) &&
                Objects.equals(getCoriantActualLayers(), edgeEnd.getCoriantActualLayers()) &&
                Objects.equals(getCoriantEndIdentifiers(), edgeEnd.getCoriantEndIdentifiers()) &&
                Objects.equals(getCoriantSrgDetails(), edgeEnd.getCoriantSrgDetails());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getOifENNIv2LayerAttribs(), getCoriantActualLayers(), getCoriantEndIdentifiers(), getCoriantSrgDetails());
    }
}
