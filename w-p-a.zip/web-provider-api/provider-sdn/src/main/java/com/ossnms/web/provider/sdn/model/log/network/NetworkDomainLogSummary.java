package com.ossnms.web.provider.sdn.model.log.network;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class NetworkDomainLogSummary implements EntitySummary<NetworkDomainLogID> {

    private static final long serialVersionUID = -1359834486753229141L;

    private final NetworkDomainLogID id;

    /**
     * @param builder
     */
    protected NetworkDomainLogSummary(Builder builder) {
        this.id = builder.id;
    }

    /**
     * Returns an instance of {@link NetworkDomainLogID} representing an identifier
     *
     * @return the identifier
     */
    @Override
    public NetworkDomainLogID getID() {
        return this.id;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<NetworkDomainLogSummary> {

        private NetworkDomainLogID id;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(NetworkDomainLogID id) {
            this.id = id;
        }

        /**
         * Constructs an instance of {@link NetworkDomainLogSummary}
         *
         * @return the object instance
         */
        @Override
        public NetworkDomainLogSummary build() {
            return new NetworkDomainLogSummary(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        NetworkDomainLogSummary that = (NetworkDomainLogSummary) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
