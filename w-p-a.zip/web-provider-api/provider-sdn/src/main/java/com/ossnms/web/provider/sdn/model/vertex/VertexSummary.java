package com.ossnms.web.provider.sdn.model.vertex;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.sdn.model.vertex.attribute.VertexIdentifier;

import java.util.Objects;

/**
 *
 */
public class VertexSummary implements EntitySummary<VertexID> {

    private static final long serialVersionUID = -1359834486753229141L;

    private final VertexID id;
    private final String name;
    private final String coriantEmsName;
    private final VertexIdentifier coriantVertexIdentifier;

    /**
     * @param builder
     */
    protected VertexSummary(Builder builder) {
        this.id = builder.id;

        this.name = builder.name ;
        this.coriantEmsName = builder.coriantEmsName;
        this.coriantVertexIdentifier = builder.coriantVertexIdentifier;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @return
     */
    public String getCoriantEmsName() {
        return coriantEmsName;
    }

    /**
     *
     * @return
     */
    public VertexIdentifier getCoriantVertexIdentifier() {
        return coriantVertexIdentifier;
    }

    /**
     * Returns an instance of {@link VertexID} representing an identifier
     *
     * @return the identifier
     */
    @Override
    public VertexID getID() {
        return this.id;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<VertexSummary> {

        private VertexID id;
        private String name;
        private String coriantEmsName;
        private VertexIdentifier coriantVertexIdentifier;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(VertexID id) {
            this.id = id;
        }

        /**
         *
         * @param coriantVertexIdentifier
         * @return
         */
        public Builder setCoriantVertexIdentifier(VertexIdentifier coriantVertexIdentifier) {
            this.coriantVertexIdentifier = coriantVertexIdentifier;
            return this;
        }

        /**
         *
         * @param coriantEmsName
         * @return
         */
        public Builder setCoriantEmsName(String coriantEmsName) {
            this.coriantEmsName = coriantEmsName;
            return this;
        }

        /**
         *
         * @param name
         * @return
         */
        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        /**
         * Constructs an instance of {@link VertexSummary}
         *
         * @return the object instance
         */
        @Override
        public VertexSummary build() {
            return new VertexSummary(this);
        }
    }

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        VertexSummary that = (VertexSummary) o;
        return Objects.equals( id, that.id ) &&
               Objects.equals( name, that.name ) &&
               Objects.equals( coriantEmsName, that.coriantEmsName ) &&
               Objects.equals( coriantVertexIdentifier, that.coriantVertexIdentifier );
    }

    @Override
    public int hashCode() {

        return Objects.hash( id, name, coriantEmsName, coriantVertexIdentifier );
    }
}