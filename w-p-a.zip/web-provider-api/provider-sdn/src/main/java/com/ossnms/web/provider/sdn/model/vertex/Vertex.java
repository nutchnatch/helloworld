package com.ossnms.web.provider.sdn.model.vertex;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.sdn.model.common.attributes.SrgDetail;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public final class Vertex extends VertexSummary implements Entity<VertexID> {

    private static final long serialVersionUID = -2973758787882535401L;

    private final String description;
    private final List<SrgDetail> coriantSrgDetails;

    /**
     * @param builder
     */
    private Vertex( Builder builder ) {

        super( builder );
        this.description = builder.description;
        this.coriantSrgDetails = builder.coriantSrgDetails;
    }

    /**
     *
     * @return
     */
    public String getDescription() {

        return description;
    }

    /**
     *
     * @return
     */
    public List<SrgDetail> getCoriantSrgDetails() {
        return coriantSrgDetails;
    }

    /**
     *
     */
    public static class Builder extends VertexSummary.Builder {

        private String description;
        private List<SrgDetail> coriantSrgDetails;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(VertexID id) {
            super(id);
            this.coriantSrgDetails = new ArrayList<>();
        }

        /**
         *
         * @param description
         * @return
         */
        public Builder setDescription( String description ) {

            this.description = description;
            return this;
        }

        /**
         *
         * @param coriantSrgDetail
         * @return
         */
        public Builder addCoriantSrgDetail(SrgDetail coriantSrgDetail) {
            this.coriantSrgDetails.add(coriantSrgDetail);
            return this;
        }

        /**
         *
         * @param coriantSrgDetails
         * @return
         */
        public Builder addCoriantSrgDetails(List<SrgDetail> coriantSrgDetails) {
            this.coriantSrgDetails.addAll(coriantSrgDetails);
            return this;
        }

        /**
         * Overriden method to build a {@link Vertex} instance
         *
         * @return a {@link Vertex} instance, if every mandatory field was correctly filled
         */
        @Override
        public Vertex build() {
            return new Vertex(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        if (!super.equals(o)) { return false; }
        Vertex vertex = (Vertex) o;
        return Objects.equals( this.description, vertex.description ) &&  Objects.equals( getCoriantSrgDetails(), vertex.getCoriantSrgDetails() );
    }

    @Override
    public int hashCode() { return Objects.hash( super.hashCode(), this.description, getCoriantSrgDetails() ); }
}
