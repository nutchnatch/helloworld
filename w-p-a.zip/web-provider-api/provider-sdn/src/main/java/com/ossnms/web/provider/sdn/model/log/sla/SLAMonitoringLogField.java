package com.ossnms.web.provider.sdn.model.log.sla;

/**
 *
 */
public enum SLAMonitoringLogField {
}
