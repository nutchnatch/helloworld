package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;

import java.util.Objects;

/**
 *
 */
public class CallSummary implements EntitySummary<CallID> {

   private static final long serialVersionUID = -1359834486753229141L;

   private final CallID id;

   private final String name;

   private final EndpointSummary aEnd;

   private final EndpointSummary zEnd;

   private final String operStatus;

   /**
    * @param builder
    */
   protected CallSummary( CallSummaryPrototype<?> builder ) {

      this.id = builder.getId();
      this.name = builder.getName();

      this.aEnd = builder.getAEnd();
      this.zEnd = builder.getZEnd();

      this.operStatus = builder.getOperStatus();
   }

   /**
    * Returns an instance of {@link CallID} representing an identifier
    *
    * @return the identifier
    */
   @Override
   public CallID getID() {
      return this.id;
   }

   /**
    *
    * @return
    */
   public String getName() {
      return this.name;
   }

   /**
    *
    * @return
    */
   public String getOperStatus() {
      return this.operStatus;
   }

   /**
    *
    */
   public EndpointSummary getAEnd() {
      return this.aEnd;
   }

   /**
    *
    */
   public EndpointSummary getZEnd() {
      return this.zEnd;
   }

   /**
    *
    */
   public static class Builder extends CallSummaryPrototype<Builder> {

      /**
       * Builder constructor
       *
       * @param id mandatory field, id
       */
      public Builder( CallID id ) {
         super( id );
      }

      @Override
      protected Builder self() {
         return this;
      }

      /**
       * Constructs an instance of {@link CallSummary}
       *
       * @return the object instance
       */
      @Override
      public CallSummary build() {
         if ( this.getId() == null ) {
            throw new IllegalStateException( "Builder is invalid since the CallID is null!" );
         }
         return new CallSummary( this );
      }
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (o == null || getClass() != o.getClass()) {
         return false;
      }
      CallSummary that = (CallSummary) o;
      return Objects.equals(id, that.id) &&
              Objects.equals(getName(), that.getName()) &&
              Objects.equals(aEnd, that.aEnd) &&
              Objects.equals(zEnd, that.zEnd) &&
              Objects.equals(getOperStatus(), that.getOperStatus());
   }

   @Override
   public int hashCode() {
      return Objects.hash(id, getName(), aEnd, zEnd, getOperStatus());
   }
}