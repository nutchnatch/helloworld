package com.ossnms.web.provider.sdn.operations.edge;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.sdn.model.edge.Edge;
import com.ossnms.web.provider.sdn.model.edge.EdgeField;
import com.ossnms.web.provider.sdn.model.edge.EdgeID;
import com.ossnms.web.provider.sdn.model.edge.EdgeSummary;

/**
 *
 */
public interface EdgeEntityOperations extends EntityOperations<EdgeID, Edge, EdgeSummary, EdgeField> {
}
