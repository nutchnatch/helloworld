package com.ossnms.web.provider.sdn.model.topology;

/**
 *
 */
public enum TopologyField {
}
