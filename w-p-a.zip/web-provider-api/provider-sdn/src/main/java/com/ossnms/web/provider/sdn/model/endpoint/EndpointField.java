package com.ossnms.web.provider.sdn.model.endpoint;

/**
 *
 */
public enum EndpointField {
}
