package com.ossnms.web.provider.sdn.model.link;

/**
 *
 */
public enum LinkField {
}
