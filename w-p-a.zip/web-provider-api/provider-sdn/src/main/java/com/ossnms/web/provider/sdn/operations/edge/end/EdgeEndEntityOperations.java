package com.ossnms.web.provider.sdn.operations.edge.end;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEnd;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndField;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndID;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndSummary;

/**
 *
 */
public interface EdgeEndEntityOperations extends EntityOperations<EdgeEndID, EdgeEnd, EdgeEndSummary, EdgeEndField> {
}
