package com.ossnms.web.provider.sdn.model.common.attributes;

import com.ossnms.web.provider.common.api.model.EntityField;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointID;

import java.util.Objects;

/**
 *
 */
public class LayerAttribute implements EntityField<LayerAttribute> {

    private static final long serialVersionUID = -8692902462508878191L;

    private final int coriantLayerId;
    private final String coriantPortMode;
    private final int ietfGMPLSSwitchingType;
    private final int ietfGMPLSEncoding;
    private final int ietfASONSigType;
    private final int ietfASONAdaptation;
    private final long coriantMinBitrate;
    private final long coriantMaxBitrate;
    private final EndpointID coriantEndpoint;
    private final boolean coriantCurrentConfiguration;


    /**
     *
     * @param builder
     */
    private LayerAttribute(Builder builder) {
        this.coriantLayerId = builder.coriantLayerId;
        this.coriantPortMode = builder.coriantPortMode;
        this.ietfGMPLSSwitchingType = builder.ietfGMPLSSwitchingType;
        this.ietfGMPLSEncoding = builder.ietfGMPLSEncoding;
        this.ietfASONSigType = builder.ietfASONSigType;
        this.ietfASONAdaptation = builder.ietfASONAdaptation;
        this.coriantMinBitrate = builder.coriantMinBitrate;
        this.coriantMaxBitrate = builder.coriantMaxBitrate;
        this.coriantEndpoint = builder.coriantEndpoint;
        this.coriantCurrentConfiguration = builder.coriantCurrentConfiguration;
    }

    /**
     *
     * @return
     */
    public int getCoriantLayerId() {
        return coriantLayerId;
    }

    /**
     *
     * @return
     */
    public String getCoriantPortMode() {
        return coriantPortMode;
    }

    /**
     *
     * @return
     */
    public int getIetfGMPLSSwitchingType() {
        return ietfGMPLSSwitchingType;
    }

    /**
     *
     * @return
     */
    public int getIetfGMPLSEncoding() {
        return ietfGMPLSEncoding;
    }

    /**
     *
     * @return
     */
    public int getIetfASONSigType() {
        return ietfASONSigType;
    }

    /**
     *
     * @return
     */
    public int getIetfASONAdaptation() {
        return ietfASONAdaptation;
    }

    /**
     *
     * @return
     */
    public long getCoriantMinBitrate() {
        return coriantMinBitrate;
    }

    /**
     *
     * @return
     */
    public long getCoriantMaxBitrate() {
        return coriantMaxBitrate;
    }

    /**
     *
     * @return
     */
    public EndpointID getCoriantEndpoint() {
        return coriantEndpoint;
    }

    /**
     *
     * @return
     */
    public boolean isCoriantCurrentConfiguration() {
        return coriantCurrentConfiguration;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<LayerAttribute> {

        private int coriantLayerId;
        private String coriantPortMode;
        private int ietfGMPLSSwitchingType;
        private int ietfGMPLSEncoding;
        private int ietfASONSigType;
        private int ietfASONAdaptation;
        private long coriantMinBitrate;
        private long coriantMaxBitrate;
        private EndpointID coriantEndpoint;
        private boolean coriantCurrentConfiguration;

        /**
         *
         * @param coriantLayerId
         * @return
         */
        public Builder setCoriantLayerId(int coriantLayerId) {
            this.coriantLayerId = coriantLayerId;
            return this;
        }

        /**
         *
         * @param coriantPortMode
         * @return
         */
        public Builder setCoriantPortMode(String coriantPortMode) {
            this.coriantPortMode = coriantPortMode;
            return this;
        }

        /**
         *
         * @param ietfGMPLSSwitchingType
         * @return
         */
        public Builder setIetfGMPLSSwitchingType(int ietfGMPLSSwitchingType) {
            this.ietfGMPLSSwitchingType = ietfGMPLSSwitchingType;
            return this;
        }

        /**
         *
         * @param ietfGMPLSEncoding
         * @return
         */
        public Builder setIetfGMPLSEncoding(int ietfGMPLSEncoding) {
            this.ietfGMPLSEncoding = ietfGMPLSEncoding;
            return this;
        }

        /**
         *
         * @param ietfASONSigType
         * @return
         */
        public Builder setIetfASONSigType(int ietfASONSigType) {
            this.ietfASONSigType = ietfASONSigType;
            return this;
        }

        /**
         *
         * @param ietfASONAdaptation
         * @return
         */
        public Builder setIetfASONAdaptation(int ietfASONAdaptation) {
            this.ietfASONAdaptation = ietfASONAdaptation;
            return this;
        }

        /**
         *
         * @param coriantMinBitrate
         * @return
         */
        public Builder setCoriantMinBitrate(long coriantMinBitrate) {
            this.coriantMinBitrate = coriantMinBitrate;
            return this;
        }

        /**
         *
         * @param coriantMaxBitrate
         * @return
         */
        public Builder setCoriantMaxBitrate(long coriantMaxBitrate) {
            this.coriantMaxBitrate = coriantMaxBitrate;
            return this;
        }

        /**
         *
         * @param coriantEndpoint
         * @return
         */
        public Builder setCoriantEndpoint(EndpointID coriantEndpoint) {
            this.coriantEndpoint = coriantEndpoint;
            return this;
        }

        /**
         *
         * @param coriantCurrentConfiguration
         * @return
         */
        public Builder setCoriantCurrentConfiguration(boolean coriantCurrentConfiguration) {
            this.coriantCurrentConfiguration = coriantCurrentConfiguration;
            return this;
        }

        @Override
        public LayerAttribute build() {
            return new LayerAttribute(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        LayerAttribute that = (LayerAttribute) o;
        return getCoriantLayerId() == that.getCoriantLayerId() &&
                getIetfGMPLSSwitchingType() == that.getIetfGMPLSSwitchingType() &&
                getIetfGMPLSEncoding() == that.getIetfGMPLSEncoding() &&
                getIetfASONSigType() == that.getIetfASONSigType() &&
                getIetfASONAdaptation() == that.getIetfASONAdaptation() &&
                getCoriantMinBitrate() == that.getCoriantMinBitrate() &&
                getCoriantMaxBitrate() == that.getCoriantMaxBitrate() &&
                isCoriantCurrentConfiguration() == that.isCoriantCurrentConfiguration() &&
                Objects.equals(getCoriantPortMode(), that.getCoriantPortMode()) &&
                Objects.equals(getCoriantEndpoint(), that.getCoriantEndpoint());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCoriantLayerId(), getCoriantPortMode(), getIetfGMPLSSwitchingType(), getIetfGMPLSEncoding(), getIetfASONSigType(), getIetfASONAdaptation(), getCoriantMinBitrate(), getCoriantMaxBitrate(), getCoriantEndpoint(), isCoriantCurrentConfiguration());
    }
}
