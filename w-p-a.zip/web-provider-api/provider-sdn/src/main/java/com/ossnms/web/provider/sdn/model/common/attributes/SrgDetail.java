package com.ossnms.web.provider.sdn.model.common.attributes;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public class SrgDetail implements Serializable {

   private static final long serialVersionUID = 837043490087933677L;

   private final String riskClass;
   private final String riskStartTime;
   private final String riskStopTime;
   private final List<Risk> risks;

   /**
    * @param builder
    */
   private SrgDetail( Builder builder ) {

      this.riskClass = builder.riskClass;
      this.riskStopTime = builder.riskStopTime;
      this.riskStartTime = builder.riskStartTime;
      this.risks = builder.risks;
   }

   /**
    * @return the risk class, of type {@link String}
    */
   public String getRiskClass() {

      return riskClass;
   }

   /**
    * @return the risk start time class, of type {@link String}
    */
   public String getRiskStartTime() {

      return riskStartTime;
   }

   /**
    * @return the risk stop time class, of type {@link String}
    */
   public String getRiskStopTime() {

      return riskStopTime;
   }

   /**
    * @return the list of risks, of type {@link Risk}
    */
   public List<Risk> getRisks() {

      return risks;
   }

   /**
    *
    */
   public static class Builder implements ObjectBuilder<SrgDetail> {

      private String riskClass;
      private String riskStopTime;
      private String riskStartTime;
      private List<Risk> risks;

      public Builder() {

         risks = new ArrayList<>();
      }

      /**
       * @param riskClass
       * @return
       */
      public Builder setRiskClass( String riskClass ) {

         this.riskClass = riskClass;
         return this;
      }

      /**
       * @param riskStopTime
       * @return
       */
      public Builder setRiskStopTime( String riskStopTime ) {

         this.riskStopTime = riskStopTime;
         return this;
      }

      /**
       * @param riskStartTime
       * @return
       */
      public Builder setRiskStartTime( String riskStartTime ) {

         this.riskStartTime = riskStartTime;
         return this;
      }

      /**
       * @param risk
       * @return
       */
      public Builder addRisk( Risk risk ) {

         this.risks.add( risk );
         return this;
      }

      /**
       * @param risks
       * @return
       */
      public Builder addRisks( List<Risk> risks ) {

         this.risks.addAll( risks );
         return this;
      }

      /**
       * @return
       */
      @Override
      public SrgDetail build() {

         return new SrgDetail( this );
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      SrgDetail srgDetail = (SrgDetail) o;
      return Objects.equals( getRiskClass(), srgDetail.getRiskClass() ) &&
             Objects.equals( getRiskStartTime(), srgDetail.getRiskStartTime() ) &&
             Objects.equals( getRiskStopTime(), srgDetail.getRiskStopTime() ) &&
             Objects.equals( getRisks(), srgDetail.getRisks() );
   }

   @Override
   public int hashCode() {

      return Objects.hash( getRiskClass(), getRiskStartTime(), getRiskStopTime(), getRisks() );
   }
}
