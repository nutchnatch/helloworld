package com.ossnms.web.provider.sdn.model.edge;

/**
 *
 */
public enum EdgeField {
}
