package com.ossnms.web.provider.sdn.model.network;

import com.ossnms.web.provider.common.api.model.EntitySummary;

import java.util.Arrays;
import java.util.Objects;

/**
 *
 */
public class NetworkSummary implements EntitySummary<NetworkID> {

    private static final long serialVersionUID = -281499310573199589L;

    private final NetworkID id;

    private final String name;

    private final String[] protocols;

    private final String topologyType;

    /**
     * @param builder
     */
    protected NetworkSummary(NetworkSummaryPrototype<?> builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.protocols = builder.protocols != null ? Arrays.copyOf(builder.protocols, builder.protocols.length) : null;
        this.topologyType = builder.topologyType;
    }

    /**
     * Returns an instance of {@link NetworkID} representing an identifier
     *
     * @return the identifier
     */
    @Override
    public NetworkID getID() {
        return this.id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @return
     */
    public String[] getProtocols() {
        return protocols;
    }

    /**
     *
     * @return
     */
    public String getTopologyType() {
        return topologyType;
    }

    /**
     *
     */
    public static class Builder extends NetworkSummaryPrototype<Builder>  {

        public Builder(NetworkID id) {
            super(id);
        }

        @Override
        protected Builder self() {
            return this;
        }

        public NetworkSummary build() {
            if(this.getId() == null){
                throw new IllegalStateException("Builder is invalid since the NetworkID is null");
            }

            return new NetworkSummary(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        NetworkSummary that = (NetworkSummary) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(name, that.name) &&
                Arrays.equals(protocols, that.protocols) &&
                Objects.equals(topologyType, that.topologyType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, protocols, topologyType);
    }
}
