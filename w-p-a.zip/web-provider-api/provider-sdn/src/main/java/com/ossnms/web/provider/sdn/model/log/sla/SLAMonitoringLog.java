package com.ossnms.web.provider.sdn.model.log.sla;

import com.ossnms.web.provider.common.api.model.Entity;

/**
 *
 */
public final class SLAMonitoringLog extends SLAMonitoringLogSummary implements Entity<SLAMonitoringLogID> {

    private static final long serialVersionUID = -5185280422846262486L;

    /**
     * @param builder
     */
    private SLAMonitoringLog(Builder builder) {
        super(builder);
    }

    /**
     *
     */
    public static class Builder extends SLAMonitoringLogSummary.Builder {
        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(SLAMonitoringLogID id) {
            super(id);
        }

        /**
         * Overriden method to build a {@link SLAMonitoringLog} instance
         *
         * @return a {@link SLAMonitoringLog} instance, if every mandatory field was correctly filled
         */
        @Override
        public SLAMonitoringLog build() {
            return new SLAMonitoringLog(this);
        }
    }
}
