package com.ossnms.web.provider.sdn.model.log.sla;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 * {@link SLAMonitoringLogID}
 */
public final class SLAMonitoringLogID implements EntityID {

    private static final long serialVersionUID = 4128390037909683457L;

    private final String id;

    /**
     *
     */
    public String getID() {
        return id;
    }

    /**
     * Private builder constructor
     *
     * @param builder the builder
     */
    private SLAMonitoringLogID(Builder builder) {
        this.id = builder.id;
    }

    /**
     * Builder of {@link SLAMonitoringLogID} instances
     */
    public static class Builder implements ObjectBuilder<SLAMonitoringLogID> {

        private String id;

        /**
         * Builder constructor
         *
         * @param id the id parameter
         */
        public Builder(String id) {
            this.id = id;
        }

        /**
         * Builds the object
         *
         * @return instance of {@link SLAMonitoringLogID}
         */
        @Override
        public SLAMonitoringLogID build() {
            return new SLAMonitoringLogID(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        SLAMonitoringLogID that = (SLAMonitoringLogID) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}