package com.ossnms.web.provider.sdn.model.topology;

import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.sdn.model.edge.Edge;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEnd;
import com.ossnms.web.provider.sdn.model.vertex.Vertex;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * For the requested topology contains the entire information of objects
 */
public final class Topology extends TopologySummary implements Entity<TopologyID> {

    private static final long serialVersionUID = -5687842462746556797L;

    private final List<Vertex> vertices;

    private final List<EdgeEnd> ends;

    private final List<Edge> edges;

    /**
     * @param builder
     */
    private Topology(Builder builder) {
        super(builder);
        this.edges = builder.edges;
        this.ends = builder.ends;
        this.vertices = builder.vertices;
    }

    /**
     *
     * @return
     */
    public List<Vertex> getVertices() {
        return vertices;
    }

    /**
     *
     * @return
     */
    public List<EdgeEnd> getEnds() {
        return ends;
    }

    /**
     * @return
     */
    public List<Edge> getEdges() {
        return edges;
    }

    /**
     *
     */
    public static class Builder extends TopologySummary.Builder {
        private List<Edge> edges;
        private List<EdgeEnd> ends;
        private List<Vertex> vertices;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(TopologyID id) {
            super(id);

            edges = new ArrayList<>();
            ends = new ArrayList<>();
            vertices = new ArrayList<>();
        }

        /**
         *
         * @param edge
         * @return
         */
        public Builder addEdge(Edge edge) {
            this.edges.add(edge);
            return this;
        }

        /**
         *
         * @param end
         * @return
         */
        public Builder addEnd(EdgeEnd end) {
            this.ends.add(end);
            return this;
        }

        /**
         *
         * @param vertex
         * @return
         */
        public Builder addVertex(Vertex vertex) {
            this.vertices.add(vertex);
            return this;
        }

        /**
         *
         * @param edges
         * @return
         */
        public Builder addEdges(List<Edge> edges) {
            this.edges.addAll(edges);
            return this;
        }

        /**
         *
         * @param ends
         * @return
         */
        public Builder addEnds(List<EdgeEnd> ends) {
            this.ends.addAll(ends);
            return this;
        }

        /**
         *
         * @param vertices
         * @return
         */
        public Builder addVertices(List<Vertex> vertices) {
            this.vertices.addAll(vertices);
            return this;
        }

        /**
         * Overriden method to build a {@link Topology} instance
         *
         * @return a {@link Topology} instance, if every mandatory field was correctly filled
         */
        @Override
        public Topology build() {
            return new Topology(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        if (!super.equals(o)) { return false; }
        Topology topology = (Topology) o;
        return Objects.equals(getVertices(), topology.getVertices()) &&
                Objects.equals(getEnds(), topology.getEnds()) &&
                Objects.equals(getEdges(), topology.getEdges());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getVertices(), getEnds(), getEdges());
    }
}
