package com.ossnms.web.provider.sdn.model.edge.end;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 * {@link EdgeEndID}
 */
public final class EdgeEndID implements EntityID {

    private static final long serialVersionUID = 4128390037909683457L;

    private final String domainId;
    private final String vertexId;
    private final String id;

    /**
     *
     * @return
     */
    public String getDomainId() {

        return domainId;
    }

    /**
     *
     * @return
     */
    public String getVertexId() {

        return vertexId;
    }

    /**
     *
     * @return
     */
    public String getID() {
        return id;
    }

    /**
     * Private builder constructor
     *
     * @param builder the builder
     */
    private EdgeEndID( Builder builder ) {

        this.domainId = builder.domainId;
        this.vertexId = builder.vertexId;
        this.id = builder.id;
    }

    /**
     * Builder of {@link EdgeEndID} instances
     */
    public static class Builder implements ObjectBuilder<EdgeEndID> {

        private String domainId;
        private String vertexId;
        private String id;

        /**
         * Builder constructor
         *
         * @param domainId
         * @param vertexId
         * @param id
         */
        public Builder( String domainId, String vertexId, String id ) {

            this.domainId = domainId;
            this.vertexId = vertexId;
            this.id = id;
        }

        /**
         * Builds the object
         *
         * @return instance of {@link EdgeEndID}
         */
        @Override
        public EdgeEndID build() {
            return new EdgeEndID(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        EdgeEndID edgeEndID = (EdgeEndID) o;
        return Objects.equals( this.domainId, edgeEndID.domainId )
            && Objects.equals( this.vertexId, edgeEndID.vertexId )
            && Objects.equals( this.id, edgeEndID.id );
    }

    @Override
    public int hashCode() { return Objects.hash( this.domainId, this.vertexId, this.id ); }
}