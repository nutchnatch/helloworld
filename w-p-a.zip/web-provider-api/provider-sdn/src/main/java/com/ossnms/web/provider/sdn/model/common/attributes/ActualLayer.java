package com.ossnms.web.provider.sdn.model.common.attributes;

import com.ossnms.web.provider.common.api.model.EntityField;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class ActualLayer implements EntityField<ActualLayer> {

    private static final long serialVersionUID = -8728695151088155166L;

    private final int coriantLayerId;
    private final long coriantMinBitrate;
    private final long coriantMaxBitrate;

    /**
     *
     * @param builder
     */
    private ActualLayer(Builder builder) {
        this.coriantLayerId = builder.coriantLayerId;
        this.coriantMinBitrate = builder.coriantMinBitrate;
        this.coriantMaxBitrate = builder.coriantMaxBitrate;
    }

    /**
     *
     * @return
     */
    public int getCoriantLayerId() {
        return coriantLayerId;
    }

    /**
     *
     * @return
     */
    public long getCoriantMinBitrate() {
        return coriantMinBitrate;
    }

    /**
     *
     * @return
     */
    public long getCoriantMaxBitrate() {
        return coriantMaxBitrate;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<ActualLayer> {

        private int coriantLayerId;
        private long coriantMinBitrate;
        private long coriantMaxBitrate;

        /**
         *
         * @param coriantLayerId
         * @return
         */
        public Builder setCoriantLayerId(int coriantLayerId) {
            this.coriantLayerId = coriantLayerId;
            return this;
        }

        /**
         *
         * @param coriantMinBitrate
         * @return
         */
        public Builder setCoriantMinBitrate(long coriantMinBitrate) {
            this.coriantMinBitrate = coriantMinBitrate;
            return this;
        }

        /**
         *
         * @param coriantMaxBitrate
         * @return
         */
        public Builder setCoriantMaxBitrate(long coriantMaxBitrate) {
            this.coriantMaxBitrate = coriantMaxBitrate;
            return this;
        }

        @Override
        public ActualLayer build() {
            return new ActualLayer(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        ActualLayer that = (ActualLayer) o;
        return getCoriantLayerId() == that.getCoriantLayerId() &&
                getCoriantMinBitrate() == that.getCoriantMinBitrate() &&
                getCoriantMaxBitrate() == that.getCoriantMaxBitrate();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCoriantLayerId(), getCoriantMinBitrate(), getCoriantMaxBitrate());
    }
}
