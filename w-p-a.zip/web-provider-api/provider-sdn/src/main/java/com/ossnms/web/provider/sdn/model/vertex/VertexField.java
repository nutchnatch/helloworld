package com.ossnms.web.provider.sdn.model.vertex;

/**
 *
 */
public enum VertexField {
}
