package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.sdn.model.common.attributes.SrgDetail;
import com.ossnms.web.provider.sdn.model.common.attributes.TrafficParam;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndSummary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public class Connection implements Serializable {

   private static final long serialVersionUID = 8963286899256846487L;

   private ConnectionID id;
   private String name;
   private EdgeEndSummary aEnd;
   private EdgeEndSummary zEnd;

   private TrafficParam trafficParam;

   private String adminStatus;
   private String operStatus;
   private String provisioningStatus;
   private String networkSyncStatus;

   private Integer switchingType;
   private Integer encoding;
   private String directionality;

   private Long frequency;
   private Long freqSlotWidth;

   private ConnectionTopoComponent topoComponent;

   private List<SrgDetail> srgDetails;


   private Connection( Builder builder ) {

      this.id = builder.id;
      this.name = builder.name;
      this.aEnd = builder.aEnd;
      this.zEnd = builder.zEnd;
      this.adminStatus = builder.adminStatus;
      this.trafficParam = builder.trafficParam;
      this.directionality = builder.directionality;
      this.provisioningStatus = builder.provisioningStatus;
      this.frequency = builder.frequency;
      this.topoComponent = builder.topoComponent;
      this.switchingType = builder.switchingType;
      this.operStatus = builder.operStatus;
      this.networkSyncStatus = builder.networkSyncStatus;
      this.freqSlotWidth = builder.freqSlotWidth;
      this.srgDetails = builder.srgDetails;
      this.encoding = builder.encoding;
   }


   public ConnectionID getID() {

      return id;
   }

   public String getName() {

      return name;
   }

   public EdgeEndSummary getAEnd() {

      return aEnd;
   }

   public EdgeEndSummary getZEnd() {

      return zEnd;
   }

   public TrafficParam getTrafficParam() {

      return trafficParam;
   }

   public String getAdminStatus() {

      return adminStatus;
   }

   public String getOperStatus() {

      return operStatus;
   }

   public String getProvisioningStatus() {

      return provisioningStatus;
   }

   public String getNetworkSyncStatus() {

      return networkSyncStatus;
   }

   public Integer getSwitchingType() {

      return switchingType;
   }

   public Integer getEncoding() {

      return encoding;
   }

   public String getDirectionality() {

      return directionality;
   }

   public Long getFrequency() {

      return frequency;
   }

   public Long getFreqSlotWidth() {

      return freqSlotWidth;
   }

   public ConnectionTopoComponent getTopoComponent() {

      return topoComponent;
   }

   public List<SrgDetail> getSrgDetails() {

      return srgDetails;
   }

   public static final class Builder {

      private ConnectionID id;
      private String name;
      private EdgeEndSummary aEnd;
      private EdgeEndSummary zEnd;
      private TrafficParam trafficParam;
      private String adminStatus;
      private String operStatus;
      private String provisioningStatus;
      private String networkSyncStatus;
      private Integer switchingType;
      private Integer encoding;
      private String directionality;
      private Long frequency;
      private Long freqSlotWidth;
      private ConnectionTopoComponent topoComponent;
      private List<SrgDetail> srgDetails;


      public Builder( ConnectionID connectionId ) {

         this.id = connectionId;
         this.srgDetails = new ArrayList<>();
      }

      public Builder setName( String name ) {

         this.name = name;
         return this;
      }

      public Builder setAEnd( EdgeEndSummary aEnd ) {

         this.aEnd = aEnd;
         return this;
      }

      public Builder setZEnd( EdgeEndSummary zEnd ) {

         this.zEnd = zEnd;
         return this;
      }

      public Builder setTrafficParam( TrafficParam trafficParam ) {

         this.trafficParam = trafficParam;
         return this;
      }

      public Builder setAdminStatus( String adminStatus ) {

         this.adminStatus = adminStatus;
         return this;
      }

      public Builder setOperStatus( String operStatus ) {

         this.operStatus = operStatus;
         return this;
      }

      public Builder setProvisioningStatus( String provisioningStatus ) {

         this.provisioningStatus = provisioningStatus;
         return this;
      }

      public Builder setNetworkSyncStatus( String networkSyncStatus ) {

         this.networkSyncStatus = networkSyncStatus;
         return this;
      }

      public Builder setSwitchingType( Integer switchingType ) {

         this.switchingType = switchingType;
         return this;
      }

      public Builder setEncoding( Integer encoding ) {

         this.encoding = encoding;
         return this;
      }

      public Builder setDirectionality( String directionality ) {

         this.directionality = directionality;
         return this;
      }

      public Builder setFrequency( Long frequency ) {

         this.frequency = frequency;
         return this;
      }

      public Builder setFreqSlotWidth( Long freqSlotWidth ) {

         this.freqSlotWidth = freqSlotWidth;
         return this;
      }

      public Builder setTopoComponent( ConnectionTopoComponent topoComponent ) {

         this.topoComponent = topoComponent;
         return this;
      }

      public Builder addSrgDetails( List<SrgDetail> srgDetails ) {

         this.srgDetails.addAll( srgDetails );
         return this;
      }

      public Connection build() {

         return new Connection( this );
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      Connection that = (Connection) o;
      return Objects.equals( id, that.id ) &&
             Objects.equals( name, that.name ) &&
             Objects.equals( aEnd, that.aEnd ) &&
             Objects.equals( zEnd, that.zEnd ) &&
             Objects.equals( trafficParam, that.trafficParam ) &&
             Objects.equals( adminStatus, that.adminStatus ) &&
             Objects.equals( operStatus, that.operStatus ) &&
             Objects.equals( provisioningStatus, that.provisioningStatus ) &&
             Objects.equals( networkSyncStatus, that.networkSyncStatus ) &&
             Objects.equals( switchingType, that.switchingType ) &&
             Objects.equals( encoding, that.encoding ) &&
             Objects.equals( directionality, that.directionality ) &&
             Objects.equals( frequency, that.frequency ) &&
             Objects.equals( freqSlotWidth, that.freqSlotWidth ) &&
             Objects.equals( topoComponent, that.topoComponent ) &&
             Objects.equals( srgDetails, that.srgDetails );
   }

   @Override
   public int hashCode() {

      return Objects.hash( id, name, aEnd, zEnd, trafficParam, adminStatus, operStatus, provisioningStatus, networkSyncStatus, switchingType, encoding, directionality, frequency, freqSlotWidth, topoComponent, srgDetails );
   }
}