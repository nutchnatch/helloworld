package com.ossnms.web.provider.sdn.operations.network;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkField;
import com.ossnms.web.provider.sdn.model.network.NetworkID;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;

/**
 *
 */
public interface NetworkEntityOperations extends EntityOperations<NetworkID, Network, NetworkSummary, NetworkField> {
}
