package com.ossnms.web.provider.sdn.model.network;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Arrays;

/**
 *
 */
public abstract class NetworkSummaryPrototype<E extends NetworkSummaryPrototype<E>> implements ObjectBuilder<NetworkSummary> {

    protected NetworkID id;
    protected String name;
    protected String[] protocols;
    protected String topologyType;

    /**
     * Builder constructor
     *
     * @param id mandatory field, id
     */
    public NetworkSummaryPrototype(NetworkID id) {
        this.id = id;
    }

    /**
     *
     * @param name
     * @return
     */
    public E setName(String name) {
        this.name = name;
        return self();
    }

    /**
     *
     * @param protocols
     * @return
     */
    public E setProtocols(String[] protocols) {
        // store a copy of the array and not the array itself
        this.protocols = protocols != null ? Arrays.copyOf(protocols, protocols.length) : null;
        return self();
    }

    /**
     *
     * @param topologyType
     * @return
     */
    public E setTopologyType(String topologyType) {
        this.topologyType = topologyType;
        return self();
    }

    public NetworkID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String[] getProtocols() {
        return protocols;
    }

    public String getTopologyType() {
        return topologyType;
    }


    /**
     *
     * @return
     */
    protected abstract E self();
}
