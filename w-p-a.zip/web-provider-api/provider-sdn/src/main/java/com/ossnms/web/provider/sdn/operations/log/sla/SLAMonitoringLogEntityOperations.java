package com.ossnms.web.provider.sdn.operations.log.sla;

import com.ossnms.web.provider.common.api.facade.ReadEntityOperations;
import com.ossnms.web.provider.sdn.model.log.sla.SLAMonitoringLog;
import com.ossnms.web.provider.sdn.model.log.sla.SLAMonitoringLogField;
import com.ossnms.web.provider.sdn.model.log.sla.SLAMonitoringLogID;
import com.ossnms.web.provider.sdn.model.log.sla.SLAMonitoringLogSummary;

/**
 *
 */
public interface SLAMonitoringLogEntityOperations
        extends ReadEntityOperations<SLAMonitoringLogID, SLAMonitoringLog, SLAMonitoringLogSummary, SLAMonitoringLogField> {
}
