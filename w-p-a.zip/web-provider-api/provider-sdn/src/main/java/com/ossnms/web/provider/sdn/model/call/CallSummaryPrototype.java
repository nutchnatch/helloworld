package com.ossnms.web.provider.sdn.model.call;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.sdn.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;

/**
 *
 */
public abstract class CallSummaryPrototype<E extends CallSummaryPrototype<E>> implements ObjectBuilder<CallSummary> {

    private CallID id;
    private String name;
    private EndpointSummary aEnd;
    private EndpointSummary zEnd;
    private String operStatus;

    /**
     * Builder constructor
     *
     * @param id mandatory field, id
     */
    protected CallSummaryPrototype( CallID id ) {
        this.id = id;
    }

    public CallID getId() {
        return id;
    }

    public CallSummaryPrototype setName( String name ) {
        this.name = name;
        return this;
    }

    public CallSummaryPrototype setAEnd(EndpointSummary aEnd) {
        this.aEnd = aEnd;
        return this;
    }

    public CallSummaryPrototype setZEnd(EndpointSummary zEnd) {
        this.zEnd = zEnd;
        return this;
    }

    public CallSummaryPrototype setOperStatus( String operStatus ) {
        this.operStatus = operStatus;
        return this;
    }

    /**
     *
     */
    protected String getName() {
        return name;
    }

    /**
     *
     */
    protected EndpointSummary getAEnd() {
        return aEnd;
    }

    /**
     *
     */
    protected EndpointSummary getZEnd() {
        return zEnd;
    }

    /**
     *
     */
    protected String getOperStatus() {
        return operStatus;
    }

    /**
     *
     * @return
     */
    protected abstract E self();
}
