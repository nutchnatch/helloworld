package com.ossnms.web.provider.sdn.model.endpoint;

import com.ossnms.web.provider.common.api.model.Entity;

/**
 *
 */
public final class Endpoint extends EndpointSummary implements Entity<EndpointID> {

    private static final long serialVersionUID = -8513691180322180428L;

    /**
     * @param builder
     */
    private Endpoint(Builder builder) {
        super(builder);
    }

    /**
     *
     */
    public static class Builder extends EndpointSummary.Builder {
        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(EndpointID id) {
            super(id);
        }

        /**
         * Overriden method to build a {@link Endpoint} instance
         *
         * @return a {@link Endpoint} instance, if every mandatory field was correctly filled
         */
        @Override
        public Endpoint build() {
            return new Endpoint(this);
        }
    }
}
