package com.ossnms.web.provider.sdn.model.common.attributes;

import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.io.Serializable;
import java.util.Objects;


public class TrafficParam implements Serializable {

   private static final long serialVersionUID = -8088688338997393022L;

   private final String sigType;
   private final String multiplier;
   private final String bandwidth;


   private TrafficParam( Builder builder ) {

      this.sigType = builder.sigType;
      this.multiplier = builder.multiplier;
      this.bandwidth = builder.bandwidth;
   }

   public String getSigType() {

      return sigType;
   }

   public String getMultiplier() {

      return multiplier;
   }

   public String getBandwidth() {

      return bandwidth;
   }

   public static final class Builder implements ObjectBuilder<TrafficParam> {

      private String sigType;
      private String multiplier;
      private String bandwidth;

      public Builder setSigType( String sigType ) {

         this.sigType = sigType;
         return this;
      }

      public Builder setMultiplier( String multiplier ) {

         this.multiplier = multiplier;
         return this;
      }

      public Builder setBandwidth( String bandwidth ) {

         this.bandwidth = bandwidth;
         return this;
      }

      @Override
      public TrafficParam build() {

         return new TrafficParam( this );
      }
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      TrafficParam that = (TrafficParam) o;
      return Objects.equals( sigType, that.sigType ) &&
            Objects.equals( multiplier, that.multiplier ) &&
            Objects.equals( bandwidth, that.bandwidth );
   }

   @Override
   public int hashCode() {

      return Objects.hash( sigType, multiplier, bandwidth );
   }
}