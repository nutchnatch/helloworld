package com.ossnms.web.provider.sdn.model.network;

import com.ossnms.web.provider.common.api.model.Entity;

import java.util.Objects;

/**
 *
 */
public final class Network extends NetworkSummary implements Entity<NetworkID> {

    private static final long serialVersionUID = 8605666257201911978L;

    /**
     *
     */
    private final String userDomain;

    /**
     *
     */
    private final String adminState;

    /**
     *
     */
    private final Boolean secure;

    /**
     *
     */
    private final Boolean automaticServerTrailCreation;


    /**
     * @param builder
     */
    private Network(Builder builder) {
        super(builder);
        this.userDomain = builder.userDomain;
        this.adminState = builder.adminState;
        this.secure = builder.secure;
        this.automaticServerTrailCreation = builder.automaticServerTrailCreation;
    }


    /**
     * @return
     */
    public String getUserDomain() {
        return userDomain;
    }

    /**
     *
     * @return
     */
    public String getAdminState() {
        return adminState;
    }

    /**
     *
     * @return
     */
    public Boolean isSecure() {
        return secure;
    }

    /**
     *
     * @return
     */
    public Boolean isAutomaticServerTrailCreation() {
        return automaticServerTrailCreation;
    }

    /**
     *
     */
    public static class Builder extends NetworkSummaryPrototype<Builder> {

        /**
         *
         */
        private String userDomain;

        /**
         *
         */
        private String adminState;

        /**
         *
         */
        private Boolean secure;

        /**
         *
         */
        private Boolean automaticServerTrailCreation;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(NetworkID id) {
            super(id);
        }

        @Override
        protected Builder self() {
            return this;
        }

        /**
         *
         * @param userDomain
         * @return
         */
        public Builder setUserDomain(String userDomain) {
            this.userDomain = userDomain;
            return this;
        }

        /**
         *
         * @param adminState
         * @return
         */
        public Builder setAdminState(String adminState) {
            this.adminState = adminState;
            return this;
        }

        /**
         *
         * @param secure
         * @return
         */
        public Builder setSecure(Boolean secure) {
            this.secure = secure;
            return this;
        }

        /**
         *
         * @param automaticServerTrailCreation
         * @return
         */
        public Builder setAutomaticServerTrailCreation(Boolean automaticServerTrailCreation) {
            this.automaticServerTrailCreation = automaticServerTrailCreation;
            return this;
        }

        /**
         * Overriden method to build a {@link Network} instance
         *
         * @return a {@link Network} instance, if every mandatory field was correctly filled
         */
        @Override
        public Network build() {
            return new Network(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        if (!super.equals(o)){
            return false;
        }
        Network network = (Network) o;
        return Objects.equals(getUserDomain(), network.getUserDomain()) &&
                Objects.equals(getAdminState(), network.getAdminState()) &&
                Objects.equals(secure, network.secure) &&
                Objects.equals(automaticServerTrailCreation, network.automaticServerTrailCreation);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getUserDomain(), getAdminState(), secure, automaticServerTrailCreation);
    }
}

