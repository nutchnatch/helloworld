package com.ossnms.web.provider.sdn.model.endpoint;

import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 * {@link EndpointID}
 */
public final class EndpointID implements EntityID {

    private static final long serialVersionUID = 4128390037909683457L;

    private final String id;
    private final String domainId;

    /**
     *
     * @return
     */
    public String getID() {
        return this.id;
    }

    /**
     *
     * @return
     */
    public String getDomainId() {
        return this.domainId;
    }


    /**
     * Private builder constructor
     *
     * @param builder the builder
     */
    private EndpointID( Builder builder ) {

        this.id = builder.id;
        this.domainId = builder.domainId;
    }

    /**
     * Builder of {@link EndpointID} instances
     */
    public static class Builder implements ObjectBuilder<EndpointID> {

        private String id;
        private String domainId;

        /**
         * Builder constructor
         *
         * @param id the id parameter
         */
        public Builder( String domainId, String id ) {

            this.id = id;
            this.domainId = domainId;
        }

        /**
         * Builds the object
         *
         * @return instance of {@link EndpointID}
         */
        @Override
        public EndpointID build() {
            return new EndpointID(this);
        }
    }

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        EndpointID that = (EndpointID) o;
        return
              Objects.equals( this.id, that.id ) &&
              Objects.equals( this.domainId, that.domainId );
    }

    @Override
    public int hashCode() {

        return Objects.hash( this.id, this.domainId );
    }
}