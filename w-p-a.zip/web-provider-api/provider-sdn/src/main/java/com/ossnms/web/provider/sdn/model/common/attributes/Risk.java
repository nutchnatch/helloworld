package com.ossnms.web.provider.sdn.model.common.attributes;

import com.ossnms.web.provider.common.api.model.EntityField;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class Risk implements EntityField<Risk> {

    private static final long serialVersionUID = 8684612194163904050L;

    private final String domainId;
    private final String id;
    private final String name;

    /**
     * Private builder constructor
     * @param builder
     */
    private Risk(Risk.Builder builder) {

        this.domainId = builder.domainId;
        this.id = builder.id;
        this.name = builder.name;
    }

    /**
     *
     * @return
     */
    public String getDomainId() {

        return domainId;
    }

    /**
     *
     * @return
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<Risk> {

        private String domainId;
        private String id;
        private String name;

        /**
         *
         * @param domainId
         */
        public Builder setDomainId( String domainId ) {

            this.domainId = domainId;
            return this;
        }

        /**
         *
         * @param id
         * @return
         */
        public Builder setId( String id ) {
            this.id = id;
            return this;
        }

        /**
         *
         * @param name
         * @return
         */
        public Builder setName( String name ) {
            this.name = name;
            return this;
        }

        @Override
        public Risk build() {
            return new Risk(this);
        }
    }


    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        Risk risk = (Risk) o;
        return Objects.equals( domainId, risk.domainId ) &&
               Objects.equals( id, risk.id ) &&
               Objects.equals( name, risk.name );
    }

    @Override
    public int hashCode() {

        return Objects.hash( domainId, id, name );
    }
}