package com.ossnms.web.provider.sdn.model.endpoint;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndID;
import com.ossnms.web.provider.sdn.model.vertex.VertexSummary;

import java.util.Objects;

/**
 *
 */
public class EndpointSummary implements EntitySummary<EndpointID> {

    private static final long serialVersionUID = -1359834486753229141L;

    private final EndpointID id;
    private final String name;
    private final VertexSummary vertex;
    private final EdgeEndID edgeEndId;

    /**
     * @param builder
     */
    protected EndpointSummary(Builder builder) {
        this.id = builder.id;
        this.name = builder.name;
        this.vertex = builder.vertex;
        this.edgeEndId = builder.edgeEndId;
    }

    /**
     * Returns an instance of {@link EndpointID} representing an identifier
     *
     * @return the identifier
     */
    @Override
    public EndpointID getID() {
        return this.id;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    /**
     *
     */
    public VertexSummary getVertex() {
        return vertex;
    }

    /**
     *
     */
    public EdgeEndID getEdgeEndID() {

        return edgeEndId;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<EndpointSummary> {

        private EndpointID id;
        private VertexSummary vertex;
        private String name;
        private EdgeEndID edgeEndId;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(EndpointID id) {
            this.id = id;
        }

        /**
         *
         * @param vertex
         * @return
         */
        public Builder setVertex(VertexSummary vertex) {
            this.vertex = vertex;
            return this;
        }

        /**
         *
         * @param name
         * @return
         */
        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        /**
         *
         * @param edgeEndId
         * @return
         */
        public Builder setEdgeEndID( EdgeEndID edgeEndId ) {

            this.edgeEndId = edgeEndId;
            return this;
        }

        /**
         * Constructs an instance of {@link EndpointSummary}
         *
         * @return the object instance
         */
        @Override
        public EndpointSummary build() {
            return new EndpointSummary(this);
        }
    }

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        EndpointSummary that = (EndpointSummary) o;
        return Objects.equals( id, that.id ) &&
               Objects.equals( name, that.name ) &&
               Objects.equals( vertex, that.vertex ) &&
               Objects.equals( edgeEndId, that.edgeEndId );
    }

    @Override
    public int hashCode() {

        return Objects.hash( id, name, vertex, edgeEndId );
    }
}