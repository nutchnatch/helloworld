package com.ossnms.web.provider.sdn.operations.log.network;

import com.ossnms.web.provider.common.api.facade.ReadEntityOperations;
import com.ossnms.web.provider.sdn.model.log.network.NetworkDomainLog;
import com.ossnms.web.provider.sdn.model.log.network.NetworkDomainLogField;
import com.ossnms.web.provider.sdn.model.log.network.NetworkDomainLogID;
import com.ossnms.web.provider.sdn.model.log.network.NetworkDomainLogSummary;

/**
 *
 */
public interface NetworkDomainLogEntityOperations
        extends ReadEntityOperations<NetworkDomainLogID, NetworkDomainLog, NetworkDomainLogSummary, NetworkDomainLogField> {
}
