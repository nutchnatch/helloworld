package com.ossnms.web.provider.sdn.model.edge.end;

/**
 *
 */
public enum EdgeEndField {
}
