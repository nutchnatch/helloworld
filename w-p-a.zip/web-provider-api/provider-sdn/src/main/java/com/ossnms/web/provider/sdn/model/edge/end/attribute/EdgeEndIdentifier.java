package com.ossnms.web.provider.sdn.model.edge.end.attribute;

import com.ossnms.web.provider.common.api.model.EntityField;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class EdgeEndIdentifier implements EntityField<EdgeEndIdentifier> {

    private static final long serialVersionUID = 494752254801182970L;

    private final String coriantRack;
    private final String coriantShelf;
    private final String coriantSlot;
    private final String coriantSubslot;
    private final String coriantPort;
    private final String coriantAccessMode;
    private final String coriantAltRack;
    private final String coriantAltShelf;
    private final String coriantAltSlot;
    private final String coriantAltSubslot;
    private final String coriantAltPort;


    /**
     *
     * @param builder
     */
    private EdgeEndIdentifier(Builder builder) {
        this.coriantRack = builder.coriantRack;
        this.coriantShelf = builder.coriantShelf;
        this.coriantSlot = builder.coriantSlot;
        this.coriantSubslot = builder.coriantSubslot;
        this.coriantPort = builder.coriantPort;
        this.coriantAccessMode = builder.coriantAccessMode;
        this.coriantAltRack = builder.coriantAltRack;
        this.coriantAltShelf = builder.coriantAltShelf;
        this.coriantAltSlot = builder.coriantAltSlot;
        this.coriantAltSubslot = builder.coriantAltSubslot;
        this.coriantAltPort = builder.coriantAltPort;
    }

    /**
     *
     * @return
     */
    public String getCoriantRack() {
        return coriantRack;
    }

    /**
     *
     * @return
     */
    public String getCoriantShelf() {
        return coriantShelf;
    }

    /**
     *
     * @return
     */
    public String getCoriantSlot() {
        return coriantSlot;
    }

    /**
     *
     * @return
     */
    public String getCoriantSubslot() {
        return coriantSubslot;
    }

    /**
     *
     * @return
     */
    public String getCoriantPort() {
        return coriantPort;
    }

    /**
     *
     * @return
     */
    public String getCoriantAccessMode() {
        return coriantAccessMode;
    }

    /**
     *
     * @return
     */
    public String getCoriantAltRack() {
        return coriantAltRack;
    }

    /**
     *
     * @return
     */
    public String getCoriantAltShelf() {
        return coriantAltShelf;
    }

    /**
     *
     * @return
     */
    public String getCoriantAltSlot() {
        return coriantAltSlot;
    }

    /**
     *
     * @return
     */
    public String getCoriantAltSubslot() {
        return coriantAltSubslot;
    }

    /**
     *
     * @return
     */
    public String getCoriantAltPort() {
        return coriantAltPort;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<EdgeEndIdentifier> {

        private String coriantRack;
        private String coriantShelf;
        private String coriantSlot;
        private String coriantSubslot;
        private String coriantPort;
        private String coriantAccessMode;
        private String coriantAltRack;
        private String coriantAltShelf;
        private String coriantAltSlot;
        private String coriantAltSubslot;
        private String coriantAltPort;

        /**
         *
         * @param coriantRack
         * @return
         */
        public Builder setCoriantRack(String coriantRack) {
            this.coriantRack = coriantRack;
            return this;
        }

        /**
         *
         * @param coriantShelf
         * @return
         */
        public Builder setCoriantShelf(String coriantShelf) {
            this.coriantShelf = coriantShelf;
            return this;
        }

        /**
         *
         * @param coriantSlot
         * @return
         */
        public Builder setCoriantSlot(String coriantSlot) {
            this.coriantSlot = coriantSlot;
            return this;
        }

        /**
         *
         * @param coriantSubslot
         * @return
         */
        public Builder setCoriantSubslot(String coriantSubslot) {
            this.coriantSubslot = coriantSubslot;
            return this;
        }

        /**
         *
         * @param coriantPort
         * @return
         */
        public Builder setCoriantPort(String coriantPort) {
            this.coriantPort = coriantPort;
            return this;
        }

        /**
         *
         * @param coriantAccessMode
         * @return
         */
        public Builder setCoriantAccessMode(String coriantAccessMode) {
            this.coriantAccessMode = coriantAccessMode;
            return this;
        }

        /**
         *
         * @param coriantAltRack
         * @return
         */
        public Builder setCoriantAltRack(String coriantAltRack) {
            this.coriantAltRack = coriantAltRack;
            return this;
        }

        /**
         *
         * @param coriantAltShelf
         * @return
         */
        public Builder setCoriantAltShelf(String coriantAltShelf) {
            this.coriantAltShelf = coriantAltShelf;
            return this;
        }

        /**
         *
         * @param coriantAltSlot
         * @return
         */
        public Builder setCoriantAltSlot(String coriantAltSlot) {
            this.coriantAltSlot = coriantAltSlot;
            return this;
        }

        /**
         *
         * @param coriantAltSubslot
         * @return
         */
        public Builder setCoriantAltSubslot(String coriantAltSubslot) {
            this.coriantAltSubslot = coriantAltSubslot;
            return this;
        }

        /**
         *
         * @param coriantAltPort
         * @return
         */
        public Builder setCoriantAltPort(String coriantAltPort) {
            this.coriantAltPort = coriantAltPort;
            return this;
        }

        @Override
        public EdgeEndIdentifier build() {
            return new EdgeEndIdentifier(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        EdgeEndIdentifier that = (EdgeEndIdentifier) o;
        return Objects.equals(getCoriantRack(), that.getCoriantRack()) &&
                Objects.equals(getCoriantShelf(), that.getCoriantShelf()) &&
                Objects.equals(getCoriantSlot(), that.getCoriantSlot()) &&
                Objects.equals(getCoriantSubslot(), that.getCoriantSubslot()) &&
                Objects.equals(getCoriantPort(), that.getCoriantPort()) &&
                Objects.equals(getCoriantAccessMode(), that.getCoriantAccessMode()) &&
                Objects.equals(getCoriantAltRack(), that.getCoriantAltRack()) &&
                Objects.equals(getCoriantAltShelf(), that.getCoriantAltShelf()) &&
                Objects.equals(getCoriantAltSlot(), that.getCoriantAltSlot()) &&
                Objects.equals(getCoriantAltSubslot(), that.getCoriantAltSubslot()) &&
                Objects.equals(getCoriantAltPort(), that.getCoriantAltPort());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCoriantRack(), getCoriantShelf(), getCoriantSlot(), getCoriantSubslot(), getCoriantPort(), getCoriantAccessMode(), getCoriantAltRack(), getCoriantAltShelf(), getCoriantAltSlot(), getCoriantAltSubslot(), getCoriantAltPort());
    }
}
