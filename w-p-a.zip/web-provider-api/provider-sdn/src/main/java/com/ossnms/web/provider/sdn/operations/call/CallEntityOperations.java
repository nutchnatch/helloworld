package com.ossnms.web.provider.sdn.operations.call;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;

/**
 * {@inheritDoc}
 */
public interface CallEntityOperations extends EntityOperations<CallID,Call,CallSummary,CallField> {
}
