package com.ossnms.web.provider.sdn.operations.endpoint;

import com.ossnms.web.provider.common.api.facade.ProcessableResultEntityOperations;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.model.endpoint.Endpoint;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointField;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointID;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;

/**
 *
 */
public interface ProcessableEndpointEntityOperations
        extends ProcessableResultEntityOperations<EndpointID, Endpoint, EndpointSummary, EndpointField, ErrorCode> {
}