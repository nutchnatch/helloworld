package com.ossnms.web.provider.sdn.model.edge.end;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.sdn.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.sdn.model.common.enumerable.Ownership;
import com.ossnms.web.provider.sdn.model.vertex.VertexSummary;

import java.util.Objects;

/**
 *
 */
public class EdgeEndSummary implements EntitySummary<EdgeEndID> {

    private static final long serialVersionUID = -493890556445615037L;

    private final EdgeEndID id;
    private final String name;
    private final VertexSummary vertex;
    private final String operState;
    private final String ownership;


    /**
     * @param builder
     */
    protected EdgeEndSummary(Builder builder) {
        this.id = builder.id;

        this.operState = builder.operState;
        this.vertex = builder.vertex;
        this.name = builder.name;
        this.ownership = builder.ownership;
    }

    /**
     * Returns an instance of {@link EdgeEndID} representing an identifier
     *
     * @return the identifier
     */
    @Override
    public EdgeEndID getID() {
        return this.id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @return
     */
    public VertexSummary getVertex() {
        return vertex;
    }

    /**
     *
     * @return
     */
    public String getOperState() {

        return operState;
    }

    /**
     *
     * @return
     */
    public String getOwnership() {
        return ownership;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<EdgeEndSummary> {

        private EdgeEndID id;
        private VertexSummary vertex;
        private String name;
        private String operState;
        private String ownership;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(EdgeEndID id) {
            this.id = id;
        }


        public Builder setOperState( String operState ) {

            this.operState = operState;
            return this;
        }

        /**
         *
         * @param vertex
         * @return
         */
        public Builder setVertex(VertexSummary vertex) {
            this.vertex = vertex;
            return this;
        }

        /**
         *
         * @param name
         * @return
         */
        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        /**
         *
         * @param ownership
         * @return
         */
        public Builder setOwnership( String ownership ) {
            this.ownership = ownership;
            return this;
        }

        /**
         * Constructs an instance of {@link EdgeEndSummary}
         *
         * @return the object instance
         */
        @Override
        public EdgeEndSummary build() {
            return new EdgeEndSummary(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        EdgeEndSummary that = (EdgeEndSummary) o;
        return Objects.equals(getID(), that.getID()) &&
               Objects.equals(getName(), that.getName()) &&
               Objects.equals(getVertex(), that.getVertex()) &&
               Objects.equals(getOperState(), that.getOperState()) &&
               Objects.equals(getOwnership(), that.getOwnership());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getID(), getName(), getVertex(), getOperState(), getOwnership());
    }
}