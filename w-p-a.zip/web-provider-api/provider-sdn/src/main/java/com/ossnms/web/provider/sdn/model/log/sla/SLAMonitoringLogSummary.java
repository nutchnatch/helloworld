package com.ossnms.web.provider.sdn.model.log.sla;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;

import java.util.Objects;

/**
 *
 */
public class SLAMonitoringLogSummary implements EntitySummary<SLAMonitoringLogID> {

    private static final long serialVersionUID = -1359834486753229141L;

    private final SLAMonitoringLogID id;

    /**
     * @param builder
     */
    protected SLAMonitoringLogSummary(Builder builder) {
        this.id = builder.id;
    }

    /**
     * Returns an instance of {@link SLAMonitoringLogID} representing an identifier
     *
     * @return the identifier
     */
    @Override
    public SLAMonitoringLogID getID() {
        return this.id;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<SLAMonitoringLogSummary> {

        private SLAMonitoringLogID id;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(SLAMonitoringLogID id) {
            this.id = id;
        }

        /**
         * Constructs an instance of {@link SLAMonitoringLogSummary}
         *
         * @return the object instance
         */
        @Override
        public SLAMonitoringLogSummary build() {
            return new SLAMonitoringLogSummary(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        SLAMonitoringLogSummary that = (SLAMonitoringLogSummary) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
