package com.ossnms.web.provider.sdn.model.common.enumerable;

import static com.ossnms.web.provider.common.utils.EnumHelper.getValue;

/**
 *
 */
public enum OperationalState {

   UP( "up" ),
   DOWN( "down" ),
   UNKNOWN( "unknown" );

   private final String name;

   OperationalState( String name ) { this.name = name; }

   public String getName() { return name; }

   /**
    * Retrieves the enum value from a name
    *
    * @param name the name to search for
    * @return an instance of {@link OperationalState}; null if no match
    */
   public static OperationalState fromName( String name ) {

      return getValue(
            OperationalState.values(),
            candidate -> candidate.getName().equalsIgnoreCase( name )
      );
   }
}