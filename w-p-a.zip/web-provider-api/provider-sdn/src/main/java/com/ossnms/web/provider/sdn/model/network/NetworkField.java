package com.ossnms.web.provider.sdn.model.network;

/**
 *
 */
public enum NetworkField {
    NAME
}