package com.ossnms.web.provider.sdn.model.edge;

import com.ossnms.web.provider.common.api.model.EntitySummary;
import com.ossnms.web.provider.common.api.model.ObjectBuilder;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndSummary;

import java.util.Objects;

/**
 *
 */
public class EdgeSummary implements EntitySummary<EdgeID> {

    private static final long serialVersionUID = -1359834486753229141L;

    private final EdgeID id;

    private final String name;
    private final EdgeEndSummary aEnd;
    private final EdgeEndSummary zEnd;

    /**
     * @param builder
     */
    protected EdgeSummary(Builder builder) {
        this.id = builder.id;

       this.name = builder.name;
       this.aEnd = builder.aEnd;
       this.zEnd = builder.zEnd;
    }

    /**
     * Returns an instance of {@link EdgeID} representing an identifier
     *
     * @return the identifier
     */
    @Override
    public EdgeID getID() {
        return this.id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @return
     */
    public EdgeEndSummary getAEnd() { return aEnd; }

    /**
     *
     * @return
     */
    public EdgeEndSummary getZEnd() {
        return zEnd;
    }

    /**
     *
     */
    public static class Builder implements ObjectBuilder<EdgeSummary> {

        private EdgeID id;
        private String name;
        private EdgeEndSummary aEnd;
        private EdgeEndSummary zEnd;

        /**
         * Builder constructor
         *
         * @param id mandatory field, id
         */
        public Builder(EdgeID id) {
            this.id = id;
        }

        /**
         *
         * @param name
         * @return
         */
        public Builder setName(String name) {
            this.name = name;
            return this;
        }


        /**
         *
         * @param aEnd
         * @return
         */
        public Builder setAEnd( EdgeEndSummary aEnd) {
            this.aEnd = aEnd;
            return this;
        }

        /**
         *
         * @param zEnd
         * @return
         */
        public Builder setZEnd( EdgeEndSummary zEnd) {
            this.zEnd = zEnd;
            return this;
        }

        /**
         * Constructs an instance of {@link EdgeSummary}
         *
         * @return the object instance
         */
        @Override
        public EdgeSummary build() {
            return new EdgeSummary(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        EdgeSummary that = (EdgeSummary) o;
        return Objects.equals(id, that.id) &&
               Objects.equals(name, that.name) &&
               Objects.equals( aEnd, that.aEnd ) &&
               Objects.equals( zEnd, that.zEnd );
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, aEnd, zEnd );
    }
}