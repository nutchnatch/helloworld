package com.ossnms.web.provider.mef.service.operations;

import com.ossnms.web.provider.common.api.facade.ProcessableResultEntityOperations;
import com.ossnms.web.provider.mef.service.model.ErrorCode;
import com.ossnms.web.provider.mef.service.model.Service;
import com.ossnms.web.provider.mef.service.model.ServiceField;
import com.ossnms.web.provider.mef.service.model.ServiceID;
import com.ossnms.web.provider.mef.service.model.ServiceSummary;

public interface ServiceEntityOperations extends ProcessableResultEntityOperations<ServiceID, Service, ServiceSummary, ServiceField, ErrorCode>{
}
