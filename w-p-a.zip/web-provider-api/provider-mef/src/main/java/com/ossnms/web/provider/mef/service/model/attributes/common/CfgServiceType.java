package com.ossnms.web.provider.mef.service.model.attributes.common;

public enum CfgServiceType {
    POINT_TO_POINT("Point-to-Point"),
    MULTIPOINT_TO_MULTIPOINT("Multipoint-to-Multipoint"),
    ROOTED_MULTIPOINT("Rooted-Multipoint");

    private String value;

    CfgServiceType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
