package com.ossnms.web.provider.mef.service.model.attributes.common;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.mef.service.model.enumerable.BaseType;

import java.util.Objects;

public class ServiceTypeSetting implements EntityBase {

    private static final long serialVersionUID = -2899923555971073313L;

    private ServiceType serviceType;
    private BaseType baseType;


    public ServiceTypeSetting(ServiceType serviceType, BaseType baseType) {
        this.serviceType = serviceType;
        this.baseType = baseType;
    }

    public ServiceType getServiceType() {
        return serviceType;
    }

    public void setServiceType(ServiceType serviceType) {
        this.serviceType = serviceType;
    }

    public BaseType getBaseType() {
        return baseType;
    }

    public void setBaseType(BaseType baseType) {
        this.baseType = baseType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ServiceTypeSetting)) {
            return false;
        }
        ServiceTypeSetting that = (ServiceTypeSetting) o;
        return getServiceType() == that.getServiceType() &&
                getBaseType() == that.getBaseType();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getServiceType(), getBaseType());
    }
}
