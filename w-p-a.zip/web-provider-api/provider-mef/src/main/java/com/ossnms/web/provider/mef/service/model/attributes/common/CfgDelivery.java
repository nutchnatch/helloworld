package com.ossnms.web.provider.mef.service.model.attributes.common;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class CfgDelivery implements EntityBase {

    private static final long serialVersionUID = -7582455423875845689L;

    private CfgFrameDelivery evcCfgFrameDelivery;
    private FrameDeliveryCondition deliveryCondition;

    public CfgDelivery(CfgFrameDelivery evcCfgFrameDelivery, FrameDeliveryCondition deliveryCondition) {
        this.evcCfgFrameDelivery = evcCfgFrameDelivery;
        this.deliveryCondition = deliveryCondition;
    }

    public CfgFrameDelivery getEvcCfgFrameDelivery() {
        return evcCfgFrameDelivery;
    }

    public void setEvcCfgFrameDelivery(CfgFrameDelivery evcCfgFrameDelivery) {
        this.evcCfgFrameDelivery = evcCfgFrameDelivery;
    }

    public FrameDeliveryCondition getDeliveryCondition() {
        return deliveryCondition;
    }

    public void setDeliveryCondition(FrameDeliveryCondition deliveryCondition) {
        this.deliveryCondition = deliveryCondition;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof CfgDelivery)) {
            return false;
        }
        CfgDelivery that = (CfgDelivery) o;
        return getEvcCfgFrameDelivery() == that.getEvcCfgFrameDelivery() &&
                Objects.equals(getDeliveryCondition(), that.getDeliveryCondition());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEvcCfgFrameDelivery(), getDeliveryCondition());
    }
}
