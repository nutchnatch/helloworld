package com.ossnms.web.provider.mef.service.model.attributes.connection.ovc;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

class OvcCfgCevlanIdPreservationEntry implements EntityBase {

    private static final long serialVersionUID = 6904855875610013148L;

    private String IngressInterface;
    private String IngressFrameFormat;
    private String EgressInterface;
    private String EgressFrameFormat;

    public OvcCfgCevlanIdPreservationEntry(String ingressInterface, String ingressFrameFormat, String egressInterface, String egressFrameFormat) {
        IngressInterface = ingressInterface;
        IngressFrameFormat = ingressFrameFormat;
        EgressInterface = egressInterface;
        EgressFrameFormat = egressFrameFormat;
    }

    public String getIngressInterface() {
        return IngressInterface;
    }

    public void setIngressInterface(String ingressInterface) {
        IngressInterface = ingressInterface;
    }

    public String getIngressFrameFormat() {
        return IngressFrameFormat;
    }

    public void setIngressFrameFormat(String ingressFrameFormat) {
        IngressFrameFormat = ingressFrameFormat;
    }

    public String getEgressInterface() {
        return EgressInterface;
    }

    public void setEgressInterface(String egressInterface) {
        EgressInterface = egressInterface;
    }

    public String getEgressFrameFormat() {
        return EgressFrameFormat;
    }

    public void setEgressFrameFormat(String egressFrameFormat) {
        EgressFrameFormat = egressFrameFormat;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof OvcCfgCevlanIdPreservationEntry)) {
            return false;
        }
        OvcCfgCevlanIdPreservationEntry that = (OvcCfgCevlanIdPreservationEntry) o;
        return Objects.equals(getIngressInterface(), that.getIngressInterface()) &&
                Objects.equals(getIngressFrameFormat(), that.getIngressFrameFormat()) &&
                Objects.equals(getEgressInterface(), that.getEgressInterface()) &&
                Objects.equals(getEgressFrameFormat(), that.getEgressFrameFormat());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIngressInterface(), getIngressFrameFormat(), getEgressInterface(), getEgressFrameFormat());
    }
}
