package com.ossnms.web.provider.mef.service.model.attributes.connection.evc;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.mef.service.model.attributes.common.CfgDelivery;

import java.util.Objects;

public class FrameDelivery implements EntityBase {

    private static final long serialVersionUID = 2301153054373822921L;

    private CfgDelivery unicastDelivery;
    private CfgDelivery multicastDelivery;
    private CfgDelivery broadcastDelivery;

    public FrameDelivery() {
    }


    public CfgDelivery getUnicastDelivery() {
        return unicastDelivery;
    }

    public void setUnicastDelivery(CfgDelivery unicastDelivery) {
        this.unicastDelivery = unicastDelivery;
    }

    public CfgDelivery getMulticastDelivery() {
        return multicastDelivery;
    }

    public void setMulticastDelivery(CfgDelivery multicastDelivery) {
        this.multicastDelivery = multicastDelivery;
    }

    public CfgDelivery getBroadcastDelivery() {
        return broadcastDelivery;
    }

    public void setBroadcastDelivery(CfgDelivery broadcastDelivery) {
        this.broadcastDelivery = broadcastDelivery;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof FrameDelivery)) {
            return false;
        }
        FrameDelivery that = (FrameDelivery) o;
        return Objects.equals(getUnicastDelivery(), that.getUnicastDelivery()) &&
                Objects.equals(getMulticastDelivery(), that.getMulticastDelivery()) &&
                Objects.equals(getBroadcastDelivery(), that.getBroadcastDelivery());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getUnicastDelivery(), getMulticastDelivery(), getBroadcastDelivery());
    }
}
