package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

public enum InterfaceCfgFrameFormat {
    DA_SA_ET_PAYLOAD_AND_FCS("DA:SA:ET:payload and FCS"),
    DA_SA_STAG_ET_PAYLOAD_AND_FCS("DA:SA:S-Tag:ET:payload and FCS"),
    DA_SA_STAG_CTAG_ET_PAYLOAD_AND_FCS("DA:SA:S-Tag:C-Tag:ET:payload and FCS");

    private String value;

    InterfaceCfgFrameFormat(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
