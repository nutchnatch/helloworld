package com.ossnms.web.provider.mef.service.model.attributes.endpoint.inni;

import com.ossnms.web.provider.mef.service.api.model.attributes.endpoint.Endpoint;
import com.ossnms.web.provider.mef.service.api.model.attributes.endpoint.EndpointType;
import com.ossnms.web.provider.mef.service.model.attributes.common.Lag;
import com.ossnms.web.provider.mef.service.model.attributes.common.Ptp;

import java.util.Objects;

public class InniEndpoint implements Endpoint{

    private static final long serialVersionUID = 4485814168072017893L;

    //    Choice
    private Ptp inniPtp;
    private Lag inniLag;

    private String interfaceDescription;
    private Integer stag;
    private String tpid;
    private String mtu;
    private String speed;
    private String circuitId;
    private Integer vcid;
    private String pwType;
    private String hvplsRole;
    private String hvplsSpokeLbIpAddrs;
    private String hvplsSpokeVcid;
    private String peerLbIpAddrs;
    private BgpLuVpnId bgpLuVpnId;

    public InniEndpoint() {
    }

    public InniEndpoint(Ptp endPoint, Lag inniLag, Integer stag, String speed) {
        this.inniPtp = endPoint;
        this.inniLag = inniLag;
        this.stag = stag;
        this.speed = speed;
    }

    public Ptp getInniPtp() {
        return inniPtp;
    }

    public void setInniPtp(Ptp inniPtp) {
        this.inniPtp = inniPtp;
    }

    public Lag getInniLag() {
        return inniLag;
    }

    public void setInniLag(Lag inniLag) {
        this.inniLag = inniLag;
    }

    public String getInterfaceDescription() {
        return interfaceDescription;
    }

    public void setInterfaceDescription(String interfaceDescription) {
        this.interfaceDescription = interfaceDescription;
    }

    public Integer getStag() {
        return stag;
    }

    public void setStag(Integer stag) {
        this.stag = stag;
    }

    public String getTpid() {
        return tpid;
    }

    public void setTpid(String tpid) {
        this.tpid = tpid;
    }

    public String getMtu() {
        return mtu;
    }

    public void setMtu(String mtu) {
        this.mtu = mtu;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getCircuitId() {
        return circuitId;
    }

    public void setCircuitId(String circuitId) {
        this.circuitId = circuitId;
    }

    public Integer getVcid() {
        return vcid;
    }

    public void setVcid(Integer vcid) {
        this.vcid = vcid;
    }

    public String getPwType() {
        return pwType;
    }

    public void setPwType(String pwType) {
        this.pwType = pwType;
    }

    public String getHvplsRole() {
        return hvplsRole;
    }

    public void setHvplsRole(String hvplsRole) {
        this.hvplsRole = hvplsRole;
    }

    public String getHvplsSpokeLbIpAddrs() {
        return hvplsSpokeLbIpAddrs;
    }

    public void setHvplsSpokeLbIpAddrs(String hvplsSpokeLbIpAddrs) {
        this.hvplsSpokeLbIpAddrs = hvplsSpokeLbIpAddrs;
    }

    public String getHvplsSpokeVcid() {
        return hvplsSpokeVcid;
    }

    public void setHvplsSpokeVcid(String hvplsSpokeVcid) {
        this.hvplsSpokeVcid = hvplsSpokeVcid;
    }

    public String getPeerLbIpAddrs() {
        return peerLbIpAddrs;
    }

    public void setPeerLbIpAddrs(String peerLbIpAddrs) {
        this.peerLbIpAddrs = peerLbIpAddrs;
    }

    public BgpLuVpnId getBgpLuVpnId() {
        return bgpLuVpnId;
    }

    public void setBgpLuVpnId(BgpLuVpnId bgpLuVpnId) {
        this.bgpLuVpnId = bgpLuVpnId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof InniEndpoint)) {
            return false;
        }
        InniEndpoint that = (InniEndpoint) o;
        return Objects.equals(getInniPtp(), that.getInniPtp()) &&
                Objects.equals(getInniLag(), that.getInniLag()) &&
                Objects.equals(getInterfaceDescription(), that.getInterfaceDescription()) &&
                Objects.equals(getStag(), that.getStag()) &&
                Objects.equals(getTpid(), that.getTpid()) &&
                Objects.equals(getMtu(), that.getMtu()) &&
                Objects.equals(getSpeed(), that.getSpeed()) &&
                Objects.equals(getCircuitId(), that.getCircuitId()) &&
                Objects.equals(getVcid(), that.getVcid()) &&
                Objects.equals(getPwType(), that.getPwType()) &&
                Objects.equals(getHvplsRole(), that.getHvplsRole()) &&
                Objects.equals(getHvplsSpokeLbIpAddrs(), that.getHvplsSpokeLbIpAddrs()) &&
                Objects.equals(getHvplsSpokeVcid(), that.getHvplsSpokeVcid()) &&
                Objects.equals(getPeerLbIpAddrs(), that.getPeerLbIpAddrs()) &&
                Objects.equals(getBgpLuVpnId(), that.getBgpLuVpnId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getInniPtp(), getInniLag(), getInterfaceDescription(), getStag(), getTpid(), getMtu(), getSpeed(), getCircuitId(), getVcid(), getPwType(), getHvplsRole(), getHvplsSpokeLbIpAddrs(), getHvplsSpokeVcid(), getPeerLbIpAddrs(), getBgpLuVpnId());
    }

    @Override
    public EndpointType getEndpointType() {
        return EndpointType.INNI;
    }
}
