package com.ossnms.web.provider.mef.service.model.attributes.common;

public enum ServiceType {
    ELINE("ELine"),
    ELAN("ELan"),
    ETREE("ETree"), // not supported by mef/tnms
    EACCESS("EAccess"), // not supported by mef/tnms
    ETRANSIT("ETransit"); // not supported by mef/tnms

    private String value;

    ServiceType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
