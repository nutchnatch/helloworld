package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

public enum EnniCfgPhyType {
    TYPE_1000BASESX("1000Base-SX"),
    TYPE_1000BASELX("1000Base-LX"),
    TYPE_1000BASET("1000BaseT"),
    TYPE_10GBASESR("10GBASE-SR"),
    TYPE_10GBASELX4("10GBASE-LX4"),
    TYPE_10GBASELR("10GBASE-LR"),
    TYPE_10GBASEER("10GBASE-ER"),
    TYPE_10GBASESW("10GBASE-SW"),
    TYPE_10GBASELW("10GBASE-LW"),
    TYPE_10GBASEEW("10GBASE-EW");

    private String value;

    EnniCfgPhyType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
