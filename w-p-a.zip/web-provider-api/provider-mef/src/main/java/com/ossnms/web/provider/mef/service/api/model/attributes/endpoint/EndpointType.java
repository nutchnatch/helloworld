package com.ossnms.web.provider.mef.service.api.model.attributes.endpoint;

public enum EndpointType {
    UNI,
    ENNI,
    INNI
}
