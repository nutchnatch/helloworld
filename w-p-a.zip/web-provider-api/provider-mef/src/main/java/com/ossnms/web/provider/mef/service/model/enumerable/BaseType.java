package com.ossnms.web.provider.mef.service.model.enumerable;

public enum BaseType {
    PORT("Port"),
    VLAN("Vlan");

    private String value;

    BaseType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
