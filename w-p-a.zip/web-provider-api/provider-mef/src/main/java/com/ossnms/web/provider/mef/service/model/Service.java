package com.ossnms.web.provider.mef.service.model;


import com.ossnms.web.provider.common.api.model.Entity;
import com.ossnms.web.provider.mef.service.api.model.attributes.connection.VirtualConnection;
import com.ossnms.web.provider.mef.service.api.model.attributes.endpoint.Endpoint;
import com.ossnms.web.provider.mef.service.model.attributes.common.ServiceTypeSetting;

import java.util.List;
import java.util.Objects;

public class Service extends ServiceSummary implements Entity<ServiceID> {

    private static final long serialVersionUID = 1166755382244151631L;
    /**
     *
     */
    private String customer;

    /**
     *
     */
    private ServiceTypeSetting ethernetServiceType;

    /**
     *
     */
    private List<Endpoint> endpoints;

    /**
     *
     */
    private VirtualConnection virtualConnection;

    /**
     *
     */
    public String getCustomer() {
        return customer;
    }

    public Service setCustomer(String customer) {
        this.customer = customer;
        return this;
    }

    /**
     *
     */
    public ServiceTypeSetting getEthernetServiceType() {
        return ethernetServiceType;
    }

    public Service setEthernetServiceType(ServiceTypeSetting ethernetServiceType) {
        this.ethernetServiceType = ethernetServiceType;
        return this;
    }

    /**
     *
     */
    public List<Endpoint> getEndpoints() {
        return endpoints;
    }

    public Service setEndpoints(List<Endpoint> endpoints) {
        this.endpoints = endpoints;
        return this;
    }

    /**
     *
     */
    public VirtualConnection getVirtualConnection() {
        return virtualConnection;
    }

    public Service setVirtualConnection(VirtualConnection virtualConnection) {
        this.virtualConnection = virtualConnection;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Service service = (Service) o;
        return Objects.equals(getCustomer(), service.getCustomer()) &&
                Objects.equals(getEthernetServiceType(), service.getEthernetServiceType()) &&
                Objects.equals(getEndpoints(), service.getEndpoints()) &&
                Objects.equals(getVirtualConnection(), service.getVirtualConnection());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCustomer(), getEthernetServiceType(), getEndpoints(), getVirtualConnection());
    }
}
