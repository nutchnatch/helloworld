package com.ossnms.web.provider.mef.service.model.attributes.endpoint.uni;

import com.ossnms.web.provider.mef.service.api.model.attributes.endpoint.Endpoint;
import com.ossnms.web.provider.mef.service.api.model.attributes.endpoint.EndpointType;
import com.ossnms.web.provider.mef.service.model.attributes.common.Lag;
import com.ossnms.web.provider.mef.service.model.attributes.common.Ptp;

public class UniEndpoint implements Endpoint{
    private static final long serialVersionUID = -3012055294329192135L;
    //Choice
    private Ptp uniPtp;
    private Lag uniLag;

    private String serviceInterfaceCfgIdentifier;               // Max 45 Chars
    private EvcPerUniCfgCeVlanMap evcPerUniCfgCeVlanMap;        // evcId = all -> PortBased | valores/rangeValores -> Cvlan based
    private EvcPerUni evcPerUni;

    @Override
    public EndpointType getEndpointType() {
        return EndpointType.UNI;
    }

    public Ptp getUniPtp() {
        return uniPtp;
    }

    public void setUniPtp(Ptp uniPtp) {
        this.uniPtp = uniPtp;
    }

    public Lag getUniLag() {
        return uniLag;
    }

    public void setUniLag(Lag uniLag) {
        this.uniLag = uniLag;
    }

    public String getServiceInterfaceCfgIdentifier() {
        return serviceInterfaceCfgIdentifier;
    }

    public void setServiceInterfaceCfgIdentifier(String serviceInterfaceCfgIdentifier) {
        this.serviceInterfaceCfgIdentifier = serviceInterfaceCfgIdentifier;
    }

    public EvcPerUniCfgCeVlanMap getEvcPerUniCfgCeVlanMap() {
        return evcPerUniCfgCeVlanMap;
    }

    public void setEvcPerUniCfgCeVlanMap(EvcPerUniCfgCeVlanMap evcPerUniCfgCeVlanMap) {
        this.evcPerUniCfgCeVlanMap = evcPerUniCfgCeVlanMap;
    }

    public EvcPerUni getEvcPerUni() {
        return evcPerUni;
    }

    public void setEvcPerUni(EvcPerUni evcPerUni) {
        this.evcPerUni = evcPerUni;
    }
}
