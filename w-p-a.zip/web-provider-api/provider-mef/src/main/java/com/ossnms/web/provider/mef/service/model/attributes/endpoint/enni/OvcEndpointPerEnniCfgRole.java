package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

public enum OvcEndpointPerEnniCfgRole {
    ROOT("Root"),
    LEAF("Leaf"),
    TRUNK("Trunk");

    private String value;

    OvcEndpointPerEnniCfgRole(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
