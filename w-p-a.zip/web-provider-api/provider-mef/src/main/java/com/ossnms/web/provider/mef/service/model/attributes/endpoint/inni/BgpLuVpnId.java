package com.ossnms.web.provider.mef.service.model.attributes.endpoint.inni;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class BgpLuVpnId implements EntityBase {

    private static final long serialVersionUID = 516529320019880046L;

    private String asn;
    private String serviceId;

    public BgpLuVpnId() {
    }

    public BgpLuVpnId(String asn, String serviceId) {
        this.asn = asn;
        this.serviceId = serviceId;
    }

    public String getAsn() {
        return asn;
    }

    public void setAsn(String asn) {
        this.asn = asn;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BgpLuVpnId)) {
            return false;
        }
        BgpLuVpnId that = (BgpLuVpnId) o;
        return Objects.equals(getAsn(), that.getAsn()) &&
                Objects.equals(getServiceId(), that.getServiceId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getAsn(), getServiceId());
    }
}
