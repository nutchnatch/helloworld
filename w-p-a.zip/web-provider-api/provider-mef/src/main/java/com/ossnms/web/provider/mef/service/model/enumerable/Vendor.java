package com.ossnms.web.provider.mef.service.model.enumerable;

public enum Vendor {
    CISCO("cisco"),
    JUNIPER("juniper"),
    CIENA("ciena"),
    ALCATEL("alcatel"),
    RAD("rad"),
    CALIX("calix"),
    CYAN("cyan"),
    ADTRAN("adtran"),
    TELLABS("tellabs"),
    FUJITSU("fujitsu"),
    INFINERA("infinera");

    private String value;

    Vendor(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
