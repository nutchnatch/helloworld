package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

public enum EnniCfgNumberLinks {
    ONE(1),
    TWO(2);

    private int value;

    EnniCfgNumberLinks(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
