package com.ossnms.web.provider.mef.service.model.attributes.common;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.List;
import java.util.Objects;

public class Lag implements EntityBase {

    private static final long serialVersionUID = -3523156110324170688L;

    //at least 2 occurrences
    private List<Ptp> lagMembers;
    private String groupName;
    private Integer groupId;

    public Lag(List<Ptp> lagMembers, String groupName, Integer groupId) {
        this.lagMembers = lagMembers;
        this.groupName = groupName;
        this.groupId = groupId;
    }

    public List<Ptp> getLagMembers() {
        return lagMembers;
    }

    public void setLagMembers(List<Ptp> lagMembers) {
        this.lagMembers = lagMembers;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Lag)) {
            return false;
        }
        Lag lagT = (Lag) o;
        return Objects.equals(getLagMembers(), lagT.getLagMembers()) &&
                Objects.equals(getGroupName(), lagT.getGroupName()) &&
                Objects.equals(getGroupId(), lagT.getGroupId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getLagMembers(), getGroupName(), getGroupId());
    }
}
