package com.ossnms.web.provider.mef.service.api.model.attributes.connection;

import com.ossnms.web.provider.common.api.model.EntityBase;

/**
 *
 */
public interface VirtualConnection extends EntityBase {

    VirtualConnectionType getVirtualConnectionType();

}
