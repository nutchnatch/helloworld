package com.ossnms.web.provider.mef.service.api.model.attributes.endpoint;

import com.ossnms.web.provider.common.api.model.EntityBase;

/**
 *
 */
public interface Endpoint extends EntityBase{

    /**
     *
     * @return endpoint type
     */
    EndpointType getEndpointType();

}
