package com.ossnms.web.provider.mef.service.model.attributes.connection.ovc;

import com.ossnms.web.provider.mef.service.api.model.attributes.connection.VirtualConnection;
import com.ossnms.web.provider.mef.service.api.model.attributes.connection.VirtualConnectionType;
import com.ossnms.web.provider.mef.service.model.attributes.common.CfgDelivery;
import com.ossnms.web.provider.mef.service.model.attributes.common.CfgServiceType;
import com.ossnms.web.provider.mef.service.model.attributes.common.EnabledDisabledType;

import java.util.Objects;

public class Ovc implements VirtualConnection {

    private static final long serialVersionUID = -7836947667673219926L;

    private String ovcCfgIdentifier;
    private CfgServiceType ovcCfgServiceType;
    private OvcEndpointCfgTableEntry ovcEndPtCfgTableEntry;
    private OvcEndpointCfgTableEntry ovcEndPtPerUniCfgTable;
    private OvcEndpointCfgTableEntry ovcEndPtPerVuniCfgTable;
    private Integer ovcStatusMaxNumUniOvcEndPt;
    private Integer ovcStatusMaxNumEnniOvcEndPt;
    private Integer ovcStatusMaxNumVuniOvcEndPt;
    private Integer ovcStatusMaxMtuSize;
    private OvcCfgCevlanIdPreservation ovcCfgCevlanIdPreservation;
    private OvcCfgCevlanIdPreservation ovcCfgCevlanCosPreservation;
    private EnabledDisabledType ovcCfgSvlanIdPreservation;
    private EnabledDisabledType ovcCfgSvlanCosPreservation;
    private EnabledDisabledType ovcCfgColorForwarding;
    private String ovcCfgColorIndicator;
    private CfgDelivery ovcCfgUnicastDelivery;
    private CfgDelivery ovcCfgMulticastDelivery;
    private CfgDelivery ovcCfgBroadcastDelivery;

    public String getOvcCfgIdentifier() {
        return ovcCfgIdentifier;
    }

    public void setOvcCfgIdentifier(String ovcCfgIdentifier) {
        this.ovcCfgIdentifier = ovcCfgIdentifier;
    }

    public CfgServiceType getOvcCfgServiceType() {
        return ovcCfgServiceType;
    }

    public void setOvcCfgServiceType(CfgServiceType ovcCfgServiceType) {
        this.ovcCfgServiceType = ovcCfgServiceType;
    }

    public OvcEndpointCfgTableEntry getOvcEndPtCfgTableEntry() {
        return ovcEndPtCfgTableEntry;
    }

    public void setOvcEndPtCfgTableEntry(OvcEndpointCfgTableEntry ovcEndPtCfgTableEntry) {
        this.ovcEndPtCfgTableEntry = ovcEndPtCfgTableEntry;
    }

    public OvcEndpointCfgTableEntry getOvcEndPtPerUniCfgTable() {
        return ovcEndPtPerUniCfgTable;
    }

    public void setOvcEndPtPerUniCfgTable(OvcEndpointCfgTableEntry ovcEndPtPerUniCfgTable) {
        this.ovcEndPtPerUniCfgTable = ovcEndPtPerUniCfgTable;
    }

    public OvcEndpointCfgTableEntry getOvcEndPtPerVuniCfgTable() {
        return ovcEndPtPerVuniCfgTable;
    }

    public void setOvcEndPtPerVuniCfgTable(OvcEndpointCfgTableEntry ovcEndPtPerVuniCfgTable) {
        this.ovcEndPtPerVuniCfgTable = ovcEndPtPerVuniCfgTable;
    }

    public Integer getOvcStatusMaxNumUniOvcEndPt() {
        return ovcStatusMaxNumUniOvcEndPt;
    }

    public void setOvcStatusMaxNumUniOvcEndPt(Integer ovcStatusMaxNumUniOvcEndPt) {
        this.ovcStatusMaxNumUniOvcEndPt = ovcStatusMaxNumUniOvcEndPt;
    }

    public Integer getOvcStatusMaxNumEnniOvcEndPt() {
        return ovcStatusMaxNumEnniOvcEndPt;
    }

    public void setOvcStatusMaxNumEnniOvcEndPt(Integer ovcStatusMaxNumEnniOvcEndPt) {
        this.ovcStatusMaxNumEnniOvcEndPt = ovcStatusMaxNumEnniOvcEndPt;
    }

    public Integer getOvcStatusMaxNumVuniOvcEndPt() {
        return ovcStatusMaxNumVuniOvcEndPt;
    }

    public void setOvcStatusMaxNumVuniOvcEndPt(Integer ovcStatusMaxNumVuniOvcEndPt) {
        this.ovcStatusMaxNumVuniOvcEndPt = ovcStatusMaxNumVuniOvcEndPt;
    }

    public Integer getOvcStatusMaxMtuSize() {
        return ovcStatusMaxMtuSize;
    }

    public void setOvcStatusMaxMtuSize(Integer ovcStatusMaxMtuSize) {
        this.ovcStatusMaxMtuSize = ovcStatusMaxMtuSize;
    }

    public OvcCfgCevlanIdPreservation getOvcCfgCevlanIdPreservation() {
        return ovcCfgCevlanIdPreservation;
    }

    public void setOvcCfgCevlanIdPreservation(OvcCfgCevlanIdPreservation ovcCfgCevlanIdPreservation) {
        this.ovcCfgCevlanIdPreservation = ovcCfgCevlanIdPreservation;
    }

    public OvcCfgCevlanIdPreservation getOvcCfgCevlanCosPreservation() {
        return ovcCfgCevlanCosPreservation;
    }

    public void setOvcCfgCevlanCosPreservation(OvcCfgCevlanIdPreservation ovcCfgCevlanCosPreservation) {
        this.ovcCfgCevlanCosPreservation = ovcCfgCevlanCosPreservation;
    }

    public EnabledDisabledType getOvcCfgSvlanIdPreservation() {
        return ovcCfgSvlanIdPreservation;
    }

    public void setOvcCfgSvlanIdPreservation(EnabledDisabledType ovcCfgSvlanIdPreservation) {
        this.ovcCfgSvlanIdPreservation = ovcCfgSvlanIdPreservation;
    }

    public EnabledDisabledType getOvcCfgSvlanCosPreservation() {
        return ovcCfgSvlanCosPreservation;
    }

    public void setOvcCfgSvlanCosPreservation(EnabledDisabledType ovcCfgSvlanCosPreservation) {
        this.ovcCfgSvlanCosPreservation = ovcCfgSvlanCosPreservation;
    }

    public EnabledDisabledType getOvcCfgColorForwarding() {
        return ovcCfgColorForwarding;
    }

    public void setOvcCfgColorForwarding(EnabledDisabledType ovcCfgColorForwarding) {
        this.ovcCfgColorForwarding = ovcCfgColorForwarding;
    }

    public String getOvcCfgColorIndicator() {
        return ovcCfgColorIndicator;
    }

    public void setOvcCfgColorIndicator(String ovcCfgColorIndicator) {
        this.ovcCfgColorIndicator = ovcCfgColorIndicator;
    }

    public CfgDelivery getOvcCfgUnicastDelivery() {
        return ovcCfgUnicastDelivery;
    }

    public void setOvcCfgUnicastDelivery(CfgDelivery ovcCfgUnicastDelivery) {
        this.ovcCfgUnicastDelivery = ovcCfgUnicastDelivery;
    }

    public CfgDelivery getOvcCfgMulticastDelivery() {
        return ovcCfgMulticastDelivery;
    }

    public void setOvcCfgMulticastDelivery(CfgDelivery ovcCfgMulticastDelivery) {
        this.ovcCfgMulticastDelivery = ovcCfgMulticastDelivery;
    }

    public CfgDelivery getOvcCfgBroadcastDelivery() {
        return ovcCfgBroadcastDelivery;
    }

    public void setOvcCfgBroadcastDelivery(CfgDelivery ovcCfgBroadcastDelivery) {
        this.ovcCfgBroadcastDelivery = ovcCfgBroadcastDelivery;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Ovc)) {
            return false;
        }
        Ovc ovc = (Ovc) o;
        return Objects.equals(getOvcCfgIdentifier(), ovc.getOvcCfgIdentifier()) &&
                getOvcCfgServiceType() == ovc.getOvcCfgServiceType() &&
                Objects.equals(getOvcEndPtCfgTableEntry(), ovc.getOvcEndPtCfgTableEntry()) &&
                Objects.equals(getOvcEndPtPerUniCfgTable(), ovc.getOvcEndPtPerUniCfgTable()) &&
                Objects.equals(getOvcEndPtPerVuniCfgTable(), ovc.getOvcEndPtPerVuniCfgTable()) &&
                Objects.equals(getOvcStatusMaxNumUniOvcEndPt(), ovc.getOvcStatusMaxNumUniOvcEndPt()) &&
                Objects.equals(getOvcStatusMaxNumEnniOvcEndPt(), ovc.getOvcStatusMaxNumEnniOvcEndPt()) &&
                Objects.equals(getOvcStatusMaxNumVuniOvcEndPt(), ovc.getOvcStatusMaxNumVuniOvcEndPt()) &&
                Objects.equals(getOvcStatusMaxMtuSize(), ovc.getOvcStatusMaxMtuSize()) &&
                Objects.equals(getOvcCfgCevlanIdPreservation(), ovc.getOvcCfgCevlanIdPreservation()) &&
                Objects.equals(getOvcCfgCevlanCosPreservation(), ovc.getOvcCfgCevlanCosPreservation()) &&
                getOvcCfgSvlanIdPreservation() == ovc.getOvcCfgSvlanIdPreservation() &&
                getOvcCfgSvlanCosPreservation() == ovc.getOvcCfgSvlanCosPreservation() &&
                getOvcCfgColorForwarding() == ovc.getOvcCfgColorForwarding() &&
                Objects.equals(getOvcCfgColorIndicator(), ovc.getOvcCfgColorIndicator()) &&
                Objects.equals(getOvcCfgUnicastDelivery(), ovc.getOvcCfgUnicastDelivery()) &&
                Objects.equals(getOvcCfgMulticastDelivery(), ovc.getOvcCfgMulticastDelivery()) &&
                Objects.equals(getOvcCfgBroadcastDelivery(), ovc.getOvcCfgBroadcastDelivery());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getOvcCfgIdentifier(), getOvcCfgServiceType(), getOvcEndPtCfgTableEntry(), getOvcEndPtPerUniCfgTable(), getOvcEndPtPerVuniCfgTable(), getOvcStatusMaxNumUniOvcEndPt(), getOvcStatusMaxNumEnniOvcEndPt(), getOvcStatusMaxNumVuniOvcEndPt(), getOvcStatusMaxMtuSize(), getOvcCfgCevlanIdPreservation(), getOvcCfgCevlanCosPreservation(), getOvcCfgSvlanIdPreservation(), getOvcCfgSvlanCosPreservation(), getOvcCfgColorForwarding(), getOvcCfgColorIndicator(), getOvcCfgUnicastDelivery(), getOvcCfgMulticastDelivery(), getOvcCfgBroadcastDelivery());
    }

    @Override
    public VirtualConnectionType getVirtualConnectionType() {
        return VirtualConnectionType.OVC;
    }
}
