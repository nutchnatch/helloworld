package com.ossnms.web.provider.mef.service.model.attributes.common;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.mef.service.model.enumerable.Vendor;

import java.util.Objects;

public class Ptp implements EntityBase {

    private static final long serialVersionUID = -6962966213222453465L;

    private String clli;
    private Vendor vendor;
    private String hostName;
    private String shelf;
    private String slot;
    private String subSlot;
    private String port;
    private String rack;

    public Ptp(String clli, Vendor vendor, String hostName, String shelf, String slot, String subSlot, String port, String rack) {
        this.clli = clli;
        this.vendor = vendor;
        this.hostName = hostName;
        this.shelf = shelf;
        this.slot = slot;
        this.subSlot = subSlot;
        this.port = port;
        this.rack = rack;
    }

    public String getClli() {
        return clli;
    }

    public void setClli(String clli) {
        this.clli = clli;
    }

    public Vendor getVendor() {
        return vendor;
    }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getShelf() {
        return shelf;
    }

    public void setShelf(String shelf) {
        this.shelf = shelf;
    }

    public String getSlot() {
        return slot;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }

    public String getSubSlot() {
        return subSlot;
    }

    public void setSubSlot(String subSlot) {
        this.subSlot = subSlot;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getRack() {
        return rack;
    }

    public void setRack(String rack) {
        this.rack = rack;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Ptp)) {
            return false;
        }
        Ptp ptpT = (Ptp) o;
        return Objects.equals(getClli(), ptpT.getClli()) &&
                getVendor() == ptpT.getVendor() &&
                Objects.equals(getHostName(), ptpT.getHostName()) &&
                Objects.equals(getShelf(), ptpT.getShelf()) &&
                Objects.equals(getSlot(), ptpT.getSlot()) &&
                Objects.equals(getSubSlot(), ptpT.getSubSlot()) &&
                Objects.equals(getPort(), ptpT.getPort()) &&
                Objects.equals(getRack(), ptpT.getRack());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getClli(), getVendor(), getHostName(), getShelf(), getSlot(), getSubSlot(), getPort(), getRack());
    }
}
