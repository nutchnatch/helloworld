package com.ossnms.web.provider.mef.service.model.attributes.connection.ovc;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class OvcCfgCevlanIdPreservation implements EntityBase {

    private static final long serialVersionUID = -797544364329944372L;

    private String disabled;
    private OvcCfgCevlanIdPreservationEntry ovcCfgCevlanIdPreservationEntry;

    public OvcCfgCevlanIdPreservation(String disabled, OvcCfgCevlanIdPreservationEntry ovcCfgCevlanIdPreservationEntry) {
        this.disabled = disabled;
        this.ovcCfgCevlanIdPreservationEntry = ovcCfgCevlanIdPreservationEntry;
    }

    public String getDisabled() {
        return disabled;
    }

    public void setDisabled(String disabled) {
        this.disabled = disabled;
    }

    public OvcCfgCevlanIdPreservationEntry getOvcCfgCevlanIdPreservationEntry() {
        return ovcCfgCevlanIdPreservationEntry;
    }

    public void setOvcCfgCevlanIdPreservationEntry(OvcCfgCevlanIdPreservationEntry ovcCfgCevlanIdPreservationEntry) {
        this.ovcCfgCevlanIdPreservationEntry = ovcCfgCevlanIdPreservationEntry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof OvcCfgCevlanIdPreservation)) {
            return false;
        }
        OvcCfgCevlanIdPreservation that = (OvcCfgCevlanIdPreservation) o;
        return Objects.equals(getDisabled(), that.getDisabled()) &&
                Objects.equals(getOvcCfgCevlanIdPreservationEntry(), that.getOvcCfgCevlanIdPreservationEntry());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getDisabled(), getOvcCfgCevlanIdPreservationEntry());
    }
}