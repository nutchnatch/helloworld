package com.ossnms.web.provider.mef.service.model.attributes.connection.ovc;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class OvcEndpointCfgTableEntry implements EntityBase {

    private static final long serialVersionUID = -7098175598113057284L;

    private String ovceprole;
    private String ovcptid;

    public OvcEndpointCfgTableEntry(String ovceprole, String ovcptid) {
        this.ovceprole = ovceprole;
        this.ovcptid = ovcptid;
    }

    public String getOvceprole() {
        return ovceprole;
    }

    public void setOvceprole(String ovceprole) {
        this.ovceprole = ovceprole;
    }

    public String getOvcptid() {
        return ovcptid;
    }

    public void setOvcptid(String ovcptid) {
        this.ovcptid = ovcptid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof OvcEndpointCfgTableEntry)) {
            return false;
        }
        OvcEndpointCfgTableEntry that = (OvcEndpointCfgTableEntry) o;
        return Objects.equals(getOvceprole(), that.getOvceprole()) &&
                Objects.equals(getOvcptid(), that.getOvcptid());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getOvceprole(), getOvcptid());
    }
}
