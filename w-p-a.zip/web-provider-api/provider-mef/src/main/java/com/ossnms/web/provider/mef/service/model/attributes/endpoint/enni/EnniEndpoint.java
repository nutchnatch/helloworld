package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

import com.ossnms.web.provider.mef.service.api.model.attributes.endpoint.Endpoint;
import com.ossnms.web.provider.mef.service.api.model.attributes.endpoint.EndpointType;
import com.ossnms.web.provider.mef.service.model.attributes.common.Lag;
import com.ossnms.web.provider.mef.service.model.attributes.common.Ptp;

import java.util.List;
import java.util.Objects;

public class EnniEndpoint implements Endpoint {

    private static final long serialVersionUID = -5406992146402689700L;

    //Choice
    private Ptp enniPtp;
    private Lag enniLag;

    private String enniCfgIdentifier;
    private EnniCfgPhyType enniCfgPhyType;
    private InterfaceCfgFrameFormat interfaceCfgFrameFormat;
    //    mefEnniL2cpServiceAttributes
    private EnniCfgNumberLinks enniCfgNumberLinks;
    private EnnicfgProtection enniCfgProtection; // mefServiceEnniCfgProtection
    private Integer enniMtu;
    private List<EnniEndpointMapEntry> ovcEndPointPerEnniCfgTble;
    private List<EnniEndpointMapEntry> ovcEndPointPerVuniCfgTble;
    private Integer enniMaxNumberOvcs;
    private Integer enniCfgMaxNumberOvcEndPts;
    private List<OvcPerEnniEndpoint> ovcPerEnniEndPoint;

    public EnniEndpoint() {
    }

    public Ptp getEnniPtp() {
        return enniPtp;
    }

    public void setEnniPtp(Ptp enniPtp) {
        this.enniPtp = enniPtp;
    }

    public Lag getEnniLag() {
        return enniLag;
    }

    public void setEnniLag(Lag enniLag) {
        this.enniLag = enniLag;
    }

    public String getEnniCfgIdentifier() {
        return enniCfgIdentifier;
    }

    public void setEnniCfgIdentifier(String enniCfgIdentifier) {
        this.enniCfgIdentifier = enniCfgIdentifier;
    }

    public EnniCfgPhyType getEnniCfgPhyType() {
        return enniCfgPhyType;
    }

    public void setEnniCfgPhyType(EnniCfgPhyType enniCfgPhyType) {
        this.enniCfgPhyType = enniCfgPhyType;
    }

    public InterfaceCfgFrameFormat getInterfaceCfgFrameFormat() {
        return interfaceCfgFrameFormat;
    }

    public void setInterfaceCfgFrameFormat(InterfaceCfgFrameFormat interfaceCfgFrameFormat) {
        this.interfaceCfgFrameFormat = interfaceCfgFrameFormat;
    }

    public EnniCfgNumberLinks getEnniCfgNumberLinks() {
        return enniCfgNumberLinks;
    }

    public void setEnniCfgNumberLinks(EnniCfgNumberLinks enniCfgNumberLinks) {
        this.enniCfgNumberLinks = enniCfgNumberLinks;
    }

    public EnnicfgProtection getEnniCfgProtection() {
        return enniCfgProtection;
    }

    public void setEnniCfgProtection(EnnicfgProtection enniCfgProtection) {
        this.enniCfgProtection = enniCfgProtection;
    }

    public Integer getEnniMtu() {
        return enniMtu;
    }

    public void setEnniMtu(Integer enniMtu) {
        this.enniMtu = enniMtu;
    }

    public List<EnniEndpointMapEntry> getOvcEndPointPerEnniCfgTble() {
        return ovcEndPointPerEnniCfgTble;
    }

    public void setOvcEndPointPerEnniCfgTble(List<EnniEndpointMapEntry> ovcEndPointPerEnniCfgTble) {
        this.ovcEndPointPerEnniCfgTble = ovcEndPointPerEnniCfgTble;
    }

    public List<EnniEndpointMapEntry> getOvcEndPointPerVuniCfgTble() {
        return ovcEndPointPerVuniCfgTble;
    }

    public void setOvcEndPointPerVuniCfgTble(List<EnniEndpointMapEntry> ovcEndPointPerVuniCfgTble) {
        this.ovcEndPointPerVuniCfgTble = ovcEndPointPerVuniCfgTble;
    }

    public Integer getEnniMaxNumberOvcs() {
        return enniMaxNumberOvcs;
    }

    public void setEnniMaxNumberOvcs(Integer enniMaxNumberOvcs) {
        this.enniMaxNumberOvcs = enniMaxNumberOvcs;
    }

    public Integer getEnniCfgMaxNumberOvcEndPts() {
        return enniCfgMaxNumberOvcEndPts;
    }

    public void setEnniCfgMaxNumberOvcEndPts(Integer enniCfgMaxNumberOvcEndPts) {
        this.enniCfgMaxNumberOvcEndPts = enniCfgMaxNumberOvcEndPts;
    }

    public List<OvcPerEnniEndpoint> getOvcPerEnniEndPoint() {
        return ovcPerEnniEndPoint;
    }

    public void setOvcPerEnniEndPoint(List<OvcPerEnniEndpoint> ovcPerEnniEndPoint) {
        this.ovcPerEnniEndPoint = ovcPerEnniEndPoint;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EnniEndpoint)) {
            return false;
        }
        EnniEndpoint that = (EnniEndpoint) o;
        return Objects.equals(getEnniPtp(), that.getEnniPtp()) &&
                Objects.equals(getEnniLag(), that.getEnniLag()) &&
                Objects.equals(getEnniCfgIdentifier(), that.getEnniCfgIdentifier()) &&
                getEnniCfgPhyType() == that.getEnniCfgPhyType() &&
                getInterfaceCfgFrameFormat() == that.getInterfaceCfgFrameFormat() &&
                getEnniCfgNumberLinks() == that.getEnniCfgNumberLinks() &&
                getEnniCfgProtection() == that.getEnniCfgProtection() &&
                Objects.equals(getEnniMtu(), that.getEnniMtu()) &&
                Objects.equals(getOvcEndPointPerEnniCfgTble(), that.getOvcEndPointPerEnniCfgTble()) &&
                Objects.equals(getOvcEndPointPerVuniCfgTble(), that.getOvcEndPointPerVuniCfgTble()) &&
                Objects.equals(getEnniMaxNumberOvcs(), that.getEnniMaxNumberOvcs()) &&
                Objects.equals(getEnniCfgMaxNumberOvcEndPts(), that.getEnniCfgMaxNumberOvcEndPts()) &&
                Objects.equals(getOvcPerEnniEndPoint(), that.getOvcPerEnniEndPoint());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEnniPtp(), getEnniLag(), getEnniCfgIdentifier(), getEnniCfgPhyType(), getInterfaceCfgFrameFormat(), getEnniCfgNumberLinks(), getEnniCfgProtection(), getEnniMtu(), getOvcEndPointPerEnniCfgTble(), getOvcEndPointPerVuniCfgTble(), getEnniMaxNumberOvcs(), getEnniCfgMaxNumberOvcEndPts(), getOvcPerEnniEndPoint());
    }

    @Override
    public EndpointType getEndpointType() {
        return EndpointType.ENNI;
    }
}
