package com.ossnms.web.provider.mef.service.api.model.attributes.connection;

/**
 *
 */
public enum VirtualConnectionType {

    EVC,
    OVC

}
