package com.ossnms.web.provider.mef.service.model.enumerable;

public enum ActionType {
    CREATEANDACTIVATEMEFSERVICE("createAndActivateMefService"),
    CREATEMEFSERVICE("createMefService"),
    ACTIVATEMEFSERVICE("activateMefService"),
    DEACTIVATEANDDELETEMEFSERVICE("deactivateAndDeleteMefService"),
    DELETEMEFSERVICE("deleteMefService"),
    DEACTIVATEMEFSERVICE("deactivateMefService"),
    SUSPENDMEFSERVICE("suspendMefService"),
    RESUMEMEFSERVICE("resumeMefService"),
    SUSPENDUNI("suspendUni"),
    RESUMEUNI("resumeUni"),
    ADDUNITOEXISTINGMEFSERVICE("addUniToExistingMefService"),
    REMOVEUNIFROMEXISTINGMEFSERVICE("removeUniFromExistingMefService"),
    MODIFYMEFUNI("modifyMefUni"),
    MODIFYMEFEVC("modifyMefEvc"),
    STATUSMEFSERVICE("statusMefService");

    private final String value;

    ActionType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
