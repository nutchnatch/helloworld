package com.ossnms.web.provider.mef.service.model;

import com.ossnms.web.provider.common.api.model.EntityID;

import java.util.Objects;

public class ServiceID implements EntityID {

    private static final long serialVersionUID = -6958872404204427630L;

    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ServiceID)) {
            return false;
        }
        ServiceID serviceID = (ServiceID) o;
        return Objects.equals(getId(), serviceID.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }
}
