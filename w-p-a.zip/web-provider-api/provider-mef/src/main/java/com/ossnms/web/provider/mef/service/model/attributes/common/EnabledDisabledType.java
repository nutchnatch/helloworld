package com.ossnms.web.provider.mef.service.model.attributes.common;

public enum EnabledDisabledType {
    ENABLED("Enabled"),
    DISABLED("Disabled");

    private String value;

    EnabledDisabledType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value;
    }
}
