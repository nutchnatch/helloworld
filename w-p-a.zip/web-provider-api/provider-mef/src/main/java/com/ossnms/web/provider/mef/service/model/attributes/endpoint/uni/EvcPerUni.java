package com.ossnms.web.provider.mef.service.model.attributes.endpoint.uni;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.mef.service.model.attributes.common.EnabledDisabledType;

import java.util.Objects;

public class EvcPerUni implements EntityBase {

    private static final long serialVersionUID = 8760449416005742088L;

    private String evcPerUniCfgIdentifier; // maybe not required on creation - to check // concat identifier evc + identifier uni
    private EnabledDisabledType sourceMacAddressLimit; //not supported
    private Integer sourceMacAddressLimitN; //not supported
    private Integer sourceMacAddressLimitT; //not supported
    private EnabledDisabledType testMeg; //not supported
    private EnabledDisabledType subscriberMegMip; //not supported

    public EvcPerUni() {
    }

    public EvcPerUni(String mefServiceEvcPerUniCfgIdentifier, EnabledDisabledType mefSourceMacAddressLimit, Integer mefSourceMacAddressLimitN, Integer mefSourceMacAddressLimitT, EnabledDisabledType mefTestMeg, EnabledDisabledType mefSubscriberMegMip) {
        this.evcPerUniCfgIdentifier = mefServiceEvcPerUniCfgIdentifier;
        this.sourceMacAddressLimit = mefSourceMacAddressLimit;
        this.sourceMacAddressLimitN = mefSourceMacAddressLimitN;
        this.sourceMacAddressLimitT = mefSourceMacAddressLimitT;
        this.testMeg = mefTestMeg;
        this.subscriberMegMip = mefSubscriberMegMip;
    }

    public String getEvcPerUniCfgIdentifier() {
        return evcPerUniCfgIdentifier;
    }

    public void setEvcPerUniCfgIdentifier(String evcPerUniCfgIdentifier) {
        this.evcPerUniCfgIdentifier = evcPerUniCfgIdentifier;
    }

    public EnabledDisabledType getSourceMacAddressLimit() {
        return sourceMacAddressLimit;
    }

    public void setSourceMacAddressLimit(EnabledDisabledType sourceMacAddressLimit) {
        this.sourceMacAddressLimit = sourceMacAddressLimit;
    }

    public Integer getSourceMacAddressLimitN() {
        return sourceMacAddressLimitN;
    }

    public void setSourceMacAddressLimitN(Integer sourceMacAddressLimitN) {
        this.sourceMacAddressLimitN = sourceMacAddressLimitN;
    }

    public Integer getSourceMacAddressLimitT() {
        return sourceMacAddressLimitT;
    }

    public void setSourceMacAddressLimitT(Integer sourceMacAddressLimitT) {
        this.sourceMacAddressLimitT = sourceMacAddressLimitT;
    }

    public EnabledDisabledType getTestMeg() {
        return testMeg;
    }

    public void setTestMeg(EnabledDisabledType testMeg) {
        this.testMeg = testMeg;
    }

    public EnabledDisabledType getSubscriberMegMip() {
        return subscriberMegMip;
    }

    public void setSubscriberMegMip(EnabledDisabledType subscriberMegMip) {
        this.subscriberMegMip = subscriberMegMip;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EvcPerUni)) {
            return false;
        }
        EvcPerUni that = (EvcPerUni) o;
        return Objects.equals(getEvcPerUniCfgIdentifier(), that.getEvcPerUniCfgIdentifier()) &&
                getSourceMacAddressLimit() == that.getSourceMacAddressLimit() &&
                Objects.equals(getSourceMacAddressLimitN(), that.getSourceMacAddressLimitN()) &&
                Objects.equals(getSourceMacAddressLimitT(), that.getSourceMacAddressLimitT()) &&
                getTestMeg() == that.getTestMeg() &&
                getSubscriberMegMip() == that.getSubscriberMegMip();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEvcPerUniCfgIdentifier(), getSourceMacAddressLimit(), getSourceMacAddressLimitN(), getSourceMacAddressLimitT(), getTestMeg(), getSubscriberMegMip());
    }

    @Override
    public String toString() {
        return "EvcPerUni{" +
                "evcPerUniCfgIdentifier='" + evcPerUniCfgIdentifier + '\'' +
                ", sourceMacAddressLimit=" + sourceMacAddressLimit +
                ", sourceMacAddressLimitN=" + sourceMacAddressLimitN +
                ", sourceMacAddressLimitT=" + sourceMacAddressLimitT +
                ", testMeg=" + testMeg +
                ", subscriberMegMip=" + subscriberMegMip +
                '}';
    }
}
