package com.ossnms.web.provider.mef.service.model.attributes.common;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class FrameDeliveryCondition implements EntityBase {

    private static final long serialVersionUID = 3840286811481397914L;

    private String conditionName;
    private String value;

    public FrameDeliveryCondition(String conditionName, String value) {
        this.conditionName = conditionName;
        this.value = value;
    }

    public String getConditionName() {
        return conditionName;
    }

    public void setConditionName(String conditionName) {
        this.conditionName = conditionName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof FrameDeliveryCondition)) {
            return false;
        }
        FrameDeliveryCondition that = (FrameDeliveryCondition) o;
        return Objects.equals(getConditionName(), that.getConditionName()) &&
                Objects.equals(getValue(), that.getValue());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getConditionName(), getValue());
    }

    @Override
    public String toString() {
        return "FrameDeliveryCondition{" +
                "conditionName='" + conditionName + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
