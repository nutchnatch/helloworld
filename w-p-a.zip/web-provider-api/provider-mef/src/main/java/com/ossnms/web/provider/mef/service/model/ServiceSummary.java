package com.ossnms.web.provider.mef.service.model;

import com.ossnms.web.provider.common.api.model.EntitySummary;

import java.util.Objects;

public class ServiceSummary implements EntitySummary<ServiceID> {

    private static final long serialVersionUID = 4704994944588985511L;

    private ServiceID serviceID;
    private String name;


    @Override
    public ServiceID getID() {
        return serviceID;
    }

    public void setServiceID(ServiceID serviceID) {
        this.serviceID = serviceID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ServiceSummary)) {
            return false;
        }
        ServiceSummary that = (ServiceSummary) o;
        return Objects.equals(serviceID, that.serviceID) &&
                Objects.equals(getName(), that.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(serviceID, getName());
    }
}
