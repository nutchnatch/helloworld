package com.ossnms.web.provider.mef.service.model.attributes.endpoint.uni;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class EvcPerUniCfgCeVlanMap implements EntityBase {

    private static final long serialVersionUID = -8554443256294752908L;

    //    Untagged Only: Untagged = true and CeVlanMap  = 0
    //    CE-Vlan-ID: Untagged = false and CeVlanMap  = Ce-Vlan-ID value/range (1-4094)
    //    All-To-One: Untagged = false and CeVlanMap  = 4095 (4095 = any)
    //    EVC ID is included.
    private String ceVlanId; // ceVLanId = all -> PortBased | valores/rangeValores 1,2,3,4 ou 1-4 -> Cvlan based
    private String evcId; // nome (id) no evc

    public EvcPerUniCfgCeVlanMap(String ceVlanId, String evcId) {
        this.ceVlanId = ceVlanId;
        this.evcId = evcId;
    }

    public String getCeVlanId() {
        return ceVlanId;
    }

    public void setCeVlanId(String ceVlanId) {
        this.ceVlanId = ceVlanId;
    }

    public String getEvcId() {
        return evcId;
    }

    public void setEvcId(String evcId) {
        this.evcId = evcId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EvcPerUniCfgCeVlanMap)) {
            return false;
        }
        EvcPerUniCfgCeVlanMap that = (EvcPerUniCfgCeVlanMap) o;
        return Objects.equals(getCeVlanId(), that.getCeVlanId()) &&
                Objects.equals(getEvcId(), that.getEvcId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCeVlanId(), getEvcId());
    }
}
