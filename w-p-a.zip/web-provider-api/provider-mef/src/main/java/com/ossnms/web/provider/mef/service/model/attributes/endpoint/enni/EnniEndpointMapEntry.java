package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class EnniEndpointMapEntry implements EntityBase {

    private static final long serialVersionUID = 1376448336987856307L;

    private Integer svlanId;
    private String endPointIdentifier;
    private String endPointType;

    public EnniEndpointMapEntry(Integer svlanId, String endPointIdentifier, String endPointType) {
        this.svlanId = svlanId;
        this.endPointIdentifier = endPointIdentifier;
        this.endPointType = endPointType;
    }

    public Integer getSvlanId() {
        return svlanId;
    }

    public void setSvlanId(Integer svlanId) {
        this.svlanId = svlanId;
    }

    public String getEndPointIdentifier() {
        return endPointIdentifier;
    }

    public void setEndPointIdentifier(String endPointIdentifier) {
        this.endPointIdentifier = endPointIdentifier;
    }

    public String getEndPointType() {
        return endPointType;
    }

    public void setEndPointType(String endPointType) {
        this.endPointType = endPointType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EnniEndpointMapEntry)) {
            return false;
        }
        EnniEndpointMapEntry that = (EnniEndpointMapEntry) o;
        return Objects.equals(getSvlanId(), that.getSvlanId()) &&
                Objects.equals(getEndPointIdentifier(), that.getEndPointIdentifier()) &&
                Objects.equals(getEndPointType(), that.getEndPointType());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSvlanId(), getEndPointIdentifier(), getEndPointType());
    }
}
