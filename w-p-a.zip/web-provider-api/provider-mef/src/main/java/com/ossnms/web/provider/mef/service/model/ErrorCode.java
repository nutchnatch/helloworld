package com.ossnms.web.provider.mef.service.model;

public enum ErrorCode {
    ERROR
}
