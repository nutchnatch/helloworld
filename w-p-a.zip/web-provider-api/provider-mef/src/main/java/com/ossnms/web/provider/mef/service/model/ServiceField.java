package com.ossnms.web.provider.mef.service.model;

public enum ServiceField {
    NAME
}
