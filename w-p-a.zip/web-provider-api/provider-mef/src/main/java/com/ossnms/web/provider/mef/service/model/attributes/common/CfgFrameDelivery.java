package com.ossnms.web.provider.mef.service.model.attributes.common;

public enum CfgFrameDelivery {
    DISCARD("Discard"),
    UNCONDITIONALLY("Unconditionally"),
    CONDITIONALLY("Conditionally");

    private String value;

    CfgFrameDelivery(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
