package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class EnniSvlanMapEntry implements EntityBase {

    private static final long serialVersionUID = -948580496293830135L;

    private Boolean ingressRoot;
    private Boolean ingressLeaf;
    private Integer ingressLeafSVID;
    private Integer ingressRootSVID;
    private Boolean egressRoot;
    private Boolean egressLeaf;
    private Integer egressLeafSVID;
    private Integer egressRootSVID;

    public EnniSvlanMapEntry() {
    }

    public Boolean getIngressRoot() {
        return ingressRoot;
    }

    public void setIngressRoot(Boolean ingressRoot) {
        this.ingressRoot = ingressRoot;
    }

    public Boolean getIngressLeaf() {
        return ingressLeaf;
    }

    public void setIngressLeaf(Boolean ingressLeaf) {
        this.ingressLeaf = ingressLeaf;
    }

    public Integer getIngressLeafSVID() {
        return ingressLeafSVID;
    }

    public void setIngressLeafSVID(Integer ingressLeafSVID) {
        this.ingressLeafSVID = ingressLeafSVID;
    }

    public Integer getIngressRootSVID() {
        return ingressRootSVID;
    }

    public void setIngressRootSVID(Integer ingressRootSVID) {
        this.ingressRootSVID = ingressRootSVID;
    }

    public Boolean getEgressRoot() {
        return egressRoot;
    }

    public void setEgressRoot(Boolean egressRoot) {
        this.egressRoot = egressRoot;
    }

    public Boolean getEgressLeaf() {
        return egressLeaf;
    }

    public void setEgressLeaf(Boolean egressLeaf) {
        this.egressLeaf = egressLeaf;
    }

    public Integer getEgressLeafSVID() {
        return egressLeafSVID;
    }

    public void setEgressLeafSVID(Integer egressLeafSVID) {
        this.egressLeafSVID = egressLeafSVID;
    }

    public Integer getEgressRootSVID() {
        return egressRootSVID;
    }

    public void setEgressRootSVID(Integer egressRootSVID) {
        this.egressRootSVID = egressRootSVID;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EnniSvlanMapEntry)) {
            return false;
        }
        EnniSvlanMapEntry that = (EnniSvlanMapEntry) o;
        return Objects.equals(getIngressRoot(), that.getIngressRoot()) &&
                Objects.equals(getIngressLeaf(), that.getIngressLeaf()) &&
                Objects.equals(getIngressLeafSVID(), that.getIngressLeafSVID()) &&
                Objects.equals(getIngressRootSVID(), that.getIngressRootSVID()) &&
                Objects.equals(getEgressRoot(), that.getEgressRoot()) &&
                Objects.equals(getEgressLeaf(), that.getEgressLeaf()) &&
                Objects.equals(getEgressLeafSVID(), that.getEgressLeafSVID()) &&
                Objects.equals(getEgressRootSVID(), that.getEgressRootSVID());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIngressRoot(), getIngressLeaf(), getIngressLeafSVID(), getIngressRootSVID(), getEgressRoot(), getEgressLeaf(), getEgressLeafSVID(), getEgressRootSVID());
    }
}
