package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

public enum EnnicfgProtection {
    NONE("none"),
    LINK_AGGREGATION("Link Aggregation"),
    OTHER("other");

    private String value;

    EnnicfgProtection(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
