package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.List;
import java.util.Objects;

public class OvcPerEnniEndpoint implements EntityBase {

    private static final long serialVersionUID = -7690692929750271965L;

    private String ovcEndPointPerEnniCfgIdentifier;
    private OvcEndpointPerEnniCfgRole ovcEndPointPerEnniCfgRole;
    private List<EnniSvlanMapEntry> ovcEndPtPerEnniCfgSvlanMap;
    private StagPcpType cosCfgEntry;
//    mefServiceOvcEndPtPerEnniCfgIngressBwp
//    mefServiceOvcEndPtPerEnniCfgEgressBwp
//    mefServiceOvcEndPtPerEnniCosIdCfgIngressBwp
//    mefServiceOvcEndPtPerEnniCosIdCfgEgressBwp

    public String getOvcEndPointPerEnniCfgIdentifier() {
        return ovcEndPointPerEnniCfgIdentifier;
    }

    public void setOvcEndPointPerEnniCfgIdentifier(String ovcEndPointPerEnniCfgIdentifier) {
        this.ovcEndPointPerEnniCfgIdentifier = ovcEndPointPerEnniCfgIdentifier;
    }

    public OvcEndpointPerEnniCfgRole getOvcEndPointPerEnniCfgRole() {
        return ovcEndPointPerEnniCfgRole;
    }

    public void setOvcEndPointPerEnniCfgRole(OvcEndpointPerEnniCfgRole ovcEndPointPerEnniCfgRole) {
        this.ovcEndPointPerEnniCfgRole = ovcEndPointPerEnniCfgRole;
    }

    public List<EnniSvlanMapEntry> getOvcEndPtPerEnniCfgSvlanMap() {
        return ovcEndPtPerEnniCfgSvlanMap;
    }

    public void setOvcEndPtPerEnniCfgSvlanMap(List<EnniSvlanMapEntry> ovcEndPtPerEnniCfgSvlanMap) {
        this.ovcEndPtPerEnniCfgSvlanMap = ovcEndPtPerEnniCfgSvlanMap;
    }

    public StagPcpType getStagPcp() {
        return cosCfgEntry;
    }

    public void setStagPcp(StagPcpType mefServiceCosCfgEntry) {
        this.cosCfgEntry = mefServiceCosCfgEntry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof OvcPerEnniEndpoint)) {
            return false;
        }
        OvcPerEnniEndpoint that = (OvcPerEnniEndpoint) o;
        return Objects.equals(getOvcEndPointPerEnniCfgIdentifier(), that.getOvcEndPointPerEnniCfgIdentifier()) &&
                getOvcEndPointPerEnniCfgRole() == that.getOvcEndPointPerEnniCfgRole() &&
                Objects.equals(getOvcEndPtPerEnniCfgSvlanMap(), that.getOvcEndPtPerEnniCfgSvlanMap()) &&
                Objects.equals(getStagPcp(), that.getStagPcp());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getOvcEndPointPerEnniCfgIdentifier(), getOvcEndPointPerEnniCfgRole(), getOvcEndPtPerEnniCfgSvlanMap(), getStagPcp());
    }
}
