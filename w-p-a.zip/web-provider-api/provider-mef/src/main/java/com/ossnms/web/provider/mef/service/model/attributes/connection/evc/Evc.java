package com.ossnms.web.provider.mef.service.model.attributes.connection.evc;

import com.ossnms.web.provider.mef.service.api.model.attributes.connection.VirtualConnection;
import com.ossnms.web.provider.mef.service.api.model.attributes.connection.VirtualConnectionType;
import com.ossnms.web.provider.mef.service.model.attributes.common.CfgServiceType;
import com.ossnms.web.provider.mef.service.model.attributes.common.EnabledDisabledType;

import java.util.Objects;

public class Evc implements VirtualConnection {

    private static final long serialVersionUID = 1241079359579948129L;

    private CfgServiceType evcCfgServiceType;
    private Integer evcCfgIdentifier;
    //    mefServiceEvcUniCfgTable
    private Integer evcStatusMaxNumUni;     // range of values [2, 16384]
    private Integer evcCfgMtuSize;          // range of values [1552, 16384]
    private EnabledDisabledType evcCfgCevlanIdPreservation;
    private EnabledDisabledType evcCfgCevlanCosPreservation;
    private FrameDelivery frameDelivery;

    public Evc(CfgServiceType evcCfgServiceType, Integer evcCfgIdentifier, Integer evcStatusMaxNumUni, Integer evcCfgMtuSize, EnabledDisabledType evcCfgCevlanIdPreservation, EnabledDisabledType evcCfgCevlanCosPreservation, FrameDelivery frameDelivery) {
        this.evcCfgServiceType = evcCfgServiceType;
        this.evcCfgIdentifier = evcCfgIdentifier;
        this.evcStatusMaxNumUni = evcStatusMaxNumUni;
        this.evcCfgMtuSize = evcCfgMtuSize;
        this.evcCfgCevlanIdPreservation = evcCfgCevlanIdPreservation;
        this.evcCfgCevlanCosPreservation = evcCfgCevlanCosPreservation;
        this.frameDelivery = frameDelivery;
    }

    public CfgServiceType getEvcCfgServiceType() {
        return evcCfgServiceType;
    }

    public void setEvcCfgServiceType(CfgServiceType evcCfgServiceType) {
        this.evcCfgServiceType = evcCfgServiceType;
    }

    public Integer getEvcCfgIdentifier() {
        return evcCfgIdentifier;
    }

    public void setEvcCfgIdentifier(Integer evcCfgIdentifier) {
        this.evcCfgIdentifier = evcCfgIdentifier;
    }

    public Integer getEvcStatusMaxNumUni() {
        return evcStatusMaxNumUni;
    }

    public void setEvcStatusMaxNumUni(Integer evcStatusMaxNumUni) {
        this.evcStatusMaxNumUni = evcStatusMaxNumUni;
    }

    public Integer getEvcCfgMtuSize() {
        return evcCfgMtuSize;
    }

    public void setEvcCfgMtuSize(Integer evcCfgMtuSize) {
        this.evcCfgMtuSize = evcCfgMtuSize;
    }

    public EnabledDisabledType getEvcCfgCevlanIdPreservation() {
        return evcCfgCevlanIdPreservation;
    }

    public void setEvcCfgCevlanIdPreservation(EnabledDisabledType evcCfgCevlanIdPreservation) {
        this.evcCfgCevlanIdPreservation = evcCfgCevlanIdPreservation;
    }

    public EnabledDisabledType getEvcCfgCevlanCosPreservation() {
        return evcCfgCevlanCosPreservation;
    }

    public void setEvcCfgCevlanCosPreservation(EnabledDisabledType evcCfgCevlanCosPreservation) {
        this.evcCfgCevlanCosPreservation = evcCfgCevlanCosPreservation;
    }

    public FrameDelivery getFrameDelivery() {
        return frameDelivery;
    }

    public void setFrameDelivery(FrameDelivery frameDelivery) {
        this.frameDelivery = frameDelivery;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Evc)) {
            return false;
        }
        Evc evc = (Evc) o;
        return getEvcCfgServiceType() == evc.getEvcCfgServiceType() &&
                Objects.equals(getEvcCfgIdentifier(), evc.getEvcCfgIdentifier()) &&
                Objects.equals(getEvcStatusMaxNumUni(), evc.getEvcStatusMaxNumUni()) &&
                Objects.equals(getEvcCfgMtuSize(), evc.getEvcCfgMtuSize()) &&
                getEvcCfgCevlanIdPreservation() == evc.getEvcCfgCevlanIdPreservation() &&
                getEvcCfgCevlanCosPreservation() == evc.getEvcCfgCevlanCosPreservation() &&
                Objects.equals(getFrameDelivery(), evc.getFrameDelivery());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEvcCfgServiceType(), getEvcCfgIdentifier(), getEvcStatusMaxNumUni(), getEvcCfgMtuSize(), getEvcCfgCevlanIdPreservation(), getEvcCfgCevlanCosPreservation(), getFrameDelivery());
    }

    @Override
    public VirtualConnectionType getVirtualConnectionType() {
        return VirtualConnectionType.EVC;
    }
}
