package com.ossnms.web.provider.mef.service.model.attributes.endpoint.enni;

import com.ossnms.web.provider.common.api.model.EntityBase;

import java.util.Objects;

public class StagPcpType implements EntityBase {

    private static final long serialVersionUID = 67806041056643821L;

    private String stagPcp;
    private String classOfServiceName;

    public StagPcpType(String stagPcp, String classOfServiceName) {
        this.stagPcp = stagPcp;
        this.classOfServiceName = classOfServiceName;
    }

    public String getStagPcp() {
        return stagPcp;
    }

    public void setStagPcp(String stagPcp) {
        this.stagPcp = stagPcp;
    }

    public String getClassOfServiceName() {
        return classOfServiceName;
    }

    public void setClassOfServiceName(String classOfServiceName) {
        this.classOfServiceName = classOfServiceName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof StagPcpType)) {
            return false;
        }
        StagPcpType stagPcp1 = (StagPcpType) o;
        return Objects.equals(getStagPcp(), stagPcp1.getStagPcp()) &&
                Objects.equals(getClassOfServiceName(), stagPcp1.getClassOfServiceName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getStagPcp(), getClassOfServiceName());
    }
}
