package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.ne.ExportNeTransformer;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.ERROR;
import static java.util.stream.Collectors.toList;

public class ExportNes<C extends CallContext> extends Command<C, Collection<NeValueObject>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExportNes.class);
    private final Collection<INE> nes;
    private final NeEntityRepository neRepository;
    private final LoggerManager<C> loggerManager;
    private final ExportNeTransformer neTransformer;

    public ExportNes(C context, 
                     Collection<INE> nes, 
                     NeEntityRepository neRepository, 
                     LoggerManager<C> loggerManager, 
                     ExportNeTransformer neTransformer) {
        super(context);
        this.nes = nes;
        this.neRepository = neRepository;
        this.loggerManager = loggerManager;
        this.neTransformer = neTransformer;
    }

    @Override public Collection<NeValueObject> call() {
        return nes.stream()
                .map(this::fetchNe)
                .flatMap(option -> option.map(Stream::of).orElseGet(Stream::empty))
                .map(neTransformer)
                .flatMap(option -> option.map(Stream::of).orElseGet(Stream::empty))
                .collect(toList());
    }

    private Optional<NeEntity> fetchNe(INE ne) {
        try {
            return neRepository.queryNe(ne.getId());
        } catch (RepositoryException e) {
            loggerManager.createSystemEventLog(getContext(), new LoggerItemNe(ne.getIdName(), e.getMessage(), ne.getId(), ERROR));
            LOGGER.error("Failed to fetch ne {}", ne, e);
        }
        return Optional.empty();
    }
}
