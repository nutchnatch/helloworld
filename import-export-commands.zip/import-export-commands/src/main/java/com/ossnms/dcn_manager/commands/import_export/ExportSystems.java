package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.system.ExportSystemTransformer;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static java.util.stream.StreamSupport.stream;

public class ExportSystems<C extends CallContext> extends Command<C, Collection<SystemValueObject>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExportSystems.class);
    private final SystemRepository systemRepository;
    private final ExportSystemTransformer systemTransformer;

    public ExportSystems(C context, SystemRepository systemRepository, ExportSystemTransformer systemTransformer) {
        super(context);
        this.systemRepository = systemRepository;
        this.systemTransformer = systemTransformer;
    }

    @Override public Collection<SystemValueObject> call() {
        return fetchSystems()
                .map(systemTransformer)
                .collect(toList());
    }

    private Stream<SystemInfo> fetchSystems() {
        try {
            return stream(systemRepository.queryAll().spliterator(), false);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch systems", e);
            return Stream.empty();
        }
    }
}
