package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.Either;
import com.ossnms.dcn_manager.composables.import_export.ne.ImportNeTransformer;
import com.ossnms.dcn_manager.composables.ne.NeCreationBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.import_export.identification.GenericContainerIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.NeIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.AssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableContainerValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.exceptions.DataCreationException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.DuplicatedRouteException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.composables.import_export.Either.left;
import static com.ossnms.dcn_manager.composables.import_export.Either.right;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.ERROR;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.WARNING;
import static com.ossnms.dcn_manager.i18n.Message.NE_ERROR_TO_IMPORT;
import static com.ossnms.dcn_manager.i18n.Message.NE_EXISTS;
import static com.ossnms.dcn_manager.i18n.Message.NE_IMPORTED;
import static com.ossnms.dcn_manager.i18n.Message.NE_MISSING_NAME;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public class ImportNEs<C extends CallContext> extends Command<C, Collection<String>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImportNEs.class);

    private final ContainersNeAssignmentUpdater<C> containersNeAssignmentUpdater;
    private final Collection<NeValueObject> nes;
    private final NeIdentification neIdentification;
    private final LoggerManager<C> loggerManager;

    private final ImportNeTransformer toCreationDescriptor;
    private final GenericContainerIdentification containerIdentification;
    private final NeCreationBase<C> neCreationBase;

    public ImportNEs(
            @Nonnull final C context,
            @Nonnull final Collection<NeValueObject> nes,
            @Nonnull final LoggerManager<C> loggerManager,
            @Nonnull final ContainersNeAssignmentUpdater<C> containersNeAssignmentUpdater,
            @Nonnull final NeIdentification neIdentification,
            @Nonnull final GenericContainerIdentification containerIdentification,
            @Nonnull final ImportNeTransformer neTransformer, NeCreationBase<C> neCreationBase) {
        super(context);
        this.nes = nes;
        this.loggerManager = loggerManager;
        this.containersNeAssignmentUpdater = containersNeAssignmentUpdater;

        this.neIdentification = neIdentification;
        this.containerIdentification = containerIdentification;
        toCreationDescriptor = neTransformer;

        this.neCreationBase = neCreationBase;
    }

    @Override
    public Collection<String> call() {
        return nes.stream()
                .map(this::validateNe)
                .map(validValue -> validValue.flatMap(this::withDescriptor))
                .map(withDescriptor -> withDescriptor.flatMap(pair -> createNE(pair.getRight(), pair.getLeft())))
                .peek(result -> result.ifLeft(this::toSEL)) // Push errors to SEL
                .flatMap(result -> result.mapLeft(LoggerItem::getMessage).leftStream())
                .collect(toList());
    }

    private Either<LoggerItem, Pair<NeValueObject, NeCreateDescriptor>> withDescriptor(NeValueObject neValueObject) {
        return toCreationDescriptor.apply(neValueObject).mapRight(descriptor -> Pair.of(neValueObject, descriptor));
    }

    /**
     * @return Either error log item or the same valid ne value object
     */
    private Either<LoggerItem, NeValueObject> validateNe(NeValueObject ne) {
        return validateName(ne).flatMap(this::validateNotExists);
    }

    private Either<LoggerItem, NeValueObject> validateName(NeValueObject ne) {
        return isNotEmpty(ne.getName())
                ? right(ne)
                : left(new LoggerItemNe(ne.getName(), tr(NE_MISSING_NAME, ne.getType()), -1, WARNING));
    }

    private Either<LoggerItem, NeValueObject> validateNotExists(NeValueObject ne) {
        return neIdentification.notExists(ne)
                ? right(ne)
                : left(new LoggerItemNe(ne.getName(), tr(NE_EXISTS, ne.getName()), -1, WARNING));
    }

    private void toSEL(LoggerItem logItem) {
        loggerManager.createSystemEventLog(getContext(), logItem);
    }

    /**
     * @return Either error log item or log item with progress information
     */
    private Either<LoggerItem, LoggerItem> createNE(final NeCreateDescriptor descriptor, NeValueObject value) {
        final String neName = descriptor.getPreferences().getName();
        try {
            final NeEntity neEntity = neCreationBase.tryCreateNe(descriptor);
            assignContainers(value, neEntity);

            return right(new LoggerItemNe(neName, tr(NE_IMPORTED, neName), neEntity.getInfo().getNeId()));
        } catch (final UnknownChannelIdException | DuplicatedRouteException | DuplicatedObjectNameException e) {
            LOGGER.error(e.getMessage(), e);
            return left(new LoggerItemNe(neName, e.getMessage(), -1, ERROR));
        } catch (final RepositoryException | DataCreationException e) {
            LOGGER.error("Error to import NE", e);
            return left(new LoggerItemNe(neName, tr(NE_ERROR_TO_IMPORT, neName), -1, ERROR));
        }
    }

    private void assignContainers(NeValueObject value, NeEntity neEntity) throws RepositoryException {
        Optional<Integer> system = neEntity.getPreferences().getContainerId().filter(id -> id != 0);
        if (system.isPresent()) {
            return; //no containers if under system
        }

        Set<NeAssignmentData> assignments = value.getAssignedContainers().stream()
                .map(assignedContainer -> resolveAssignment(neEntity, assignedContainer))
                .flatMap(opt -> opt.map(Stream::of).orElseGet(Stream::empty))
                .collect(toSet());

        if (assignments.isEmpty()) {
            containersNeAssignmentUpdater.defaultNeAssignment(neEntity.getPreferences());
        } else {
            containersNeAssignmentUpdater.store(assignments, neEntity.getPreferences());
        }
    }

    private Optional<NeAssignmentData> resolveAssignment(NeEntity neEntity, AssignedContainer assignedContainer) {
        return containerIdentification
                .tryIdentify(ImmutableContainerValueObject.of(assignedContainer.idName()))
                .map(containerInfo -> new NeAssignmentData(
                        containerInfo,
                        neEntity.getInfo().getNeId(),
                        AssignmentType.fromFlag(assignedContainer.isPrimary())));
    }
}
