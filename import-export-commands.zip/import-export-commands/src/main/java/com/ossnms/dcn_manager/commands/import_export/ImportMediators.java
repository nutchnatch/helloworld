package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.Either;
import com.ossnms.dcn_manager.composables.import_export.mediator.ImportMediatorTransformer;
import com.ossnms.dcn_manager.composables.mediator.MediatorCreationBase;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.import_export.identification.MediatorIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.exceptions.DuplicatedHostException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;

import static com.ossnms.dcn_manager.composables.import_export.Either.left;
import static com.ossnms.dcn_manager.composables.import_export.Either.right;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.ERROR;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.WARNING;
import static com.ossnms.dcn_manager.i18n.Message.DUPLICATED_MEDIATOR_HOST;
import static com.ossnms.dcn_manager.i18n.Message.MEDIATOR_ERROR_TO_IMPORT;
import static com.ossnms.dcn_manager.i18n.Message.MEDIATOR_IMPORTED;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.stream.Collectors.toList;

public class ImportMediators<C extends CallContext> extends Command<C, Collection<String>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImportMediators.class);

    private final Collection<MediatorValueObject> mediators;
    private final MediatorIdentification mediatorIdentification;
    private final MediatorCreationBase<C> mediatorCreation;
    private final LoggerManager<C> loggerManager;
    private final ImportMediatorTransformer toCreationDescriptor;

    public ImportMediators(
            @Nonnull final C context,
            @Nonnull final Collection<MediatorValueObject> mediators,
            @Nonnull final LoggerManager<C> loggerManager, 
            ImportMediatorTransformer mediatorTransformer, 
            MediatorCreationBase<C> mediatorCreation, 
            MediatorIdentification mediatorIdentification) {
        super(context);
        this.mediators = mediators;
        this.loggerManager = loggerManager;
        this.mediatorIdentification = mediatorIdentification;
        this.mediatorCreation = mediatorCreation;
        toCreationDescriptor = mediatorTransformer;
    }

    @Override
    public Collection<String> call() {
        return mediators.stream()
                .map(this::validateNotExists)
                .map(validated -> validated.flatMap(toCreationDescriptor))
                .map(descriptor -> descriptor.flatMap(this::createMediator))
                .peek(result -> result.ifLeft(this::toSEL)) // Push errors to SEL
                .flatMap(result -> result.mapLeft(LoggerItem::getMessage).leftStream())
                .collect(toList());
    }

    private Either<LoggerItem, MediatorValueObject> validateNotExists(MediatorValueObject mediator) {
        return mediatorIdentification.notExists(mediator)
                ? right(mediator)
                : left(duplicatedMediatorLogItem(mediator));
    }
    
    private void toSEL(LoggerItem logItem) {
        loggerManager.createSystemEventLog(getContext(), logItem);
    }

    private LoggerItem duplicatedMediatorLogItem(MediatorValueObject mediator) {
        final String message = tr(DUPLICATED_MEDIATOR_HOST, mediator.getType(), mediator.getHost(), mediator.getName());
        return new LoggerItemMediator(mediator.getName(), message, WARNING);
    }

    private Either<LoggerItem, LoggerItem> createMediator(final MediatorCreateDescriptor mediator) {
        final String mediatorName = mediator.getInfoInitialData().getName();
        try {
            mediatorCreation.tryCreateMediator(mediator);
            return right(new LoggerItemMediator(mediatorName, tr(MEDIATOR_IMPORTED, mediatorName)));
        } catch (final UnknownMediatorTypeException | DuplicatedObjectNameException | DuplicatedHostException e) {
            LOGGER.error(e.getMessage(), e);
            return left(new LoggerItemMediator(mediatorName, e.getMessage(), ERROR));
        } catch (final RepositoryException e) {
            LOGGER.error("Error to import mediator", e);
            return left(new LoggerItemMediator(mediatorName, tr(MEDIATOR_ERROR_TO_IMPORT, mediatorName), ERROR));
        }
    }
}
