package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.container.ContainerCreationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.container.ImportContainerTransformer;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;

public class ImportContainers<C extends CallContext> extends Command<C, Collection<String>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ImportContainers.class);
    private final ImportContainerTransformer containerTransformer;
    private final Collection<ContainerValueObject> containers;
    private final ContainerCreationBase<C> creation;

    public ImportContainers(@Nonnull C context,
                            Collection<ContainerValueObject> containers,
                            ContainerCreationBase<C> containerCreationBase,
                            ImportContainerTransformer containerTransformer) {
        super(context);
        this.containers = containers;
        this.containerTransformer = containerTransformer;
        creation = containerCreationBase;
    }

    @Override public Collection<String> call() {
        return containers.stream()
                .map(containerTransformer).flatMap(this::optionAsStream)
                .map(this::createContainer).flatMap(this::optionAsStream)
                .collect(toList());
    }

    private Optional<String> createContainer(ContainerCreationDescriptor descriptor) {
        try {
            creation.tryCreateContainer(descriptor);
        } catch (RepositoryException | DuplicatedObjectNameException e) {
            //todo provide user a proper error message
            LOGGER.error("Failed to create container", e);
        }
        return Optional.empty();
    }

    private <T> Stream<T> optionAsStream(Optional<T> optional) {
        return optional.map(Stream::of).orElseGet(Stream::empty);
    }
}
