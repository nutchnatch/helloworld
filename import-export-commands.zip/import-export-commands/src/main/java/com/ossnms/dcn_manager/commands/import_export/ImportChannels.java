package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.channel.ChannelCreationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.Either;
import com.ossnms.dcn_manager.composables.import_export.channel.ImportChannelTransformer;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.import_export.identification.ChannelIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;

import static com.ossnms.dcn_manager.composables.import_export.Either.left;
import static com.ossnms.dcn_manager.composables.import_export.Either.right;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.ERROR;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.WARNING;
import static com.ossnms.dcn_manager.i18n.Message.CHANNEL_ALREADY_EXISTS;
import static com.ossnms.dcn_manager.i18n.Message.CHANNEL_ERROR_TO_IMPORT;
import static com.ossnms.dcn_manager.i18n.Message.CHANNEL_IMPORTED;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.stream.Collectors.toList;

public class ImportChannels<C extends CallContext> extends Command<C, Collection<String>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImportChannels.class);

    private final Collection<ChannelValueObject> channels;
    private final ChannelIdentification channelIdentification;
    private final LoggerManager<C> loggerManager;
    private final ChannelCreationBase<C> channelCreation;
    private final ImportChannelTransformer toCreationDescriptor;

    public ImportChannels(
            @Nonnull final C context,
            @Nonnull final Collection<ChannelValueObject> channels,
            @Nonnull final LoggerManager<C> loggerManager, 
            ChannelIdentification channelIdentification, 
            ChannelCreationBase<C> channelCreation, 
            ImportChannelTransformer channelTransformer) {
        super(context);
        this.channels = channels;
        this.loggerManager = loggerManager;
        this.channelIdentification = channelIdentification;
        this.channelCreation = channelCreation;
        toCreationDescriptor = channelTransformer;
    }

    @Override
    public Collection<String> call() {
        return channels.stream()
                .map(this::validateNotExists)
                .map(validated -> validated.flatMap(toCreationDescriptor))
                .map(descriptor -> descriptor.flatMap(this::createChannel))
                .peek(result -> result.ifLeft(this::toSEL)) // Push errors to SEL
                .flatMap(result -> result.mapLeft(LoggerItem::getMessage).leftStream())
                .collect(toList());
    }

    private void toSEL(LoggerItem logItem) {
        loggerManager.createSystemEventLog(getContext(), logItem);
    }

    private Either<LoggerItem, ChannelValueObject> validateNotExists(ChannelValueObject channelValueObject) {
        return channelIdentification.notExists(channelValueObject)
                ? right(channelValueObject)
                : left(new LoggerItemChannel(channelValueObject.getName(), tr(CHANNEL_ALREADY_EXISTS, channelValueObject.getName()), WARNING));
    }

    private Either<LoggerItem, LoggerItem> createChannel(final ChannelCreateDescriptor channel) {
        final String channelName = channel.getPreferencesInitialData().getName();
        try {
            channelCreation.tryCreateChannel(channel);
            return right(new LoggerItemChannel(channelName, tr(CHANNEL_IMPORTED, channelName)));
        } catch (final DuplicatedObjectNameException | UnknownMediatorIdException e) {
            LOGGER.error(e.getMessage(), e);
            return left(new LoggerItemChannel(channelName, e.getMessage(), ERROR));
        } catch (final RepositoryException e) {
            LOGGER.error("Error to import mediator", e);
            return left(new LoggerItemChannel(channelName, tr(CHANNEL_ERROR_TO_IMPORT, channelName), ERROR));
        }
    }
}
