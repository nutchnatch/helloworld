package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.mediator.ExportMediatorTransformer;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;

import static com.google.common.collect.Iterables.isEmpty;
import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.ERROR;
import static java.util.stream.Collectors.toList;

public class ExportMediators<C extends CallContext> extends Command<C, Collection<MediatorValueObject>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportMediators.class);
    private final Collection<IMediator> mediatorIds;
    private final MediatorManagers mediatorManagers;
    private final LoggerManager<C> loggerManager;

    public ExportMediators(@Nonnull C context, Collection<IMediator> mediatorIds,
            MediatorManagers mediatorManagers, LoggerManager<C> loggerManager) {
        super(context);
        this.mediatorIds = mediatorIds;
        this.mediatorManagers = mediatorManagers;
        this.loggerManager = loggerManager;
    }

    @Override public Collection<MediatorValueObject> call() {
        return mediatorIds.stream()
                .map(this::fetchMediator)
                .flatMap(option -> option.map(Stream::of).orElseGet(Stream::empty))
                .map(ExportMediatorTransformer::apply)
                .collect(toList());
    }

    private Optional<Pair<MediatorEntity, Iterable<MediatorInstance>>> fetchMediator(IMediator mediator) {
        try {
            final MediatorEntity mediatorEntity = mediatorManagers.getMediatorRepository().query(mediator.getId()).orElse(null);
            final Iterable<MediatorInstance> mediatorInstances = mediatorManagers.getMediatorInstanceRepository()
                    .queryAll(mediator.getId());

            if (null != mediatorEntity || !isEmpty(mediatorInstances)) {
                return Optional.of(ImmutablePair.of(mediatorEntity, mediatorInstances));
            }
        } catch (RepositoryException e) {
            loggerManager.createSystemEventLog(getContext(), new LoggerItemMediator(mediator.getIdName(), e.getMessage(), ERROR));
            LOGGER.error("Failed to fetch mediator {}", mediator, e);
        }

        return Optional.empty();
    }
}
