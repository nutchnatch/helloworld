package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.container.ContainersSystemAssignmentUpdater;
import com.ossnms.dcn_manager.composables.container.SystemCreationBase;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.system.ImportSystemTransformer;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.import_export.identification.GenericContainerIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.AssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableContainerValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toSet;

public class ImportSystems<C extends CallContext> extends Command<C, Collection<String>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImportSystems.class);

    private final Collection<SystemValueObject> systems;
    private final ImportSystemTransformer importSystemTransformer;
    private final SystemCreationBase<C> creationBase;
    private final ContainersSystemAssignmentUpdater<C> assignmentUpdater;
    private final GenericContainerIdentification containerIdentification;

    public ImportSystems(@Nonnull C context,
                         @Nonnull Collection<SystemValueObject> systems,
                         @Nonnull ImportSystemTransformer importSystemTransformer,
                         @Nonnull SystemCreationBase<C> creationBase,
                         @Nonnull ContainersSystemAssignmentUpdater<C> assignmentUpdater,
                         @Nonnull GenericContainerIdentification containerIdentification) {
        super(context);
        this.systems = systems;
        this.importSystemTransformer = importSystemTransformer;
        this.creationBase = creationBase;
        this.assignmentUpdater = assignmentUpdater;
        this.containerIdentification = containerIdentification;
    }

    @Override public Collection<String> call() {
        systems.stream()
                .map(value -> importSystemTransformer.apply(value).map(descriptor -> Pair.of(descriptor, value)))
                .flatMap(this::optionAsStream)
                .forEach(pair -> createSystem(pair.getRight(), pair.getLeft()));

        return Collections.emptyList();
    }

    private void createSystem(SystemValueObject value, SystemCreationDescriptor systemCreationDescriptor) {
        creationBase.tryCreateSystem(systemCreationDescriptor)
                .ifPresent(systemInfo -> assignContainers(value, systemInfo));
    }

    private void assignContainers(SystemValueObject value, SystemInfo systemInfo) {
        Set<SystemAssignmentData> assignments = value.assignedContainers().stream()
                .map(assignedContainer -> resolveAssignment(systemInfo, assignedContainer))
                .flatMap(opt -> opt.map(Stream::of).orElseGet(Stream::empty))
                .collect(toSet());

        try {
            if (assignments.isEmpty()) {
                assignmentUpdater.defaultSystemAssignment(systemInfo);
            } else {
                assignmentUpdater.store(assignments, systemInfo);
            }
        } catch (RepositoryException e) {
            LOGGER.error("Failed to assign containers", e);
        }
    }

    private Optional<SystemAssignmentData> resolveAssignment(SystemInfo systemInfo, AssignedContainer assignedContainer) {
        return containerIdentification
                .tryIdentify(ImmutableContainerValueObject.of(assignedContainer.idName()))
                .map(containerInfo -> new SystemAssignmentData(
                        containerInfo,
                        systemInfo.getId(),
                        AssignmentType.fromFlag(assignedContainer.isPrimary())));
    }

    private <T> Stream<T> optionAsStream(Optional<T> optional) {
        return optional.map(Stream::of).orElseGet(Stream::empty);
    }
}
