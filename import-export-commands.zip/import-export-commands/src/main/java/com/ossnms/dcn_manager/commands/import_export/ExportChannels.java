package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.channel.ExportChannelTransformer;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.ERROR;
import static java.util.stream.Collectors.toList;

public class ExportChannels<C extends CallContext> extends Command<C, Collection<ChannelValueObject>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportChannels.class);
    private final Collection<IEM> ems;
    private final ChannelEntityRepository channelRepository;
    private final LoggerManager<C> loggerManager;
    private final ExportChannelTransformer channelTransformer;

    public ExportChannels(C context, 
                          Collection<IEM> ems, 
                          ChannelEntityRepository channelRepository,
                          LoggerManager<C> loggerManager, 
                          ExportChannelTransformer channelTransformer) {
        super(context);
        this.ems = ems;
        this.channelRepository = channelRepository;
        this.loggerManager = loggerManager;
        this.channelTransformer = channelTransformer;
    }

    @Override public Collection<ChannelValueObject> call() {
        return ems.stream()
                .map(this::fetchChannel)
                .flatMap(option -> option.map(Stream::of).orElseGet(Stream::empty))
                .map(channelTransformer)
                .flatMap(option -> option.map(Stream::of).orElseGet(Stream::empty))
                .collect(toList());
    }

    private Optional<ChannelEntity> fetchChannel(IEM em) {
        try {
            return channelRepository.queryChannel(em.getId());
        } catch (RepositoryException e) {
            loggerManager.createSystemEventLog(getContext(), new LoggerItemChannel(em.getIdName(), e.getMessage(), ERROR));
            LOGGER.error("Failed to fetch channel {}", em, e);
        }
        return Optional.empty();
    }
}
