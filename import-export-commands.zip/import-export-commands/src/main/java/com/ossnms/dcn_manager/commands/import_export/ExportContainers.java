package com.ossnms.dcn_manager.commands.import_export;

import com.ossnms.dcn_manager.commands.Command;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.import_export.container.ExportContainerTransformer;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toList;
import static java.util.stream.StreamSupport.stream;

public class ExportContainers<C extends CallContext> extends Command<C, Collection<ContainerValueObject>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExportContainers.class);
    private final ContainerRepository containerRepository;
    private final ExportContainerTransformer containerTransformer;

    public ExportContainers(C context, ContainerRepository containerRepository, ExportContainerTransformer containerTransformer) {
        super(context);
        this.containerRepository = containerRepository;
        this.containerTransformer = containerTransformer;
    }

    @Override public Collection<ContainerValueObject> call() {
        return fetchSystems()
                .map(containerTransformer)
                .collect(toList());
    }

    private Stream<ContainerInfo> fetchSystems() {
        try {
            return stream(containerRepository.queryAll().spliterator(), false);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch containers", e);
            return Stream.empty();
        }
    }
}
