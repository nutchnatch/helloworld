
/**
 * This class provides the configuration for the responses of the Sesame Mock (sesame-mock.jar). <br>
 * <br>
 * If you need to add your own response for a particular service, add a method in this class with this
 * method signature : <br>
 * String mock_%ENDPOINT%_%SOAP-OPERATION%(String request); <br>
 * - ENDPOINT is the url ENDPOINT without /sesame_services/services/ or /sesame_sso_services/services/ <br>
 * - SOAP-OPERATION is the name child of <br>
 * - request is a String containing the xml of the request.<br>
 * - The response will be the xml of your mock. <br>
 * <br>
 * So, this mock configuration requires that you know the format of the original SOAP responses of Sesame.
 * If you need to view the response xml (and request) you can use SOAP UI or you can plug your application to
 * the original Sesame and to set up Charles Proxy.<br>
 * <br>
 * You can obviously creates smart responses based on the requests, Watch the existing responses for examples.<br>
 * <br>
 * You can use as many response files as you want, just use the pattern : SesameMockResponses*.groovy
 * <br>
 * asciiart with http://patorjk.com/software/taag/#p=display&h=0&v=1&f=Big
 */
public class SesameMockResponses_soap {
	
	
//                     _    _                   _    _              _    _               
//        /\          | |  | |                 | |  (_)            | |  (_)              
//       /  \   _   _ | |_ | |__    ___  _ __  | |_  _   ___  __ _ | |_  _   ___   _ __  
//      / /\ \ | | | || __|| '_ \  / _ \| '_ \ | __|| | / __|/ _` || __|| | / _ \ | '_ \ 
//     / ____ \| |_| || |_ | | | ||  __/| | | || |_ | || (__| (_| || |_ | || (_) || | | |
//    /_/    \_\\__,_| \__||_| |_| \___||_| |_| \__||_| \___|\__,_| \__||_| \___/ |_| |_|

	String mock_AuthenticationServicesWSP_logout(String request) {
		return sendSoapResponse( 
					"""<p555:logoutResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com" />""");
	}

	String mock_AuthenticationServicesWSP_changePassword(String request) {
		def req = new XmlSlurper().parseText(request)
		def login = req.'**'.find { node-> node.name() == 'login' }.text()

		if ("badpwd".equalsIgnoreCase(login)) {
			return sendSoapResponse(
					"\t\t<soapenv:Fault xmlns:ns4=\"http://exception.services.sesame.bnppa.com\">\n" +
					"\t\t\t<faultcode>ns4:LoginException</faultcode>\n" +
					"\t\t\t<faultstring>L001cLIW1 : L'identifiant du compte user_tony ou le mot de passe saisi ne sont pas conformes.</faultstring>\n" +
					"\t\t\t<detail>\n" +
					"\t\t\t\t<ns4:LoginException xmlns:ns2=\"http://proxy.standard.services.sesame.bnppa.com\" xmlns:ns3=\"http://exception.common.services.sesame.bnppa.com\">\n" +
					"\t\t\t\t\t<message>L001cLIW1 : L'identifiant du compte user_tony ou le mot de passe saisi ne sont pas conformes.</message>\n" +
					"\t\t\t\t</ns4:LoginException>\n" +
					"\t\t\t</detail>\n" +
					"\t\t</soapenv:Fault>\n");
		}
		return sendSoapResponse(
						"\t<ns2:changePasswordResponse xmlns:ns2=\"http://proxy.standard.services.sesame.bnppa.com\" xmlns:ns3=\"http://exception.common.services.sesame.bnppa.com\" xmlns:ns4=\"http://exception.services.sesame.bnppa.com\" />\n");
	}
	
	String mock_AuthenticationServicesWSP_loginInUserRef(String request) {
		def req = new XmlSlurper().parseText(request)
        def login = req.'**'.find { node-> node.name() == 'login' }.text()

        if ("badpwd".equalsIgnoreCase(login)) {
			return sendSoapResponse("""
						<soapenv:Fault>
							<faultcode xmlns:p623="http://exception.services.sesame.bnppa.com">p623:LoginException</faultcode>
							<faultstring>com.bnppa.sesame.services.exception.LoginException@1e83276b[message=L001cPIW1 : L&apos;identifiant du compte badpwd ou le mot de passe saisi ne sont pas conformes.]</faultstring>
							<detail encodingStyle="">
								<p623:LoginException xmlns:p623="http://exception.services.sesame.bnppa.com">
									<message>L001cPIW1 : L&apos;identifiant du compte badpwd ou le mot de passe saisi ne sont pas conformes.</message>
								</p623:LoginException>
							</detail>
						</soapenv:Fault>""");
		}
		
		
		
		return sendSoapResponse("""
					<p555:loginInUserRefResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
						<loginInUserRefReturn>ValidSesameTokenFor_$login</loginInUserRefReturn>
					</p555:loginInUserRefResponse>
                """);
		
	}
	
	String mock_AuthenticationServicesWSP_validateToken(String request) {
		return sendSoapResponse("""
					<p555:validateTokenResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
						<validateTokenReturn>1</validateTokenReturn>
					</p555:validateTokenResponse>""");
	}
	

	String mock_AppAuthenticationServiceSOAP_loginForApplicationIn(String request) {
		def req = new XmlSlurper().parseText(request)
        def login = req.'**'.find { node-> node.name() == 'login' }.text()
        
		return sendSoapResponse("""
				<p68:loginForApplicationOut xmlns:p68="http://sesame.assurance.bnpparibas.com/int/schema/mp/sesame/AppAuthenticationService/v1">
					<p68:sesameToken>ValidSesameTokenFor_$login</p68:sesameToken>
				</p68:loginForApplicationOut>
				""")
	}
	
	String mock_SecuredAuthenticationServicesWSP_getTokenFromLogin(String request) {
		def req = new XmlSlurper().parseText(request)
        def login = req.'**'.find { node-> node.name() == 'login' }.text()
		
		return sendSoapResponse("""
						<ns2:getTokenFromLoginResponse xmlns:ns2="http://proxy.standard.services.sesame.bnppa.com">
							<getTokenFromLoginReturn>ValidSesameTokenFor_$login</getTokenFromLoginReturn>
						</ns2:getTokenFromLoginResponse>
						""");
	}
	
//     _____     _               _    _  _          
//	  |_   _|   | |             | |  (_)| |         
//	    | |   __| |  ___  _ __  | |_  _ | |_  _   _ 
//	    | |  / _` | / _ \| '_ \ | __|| || __|| | | |
//	   _| |_| (_| ||  __/| | | || |_ | || |_ | |_| |
//	  |_____|\__,_| \___||_| |_| \__||_| \__| \__, |
//	                                           __/ |
//	                                          |___/ 
	String mock_IdentityServicesWSP_getUserIdentity(String request) {

        def req = new XmlSlurper().parseText(request)
        def token = req.'**'.find { node-> node.name() == 'token' }.text()
		String name = "SES_MOCK_USER";
		if (token.startsWith("ValidSesameTokenFor_")) {
			name = token.substring(20);
		}
		
		if ("b48489".equalsIgnoreCase(name)) {
			return sendSoapResponse("""
						<p555:getUserIdentityResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
						<getUserIdentityReturn>
							<emails>
								<string>nivaldo.monteiro@cardif.com</string>
							</emails>
							<expiryDate>2016-04-16T08:55:24.000Z</expiryDate>
							<firstName>Nivaldo</firstName>
							<lastConnexion>2015-12-09T15:05:01.209Z</lastConnexion>
							<lastName>Monteiro</lastName>
							<login>$name</login>
							<accountType>TIERS</accountType>
							<functionalAreaId>SUGAR</functionalAreaId>
							<lastUpdate>2015-01-28T10:12:30.000Z</lastUpdate>
							<inactiveDate xsi:nil="true" />
						</getUserIdentityReturn>
					</p555:getUserIdentityResponse>
			""");
		}
		
		return sendSoapResponse("""
					<p555:getUserIdentityResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
						<getUserIdentityReturn>
							<emails>
								<string>${name.toLowerCase()}@bnpparibas.com</string>
							</emails>
							<expiryDate>2016-04-16T08:55:24.000Z</expiryDate>
							<firstName>$name</firstName>
							<lastConnexion>2015-12-09T15:05:01.209Z</lastConnexion>
							<lastName>$name</lastName>
							<login>$name</login>
							<accountType>TIERS</accountType>
							<functionalAreaId>NRJ</functionalAreaId>
							<lastUpdate>2015-01-28T10:12:30.000Z</lastUpdate>
							<inactiveDate xsi:nil="true" />
						</getUserIdentityReturn>
					</p555:getUserIdentityResponse>
				""");
	}
	
	String mock_IdentityServicesWSP_getExtendedAttributes(String request) {
		
		if ("b48489".equalsIgnoreCase(name)) {
			return sendSoapResponse("""
					<p555:getExtendedAttributesResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
				         <getExtendedAttributesReturn>
				            <KeyValue>
				               <key>bnplblpostetype</key>
				               <value>ASSISTANT EXTERIEUR</value>
				            </KeyValue>
				            <KeyValue>
				               <key>bnpuid_bnpuoappartenance</key>
				               <value>08103682</value>
				            </KeyValue>
				            <KeyValue>
				               <key>givenname</key>
				               <value>Nivaldo</value>
				            </KeyValue>
				         </getExtendedAttributesReturn>
				     </p555:getExtendedAttributesResponse>
			""");
		}
		
	
		return sendSoapResponse("""
				<p555:getExtendedAttributesResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
				         <getExtendedAttributesReturn>
				            <KeyValue>
				               <key>bnplblpostetype</key>
				               <value>ASSISTANT EXTERIEUR</value>
				            </KeyValue>
				            <KeyValue>
				               <key>bnpuid_bnpuoappartenance</key>
				               <value>08103682</value>
				            </KeyValue>
				            <KeyValue>
				               <key>givenname</key>
				               <value>Roch</value>
				            </KeyValue>
				         </getExtendedAttributesReturn>
				      </p555:getExtendedAttributesResponse>
			""");
				
	}
	
	
//                     _    _                   _             _    _               
//        /\          | |  | |                 (_)           | |  (_)              
//       /  \   _   _ | |_ | |__    ___   _ __  _  ____ __ _ | |_  _   ___   _ __  
//      / /\ \ | | | || __|| '_ \  / _ \ | '__|| ||_  // _` || __|| | / _ \ | '_ \ 
//     / ____ \| |_| || |_ | | | || (_) || |   | | / /| (_| || |_ | || (_) || | | |
//    /_/    \_\\__,_| \__||_| |_| \___/ |_|   |_|/___|\__,_| \__||_| \___/ |_| |_|
                                                                             
	
	String mock_AuthorizationServicesWSP_getPermissions(String request) {
		
		String permissions = "<string>perm1</string><string>perm2</string>";
        def req = new XmlSlurper().parseText(request)
        def token = req.'**'.find { node-> node.name() == 'token' }.text()
		
		if (token.contains("NO_PERM")) {
			permissions = "";
		}
		
		return sendSoapResponse("""
					<p555:getPermissionsResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
						<getPermissionsReturn>
								$permissions
						</getPermissionsReturn>
					</p555:getPermissionsResponse>""");
	}
	
	String mock_AuthorizationServicesWSP_getJoinings(String request) {
		return sendSoapResponse("""
				    <p555:getJoiningsResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
				       <getJoiningsReturn>
				          <Joining>
				             <subsidiary>SUGAR</subsidiary>
				             <interv>Syldavia</interv>
				             <joiningType>SCOPE</joiningType>
				             <source>SUGAR</source>
				          </Joining>
				       </getJoiningsReturn>
				    </p555:getJoiningsResponse>""");
	}
	
	String mock_AuthorizationServicesWSP_getUsingRight(String request) {
		return sendSoapResponse("""
				    <p555:getUsingRightResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
				       <getUsingRightReturn>
				          <contractView>RESCOM</contractView>
				          <productView>DIRECT</productView>
				          <rescom>DIRECT</rescom>
				          <sadr xsi:nil="true"/>
				          <topGroup>1</topGroup>
				          <userType>APA</userType>
				       </getUsingRightReturn>
				    </p555:getUsingRightResponse>""");
	}
	
	String mock_AuthorizationServicesWSP_getRoles(String request) {
		return sendSoapResponse("""
				      <p555:getRolesResponse xmlns:p555="http://proxy.standard.services.sesame.bnppa.com">
				         <getRolesReturn>
							<string>SUGAR_USER_ROLE</string>
							<string>SUGAR_ADMIN</string>
							<string>SUGAR_BS_MANAGER</string>
							<string>SUGAR_ADMIN</string>
							<string>SUGAR_CONFIDENTIAL_USER_ROLE</string>
				         </getRolesReturn>
				      </p555:getRolesResponse>
					  """);
	}
	
	
						//<getRolesReturn>
						//	<string>SUGAR_USER_ROLE</string>
						//	<string>SUGAR_BS_MANAGER</string>
						//	<string>SUGAR_ADMIN</string>
						//	<string>SUGAR_CONFIDENTIAL_USER_ROLE</string>
				        // </getRolesReturn>
	
//          _____    _____    ____  
//    	   / ____|  / ____|  / __ \ 
//    	  | (___   | (___   | |  | |
//    	   \___ \   \___ \  | |  | |
//    	   ____) |  ____) | | |__| |
//    	  |_____/  |_____/   \____/ 
	                            
	//Warning this SSO implementation with the parameters is not multi-user safe.  
	String businessParamsSSO = "<businessParams/>";
	String tokenSesameForSesameSSO = "undefined";
	
	String mock_SSOServicesWSP_login(String request) {
        def req = new XmlSlurper().parseText(request)
        businessParamsSSO = req.'**'.find { node-> node.name() == 'businessParams' }.text()
        tokenSesameForSesameSSO = req.'**'.find { node-> node.name() == 'token' }.text()

        return sendSoapResponse("""
					<p147:loginResponse xmlns:p147="http://proxy.sso.sesame.bnppa.com">
						<loginReturn>##**##_validSSOTokenFromMock</loginReturn>
					</p147:loginResponse>
					""");
	}
	
	String mock_SSOServicesWSP_singleSignOn(String request) {
		return sendSoapResponse("""
					<p147:singleSignOnResponse xmlns:p147="http://proxy.sso.sesame.bnppa.com">
						<singleSignOnReturn>
								$businessParamsSSO
							<token>
									$tokenSesameForSesameSSO
							</token>
						</singleSignOnReturn>
					</p147:singleSignOnResponse>""");
	}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	/**
	 * Wrap a the soap envelope
	 * @param body
	 * @return
	 */
	def sendSoapResponse(String body) {
		return """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
				<soapenv:Body>
						$body 
				</soapenv:Body>
				</soapenv:Envelope>""";
	}
	

}
