
package com.bnpparibas.assurance.sugar.internal.service.app.acl.v1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bnpparibas.assurance.sugar.internal.service.app.acl.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Scope_QNAME = new QName("http://sugar.assurance.bnpparibas.com/internal/service/app/acl/v1", "Scope");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bnpparibas.assurance.sugar.internal.service.app.acl.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetByClassIdRequest }
     * 
     */
    public GetByClassIdRequest createGetByClassIdRequest() {
        return new GetByClassIdRequest();
    }

    /**
     * Create an instance of {@link GetByClassIdResponse }
     * 
     */
    public GetByClassIdResponse createGetByClassIdResponse() {
        return new GetByClassIdResponse();
    }

    /**
     * Create an instance of {@link GetByBasketIdRequest }
     * 
     */
    public GetByBasketIdRequest createGetByBasketIdRequest() {
        return new GetByBasketIdRequest();
    }

    /**
     * Create an instance of {@link GetByBasketIdResponse }
     * 
     */
    public GetByBasketIdResponse createGetByBasketIdResponse() {
        return new GetByBasketIdResponse();
    }

    /**
     * Create an instance of {@link GetAllRequest }
     * 
     */
    public GetAllRequest createGetAllRequest() {
        return new GetAllRequest();
    }

    /**
     * Create an instance of {@link GetAllResponse }
     * 
     */
    public GetAllResponse createGetAllResponse() {
        return new GetAllResponse();
    }

    /**
     * Create an instance of {@link GetDefaultRequest }
     * 
     */
    public GetDefaultRequest createGetDefaultRequest() {
        return new GetDefaultRequest();
    }

    /**
     * Create an instance of {@link GetDefaultResponse }
     * 
     */
    public GetDefaultResponse createGetDefaultResponse() {
        return new GetDefaultResponse();
    }

    /**
     * Create an instance of {@link ChangeDefaultAclRequest }
     * 
     */
    public ChangeDefaultAclRequest createChangeDefaultAclRequest() {
        return new ChangeDefaultAclRequest();
    }

    /**
     * Create an instance of {@link ChangeDefaultAclResponse }
     * 
     */
    public ChangeDefaultAclResponse createChangeDefaultAclResponse() {
        return new ChangeDefaultAclResponse();
    }

    /**
     * Create an instance of {@link AssignToClassRequest }
     * 
     */
    public AssignToClassRequest createAssignToClassRequest() {
        return new AssignToClassRequest();
    }

    /**
     * Create an instance of {@link AssignToClassResponse }
     * 
     */
    public AssignToClassResponse createAssignToClassResponse() {
        return new AssignToClassResponse();
    }

    /**
     * Create an instance of {@link AssignToBasketRequest }
     * 
     */
    public AssignToBasketRequest createAssignToBasketRequest() {
        return new AssignToBasketRequest();
    }

    /**
     * Create an instance of {@link AssignToBasketResponse }
     * 
     */
    public AssignToBasketResponse createAssignToBasketResponse() {
        return new AssignToBasketResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/acl/v1", name = "Scope")
    public JAXBElement<String> createScope(String value) {
        return new JAXBElement<String>(_Scope_QNAME, String.class, null, value);
    }

}
