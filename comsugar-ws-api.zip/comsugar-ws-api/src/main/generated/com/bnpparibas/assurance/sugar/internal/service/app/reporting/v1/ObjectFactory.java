
package com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetEnvelopeFlowsRequest }
     * 
     */
    public GetEnvelopeFlowsRequest createGetEnvelopeFlowsRequest() {
        return new GetEnvelopeFlowsRequest();
    }

    /**
     * Create an instance of {@link GetEnvelopeFlowsResponse }
     * 
     */
    public GetEnvelopeFlowsResponse createGetEnvelopeFlowsResponse() {
        return new GetEnvelopeFlowsResponse();
    }

    /**
     * Create an instance of {@link GetEnvelopeFlowsReportRequest }
     * 
     */
    public GetEnvelopeFlowsReportRequest createGetEnvelopeFlowsReportRequest() {
        return new GetEnvelopeFlowsReportRequest();
    }

    /**
     * Create an instance of {@link GetEnvelopeFlowsReportResponse }
     * 
     */
    public GetEnvelopeFlowsReportResponse createGetEnvelopeFlowsReportResponse() {
        return new GetEnvelopeFlowsReportResponse();
    }

    /**
     * Create an instance of {@link GetDocumentStockReportRequest }
     * 
     */
    public GetDocumentStockReportRequest createGetDocumentStockReportRequest() {
        return new GetDocumentStockReportRequest();
    }

    /**
     * Create an instance of {@link GetDocumentStockReportResponse }
     * 
     */
    public GetDocumentStockReportResponse createGetDocumentStockReportResponse() {
        return new GetDocumentStockReportResponse();
    }

    /**
     * Create an instance of {@link GetFolderStockReportRequest }
     * 
     */
    public GetFolderStockReportRequest createGetFolderStockReportRequest() {
        return new GetFolderStockReportRequest();
    }

    /**
     * Create an instance of {@link GetFolderStockReportResponse }
     * 
     */
    public GetFolderStockReportResponse createGetFolderStockReportResponse() {
        return new GetFolderStockReportResponse();
    }

    /**
     * Create an instance of {@link GetBasketRatioRequest }
     * 
     */
    public GetBasketRatioRequest createGetBasketRatioRequest() {
        return new GetBasketRatioRequest();
    }

    /**
     * Create an instance of {@link GetBasketRatioResponse }
     * 
     */
    public GetBasketRatioResponse createGetBasketRatioResponse() {
        return new GetBasketRatioResponse();
    }

    /**
     * Create an instance of {@link GetBasketRatioReportRequest }
     * 
     */
    public GetBasketRatioReportRequest createGetBasketRatioReportRequest() {
        return new GetBasketRatioReportRequest();
    }

    /**
     * Create an instance of {@link GetBasketRatioReportResponse }
     * 
     */
    public GetBasketRatioReportResponse createGetBasketRatioReportResponse() {
        return new GetBasketRatioReportResponse();
    }

    /**
     * Create an instance of {@link GetDocumentStockIndicatorRequest }
     * 
     */
    public GetDocumentStockIndicatorRequest createGetDocumentStockIndicatorRequest() {
        return new GetDocumentStockIndicatorRequest();
    }

    /**
     * Create an instance of {@link GetDocumentStockIndicatorResponse }
     * 
     */
    public GetDocumentStockIndicatorResponse createGetDocumentStockIndicatorResponse() {
        return new GetDocumentStockIndicatorResponse();
    }

    /**
     * Create an instance of {@link GetFolderStockIndicatorRequest }
     * 
     */
    public GetFolderStockIndicatorRequest createGetFolderStockIndicatorRequest() {
        return new GetFolderStockIndicatorRequest();
    }

    /**
     * Create an instance of {@link GetFolderStockIndicatorResponse }
     * 
     */
    public GetFolderStockIndicatorResponse createGetFolderStockIndicatorResponse() {
        return new GetFolderStockIndicatorResponse();
    }

    /**
     * Create an instance of {@link GetReportingSummaryRequest }
     * 
     */
    public GetReportingSummaryRequest createGetReportingSummaryRequest() {
        return new GetReportingSummaryRequest();
    }

    /**
     * Create an instance of {@link GetReportingSummaryResponse }
     * 
     */
    public GetReportingSummaryResponse createGetReportingSummaryResponse() {
        return new GetReportingSummaryResponse();
    }

}
