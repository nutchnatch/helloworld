
package com.bnpparibas.assurance.sugar.internal.service.app.document.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FileInDocumentURI" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *         &lt;element name="FileOutIdOk" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *         &lt;element name="FileOutDocumentRejected" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *         &lt;element name="StopOnError" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="CommitPoint" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="GenerateNewId" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="CheckIfClassIsActive" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fileInDocumentURI",
    "fileOutIdOk",
    "fileOutDocumentRejected",
    "stopOnError",
    "commitPoint",
    "generateNewId",
    "checkIfClassIsActive"
})
@XmlRootElement(name = "LoadDocumentRequest")
public class LoadDocumentRequest {

    @XmlElement(name = "FileInDocumentURI", required = true)
    @XmlSchemaType(name = "anyURI")
    protected String fileInDocumentURI;
    @XmlElement(name = "FileOutIdOk", required = true)
    @XmlSchemaType(name = "anyURI")
    protected String fileOutIdOk;
    @XmlElement(name = "FileOutDocumentRejected", required = true)
    @XmlSchemaType(name = "anyURI")
    protected String fileOutDocumentRejected;
    @XmlElement(name = "StopOnError")
    protected int stopOnError;
    @XmlElement(name = "CommitPoint")
    protected int commitPoint;
    @XmlElement(name = "GenerateNewId")
    protected boolean generateNewId;
    @XmlElement(name = "CheckIfClassIsActive")
    protected boolean checkIfClassIsActive;

    /**
     * Gets the value of the fileInDocumentURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileInDocumentURI() {
        return fileInDocumentURI;
    }

    /**
     * Sets the value of the fileInDocumentURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileInDocumentURI(String value) {
        this.fileInDocumentURI = value;
    }

    /**
     * Gets the value of the fileOutIdOk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileOutIdOk() {
        return fileOutIdOk;
    }

    /**
     * Sets the value of the fileOutIdOk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileOutIdOk(String value) {
        this.fileOutIdOk = value;
    }

    /**
     * Gets the value of the fileOutDocumentRejected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileOutDocumentRejected() {
        return fileOutDocumentRejected;
    }

    /**
     * Sets the value of the fileOutDocumentRejected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileOutDocumentRejected(String value) {
        this.fileOutDocumentRejected = value;
    }

    /**
     * Gets the value of the stopOnError property.
     * 
     */
    public int getStopOnError() {
        return stopOnError;
    }

    /**
     * Sets the value of the stopOnError property.
     * 
     */
    public void setStopOnError(int value) {
        this.stopOnError = value;
    }

    /**
     * Gets the value of the commitPoint property.
     * 
     */
    public int getCommitPoint() {
        return commitPoint;
    }

    /**
     * Sets the value of the commitPoint property.
     * 
     */
    public void setCommitPoint(int value) {
        this.commitPoint = value;
    }

    /**
     * Gets the value of the generateNewId property.
     * 
     */
    public boolean isGenerateNewId() {
        return generateNewId;
    }

    /**
     * Sets the value of the generateNewId property.
     * 
     */
    public void setGenerateNewId(boolean value) {
        this.generateNewId = value;
    }

    /**
     * Gets the value of the checkIfClassIsActive property.
     * 
     */
    public boolean isCheckIfClassIsActive() {
        return checkIfClassIsActive;
    }

    /**
     * Sets the value of the checkIfClassIsActive property.
     * 
     */
    public void setCheckIfClassIsActive(boolean value) {
        this.checkIfClassIsActive = value;
    }

}
