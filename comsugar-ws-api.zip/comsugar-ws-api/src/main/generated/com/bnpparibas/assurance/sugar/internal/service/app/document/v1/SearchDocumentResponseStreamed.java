
package com.bnpparibas.assurance.sugar.internal.service.app.document.v1;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="NbFind" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="FileData" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "nbFind",
    "fileData"
})
@XmlRootElement(name = "SearchDocumentResponseStreamed")
public class SearchDocumentResponseStreamed {

    @XmlElement(name = "NbFind")
    protected long nbFind;
    @XmlElement(name = "FileData", required = true)
    @XmlMimeType("application/octet-stream")
    protected DataHandler fileData;

    /**
     * Gets the value of the nbFind property.
     * 
     */
    public long getNbFind() {
        return nbFind;
    }

    /**
     * Sets the value of the nbFind property.
     * 
     */
    public void setNbFind(long value) {
        this.nbFind = value;
    }

    /**
     * Gets the value of the fileData property.
     * 
     * @return
     *     possible object is
     *     {@link DataHandler }
     *     
     */
    public DataHandler getFileData() {
        return fileData;
    }

    /**
     * Sets the value of the fileData property.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHandler }
     *     
     */
    public void setFileData(DataHandler value) {
        this.fileData = value;
    }

}
