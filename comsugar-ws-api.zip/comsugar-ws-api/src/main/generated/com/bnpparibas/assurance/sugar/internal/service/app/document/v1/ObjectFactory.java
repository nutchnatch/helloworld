
package com.bnpparibas.assurance.sugar.internal.service.app.document.v1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bnpparibas.assurance.sugar.internal.service.app.document.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Scope_QNAME = new QName("http://sugar.assurance.bnpparibas.com/internal/service/app/document/v1", "Scope");
    private final static QName _SearchDocumentRequestStreamed_QNAME = new QName("http://sugar.assurance.bnpparibas.com/internal/service/app/document/v1", "SearchDocumentRequestStreamed");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bnpparibas.assurance.sugar.internal.service.app.document.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SearchDocumentResponse }
     * 
     */
    public SearchDocumentResponse createSearchDocumentResponse() {
        return new SearchDocumentResponse();
    }

    /**
     * Create an instance of {@link StoreRequest }
     * 
     */
    public StoreRequest createStoreRequest() {
        return new StoreRequest();
    }

    /**
     * Create an instance of {@link StoreResponse }
     * 
     */
    public StoreResponse createStoreResponse() {
        return new StoreResponse();
    }

    /**
     * Create an instance of {@link ReindexRequest }
     * 
     */
    public ReindexRequest createReindexRequest() {
        return new ReindexRequest();
    }

    /**
     * Create an instance of {@link ReindexResponse }
     * 
     */
    public ReindexResponse createReindexResponse() {
        return new ReindexResponse();
    }

    /**
     * Create an instance of {@link UpdateMetaDataRequest }
     * 
     */
    public UpdateMetaDataRequest createUpdateMetaDataRequest() {
        return new UpdateMetaDataRequest();
    }

    /**
     * Create an instance of {@link UpdateMetaDataResponse }
     * 
     */
    public UpdateMetaDataResponse createUpdateMetaDataResponse() {
        return new UpdateMetaDataResponse();
    }

    /**
     * Create an instance of {@link ChangeClassRequest }
     * 
     */
    public ChangeClassRequest createChangeClassRequest() {
        return new ChangeClassRequest();
    }

    /**
     * Create an instance of {@link ChangeClassResponse }
     * 
     */
    public ChangeClassResponse createChangeClassResponse() {
        return new ChangeClassResponse();
    }

    /**
     * Create an instance of {@link ArchiveRequest }
     * 
     */
    public ArchiveRequest createArchiveRequest() {
        return new ArchiveRequest();
    }

    /**
     * Create an instance of {@link ArchiveResponse }
     * 
     */
    public ArchiveResponse createArchiveResponse() {
        return new ArchiveResponse();
    }

    /**
     * Create an instance of {@link GetRequest }
     * 
     */
    public GetRequest createGetRequest() {
        return new GetRequest();
    }

    /**
     * Create an instance of {@link GetResponse }
     * 
     */
    public GetResponse createGetResponse() {
        return new GetResponse();
    }

    /**
     * Create an instance of {@link FindRequest }
     * 
     */
    public FindRequest createFindRequest() {
        return new FindRequest();
    }

    /**
     * Create an instance of {@link SearchDocumentRequestType }
     * 
     */
    public SearchDocumentRequestType createSearchDocumentRequestType() {
        return new SearchDocumentRequestType();
    }

    /**
     * Create an instance of {@link FindResponse }
     * 
     */
    public FindResponse createFindResponse() {
        return new FindResponse();
    }

    /**
     * Create an instance of {@link FindStreamedRequest }
     * 
     */
    public FindStreamedRequest createFindStreamedRequest() {
        return new FindStreamedRequest();
    }

    /**
     * Create an instance of {@link FindStreamedResponse }
     * 
     */
    public FindStreamedResponse createFindStreamedResponse() {
        return new FindStreamedResponse();
    }

    /**
     * Create an instance of {@link GetWithFilesRequest }
     * 
     */
    public GetWithFilesRequest createGetWithFilesRequest() {
        return new GetWithFilesRequest();
    }

    /**
     * Create an instance of {@link GetWithFilesResponse }
     * 
     */
    public GetWithFilesResponse createGetWithFilesResponse() {
        return new GetWithFilesResponse();
    }

    /**
     * Create an instance of {@link AddFilesRequest }
     * 
     */
    public AddFilesRequest createAddFilesRequest() {
        return new AddFilesRequest();
    }

    /**
     * Create an instance of {@link AddFilesResponse }
     * 
     */
    public AddFilesResponse createAddFilesResponse() {
        return new AddFilesResponse();
    }

    /**
     * Create an instance of {@link DeleteRequest }
     * 
     */
    public DeleteRequest createDeleteRequest() {
        return new DeleteRequest();
    }

    /**
     * Create an instance of {@link DeleteResponse }
     * 
     */
    public DeleteResponse createDeleteResponse() {
        return new DeleteResponse();
    }

    /**
     * Create an instance of {@link DeleteAllFilesRequest }
     * 
     */
    public DeleteAllFilesRequest createDeleteAllFilesRequest() {
        return new DeleteAllFilesRequest();
    }

    /**
     * Create an instance of {@link DeleteAllFilesResponse }
     * 
     */
    public DeleteAllFilesResponse createDeleteAllFilesResponse() {
        return new DeleteAllFilesResponse();
    }

    /**
     * Create an instance of {@link LoadDocumentRequest }
     * 
     */
    public LoadDocumentRequest createLoadDocumentRequest() {
        return new LoadDocumentRequest();
    }

    /**
     * Create an instance of {@link LoadDocumentResponse }
     * 
     */
    public LoadDocumentResponse createLoadDocumentResponse() {
        return new LoadDocumentResponse();
    }

    /**
     * Create an instance of {@link UpdateDocumentRequest }
     * 
     */
    public UpdateDocumentRequest createUpdateDocumentRequest() {
        return new UpdateDocumentRequest();
    }

    /**
     * Create an instance of {@link UpdateDocumentResponse }
     * 
     */
    public UpdateDocumentResponse createUpdateDocumentResponse() {
        return new UpdateDocumentResponse();
    }

    /**
     * Create an instance of {@link GetDocumentRequest }
     * 
     */
    public GetDocumentRequest createGetDocumentRequest() {
        return new GetDocumentRequest();
    }

    /**
     * Create an instance of {@link GetDocumentResponse }
     * 
     */
    public GetDocumentResponse createGetDocumentResponse() {
        return new GetDocumentResponse();
    }

    /**
     * Create an instance of {@link SearchDocumentRequest }
     * 
     */
    public SearchDocumentRequest createSearchDocumentRequest() {
        return new SearchDocumentRequest();
    }

    /**
     * Create an instance of {@link SearchDocumentResponse.Documents }
     * 
     */
    public SearchDocumentResponse.Documents createSearchDocumentResponseDocuments() {
        return new SearchDocumentResponse.Documents();
    }

    /**
     * Create an instance of {@link SearchDocumentResponseStreamed }
     * 
     */
    public SearchDocumentResponseStreamed createSearchDocumentResponseStreamed() {
        return new SearchDocumentResponseStreamed();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/document/v1", name = "Scope")
    public JAXBElement<String> createScope(String value) {
        return new JAXBElement<String>(_Scope_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SearchDocumentRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/document/v1", name = "SearchDocumentRequestStreamed")
    public JAXBElement<SearchDocumentRequestType> createSearchDocumentRequestStreamed(SearchDocumentRequestType value) {
        return new JAXBElement<SearchDocumentRequestType>(_SearchDocumentRequestStreamed_QNAME, SearchDocumentRequestType.class, null, value);
    }

}
