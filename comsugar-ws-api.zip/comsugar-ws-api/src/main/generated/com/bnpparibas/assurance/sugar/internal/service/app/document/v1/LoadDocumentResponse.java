
package com.bnpparibas.assurance.sugar.internal.service.app.document.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fileOutIdOk" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *         &lt;element name="fileOutDocumentRejected" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *         &lt;element name="ok" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="ko" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fileOutIdOk",
    "fileOutDocumentRejected",
    "ok",
    "ko"
})
@XmlRootElement(name = "LoadDocumentResponse")
public class LoadDocumentResponse {

    @XmlElement(required = true)
    @XmlSchemaType(name = "anyURI")
    protected String fileOutIdOk;
    @XmlElement(required = true)
    @XmlSchemaType(name = "anyURI")
    protected String fileOutDocumentRejected;
    protected int ok;
    protected int ko;

    /**
     * Gets the value of the fileOutIdOk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileOutIdOk() {
        return fileOutIdOk;
    }

    /**
     * Sets the value of the fileOutIdOk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileOutIdOk(String value) {
        this.fileOutIdOk = value;
    }

    /**
     * Gets the value of the fileOutDocumentRejected property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFileOutDocumentRejected() {
        return fileOutDocumentRejected;
    }

    /**
     * Sets the value of the fileOutDocumentRejected property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFileOutDocumentRejected(String value) {
        this.fileOutDocumentRejected = value;
    }

    /**
     * Gets the value of the ok property.
     * 
     */
    public int getOk() {
        return ok;
    }

    /**
     * Sets the value of the ok property.
     * 
     */
    public void setOk(int value) {
        this.ok = value;
    }

    /**
     * Gets the value of the ko property.
     * 
     */
    public int getKo() {
        return ko;
    }

    /**
     * Sets the value of the ko property.
     * 
     */
    public void setKo(int value) {
        this.ko = value;
    }

}
