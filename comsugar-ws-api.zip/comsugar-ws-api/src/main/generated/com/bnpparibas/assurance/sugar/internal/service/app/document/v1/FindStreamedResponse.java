
package com.bnpparibas.assurance.sugar.internal.service.app.document.v1;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Found" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="Retrieved" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="FileData" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "found",
    "retrieved",
    "fileData"
})
@XmlRootElement(name = "FindStreamedResponse")
public class FindStreamedResponse {

    @XmlElement(name = "Found")
    protected long found;
    @XmlElement(name = "Retrieved")
    protected long retrieved;
    @XmlElement(name = "FileData", required = true)
    @XmlMimeType("application/octet-stream")
    protected DataHandler fileData;

    /**
     * Gets the value of the found property.
     * 
     */
    public long getFound() {
        return found;
    }

    /**
     * Sets the value of the found property.
     * 
     */
    public void setFound(long value) {
        this.found = value;
    }

    /**
     * Gets the value of the retrieved property.
     * 
     */
    public long getRetrieved() {
        return retrieved;
    }

    /**
     * Sets the value of the retrieved property.
     * 
     */
    public void setRetrieved(long value) {
        this.retrieved = value;
    }

    /**
     * Gets the value of the fileData property.
     * 
     * @return
     *     possible object is
     *     {@link DataHandler }
     *     
     */
    public DataHandler getFileData() {
        return fileData;
    }

    /**
     * Sets the value of the fileData property.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHandler }
     *     
     */
    public void setFileData(DataHandler value) {
        this.fileData = value;
    }

}
