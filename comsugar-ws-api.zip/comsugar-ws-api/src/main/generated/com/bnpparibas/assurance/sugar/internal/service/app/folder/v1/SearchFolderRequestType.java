
package com.bnpparibas.assurance.sugar.internal.service.app.folder.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;


/**
 * <p>Java class for SearchFolderRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SearchFolderRequestType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Start" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="Max" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="IncludeChild" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="IncludeFiles" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="RequestExpression" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Criteria" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}Criteria"/&gt;
 *         &lt;element name="Order" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}OrderClause"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchFolderRequestType", propOrder = {
    "start",
    "max",
    "includeChild",
    "includeFiles",
    "requestExpression",
    "criteria",
    "order"
})
@XmlSeeAlso({
    FindRequest.class
})
public class SearchFolderRequestType {

    @XmlElement(name = "Start")
    protected long start;
    @XmlElement(name = "Max")
    protected long max;
    @XmlElement(name = "IncludeChild")
    protected boolean includeChild;
    @XmlElement(name = "IncludeFiles")
    protected boolean includeFiles;
    @XmlElement(name = "RequestExpression", required = true)
    protected String requestExpression;
    @XmlElement(name = "Criteria", required = true)
    protected Criteria criteria;
    @XmlElement(name = "Order", required = true)
    protected OrderClause order;

    /**
     * Gets the value of the start property.
     * 
     */
    public long getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     */
    public void setStart(long value) {
        this.start = value;
    }

    /**
     * Gets the value of the max property.
     * 
     */
    public long getMax() {
        return max;
    }

    /**
     * Sets the value of the max property.
     * 
     */
    public void setMax(long value) {
        this.max = value;
    }

    /**
     * Gets the value of the includeChild property.
     * 
     */
    public boolean isIncludeChild() {
        return includeChild;
    }

    /**
     * Sets the value of the includeChild property.
     * 
     */
    public void setIncludeChild(boolean value) {
        this.includeChild = value;
    }

    /**
     * Gets the value of the includeFiles property.
     * 
     */
    public boolean isIncludeFiles() {
        return includeFiles;
    }

    /**
     * Sets the value of the includeFiles property.
     * 
     */
    public void setIncludeFiles(boolean value) {
        this.includeFiles = value;
    }

    /**
     * Gets the value of the requestExpression property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestExpression() {
        return requestExpression;
    }

    /**
     * Sets the value of the requestExpression property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestExpression(String value) {
        this.requestExpression = value;
    }

    /**
     * Gets the value of the criteria property.
     * 
     * @return
     *     possible object is
     *     {@link Criteria }
     *     
     */
    public Criteria getCriteria() {
        return criteria;
    }

    /**
     * Sets the value of the criteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link Criteria }
     *     
     */
    public void setCriteria(Criteria value) {
        this.criteria = value;
    }

    /**
     * Gets the value of the order property.
     * 
     * @return
     *     possible object is
     *     {@link OrderClause }
     *     
     */
    public OrderClause getOrder() {
        return order;
    }

    /**
     * Sets the value of the order property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderClause }
     *     
     */
    public void setOrder(OrderClause value) {
        this.order = value;
    }

}
