
package com.bnpparibas.assurance.sugar.internal.service.app.acl.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://sugar.assurance.bnpparibas.com/internal/service/app/acl/v1}Scope"/&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1}AclId"/&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1}BasketId"/&gt;
 *         &lt;element name="IsInstanceValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "scope",
    "aclId",
    "basketId",
    "isInstanceValue"
})
@XmlRootElement(name = "assignToBasketRequest")
public class AssignToBasketRequest {

    @XmlElement(name = "Scope", required = true)
    protected String scope;
    @XmlElement(name = "AclId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1", required = true)
    protected AclId aclId;
    @XmlElement(name = "BasketId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1", required = true)
    protected BasketId basketId;
    @XmlElement(name = "IsInstanceValue")
    protected boolean isInstanceValue;

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    /**
     * Gets the value of the aclId property.
     * 
     * @return
     *     possible object is
     *     {@link AclId }
     *     
     */
    public AclId getAclId() {
        return aclId;
    }

    /**
     * Sets the value of the aclId property.
     * 
     * @param value
     *     allowed object is
     *     {@link AclId }
     *     
     */
    public void setAclId(AclId value) {
        this.aclId = value;
    }

    /**
     * Gets the value of the basketId property.
     * 
     * @return
     *     possible object is
     *     {@link BasketId }
     *     
     */
    public BasketId getBasketId() {
        return basketId;
    }

    /**
     * Sets the value of the basketId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasketId }
     *     
     */
    public void setBasketId(BasketId value) {
        this.basketId = value;
    }

    /**
     * Gets the value of the isInstanceValue property.
     * 
     */
    public boolean isIsInstanceValue() {
        return isInstanceValue;
    }

    /**
     * Sets the value of the isInstanceValue property.
     * 
     */
    public void setIsInstanceValue(boolean value) {
        this.isInstanceValue = value;
    }

}
