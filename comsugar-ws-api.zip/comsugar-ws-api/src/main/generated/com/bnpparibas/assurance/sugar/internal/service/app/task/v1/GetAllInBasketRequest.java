
package com.bnpparibas.assurance.sugar.internal.service.app.task.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Start" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="Max" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element ref="{http://sugar.assurance.bnpparibas.com/internal/service/app/task/v1}Scope"/&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1}BasketId"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "start",
    "max",
    "scope",
    "basketId"
})
@XmlRootElement(name = "GetAllInBasketRequest")
public class GetAllInBasketRequest {

    @XmlElement(name = "Start")
    protected long start;
    @XmlElement(name = "Max")
    protected long max;
    @XmlElement(name = "Scope", required = true)
    protected String scope;
    @XmlElement(name = "BasketId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1", required = true)
    protected BasketId basketId;

    /**
     * Gets the value of the start property.
     * 
     */
    public long getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     */
    public void setStart(long value) {
        this.start = value;
    }

    /**
     * Gets the value of the max property.
     * 
     */
    public long getMax() {
        return max;
    }

    /**
     * Sets the value of the max property.
     * 
     */
    public void setMax(long value) {
        this.max = value;
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    /**
     * Gets the value of the basketId property.
     * 
     * @return
     *     possible object is
     *     {@link BasketId }
     *     
     */
    public BasketId getBasketId() {
        return basketId;
    }

    /**
     * Sets the value of the basketId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasketId }
     *     
     */
    public void setBasketId(BasketId value) {
        this.basketId = value;
    }

}
