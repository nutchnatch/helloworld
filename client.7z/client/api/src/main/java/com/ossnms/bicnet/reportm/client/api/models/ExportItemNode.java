package com.ossnms.bicnet.reportm.client.api.models;

import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;

import javax.swing.tree.DefaultMutableTreeNode;


public class ExportItemNode extends DefaultMutableTreeNode {

    private static final long serialVersionUID = 6886486715515622430L;

    private IReportManagerExportItem item;

    public ExportItemNode(String name) {
        setUserObject(name);
    }

    public ExportItemNode(IReportManagerExportItem item) {
        setUserObject(item.getName());
        this.item = item;
    }

    public IReportManagerExportItem getItem() {
        return item;
    }
}
