package com.ossnms.bicnet.reportm.client.api.ui.utils;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.tools.jfx.ETimeDisplay;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeConvertionUtils {

	public TimeConvertionUtils() {
	}

	/**
	 * Gets the current client Time Zone.
	 * 
	 * @return The ETimeDisplay of the current time
	 */
	public static ETimeDisplay getCurrentETimeDisplay() {
	    ETimeDisplay obj;
	
	    String timeDisplayStr = RMPluginHelperImpl.getInstance().getCfPluginSite().getClientProperty(BiCNetPluginClientProperties.TIME_DISPLAY, BiCNetPluginClientProperties.TIME_DISPLAY_CST);
	
	    if (timeDisplayStr.compareTo(BiCNetPluginClientProperties.TIME_DISPLAY_LOCAL) == 0) {
	        obj = ETimeDisplay.fromInteger(ETimeDisplay.i_LOCALTIME);
	    } else if (timeDisplayStr.compareTo(BiCNetPluginClientProperties.TIME_DISPLAY_GMT) == 0) {
	        obj = ETimeDisplay.fromInteger(ETimeDisplay.i_GMT);
	    } else { // by default, CST
	        obj = ETimeDisplay.fromInteger(ETimeDisplay.i_CST);
	    }
	
	    return obj;
	}

	/**
	 * Converts a Date to a formatted Time Zone date.
	 * 
	 * @param date
	 *            - The Date to be converted
	 * @param dateFormatPattern
	 *            - The date format pattern to use
	 * @return the Date formatted in the client Time Zone format.
	 */
	public static String convertToTime(final Date date, String dateFormatPattern) {
		if (date == null || dateFormatPattern == null) {
			return null;
		}
		
	    final ETimeDisplay eTimeDisplay = getCurrentETimeDisplay();
	
	    DateFormat df = new SimpleDateFormat(dateFormatPattern);
	    df.setTimeZone(eTimeDisplay.getTimeZone());
	
	    return df.format(date);
	}

}
