package com.ossnms.bicnet.reportm.client.api.models;

import com.coriant.widgets.togglebuttontree.ToggleButtonTreeSelectionModel;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import com.ossnms.bicnet.reportmanager.util.Constants;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Stream.concat;
import static java.util.stream.Stream.of;

public abstract class AbstractExportableItemsModel extends DefaultTreeModel {

    private static final long serialVersionUID = 171363667263245792L;

    private ToggleButtonTreeSelectionModel<ExportItemNode> selectionModel;

    protected AbstractExportableItemsModel() {
        super(new ExportItemNode("All"));
    }

    public void setSelectionModel(ToggleButtonTreeSelectionModel<ExportItemNode> selectionModel) {
        this.selectionModel = selectionModel;
    }

    protected ToggleButtonTreeSelectionModel<ExportItemNode> getSelectionModel() {
        return selectionModel;
    }

    @Override
    public ExportItemNode getRoot() {
        return (ExportItemNode) super.getRoot();
    }

    /**
     * Initializes the item container.
     */
    public void initFromExportableItems(Iterable<IExportableItem> exportableItems) {

        getRoot().removeAllChildren();
        addExportableItems(exportableItems);
    }

    public void setAllSelected() {
        selectionModel.setSelectionPath(getTreePath(getRoot()));
    }

    /**
     * Adds options section for each plugin if user has rights
     */
    private void addExportableItems(Iterable<IExportableItem> exportableItems) {

        collectTreeItems(exportableItems);
    }

    /**
     * Collects all items through exportableItems
     * @param exportableItems - items used on the collecting process
     * @return collected items
     */
    public abstract List<ExportItemNode> collectTreeItems(Iterable<IExportableItem> exportableItems);

    /**
     * Get all selectd nodes
     * @return selected items
     */
    public abstract IExportableItem[] getAllSelectedNodes();

    public void addChildItems(ExportItemNode itemNode) {
        Iterable<IReportManagerExportItem> children = itemNode.getItem().getChildImportExportItems();
        StreamSupport.stream(children.spliterator(), false)
                .map(ExportItemNode::new)
                .map(node -> {
                    itemNode.add(node);
                    return node;
                })
                .collect(toList());
    }

    public boolean checkSelected(ExportItemNode node) {
        TreePath treePath = getTreePath(node);
        if (selectionModel.isPathSelected(treePath)) {
            setNodeSelection(node, 1);
            return true;
        } else {
            setNodeSelection(node, 0);
        }

        TreePath[] selectedPaths = selectionModel.getSelectionPaths();
        if (selectedPaths != null) {
            for (TreePath selectedPath : selectedPaths) {
                if (selectedPath.isDescendant(treePath) || treePath.isDescendant(selectedPath)) {
                    setNodeSelection(node, 1);
                    return true;
                } else {
                    setNodeSelection(node, 0);
                }
            }
        }

        return false;
    }

    private void setNodeSelection(ExportItemNode node, int selected) {
        if (null != node.getItem()) {
            node.getItem().setSelection(selected);
        }
    }

    public TreePath getTreePath(ExportItemNode node) {
        return new TreePath(node.getPath());
    }

    /**
     * @return steam of all nodes in tree for specified node in BFS order
     */
    public Stream<ExportItemNode> flattenTreeOf(ExportItemNode node) {
        return concat(of(node), childrenOf(node).stream().flatMap(this::flattenTreeOf));
    }

    /**
     * @return children of specified node
     */
    private List<ExportItemNode> childrenOf(ExportItemNode node) {
        int children = node.getChildCount();
        List<ExportItemNode> result = new ArrayList<>(children);
        for (int i = 0; i < children; i++) {
            ExportItemNode child = (ExportItemNode) node.getChildAt(i);
            if (null != child && child.isLeaf()) {
                checkSelected(child);
            }
            result.add((ExportItemNode) node.getChildAt(i));
        }
        return result;
    }

    public List<ExportItemNode> getChildren(ExportItemNode node) {
        int children = node.getChildCount();
        List<ExportItemNode> result = new ArrayList<>(children);
        for (int i = 0; i < children; i++) {
            result.add((ExportItemNode) node.getChildAt(i));
        }
        return result;
    }
}
