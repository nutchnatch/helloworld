package com.ossnms.bicnet.reportm.client.api.views;

import java.awt.Cursor;
import java.util.TimeZone;

import javax.annotation.Nonnull;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTable;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientPropertyListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPrintData;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.jfx.FrameworkPrintData;
import com.ossnms.bicnet.framework.client.persistence.FrameworkPersistentView;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.api.ui.utils.TimeConvertionUtils;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.tools.jfx.ETimeDisplay;
import com.ossnms.tools.jfx.print.JfxPrintData;

/**
 * Abstract class to be extended by all views in RM to set common behaviors
 */
public abstract class AbstractView extends FrameworkPersistentView implements BiCNetPluginClientPropertyListener {

	private static final long serialVersionUID = 2377916150747959259L;

    public AbstractView(@Nonnull final String id, @Nonnull final String title, @Nonnull final FrameworkDocument doc, @Nonnull final boolean resizable, @Nonnull final int helpId) throws BcbException {
		super(id, title, doc, resizable, helpId);
	}


	@Override
	public void eventOpened() {
		super.eventOpened();

		initKeyBindings();
	}

	@Override
	public void eventClosing() {
		if (RMPluginHelperImpl.getInstance().isLoggingOff() && supportsPersistance()) {
			RMPluginHelperImpl.getInstance().addOpenView(getClass().getName(), getCommandClassName());
		}
		super.eventClosing();
	}

	/**
	 * Initialize key bindings
	 */
	protected abstract void initKeyBindings();

	@Override
	public Icon getIcon() {
		return IconFactory.getIconWithOverlay(getViewIcon(), getViewAction());
	}

	/**
	 * Get view image icon
	 *
	 * @return the icon
	 */
	protected abstract ImageIcon getViewIcon();

	/**
	 * Get the main action from view
	 *
	 * @return the main action expected to be implemented by view
	 */
	protected abstract ActionType getViewAction();

	@Override
	public boolean isPrintable() {
		return false;
	}

	@Override
	protected void setActivityIndicatorVisible(@Nonnull final boolean visible) {
		super.setActivityIndicatorVisible(visible);

		if (visible) {
			getMainComponent().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		}
		else {
			getMainComponent().setCursor(Cursor.getDefaultCursor());
		}
	}

	public abstract String getCommandClassName();

	public abstract boolean supportsPersistance();

	@Override
	public BiCNetPluginPrintData getPrintData() {
		JfxPrintData data = new JfxPrintData(true);
		data.setWindowName(getTitle());
		data.addListItem(getDataToPrint());
		return new FrameworkPrintData(data);
	}

	public abstract JTable getDataToPrint();

    public abstract void timeDisplayChangeActions(TimeZone timeZone);

	/**
	 * Called by site when client properties have changed. Updates the GUI according to the time zone defined by the client.
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientPropertyListener#eventPluginClientPropertiesChanged()
	 */
	@Override
	public void eventPluginClientPropertiesChanged() {
        ETimeDisplay eTimeDisplay = TimeConvertionUtils.getCurrentETimeDisplay();
        TimeZone timeZone = eTimeDisplay.getTimeZone();
        timeDisplayChangeActions(timeZone);
	}
}
