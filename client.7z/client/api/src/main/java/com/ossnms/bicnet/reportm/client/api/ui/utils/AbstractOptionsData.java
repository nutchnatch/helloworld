package com.ossnms.bicnet.reportm.client.api.ui.utils;

import com.ossnms.tools.jfx.JfxOptionsData;
import com.ossnms.tools.jfx.JfxProperties;
import com.ossnms.tools.jfx.components.JfxPersistentProperties;
import com.ossnms.tools.jfx.table.JfxTableProperties;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class AbstractOptionsData extends JfxOptionsData {
    private Map persistentPropertiesMap = new HashMap();

    private static final String PROPERTIES ="Properties.";

    public AbstractOptionsData() {
    }

    /**
     * ************************************************************************
     * Creates a persistent properties object of the appropriate class.
     *
     * @param strClass   Class name.
     * @param strViewId  View ID.
     * @param nControlId Control ID.
     * @return Persistent properties object or null.
     * ************************************************************************
     */
    public abstract JfxPersistentProperties createPersistentProperties(String strClass, String strViewId, int nControlId);

    /**
     * ************************************************************************
     * Sets persistant properties.
     *
     * @param props Properties object.
     * ************************************************************************
     */

    public void setPersistentProperties(JfxPersistentProperties props) {
        getPersistentPropertiesMap().put(props, props);
    }

    /**
     * ************************************************************************
     * Returns persistant properties for the given table.
     *
     * @param viewID     ID of view.
     * @param nControlID ID of table.
     * @return Table properties object or null.
     * ************************************************************************
     */
    public JfxTableProperties getPersistentTableProperties(String viewID, int nControlID) {
        return (JfxTableProperties) getPersistentPropertiesMap().get(new JfxTableProperties(viewID, nControlID));
    }

    /**
     * ************************************************************************
     * Loads user options from LDAP server.
     *
     * @param props Properties for Client Frame stored in the LDAP.
     * ************************************************************************
     */
    public void loadData(JfxProperties props) {
        JfxPersistentProperties persistent;
        String strClass, strViewId;
        int nIndex, nControlId;

        // Persistent properties
        getPersistentPropertiesMap().clear();
        for (nIndex = 0; nIndex < (Integer.MAX_VALUE - 1); nIndex++) {
        	strClass = props.getProperty(PROPERTIES + nIndex + ".Class");
        	strViewId = props.getProperty(PROPERTIES + nIndex + ".ViewID");
            if ( strClass != null && strViewId != null ) {
                nControlId = props.getPropertyAsInt(PROPERTIES + nIndex + ".ControlID", 0);
                persistent = createPersistentProperties(strClass, strViewId, nControlId);
                if (persistent != null ) {
                    persistent.loadProperties(props, PROPERTIES + nIndex);
                    getPersistentPropertiesMap().put(persistent, persistent);
                }
            } else {
                break;
            }
        }
    }

    /**
     * ************************************************************************
     * Saves user options to LDAP server.
     *
     * @param props Properties for Client Frame stored in the LDAP.
     * ************************************************************************
     */
    public void saveData(JfxProperties props) {
        JfxPersistentProperties persistent;
        Iterator iter;
        int nIndex;

        // Persistent properties
        nIndex = 0;
        iter = getPersistentPropertiesMap().values().iterator();
        while (iter.hasNext()) {
            persistent = (JfxPersistentProperties) iter.next();

            props.setProperty(PROPERTIES + nIndex + ".Class", persistent.getClass().getName());
            props.setProperty(PROPERTIES + nIndex + ".ViewID", persistent.getViewID().toString());
            props.setProperty(PROPERTIES + nIndex + ".ControlID", persistent.getControlID());
            persistent.saveProperties(props, PROPERTIES + nIndex);

            nIndex++;
        }
    }

    public Map getPersistentPropertiesMap() {
        return persistentPropertiesMap;
    }

    public void setPersistentPropertiesMap(Map persistentPropertiesMap) {
        this.persistentPropertiesMap = persistentPropertiesMap;
    }
}
