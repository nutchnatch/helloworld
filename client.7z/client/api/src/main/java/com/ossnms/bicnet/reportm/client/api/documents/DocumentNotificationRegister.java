package com.ossnms.bicnet.reportm.client.api.documents;

import com.ossnms.bicnet.framework.client.helpers.FrameworkDefaultUpdateJob;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkNotifFilterProperties;
import static com.ossnms.bicnet.reportm.client.api.plugin.configuration.NotificationTopicConf.TOPIC_FACTORY_NAME;
import static com.ossnms.bicnet.reportm.client.api.plugin.configuration.NotificationTopicConf.TOPIC_NAME;

import javax.annotation.Nonnull;

public final class DocumentNotificationRegister {

    public static final DocumentNotificationRegister INSTANCE = new DocumentNotificationRegister();

    private DocumentNotificationRegister(){
    }

    public static DocumentNotificationRegister getInstance(){
        return INSTANCE;
    }

    /**
     * Register Document for RM Notifications
     * @param document - Document to process notifications
     * @param jobName - Job name associated to this configuration
     * @param filterProperties - Filter properties to be used in the configuration
     * @return
     */
    public FrameworkDefaultUpdateJob registerDocumentForNotification(@Nonnull FrameworkDocument document, @Nonnull String jobName, @Nonnull FrameworkNotifFilterProperties filterProperties){
        FrameworkDefaultUpdateJob job = new FrameworkDefaultUpdateJob("", jobName, null, document, filterProperties);
        job.setTopicFactoryName(TOPIC_FACTORY_NAME.getName());
        job.setTopicName(TOPIC_NAME.getName());
        return job;
    }
}