package com.ossnms.bicnet.reportm.client.api.plugin;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceProvider;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;

/**
 * Provide plugin helper for Report Manager
 * Allow all Plugin operations
 */
public final class RMPluginHelperImpl extends FrameworkPluginHelper implements RMPluginHelper{

    private static final RMPluginHelperImpl INSTANCE = new RMPluginHelperImpl();

    private String pluginId;
    private final Map<String, String> openPluginViews = new HashMap<>();
    private boolean loggingOff;
    /**
     * Return Singleton Instance of RMPluginHelperImpl
     * @return
     */
    public static RMPluginHelperImpl getInstance(){
        return INSTANCE;
    }

    /**
     * Protected Constructor
     *
     */
    private RMPluginHelperImpl() {
        super(null);
    }

    @Override
    public String getPluginId() {
        return pluginId;
    }

    @Override
    public ISessionContext getSessionContext() {
        return super.getLogonContext();
    }

    @Override
    public void setPluginId(String pluginId) {
        this.pluginId = pluginId;
    }

    @Override
    public void uninitialize(String info) {

    }

    @Override
    public IPluginSecurityProvider getSecurityProvider() {
        try {
            return getCfPluginSite().getSecurityProvider();
        } catch (BiCNetPluginException e) {
            throw new IllegalStateException(e);
        }
    }
    
    /**
     * Adds a currently open View to the "session manager-like" list. The list values will be saved to LDAP, and the
     * next time the user logs into the system, the saved windows will be loaded, therefore restoring the user session.
     *
     * @param aView    the key to store the view's command (i.e.: getClass().getName() )
     * @param aCommand the command fully qualified name (i.e.: Command.class.getName())
     */
    public void addOpenView(String aView, String aCommand) {
        openPluginViews.put(aView, aCommand);
    }

    public Map<String, String> getOpenViews() {
        return Collections.unmodifiableMap(openPluginViews);
    }

    public void clearPluginViews() {
        openPluginViews.clear();
    }
    
    public boolean isLoggingOff() {
        return loggingOff;
    }
    
    public void setLoggingOff(boolean value) {
        loggingOff = value;
    }

    /**
     * Get the ECS Plugin Provider
     * @return
     * @throws BiCNetPluginException
     */
    @Override
    public BiCNetPluginExternalCommunicationServiceProvider getPluginExternalCommunicationService() {
        try {
            return getCfPluginSite().getExternalCommunicationServiceProvider();
        } catch (BiCNetPluginException e) {
            throw new IllegalStateException(e);
        }
    }

}
