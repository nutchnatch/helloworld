package com.ossnms.bicnet.reportm.client.api.plugin.configuration;

/**
 * Notification configuration for Report Manager Client
 */
public enum NotificationTopicConf {

    //JMS factory configuration
    TOPIC_FACTORY_NAME("ConnectionFactoryHornetQ"),
    TOPIC_NAME("topic/client"),
    SENDER_ID("SenderId");

    private String name;

    private NotificationTopicConf(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
