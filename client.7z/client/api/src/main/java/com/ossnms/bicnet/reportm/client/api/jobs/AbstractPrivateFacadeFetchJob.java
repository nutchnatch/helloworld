/*
 * Copyright (C) Coriant - 2013
 * 
 * The reproduction, transmission or use of this document or its contents is not
 * permitted without express written authorization. All rights, including rights
 * created by patent grant or registration of a utility model or design, are
 * reserved. Modifications made to this document are restricted to authorized
 * personnel only. Technical specifications and features are binding only when
 * specifically and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.api.jobs;

import com.google.common.base.Joiner;
import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportmanager.servicelocator.ReportManagerServiceLocator;

import javax.annotation.Nonnull;

import static java.util.Optional.ofNullable;

public abstract class AbstractPrivateFacadeFetchJob<JobReturn, FacadeType extends IFacade> extends AbstractFetchJob<FacadeType>
        implements IJobVisitable{

    /**
     * The fetch job to be created
     *
     * @param privateFacade  The privateFacade to invoke
     * @param id             The id of this job
     * @param name           The name of this job
     * @param additionalInfo Any additional information of the job
     * @param jobOwner       The job owner
     */
    public AbstractPrivateFacadeFetchJob(@Nonnull final Class<FacadeType> privateFacade, @Nonnull final String id, @Nonnull final String name,
                                         @Nonnull final String additionalInfo, @Nonnull final IFrameworkDocument jobOwner) {
        super(privateFacade, id, name, additionalInfo, jobOwner);
    }

    /**
     * execute - executes the job and return the result to the job owner.
     *
     * @return Object Result
     */
    @Override
    public final Object execute(final Object obj) throws FrameworkException {
        getLogger().debug("execute in PrivateFacadeFetchJob");
        final Object result;

        final ReportManagerServiceLocator reportManagerServiceLocator = ReportManagerServiceLocator.getInstance();
        FacadeType facade = ofNullable(reportManagerServiceLocator.getIPrivateFacade(getFacade()))
                .orElseThrow(() -> new FrameworkException("Error while creating facade. Unable to execute with null facade!"));

        try {
            result = invokeMethodFromFacade(facade);
            getLogger().debug("Reply from invokeMethodFromFacade({}) invocation: {}", facade, result);
        } catch (final Exception e) {

            final String joiner = Joiner.on(" ").skipNulls()
                    .join("Exception while executing invokeMethodFromFacade: ", "Operation",
                            getName(), "from facade", getFacade() + "!");
            // Log error
            getLogger().error(joiner, e);
            // throw exception
            throw new FrameworkException(joiner, e);
        }
        return result;
    }

    /**
     * The operation from the interface to be executed
     *
     * @param iPrivateFacade The private facade to be executed
     * @return result of the invocation
     * @throws BcbException
     */
    public abstract JobReturn invokeMethodFromFacade(@Nonnull final FacadeType iPrivateFacade) throws BcbException;
}
