/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.api.documents;

//Represent the job states
public enum OperationKey {
    ERROR,
    LOAD_EXPORT_DATA,
    LOAD_EXPORTABLE_ITEMS,
    LOAD_SYSTEM_SETTINGS,
    NOTHING_TO_DO,
    HANDLE_NOTIFICATIONS,
    MANUAL_EXPORT_JOB_EXECUTED,
    LOAD_DCN_LIST_DATA,
    LOAD_ALARM_FILTER,
    LOAD_OUTAGE_ALL_NES_ITEMS,
    LOAD_OUTAGE_SETTINGS_ITEMS,
    LOAD_EXPORT_LOCATION_DATA,
    LOAD_OUTAGE_SETTINGS_WITH_DEFAULT,
    LOAD_ALARMMESSAGING_SETTINGS
}
