/*
 * Copyright (C) Coriant - 2014
 * 
 * The reproduction, transmission or use of this document or its contents is not
 * permitted without express written authorization. All rights, including rights
 * created by patent grant or registration of a utility model or design, are
 * reserved. Modifications made to this document are restricted to authorized
 * personnel only. Technical specifications and features are binding only when
 * specifically and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.api.ui.utils;

import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.bicnet.reportmanager.util.Settings;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public final class KeyBindings {

	// Accelerators to be used in commands
	public static final String ACCELERATOR_NEW = "control N";
	public static final String ACCELERATOR_UPDATE = "F5";
	public static final String ACCELERATOR_PROPERTIES = "ENTER";
	public static final String ACCELERATOR_DELETE = "DELETE";
	public static final String ACCELERATOR_CUT = "control X";
	public static final String ACCELERATOR_PASTE = "control V";
	public static final String ACCELERATOR_DETAILS = "ENTER";
	public static final String ACCELERATOR_INCREASE = "pressed PLUS";
	public static final String ACCELERATOR_DECREASE = "pressed MINUS";

	private KeyBindings() {
		// Utility class
	}

	public static void installGoodiesToggle(final FrameworkView view) {
		final Action goodiesToggle = new AbstractAction() {
			private static final long serialVersionUID = 8008657887577197555L;
			private int counter = 0;
			@Override
			public void actionPerformed(final ActionEvent e) {
				if (++counter < 5) {
					return;
				}
				counter = 0;
				final boolean newAdvancedMode = !Settings.isAdvancedMode();
				Settings.setAdvancedMode(newAdvancedMode);
				final StringBuilder message = new StringBuilder();
				message.append("CSL goodies are ");
				message.append(newAdvancedMode ? "enabled." : "disabled.").append('\n');
				message.append("Reopening CSL windows ensures this setting is properly applied.");
				JOptionPane.showMessageDialog(view, message);
			}
		};

		final int modifiers = InputEvent.CTRL_DOWN_MASK | InputEvent.ALT_DOWN_MASK | InputEvent.SHIFT_DOWN_MASK;
		final KeyStroke keyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_C, modifiers);
		installActionOnKey(view, "GoodiesToggleOnKey", goodiesToggle, keyStroke);
	}

	private static void installActionOnKey(final JComponent component, final String actionId, final Action action, final KeyStroke keyStroke) {
		component.getActionMap().put(actionId, action);
		final InputMap inputMap = component.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
		inputMap.put(keyStroke, actionId);
	}

	public static void installActionOnKey(final JComponent component, final String actionId, final Action action, final int keyCode) {
		final KeyStroke keyStroke = KeyStroke.getKeyStroke(keyCode, 0);
		installActionOnKey(component, actionId, action, keyStroke);
	}

	public static void installActionOnCtrlKey(final FrameworkView view, final String actionId, final Action action, int key) {
		final KeyStroke keyStroke = KeyStroke.getKeyStroke(key, KeyEvent.CTRL_MASK);
		installActionOnKey(view, actionId, action, keyStroke);
	}
}

