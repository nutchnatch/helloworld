package com.ossnms.bicnet.reportm.client.api.plugin;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceProvider;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;


public interface RMPluginHelper {
    /**
     * @return The RM Plug-in Identification.
     */
    String getPluginId();

    /**
     * @return The current session context.
     */
    ISessionContext getSessionContext();

    /**
     * Sets the RM Plug-in Identification.
     * @param pluginId
     */
    void setPluginId(String pluginId);

    /**
     * @return The Plug-in Object that access the BiCNet Plug-in Environment.
     */
    BiCNetPluginSite getCfPluginSite();

    /**
     * Called when the BiCNet Plug-in Client GUI is open.
     *
     * @param logonContext
     */
    void initialize(ISessionContext logonContext);

    /**
     * Called when the BiCNet Plug-in Client GUI is destroyed.
     *
     */
    void uninitialize(String info);

    /**
     * @return The BiCNet Security Plug-in interface.
     */
    IPluginSecurityProvider getSecurityProvider();

    /**
     * get External Communication Service contribution
     * @return BiCNetPluginExternalCommunicationServiceProvider
     */
    BiCNetPluginExternalCommunicationServiceProvider getPluginExternalCommunicationService();

    /**
     * Check if user is logging off
     * @return true if user is logging off or false otherwise
     */
    boolean isLoggingOff();

    /**
     * Set user logging off state
     * @param value true if user is logging off or false otherwise
     */
    void setLoggingOff(boolean value);

    /**
     * Clears plugin view cash
     */
    void clearPluginViews();

}
