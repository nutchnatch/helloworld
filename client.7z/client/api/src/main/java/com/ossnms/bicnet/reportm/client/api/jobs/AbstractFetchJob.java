/*
 * Copyright (C) Coriant - 2013
 * 
 * The reproduction, transmission or use of this document or its contents is not
 * permitted without express written authorization. All rights, including rights
 * created by patent grant or registration of a utility model or design, are
 * reserved. Modifications made to this document are restricted to authorized
 * personnel only. Technical specifications and features are binding only when
 * specifically and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.api.jobs;

import com.google.common.base.Optional;
import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

/**
 * Abstract class to be used when invoking a private interface
 */
abstract class AbstractFetchJob<FacadeType extends IFacade> extends FrameworkFetchJob {

	/** The logger used by this class. */
	private final Logger LOGGER = LoggerFactory.getLogger(getClass());

	/** The facade to used in the job **/
	private final Class<FacadeType> iFacade;

	/**
	 * The invocation to be created
	 * @param id The id of this invocation
	 * @param name The name of this invocation
	 * @param additionalInfo Any additional information of the invocation
	 * @param jobOwner The job owner
	 */
	public AbstractFetchJob(@Nonnull final Class<FacadeType> iFacade, @Nonnull final String id, @Nonnull final String name, @Nonnull final String additionalInfo, @Nonnull final IFrameworkDocument jobOwner) {
		super(id, name, additionalInfo, jobOwner);
        final Optional<Class<FacadeType>> thisFacade = Optional.fromNullable(iFacade);
        if(thisFacade.isPresent()){
            this.iFacade = iFacade;
        }else{
            throw new IllegalArgumentException("The iFacade must not be null");
        }
	}

	/**
	 * The logger for this operation
	 * @return the logger
	 */
	public final Logger getLogger(){
		return this.LOGGER;
	}

	/**
	 * The Session Context
	 * @return the session context
	 */
	public final ISessionContext getSessionContext(){
		return RMPluginHelperImpl.getInstance().getLogonContext();
	}

	/**
	 * The Stored Facade
	 * @return the iFacade
	 */
	public final Class<FacadeType> getFacade() {
		return iFacade;
	}
}
