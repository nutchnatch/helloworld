/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.api.ui.utils;

import com.ossnms.bicnet.framework.client.jfx.FrameworkHelpUtils;

/**
 * Report Manager List Plug-in Help IDs.
 */
public final class HelpIds {
    // Context sensitive help IDs (one for each view)
    // These IDs must begin with "HID_" to be processed in createHelpMap() method

    public static final int HID_INVENTORY_EXPORT_DATA;
    public static final int HID_SCHEDULE_INVENTORY_EXPORT;
    public static final int HID_SCHEDULE_CONFIGURATION_EXPORT;
    public static final int HID_CONFIGURATION_EXPORT;
    public static final int HID_DCN_LIST;
    public static final int HID_MANUAL_EXPORT;
    public static final int HID_ALARMS_OUTAGE_EXPORT;
    public static final int HID_MANUAL_ALARMS_OUTAGE_EXPORT;
    public static final int HID_SCHEDULE_ALARMS_OUTAGE_EXPORT;
    public static final int HID_ALARM_MESSAGING;

    /**
     * A random prefix used as base for the help IDs (using the plugin load id in jboss).
     */
    // TODO use correct plug-in load id
    private static final int PREFIX = 1100;

    /**
     * The shift applied to the prefix for each help ID.
     */
    private static final int SHIFT = 16;

    static {
        int hidCounter = PREFIX << SHIFT;                   // 72089600

        HID_INVENTORY_EXPORT_DATA = ++hidCounter;           // 72089601
        HID_SCHEDULE_INVENTORY_EXPORT = ++hidCounter;       // 72089602
        HID_CONFIGURATION_EXPORT = ++hidCounter;            // 72089603
        HID_DCN_LIST = ++hidCounter;                        // 72089604
        HID_MANUAL_EXPORT = ++hidCounter;                   // 72089605
        HID_SCHEDULE_CONFIGURATION_EXPORT = ++hidCounter;   // 72089606
        HID_ALARMS_OUTAGE_EXPORT = ++hidCounter;            // 72089607
        HID_MANUAL_ALARMS_OUTAGE_EXPORT = ++hidCounter;     // 72089608
        HID_SCHEDULE_ALARMS_OUTAGE_EXPORT = ++hidCounter;   // 72089609
        HID_ALARM_MESSAGING = ++hidCounter;                 // 72089610
    }

    /**
     * Private constructor.
     */
    private HelpIds() {
        // Empty block
    }

    /**
     * Generates a help map file suitable for importing in RoboHelp. It contains
     * an entry for every view ID.
     *
     * @param strPath
     *            Path of help map file.
     */
    public static void createHelpMap(String strPath) {
        FrameworkHelpUtils.createHelpMap(new HelpIds(), strPath);
    }
}