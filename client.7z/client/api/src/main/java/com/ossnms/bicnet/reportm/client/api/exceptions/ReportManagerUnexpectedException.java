/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.api.exceptions;

import org.slf4j.helpers.MessageFormatter;

/**
 * A Runtime exception to be thrown upon any <b>unexpected exception</b> within the <b>Common Report Manager plugin context</b>.
 */
public class ReportManagerUnexpectedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new runtime exception with the specified detail message and cause.
     * 
     * Note that the detail message associated with cause is not automatically incorporated in this runtime exception's
     * detail message.
     * 
     * @param message
     *            the detail message (which is saved for later retrieval by the getMessage() method).
     * @param cause
     *            the cause (which is saved for later retrieval by the getCause() method). (A null value is permitted,
     *            and indicates that the cause is nonexistent or unknown.)
     */
    public ReportManagerUnexpectedException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new runtime exception with null as its detail message. The cause is not initialized, and may
     * subsequently be initialized by a call to initCause.
     * 
     * @param message
     *            the detail message (which is saved for later retrieval by the getMessage() method).
     */
    public ReportManagerUnexpectedException(String message) {
        super(message);
    }

    /**
     * Constructs a new runtime exception with the specified cause and a detail message of (cause==null ? null :
     * cause.toString()) (which typically contains the class and detail message of cause). This constructor is useful
     * for runtime exceptions that are little more than wrappers for other throwables.
     * 
     * @param cause
     *            the cause (which is saved for later retrieval by the getCause() method). (A null value is permitted,
     *            and indicates that the cause is nonexistent or unknown.)
     */
    public ReportManagerUnexpectedException(Throwable cause) {
        super(cause);
    }

    /**
     * Construct a new Exception with a given detail message built with the given format and parameters
     * @param format - A format String
     * @param parameters - Parameters referenced by format specifiers in the format string
     */
    public ReportManagerUnexpectedException(String format, Object... parameters){
        this(buildMessage(format, parameters));
    }

    /**
     * Construct a new Exception with a given cause and a detail message built with the given format and parameters
     * @param format - A format String
     * @param cause - Exception cause
     * @param parameters - Parameters referenced by format specifiers in the format string
     */
    public ReportManagerUnexpectedException(String format, Throwable cause, Object... parameters){
        this(buildMessage(format, parameters), cause);
    }

    private static String buildMessage(String format, Object... parameters){
        return MessageFormatter.arrayFormat(format, parameters).getMessage();
    }
}
