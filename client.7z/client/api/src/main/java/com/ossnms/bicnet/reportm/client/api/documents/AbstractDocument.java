package com.ossnms.bicnet.reportm.client.api.documents;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDefaultUpdateJob;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkNotifFilterProperties;
import com.ossnms.bicnet.framework.client.helpers.interfaces.FrameworkUpdateJobCallsInEDT;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.bicnet.reportm.client.api.exceptions.ReportManagerUnexpectedException;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitable;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem.IVisitor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;

import static java.util.Optional.ofNullable;

/**
 * Abstract class to be extended by all documents in Report Manager to set common behaviors
 */
public abstract class AbstractDocument extends FrameworkDocument implements IVisitor, FrameworkUpdateJobCallsInEDT {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractDocument.class);

    protected AbstractDocument() {
        super(RMPluginHelperImpl.getInstance());
    }

    @Override
    public void init() {
        fetchOtherData();
        fetchData();
        fetchSystemSettings();
        registrationForNotifications();
    }

    public void registrationForNotifications() {
        FrameworkNotifFilterProperties filterProps = new FrameworkNotifFilterProperties(BiCNetComponentType.REPORT_MANAGER, false);
        addAndExecuteJob(DocumentNotificationRegister.getInstance().registerDocumentForNotification(this, getClass().getName(), filterProps));
    }

    public abstract void fetchOtherData();

    /**
     * Fetch Data when Document is initialized
     */
    public abstract void fetchData();

    protected abstract void fetchSystemSettings();

    /**
     * Fire data to be updated by the GUI
     *
     * @param key - identifies the operation to be executed
     */
    public void fireUpdateData(@Nonnull final OperationKey key) {
        updateData(key);
    }

    @Override
    public Object getObject(Object key) {
        // mandatory but not used.
        return key;
    }

    public abstract OperationKey handleJobNotifications(@Nonnull IJobVisitable job, @Nonnull Object result);

    private static final String RESULT_NULL_VALUE = "Result report a null value.";
    private static final String ERROR_HANDLING_JOB = "Error handling job. ";
    private static final String ERROR_CALLING_DOCUMENT = "Error calling document to handle notification. ";

    @Override
    public void setResult(IFrameworkJob job, Object result) {
        OperationKey key = OperationKey.NOTHING_TO_DO;
        if (job.hasExceptionOccured()) {
            LOGGER.error(ERROR_HANDLING_JOB, job.getException());
            key = OperationKey.ERROR;
        } else if (job instanceof FrameworkDefaultUpdateJob) {
            if (result instanceof Notification) {
                try {
                    ((Notification) result).dispatch(this);
                } catch (BcbException e) {
                    LOGGER.error(ERROR_CALLING_DOCUMENT, e);
                }
                key = OperationKey.NOTHING_TO_DO;
            }
        } else {
            ofNullable(result).orElseThrow(() -> new ReportManagerUnexpectedException(RESULT_NULL_VALUE));
            key = handleJobNotifications((IJobVisitable) job, result);
        }

        if (OperationKey.NOTHING_TO_DO != key) {
            fireUpdateData(key);
        }
    }

    /**
     * Get Logger to log info on Client Log
     *
     * @return Logger
     */
    public final Logger getLogger() {
        return LOGGER;
    }

}
