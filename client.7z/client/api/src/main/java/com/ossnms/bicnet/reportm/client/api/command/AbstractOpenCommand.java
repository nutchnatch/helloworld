package com.ossnms.bicnet.reportm.client.api.command;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.utilities.i18n.RM18nSupport;

import javax.annotation.Nonnull;

/**
 * Contains Global behavior for all commands to be used in Report Manager
 */
public abstract class AbstractOpenCommand extends FrameworkCommand {
    private static final long serialVersionUID = 218995337305297429L;

    /**
     * Creates and define a command
     * 
     * @param name - Command name
     * @param description - Command description
     * @param menuPath - Command path
     */
    protected AbstractOpenCommand(@Nonnull final String name, @Nonnull final String description, @Nonnull final String... menuPath) {
        setCmdDetails(name, name, RM18nSupport.EMPTY_STRING, null, description, description, null, menuPath);
        setPluginHelper(RMPluginHelperImpl.getInstance());
    }

    /**
     * Brings this view to the front
     * @see com.ossnms.bicnet.framework.client.command.FrameworkCommand#bringViewToFront(com.ossnms.bicnet.bcb.plugin.BiCNetPluginView)
     */
    @Override
    public void bringViewToFront(final BiCNetPluginView view) {
        if (!(view instanceof FrameworkView)) {
            return;
        }
        ((FrameworkView) view).bringToFront();
    }
}