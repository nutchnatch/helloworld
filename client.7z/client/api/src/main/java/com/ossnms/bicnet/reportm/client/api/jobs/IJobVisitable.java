package com.ossnms.bicnet.reportm.client.api.jobs;

import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;

public interface IJobVisitable extends IFrameworkJob {

    OperationKey dispatch(IJobVisitor visitor, Object result);
}
