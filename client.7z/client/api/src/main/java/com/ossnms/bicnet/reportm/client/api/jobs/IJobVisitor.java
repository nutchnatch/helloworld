package com.ossnms.bicnet.reportm.client.api.jobs;

public interface IJobVisitor {
}
