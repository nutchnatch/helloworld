/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.core.plugin;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.reportm.client.presentation.settings.system.SystemSettingsPage;
import org.junit.Test;

import static com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext.ADMINISTRATION;
import static com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext.CONFIGURATION;
import static org.hamcrest.Matchers.hasItemInArray;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class RMPluginTest {

    @Test public void propertyPages_shouldContainSystemSettingsInAdminContext() throws Exception {
        BiCNetPluginPropertyPage[] propertyPages = new RMPlugin().getMainPropertyPages(ADMINISTRATION);
        assertThat(propertyPages, hasItemInArray(instanceOf(SystemSettingsPage.class)));
    }

    @Test public void propertyPages_shouldntContainSystemSettingsInOtherContexts() throws Exception {
        BiCNetPluginPropertyPage[] propertyPages = new RMPlugin().getMainPropertyPages(CONFIGURATION);
        assertThat(propertyPages, not(hasItemInArray(instanceOf(SystemSettingsPage.class))));
    }
}