package com.ossnms.bicnet.reportm.client.core.plugin.action;


import org.apache.commons.lang3.builder.Builder;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandRegistrar;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.commands.AlarmMessagingCommand;
import com.ossnms.bicnet.reportm.client.presentation.dcnlist.commands.DcnListCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands.ConfigurationExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.commands.InventoryExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.commands.OutageExportCommand;

/**
 * Responsible for all menu actions added to Report Manager
 */
public class PluginActionBuilder implements Builder<ImmutableMap<BiCNetPluginMainContext, BiCNetPluginAction[]>> {

    private final BiCNetPluginAction[] reportManageractions = {
            createExportCommand(), createConfigurationExportCommand(), createOutageExportCommand(), 
            createDcnListCommand(), createAlarmMessagingCommand()
    };

    /**
     * Builds main menu actions
     * @return - Immutable Map of actions
     */
    @Override
    public ImmutableMap<BiCNetPluginMainContext, BiCNetPluginAction[]> build() {
        return ImmutableMap.of(BiCNetPluginMainContext.REPORTS, reportManageractions);
    }

    /**
     * Create Command for Export menu Entry
     * @return - command for Export menu
     */
    private InventoryExportCommand createExportCommand(){
        final InventoryExportCommand inventoryExportCommand = new InventoryExportCommand();
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(inventoryExportCommand);
        return inventoryExportCommand;
    }

    /**
     * Create command for configuration export menu entry
     */
    private ConfigurationExportCommand createConfigurationExportCommand() {
        final ConfigurationExportCommand command = new ConfigurationExportCommand();
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        return command;
    }
    
    /**
     * Create command for Alarms Outage Export menu entry
     */
    private OutageExportCommand createOutageExportCommand() {
        final OutageExportCommand command = new OutageExportCommand();
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        return command;
    }
    
    /**
     * Create command for DCN List menu entry
     */
    private DcnListCommand createDcnListCommand() {
        final DcnListCommand command = new DcnListCommand();
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        return command;
    }
    
    /**
     * Create command for Alarm Messaging menu entry
     */
    private AlarmMessagingCommand createAlarmMessagingCommand() {
        final AlarmMessagingCommand command = new AlarmMessagingCommand();
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(command);
        return command;
    }
}