package com.ossnms.bicnet.reportm.client.core.plugin.configuration;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandManager;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandRegistrar;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Hashtable;
import java.util.Optional;
import java.util.Properties;

public class LdapViewManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(LdapViewManager.class);
    public void saveOpenViews(BiCNetPluginSite pluginSite) {
        try {
            Properties ldapProfile = pluginSite.getSecurityProvider().getClientSession(RMPluginHelperImpl.getInstance().getLogonContext()).getUserProfile("RMPlugin_OpenViews");
            Optional.ofNullable(ldapProfile).ifPresent(Hashtable::clear);
            ldapProfile = Optional.ofNullable(ldapProfile).orElse(new Properties());

            final Properties profiles = ldapProfile;

            RMPluginHelperImpl.getInstance().getOpenViews().entrySet().stream()
                    .map(key -> profiles.setProperty(key.getKey(), key.getValue())).toArray();

            pluginSite.getSecurityProvider().getClientSession(RMPluginHelperImpl.getInstance().getLogonContext()).setUserProfile("RMPlugin_OpenViews", profiles);
        } catch (BiCNetPluginException ex) {
            LOGGER.warn("saveOpenViews ", ex);
        }
    }

    public void restoreOpenViews(BiCNetPluginSite pluginSite) {
        try {
            Properties ldapProfile = pluginSite.getSecurityProvider().getClientSession(RMPluginHelperImpl.getInstance().getLogonContext()).getUserProfile("RMPlugin_OpenViews");
            if (ldapProfile == null) {
                return;
            }

            ldapProfile.values().stream()
                    .map(value -> ((String)value).trim())
                    .filter(value -> !value.isEmpty())
                    .map(classToLoad -> {
                        try {
                            Class view = getClass().getClassLoader().loadClass(classToLoad);
                            IFrameworkCommand viewCommand = (IFrameworkCommand) view.newInstance();
                            if (viewCommand.isEnabled(null)) { // check that the user is still allowed to open the window
                                FrameworkCommandRegistrar.getUICmdRegister().registerCmd(viewCommand);
                                FrameworkCommandManager.getCommandMgr().executeCmd(viewCommand.getCommandID(), null);
                            }
                            return viewCommand;
                        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
                            LOGGER.warn("restoreOpenViews ", e);
                        }
                        return Optional.empty();
                    }).toArray();

        } catch (BiCNetPluginException ex) {
            LOGGER.warn("restoreOpenViews ", ex);
        }
    }
}
