package com.ossnms.bicnet.reportm.client.core.plugin;

import static com.ossnms.bicnet.reportmanager.servicelocator.ReportManagerServiceLocator.getInstance;

import java.util.Collection;
import java.util.Map;
import com.ossnms.bicnet.reportm.client.core.plugin.configuration.LdapViewManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.licensing.LicenseStatus;
import com.ossnms.bicnet.bcb.model.topoMgmt.INetworkViewId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPlugin;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMapEventType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettings;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginStatusIndicator;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginWizardStep;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.core.notification.PluginNotificationManager;
import com.ossnms.bicnet.reportm.client.core.plugin.action.PluginActionBuilder;
import com.ossnms.bicnet.reportm.client.core.plugin.configuration.GeneralPluginConfiguration;
import com.ossnms.bicnet.reportm.client.presentation.settings.export.SettingsExport;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;
import com.ossnms.bicnet.util.versions.ClientComponentVersionInfo;

/**
 * Responsible for Report Manager Client Integration on BiCNet Client and for communication with Client Frame
 */
public class RMPlugin implements BiCNetPlugin {

    private static final String PLUGIN_ID = RMPlugin.class.getName();
    private BiCNetPluginSite pluginSite;
    private ListenersRegistrationManager pluginListenersRegistrationManager;
    private final BiCNetPluginTopicListener topicListener;
    private final ImmutableMap<BiCNetPluginMainContext, BiCNetPluginAction[]> mainActions;
    private final Map<BiCNetPluginMainContext, BiCNetPluginPropertyPage[]> mainPropertyPages;

    @Override
    public String getID() {
        return PLUGIN_ID;
    }

    @Override
    //TODO - create internationalization string map
    public String getName() {
        return "Report Manager";
    }

    @Override
    //TODO - create internationalization string map
    public String getDescription() {
        return "Report Manager Description";
    }

    /**
     * Constructor to be called by Client frame to integrate Report Manager on TNMS client
     */
    public RMPlugin() {
        mainActions = new PluginActionBuilder().build();
        topicListener = new PluginNotificationManager();
        mainPropertyPages = new PluginMainPropertyPages().build();
    }

    /**
     * Configure site interface for RM plug-in. after creating plug-in class instance, this is the first method called
     * (by TNMS plug-in manager), after the plug-in class instance has been created, like @PostConstruct.
     *
     * @param biCNetPluginSite will be initialized by the BiCNet Plug-in manager.
     */
    @Override
    public void setSite(BiCNetPluginSite biCNetPluginSite) {
        pluginSite = biCNetPluginSite;
        final RMPluginHelperImpl rmPluginHelper = RMPluginHelperImpl.getInstance();
        rmPluginHelper.setCfPluginSite(biCNetPluginSite);
        rmPluginHelper.setPluginId(PLUGIN_ID);
        LdapViewManager ldapViewManager = new LdapViewManager();
        Collection<ILogonListener> listeners = new PluginListenersBuilder().listeners(rmPluginHelper, topicListener, ldapViewManager);
        pluginListenersRegistrationManager = new ListenersRegistrationManager(listeners, rmPluginHelper.getSecurityProvider());
    }

    /**
     * Initializes the plug-in, and is called after setSite(BiCNetPluginSite) method calling.
     *
     * @throws BiCNetPluginException if no Security Provider is installed.
     */
    @Override
    public void init() throws BiCNetPluginException {
        GeneralPluginConfiguration.builder().load();
        pluginListenersRegistrationManager.register();
    }

    /**
     * Destroys the plug-in. This method is called before Client app is closed.
     */
    @Override
    public void destroy() {
        pluginListenersRegistrationManager.unregister();
    }

    /**
     * Returns Report Manger main menus
     *
     * @param biCNetPluginMainContext - BiCNetPluginMainContext provided bo Plugin Manager
     * @return BiCNetPluginAction array of actions
     */
    @Override
    public BiCNetPluginAction[] getMainActions(BiCNetPluginMainContext biCNetPluginMainContext) {
        return mainActions.get(biCNetPluginMainContext);
    }

    @Override
    public BiCNetPluginAction[] getObjectActions(IManagedObject[] iManagedObjects, IManagedObject iManagedObject, String s) {
        return new BiCNetPluginAction[0];
    }

    @Override
    public BiCNetPluginAction[] getHighlightActions(IManagedObject[] iManagedObjects, IManagedObject iManagedObject, String s) {
        return new BiCNetPluginAction[0];
    }

    @Override
    public void notifyUnhighlight(INetworkViewId iNetworkViewId) {

    }

    @Override
    public void notifyMapEvent(INetworkViewId iNetworkViewId, BiCNetPluginMapEventType biCNetPluginMapEventType) {

    }

    @Override
    public BiCNetPluginPropertyPage[] getMainPropertyPages(BiCNetPluginMainContext biCNetPluginMainContext) {
        return mainPropertyPages.get(biCNetPluginMainContext);
    }

    @Override
    public BiCNetPluginPropertyPage[] getObjectPropertyPages(IManagedObject[] iManagedObjects, IManagedObject iManagedObject, String s) {
        return new BiCNetPluginPropertyPage[0];
    }

    @Override
    public BiCNetPluginStatusIndicator[] getStatusIndicators() {
        return new BiCNetPluginStatusIndicator[0];
    }

    @Override
    public BiCNetPluginImportExportItem getImportExportItems(Element element) {
        return null;
    }

    @Override
    public ComponentVersionInformation[] getVersionInfoItems() {
        return ClientComponentVersionInfo.getVersionInfo(getClass());
    }

    @Override
    public BiCNetPluginWizardStep[] getObjectWizardSteps(ManagedObjectType managedObjectType) {
        return new BiCNetPluginWizardStep[0];
    }

    @Override
    public BiCNetPluginAction[] getObjectTypeActions(ManagedObjectType managedObjectType, BiCNetPluginActionType biCNetPluginActionType) {
        return new BiCNetPluginAction[0];
    }

    @Override
    public BiCNetPluginSettings getPluginSettings() {
        IReportManagerPrivateFacade privateFacade = getInstance().getIPrivateFacade(IReportManagerPrivateFacade.class);
        ISessionContext context = RMPluginHelperImpl.getInstance().getLogonContext();

        return new SettingsExport(privateFacade, context).pluginSettings();
    }

    @Override
    public LicenseStatus getLicenseStatus() {
        return null;
    }
}
