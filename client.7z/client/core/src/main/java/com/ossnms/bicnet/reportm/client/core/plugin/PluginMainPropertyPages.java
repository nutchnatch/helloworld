/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.core.plugin;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.reportm.client.presentation.settings.system.SystemSettingsDocument;
import com.ossnms.bicnet.reportm.client.presentation.settings.system.SystemSettingsPage;

import java.util.Map;

public class PluginMainPropertyPages {

    public Map<BiCNetPluginMainContext, BiCNetPluginPropertyPage[]> build() {
        SystemSettingsPage systemSettingsPage = new SystemSettingsPage(new SystemSettingsDocument());
        return ImmutableMap.of(
                BiCNetPluginMainContext.ADMINISTRATION, new BiCNetPluginPropertyPage[]{systemSettingsPage});
    }
}
