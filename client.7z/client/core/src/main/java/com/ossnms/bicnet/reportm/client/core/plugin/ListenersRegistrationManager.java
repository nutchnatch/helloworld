package com.ossnms.bicnet.reportm.client.core.plugin;

import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;

import javax.annotation.Nonnull;
import java.util.Collection;

public class ListenersRegistrationManager {

    private final Collection<ILogonListener> listeners;
    private final IPluginSecurityProvider securityProvider;

    public ListenersRegistrationManager(@Nonnull final Collection<ILogonListener> listeners, @Nonnull final IPluginSecurityProvider securityProvider) {
        this.listeners = listeners;
        this.securityProvider = securityProvider;
    }

    /**
     *  Register the log-on listeners on Security Manager facade.
     */
    public void register() {
        for (final ILogonListener logonListener : listeners) {
            securityProvider.addLogonListener(logonListener);
        }
    }

    /**
     *  Unregister the log-on listeners on Security Manager facade.
     */
    public void unregister() {
        for (final ILogonListener logonListener : listeners) {
            securityProvider.removeLogonListener(logonListener);
        }
    }
}
