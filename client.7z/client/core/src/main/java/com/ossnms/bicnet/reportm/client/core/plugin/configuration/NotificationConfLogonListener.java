package com.ossnms.bicnet.reportm.client.core.plugin.configuration;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;
import com.ossnms.bicnet.framework.client.listeners.FrameworkAbstractLogonListener;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static com.ossnms.bicnet.reportm.client.api.plugin.configuration.NotificationTopicConf.TOPIC_FACTORY_NAME;
import static com.ossnms.bicnet.reportm.client.api.plugin.configuration.NotificationTopicConf.TOPIC_NAME;

import javax.annotation.Nonnull;

public class NotificationConfLogonListener extends FrameworkAbstractLogonListener {

    private final Logger LOGGER = LoggerFactory.getLogger(NotificationConfLogonListener.class);
    private final BiCNetPluginTopicListener topicListener;
    private final RMPluginHelper rmPluginHelper;

    public NotificationConfLogonListener(@Nonnull BiCNetPluginTopicListener biCNetPluginTopicListener, @Nonnull RMPluginHelper rmPluginHelper){
        topicListener = biCNetPluginTopicListener;
        this.rmPluginHelper = rmPluginHelper;
    }

    @Override
    protected BiCNetPluginSite getPluginSite() {
        return rmPluginHelper.getCfPluginSite();
    }

    /**
     * Subscribe the server topic.
     */
    @Override
    protected void eventUserLoggedOn(@Nonnull ISessionContext sessionContext) {
        try {
            rmPluginHelper.getCfPluginSite().subscribeServerTopic(TOPIC_FACTORY_NAME.getName(), TOPIC_NAME.getName(), topicListener);
        } catch (final BiCNetPluginException e) {
            LOGGER.error("Error to subscribe ServerTopic", e);
        }
    }

    /**
     * Unsubscribe the server topic.
     */
    @Override
    protected void eventUserLoggedOff(@Nonnull ISessionContext sessionContext) {
        rmPluginHelper.getCfPluginSite().unsubscribeServerTopic(TOPIC_FACTORY_NAME.getName(), TOPIC_NAME.getName(), topicListener);
    }
}
