package com.ossnms.bicnet.reportm.client.core.notification;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IVisitor;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;
import com.ossnms.bicnet.reportmanager.util.Constants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;
import static com.ossnms.bicnet.reportm.client.api.plugin.configuration.NotificationTopicConf.SENDER_ID;

public class PluginNotificationManager implements BiCNetPluginTopicListener{

    private static final Logger LOGGER = LoggerFactory.getLogger(PluginNotificationManager.class);

    private final Collection<IVisitor> visitors;

    public PluginNotificationManager() {
        //TODO - Create List of items to be notified
        this(new ArrayList<IVisitor>());
    }

    public PluginNotificationManager(@Nonnull final Collection<IVisitor> notificationVisitors) {
        this.visitors = notificationVisitors;
    }

    /**
     * Called by plug-in site when message from JMS topic has been received.
     */
    @Override
    public void eventPluginTopicMessage(@Nonnull final Message message) {
        try {
            if (isValid(message)) {
                final Serializable obj = ((ObjectMessage) message).getObject();
                processNotification(obj);
            }
        } catch (JMSException | BcbException e) {
            LOGGER.error("Erro to process message from TNMS server", e);
        }
    }

    /**
     * This is just for information, the site will display an error and perform a log-off.
     */
    @Override
    public void eventPluginTopicLost() {
        LOGGER.error("Report Manager Plug-in. Message Lost!");
    }

    /*
     * Verifies if the message is for the Report Manager plug-in.
     */
    private boolean isValid(@Nonnull final Message message) throws JMSException {
        final String senderId = message.getStringProperty(SENDER_ID.getName());

        final boolean isFromReportManager = Objects.equals(Constants.BICNET_COMPONENT_TYPE.toString(), senderId);
        final boolean isObjectMessage = message instanceof ObjectMessage;

        return isObjectMessage && isFromReportManager;
    }

    /*
     * Process the notification for only one message or batch processing.
     */
    private void processNotification(@Nonnull final Serializable obj) throws BcbException {
        if (obj instanceof Notification[]) {
            for (final Notification notification : (Notification[]) obj) {
                dispatch(notification);
            }
        } else if (obj instanceof Notification) {
            dispatch((Notification) obj);
        }
    }

    /*
     * Process notification for all register visitors.
     */
    private void dispatch(@Nonnull final Notification n) throws BcbException {
        for (final IVisitor visitor : visitors) {
            if (n.dispatch(visitor)) {
                break;
            }
        }
    }
}
