package com.ossnms.bicnet.reportm.client.core.plugin.configuration;


import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.reportmanager.servicelocator.ReportManagerServiceLocator;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;

/**
 * Responsible for managing service locator on the Report manager Client
 */
public class GeneralPluginConfiguration {

    public static GeneralPluginConfiguration builder(){
        return new GeneralPluginConfiguration();
    }

    /**
     * Register Report Manager Client on service locator
     */
    public void load(){
        BiCNetServiceLocator.getInstance().registerServiceLocator(BiCNetComponentType.REPORT_MANAGER, ReportManagerServiceLocator.getInstance());
    }
}
