package com.ossnms.bicnet.reportm.client.core.plugin.configuration;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.framework.client.listeners.FrameworkAbstractLogonListener;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelper;

import javax.annotation.Nonnull;


public class PluginLogonListener extends FrameworkAbstractLogonListener {

    private final RMPluginHelper rmPluginHelper;
    private final LdapViewManager ldapViewManager;

    public PluginLogonListener(@Nonnull RMPluginHelper pluginHelper, @Nonnull LdapViewManager ldapViewManager){
        rmPluginHelper = pluginHelper;
        this.ldapViewManager = ldapViewManager;
    }

    @Override
    protected BiCNetPluginSite getPluginSite() {
        return rmPluginHelper.getCfPluginSite();
    }

    /**
     * Listen to user login event
     *
     * @param sessionContext current context
     */
    @Override
    protected void eventUserLoggedOn(@Nonnull ISessionContext sessionContext) {
        rmPluginHelper.initialize(sessionContext);
        ldapViewManager.restoreOpenViews(rmPluginHelper.getCfPluginSite());
    }

    /**
     * Listen to user logout event
     *
     * @param sessionContext Session context identifying the session that has terminated.
     */
    @Override
    protected void eventUserLoggedOff(@Nonnull ISessionContext sessionContext) {
        rmPluginHelper.uninitialize("");
        ldapViewManager.saveOpenViews(rmPluginHelper.getCfPluginSite());
        rmPluginHelper.setLoggingOff(false);
    }

    /**
     * Listen to user permissions changed event
     *
     * @param sessionContext - context of the session
     */
    @Override
    protected void eventUserPermissionsChanged(@Nonnull ISessionContext sessionContext) {
        rmPluginHelper.initialize(sessionContext);
    }

    @Override
    protected void eventUserLoggingOff(ISessionContext sessionContext) {
        rmPluginHelper.setLoggingOff(true);
        rmPluginHelper.clearPluginViews();
    }

}
