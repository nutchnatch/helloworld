package com.ossnms.bicnet.reportm.client.core.plugin;


import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelper;
import com.ossnms.bicnet.reportm.client.core.plugin.configuration.LdapViewManager;
import com.ossnms.bicnet.reportm.client.core.plugin.configuration.NotificationConfLogonListener;
import com.ossnms.bicnet.reportm.client.core.plugin.configuration.PluginLogonListener;

import javax.annotation.Nonnull;
import java.util.Collection;

public class PluginListenersBuilder {

    PluginListenersBuilder(){
    }

    /**
     * Returen a Immutable Collection of Listeners
     * @param rmPluginHelper - RM plugin Helper
     * @param topicListener - Plugin Notification Listener
     * @return Immutable Collection of Listeners
     */
    public Collection<ILogonListener> listeners(@Nonnull RMPluginHelper rmPluginHelper,
                                                @Nonnull BiCNetPluginTopicListener topicListener, LdapViewManager ldapViewManager){
        final Builder<ILogonListener> builder = ImmutableList.builder();

        builder.add(new PluginLogonListener(rmPluginHelper,ldapViewManager));
        builder.add(new NotificationConfLogonListener(topicListener, rmPluginHelper));

        return builder.build();
    }
}
