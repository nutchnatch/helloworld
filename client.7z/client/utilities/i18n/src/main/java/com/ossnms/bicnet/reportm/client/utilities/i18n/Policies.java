package com.ossnms.bicnet.reportm.client.utilities.i18n;

public enum Policies {
    EXPORT_INVENTORY_DATA,
    EXPORT_CONFIGURATION_DATA,
    ALARMS_OUTAGE_DATA,
    NETWORK_INVENTORY_SETTINGS,
    DCN_LIST,
    ALARM_MESSAGING;

    @Override
    public String toString() {
        return RM18nSupport.getString(this);
    }
}