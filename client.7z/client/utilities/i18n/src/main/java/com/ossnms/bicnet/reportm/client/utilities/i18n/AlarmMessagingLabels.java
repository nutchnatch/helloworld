package com.ossnms.bicnet.reportm.client.utilities.i18n;

import com.ossnms.tools.jfx.JfxText;

public enum AlarmMessagingLabels {

    WINDOW_TITLE,
    OK_BUTTON,
    OK_BUTTON_TOOLTIP,
    
    SCHEDULE_TAB_TITLE,
    
    NES_TAB_TITLE,
    
    NES_SELECTEDNES_LABEL,
    
    CRITERIA_TAB_TITLE,
    CRITERIA_ACTIVATE_LABEL,
    CRITERIA_ALARMNUMBER_LABEL,
    CRITERIA_ALARMNUMBERRANGE_LABEL,
    CRITERIA_SEVERITYLABEL,
    MENU,
    DESCRIPTION;

	
	public JfxText guiName(){
        return RM18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
    
    public String format(Object... params) {
        return guiName().getFormatedMessage(params);
    }
}
