package com.ossnms.bicnet.reportm.client.utilities.i18n;

import com.ossnms.bicnet.framework.client.i18n.FrameworkMessages;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.text.MessageFormat;
import java.util.Locale;

public final class RM18nSupport extends JfxStringTable{

    private static final Logger LOGGER = LoggerFactory.getLogger(RM18nSupport.class);
    private static final ClassLoader CLASS_LOADER = RM18nSupport.class.getClassLoader();
    private static final String PROPERTY_LOCATION = RM18nSupport.class.getName() + "Pluginstrings";
    private static final FrameworkMessages FRAMEWORK_MESSAGES = new FrameworkMessages(RM18nSupport.PROPERTY_LOCATION, Locale.getDefault(), RM18nSupport.CLASS_LOADER);

    /** Empty string (used as default value). */
    public static final String EMPTY_STRING = "";

    /** Empty text. */
    public static final JfxText EMPTY_JFX_TEXT = new JfxText("");


    private RM18nSupport(){
    }

    public static FrameworkMessages getFrameworkMessages() {
    	return FRAMEWORK_MESSAGES;
    }
    
    public static JfxText getGuiName(@Nonnull Enum<?> value){
        return new JfxText(FRAMEWORK_MESSAGES.getString(value.getClass().getSimpleName() + "." + value.name()));
    }

    /**
     * Gets formated string for given key
     *
     * @param key
     *            the key
     * @param params
     *            the parameters to format
     * @return the formated string
     */
    public static String getString(String key, Object... params) {
        if (key == null) {
            return EMPTY_STRING;
        }

        try {
            return MessageFormat.format(FRAMEWORK_MESSAGES.getString(key), params);
        }
        catch (IllegalArgumentException ex) {
            LOGGER.error("Cannot find resource in properties file: " + key, ex);
            return key;
        }
    }

    /**
     * Gets the enumerator string for given value
     *
     * @param value
     *            the enumerator value
     * @return the string
     */
    public static String getString(Enum<?> value) {
        return getString(value.getClass().getSimpleName() + "." + value.name());
    }

    /**
     * Gets the enumerator mnemonic for given value
     *
     * @param value
     *            the enumerator value
     * @return the mnemonic
     */
    public static String getMnemonic(Enum<?> value) {
        return getString(value.getClass().getSimpleName() + "." + value.name() + "_MN");
    }
}