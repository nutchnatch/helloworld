package com.ossnms.bicnet.reportm.client.utilities.i18n;

import com.ossnms.tools.jfx.JfxText;

public enum PluginLabels {
    PLUGIN_NAME_MENU,
    INVENTORY_EXPORT_REPORT;

    public JfxText guiName(){
        return RM18nSupport.getGuiName(this);
    }

    @Override
    public String toString() {
        return guiName().getText();
    }
}