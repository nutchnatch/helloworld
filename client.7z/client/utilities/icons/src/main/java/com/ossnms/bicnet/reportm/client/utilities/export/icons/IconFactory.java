package com.ossnms.bicnet.reportm.client.utilities.export.icons;

import javax.swing.ImageIcon;

import com.ossnms.bicnet.resources.ResourcesIconFactory;

/**
 * Used to declare application private icons which will extend the class with common icons. Compatible icon factory for common BiCNet
 * resources. An icon from the factory can be used directly as parameter:
 * <p/>
 * <pre>
 * JLabel label = new JLabel(IconFactory.ICON_EMPTY_16);
 * </pre>
 */

public final class IconFactory {

    /**
     * Component icons
     * public static final JfxIconImpl ICON_OVERLAY_x_16 = new JfxIconImpl("icon.png", IconFactory.class);
     */

    private IconFactory() {
    }

    /**
     * Types of action to overlays
     */
    public enum ActionType {
        UNKNOWN, NEW, MANAGEMENT, MODIFY, DETAILS, PROPERTIES, SCHEDULED, ALARM
    }

    /**
     * Overlap icon over given icon according to action type
     *
     * @param icon       the icon to be overlapped
     * @param actionType the action type
     * @return the overlapping icon
     */
    public static ImageIcon getIconWithOverlay(ImageIcon icon, ActionType actionType) {
        ImageIcon overlay;

        switch (actionType) {
            case DETAILS:
                overlay = ResourcesIconFactory.ICON_OVERLAY_DETAILS_16;
                break;

            case MANAGEMENT:
                overlay = ResourcesIconFactory.ICON_OVERLAY_MANAGEMENT_16;
                break;

            case NEW:
                overlay = ResourcesIconFactory.ICON_OVERLAY_NEW_16;
                break;

            case MODIFY:
            case PROPERTIES:
                overlay = ResourcesIconFactory.ICON_OVERLAY_MODIFY_16;
                break;

            case SCHEDULED:
                overlay = ResourcesIconFactory.ICON_OVERLAY_SCHEDULED_16;
                break;
                
            case ALARM:
                overlay = ResourcesIconFactory.ICON_OVERLAY_ALARM_16;
                break;

            case UNKNOWN:
            default:
                return icon;
        }

        return ResourcesIconFactory.getIconWithOverlay(icon, overlay);
    }
}
