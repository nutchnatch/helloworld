package com.ossnms.bicnet.reportm.client.presentation.dcnlist.views;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.model.EnumBase;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INamedObjectPkg;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.utilities.i18n.DcnListLabels;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.dto.DcnObject.Alarm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
//import static org.apache.commons.lang3.StringUtils.EMPTY;

public enum DcnListTableColumn {

    DCN_TYPE(DcnListLabels.DCN_LIST_COLUMN_DCN_TYPE.toString(), 100) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.type();
        }
    },
    NAME(DcnListLabels.DCN_LIST_COLUMN_NAME.toString(), 120) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.name();
        }
    },
    ADDRESS(DcnListLabels.DCN_LIST_COLUMN_ADDRESS.toString(), 90) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.address();
        }
    },
    STATE(DcnListLabels.DCN_LIST_COLUMN_STATE.toString(), 100) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.state();
        }
    },
    NE_NAME(DcnListLabels.DCN_LIST_COLUMN_NE_NAME.toString(), 90) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.neName().orElse(EMPTY);
        }
    },
    SEVERITY(DcnListLabels.DCN_LIST_COLUMN_SEVERITY.toString()) {
        @Override public AlarmSeverityColumnValue getObjectValue(DcnObject dto) {
            Optional<AlarmSeverity> severity = dto.alarm().map(Alarm::severity);
            return new AlarmSeverityColumnValue(
                    severity.orElse(null),
                    severity.map(EnumBase::guiLabel)
                            .orElse(EMPTY));
        }
    },
    CHANNEL(DcnListLabels.DCN_LIST_COLUMN_CHANNEL.toString(), 100) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.channelId().flatMap(this::fetchChannel)
                    .map(INamedObjectPkg::getIdName).orElse(EMPTY);
        }

        private Optional<IEM> fetchChannel(Integer channelId) {
            try {
                return ofNullable(RMPluginHelperImpl.getInstance().getCfPluginSite().getNEObjectProvider().getEm(new EMIdItem(channelId)));
            } catch (BiCNetPluginException e) {
                LOGGER.error("getNEObjectProvider", e);
                return empty();
            }
        }
    },
    MAITENANCE_STATE(DcnListLabels.DCN_LIST_COLUMN_MAINTENANCE_STATE.toString()) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.maintenanceState().map(EnumBase::guiLabel).orElse(EMPTY);
        }
    },
    OPERATIONAL_STATE(DcnListLabels.DCN_LIST_COLUMN_OPERATIONAL_STATE.toString()) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.operationalState().map(EnumBase::guiLabel).orElse(EMPTY);
        }
    },
    ALARM_STATE(DcnListLabels.DCN_LIST_COLUMN_ALARM_STATE.toString(), 100) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.alarm().map(Alarm::acknowledge)
                    .map(ack -> ack ? "Acknowledged" : "Unacknowledged")
                    .orElse(EMPTY);
        }
    },
    SYSTEM(DcnListLabels.DCN_LIST_COLUMN_SYSTEM.toString(), 110) {
        @Override public String getObjectValue(DcnObject dto) {
            return dto.systemName().orElse(EMPTY);
        }
    };

    private static final String EMPTY = " ";
    
    private final String columnName;
    private final int preferredWidth;

    private static final Logger LOGGER = LoggerFactory.getLogger(DcnListTableColumn.class);

    DcnListTableColumn(String columnName, int preferredWidth) {
        this.columnName = columnName;
        this.preferredWidth = preferredWidth;
    }

    DcnListTableColumn(String name) {
        columnName = name;
        preferredWidth = 140;
    }

    public String getColumnName() {
        return columnName;
    }

    public int getPreferredWidth() {
        return preferredWidth;
    }

    public static DcnListTableColumn getEnumByColumnName(String name) {
        return Arrays.stream(values()).filter(e -> e.getColumnName() == name).findFirst().orElse(null);
    }

    abstract Object getObjectValue(DcnObject dto);
}
