package com.ossnms.bicnet.reportm.client.presentation.dcnlist.commands;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginViewFactory;
import com.ossnms.bicnet.reportm.client.api.command.AbstractOpenCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.dcnlist.documents.DcnListDocument;
import com.ossnms.bicnet.reportm.client.presentation.dcnlist.views.DcnListView;
import com.ossnms.bicnet.reportm.client.utilities.i18n.DcnListLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

public class DcnListCommand extends AbstractOpenCommand {

    private static final long serialVersionUID = -5380259936823494146L;

    public DcnListCommand() {
        super(DcnListLabels.DCN_LIST_MENU.toString(), DcnListLabels.DCN_LIST_OPEN_DESCRIPTION.toString());

        final FrameworkCommandID commandID = new FrameworkCommandID(DcnListCommand.class.getName());
        setCommandID(commandID);
        setToolIcon(ResourcesIconFactory.ICON_WINDOW_DCN_LIST_16);
        setActionListener(new FrameworkCommandHandler(commandID));
        setSecurityId(Policies.DCN_LIST.toString());
        setComponentName("Export");
    }

    @Override
    public boolean execute(IManagedObject[] arSelectedObjects) {
        FrameworkPluginViewFactory.createView(DcnListDocument.class, DcnListView.class, DcnListLabels.DCN_LIST_TITLE.toString(), 
                arSelectedObjects, RMPluginHelperImpl.getInstance(), this, BiCNetPluginFrameType.INTERNAL);
        return false;
    }

    @Override
    public IFrameworkCommand clone(IManagedObject[] arSelectedObjects) {
        DcnListCommand clonedCmd = new DcnListCommand();
        return clonedCmd;
    }
}