package com.ossnms.bicnet.reportm.client.presentation.dcnlist.documents;

import java.util.List;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkTableModelDataChangeListener;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkTableModelSource;
import com.ossnms.bicnet.reportm.client.api.documents.AbstractDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitable;
import com.ossnms.bicnet.reportm.client.presentation.dcnlist.jobs.DcnListFetchJob;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem;
import com.ossnms.tools.jfx.JfxSortedListModel;

public class DcnListDocument extends AbstractDocument implements IFrameworkTableModelSource {

	private JfxSortedListModel itens;
	private boolean isCurrentlyFiltered;
	
	public DcnListDocument() {
		itens = new JfxSortedListModel();
	}

    @Override
    public void fetchOtherData() {

    }

    @Override
	public boolean onHandlingRMMessageItem(RMMessageItem arg) throws BcbException {
		return false;
	}

	@Override
	public void fetchData() {
		addAndExecuteJob(new DcnListFetchJob(this));
	}

	@Override
	protected void fetchSystemSettings() {
	}

	@Override
	public OperationKey handleJobNotifications(IJobVisitable job, Object result) {
		if(job instanceof DcnListFetchJob){
			itens.removeAllElements();
			itens.addAll((List<DcnObject>)result);
		}

		return OperationKey.LOAD_DCN_LIST_DATA;
	}

	@Override
	public void setTableModelChangeListener(IFrameworkTableModelDataChangeListener listener) {
	}

	@Override
	public int getNumOfObjects() {
		return itens.getSize();
	}

	@Override
	public Object getObject(int index) {
		return itens.getElementAt(index);
	}
	
    public void setCurrentlyFiltered(boolean filtered) {
    	this.isCurrentlyFiltered = filtered;
    }
    
    public boolean isCurrentlyFiltered() {
    	return this.isCurrentlyFiltered;
    }
}
