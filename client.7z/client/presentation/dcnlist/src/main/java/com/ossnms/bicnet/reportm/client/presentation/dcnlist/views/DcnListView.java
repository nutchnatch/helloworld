package com.ossnms.bicnet.reportm.client.presentation.dcnlist.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.Nonnull;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientPropertyListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.bcb.plugin.topology.BiCNetPluginTopologyProvider;
import com.ossnms.bicnet.common.filter.command.FilterAndSortButtonCommand;
import com.ossnms.bicnet.common.filter.command.FilterAndSortClearButtonCommand;
import com.ossnms.bicnet.common.filter.toolbar.FilterPanel;
import com.ossnms.bicnet.framework.client.command.FrameworkButtonCommand;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkTableModelDataChangeListener;
import com.ossnms.bicnet.framework.client.jfx.FrameworkDialogApp;
import com.ossnms.bicnet.framework.client.utils.FrameworkStatusBar;
import com.ossnms.bicnet.framework.client.utils.FrameworkStatusBar.FrameworkStatusBarCapabilities;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.api.views.AbstractView;
import com.ossnms.bicnet.reportm.client.presentation.dcnlist.commands.DcnListCommand;
import com.ossnms.bicnet.reportm.client.presentation.dcnlist.documents.DcnListDocument;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.DcnListLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxOptionsData;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.components.JfxMenuItem;
import com.ossnms.tools.jfx.table.EFilterStatus;
import com.ossnms.tools.jfx.table.JfxColumnSettings;
import com.ossnms.tools.jfx.table.JfxDefaultVisibleColumnsSettings;
import com.ossnms.tools.jfx.table.JfxFilterConnector;
import com.ossnms.tools.jfx.table.JfxFilteredTableModel;
import com.ossnms.tools.jfx.table.JfxSortedTableModel;
import com.ossnms.tools.jfx.table.JfxTable;
import com.ossnms.tools.jfx.table.JfxTableProperties;

public class DcnListView extends AbstractView implements BiCNetPluginClientPropertyListener, TableModelListener {
    /**
     * Constants
     */
    private static final long serialVersionUID = 2646897902632020226L;
    private static final int WINDOW_WIDTH = 400;
    private static final int WINDOW_HEIGHT = 215;

    private static final boolean RESIZABLE = true;
    private static final String VIEW_ID = DcnListView.class.getName();
    private static final List<DcnListTableColumn> columns = Arrays.asList(DcnListTableColumn.values());
    private final DcnListTable table;
    private final DcnListTableModel dcnListTableModel;
    private final FrameworkStatusBar statusBar;
    private final DcnListUpdateButtonCmd updateBtn = new DcnListUpdateButtonCmd();
    private final FilterAndSortButtonCommand filterButton;
    private final FilterAndSortClearButtonCommand removeAllFiltersButton;
    private final JPanel mainPanel = new JPanel(new BorderLayout());
    private transient JfxOptionsData iOptionsData;

    private static final Logger LOGGER = LoggerFactory.getLogger(DcnListView.class);

    public DcnListView(@Nonnull String title, @Nonnull DcnListDocument doc) throws BcbException {
        super(VIEW_ID, title, doc, RESIZABLE, HelpIds.HID_DCN_LIST);
        setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        dcnListTableModel = new DcnListTableModel(doc);
        table = new DcnListTable(dcnListTableModel);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent mouseEvent) {
            }
        });

        table.getFilteredTableModel().addTableModelListener(this);

        statusBar = new FrameworkStatusBar(FrameworkStatusBarCapabilities.FILTER_SUPPORT, FrameworkStatusBarCapabilities.COUNTERS_SUPPORT);
        doc.getPluginHelper().getCfPluginSite().addClientPropertyListener(this);
        
        JScrollPane scrollpane = new JScrollPane();
        scrollpane.getViewport().add(table, null);
        
        JfxFilterConnector filterConnector = new JfxFilterConnector(table, RMPluginHelperImpl.getInstance(), this);
        FilterPanel filterPanel = new FilterPanel(filterConnector); 
        filterPanel.setVisible(false); 
        filterConnector.setFilterPanel(filterPanel);
        
        removeAllFiltersButton = new FilterAndSortClearButtonCommand(RMPluginHelperImpl.getInstance(), filterConnector);  
        filterButton = new FilterAndSortButtonCommand(getFrameworkDocument().getPluginHelper(), filterPanel);
        
        for (DcnListTableColumn column : columns) {
            table.setColumnFilter(column.ordinal(), EFilterStatus.Complex, filterConnector);
        }
        
        mainPanel.add(filterPanel, BorderLayout.NORTH);
        mainPanel.add(scrollpane, BorderLayout.CENTER);
        
        initGuiNames();

        setupContextMenu();
        super.initControls();
        
        removeAllFiltersButton.setEnabled(table.isFiltered());
    }

    public static List<DcnListTableColumn> getColumns() {
        return columns;
    }

    private void setupContextMenu() {
        JfxAction actionFindInMap = new JfxAction(new JfxText(DcnListLabels.DCN_LIST_CONTEXT_FIND_IN_MAP.toString()), null, null, null);
        actionFindInMap.setIfConditionHandler(action -> {
            boolean permissions = RMPluginHelperImpl.getInstance().checkPermissions(Policies.DCN_LIST.toString());
            if (permissions && table.getSelectedRowCount() == 1) {
                DcnObject object = (DcnObject) getDocument().getObject(table.convertRowIndexToBaseModel(table.getSelectedRow()));
                if (object.neId().isPresent()) {
                    return true;
                }
            }

            return false;
        });
        actionFindInMap.setIfPerformedHandler(action -> {
            DcnObject object = (DcnObject) getDocument().getObject(table.convertRowIndexToBaseModel(table.getSelectedRow()));
            object.neId().ifPresent(neId -> {
                try {
                    BiCNetPluginTopologyProvider topologyProvider = RMPluginHelperImpl.getInstance().getCfPluginSite().getTopologyProvider();
                    Optional<IManagedObjectId> system = object.systemId().filter(id -> id != 0).map(SystemContainerIdItem::new);
                    topologyProvider.findInMap(system.orElseGet(() -> new NEIdItem(neId)));
                } catch (BiCNetPluginException e) {
                    LOGGER.error("getTopologyProvider", e);
                }
            });
        });
        JfxMenuItem findInMapMenuItem = new JfxMenuItem(actionFindInMap);
        table.addTablePopupItem(findInMapMenuItem, true);
    }

    private void initGuiNames() {
        table.setName("DcnListTable");
        statusBar.setName("DcnListStatusbar");
        filterButton.setComponentName("FilterAndSort");
        removeAllFiltersButton.setComponentName("RemoveAll");
    }

    @Override
    public void eventOpened() {
        super.eventOpened();
        table.setDialogApp(new FrameworkDialogApp(getFrame()));
    }

    @Override
    protected void initKeyBindings() {
    }

    @Override
    public JComponent getStatusBar() {
        return statusBar;
    }

    @Override
    public void updateData(Object key) {
        dcnListTableModel.fireTableDataChanged();
    }

    @Override
    public void eventPluginClientPropertiesChanged() {
    }

    @Override
    protected JComponent getMainComponent() {
        return mainPanel;
    }

    /**
     * get the associated document
     */
    DcnListDocument getDocument() {
        return (DcnListDocument) m_doc;
    }

    public static class DcnListTableModel extends AbstractTableModel implements IFrameworkTableModelDataChangeListener, JfxColumnSettings, JfxDefaultVisibleColumnsSettings {
        private static final long serialVersionUID = 3592567474547200344L;
        private DcnListDocument doc;

        public DcnListTableModel(DcnListDocument doc) {
            this.doc = doc;
            this.doc.setTableModelChangeListener(this);
        }

        @Override
        public int getRowCount() {
            return doc.getNumOfObjects();
        }

        @Override
        public int getColumnCount() {
            return columns.size();
        }

        @Override
        public String getColumnName(int col) {
            return columns.get(col).getColumnName();
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            DcnObject dto = (DcnObject) doc.getObject(rowIndex);
            DcnListTableColumn dcnListTableColumn = columns.get(columnIndex);

            return dcnListTableColumn.getObjectValue(dto);
        }

        @Override
        public Collection<String> getDefaultVisibleColumnsNames() {
            return Stream.of(DcnListTableColumn.values()).filter(a -> !a.equals(DcnListTableColumn.SYSTEM))
                    .map(DcnListTableColumn::getColumnName)
                    .collect(Collectors.toList());
        }

        @Override
        public int getPreferredColumnWidth(int nColumn) {
            return columns.get(nColumn).getPreferredWidth();
        }

        @Override
        public boolean isColumnRemovable(int nColumn) {
            return false;
        }

        @Override
        public void holderDataChanged(int firstIndex, int lastIndex, int type) {
        }

        public int getColumnIndex(DcnListTableColumn eColumn) {
            return columns.indexOf(eColumn);
        }

        @Override
        public Class<?> getColumnClass(int col) {
            return String.class;
        }
    }

    private class DcnListTable extends JfxTable {
        private static final long serialVersionUID = -7124126462443919105L;

        public DcnListTable(TableModel model) {
            super(model);

            setSortable(true, false, true);
            JfxSortedTableModel sortedTableModel = getSortedModel();
            sortedTableModel.setDefaultSortColumn(((DcnListTableModel) model).getColumnIndex(DcnListTableColumn.NAME));
            sortedTableModel.setSortColumn(dcnListTableModel.getColumnIndex(DcnListTableColumn.NAME));

            JfxFilteredTableModel filteredTableModel = new JfxFilteredTableModel(this, sortedTableModel.getModel());
            setFilterable(true, filteredTableModel, true);

            // Allow horizontal scrollbar
            setAutoResizeMode(JfxTable.AUTO_RESIZE_OFF);
            setHeaderToolTipsEnabled(true);
            setDefaultToolTipBehaviour(true);
        }
    }

    /**
     * @return a List with the view's toolbar buttons
     */
    @Override
    protected List<Object> getButtonActions() {
        List<Object> toolbar = new ArrayList<>();

        toolbar.add(updateBtn);
        toolbar.add(filterButton.getToggleButton());
        toolbar.add(removeAllFiltersButton);
        return toolbar;
    }

    public class DcnListUpdateButtonCmd extends FrameworkButtonCommand {
        private static final long serialVersionUID = 2668545255717973855L;

        DcnListUpdateButtonCmd() {
            setCmdDetails(DcnListLabels.DCN_LIST_UPDATETOOLBTN.toString(),
                    "DcnList:UpdateButtonCmd", "",
                    DcnListLabels.DCN_LIST_UPDATETOOLBTNSHORTCUT.toString(),
                    DcnListLabels.DCN_LIST_UPDATEBTNTOOLTIP.toString(),
                    DcnListLabels.DCN_LIST_UPDATEBTNDESC.toString(),
                    ResourcesIconFactory.ICON_TOOL_UPDATE_16);
        }

        /**
         * @see com.ossnms.bicnet.framework.client.command.IFrameworkCommand#execute(IManagedObject[])
         */
        @Override
        public boolean execute(IManagedObject[] selectedObjects) {
            getDocument().fetchData();
            return true;
        }
    }

    @Override
    public JTable getDataToPrint() {
        return table;
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {

    }

    @Override
    public boolean isPrintable() {
        return true;
    }

    @Override
    public String getCommandClassName() {
        return DcnListCommand.class.getName();
    }

    private void updateStatusBar() {
        statusBar.setInfoAreaVisible(false);
        statusBar.updateStatusBar(table.getFilteredTableModel().getRowCount(), getDocument().getNumOfObjects(), 0, table.isFiltered());
    }

    @Override
    public void addClientLogEntry(String aMessage, Exception aEx) {
        // Nothing
    }

    @Override
    public boolean supportsPersistance() {
        return true;
    }

    @Override
    protected String getProfileId() {
        return VIEW_ID;
    }

    @Override
    public void tableChanged(TableModelEvent event) {
        updateStatusBar();
    }

    @Override
    protected void loadSettings(JfxOptionsData aProfile) {
        JfxTableProperties props = ((OptionsData) aProfile).getPersistentTableProperties(getClass().getName(), 0);
        Optional.ofNullable(props).ifPresent(currentProps -> table.setPersistentProperties(currentProps, false));
    }

    @Override
    protected void saveSettings(JfxOptionsData aProfile) {
        ((OptionsData) aProfile).setPersistentProperties(table.getPersistentProperties(getClass().getName(), 0));
    }

    @Override
    protected IPluginSecurityProvider getSecurityProvider() throws BiCNetPluginException {
        return m_doc.getPluginHelper().getCfPluginSite().getSecurityProvider();
    }

    @Override
    protected ISecureClientSession getSecureClientSession() throws BiCNetPluginException {
        return m_doc.getPluginHelper().getCfPluginSite().getSecurityProvider().getClientSession(m_doc.getPluginHelper().getLogonContext());
    }

    @Override
    public DcnListCommand getCommand() {
        return (DcnListCommand) super.getCommand();
    }

    @Override
    protected ImageIcon getViewIcon() {
        return ResourcesIconFactory.ICON_WINDOW_DCN_LIST_16;
    }

    @Override
    protected ActionType getViewAction() {
        return ActionType.UNKNOWN;
    }

    @Override
    protected void loadFilter(JfxOptionsData aProfile) {
    }

    @Override
    protected void saveFilter(JfxOptionsData aProfile) {
    }

    @Override
    protected JfxOptionsData getOptionsData() {
        if (iOptionsData == null) {
            iOptionsData = new OptionsData();
        }
        return iOptionsData;
    }
}