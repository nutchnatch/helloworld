package com.ossnms.bicnet.reportm.client.presentation.dcnlist.views;

import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;

public class AlarmSeverityColumnValue implements Comparable<Object> {

    private AlarmSeverity alarmSeverity;
    private String guiName;

    public AlarmSeverityColumnValue(AlarmSeverity alarmSeverity, String guiName) {
        this.alarmSeverity = alarmSeverity;
        this.guiName = guiName;
    }
    
    public AlarmSeverity getAlarmSeverity() {
        return alarmSeverity;
    }

    public void setAlarmSeverity(AlarmSeverity alarmSeverity) {
        this.alarmSeverity = alarmSeverity;
    }

    public String getGuiName() {
        return guiName;
    }

    public void setGuiName(String guiName) {
        this.guiName = guiName;
    }

    @Override
    public String toString() {
        return guiName;
    }
    
    /**
     * Comparable interface method. Necessary for e.g. the sorted table model.
     *
     * @param o 'other' FMColorString object to compare to 'this' object
     * @return negative, 0 or positive for smaller, equal and greater than
     */
    @Override
    public int compareTo(Object o) {
        if (null == o || !(o instanceof AlarmSeverityColumnValue)) {
            return alarmSeverity == null ? 0 : 1;
        }

        // Now it's save to cast
        AlarmSeverityColumnValue other = (AlarmSeverityColumnValue)o;
        
        if (other.getAlarmSeverity() == null ) {
            return alarmSeverity == null ? 0 : 1;
        }
        
        if (alarmSeverity == null) {
            return -1;
        }

        return alarmSeverity.compareTo(other.getAlarmSeverity());
    }

}
