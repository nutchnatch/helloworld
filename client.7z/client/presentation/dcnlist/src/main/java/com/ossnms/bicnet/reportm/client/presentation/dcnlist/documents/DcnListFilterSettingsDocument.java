package com.ossnms.bicnet.reportm.client.presentation.dcnlist.documents;

import com.ossnms.bicnet.framework.client.helpers.filterNSort.FrameworkFilterSettingsDocument;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;

public class DcnListFilterSettingsDocument extends FrameworkFilterSettingsDocument {

	public DcnListFilterSettingsDocument() {
		super(RMPluginHelperImpl.getInstance());
	}
}
