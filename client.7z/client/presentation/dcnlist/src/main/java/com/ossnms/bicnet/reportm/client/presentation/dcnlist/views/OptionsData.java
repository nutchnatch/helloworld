package com.ossnms.bicnet.reportm.client.presentation.dcnlist.views;

import com.ossnms.bicnet.reportm.client.api.ui.utils.AbstractOptionsData;
import com.ossnms.tools.jfx.components.JfxPersistentProperties;
import com.ossnms.tools.jfx.table.JfxTableProperties;

public class OptionsData extends AbstractOptionsData {

    public OptionsData() {
    }

    /**
     * ************************************************************************
     * Creates a persistent properties object of the appropriate class.
     *
     * @param strClass   Class name.
     * @param strViewId  View ID.
     * @param nControlId Control ID.
     * @return Persistent properties object or null.
     * ************************************************************************
     */
    public JfxPersistentProperties createPersistentProperties(String strClass, String strViewId, int nControlId) {
        JfxPersistentProperties persistent = null;

        if (strClass.equals(JfxTableProperties.class.getName())) {
            persistent = new JfxTableProperties(strViewId, nControlId);
        }

        return persistent;
    }

    /**
     * Returns persistant properties for the given Log Filter.
     *
     * @param viewID     ID of view.
     * @param nControlID ID of filter object.
     * @return Log filter properties object or null.
     */
    public JfxTableProperties getPersistentLogFilterProperties(String viewID, int nControlID) {
        return (JfxTableProperties) getPersistentPropertiesMap().get(new JfxTableProperties(viewID, nControlID));
    }

}
