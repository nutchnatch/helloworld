package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.views;

import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.Nonnull;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.command.FrameworkCommitButton;
import com.ossnms.bicnet.framework.client.utils.FrameworkCancelCommand;
import com.ossnms.bicnet.framework.client.utils.FrameworkCloseCommand;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.api.views.AbstractView;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.commands.AlarmMessagingCommand;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.commands.OkCommand;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.documents.AlarmMessagingDocument;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.AlarmMessagingLabels;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings.ThresholdSettings;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import com.ossnms.bicnet.reportmanager.util.Constants;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.JfxOptionsData;
import com.ossnms.tools.jfx.JfxStringTable;

public class AlarmMessagingView extends AbstractView {

    private static final long serialVersionUID = -5981627197261286975L;
    private static final String VIEW_ID = AlarmMessagingView.class.getName();
    private static final boolean NOT_RESIZABLE = false;
    
    private final OkCommand okCommand = new OkCommand(this);
    private final FrameworkCloseCommand frameworkCloseCommand = new FrameworkCloseCommand(this, JfxStringTable.IDS_Close_WITHOUT_MNEMONIC.toString());

    private final JTabbedPane mainComponent = new JTabbedPane();
    private AlarmMessagingSchedulePanel schedulePanel;
    private AlarmMessagingCriteriaPanel criteriaPanel;
    private AlarmMessagingNePanel nesPanel;
    private int jobstoFinish;
    
    public AlarmMessagingView(@Nonnull String title, @Nonnull AlarmMessagingDocument doc) throws BcbException {
        super(VIEW_ID, title, doc, NOT_RESIZABLE, HelpIds.HID_ALARM_MESSAGING);
        setActivityIndicatorVisible(true);
        jobstoFinish=2;
        getFrameworkDocument().runFetchCriteriaSettingsJob();
        
        initLayout();
        initControls();
        setGuiNames();
        doc.getPluginHelper().getCfPluginSite().addClientPropertyListener(this);
    }

    private void setGuiNames() {
        getMainComponent().setName("VIEW.AlarmMessagingView");
        schedulePanel.setName("PANEL.SchedulePanel");
        criteriaPanel.setName("PANEL.CriteriaPanel");
        nesPanel.setName("PANEL.NesPanel");
    }

    
    private void initLayout() {
        schedulePanel = new AlarmMessagingSchedulePanel(this);
        criteriaPanel = new AlarmMessagingCriteriaPanel(this);
        nesPanel = new AlarmMessagingNePanel(this);

        mainComponent.add(AlarmMessagingLabels.SCHEDULE_TAB_TITLE.toString(), schedulePanel);
        mainComponent.add(AlarmMessagingLabels.CRITERIA_TAB_TITLE.toString(), criteriaPanel);
        mainComponent.add(AlarmMessagingLabels.NES_TAB_TITLE.toString(), nesPanel);
        
        okCommand.updateAction();
    }
    
    public boolean isViewValid() {
        return schedulePanel.isValidIfEnable() && !((schedulePanel.isScheduleActivated() || criteriaPanel.isCriteriaEnabled()) && !nesPanel.isAnyNeSelected());
    }
        
    public void createScheduleAlarmMessaging() {
        schedulePanel.actionApply();
        IScheduleMarkable schedule = schedulePanel.getSchedule();
        getFrameworkDocument().scheduleAlarmMessaging(Constants.ALARM_MESSAGING_REPORT, schedule);
    }
    
    public void createCriteriaAlarmMessaging() {
        getFrameworkDocument().criteriaAlarmMessaging(criteriaPanel.isCriteriaEnabled(), criteriaPanel.getAlarmsNumber(), criteriaPanel.getAlarmsSeverety(), selectedNEs(nesPanel.getNesTreeModel()));
    }
    
    @Override
    public void updateData(Object key) {
        if (key instanceof OperationKey) {
            switch ((OperationKey) key) {
            case LOAD_OUTAGE_ALL_NES_ITEMS:
                nesPanel.loadData(getFrameworkDocument().getSelectedNes());
                ThresholdSettings threshold = getFrameworkDocument().getResult().threshold();
                criteriaPanel.loadData(threshold.enabled(), threshold.number(), threshold.severity());
                jobstoFinish--;
                break;
            case LOAD_ALARMMESSAGING_SETTINGS:
                schedulePanel.loadData(getFrameworkDocument().getScheduleDataFetchJob());
                jobstoFinish--;
            break;
            default:
                break;
            }
        }
        if(jobstoFinish==0) {
            setActivityIndicatorVisible(false);
        }
    }

    public OkCommand getOkCommand() {
        return okCommand;
    }
    
    @Override
    protected void initKeyBindings() {
        getComponent().getActionMap().put("Esc", frameworkCloseCommand);
    }

    @Override
    protected ImageIcon getViewIcon() {
        return ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16;
    }

    @Override
    protected ActionType getViewAction() {
        return ActionType.UNKNOWN;
    }

    @Override
    public String getCommandClassName() {
        return AlarmMessagingCommand.class.getName();
    }

    @Override
    public boolean supportsPersistance() {
        return false;
    }

    @Override
    public JTable getDataToPrint() {
        return new JTable();
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {
    }

    @Override
    public void addClientLogEntry(String arg0, Exception arg1) {
    }

    @Override
    protected JfxOptionsData getOptionsData() {
        return null;
    }

    @Override
    protected String getProfileId() {
        return null;
    }

    @Override
    protected ISecureClientSession getSecureClientSession() throws BiCNetPluginException {
        return null;
    }

    @Override
    protected IPluginSecurityProvider getSecurityProvider() throws BiCNetPluginException {
        return null;
    }

    @Override
    protected void loadSettings(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveSettings(JfxOptionsData aProfile) {

    }


    @Override
    protected void loadFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected JComponent getMainComponent() {
        return mainComponent;
    }

    @Override
    protected AlarmMessagingDocument getFrameworkDocument() {
        return (AlarmMessagingDocument) super.getFrameworkDocument();
    }
    
    @Override
    protected List<FrameworkCommitButton> getCommitActions() {
        List<FrameworkCommitButton> buttons = new ArrayList<FrameworkCommitButton>();
        buttons.add(new FrameworkCancelCommand(this));
        buttons.add(okCommand);
        return buttons;
    }
    
    public void closeWindow() {
       close();
    }
    
    private static Collection<INEId> selectedNEs(AlarmMessagingNesTreeModel nesListModel) {
        return stream(nesListModel.getAllSelectedNodes())
                .map(IReportManagerExportItem::getObjectId)
                .map(NEIdItem::new)
                .collect(toList());
    }
        
}
