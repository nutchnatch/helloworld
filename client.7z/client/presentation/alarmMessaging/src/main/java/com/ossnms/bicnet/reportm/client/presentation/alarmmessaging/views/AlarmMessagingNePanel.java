package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.ossnms.bicnet.reportm.client.api.models.ExportItemNode;
import com.ossnms.bicnet.reportm.client.utilities.i18n.AlarmMessagingLabels;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxLabel;

public class AlarmMessagingNePanel extends JPanel {

    private static final long serialVersionUID = 1L;
    private static final int WINDOW_WIDTH = 360;
    private static final int WINDOW_HEIGHT = 300;
    private ToggleButtonTree<ExportItemNode> nesTree;
    private AlarmMessagingNesTreeModel nesTreeModel;
    private AlarmMessagingView view;
    private Iterable<IExportableItem> exportableItems;
    
    public AlarmMessagingNePanel(final AlarmMessagingView view) {
        super(new GridBagLayout());
        this.view = view;
        initLayout();
        initGuiNames();
    }
        
    private void initLayout() {
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        
        nesTreeModel = new AlarmMessagingNesTreeModel();
        nesTree = new ToggleButtonTree<>(nesTreeModel);
        nesTreeModel.setSelectionModel(nesTree.getToggleButtonTreeSelectionModel());
        nesTree.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                int index = nesTree.getRowForLocation(e.getX(), e.getY());
                if (index >= 0) {
                    updateTreePane();
                    nesTreeModel.reload();
                    view.getOkCommand().updateAction();
                }
            }
        });
        
        nesTree.setClickInToggleButtonOnly(true);
        nesTree.setRootVisible(true);
        nesTree.setDigInMode(true);
        nesTree.getSelectionModel().setSelectionMode(TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
        
        JPanel treePane = new JPanel(new BorderLayout());
        treePane.add(new JScrollPane(nesTree), BorderLayout.CENTER);
        JfxLabel selectedNesLabel = new JfxLabel(AlarmMessagingLabels.NES_SELECTEDNES_LABEL.guiName());
        selectedNesLabel.setLabelAndMnemonicFor(treePane);
        
        add(selectedNesLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        add(treePane, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    }
    
    public final void initGuiNames() {
        nesTree.setName("FIELD.NesTree");
    }
    
    private void updateTreePane() {
        SwingUtilities.invokeLater(() -> {
            expandAll(nesTree, new TreePath(nesTree.getModel().getRoot()));
            nesTree.updateUI();
        });
    }
    
    private void expandAll(JTree tree, TreePath parent) {
        TreeNode node = (TreeNode) parent.getLastPathComponent();
        if (!node.isLeaf()) {
            for (int i = 0; i < node.getChildCount(); i++) {
                TreePath path = parent.pathByAddingChild(node.getChildAt(i));
                expandAll(tree, path);
            }
        }
        tree.expandPath(parent);
    }

    public void loadData(Iterable<IExportableItem> exportableItems) {
        this.exportableItems = exportableItems;
        new LoadFetchData().execute();
    }

    private final class LoadFetchData extends SwingWorker<Boolean, Void> {

        @Override
        protected Boolean doInBackground() throws Exception {

            nesTreeModel.initFromExportableItems(exportableItems);
            return null;
        }

        @Override
        protected void done() {
            getExportedData();
        }
    }
    
    private void getExportedData() {
        new SwingWorker<Boolean, Object>() {
            @Override
            protected Boolean doInBackground() {
                updateTreePane();
                return true;
            }
        }.execute();
    }
    
   public boolean isAnyNeSelected() {
       return getNesTreeModel().getAllSelectedNodes().length>0;
   }
    
    public AlarmMessagingNesTreeModel getNesTreeModel() {
        return nesTreeModel;
    }
    
}
