package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.documents;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.api.documents.AbstractDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitable;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.jobs.CriteriaAlarmMessagingJob;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.jobs.FetchAlarmMessagingSettingsJob;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.jobs.ScheduleAlarmMessagingJob;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.jobs.ScheduleDataFetchJob;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.Collection;
import java.util.Set;

import static com.ossnms.bicnet.reportmanager.dto.ImmutableAlarmMessagingCriteriaSettings.alarmMessaging;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableThresholdSettings.threshold;

public class AlarmMessagingDocument extends AbstractDocument {

    FetchAlarmMessagingSettingsJob fetchCriteriaSettingsJob;
    ScheduleDataFetchJob scheduleDataFetchJob;
    
    @Override
    public boolean onHandlingRMMessageItem(RMMessageItem arg) throws BcbException {
        return false;
    }

    @Override
    public void fetchOtherData() {
    }

    @Override
    public void fetchData() {
        scheduleDataFetchJob = new ScheduleDataFetchJob(this, Constants.ALARM_MESSAGING_REPORT);
        try {
            executeFetchJob(scheduleDataFetchJob);
        } catch (FrameworkException e) {
            getLogger().error("Error executing ExportDataFetchJob job.", e);
        }
    }

    @Override
    protected void fetchSystemSettings() {
    }

    @Override
    public OperationKey handleJobNotifications(IJobVisitable job, Object result) {
        return job.dispatch(null, result);
    }
    
    
    public void scheduleAlarmMessaging(String reportId, IScheduleMarkable mark) {
        FrameworkFetchJob job = new ScheduleAlarmMessagingJob(this, reportId, mark);
        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Unable to schedule periodic alarm messaging:", e);
        }
    }
    
    public void criteriaAlarmMessaging(boolean isEnabled, int alarmNumber, int alarmSeverity, Collection<INEId> neList) {
        addAndExecuteJob(new CriteriaAlarmMessagingJob(this, 
                alarmMessaging(threshold(isEnabled, alarmNumber, alarmSeverity), neList)));
    }
    
    public ReportDataDto getScheduleDataFetchJob() {
        return scheduleDataFetchJob.getScheduleData();
    }
    
    /**
     * Execute getNes
     */
    public void runFetchCriteriaSettingsJob() {
        fetchCriteriaSettingsJob = new FetchAlarmMessagingSettingsJob(this);
        try {
            executeFetchJob(fetchCriteriaSettingsJob);
        } catch (FrameworkException e) {
            getLogger().error("Error executing OutageFetchJob.", e);
        }
    }

    public AlarmMessagingCriteriaSettings getResult() {
        return fetchCriteriaSettingsJob.getResult();
    }

    public Set<IExportableItem> getSelectedNes() {
        return fetchCriteriaSettingsJob.getSelectedNes();
    }
}
