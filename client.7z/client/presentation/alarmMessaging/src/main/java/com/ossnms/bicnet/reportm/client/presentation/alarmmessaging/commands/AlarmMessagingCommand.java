package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.commands;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginViewFactory;
import com.ossnms.bicnet.reportm.client.api.command.AbstractOpenCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.documents.AlarmMessagingDocument;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.views.AlarmMessagingView;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.AlarmMessagingLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

public class AlarmMessagingCommand extends AbstractOpenCommand {

    private static final long serialVersionUID = -1034555651827785643L;
    
    public AlarmMessagingCommand() {
        super(AlarmMessagingLabels.MENU.toString(), AlarmMessagingLabels.DESCRIPTION.toString());

        final FrameworkCommandID commandID = new FrameworkCommandID(getClass().getName());
        setCommandID(commandID);
        setToolIcon(IconFactory.getIconWithOverlay(ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16, ActionType.ALARM));
        setActionListener(new FrameworkCommandHandler(commandID));
        setSecurityId(Policies.DCN_LIST.toString());
    }

    @Override
    public boolean execute(IManagedObject[] selectedObjects) {
        FrameworkPluginViewFactory.createView(AlarmMessagingDocument.class, AlarmMessagingView.class, AlarmMessagingLabels.WINDOW_TITLE.toString(), 
                selectedObjects, RMPluginHelperImpl.getInstance(), this, BiCNetPluginFrameType.INTERNAL);
        return false;
    }

    @Override
    public IFrameworkCommand clone(IManagedObject[] arg0) {
        return new AlarmMessagingCommand();
    }
}
