package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.views;

import static java.util.stream.Collectors.toList;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.StreamSupport;

import com.ossnms.bicnet.reportm.client.api.models.AbstractExportableItemsModel;
import com.ossnms.bicnet.reportm.client.api.models.ExportItemNode;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;

public class AlarmMessagingNesTreeModel extends AbstractExportableItemsModel {

    private static final long serialVersionUID = 1L;

    boolean isAnyNodeSelected() {
        return getSelectionModel().getSelectionCount() > 0;
    }

    
    @Override
    public List<ExportItemNode> collectTreeItems(Iterable<IExportableItem> exportableItems) {
        getSelectionModel().removeSelectionPath(getTreePath(getRoot()));
        return StreamSupport.stream(exportableItems.spliterator(), false)
                .filter(iExportableItem -> iExportableItem.getName() != null)
                .map(ExportItemNode::new)
                .peek(node -> getRoot().add(node))
                .map(item -> {
                    if(item.getItem().isSelected()){
                        getSelectionModel().addSelectionPath(getTreePath(item));
                    }
                    return item;
                })
                .collect(toList());
    }

    @Override
    public IExportableItem[] getAllSelectedNodes() {
        ExportItemNode root = getRoot();
        Predicate<ExportItemNode> isCollectible = node -> node.isLeaf();
        Predicate<ExportItemNode> notRoot = node -> !Objects.equals(root, node);

        return flattenTreeOf(root)
                .filter(isCollectible.and(this::checkSelected).and(notRoot))
                .map(ExportItemNode::getItem)
                .toArray(IExportableItem[]::new);
    }

}
