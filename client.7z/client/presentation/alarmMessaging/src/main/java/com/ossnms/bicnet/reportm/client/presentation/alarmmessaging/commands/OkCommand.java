package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.commands;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.framework.client.utils.FrameworkOkCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.views.AlarmMessagingView;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;

public class OkCommand extends FrameworkOkCommand {

    private static final long serialVersionUID = 1L;

    public OkCommand(AlarmMessagingView view) {
        setView(view);
        setPluginHelper(RMPluginHelperImpl.getInstance());
        setSecurityId(Policies.ALARM_MESSAGING.toString());
    }
    
    @Override
    public boolean execute(IManagedObject[] arSelectedObjects) {
        getView().createScheduleAlarmMessaging();
        getView().createCriteriaAlarmMessaging();
        getView().closeWindow();
        return true;
    }

    @Override
    public boolean isEnabled(IManagedObject[] selectedObjects) {
        return getView().isViewValid();
    }
    
    @Override
    public AlarmMessagingView getView() {
        return (AlarmMessagingView) super.getView();
    }
    
}
