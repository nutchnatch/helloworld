package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.views;

import java.util.Date;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.bcb.model.platform.SchedulePeriod;
import com.ossnms.bicnet.framework.client.helpers.scheduler.FrameworkScheduledJobPanel;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.tools.jfx.JfxUtils;

public class AlarmMessagingSchedulePanel extends FrameworkScheduledJobPanel {

    private static final long serialVersionUID = 1L;
    private AlarmMessagingView view;

    public AlarmMessagingSchedulePanel(final AlarmMessagingView view) {
        super(RMPluginHelperImpl.getInstance().getCfPluginSite(), ExportLabels.SCHEDULE_EXPORT_TIME.toString(), true, true, true);
        this.view = view;
        initLayout();
    }
   
    public void loadData(ReportDataDto data) {
        ISchedule schedule = (data.getSchedule()!=null)?data.getSchedule():getNewScheduleItem();
        IScheduleMarkable[] scheduleMarkables = new IScheduleMarkable[]{schedule.toMarkableSchedule(false)};
        setObjects(scheduleMarkables);
    }
    
    public boolean isValidIfEnable() {
        return !isScheduleActivated() || (isScheduleActivated() && isNextExecutionTimeValid());
    }
    
    private void initLayout() {
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);    
        
        addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                view.getOkCommand().updateAction();
            }
        });
    }
    
    private ISchedule getNewScheduleItem() {
        final ScheduleItem item = new ScheduleItem();
        item.setStartTime(new Date(System.currentTimeMillis()));
        item.setPeriod(SchedulePeriod.USER_DEFINED);
        item.setUserPeriod(0);
        item.setActivation(EnableSwitch.DISABLED);
        return item;
    }
}
