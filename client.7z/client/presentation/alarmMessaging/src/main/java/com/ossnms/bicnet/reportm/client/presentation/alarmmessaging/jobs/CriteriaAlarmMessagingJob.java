package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.jobs;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.AbstractPrivateFacadeFetchJob;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;

import javax.annotation.Nonnull;
import java.util.concurrent.atomic.AtomicInteger;

public class CriteriaAlarmMessagingJob extends AbstractPrivateFacadeFetchJob<Boolean, IReportManagerPrivateFacade> {

    private static final String OPERATION_ID = CriteriaAlarmMessagingJob.class.getSimpleName();
    private static final AtomicInteger jobInstanceCounter = new AtomicInteger(0);
    private static final String OPERATION_NAME = "Criteria Alarm Messaging";

    private final AlarmMessagingCriteriaSettings settings;

    public CriteriaAlarmMessagingJob(@Nonnull final IFrameworkDocument jobOwner, AlarmMessagingCriteriaSettings settings) {
        super(IReportManagerPrivateFacade.class, OPERATION_ID + "#" + jobInstanceCounter.getAndIncrement(), OPERATION_NAME, "", jobOwner);
        this.settings = settings;
    }

    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        return null;
    }

    @Override
    public Boolean invokeMethodFromFacade(IReportManagerPrivateFacade iPrivateFacade) throws BcbException {
        return iPrivateFacade.createCriteriaAlarmMessaging(getSessionContext(), settings);
    }

}
