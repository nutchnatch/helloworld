package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.views;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.reportm.client.utilities.i18n.AlarmMessagingLabels;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxComboBox;
import com.ossnms.tools.jfx.components.JfxComboBox.ItemData;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxSpinner;

public class AlarmMessagingCriteriaPanel extends JPanel {

    private static final long serialVersionUID = 1L;

    private static final int SPINNER_SIZE = 2;
    private static final int ALARMNUMBER_MIN = 1;
    private static final int ALARMNUMBER_MAX = 50000;
    private static final ItemData severityComboValues[] = {new ItemData("Warning", AlarmSeverity.WARNING.getOrdinal()), 
            new ItemData("Minor", AlarmSeverity.MINOR.getOrdinal()), new ItemData("Major", AlarmSeverity.MAJOR.getOrdinal()), 
            new ItemData("Critical", AlarmSeverity.CRITICAL.getOrdinal()), new ItemData("Indeterminate", AlarmSeverity.INDETERMINATE.getOrdinal())};
    
    private final JfxCheckBox activateCheckbox = new JfxCheckBox(AlarmMessagingLabels.CRITERIA_ACTIVATE_LABEL.toString());
    private final JfxLabel thresholdEnableLabel = new JfxLabel(AlarmMessagingLabels.CRITERIA_ALARMNUMBER_LABEL.toString());
    private final SpinnerIntegerModel alarmThresholdSpinnerModel = new SpinnerIntegerModel(1, ALARMNUMBER_MIN, ALARMNUMBER_MAX, 1);
    private final JfxSpinner alarmThresholdSSpinner = new JfxSpinner(alarmThresholdSpinnerModel);
    private final JfxLabel rangeLabel = new JfxLabel(AlarmMessagingLabels.CRITERIA_ALARMNUMBERRANGE_LABEL.format(ALARMNUMBER_MIN, ALARMNUMBER_MAX));
    private final JfxLabel severityLabel = new JfxLabel(AlarmMessagingLabels.CRITERIA_SEVERITYLABEL.toString());
    private final JfxComboBox severityCombo = new JfxComboBox(severityComboValues);
    private AlarmMessagingView view;

    public AlarmMessagingCriteriaPanel(final AlarmMessagingView view) {
        super(new GridBagLayout());
        this.view = view;
        initLayout();
        enableFields();
        initGuiNames();
    }
    
    private void initLayout() {
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        JPanel contentPanel = new JPanel(new GridBagLayout());
        
        activateCheckbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                enableFields();
                updateUI();
                view.getOkCommand().updateAction();
            }
        });
        
        contentPanel.add(activateCheckbox, new GridBagConstraints(0, 0, 1, 1, 1, 1, GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        contentPanel.add(thresholdEnableLabel, new GridBagConstraints(0, 1, 1, 1, 1, 1, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.FIELD_INDENTATION, 0, 0), 0, 0));
        alarmThresholdSSpinner.setColumns(SPINNER_SIZE);
        contentPanel.add(alarmThresholdSSpinner, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.FIELD_INDENTATION, 0, 0), 0, 0));
        contentPanel.add(rangeLabel, new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
        
        contentPanel.add(severityLabel, new GridBagConstraints(0, 2, 1, 1, 1, 1, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.FIELD_INDENTATION, 0, 0), 0, 0));
        contentPanel.add(severityCombo, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.FIELD_INDENTATION, 0, 0), 0, 0));
        
        add(contentPanel, new GridBagConstraints(0, 0, 2, 1, 1.0, 1.0, GridBagConstraints.NORTH, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    }
    
    public final void initGuiNames() {
        activateCheckbox.setName("FIELD.ActivateCheckbox");
        thresholdEnableLabel.setName("LABEL.ThresholdEnableLabel");
        alarmThresholdSSpinner.setName("FIELD.AlarmThresholdSSpinner");
        rangeLabel.setName("LABEL.RangeLabel");
        severityLabel.setName("LABEL.SeverityLabel");
        severityCombo.setName("FIELD.SeverityCombo");
    }
    
    public int getAlarmsNumber() {
        return (int)alarmThresholdSSpinner.getValue();
    }

    public int getAlarmsSeverety() {
        return severityCombo.getSelectedIntValue();
    }

    public boolean isCriteriaEnabled() {
        return activateCheckbox.isSelected();
    }

    public void loadData(boolean enable, int alarmNumber, int alarmSeverity) {
        activateCheckbox.setSelected(enable);
        alarmThresholdSSpinner.setValue(alarmNumber);
        severityCombo.setSelectedItemByKey(alarmSeverity);
        enableFields();
        updateUI();
    }
    
    /**
     * Enables/disables all the fields according to activate checkbox.
     */
    private void enableFields() {
        boolean activateEnabled = activateCheckbox.isSelected();

        // Enable/disable fields
        thresholdEnableLabel.setEnabled(activateEnabled);
        alarmThresholdSSpinner.setEnabled(activateEnabled);
        rangeLabel.setEnabled(activateEnabled);
        severityLabel.setEnabled(activateEnabled);
        severityCombo.setEnabled(activateEnabled);
    }

}
