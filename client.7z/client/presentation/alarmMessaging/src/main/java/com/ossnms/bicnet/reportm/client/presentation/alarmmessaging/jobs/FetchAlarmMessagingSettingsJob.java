package com.ossnms.bicnet.reportm.client.presentation.alarmmessaging.jobs;

import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.AbstractPrivateFacadeFetchJob;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmNeDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.outage.alarms.NeExportItem;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;

public class FetchAlarmMessagingSettingsJob extends AbstractPrivateFacadeFetchJob<AlarmMessagingCriteriaSettings, IReportManagerPrivateFacade> {

    /** Job instance counter */
    private static final AtomicInteger jobInstanceCounter = new AtomicInteger(0);
    
    /** Process name */
    private static final String OPERATION_NAME = "Fetch NEs";
    
    /** Process id */
    private static final String OPERATION_ID = FetchAlarmMessagingSettingsJob.class.getSimpleName();

    private AlarmMessagingCriteriaSettings resultDto;
    private Set<IExportableItem> selectedNes = new LinkedHashSet<>(); // LinkedHashSet to keep the order

    /**
     * The class constructor
     * @param jobOwner        the document owner
     */
    public FetchAlarmMessagingSettingsJob(@Nonnull final IFrameworkDocument jobOwner) {
        super(IReportManagerPrivateFacade.class, OPERATION_ID + "#" + jobInstanceCounter.getAndIncrement(), OPERATION_NAME, "", jobOwner);
    }
    
    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        resultDto = (AlarmMessagingCriteriaSettings)result;
        Iterable<IExportableItem> allNes = convertOutageNeDtos(resultDto.allNEs(), resultDto.selectedNEs());
        for (IExportableItem item : allNes) {
            selectedNes.add(item);
        }
        return OperationKey.LOAD_OUTAGE_ALL_NES_ITEMS;
    }

    @Override
    public AlarmMessagingCriteriaSettings invokeMethodFromFacade(IReportManagerPrivateFacade iPrivateFacade) throws BcbException {
        getLogger().debug(OPERATION_NAME);
        return iPrivateFacade.getAlarmMessagingCriteriaSettings(getSessionContext());    
    }
    
    public AlarmMessagingCriteriaSettings getResult() {
        return resultDto;
    }
    
    public Set<IExportableItem> getSelectedNes() {
        return selectedNes;
    }

    
    public List<IExportableItem> convertOutageNeDtos(Collection<OutageAlarmNeDto> neDtos, Collection<INEId> selected){
        return neDtos.stream()
                .map(item->buildOutagealarmNeItems(item, selected))
                .filter(Optional::isPresent).map(Optional::get)
                .collect(toList());
    }

    private Optional<IExportableItem> buildOutagealarmNeItems(OutageAlarmNeDto neDto, Collection<INEId> selected){
        NeExportItem neExportItem=null;
        if ( neDto.getNeId() > 0 ) {
            neExportItem = new NeExportItem();
            neExportItem.setName(neDto.getNeName());
            neExportItem.setObjectId(neDto.getNeId());
            neExportItem.setSelection(selected.contains(new NEIdItem(neDto.getNeId())) ? 1 : 0);
                
        }
        return Optional.ofNullable(neExportItem);
    }
  
}
