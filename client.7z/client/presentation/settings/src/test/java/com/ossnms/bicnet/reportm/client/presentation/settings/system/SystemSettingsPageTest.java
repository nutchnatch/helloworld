/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.presentation.settings.system;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxSpinner;
import org.junit.Before;
import org.junit.Test;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Queue;

import static java.util.Collections.addAll;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SystemSettingsPageTest {

    private SystemSettingsPage systemSettingsPage;
    private FrameworkPluginHelper pluginHelper;

    @Before public void setUp() throws Exception {
        pluginHelper = mock(FrameworkPluginHelper.class);
        SystemSettingsDocument document = spy(new SystemSettingsDocument());
        when(document.getPluginHelper()).thenReturn(pluginHelper);
        systemSettingsPage = new SystemSettingsPage(document);
    }

    @Test public void shouldProvideTitle() throws Exception {
        assertThat(systemSettingsPage.getTitle(), is("Reports"));
    }

    @Test public void shouldContainDefaultButton() throws Exception {
        JComponent mainComponent = systemSettingsPage.getComponent();

        JfxButton button = findByNameAndAssert(mainComponent, "BUTTON.Default", JfxButton.class);

        assertThat(button.getText(), is("Default"));
    }

    @Test public void shouldContainRetentionNumberSpinner() throws Exception {
        JComponent mainComponent = systemSettingsPage.getComponent();

        findByNameAndAssert(mainComponent, "FIELD.InventoryRetentionNumber", JfxSpinner.class);
    }

    @Test public void shouldContainRetentionNumberLabel() throws Exception {
        JComponent mainComponent = systemSettingsPage.getComponent();

        JLabel label = findByNameAndAssert(mainComponent, "LABEL.InventoryRetentionNumber", JfxLabel.class);

        Component spinner = findByNameAndAssert(mainComponent, "FIELD.InventoryRetentionNumber", JfxSpinner.class);
        assertThat(label.getLabelFor(), is(spinner));
        assertThat(label.getText(), is("Network inventory:"));
        assertThat(label.getDisplayedMnemonic(), is((int)'N'));
    }

    @Test public void shouldContainRetentionNumberRangeLabel() throws Exception {
        JComponent mainComponent = systemSettingsPage.getComponent();

        JLabel labelRange = findByNameAndAssert(mainComponent, "LABEL.InventoryRetentionRange", JfxLabel.class);
        assertThat(labelRange.getText(), is("[1...365]"));
    }

    @Test public void shouldDisableComponentsOnReadOnly() throws Exception {
        JComponent mainComponent = systemSettingsPage.getComponent();

        systemSettingsPage.setReadOnly(true);

        Component spinner = findByNameAndAssert(mainComponent, "FIELD.InventoryRetentionNumber", JfxSpinner.class);
        Component button = findByNameAndAssert(mainComponent, "BUTTON.Default", JfxButton.class);
        assertThat(spinner.isEnabled(), is(false));
        assertThat(button.isEnabled(), is(false));
    }

    @Test public void shouldEnableComponentsOnNotReadOnly() throws Exception {

        systemSettingsPage.setReadOnly(false);

        Component spinner = findByNameAndAssert(systemSettingsPage.getComponent(), "FIELD.InventoryRetentionNumber", JfxSpinner.class);
        Component button = findByNameAndAssert(systemSettingsPage.getComponent(), "BUTTON.Default", JfxButton.class);
        assertThat(spinner.isEnabled(), is(true));
        assertThat(button.isEnabled(), is(true));
    }

    @Test public void shouldBeDisabledWithoutPermissions() throws Exception {
        when(pluginHelper.checkPermissions("Administration->System Preferences->Network Inventory")).thenReturn(false);

        assertThat(systemSettingsPage.isEnabled(null), is(false));
    }

    @Test public void shouldBeEnabledWithPermissions() throws Exception {
        when(pluginHelper.checkPermissions("Administration->System Preferences->Network Inventory")).thenReturn(true);

        assertThat(systemSettingsPage.isEnabled(null), is(true));
    }

    @Test public void shouldNotifyPageSiteOnValueChange() throws Exception {
        BiCNetPluginPropertyPageSite pageSite = mock(BiCNetPluginPropertyPageSite.class);
        systemSettingsPage.setPageSite(pageSite);
        JfxSpinner spinner = findByNameAndAssert(systemSettingsPage.getComponent(), "FIELD.InventoryRetentionNumber", JfxSpinner.class);

        spinner.getModel().setValue(23);

        verify(pageSite, atLeastOnce()).eventPageStatusChanged(systemSettingsPage);
    }

    private <T> T findByNameAndAssert(JComponent rootComponent, String name, Class<T> type) {
        List<String> found = new ArrayList<>();
        Queue<Component> components = new ArrayDeque<>();
        addAll(components, rootComponent.getComponents());

        while (!components.isEmpty()) {
            Component component = components.poll();
            if (Objects.equals(component.getName(), name)) {
                assertThat(component, instanceOf(type));
                return (T) component;
            }
            if (component instanceof Container) {
                addAll(components, ((Container) component).getComponents());
            }
            found.add('[' + component.getClass().getSimpleName() + ']' + component.getName());
        }

        throw new AssertionError("Expected [" + type.getSimpleName() + ']' + name + " but found " + found);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame();
                frame.setSize(400, 500);
                frame.setLocationRelativeTo(null);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.add(new SystemSettingsPage(new SystemSettingsDocument()).getComponent());
                frame.setVisible(true);
            }
        });
    }
}