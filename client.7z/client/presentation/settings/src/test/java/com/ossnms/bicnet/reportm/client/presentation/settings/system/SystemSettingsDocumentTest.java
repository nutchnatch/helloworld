/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.presentation.settings.system;

import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataChangeListener;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportmanager.api.ExportSettings;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collection;

import static com.ossnms.bicnet.reportmanager.api.ImmutableExportSettings.of;
import static com.ossnms.bicnet.reportmanager.api.ImmutableSystemSettings.settings;
import static javax.swing.SwingUtilities.invokeAndWait;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SystemSettingsDocumentTest {

    @Test public void shouldFetchSettingsOnInit() throws Exception {
        FrameworkPluginHelper pluginHelper = mock(FrameworkPluginHelper.class);
        SystemSettingsDocument document = spy(new SystemSettingsDocument());
        when(document.getPluginHelper()).thenReturn(pluginHelper);

        document.init();

        verify(pluginHelper).queueJob(anyString(), anyString(), isA(SystemSettingsFetchJob.class));
    }

    @Test public void shouldSaveSettings() throws Exception {
        FrameworkPluginHelper pluginHelper = mock(FrameworkPluginHelper.class);
        SystemSettingsDocument document = spy(new SystemSettingsDocument());
        when(document.getPluginHelper()).thenReturn(pluginHelper);

        document.saveSettings(9, 12, 10);

        verify(pluginHelper).queueJob(anyString(), anyString(), isA(SystemSettingsUpdateJob.class));
    }

    @Test public void shouldProvideDifferenceMessage() throws Exception {
        FrameworkPluginHelper pluginHelper = mock(FrameworkPluginHelper.class);
        SystemSettingsDocument document = spy(new SystemSettingsDocument());
        when(document.getPluginHelper()).thenReturn(pluginHelper);

        document.saveSettings(9, 12, 10);

        ArgumentCaptor<SystemSettingsUpdateJob> argument = ArgumentCaptor.forClass(SystemSettingsUpdateJob.class);
        verify(pluginHelper).queueJob(anyString(), anyString(), argument.capture());
        Collection<String> differences = argument.getValue().getMessages();
        assertThat(differences, containsInAnyOrder(
                "Network inventory: retention number updated with new value: 9",
                "Configuration: retention number updated with new value: 12",
                "Alarms outage: retention number updated with new value: 10"));
    }

    @Test public void shouldNotifyViewAboutFetchedSettings() throws Exception {
        final IFrameworkDataChangeListener view = mock(IFrameworkDataChangeListener.class);
        final SystemSettingsDocument document = new SystemSettingsDocument();
        document.setDataChangeListener(view);
        invokeAndWait(new Runnable() {
            @Override public void run() {
                document.setResult(mock(SystemSettingsFetchJob.class), SystemSettings.DEFAULT);
            }
        });
        verify(view).updateData(OperationKey.LOAD_SYSTEM_SETTINGS);
    }

    @Test public void shouldProvideSettingsValues() throws Exception {
        SystemSettingsDocument document = new SystemSettingsDocument();

        document.setResult(mock(SystemSettingsFetchJob.class), settings(of(17, "/"), ExportSettings.DEFAULT, ExportSettings.DEFAULT));

        assertThat(document.inventory().retentionNumber(), is(17));
    }
}