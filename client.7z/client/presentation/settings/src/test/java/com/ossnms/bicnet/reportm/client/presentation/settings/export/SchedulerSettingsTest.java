package com.ossnms.bicnet.reportm.client.presentation.settings.export;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.common.DaysOfMonth;
import com.ossnms.bicnet.bcb.model.common.DaysOfWeek;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettings;
import org.junit.Test;

import java.util.Date;
import java.util.Optional;

import static com.ossnms.bicnet.bcb.model.common.DayOfMonth.EIGHTH;
import static com.ossnms.bicnet.bcb.model.common.DayOfMonth.TWENTYFIRST;
import static com.ossnms.bicnet.bcb.model.common.DayOfWeek.MONDAY;
import static com.ossnms.bicnet.bcb.model.common.DayOfWeek.SATURDAY;
import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.DISABLED;
import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.ENABLED;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.MONTHLY;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.UNDEFINED;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.USER_DEFINED;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.WEEKLY;
import static com.ossnms.bicnet.reportm.client.presentation.settings.export.SchedulerSettings.scheduleSettings;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

public class SchedulerSettingsTest {
    @Test public void shouldProvideItemForEmptySchedule() throws Exception {
        BiCNetPluginSettings settings = scheduleSettings(Optional.empty());

        assertThat(settings, is(notNullValue()));
    }

    @Test public void shouldExportActivationFlag() throws Exception {
        ISchedule schedule = validEmptySchedule();
        schedule.setActivation(ENABLED);

        BiCNetPluginSettings scheduleSettings = scheduleSettings(of(schedule));

        assertThat(scheduleSettings.getProperties(), hasEntry("activate", "enabled"));
    }

    @Test public void shouldExportNumberOfExecutions() throws Exception {
        ISchedule schedule = validEmptySchedule();
        schedule.setOccurrencesUntilEnd(3);

        BiCNetPluginSettings scheduleSettings = scheduleSettings(of(schedule));

        assertThat(scheduleSettings.getProperties(), hasEntry("number executions", "3"));
    }

    @Test public void shouldExportWeeklyPeriod() throws Exception {
        ISchedule schedule = validEmptySchedule();
        schedule.setPeriod(WEEKLY);
        schedule.setWeeklyDays(DaysOfWeek.of(MONDAY, SATURDAY));

        BiCNetPluginSettings scheduleSettings = scheduleSettings(of(schedule));

        assertThat(scheduleSettings.getProperties(), hasEntry("periodic pattern", "weekly"));
        assertThat(scheduleSettings.getProperties(), hasEntry("period", "[monday, saturday]"));
    }

    @Test public void shouldExportMonthlyPeriod() throws Exception {
        ISchedule schedule = validEmptySchedule();
        schedule.setPeriod(MONTHLY);
        schedule.setMonthlyDays(DaysOfMonth.of(EIGHTH, TWENTYFIRST));

        BiCNetPluginSettings scheduleSettings = scheduleSettings(of(schedule));

        assertThat(scheduleSettings.getProperties(), hasEntry("periodic pattern", "monthly"));
        assertThat(scheduleSettings.getProperties(), hasEntry("period", "[eighth, twentyfirst]"));
    }

    @Test public void shouldExportUserDefinedPeriod() throws Exception {
        ISchedule schedule = validEmptySchedule();
        schedule.setPeriod(USER_DEFINED);
        schedule.setUserPeriod(3*1440 + 13*60);

        BiCNetPluginSettings scheduleSettings = scheduleSettings(of(schedule));

        assertThat(scheduleSettings.getProperties(), hasEntry("periodic pattern", "userDefined"));
        assertThat(scheduleSettings.getProperties(), hasEntry("period", "3 days and 13 hours"));
    }

    private ISchedule validEmptySchedule() {
        ScheduleItem schedule = new ScheduleItem();
        schedule.setPeriod(UNDEFINED);
        schedule.setActivation(DISABLED);
        schedule.setStartTime(new Date());
        return schedule;
    }
}