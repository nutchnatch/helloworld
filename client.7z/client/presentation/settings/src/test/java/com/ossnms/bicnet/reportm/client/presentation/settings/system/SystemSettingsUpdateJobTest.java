/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.presentation.settings.system;

import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;
import org.junit.Test;

import java.util.Collections;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class SystemSettingsUpdateJobTest {
    @Test public void shouldPassSystemSettingsToPrivateFacade() throws Exception {
        SystemSettings settings = SystemSettings.DEFAULT;
        IReportManagerPrivateFacade privateFacade = mock(IReportManagerPrivateFacade.class);

        new SystemSettingsUpdateJob(null, settings, Collections.<String>emptyList()).invokeMethodFromFacade(privateFacade);

        verify(privateFacade).updateSystemSettings(null, settings, Collections.<String>emptyList());
    }
}