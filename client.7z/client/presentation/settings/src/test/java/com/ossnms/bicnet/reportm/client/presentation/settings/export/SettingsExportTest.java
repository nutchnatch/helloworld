package com.ossnms.bicnet.reportm.client.presentation.settings.export;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettings;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dto.ImmutableAlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import static com.ossnms.bicnet.bcb.model.common.EnableSwitch.DISABLED;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.UNDEFINED;
import static com.ossnms.bicnet.reportmanager.api.ExportSettings.DEFAULT;
import static com.ossnms.bicnet.reportmanager.api.ImmutableExportSettings.of;
import static com.ossnms.bicnet.reportmanager.api.ImmutableSystemSettings.settings;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableAlarmMessagingCriteriaSettings.alarmMessaging;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableThresholdSettings.threshold;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARMS_OUTAGE_REPORT;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARM_MESSAGING_REPORT;
import static com.ossnms.bicnet.reportmanager.util.Constants.CONFIGURATION_EXPORT_REPORT;
import static com.ossnms.bicnet.reportmanager.util.Constants.INVENTORY_EXPORT_REPORT;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SettingsExportTest {

    private ISessionContext context;
    private ImmutableAlarmMessagingCriteriaSettings alarmMessaging;

    @Before public void setUp() throws Exception {
        context = null;
        alarmMessaging = alarmMessaging(threshold(false, 13, 1), Arrays.asList(new NEIdItem(1), new NEIdItem(42)));
    }

    @Test public void shouldBeForReportManager() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);

        BiCNetPluginSettings pluginSettings = settingsExport.pluginSettings();

        assertThat(pluginSettings.getNodeName(), is("Report Management"));
    }

    @Test public void shouldExportInventory() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);

        BiCNetPluginSettings inventorySettings = findChildByName(settingsExport.pluginSettings(), "network inventory");

        assertThat(inventorySettings, is(notNullValue()));
    }

    @Test public void shouldExportInventoryRetention() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);

        BiCNetPluginSettings inventorySettings = findChildByName(settingsExport.pluginSettings(), "network inventory");

        assertThat(inventorySettings.getProperties(), hasProperty("retention number", "90"));
    }

    @Test public void shouldExportInventoryFilesPath() throws Exception {
        SystemSettings systemSettings = settings(of(42, "/expected/export/path"), DEFAULT, DEFAULT);
        SettingsExport settingsExport = new SettingsExport(privateFacade(systemSettings, emptySchedule()), context);

        BiCNetPluginSettings inventorySettings = findChildByName(settingsExport.pluginSettings(), "network inventory");

        assertThat(inventorySettings.getProperties(), hasProperty("export path", "/expected/export/path"));
    }

    @Test public void shouldExportInventoryExportSchedule() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);

        BiCNetPluginSettings inventorySettings = findChildByName(settingsExport.pluginSettings(), "network inventory");
        BiCNetPluginSettings schedule = findChildByName(inventorySettings, "schedule");

        assertThat(schedule, is(notNullValue()));
    }

    @Test public void shouldExportConfigurationExportSchedule() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);

        BiCNetPluginSettings configurationExport = findChildByName(settingsExport.pluginSettings(), "configuration export");
        BiCNetPluginSettings schedule = findChildByName(configurationExport, "schedule");

        assertThat(schedule, is(notNullValue()));
    }

    @Test public void shouldExportConfigurationExportSettings() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);

        BiCNetPluginSettings configurationExport = findChildByName(settingsExport.pluginSettings(), "configuration export");

        assertThat(configurationExport.getProperties(), hasKey("export path"));
        assertThat(configurationExport.getProperties(), hasKey("retention number"));
    }


    @Test public void shouldExportOutageRetention() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);

        BiCNetPluginSettings outageSettings = findChildByName(settingsExport.pluginSettings(), "outage export");

        assertThat(outageSettings.getProperties(), hasProperty("retention number", "90"));
    }

    @Test public void shouldExportOutageExportSchedule() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);

        BiCNetPluginSettings outageExport = findChildByName(settingsExport.pluginSettings(), "outage export");
        BiCNetPluginSettings schedule = findChildByName(outageExport, "schedule");

        assertThat(schedule, is(notNullValue()));
    }

    @Test public void shouldExportAlarmMessagingSettings() throws Exception {
        SettingsExport settingsExport = new SettingsExport(privateFacade(SystemSettings.DEFAULT, emptySchedule()), context);
        BiCNetPluginSettings settings = findChildByName(settingsExport.pluginSettings(), "alarm messaging");
        BiCNetPluginSettings schedule = findChildByName(settings, "schedule");
        BiCNetPluginSettings threshold = findChildByName(settings, "threshold");

        assertThat(schedule, is(notNullValue()));
        assertThat(threshold, is(notNullValue()));
        assertThat(threshold.getProperties(), hasProperty("enabled", "false"));
        assertThat(threshold.getProperties(), hasProperty("number", "13"));
        assertThat(threshold.getProperties(), hasProperty("severity", "warning"));
        assertThat(settings.getProperties(), hasProperty("selected NEs", "1,42"));
    }

    private Matcher<Map<?, ?>> hasProperty(String key, String value) {
        return Matchers.hasEntry(key, value);
    }

    private ISchedule emptySchedule() {
        ScheduleItem schedule = new ScheduleItem();
        schedule.setStartTime(new Date());
        schedule.setPeriod(UNDEFINED);
        schedule.setActivation(DISABLED);
        return schedule;
    }

    private IReportManagerPrivateFacade privateFacade(SystemSettings systemSettings, ISchedule schedule) throws BcbException {
        IReportManagerPrivateFacade privateFacade = mock(IReportManagerPrivateFacade.class);
        when(privateFacade.getSystemSettings(context)).thenReturn(systemSettings);
        when(privateFacade.getReportData(context, INVENTORY_EXPORT_REPORT)).thenReturn(new ReportDataDto(null, null, schedule, null, null));
        when(privateFacade.getReportData(context, CONFIGURATION_EXPORT_REPORT)).thenReturn(new ReportDataDto(null, null, schedule, null, null));
        when(privateFacade.getReportData(context, ALARMS_OUTAGE_REPORT)).thenReturn(new ReportDataDto(null, null, schedule, null, null));
        when(privateFacade.getReportData(context, ALARM_MESSAGING_REPORT)).thenReturn(new ReportDataDto(null, null, schedule, null, null));
        when(privateFacade.getAlarmMessagingCriteriaSettings(context)).thenReturn(alarmMessaging);
        return privateFacade;
    }

    private BiCNetPluginSettings findChildByName(BiCNetPluginSettings settings, String export) {
        for (BiCNetPluginSettings child : settings.getChildren()) {
            if (child.getNodeName().equals(export)) {
                return child;
            }
        }
        return null;
    }
}