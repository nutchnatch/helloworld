/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.presentation.settings.system;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.reportm.client.api.documents.AbstractDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitable;
import com.ossnms.bicnet.reportmanager.api.ExportSettings;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collection;

import static com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels.CONFIGURATION;
import static com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels.INVENTORY;
import static com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels.OUTAGE;
import static com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels.RETENTION_DIFFERENCE;
import static com.ossnms.bicnet.reportmanager.api.ImmutableExportSettings.copyOf;
import static com.ossnms.bicnet.reportmanager.api.ImmutableSystemSettings.settings;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;

public class SystemSettingsDocument extends AbstractDocument {

    private SystemSettings settings = SystemSettings.DEFAULT;

    public ExportSettings configurationExport() {
        return settings.configurationExport();
    }

    public ExportSettings inventory() {
        return settings.inventory();
    }
    
    public ExportSettings outageExport() {
        return settings.outageExport();
    }

    public void saveSettings(Object inventoryRetention, Object configurationRetention, Object outageRetention) {
        SystemSettings newSettings = settings(
                copyOf(inventory()).withRetentionNumber((Integer) inventoryRetention),
                copyOf(configurationExport()).withRetentionNumber((Integer) configurationRetention),
                copyOf(outageExport()).withRetentionNumber((Integer) outageRetention));

        addAndExecuteJob(new SystemSettingsUpdateJob(this, newSettings, difference(settings, newSettings)));
        settings = newSettings;
    }

    @Override
    public void fetchOtherData() {

    }

    @Override public void fetchData() {
        addAndExecuteJob(new SystemSettingsFetchJob(this));
    }

    @Override
    protected void fetchSystemSettings() {
    }

    @Override public OperationKey handleJobNotifications(@Nonnull IJobVisitable job, @Nonnull Object result) {
        if (job instanceof SystemSettingsFetchJob) {
            settings = (SystemSettings) result;
            return OperationKey.LOAD_SYSTEM_SETTINGS;
        }
        return OperationKey.NOTHING_TO_DO;
    }

    @Override public boolean onHandlingRMMessageItem(@Nonnull RMMessageItem arg) throws BcbException {
        return false;
    }

    private Collection<String> difference(SystemSettings settings, SystemSettings newSettings) {
        Collection<String> messages = new ArrayList<>();
        messages.addAll(compareRetention(INVENTORY.guiName().toString(), settings.inventory(), newSettings.inventory()));
        messages.addAll(compareRetention(CONFIGURATION.guiName().toString(), settings.configurationExport(), newSettings.configurationExport()));
        messages.addAll(compareRetention(OUTAGE.guiName().toString(), settings.outageExport(), newSettings.outageExport()));
        return messages;
    }

    private Collection<String> compareRetention(String name, ExportSettings exportSettings, ExportSettings newExportSettings) {
        if (exportSettings.retentionNumber() != newExportSettings.retentionNumber()) {
            return singletonList(RETENTION_DIFFERENCE.format(name, newExportSettings.retentionNumber()));
        }
        return emptyList();
    }
}
