/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.presentation.settings.system;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.AbstractPrivateFacadeFetchJob;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;

import javax.annotation.Nonnull;

public class SystemSettingsFetchJob extends AbstractPrivateFacadeFetchJob<SystemSettings, IReportManagerPrivateFacade> {

    private static final String ID = SystemSettingsFetchJob.class.getName();
    private static final String NAME = "system settings fetch job";

    public SystemSettingsFetchJob(IFrameworkDocument document) {
        super(IReportManagerPrivateFacade.class, ID,  NAME, "", document);
    }

    @Override public SystemSettings invokeMethodFromFacade(@Nonnull IReportManagerPrivateFacade privateFacade) throws BcbException {
        return privateFacade.getSystemSettings(getSessionContext());
    }

    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        ISystemSettingsJobHandler jobHandler = (ISystemSettingsJobHandler) visitor;
        return jobHandler.handle(this, result);
    }
}
