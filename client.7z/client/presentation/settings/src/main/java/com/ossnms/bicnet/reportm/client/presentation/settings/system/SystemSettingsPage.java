/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.presentation.settings.system;

import static com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels.CONFIGURATION;
import static com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels.INVENTORY;
import static com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels.OUTAGE;
import static com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels.RETENTION_NUMBER;
import static com.ossnms.bicnet.reportmanager.api.ExportSettings.DEFAULT;
import static com.ossnms.tools.jfx.JfxStringTable.IDS_Default;
import static com.ossnms.tools.jfx.JfxStringTable.IDS_RANGE;
import static com.ossnms.tools.jfx.JfxUtils.PANEL_OUTSIDE_BORDER;
import static com.ossnms.tools.jfx.JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD;
import static java.awt.GridBagConstraints.BASELINE_LEADING;
import static java.awt.GridBagConstraints.HORIZONTAL;
import static java.awt.GridBagConstraints.NONE;
import static java.awt.GridBagConstraints.SOUTHWEST;
import static java.util.Arrays.asList;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import javax.swing.Box;
import javax.swing.JComponent;
import javax.swing.JPanel;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.common.jfx.JfxModifiableField;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataChangeListener;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.reportm.client.utilities.i18n.SystemSettingsLabels;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxSpinner;
import com.ossnms.tools.jfx.components.JfxTitledBorder;

public class SystemSettingsPage implements BiCNetPluginSettingsPropertyPage, IFrameworkDataChangeListener {

    private static final int MINIMUM_RETENTION_NUMBER = 1;
    private static final int MAXIMUM_RETENTION_NUMBER = 365;
    
    private final SystemSettingsDocument document;
    
    private JPanel mainComponent;
    
    private JfxLabel inventoryRetentionLabel;
    private JfxSpinner inventoryRetentionSpinner;
    private JfxLabel inventoryRetentionRange;
    
    private JfxSpinner configurationRetentionSpinner;
    private JfxLabel configurationRetentionLabel;
    private JfxLabel configurationRetentionRange;
    
    private JfxSpinner outageRetentionSpinner;
    private JfxLabel outageRetentionLabel;
    private JfxLabel outageRetentionRange;
    
    private JfxButton defaultButton;
    
    private BiCNetPluginPropertyPageSite pageSite;

    private static final Insets CAPTION_FIELD_INSETS = new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD);
    private static final Insets EMPTY_INSETS = new Insets(0, 0, 0, 0);

    public SystemSettingsPage(SystemSettingsDocument document) {
        this.document = document;
        this.document.setDataChangeListener(this);
        initComponents();
        doLayout();
        setGuiNames();
    }

    @Override public void eventOpened() {
        document.init();
    }

    @Override public String getID() {
        return SystemSettingsPage.class.getName();
    }

    @Override public JComponent getComponent() {
        return mainComponent;
    }

    @Override public String getTitle() {
        return SystemSettingsLabels.VIEW_TITLE.toString();
    }

    @Override public void setReadOnly(boolean readOnly) {
        List<? extends JComponent> interactive = asList(defaultButton, inventoryRetentionSpinner, configurationRetentionSpinner);

        for (JComponent component : interactive) {
            component.setEnabled(!readOnly);
        }
    }

    @Override public boolean isPageDirty() {
        return Stream.of(inventoryRetentionSpinner, configurationRetentionSpinner, outageRetentionSpinner).anyMatch(JfxModifiableField::isValueModified);
    }

    @Override public void actionApply() {
        document.saveSettings(inventoryRetentionSpinner.getValue(), configurationRetentionSpinner.getValue(), outageRetentionSpinner.getValue());
    }

    private void doLayout() {
        mainComponent.setLayout(new GridBagLayout());
        mainComponent.setBorder(PANEL_OUTSIDE_BORDER);

        JPanel retentionPanel = new JPanel(new GridBagLayout());
        retentionPanel.setBorder(new JfxTitledBorder(RETENTION_NUMBER.guiName()));
        
        int row = 0;
        int column = 0;
        retentionPanel.add(inventoryRetentionLabel, toLeft(row, column));
        ++column;
        retentionPanel.add(inventoryRetentionSpinner, toMiddle(row, column));
        ++column;
        retentionPanel.add(inventoryRetentionRange, toRight(row, column));

        ++row;
        column = 0;
        retentionPanel.add(configurationRetentionLabel, toLeft(row, column));
        ++column;
        retentionPanel.add(configurationRetentionSpinner, toMiddle(row, column));
        ++column;
        retentionPanel.add(configurationRetentionRange, toRight(row, column));
        
        ++row;
        column = 0;
        retentionPanel.add(outageRetentionLabel, toLeft(row, column));
        ++column;
        retentionPanel.add(outageRetentionSpinner, toMiddle(row, column));
        ++column;
        retentionPanel.add(outageRetentionRange, toRight(row, column));
        
        row = 0;
        column = 0;
        mainComponent.add(retentionPanel, toFit(row, column));
        ++row;
        mainComponent.add(Box.createGlue(), toFit(row, column));
        mainComponent.add(defaultButton, leftBottomCorner(row, column));
    }

    private GridBagConstraints leftBottomCorner(int row, int column) {
        return new GridBagConstraints(column, row, 3, 1, 1, 1, SOUTHWEST, NONE, EMPTY_INSETS, 0, 0);
    }
    
    private GridBagConstraints toLeft(int row, int column) {
        return new GridBagConstraints(column, row, 1, 1, 0, 0, BASELINE_LEADING, NONE, CAPTION_FIELD_INSETS, 0, 0);
    }

    private GridBagConstraints toMiddle(int row, int column) {
        return new GridBagConstraints(column, row, 1, 1, 0, 0, BASELINE_LEADING, NONE, CAPTION_FIELD_INSETS, 0, 0);
    }
    
    private GridBagConstraints toRight(int row, int column) {
        return new GridBagConstraints(column, row, 1, 1, 1.0, 0, BASELINE_LEADING, HORIZONTAL, EMPTY_INSETS, 0, 0);
    }
    
    private GridBagConstraints toFit(int row, int column) {
        return new GridBagConstraints(column, row, 1, 1, 1.0, 0.0, BASELINE_LEADING, HORIZONTAL, EMPTY_INSETS, 0, 0);
    }

    private void initComponents() {
        mainComponent = new JPanel();

        defaultButton = new JfxButton(IDS_Default);
        defaultButton.addActionListener(e -> loadDefaultValues());

        inventoryRetentionSpinner = newRetentionSpinner();

        inventoryRetentionLabel = new JfxLabel(INVENTORY.guiName());
        inventoryRetentionLabel.setLabelAndMnemonicFor(inventoryRetentionSpinner);

        inventoryRetentionRange = new JfxLabel(IDS_RANGE.getFormatedMessage(MINIMUM_RETENTION_NUMBER, MAXIMUM_RETENTION_NUMBER));

        configurationRetentionSpinner = newRetentionSpinner();

        configurationRetentionLabel = new JfxLabel(CONFIGURATION.guiName());
        configurationRetentionLabel.setLabelAndMnemonicFor(configurationRetentionSpinner);

        configurationRetentionRange = new JfxLabel(IDS_RANGE.getFormatedMessage(MINIMUM_RETENTION_NUMBER, MAXIMUM_RETENTION_NUMBER));
        
        outageRetentionSpinner = newRetentionSpinner();

        outageRetentionLabel = new JfxLabel(OUTAGE.guiName());
        outageRetentionLabel.setLabelAndMnemonicFor(outageRetentionSpinner);

        outageRetentionRange = new JfxLabel(IDS_RANGE.getFormatedMessage(MINIMUM_RETENTION_NUMBER, MAXIMUM_RETENTION_NUMBER));
    }
    
    private void setGuiNames() {
        defaultButton.setName("Default");
        
        inventoryRetentionLabel.setName("InventoryRetentionNumber");
        inventoryRetentionRange.setName("InventoryRetentionRange");
        inventoryRetentionSpinner.setName("InventoryRetentionNumber");
        
        configurationRetentionLabel.setName("ConfigurationRetentionNumber");
        configurationRetentionRange.setName("ConfigurationRetentionRange");
        configurationRetentionSpinner.setName("ConfigurationRetentionNumber");
        
        outageRetentionLabel.setName("OutageRetentionNumber");
        outageRetentionRange.setName("OutageRetentionRange");
        outageRetentionSpinner.setName("OutageRetentionNumber");
    }

    private JfxSpinner newRetentionSpinner() {
        JfxSpinner spinner = new JfxSpinner(new SpinnerIntegerModel(DEFAULT.retentionNumber(), MINIMUM_RETENTION_NUMBER, MAXIMUM_RETENTION_NUMBER, 1));
        spinner.setUnmodifiedValue(DEFAULT.retentionNumber());
        spinner.getModel().addChangeListener(e -> pageSite.eventPageStatusChanged(this));
        return spinner;
    }

    private void loadDefaultValues() {
        inventoryRetentionSpinner.setValue(DEFAULT.retentionNumber());
        configurationRetentionSpinner.setValue(DEFAULT.retentionNumber());
        outageRetentionSpinner.setValue(DEFAULT.retentionNumber());
    }

    private void loadValues() {
        inventoryRetentionSpinner.setValue(document.inventory().retentionNumber());
        inventoryRetentionSpinner.setUnmodifiedValue(document.inventory().retentionNumber());

        configurationRetentionSpinner.setValue(document.configurationExport().retentionNumber());
        configurationRetentionSpinner.setUnmodifiedValue(document.configurationExport().retentionNumber());
        
        outageRetentionSpinner.setValue(document.outageExport().retentionNumber());
        outageRetentionSpinner.setUnmodifiedValue(document.outageExport().retentionNumber());
    }

    @Override public void updateData(Object key) {
        if (Objects.equals(key, OperationKey.LOAD_SYSTEM_SETTINGS)) {
            loadValues();
        }
    }

    @Override public boolean isEnabled(IManagedObject[] mos) {
        return document.getPluginHelper().checkPermissions(Policies.NETWORK_INVENTORY_SETTINGS.toString());
    }

    @Override public void setPageSite(BiCNetPluginPropertyPageSite site) {
        pageSite = site;
    }

    @Override public void setObjects(IManagedObjectMarkable[] arObjects) {
    }

    @Override public void update() {
    }

    @Override public void validateInput() throws BiCNetPluginException {
    }

    @Override public void eventClosing() {
    }

    @Override public void actionCancel() {
    }

    @Override public BiCNetPluginSettingsPropertyPage[] getChildPages() {
        return new BiCNetPluginSettingsPropertyPage[0];
    }

    @Override public void setFrame(BiCNetPluginFrame frame) {
    }
}