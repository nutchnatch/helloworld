package com.ossnms.bicnet.reportm.client.presentation.settings.export;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettings;
import com.ossnms.bicnet.reportmanager.api.ExportSettings;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings;
import com.ossnms.bicnet.reportmanager.dto.AlarmMessagingCriteriaSettings.ThresholdSettings;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.PrivilegedActionException;
import java.util.Collection;
import java.util.Optional;
import java.util.Properties;

import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.fromOrdinal;
import static com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController.doPrivileged;
import static com.ossnms.bicnet.reportm.client.presentation.settings.export.SchedulerSettings.scheduleSettings;
import static com.ossnms.bicnet.reportm.client.presentation.settings.export.SettingsBuilder.children;
import static com.ossnms.bicnet.reportm.client.presentation.settings.export.SettingsBuilder.properties;
import static com.ossnms.bicnet.reportm.client.presentation.settings.export.SettingsBuilder.settings;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableAlarmMessagingCriteriaSettings.alarmMessaging;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableThresholdSettings.threshold;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARMS_OUTAGE_REPORT;
import static com.ossnms.bicnet.reportmanager.util.Constants.ALARM_MESSAGING_REPORT;
import static com.ossnms.bicnet.reportmanager.util.Constants.CONFIGURATION_EXPORT_REPORT;
import static com.ossnms.bicnet.reportmanager.util.Constants.INVENTORY_EXPORT_REPORT;
import static java.lang.String.valueOf;
import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.joining;

public class SettingsExport {

    public static final Logger LOGGER = LoggerFactory.getLogger(SettingsExport.class);
    private final IReportManagerPrivateFacade privateFacade;
    private final ISessionContext context;

    public SettingsExport(IReportManagerPrivateFacade privateFacade, ISessionContext context) {
        this.privateFacade = privateFacade;
        this.context = context;
    }

    public BiCNetPluginSettings pluginSettings() {
        SystemSettings systemSettings = fetchSystemSettings();
        return settings("Report Management",
                children(
                        inventoryExport(systemSettings, fetchSchedule(INVENTORY_EXPORT_REPORT)),
                        configurationExport(systemSettings, fetchSchedule(CONFIGURATION_EXPORT_REPORT)),
                        outageReport(systemSettings, fetchSchedule(ALARMS_OUTAGE_REPORT)),
                        alarmsMessaging(fetchAlarmMessaging(), fetchSchedule(ALARM_MESSAGING_REPORT))),
                properties());
    }

    private BiCNetPluginSettings inventoryExport(SystemSettings systemSettings, Optional<ISchedule> schedule) {
        return settings("network inventory",
                children(scheduleSettings(schedule)),
                properties(fromExportSettings(systemSettings.inventory())));
    }

    private BiCNetPluginSettings configurationExport(SystemSettings systemSettings, Optional<ISchedule> schedule) {
        return settings("configuration export",
                children(scheduleSettings(schedule)),
                properties(fromExportSettings(systemSettings.configurationExport())));
    }

    private BiCNetPluginSettings outageReport(SystemSettings systemSettings, Optional<ISchedule> schedule) {
        return settings("outage export",
                children(scheduleSettings(schedule)),
                properties(fromExportSettings(systemSettings.outageExport())));
    }

    private BiCNetPluginSettings alarmsMessaging(AlarmMessagingCriteriaSettings settings, Optional<ISchedule> schedule) {
        return settings("alarm messaging",
                children(scheduleSettings(schedule),
                        settings("threshold", properties(fromThreshold(settings.threshold())))),
                properties(selectedNEs(settings.selectedNEs())));
    }

    private Properties selectedNEs(Collection<INEId> nes) {
        String ids = nes.stream().map(INEId::getId).map(String::valueOf).collect(joining(","));
        Properties properties = new Properties();
        properties.setProperty("selected NEs", ids);
        return properties;
    }

    AlarmMessagingCriteriaSettings fetchAlarmMessaging() {
        try {
            return (AlarmMessagingCriteriaSettings) doPrivileged(this, () -> privateFacade.getAlarmMessagingCriteriaSettings(context));
        } catch (PrivilegedActionException e) {
            LOGGER.error("Failed to fetch AlarmMessagingCriteriaSettings data ", e);
            return alarmMessaging(threshold(false, 0, 0), emptyList());
        }
    }

    private Properties fromThreshold(ThresholdSettings threshold) {
        Properties properties = new Properties();
        properties.setProperty("enabled", valueOf(threshold.enabled()));
        properties.setProperty("number", valueOf(threshold.number()));
        properties.setProperty("severity", fromOrdinal(threshold.severity()).name());
        return properties;
    }

    private Properties fromExportSettings(ExportSettings exportSettings) {
        Properties properties = new Properties();
        properties.setProperty("retention number", valueOf(exportSettings.retentionNumber()));
        properties.setProperty("export path", exportSettings.exportPath());
        return properties;
    }

    private SystemSettings fetchSystemSettings() {
        try {
            return (SystemSettings) doPrivileged(this, () -> privateFacade.getSystemSettings(context));
        } catch (PrivilegedActionException e) {
            LOGGER.error("Failed to fetch report system settings ", e);
            return SystemSettings.DEFAULT;
        }
    }

    private Optional<ISchedule> fetchSchedule(final String reportId) {
        try {
            ReportDataDto reportData = (ReportDataDto) doPrivileged(this, () -> privateFacade.getReportData(context, reportId));
            return Optional.ofNullable(reportData.getSchedule());
        } catch (PrivilegedActionException e) {
            LOGGER.error("Failed to fetch report data for report {}", reportId, e);
            return Optional.empty();
        }
    }
}
