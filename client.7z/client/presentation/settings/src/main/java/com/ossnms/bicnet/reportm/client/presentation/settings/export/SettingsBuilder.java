package com.ossnms.bicnet.reportm.client.presentation.settings.export;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettings;

import java.util.Collection;
import java.util.Properties;

import static java.util.Arrays.asList;

enum SettingsBuilder {
    ;

    public static BiCNetPluginSettings settings(String name, Collection<BiCNetPluginSettings> children, Collection<Properties> properties) {
        return withProperties(withChildren(new BiCNetPluginSettings(name), children), properties);
    }

    public static BiCNetPluginSettings settings(String name, Collection<Properties> properties) {
        return withProperties(new BiCNetPluginSettings(name), properties);
    }

    private static BiCNetPluginSettings withProperties(BiCNetPluginSettings settings, Collection<Properties> properties) {
        if (!settings.hasProperties()) {
            settings.setProperties(new Properties());
        }
        for (Properties property : properties) {
            settings.getProperties().putAll(property);
        }
        return settings;
    }

    private static BiCNetPluginSettings withChildren(BiCNetPluginSettings settings, Collection<BiCNetPluginSettings> children) {
        for (BiCNetPluginSettings child : children) {
            settings.addChild(child);
        }
        return settings;
    }

    static Collection<BiCNetPluginSettings> children(BiCNetPluginSettings... children) {
        return asList(children);
    }

    static Collection<Properties> properties(Properties... properties) {
        return asList(properties);
    }
}
