package com.ossnms.bicnet.reportm.client.presentation.settings.export;

import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.SchedulePeriod;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettings;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.TimeZone;
import java.util.function.Function;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.MONTHLY;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.UNDEFINED;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.USER_DEFINED;
import static com.ossnms.bicnet.bcb.model.platform.SchedulePeriod.WEEKLY;
import static com.ossnms.bicnet.reportm.client.presentation.settings.export.SettingsBuilder.children;
import static com.ossnms.bicnet.reportm.client.presentation.settings.export.SettingsBuilder.properties;
import static com.ossnms.bicnet.reportm.client.presentation.settings.export.SettingsBuilder.settings;
import static java.lang.String.valueOf;
import static java.text.MessageFormat.format;

final class SchedulerSettings {

    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");
    private static final String DATE_PATTERN = "yyyy-MMM-dd HH:mm:ss z";

    private SchedulerSettings() {
    }

    private static final Map<SchedulePeriod, Function<ISchedule, String>> PERIOD_MAPPING = of(
            UNDEFINED, schedule -> "",
            WEEKLY, schedule -> schedule.getWeeklyDays().toString(),
            MONTHLY, schedule -> schedule.getMonthlyDays().toString(),
            USER_DEFINED, schedule -> daysAndHours(schedule.getUserPeriod()));

    static BiCNetPluginSettings scheduleSettings(Optional<ISchedule> schedule) {
        return settings("schedule",
                children(),
                properties(schedule.map(SchedulerSettings::propertiesOf)
                        .orElseGet(SchedulerSettings::emptyProperties)));
    }

    private static Properties emptyProperties() {
        Properties properties = new Properties();
        properties.setProperty("activate", EnableSwitch.DISABLED.toString());
        return properties;
    }

    private static Properties propertiesOf(ISchedule schedule) {
        Properties properties = new Properties();
        properties.setProperty("activate", schedule.getActivation().name());
        properties.setProperty("periodic pattern", schedule.getPeriod().name());
        properties.setProperty("start time", utcDate(schedule.getStartTime()));
        properties.setProperty("number executions", valueOf(schedule.getOccurrencesUntilEnd()));
        properties.setProperty("period", period(schedule));
        return properties;
    }

    private static String period(ISchedule schedule) {
        Function<ISchedule, String> mapping = PERIOD_MAPPING.getOrDefault(schedule.getPeriod(), PERIOD_MAPPING.get(UNDEFINED));
        return mapping.apply(schedule);
    }

    private static String daysAndHours(int minutes) {
        int days = minutes / 1440;
        int dayHours = minutes % 1440 / 60;
        return format("{0} days and {1} hours", days, dayHours);
    }

    private static String utcDate(Date date) {
        SimpleDateFormat dateFormatGmt = new SimpleDateFormat(DATE_PATTERN);
        dateFormatGmt.setTimeZone(UTC);
        return dateFormatGmt.format(date);
    }
}
