package com.ossnms.bicnet.reportm.client.presentation.settings.system;

import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;

public interface ISystemSettingsJobHandler extends IJobVisitor {

    OperationKey handle(SystemSettingsFetchJob systemSettingsFetchJob, Object result);
}
