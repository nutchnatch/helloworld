/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.presentation.export.views;

import static com.ossnms.bicnet.reportmanager.api.ImmutableExportSettings.of;
import static com.ossnms.bicnet.reportmanager.api.ImmutableSystemSettings.settings;
import static java.util.Collections.addAll;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;

import javax.swing.*;

import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceContribution;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceProvider;
import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.documents.InventoryExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.views.InventoryExportManagerView;
import com.ossnms.bicnet.reportmanager.api.ExportSettings;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxTextField;

public class InventoryExportManagerViewTest {

    private InventoryExportDocument inventoryExportDocument;
    private BiCNetPluginExternalCommunicationServiceProvider serviceProvider;
    private BiCNetPluginExternalCommunicationServiceContribution contribution;

    @Before public void setUp() throws Exception {
        FrameworkPluginHelper pluginHelper = mock(FrameworkPluginHelper.class);
        when(pluginHelper.checkPermissions(anyString())).thenReturn(true);
        when(pluginHelper.getCfPluginSite()).thenReturn(mock(BiCNetPluginSite.class));

        inventoryExportDocument = mock(InventoryExportDocument.class);
        serviceProvider = mock(BiCNetPluginExternalCommunicationServiceProvider.class);
        contribution = mock(BiCNetPluginExternalCommunicationServiceContribution.class);
        when(inventoryExportDocument.getPluginHelper()).thenReturn(pluginHelper);
        when(inventoryExportDocument.getEcsContribution()).thenReturn(contribution);
//        when(serviceProvider.getContribution()).thenReturn(contribution);
        when(contribution.getComponent()).thenReturn(new JPanel());
    }

    @Test public void shouldContainFieldWithExportPath() throws Exception {
        JComponent mainComponent = new InventoryExportManagerView("", inventoryExportDocument).getMainComponent();

        JfxTextField exportPathField = findByNameAndAssert(mainComponent, "FIELD.ExportPath", JfxTextField.class);
        assertThat(exportPathField.isEditable(), is(false));
    }

    @Test public void shouldContainLabelForExportPathField() throws Exception {
        JComponent mainComponent = new InventoryExportManagerView("", inventoryExportDocument).getMainComponent();
        Component exportPathField = findByNameAndAssert(mainComponent, "FIELD.ExportPath", JfxTextField.class);
        JfxLabel exportPathLabel = findByNameAndAssert(mainComponent, "LABEL.ExportPath", JfxLabel.class);
        assertThat(exportPathLabel.getLabelFor(), is(exportPathField));
        assertThat(exportPathLabel.getText(), is("Path:"));
    }

    @Test public void shouldSetExportPathFromJobResult() throws Exception {
        SystemSettings systemSettingsDto = settings(of(42, "some export path"), ExportSettings.DEFAULT, ExportSettings.DEFAULT);
        when(inventoryExportDocument.getSystemSettings()).thenReturn(Optional.of(systemSettingsDto));

        InventoryExportManagerView exportView = new InventoryExportManagerView("", inventoryExportDocument);
        exportView.updateData(OperationKey.LOAD_SYSTEM_SETTINGS);

        JfxTextField exportPathField = findByNameAndAssert(exportView.getMainComponent(), "FIELD.ExportPath", JfxTextField.class);
        assertThat(exportPathField.getText(), is("some export path"));
    }

    private <T> T findByNameAndAssert(JComponent rootComponent, String name, Class<T> type) {
        List<String> found = new ArrayList<>();
        Queue<Component> components = new ArrayDeque<>();
        addAll(components, rootComponent.getComponents());

        while (!components.isEmpty()) {
            Component component = components.poll();
            if (Objects.equals(component.getName(), name)) {
                assertThat(component, instanceOf(type));
                return (T) component;
            }
            if (component instanceof Container) {
                addAll(components, ((Container) component).getComponents());
            }
            found.add('[' + component.getClass().getSimpleName() + ']' + component.getName());
        }

        fail("Expected [" + type.getSimpleName() + ']' + name + " but found " + found);
        return null;
    }

    public static void main(String[] args) throws Exception {
        final InventoryExportManagerViewTest test = new InventoryExportManagerViewTest();
        test.setUp();
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame();
                frame.setSize(300, 200);
                frame.setLocationRelativeTo(null);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                try {
                    frame.add(new InventoryExportManagerView("",test.inventoryExportDocument).getComponent());
                } catch (BcbException e) {
                    e.printStackTrace();
                }
                frame.setVisible(true);
            }
        });
    }
}
