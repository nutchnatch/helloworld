package com.ossnms.bicnet.reportm.client.presentation.export.views;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientPropertyListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommitButton;
import com.ossnms.bicnet.framework.client.utils.FrameworkCloseCommand;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.ui.utils.TimeConvertionUtils;
import com.ossnms.bicnet.reportm.client.api.views.AbstractView;
import com.ossnms.bicnet.reportm.client.presentation.export.documents.AbstractExportDocument;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dto.JobExecutionStatus;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.ReportExecutionDto;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.JfxOptionsData;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxTextField;
import com.ossnms.tools.jfx.components.JfxTitledBorder;

import javax.annotation.Nonnull;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;

import static java.util.Optional.empty;

/**
 * Base class for Export views. Consists on fields for current state, last export details and next schedule time.
 */
public abstract class ExportStateView extends AbstractView {
    private static final String DATE_FORMAT_PATTERN = "dd-MM-yyyy HH:mm:ss";

    private static final int WINDOW_WIDTH = 400;
    private static final int WINDOW_HEIGHT = 215;
    private static final long serialVersionUID = 8980701435556222913L;

    private final JfxTextField nextScheduleField = new JfxTextField();
    private final JfxTextField startTimeField = new JfxTextField();
    private final JfxTextField endTimeField = new JfxTextField();
    private final JfxLabel stateLabel = new JfxLabel(ExportLabels.IDS_EXPORT_STATE.toString());
    private final JfxLabel nextScheduleLabel = new JfxLabel(ExportLabels.IDS_EXPORT_NEXT_SCHEDULE.toString());
    private final JfxLabel startTimeLabel = new JfxLabel(ExportLabels.IDS_EXPORT_START.toString());
    private final JfxLabel endTimeLabel = new JfxLabel(ExportLabels.IDS_EXPORT_END.toString());
    private final JfxLabel exportPathLabel = new JfxLabel(ExportLabels.IDS_EXPORT_FILE_PATH.toString());
    private final JfxTextField stateField = new JfxTextField();
    private final JfxTextField exportPathField = new JfxTextField();
    private final JPanel mainPanel = new JPanel();

    private final FrameworkCloseCommand frameworkCloseCommand = new FrameworkCloseCommand(this, JfxStringTable.IDS_Close_WITHOUT_MNEMONIC.toString());

    private Optional<Date> nextScheduleDate = empty();
    private Optional<Date> startDate = empty();
    private Optional<Date> endDate = empty();
    private static final EnumSet<JobExecutionStatus> RUNNING_STATUSES = EnumSet.of(JobExecutionStatus.STARTED, JobExecutionStatus.STARTING, JobExecutionStatus.STOPPING);

    public ExportStateView(String id, String title, AbstractExportDocument doc, boolean resizable, int helpId) throws BcbException {
        super(id, title, doc, resizable, helpId);
        setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        initLayout();
        doc.getPluginHelper().getCfPluginSite().addClientPropertyListener(this);
    }

    /**
     * Convert time to the configured TimeZone
     *
     * @return formatted date converted to Client Timezone
     */
    private static String convertTime(@Nonnull final Date date) {
        return TimeConvertionUtils.convertToTime(date, DATE_FORMAT_PATTERN);
    }

    private void initThisGuiNames() {
        mainPanel.setName("PANEL.Main");
        setName("View");

        nextScheduleField.setName("NextSchedule");
        startTimeField.setName("StartTime");
        endTimeField.setName("EndTime");
        stateLabel.setName("StateLbl");
        nextScheduleLabel.setName("NextScheduleLbl");
        startTimeLabel.setName("StartTimeLbl");
        endTimeLabel.setName("EndTimeLbl");
        stateField.setName("State");
        exportPathField.setName("ExportPath");
        exportPathLabel.setName("ExportPath");
    }

    private void initLayout() {
        initThisGuiNames();
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        setLableAndMnemonic();
        setNotEditable();
        JPanel statePanel = new JPanel(new GridBagLayout());
        JPanel lastSchedulePanel = new JPanel(new GridBagLayout());
        addFieldsToStatePanel(statePanel);
        addFiledsToSchedulePanel(lastSchedulePanel);
        mainPanel.add(statePanel, new GridBagConstraints(0, 0, 2, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        mainPanel.add(lastSchedulePanel, new GridBagConstraints(0, 1, 2, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        mainPanel.add(exportPathLabel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        mainPanel.add(exportPathField, new GridBagConstraints(1, 3, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
    }

    private void addFieldsToStatePanel(JPanel statePanel) {
        statePanel.add(stateLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        statePanel.add(stateField, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        statePanel.add(nextScheduleLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        statePanel.add(nextScheduleField, new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    }

    private void addFiledsToSchedulePanel(JPanel lastSchedulePanel) {
        lastSchedulePanel.setBorder(new JfxTitledBorder(ExportLabels.SCHEDULE_LAST_SUCCESSFUL_EXPORT_PANEL.toString()));
        lastSchedulePanel.add(startTimeLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        lastSchedulePanel.add(startTimeField, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        lastSchedulePanel.add(endTimeLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        lastSchedulePanel.add(endTimeField, new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    }

    private void setNotEditable() {
        stateField.setEditable(false);
        nextScheduleField.setEditable(false);
        startTimeField.setEditable(false);
        endTimeField.setEditable(false);
        exportPathField.setEditable(false);
    }

    private void setLableAndMnemonic() {
        stateLabel.setLabelAndMnemonicFor(stateField);
        nextScheduleLabel.setLabelAndMnemonicFor(nextScheduleField);
        startTimeLabel.setLabelAndMnemonicFor(startTimeField);
        endTimeLabel.setLabelAndMnemonicFor(endTimeField);
        exportPathLabel.setLabelAndMnemonicFor(exportPathField);
    }

    @Override
    protected List<FrameworkCommitButton> getCommitActions() {
        List<FrameworkCommitButton> functionActions = new ArrayList<>();
        functionActions.add(frameworkCloseCommand);
        return functionActions;
    }

    @Override
    protected void initKeyBindings() {
        getComponent().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "Esc");
        getComponent().getActionMap().put("Esc", frameworkCloseCommand);
    }

    @Override
    protected ImageIcon getViewIcon() {
        return ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16;
    }

    @Override
    protected ActionType getViewAction() {
        return ActionType.UNKNOWN;
    }

    @Override
    protected JComponent getMainComponent() {
        return mainPanel;
    }

    @Override
    public void updateData(@Nonnull Object key) {
        if (key instanceof OperationKey) {
            switch ((OperationKey) key) {
                case LOAD_EXPORT_DATA:
                    loadExportData(getFrameworkDocument().getExportData());
                    stopActivityIndicator();
                    break;
                case LOAD_SYSTEM_SETTINGS:
                    loadSettings(getFrameworkDocument().getSystemSettings());
                    break;
                case HANDLE_NOTIFICATIONS:
                    loadExportData(getFrameworkDocument().getExportData());
                    break;
                default:
                    break;
            }
        }
    }

    private void loadSettings(Optional<SystemSettings> systemSettings) {
        systemSettings.map(this::getExportPath).ifPresent(exportPathField::setText);
    }

    /**
     * Load Export Data in the GUI fileds
     *
     * @param jobData - contains inventory data coming from server
     */
    private void loadExportData(@Nonnull Optional<ReportDataDto> jobData) {
        final Optional<ReportExecutionDto> currentExecution = jobData.map(ReportDataDto::getCurrentExecution);
        stateField.setText(currentExecution.map(ReportExecutionDto::getStatus).map(Object::toString).orElse("-"));
        currentExecution.ifPresent(this::updateManualCommand);


        nextScheduleDate = jobData.map(ReportDataDto::getNextExecutionTime).map(Date::new);
        nextScheduleField.setText(nextScheduleDate.map(ExportStateView::convertTime).orElse("-"));


        final Optional<ReportExecutionDto> lastExecutionData = jobData.map(ReportDataDto::getLastSuccessfulExecution);

        startDate = lastExecutionData.map(ReportExecutionDto::getStartTime).map(Date::new);
        startTimeField.setText(startDate.map(ExportStateView::convertTime).orElse("-"));

        endDate = lastExecutionData.map(ReportExecutionDto::getEndTime).map(Date::new);
        endTimeField.setText(endDate.map(ExportStateView::convertTime).orElse("-"));
    }

    private void updateManualCommand(ReportExecutionDto currentExecution) {
        boolean isRunning = RUNNING_STATUSES.contains(currentExecution.getStatus());
        if (isRunning) {
            getManualCommand().setEnabled(false);
        } else {
            getManualCommand().setEnabled(true);
        }
    }

    private void stopActivityIndicator() {
        setActivityIndicatorVisible(false);
    }

    @Override
    public void eventOpened() {
        super.eventOpened();
        setActivityIndicatorVisible(true);
    }

    @Override
    public void eventPluginClientPropertiesChanged() {
        nextScheduleField.setText(nextScheduleDate.map(ExportStateView::convertTime).orElse("-"));
        startTimeField.setText(startDate.map(ExportStateView::convertTime).orElse("-"));
        endTimeField.setText(endDate.map(ExportStateView::convertTime).orElse("-"));
    }

    @Override
    protected AbstractExportDocument getFrameworkDocument() {
        return (AbstractExportDocument) super.getFrameworkDocument();
    }

    protected abstract FrameworkCommand getManualCommand();

    protected abstract String getExportPath(SystemSettings systemSettings);

    protected abstract List<JfxButton> provideButtons();

    @Override
    protected List<?> getFunctionActions() {
        return new ArrayList<Object>(provideButtons());
    }

    @Override
    public void addClientLogEntry(String s, Exception e) {

    }

    @Override
    public boolean supportsPersistance() {
        return false;
    }

    @Override
    protected String getProfileId() {
        return null;
    }

    @Override
    protected JfxOptionsData getOptionsData() {
        return null;
    }

//    @Override
//    protected void loadLdapSettings(JfxOptionsData jfxOptionsData) {
//
//    }
//
//    @Override
//    protected void saveLdapSettings(JfxOptionsData jfxOptionsData) {
//
//    }

    @Override
    protected void loadSettings(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveSettings(JfxOptionsData aProfile) {

    }


    @Override
    protected void loadFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected IPluginSecurityProvider getSecurityProvider() throws BiCNetPluginException {
        return null;
    }

    @Override
    protected ISecureClientSession getSecureClientSession() throws BiCNetPluginException {
        return null;
    }
}