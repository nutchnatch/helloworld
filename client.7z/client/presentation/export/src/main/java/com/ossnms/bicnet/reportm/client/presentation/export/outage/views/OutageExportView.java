package com.ossnms.bicnet.reportm.client.presentation.export.outage.views;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.Nonnull;
import javax.swing.JTable;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.commands.OutageExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.commands.OutageManualExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.commands.OutageScheduleExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.documents.OutageExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.views.ExportStateView;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.tools.jfx.components.JfxButton;

public class OutageExportView extends ExportStateView {
    private static final long serialVersionUID = -5077792332028827422L;
    
    private static final boolean NOT_RESIZABLE = false;
    private static final String VIEW_ID = OutageExportView.class.getName();

    private final OutageManualExportCommand manualCommand = new OutageManualExportCommand();
    private final OutageScheduleExportCommand scheduleCommand = new OutageScheduleExportCommand();
    private final JfxButton manualButton = new JfxButton(manualCommand);
    private final JfxButton scheduleButton  = new JfxButton(scheduleCommand);

    public OutageExportView(@Nonnull String title, @Nonnull OutageExportDocument doc) throws BcbException {
        super(VIEW_ID, title, doc, NOT_RESIZABLE, HelpIds.HID_ALARMS_OUTAGE_EXPORT);
        initControls();
        manualCommand.updateAction();
        scheduleCommand.updateAction();
        setGuiNames();
    }

    private void setGuiNames() {
        manualButton.setName("Manual");
        scheduleButton.setName("Schedule");
    }

    @Override
    protected List<JfxButton> provideButtons() {
        List<JfxButton> buttonList = new ArrayList<>();
        buttonList.add(manualButton);
        buttonList.add(scheduleButton);
        return buttonList;
    }

    @Override
    protected FrameworkCommand getManualCommand() {
        return manualCommand;
    }

    @Override
    protected String getExportPath(SystemSettings systemSettings) {
        return systemSettings.outageExport().exportPath();
    }

    @Override
    public String getCommandClassName() {
        return OutageExportCommand.class.getName();
    }

    @Override
    public JTable getDataToPrint() {
        return new JTable();
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {

    }

    @Override
    protected OutageExportDocument getFrameworkDocument() {
        return (OutageExportDocument) super.getFrameworkDocument();
    }

    @Override
    protected ActionType getViewAction() {
        return ActionType.ALARM;
    }
}