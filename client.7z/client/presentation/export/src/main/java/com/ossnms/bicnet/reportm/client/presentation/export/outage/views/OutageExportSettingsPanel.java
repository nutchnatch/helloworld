package com.ossnms.bicnet.reportm.client.presentation.export.outage.views;

import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.framework.client.utils.GenericMnemonicsCreator;
import com.ossnms.bicnet.reportm.client.api.ui.utils.TimeConvertionUtils;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.ETimeDisplay;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxDateCalendarField;
import com.ossnms.tools.jfx.components.JfxLabel;

import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.event.ChangeListener;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

public class OutageExportSettingsPanel extends JPanel {
    private static final long serialVersionUID = -2265408762040519565L;

    private JfxDateCalendarField startDateCalendar;
    private JfxDateCalendarField endDateCalendar;

    private final JLabel fieldsValidationLabel;

    protected JfxLabel startTimeLabel;
    protected JfxLabel endTimeLabel;
    protected JfxLabel severitiesLabel;
    protected JfxLabel statesLabel;

    private final List<JfxCheckBox> severityCheckboxes = new ArrayList<>();
    private List<AlarmSeverity> alarmSeverityList;

    private JfxCheckBox unacknowledgedCheckbox;
    private JfxCheckBox acknowledgedCheckbox;
    private JfxCheckBox raisedCheckbox;
    private JfxCheckBox clearedCheckbox;
    private JfxCheckBox automaticTimeRangeCheckbox;
    private final List<JfxCheckBox> stateCheckboxes = new ArrayList<>();

    private ETimeDisplay eTimeDisplay;

    public OutageExportSettingsPanel(JLabel fieldsValidationLabel, Date startDate, Date endDate) {
        this.fieldsValidationLabel = fieldsValidationLabel;
        createSettingsTab(startDate, endDate);
        setGuiNames();
    }
    private void setGuiNames() {
        setName("PANEL.Settings");
        startDateCalendar.setDateFieldName("StartDate");
        startDateCalendar.setDateFieldName("EndDate");
        unacknowledgedCheckbox.setName("Unacknowledged");
        acknowledgedCheckbox.setName("Acknowledged");
        clearedCheckbox.setName("Cleared");
        clearedCheckbox.setName("Raised");
        automaticTimeRangeCheckbox.setName("AutomaticTimeRange");
    }

    private void createSettingsTab(Date startDate, Date endDate) {
        this.setLayout(new GridBagLayout());

        severitiesLabel = new JfxLabel(ExportLabels.ALARMS_OUTAGE_EXPORT_SEVERITIES.toString());
        statesLabel = new JfxLabel(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES.toString());

        fieldsValidationLabel.setMinimumSize(new Dimension(16, 16));
        fieldsValidationLabel.setPreferredSize(new Dimension(16, 16));

        add(createTimePanel(startDate, endDate), new GridBagConstraints(0, 0, 2, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));

        add(severitiesLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        add(createSeveritiesCheckboxes(), new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.VERTICAL, new Insets(0, JfxUtils.FIELD_INDENTATION, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.FIELD_INDENTATION), 0, 0));

        add(statesLabel, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        add(createStatesCheckboxes(), new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.VERTICAL, new Insets(0, JfxUtils.FIELD_INDENTATION, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        add(Box.createHorizontalGlue(), new GridBagConstraints(2, 1, 1, 2, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));

        add(Box.createGlue(), new GridBagConstraints(0, 3, 1, 1, 0.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.VERTICAL, new Insets(0, 0, 0, 0), 0, 0));
    }

    private JPanel createTimePanel(Date startDate, Date endDate) {
        JPanel timePanel = new JPanel(new GridBagLayout());

        eTimeDisplay = TimeConvertionUtils.getCurrentETimeDisplay();

        startDateCalendar = new JfxDateCalendarField(startDate, eTimeDisplay.getTimeZone(), JfxDateCalendarField.DATE_TIME_MODE);
        endDateCalendar = new JfxDateCalendarField(endDate, eTimeDisplay.getTimeZone(), JfxDateCalendarField.DATE_TIME_MODE);

        startTimeLabel = new JfxLabel(ExportLabels.ALARMS_OUTAGE_EXPORT_STARTTIME.guiName());
        startTimeLabel.setLabelAndMnemonicFor(startDateCalendar);

        endTimeLabel = new JfxLabel(ExportLabels.ALARMS_OUTAGE_EXPORT_ENDTIME.guiName());
        endTimeLabel.setLabelAndMnemonicFor(endDateCalendar);

        automaticTimeRangeCheckbox = new JfxCheckBox(ExportLabels.ALARMS_OUTAGE_EXPORT_AUTOMATICTIMERANGE.guiName());
        
        timePanel.add(startTimeLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.LABEL_TOP_MARGIN, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        timePanel.add(startDateCalendar, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));

        timePanel.add(endTimeLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.LABEL_TOP_MARGIN, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        timePanel.add(endDateCalendar, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
        
        timePanel.add(automaticTimeRangeCheckbox, new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.DEFAULT_MARGIN, 0, JfxUtils.DEFAULT_MARGIN, 0), 0, 0));

        return timePanel;
    }

    public void setInitDate(Date initDate) {
        startDateCalendar.setDate(initDate);
    }

    public void setEndDate(Date endDate) {
        endDateCalendar.setDate(endDate);
    }

    private JPanel createSeveritiesCheckboxes() {
        JPanel severitiesPanel = new JPanel(new GridBagLayout());

        int row = 0;
        for (JfxCheckBox severityCheckbox : getSeverityCheckboxes()) {
            severitiesPanel.add(severityCheckbox, new GridBagConstraints(0, row++, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        }

        return severitiesPanel;
    }

    private JPanel createStatesCheckboxes() {
        JPanel statesPanel = new JPanel(new GridBagLayout());

        unacknowledgedCheckbox = new JfxCheckBox(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES_UNACKNOWLEDGED.guiName());
        acknowledgedCheckbox = new JfxCheckBox(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES_ACKNOWLEDGED.guiName());
        clearedCheckbox = new JfxCheckBox(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES_CLEARED.guiName());
        raisedCheckbox = new JfxCheckBox(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES_RAISED.guiName());

        unacknowledgedCheckbox.setMnemonic(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES_UNACKNOWLEDGED.guiName().getMnemonic());
        acknowledgedCheckbox.setMnemonic(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES_ACKNOWLEDGED.guiName().getMnemonic());
        clearedCheckbox.setMnemonic(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES_CLEARED.guiName().getMnemonic());
        raisedCheckbox.setMnemonic(ExportLabels.ALARMS_OUTAGE_EXPORT_STATES_RAISED.guiName().getMnemonic());

        stateCheckboxes.addAll(Arrays.asList(unacknowledgedCheckbox, acknowledgedCheckbox, clearedCheckbox, raisedCheckbox));

        statesPanel.add(unacknowledgedCheckbox, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        statesPanel.add(acknowledgedCheckbox, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        statesPanel.add(clearedCheckbox, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        statesPanel.add(raisedCheckbox, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        statesPanel.add(Box.createVerticalGlue(), new GridBagConstraints(0, 3, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.VERTICAL, new Insets(0, 0, 0, 0), 0, 0));

        return statesPanel;
    }

    protected List<JfxCheckBox> getSeverityCheckboxes() {
        int numberOfAlarmSeverity = AlarmSeverity.getSize();

        alarmSeverityList = new ArrayList<>();
        List<String> alarmSeverities = new ArrayList<>();

        for (int i = 0; i < numberOfAlarmSeverity; i++) {
            if (AlarmSeverity.fromOrdinal(i).useInAlarmCorrelation()) {
                alarmSeverityList.add(AlarmSeverity.fromOrdinal(i));
                alarmSeverities.add(getAlarmSeverityString(AlarmSeverity.fromOrdinal(i)));
            }
        }

        Map<String, String> mnemonics = GenericMnemonicsCreator.getMnemonics(alarmSeverities, "MEUADRSC");

        for (String alarmSeverity : alarmSeverities) {
            JfxCheckBox severityCheckbox = new JfxCheckBox(alarmSeverity);

            char mnemonic = mnemonics.get(alarmSeverity).charAt(0);
            if (mnemonic != ' ') {
                severityCheckbox.setMnemonic(mnemonic);
            }
            severityCheckbox.setName(alarmSeverity);
            severityCheckboxes.add(severityCheckbox);
        }

        return Collections.unmodifiableList(severityCheckboxes);
    }

    public String getAlarmSeverityString(AlarmSeverity alarmSeverity) {
        if (alarmSeverity != null) {
            return alarmSeverity.guiLabel();
        }
        return "";
    }

    public void selectAllCheckboxes() {
        for (JfxCheckBox severityCheckbox : severityCheckboxes) {
            severityCheckbox.setSelected(true);
        }

        for (JfxCheckBox stateCheckbox : stateCheckboxes) {
            stateCheckbox.setSelected(true);
        }
    }

    void selectCheckboxes(OutageAlarmSettingsDto settingsDto) {
        Map<AlarmSeverity, Boolean> settingsValueMap = new HashMap<>();
        settingsValueMap.put(AlarmSeverity.WARNING, settingsDto.getWarning());
        settingsValueMap.put(AlarmSeverity.MINOR, settingsDto.getMinor());
        settingsValueMap.put(AlarmSeverity.MAJOR, settingsDto.getMajor());
        settingsValueMap.put(AlarmSeverity.CRITICAL, settingsDto.getCritical());
        settingsValueMap.put(AlarmSeverity.INDETERMINATE, settingsDto.getIndeterminate());

        severityCheckboxes.forEach(checkBox -> 
                checkBox.setSelected(settingsValueMap.get(severity(checkBox))));

        setStateCheckbox(settingsDto);
    }

    private void setStateCheckbox(OutageAlarmSettingsDto settingsDto) {
        acknowledgedCheckbox.setSelected(settingsDto.getAcknowledged());
        clearedCheckbox.setSelected(settingsDto.getCleared());
        unacknowledgedCheckbox.setSelected(settingsDto.getUnacknowledged());
        raisedCheckbox.setSelected(settingsDto.getRaised());
    }

    boolean isAnySeverityCheckboxSelected() {
        for (JfxCheckBox severityCheckbox : severityCheckboxes) {
            if(severityCheckbox.isSelected()) {
                hideWarningIcon(fieldsValidationLabel);
                return true;
            }
        }

        showWarningIcon(fieldsValidationLabel, ExportLabels.ALARMS_OUTAGE_EXPORT_SEVERITY_STATE_WARNING.toString());
        return false;
    }

    List<AlarmSeverity> getAllSeverityCheckboxesSelected() {
        return severityCheckboxes.stream()
                .filter(AbstractButton::isSelected)
                .map(this::severity)
                .collect(toList());
    }

    Map<AlarmSeverity, Boolean> getAllSeverityCheckboxesAsMap() {
        return severityCheckboxes.stream()
                .collect(toMap(this::severity, AbstractButton::isSelected));
    }

    private AlarmSeverity severity(JfxCheckBox severityCheckbox) {
        return alarmSeverityList.get(severityCheckboxes.indexOf(severityCheckbox));
    }

    protected boolean isAnyStateCheckboxSelected() {
        if(unacknowledgedCheckbox.isSelected() || acknowledgedCheckbox.isSelected() || clearedCheckbox.isSelected()  || raisedCheckbox.isSelected()) {
            hideWarningIcon(fieldsValidationLabel);
            return true;
        }

        showWarningIcon(fieldsValidationLabel, ExportLabels.ALARMS_OUTAGE_EXPORT_SEVERITY_STATE_WARNING.toString());
        return false;
    }

    protected boolean isAnyNeSelected(boolean isNeSelected) {
        if(!isNeSelected) {
            showWarningIcon(fieldsValidationLabel, ExportLabels.ALARMS_OUTAGE_EXPORT_SEVERITY_STATE_WARNING.toString());
        }
        return isNeSelected;
    }

    protected boolean areDateFieldsValid() {
        if(endDateCalendar.getDate().before(startDateCalendar.getDate())){
            showWarningIcon(fieldsValidationLabel, ExportLabels.ALARMS_OUTAGE_EXPORT_DATE_WARNING.toString());
            return false;
        }

        hideWarningIcon(fieldsValidationLabel);
        return true;
    }

    public boolean isUnacknowledgedCheckboxSelected() {
        return unacknowledgedCheckbox.isSelected();
    }

    /**
     * Checkbox selection combination to is-acknowledged is added to the filter
     * @return
     */
    public Boolean isAcknowledged() {
        if(acknowledgedCheckbox.isSelected() && !unacknowledgedCheckbox.isSelected()) {
            return true;

        }
        if(unacknowledgedCheckbox.isSelected() && !acknowledgedCheckbox.isSelected()){
            return false;
        }
        return null;
    }

    /**
     * Checkbox selection combination to is-cleared is added to the filter
     * @return
     */
    public Boolean isCleared() {
        if(clearedCheckbox.isSelected() && !raisedCheckbox.isSelected()) {
            return true;

        }
        if(raisedCheckbox.isSelected() && !clearedCheckbox.isSelected()) {
            return false;
        }
        return null;
    }

    public boolean isRaisedSelected() {
        return raisedCheckbox.isSelected();
    }

    public boolean isUnAcknowledgedSelected() {
        return unacknowledgedCheckbox.isSelected();
    }

    public JfxCheckBox getUnacknowledgedCheckbox() {
        return unacknowledgedCheckbox;
    }

    public JfxCheckBox getRaisedCheckbox() {
        return raisedCheckbox;
    }

    public JfxCheckBox getAcknowledgedCheckbox() {
        return acknowledgedCheckbox;
    }

    public JfxCheckBox getClearedCheckbox() {
        return clearedCheckbox;
    }

    /**
     * Shows warning icon plus a label and/or tooltip messages in the specified JfxLabel field.
     */
    private static void showWarningIcon(JLabel warningLabel, String textMessage) {
        warningLabel.setIcon(ResourcesIconFactory.ICON_STATUS_WARNING_16.getImageIcon());
        warningLabel.setText(textMessage);
    }

    /**
     * Hides the icon and messages of the specified JfxLabel field.
     */
    private static void hideWarningIcon(JLabel warningLabel) {
        warningLabel.setIcon(null);
        warningLabel.setText("");
    }

    public void addItemListener(ItemListener listener) {
        for (JfxCheckBox severityCheckbox : severityCheckboxes) {
            severityCheckbox.addItemListener(listener);
        }

        for (JfxCheckBox stateCheckbox : stateCheckboxes) {
            stateCheckbox.addItemListener(listener);
        }
    }

    public void addChangeListener(ChangeListener listener) {
        startDateCalendar.addChangeListener(listener);
        endDateCalendar.addChangeListener(listener);
    }

    public void addActionListener(ActionListener listener) {
        severityCheckboxes.stream()
                .map(item -> {
                    item.addActionListener(listener);
                    return item;
                })
                .toArray();

        stateCheckboxes.stream()
                .map(item -> {
                    item.addActionListener(listener);
                    return item;
                })
                .toArray();
    }

    public JfxDateCalendarField getStartDateCalendar() {
        return startDateCalendar;
    }

    public JfxDateCalendarField getEndDateCalendar() {
        return endDateCalendar;
    }
    
    public Boolean isAutomaticTimeRangeSelected() {
        return automaticTimeRangeCheckbox.isSelected();
    }
    
    public void setAutomaticTimeRangeSelected(Boolean selected) {
        automaticTimeRangeCheckbox.setSelected(selected);
    }
     
}