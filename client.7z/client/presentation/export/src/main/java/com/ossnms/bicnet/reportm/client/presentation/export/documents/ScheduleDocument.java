/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.presentation.export.documents;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.platform.ISchedule;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.bcb.model.platform.SchedulePeriod;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.executejobs.ScheduleConfigurationExportJob;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.executejobs.ScheduleInventoryExportJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.ScheduleExportOutageJob;
import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.Optional;

public abstract class ScheduleDocument extends AbstractExportDocument {

    private IScheduleMarkable[] scheduleMarkables;
    private String reportId;

    @Override
    public void fireUpdateData(@Nonnull final OperationKey key) {
        setAttributes(getExportData());
        super.fireUpdateData(key);
    }

    public IScheduleMarkable[] getScheduleMarkables() {
        return scheduleMarkables;
    }

    public String getReportType() {
        return reportId;
    }

    public void scheduleExport(ScheduleItem scheduleItem, String reportId, IScheduleMarkable mark,
                               IExportableItem[] exportableItems, ExportLocationDto exportLocationDto) {
        FrameworkFetchJob job = new ScheduleConfigurationExportJob(this, scheduleItem, reportId, mark, exportableItems, exportLocationDto);

        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Unable to schedule connectivity data to export: {}", scheduleItem, e);
        }
    }

    public void scheduleExport(ScheduleItem scheduleItem, String reportId, IScheduleMarkable mark, ExportLocationDto exportLocationDto) {
        FrameworkFetchJob job = new ScheduleInventoryExportJob(this, scheduleItem, reportId, mark, exportLocationDto);

        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Unable to schedule connectivity data to export: {}", scheduleItem, e);
        }
    }

    public void scheduleExport(ScheduleItem scheduleItem, String reportId, IScheduleMarkable mark,
                               OutageAlarmSettingsDto outageAlarmSettings) {
        FrameworkFetchJob job = new ScheduleExportOutageJob(this, scheduleItem, reportId, mark, outageAlarmSettings);

        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Unable to schedule connectivity data to export: {}", scheduleItem, e);
        }
    }

    private void setAttributes(@Nonnull Optional<ReportDataDto> object) {
        object.map(ReportDataDto::getReportId).ifPresent(id -> reportId = id);
        ISchedule schedule = object.map(ReportDataDto::getSchedule).orElseGet(this::getNewScheduleItem);
        scheduleMarkables = new IScheduleMarkable[]{schedule.toMarkableSchedule(false)};
    }

    private ISchedule getNewScheduleItem() {
        final ScheduleItem item = new ScheduleItem();
        item.setStartTime(new Date(System.currentTimeMillis()));
        item.setPeriod(SchedulePeriod.USER_DEFINED);
        item.setUserPeriod(0);
        item.setActivation(EnableSwitch.DISABLED);
        return item;
    }

    @Override
    public boolean onHandlingRMMessageItem(@Nonnull RMMessageItem arg) throws BcbException {
        return true;
    }

}
