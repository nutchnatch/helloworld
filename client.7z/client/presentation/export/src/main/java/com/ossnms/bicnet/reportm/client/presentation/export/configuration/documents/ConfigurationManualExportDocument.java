package com.ossnms.bicnet.reportm.client.presentation.export.configuration.documents;

import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceContribution;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.executejobs.ConfigurationExportJob;
import com.ossnms.bicnet.reportm.client.presentation.export.documents.AbstractExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.FetchExportableItemsJob;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.util.Constants;

/**
 * Document class for handling Configuration Export base window
 */
public class ConfigurationManualExportDocument extends AbstractExportDocument {

    private BiCNetPluginExternalCommunicationServiceContribution ecsContribution;

    /**
     * Execute Configuration Export Data operation
     */
    public void configurationExportData(IExportableItem[] exportableItems, TransferSettings transferSettings) {
        FrameworkFetchJob fetchJob = new ConfigurationExportJob(this, exportableItems, transferSettings);
        try {
            executeFetchJob(fetchJob);
        } catch (FrameworkException e) {
            getLogger().error("Error executing InventoryExportJob.", e);
        }
    }

    @Override public void fetchOtherData() {
        FetchExportableItemsJob fetchExportableItemsJob = new FetchExportableItemsJob(this);
        try {
            executeFetchJob(fetchExportableItemsJob);
        } catch (FrameworkException e) {
            getLogger().error("Error executing FetchExportableItemsJob", e);
        }
    }

    public void setEcsContribution(BiCNetPluginExternalCommunicationServiceContribution contribution) {
        ecsContribution = contribution;
    }

    public BiCNetPluginExternalCommunicationServiceContribution getEcsContribution() {
        return ecsContribution;
    }

    @Override
    protected String getReportId() {
        return Constants.CONFIGURATION_EXPORT_REPORT;
    }
}
