/*
 * Copyright (C) Coriant - 2014
 * 
 * The reproduction, transmission or use of this document or its contents is not
 * permitted without express written authorization. All rights, including rights
 * created by patent grant or registration of a utility model or design, are
 * reserved. Modifications made to this document are restricted to authorized
 * personnel only. Technical specifications and features are binding only when
 * specifically and expressly agreed upon in a written contract.
 */

package com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs;

import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
//import com.ossnms.bicnet.reportm.client.api.jobs.AbstractPrivateFacadeFetchJob;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;
import com.ossnms.bicnet.reportm.client.api.jobs.AbstractPrivateFacadeFetchJob;

import javax.annotation.Nonnull;

/**
 * Middle class used to specify that all fetch jobs of this kind will be using the IReportManagerPrivateFacade
 * and to specify the type of returned object to one of the Facade methods
 */
public abstract class RMFetchJob<JobReturn> extends AbstractPrivateFacadeFetchJob<JobReturn, IReportManagerPrivateFacade> {

	/**
	 * Creates a new Fetch job to request data throught IReportManagerPrivateFacade
	 *
	 * @param id
	 * 		The id of this job. It can't be null
	 * @param name
	 * 		The name of this job. It can't be null
	 * @param additionalInfo
	 * 		Any additional information of the job. It could be null
	 * @param jobOwner The owner of this job
	 */
	protected RMFetchJob(@Nonnull final String id, @Nonnull final String name, @Nonnull final String additionalInfo, @Nonnull final IFrameworkDocument jobOwner) {
		super(IReportManagerPrivateFacade.class, id, name, additionalInfo, jobOwner);
	}
}
