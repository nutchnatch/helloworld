package com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs;

import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportm.client.presentation.export.jobs.IExportJobHandler;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;

public class ExportDataFetchJob extends RMFetchJob<ReportDataDto>{

    /**
     * Job instance counter
     */
    private static final AtomicInteger jobInstanceCounter = new AtomicInteger(0);

    /**
     * Process id
     */
    private static final String OPERATION_ID = ExportDataFetchJob.class.getSimpleName();

    /**
     * Process name
     */
    private static final String OPERATION_NAME = "Load inventory export data";
    private final String reportId;

    public ExportDataFetchJob(@Nonnull IFrameworkDocument ownerDocument, String reportId) {
        super(OPERATION_ID + "#" + jobInstanceCounter.getAndIncrement(), OPERATION_NAME, "", ownerDocument);
        this.reportId = reportId;
    }

    /**
     * (non-Javadoc)
     * see com.ossnms.bicnet.reportm.client.presentation.export.executejobs.RMFetchJob<ReportDataDto>
     */
    @Override
    public ReportDataDto invokeMethodFromFacade(@Nonnull IReportManagerPrivateFacade iPrivateFacade) throws BcbException {
        getLogger().debug(OPERATION_NAME);
        return iPrivateFacade.getReportData(getSessionContext(), reportId);
    }

    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        IExportJobHandler jobHandler = (IExportJobHandler) visitor;
        return jobHandler.handle(this, result);
    }
}