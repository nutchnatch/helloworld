package com.ossnms.bicnet.reportm.client.presentation.export.outage.documents;

import com.ossnms.bicnet.reportm.client.presentation.export.documents.AbstractExportDocument;
import com.ossnms.bicnet.reportmanager.util.Constants;

/**
 * Document class for handling Configuration Export base window
 */
public class OutageExportDocument extends AbstractExportDocument {

    @Override
    protected String getReportId() {
        return Constants.ALARMS_OUTAGE_REPORT;
    }

    @Override
    public void fetchOtherData() {

    }

}
