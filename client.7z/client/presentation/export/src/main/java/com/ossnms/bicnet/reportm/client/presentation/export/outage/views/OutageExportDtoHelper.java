package com.ossnms.bicnet.reportm.client.presentation.export.outage.views;

import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmNeDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.CRITICAL;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.INDETERMINATE;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MAJOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.MINOR;
import static com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity.WARNING;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableOutageAlarmNeDto.ne;
import static com.ossnms.bicnet.reportmanager.dto.ImmutableOutageAlarmSettingsDto.builder;
import static java.util.stream.Collectors.toList;

final class OutageExportDtoHelper {

    static OutageAlarmSettingsDto getAlarmSettingsDto(OutageExportSettingsPanel settingsPanel, OutageExportableItemsModel exportableItemsModel) {
        Map<AlarmSeverity, Boolean> severityCheckboxes = settingsPanel.getAllSeverityCheckboxesAsMap();
        return builder()
                .acknowledged(settingsPanel.getAcknowledgedCheckbox().isSelected())
                .unacknowledged(settingsPanel.getUnacknowledgedCheckbox().isSelected())
                .cleared(settingsPanel.getClearedCheckbox().isSelected())
                .raised(settingsPanel.getRaisedCheckbox().isSelected())

                .warning(severityCheckboxes.get(WARNING))
                .minor(severityCheckboxes.get(MINOR))
                .major(severityCheckboxes.get(MAJOR))
                .critical(severityCheckboxes.get(CRITICAL))
                .indeterminate(severityCheckboxes.get(INDETERMINATE))

                .startDate(settingsPanel.getStartDateCalendar().getDate().getTime())
                .endDate(settingsPanel.getEndDateCalendar().getDate().getTime())
                .automaticTimeRange(settingsPanel.isAutomaticTimeRangeSelected())
                .nes(getSelectedNes(exportableItemsModel))
                .build();
    }

    private static List<OutageAlarmNeDto> getSelectedNes(OutageExportableItemsModel exportableItemsModel) {
        return Arrays.stream(exportableItemsModel.getAllSelectedNodes())
                .map(item -> ne(item.getObjectId(), item.getName()))
                .collect(toList());
    }
}
