package com.ossnms.bicnet.reportm.client.presentation.export.outage.commands;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginViewFactory;
import com.ossnms.bicnet.reportm.client.api.command.AbstractOpenCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.documents.OutageExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.views.OutageExportView;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

public class OutageExportCommand extends AbstractOpenCommand {

    private static final long serialVersionUID = 1L;

    public OutageExportCommand() {
        super(ExportLabels.ALARMS_OUTAGE_EXPORT_MENU.toString(), ExportLabels.ALARMS_OUTAGE_EXPORT_DESCRIPTION.toString());

        final FrameworkCommandID commandID = new FrameworkCommandID(getClass().getName());
        setCommandID(commandID);
        setToolIcon(IconFactory.getIconWithOverlay(ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16, ActionType.ALARM));
        setActionListener(new FrameworkCommandHandler(commandID));
        setSecurityId(Policies.ALARMS_OUTAGE_DATA.toString());
    }

    @Override
    public boolean execute(IManagedObject[] selectedObjects) {
        FrameworkPluginViewFactory.createView(OutageExportDocument.class, OutageExportView.class, ExportLabels.ALARMS_OUTAGE_EXPORT_TITLE.toString(), 
                selectedObjects, RMPluginHelperImpl.getInstance(), this, BiCNetPluginFrameType.INTERNAL);
        return true;
    }

    @Override
    public IFrameworkCommand clone(IManagedObject[] arSelectedObjects) {
        return new OutageExportCommand();
    }
}