package com.ossnms.bicnet.reportm.client.presentation.export.views;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.framework.client.command.FrameworkCommitButton;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkCancelCommand;
import com.ossnms.bicnet.framework.client.utils.FrameworkOkCommand;
import com.ossnms.bicnet.reportm.client.api.ui.utils.KeyBindings;
import com.ossnms.bicnet.reportm.client.api.views.AbstractView;
import com.ossnms.bicnet.reportm.client.presentation.export.views.commands.OkCommand;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractExportView extends AbstractView {
    private static final long serialVersionUID = 8488741902640796215L;

    /**
     * The main panel
     */
    private final JPanel mainComponentPanel = new JPanel(new GridBagLayout());
    
    private FrameworkOkCommand okCommand = new OkCommand(this);

    public AbstractExportView(final String id, final String title, final FrameworkDocument doc, final int helpId) throws BcbException {
        super(id, title, doc, false, helpId);
    }

    @Override
    public void eventOpened() {
        super.eventOpened();
        setActivityIndicatorVisible(true);
    }

    
    @Override
    protected List<FrameworkCommitButton> getCommitActions() {
        final List<FrameworkCommitButton> buttons = new ArrayList<>();

        buttons.add(okCommand);
        buttons.add(new FrameworkCancelCommand(this));

        return buttons;
    }

    @Override
    protected void initKeyBindings() {
        final Action closeAction = new AbstractAction() {

            private static final long serialVersionUID = 7104214640755907547L;

            @Override
            public void actionPerformed(final ActionEvent e) {
                if (canClose()) {
                    getFrame().closeFrame();
                }
            }
        };

        KeyBindings.installActionOnKey(this, "CloseOnKey", closeAction, KeyEvent.VK_ESCAPE);
    }

    /**
     * Update command actions
     */
    public void updateActions() {
        okCommand.updateAction();
    }

    protected abstract void initGui() throws BcbException;

    protected abstract void initGuiNames();

    public abstract void callExportJob(ScheduleItem scheduleItem, IScheduleMarkable mark);

    /**
     * Check if there was a change from the original data in form
     *
     * @return {@code true} if form data has changed, {@code false} otherwise
     */
    public boolean isFormDirty() {
        return false;
    }

    @Override
    protected JComponent getMainComponent() {
        return mainComponentPanel;
    }

    /**
     * Close window
     */
    public void closeWindow() {
        close();
    }
}
