package com.ossnms.bicnet.reportm.client.presentation.export.configuration.executejobs;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.RMFetchJob;
import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;

public class ScheduleConfigurationExportJob extends RMFetchJob<Boolean> {

    /**
     * Job instance counter
     */
    private static final AtomicInteger jobInstanceCounter = new AtomicInteger(0);
    /**
     * Process id
     */
    private static final String OPERATION_ID = ScheduleConfigurationExportJob.class.getSimpleName();
    /**
     * Process name
     */
    private static final String OPERATION_NAME = "Schedule data to export";

    private final ScheduleItem scheduleItem;

    private final String reportId;

    private Collection<String> messages;

    private final IScheduleMarkable mark;
    private IExportableItem[] exportableItems;
    private final ExportLocationDto exportLocationDto;



    /**
     * The class constructor
     * @param jobOwner        the document owner
     * @param scheduleItem    the schedule item to schedule
     *@param exportableItems
     * @param exportLocationDto
     */
    public ScheduleConfigurationExportJob(@Nonnull final IFrameworkDocument jobOwner, @Nonnull final ScheduleItem scheduleItem,
                                          @Nonnull String reportId, IScheduleMarkable mark, IExportableItem[] exportableItems,
                                          ExportLocationDto exportLocationDto) {
        super(OPERATION_ID + "#" + jobInstanceCounter.getAndIncrement(), OPERATION_NAME, "", jobOwner);

        this.scheduleItem = scheduleItem;
        this.reportId = reportId;
        this.mark = mark;
        this.exportableItems = exportableItems.clone();
        this.exportLocationDto = exportLocationDto;
    }

    
    /**
     * (non-Javadoc)
     * see com.ossnms.bicnet.reportm.client.presentation.export.executejobs.RMFetchJob<ReportDataDto>
     */
    @Override
    public Boolean invokeMethodFromFacade(@Nonnull final IReportManagerPrivateFacade iPrivateFacade) throws BcbException {
        getLogger().debug(OPERATION_NAME + ": {}", scheduleItem);
        iPrivateFacade.scheduleConfigurationReport(getSessionContext(), reportId, scheduleItem, mark, exportableItems, exportLocationDto);
        return true;
    }

    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        return OperationKey.NOTHING_TO_DO;
    }
}
