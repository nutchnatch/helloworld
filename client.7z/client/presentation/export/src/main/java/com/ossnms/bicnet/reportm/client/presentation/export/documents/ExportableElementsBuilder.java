package com.ossnms.bicnet.reportm.client.presentation.export.documents;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.dcn.readers.ChannelReaderBuilder;
import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.dcn.readers.DcnItemBuilder;
import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.dcn.readers.MediatorReaderBuilder;
import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.dcn.readers.NEReaderBuilder;
import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.topo.readers.PTReaderBuilder;
import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.topo.readers.TCReaderBuilder;
import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.topo.readers.TSReaderBuilder;
import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.topo.readers.TopoItemBuilder;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmNeDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.outage.alarms.NeExportItem;

import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;

import static java.util.stream.Collectors.toList;

public final class ExportableElementsBuilder {

    private ExportableElementsBuilder() {
    }

    public static List<IExportableItem> convertDtos(Iterable<ExportableItemDto> exportableItemDtos) {
        return StreamSupport.stream(exportableItemDtos.spliterator(), false)
                .map(ExportableElementsBuilder::buildItems)
                .filter(Optional::isPresent).map(Optional::get)
                .collect(toList());
    }

    public static List<IExportableItem> convertDcnDtos(Iterable<DcnObject> exportableItemDtos) {
        return StreamSupport.stream(exportableItemDtos.spliterator(), false)
                .map(ExportableElementsBuilder::buildDcnItems)
                .filter(Optional::isPresent).map(Optional::get)
                .collect(toList());
    }

    public static List<IExportableItem> convertOutageNeDtos(List<OutageAlarmNeDto> neDtos) {
        return StreamSupport.stream(neDtos.spliterator(), false)
                .map(ExportableElementsBuilder::buildOutagealarmNeItems)
                .filter(Optional::isPresent).map(Optional::get)
                .collect(toList());
    }

    private static Iterable<IExportableReader> getTopoReaders(Iterable<ExportableReaderDto> readers) {
        return StreamSupport.stream(readers.spliterator(), false)
                .map(ExportableElementsBuilder::buildTopoReaders)
                .filter(Optional::isPresent).map(Optional::get)
                .collect(toList());
    }

    private static Optional<IExportableItem> buildItems(ExportableItemDto iExportableDto) {
        DcnItemBuilder dcnItemBuilder = new DcnItemBuilder();
        TopoItemBuilder topoItemBuilder = new TopoItemBuilder();

        ExportableReaderDto readerDto = iExportableDto.getReaders().iterator().next();

        if (dcnItemBuilder.acceptItem(iExportableDto)) {
            return Optional.of(dcnItemBuilder.buildItem(buildDcnReaders(readerDto), iExportableDto));
        }
        if (topoItemBuilder.acceptItem(iExportableDto)) {
            return Optional.of(topoItemBuilder.buildItem(getTopoReaders(iExportableDto.getReaders()), iExportableDto));
        }
        return Optional.empty();
    }

    private static Optional<IExportableItem> buildDcnItems(DcnObject dcnDto) {
        return dcnDto.neId()
                .map(id -> {
                    NeExportItem neExportItem = new NeExportItem();
                    neExportItem.setName(dcnDto.name());
                    neExportItem.setObjectId(id);
                    return neExportItem;
                });
    }

    private static Optional<IExportableItem> buildOutagealarmNeItems(OutageAlarmNeDto neDto) {
        NeExportItem neExportItem = null;
        if (neDto.getNeId() > 0) {
            neExportItem = new NeExportItem();
            neExportItem.setName(neDto.getNeName());
            neExportItem.setObjectId(neDto.getNeId());
            neExportItem.setSelection(1);
        }
        return Optional.ofNullable(neExportItem);
    }

    private static Optional<IExportableReader> buildTopoReaders(ExportableReaderDto iExportableDto) {
        TSReaderBuilder tsReaderBuilder = new TSReaderBuilder();
        TCReaderBuilder tcReaderBuilder = new TCReaderBuilder();
        PTReaderBuilder ptReaderBuilder = new PTReaderBuilder();

        if (tsReaderBuilder.acceptReader(iExportableDto)) {
            return Optional.of(tsReaderBuilder.buildReader(iExportableDto));
        }
        if (tcReaderBuilder.acceptReader(iExportableDto)) {
            return Optional.of(tcReaderBuilder.buildReader(iExportableDto));
        }
        if (ptReaderBuilder.acceptReader(iExportableDto)) {
            return Optional.of(ptReaderBuilder.buildReader(iExportableDto));
        }
        return Optional.empty();
    }

    private static Iterable<IExportableReader> buildDcnReaders(ExportableReaderDto iExportableDto) {
        Builder<IExportableReader> builder = ImmutableList.builder();

        MediatorReaderBuilder mediatorReaderBuilder = new MediatorReaderBuilder();
        ChannelReaderBuilder channelReaderBuilder = new ChannelReaderBuilder();
        NEReaderBuilder neReaderBuilder = new NEReaderBuilder();

        builder.add(mediatorReaderBuilder.buildReader(iExportableDto));
        builder.add(channelReaderBuilder.buildReader(iExportableDto));
        builder.add(neReaderBuilder.buildReader(iExportableDto));

        return builder.build();
    }
}