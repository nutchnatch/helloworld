package com.ossnms.bicnet.reportm.client.presentation.export.jobs;

import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.executejobs.ConfigurationExportJob;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.ExportDataFetchJob;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.FetchExportLocationDataJob;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.FetchExportableItemsJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchDtoDataJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchFilterJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchNesJob;
import com.ossnms.bicnet.reportm.client.presentation.settings.system.SystemSettingsFetchJob;

public interface IExportJobHandler extends IJobVisitor {

    OperationKey handle(ConfigurationExportJob configurationExportJob, Object result);

    OperationKey handle(OutageFetchFilterJob outageFetchFilterJob, Object result);

    OperationKey handle(FetchExportableItemsJob fetchExportableItemsJob, Object result);

    OperationKey handle(SystemSettingsFetchJob systemSettingsFetchJob, Object result);

    OperationKey handle(OutageFetchNesJob outageFetchNesJob, Object result);

    OperationKey handle(ExportDataFetchJob exportDataFetchJob, Object result);

    OperationKey handle(OutageFetchDtoDataJob outageFetchDtoDataJob, Object result);

    OperationKey handle(FetchExportLocationDataJob fetchExportLocationDataJob, Object result);
}
