package com.ossnms.bicnet.reportm.client.presentation.export.inventory.commands;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginViewFactory;
import com.ossnms.bicnet.reportm.client.api.command.AbstractOpenCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.documents.InventoryExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.views.InventoryExportManagerView;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.PluginLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

/**
 * Command responsible for General Export Window
 */
public class InventoryExportCommand extends AbstractOpenCommand{

    public InventoryExportCommand(){
        super(PluginLabels.PLUGIN_NAME_MENU.toString(), ExportLabels.EXPORT_OPEN_DESCRIPTION.toString());

        final FrameworkCommandID commandID = new FrameworkCommandID(InventoryExportCommand.class.getName());
        setCommandID(commandID);
        setToolIcon(ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16);
        setActionListener(new FrameworkCommandHandler(commandID));
        setSecurityId(Policies.EXPORT_INVENTORY_DATA.toString());
    }

    @Override
    public boolean execute(IManagedObject[] selectedObjects) {
        FrameworkPluginViewFactory.createView(InventoryExportDocument.class, InventoryExportManagerView.class, ExportLabels.EXPORT_TITLE.toString(),
                selectedObjects, RMPluginHelperImpl.getInstance(), this, BiCNetPluginFrameType.INTERNAL);
        return false;
    }

    @Override
    public IFrameworkCommand clone(IManagedObject[] iManagedObjects) {
        return new InventoryExportCommand();
    }
}