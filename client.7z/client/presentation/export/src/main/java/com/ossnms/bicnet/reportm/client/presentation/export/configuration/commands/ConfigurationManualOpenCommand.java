/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands;

import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceContribution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandRegistrar;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginViewFactory;
import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.documents.ConfigurationManualExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.views.ManualExportableSelectionView;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

/**
 * Responsible for Export Window
 */
public class ConfigurationManualOpenCommand extends FrameworkCommand {
    private static final long serialVersionUID = 9012873112654855487L;
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationManualOpenCommand.class);
    public static final FrameworkCommandID UI_ID = new FrameworkCommandID(ConfigurationManualOpenCommand.class.getName());
    private BiCNetPluginExternalCommunicationServiceContribution ecsContribution;

    static {
        ConfigurationManualOpenCommand cmd = new ConfigurationManualOpenCommand();
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(cmd);
    }
    
    public ConfigurationManualOpenCommand() {
        setCmdDetails(ExportLabels.CONFIGURATION_EXPORT_MANUAL_BUTTON.toString(),
                ExportLabels.CONFIGURATION_EXPORT_MANUAL_BUTTON.toString(), null, null,
                ExportLabels.CONFIGURATION_EXPORT_MANUAL_BUTTON_TOOLTIP.toString(),
                ExportLabels.CONFIGURATION_EXPORT_MANUAL_BUTTON_TOOLTIP.toString(), ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16);

        setCommandID(UI_ID);
        setActionListener(new FrameworkCommandHandler(UI_ID));
        setPluginHelper(RMPluginHelperImpl.getInstance());
        setSecurityId(Policies.EXPORT_CONFIGURATION_DATA.toString());
    }

    @Override
    public boolean execute(IManagedObject[] selectedObjects) {
        LOGGER.debug("Perform Configuration Export");

        ManualExportableSelectionView view = FrameworkPluginViewFactory.createInvisibleView(ConfigurationManualExportDocument.class, ManualExportableSelectionView.class,
                ExportLabels.CONFIGURATION_MANUAL_EXPORT_TITLE.toString(), selectedObjects, RMPluginHelperImpl.getInstance(),
                this, BiCNetPluginFrameType.INTERNAL);
        view.getFrameworkDocument().setEcsContribution(getECSContribution());
        view.getFrame().showFrame();

        return true;
    }
    
    @Override
    public boolean isEnabled(IManagedObject[] arSelectedObjects) {
        return getPluginHelper().checkPermissions(getSecurityId());
    }

    @Override
    public IFrameworkCommand clone(IManagedObject[] selectedObjects) {
        return new ConfigurationManualOpenCommand();
    }
    
    /**
     * Brings this view to the front
     * @see com.ossnms.bicnet.framework.client.command.FrameworkCommand#bringViewToFront(com.ossnms.bicnet.bcb.plugin.BiCNetPluginView)
     */
    @Override
    public void bringViewToFront(final BiCNetPluginView view) {
        if (!(view instanceof FrameworkView)) {
            return;
        }
        ((FrameworkView) view).bringToFront();
    }

    public void setECSContribution(BiCNetPluginExternalCommunicationServiceContribution ecsContribution) {
        this.ecsContribution = ecsContribution;
    }

    public BiCNetPluginExternalCommunicationServiceContribution getECSContribution() {
        return ecsContribution;
    }
}