package com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.topo.readers;

import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.ExportableElementBuilder;
import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.topo.TCExportReader;

public class TCReaderBuilder implements ExportableElementBuilder<IExportableReader> {

    @Override
    public boolean acceptReader(ExportableReaderDto readerDto) {
        return readerDto.getReaderType() == ExportableReaderType.TOPOLOGICAL_CONTAINER;
    }

    @Override
    public IExportableReader buildItem(Iterable<IExportableReader> readers, ExportableItemDto itemDto) {
        return null;
    }

    @Override
    public IExportableReader buildReader(ExportableReaderDto readerDto) {
        TCExportReader tcExportReader = new TCExportReader();
        tcExportReader.setSelection(readerDto.getSelection());
        return tcExportReader;
    }

    @Override
    public boolean acceptItem(ExportableItemDto itemDto) {
        return false;
    }
}
