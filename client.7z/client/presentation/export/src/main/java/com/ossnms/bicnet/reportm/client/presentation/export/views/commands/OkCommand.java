package com.ossnms.bicnet.reportm.client.presentation.export.views.commands;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.framework.client.utils.FrameworkOkCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.export.views.AbstractExportView;
import com.ossnms.bicnet.reportm.client.presentation.export.views.ScheduleView;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;

public class OkCommand extends FrameworkOkCommand {

    private static final long serialVersionUID = 6946483196523917094L;

    public OkCommand(AbstractExportView view) {
        setView(view);
        setPluginHelper(RMPluginHelperImpl.getInstance());
        setSecurityId(Policies.EXPORT_INVENTORY_DATA.toString());
    }

    @Override
    public boolean execute(IManagedObject[] arSelectedObjects) {
        AbstractExportView view = getView();

        if (view instanceof ScheduleView) {
            IScheduleMarkable mark = ((ScheduleView) view).getScheduleItem();
            String reportId = ((ScheduleView) view).getReportId();

            ScheduleItem scheduleItem = new ScheduleItem(mark.getOptionalFacets(), mark.getId(), mark.getStartTime(),
                    mark.getPeriod(), mark.getUserPeriod(), mark.getRepetition(), mark.getEndTime(), mark.getOccurrencesUntilEnd(),
                    mark.getActionType(), mark.getDestination(), mark.getActionParameter(), mark.getWeeklyDays(), mark.getMonthlyDays(),
                    mark.getActivation(), mark.getExecutionCount());



            view.callExportJob(scheduleItem, mark);
        }

        view.closeWindow();

        return true;
    }

    @Override
    public boolean isEnabled(IManagedObject[] selectedObjects) {
        return super.isEnabled(selectedObjects) && getView().isFormDirty();
    }

    @Override
    public AbstractExportView getView() {
        return (AbstractExportView) super.getView();
    }
}