package com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginViewFactory;
import com.ossnms.bicnet.reportm.client.api.command.AbstractOpenCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.documents.ConfigurationExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.views.ConfigurationExportView;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

/**
 * Command for configuration export window
 */
public class ConfigurationExportCommand extends AbstractOpenCommand {

    public ConfigurationExportCommand() {
        super(ExportLabels.CONFIGURATION_EXPORT_MENU.toString(), ExportLabels.CONFIGURATION_EXPORT_DESCRIPTION.toString());

        final FrameworkCommandID commandID = new FrameworkCommandID(getClass().getName());
        setCommandID(commandID);
        setToolIcon(ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16);
        setActionListener(new FrameworkCommandHandler(commandID));
        setSecurityId(Policies.EXPORT_CONFIGURATION_DATA.toString());
        setComponentName("ConfigurationExport");
    }

    @Override
    public boolean execute(IManagedObject[] selectedObjects) {
        FrameworkPluginViewFactory.createView(ConfigurationExportDocument.class, ConfigurationExportView.class, ExportLabels.CONFIGURATION_EXPORT_TITLE.toString(),
                selectedObjects, RMPluginHelperImpl.getInstance(), this, BiCNetPluginFrameType.INTERNAL);
        return true;
    }

    @Override
    public IFrameworkCommand clone(IManagedObject[] iManagedObjects) {
        return new ConfigurationExportCommand();
    }
}
