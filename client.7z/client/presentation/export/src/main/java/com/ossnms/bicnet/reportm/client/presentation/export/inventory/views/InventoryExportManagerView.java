package com.ossnms.bicnet.reportm.client.presentation.export.inventory.views;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.Nonnull;
import javax.swing.*;

import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceContribution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.framework.client.command.FrameworkButtonCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.commands.InventoryExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.commands.InventoryScheduleOpenCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.documents.InventoryExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.views.ExportStateView;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.tools.jfx.components.JfxButton;

public class InventoryExportManagerView extends ExportStateView {
    private static final long serialVersionUID = -1478291013335509146L;
    
    private static final Logger LOGGER = LoggerFactory.getLogger(InventoryExportManagerView.class);
    private static final String VIEW_ID = InventoryExportManagerView.class.getName();
    private static final int WIDTH_PANEL = 400;
    private static final int HEIGHT_PANEL = 285;

    private final StartCommand startCommand;
    private final InventoryScheduleOpenCommand inventoryScheduleCommand;
    private JfxButton manualButton;
    private JfxButton scheduleButton;

    public InventoryExportManagerView(@Nonnull String title, @Nonnull InventoryExportDocument doc) throws BcbException {
        super(VIEW_ID, title, doc, false, HelpIds.HID_INVENTORY_EXPORT_DATA);
        doc.setExternalCommunicationService();
        addECSContributionPanel(doc.getEcsContribution());
        startCommand = new StartCommand();
        manualButton = new JfxButton(startCommand);
        inventoryScheduleCommand = new InventoryScheduleOpenCommand(getFrameworkDocument().getPluginHelper());
        scheduleButton = new JfxButton(inventoryScheduleCommand);
        initControls();
        startCommand.updateAction();
        inventoryScheduleCommand.updateAction();
        setButtonsName();
    }

    private void addECSContributionPanel(BiCNetPluginExternalCommunicationServiceContribution contribution) throws BcbException {
        getMainComponent().add(getECSContributionPanel(contribution),
                new GridBagConstraints(0, 2, 2, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        setPreferredSize(new Dimension(WIDTH_PANEL, HEIGHT_PANEL));
    }

    private void setButtonsName(){
        manualButton.setName("Manual");
        scheduleButton.setName("Schedule");
    }

    private void inventoryExportData(TransferSettings transferSettings) {
        getFrameworkDocument().inventoryExportData(transferSettings);
    }

    @Override
    protected InventoryExportDocument getFrameworkDocument() {
        return (InventoryExportDocument) super.getFrameworkDocument();
    }

    @Override
    protected FrameworkCommand getManualCommand() {
        return startCommand;
    }

    @Override
    protected String getExportPath(SystemSettings systemSettings) {
        return systemSettings.inventory().exportPath();
    }

    @Override
    protected List<JfxButton> provideButtons() {
        List<JfxButton> buttonList = new ArrayList<>();
        buttonList.add(manualButton);
        buttonList.add(scheduleButton);
        return buttonList;
    }

    @Override
    public String getCommandClassName() {
        return InventoryExportCommand.class.getName();
    }

    @Override
    public JTable getDataToPrint() {
        return new JTable();
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {

    }

    /**
     * Get the ECS Contribution Panel
     * @return
     */
    private JComponent getECSContributionPanel(BiCNetPluginExternalCommunicationServiceContribution contribution) throws BcbException {
        if (contribution == null) {
            throw new BcbException("Unable to get pluginExternalCommunicationService");
        }

        return contribution.getComponent();
    }

    private class StartCommand extends FrameworkButtonCommand {
        private static final long serialVersionUID = -3109821306053410799L;

        public StartCommand() {
            setCmdDetails(ExportLabels.IDS_EXPORT_START_BUTTON.toString(),
                    ExportLabels.IDS_EXPORT_START_BUTTON.toString(), null, null,
                    ExportLabels.INVENTORY_START_EXPORT_TOOLTIP.toString(),
                    ExportLabels.INVENTORY_START_EXPORT_TOOLTIP.toString(), null);
            setPluginHelper(getFrameworkDocument().getPluginHelper());
            setSecurityId(Policies.EXPORT_INVENTORY_DATA.toString());
        }

        @Override
        public boolean execute(IManagedObject[] iManagedObjects) {
            LOGGER.debug("Perform Inventory Export");
            inventoryExportData(getFrameworkDocument().getEcsContribution().getTransferSettings());
            return true;
        }

        @Override
        public boolean isEnabled(IManagedObject[] arSelectedObjects) {
            return getPluginHelper().checkPermissions(getSecurityId());
        }
    }
}
