package com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.dcn.readers;

import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.ExportableElementBuilder;
import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableItemType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.dcn.DcnExportItem;

public class DcnItemBuilder implements ExportableElementBuilder<IExportableItem> {

    @Override
    public boolean acceptReader(ExportableReaderDto readerDto) {
        return false;
    }

    @Override
    public IExportableItem buildItem(Iterable<IExportableReader> readers, ExportableItemDto itemDto) {
        DcnExportItem dcnExportItem = new DcnExportItem();
        dcnExportItem.setReaders(readers);
        dcnExportItem.setSelection(itemDto.getSelection());
        return dcnExportItem;
    }

    @Override
    public IExportableItem buildReader(ExportableReaderDto readerDto) {
        return null;
    }

    @Override
    public boolean acceptItem(ExportableItemDto itemDto) {
        return itemDto.getExportableItemType() == ExportableItemType.DCN_MANAGEMENT;
    }
}
