package com.ossnms.bicnet.reportm.client.presentation.export.configuration.views;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceContribution;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceProvider;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands.ConfigurationExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands.ConfigurationManualOpenCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands.ConfigurationScheduleOpenCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.documents.ConfigurationExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.views.ExportStateView;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.tools.jfx.components.JfxButton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

public class ConfigurationExportView extends ExportStateView {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationExportView.class);
    private static final boolean NOT_RESIZABLE = false;
    private static final String VIEW_ID = ConfigurationExportView.class.getName();
    private static final int WIDTH_PANEL = 400;
    private static final int HEIGHT_PANEL = 285;

    private BiCNetPluginExternalCommunicationServiceContribution ecsContribution;

    private final ConfigurationManualOpenCommand manualCommand = new ConfigurationManualOpenCommand();
    private final ConfigurationScheduleOpenCommand scheduleCommand = new ConfigurationScheduleOpenCommand();
    private final JfxButton manualButton = new JfxButton(manualCommand);
    private final JfxButton scheduleButton = new JfxButton(scheduleCommand);

    public ConfigurationExportView(@Nonnull String title, @Nonnull ConfigurationExportDocument doc) throws BcbException {
        super(VIEW_ID, title, doc, NOT_RESIZABLE, HelpIds.HID_CONFIGURATION_EXPORT);
        addECSContributionPanel();
        initControls();
        manualCommand.updateAction();
        scheduleCommand.updateAction();
        setButtonsName();
    }

    private void setButtonsName(){
        manualButton.setName("Manual");

        scheduleButton.setName("Schedule");
    }

    private void addECSContributionPanel() throws BcbException {
        getMainComponent().add(getECSContributionPanel(),
                new GridBagConstraints(0, 2, 2, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        super.setPreferredSize(new Dimension(WIDTH_PANEL, HEIGHT_PANEL));

        manualCommand.setECSContribution(ecsContribution);
    }

    @Override
    protected List<JfxButton> provideButtons() {
        List<JfxButton> buttonList = new ArrayList<>();
        buttonList.add(manualButton);
        buttonList.add(scheduleButton);
        return buttonList;
    }

    @Override
    protected FrameworkCommand getManualCommand() {
        return manualCommand;
    }

    @Override
    protected String getExportPath(SystemSettings systemSettings) {
        return systemSettings.configurationExport().exportPath();
    }

    @Override
    public String getCommandClassName() {
        return ConfigurationExportCommand.class.getName();
    }

    @Override
    public JTable getDataToPrint() {
        return new JTable();
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {

    }

    @Override
    protected ConfigurationExportDocument getFrameworkDocument() {
        return (ConfigurationExportDocument) super.getFrameworkDocument();
    }

    /**
     * Get the ECS Contribution Panel
     * @return
     */
    private JComponent getECSContributionPanel() throws BcbException {
        BiCNetPluginExternalCommunicationServiceProvider pluginExternalCommunicationService = RMPluginHelperImpl.getInstance().getPluginExternalCommunicationService();

        if (pluginExternalCommunicationService == null) {
            throw new BcbException("Unable to get pluginExternalCommunicationService");
        }

        ecsContribution = pluginExternalCommunicationService.getContribution();

        return ecsContribution.getComponent();
    }
}