package com.ossnms.bicnet.reportm.client.presentation.export.configuration.views;

import com.ossnms.bicnet.reportm.client.api.models.AbstractExportableItemsModel;
import com.ossnms.bicnet.reportm.client.api.models.ExportItemNode;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.util.Constants;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.StreamSupport;

import static java.util.stream.Collectors.toList;

public class ExportableItemsModel extends AbstractExportableItemsModel {

    private static final long serialVersionUID = -6734518986290142119L;

    @Override
    public List<ExportItemNode> collectTreeItems(Iterable<IExportableItem> exportableItems) {
        return StreamSupport.stream(exportableItems.spliterator(), false)
                .filter(iExportableItem -> iExportableItem.getReaders() != null)
                .map(ExportItemNode::new)
                .peek(node -> {
                    if (node.getItem().getName().equals(Constants.DCN_MANAGEMENT)) {
                        getRoot().add(node);
                        getSelectionModel().addSelectionPath(getTreePath(node));
                    } else {
                        addChildItems(node);
                    }
                })
                .filter(node -> node.getChildCount() > 0)
                .peek(node -> {
                    getRoot().add(node);
                    getSelectionModel().removeSelectionPath(getTreePath(node));
                })
                .collect(toList());
    }

    @Override
    public IExportableItem[] getAllSelectedNodes() {
        ExportItemNode root = getRoot();
        Predicate<ExportItemNode> isCollectible = node -> !node.isLeaf() || node.isLeaf() && node.getItem().getName().equals(Constants.DCN_MANAGEMENT);
        Predicate<ExportItemNode> notRoot = node -> !Objects.equals(root, node);

        return flattenTreeOf(root)
                .filter(isCollectible.and(this::checkSelected).and(notRoot))
                .map(ExportItemNode::getItem)
                .toArray(IExportableItem[]::new);
    }

}
