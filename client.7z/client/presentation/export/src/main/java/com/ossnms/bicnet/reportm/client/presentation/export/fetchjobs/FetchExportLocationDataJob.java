package com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs;


import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportm.client.presentation.export.jobs.IExportJobHandler;
import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class FetchExportLocationDataJob extends RMFetchJob<Iterable<ExportLocationDto>>{

    /**
     * Job instance counter
     */
    private static final AtomicInteger jobInstanceCounter = new AtomicInteger(0);

    /**
     * Process id
     */
    private static final String OPERATION_ID = FetchExportLocationDataJob.class.getSimpleName();

    /**
     * Process name
     */
    private static final String OPERATION_NAME = "Export Location Data";

    /**
     * Creates a new Fetch job to request data throught IReportManagerPrivateFacade
     *
     * @param jobOwner       The owner of this job
     */
    public FetchExportLocationDataJob(@Nonnull IFrameworkDocument jobOwner) {
        super(OPERATION_ID + "#" + jobInstanceCounter.getAndIncrement(), OPERATION_NAME, "", jobOwner);
    }

    @Override
    public List<ExportLocationDto> invokeMethodFromFacade(@Nonnull IReportManagerPrivateFacade iPrivateFacade) throws BcbException {
        getLogger().debug(OPERATION_NAME);

        return iPrivateFacade.getExportLocationData();
    }

    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        IExportJobHandler jobHandler = (IExportJobHandler) visitor;
        return jobHandler.handle(this, result);
    }
}