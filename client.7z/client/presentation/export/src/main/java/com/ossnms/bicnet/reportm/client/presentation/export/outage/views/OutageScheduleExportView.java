/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.presentation.export.outage.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;
import java.util.TimeZone;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.models.ExportItemNode;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.commands.OutageScheduleExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.documents.OutageScheduleExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchDtoDataJob;
import com.ossnms.bicnet.reportm.client.presentation.export.views.ScheduleView;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.util.Constants;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxTitledBorder;

public class OutageScheduleExportView extends ScheduleView {
    private static final long serialVersionUID = -1838738162085152399L;
    
    private static final Dimension VIEW_MINIMUM_SIZE = new Dimension(434, 500);

    private ToggleButtonTree<ExportItemNode> itemsTree;
    private OutageExportableItemsModel itemsTreeModel;
    private JPanel treePanel;
    private JScrollPane treeScrollPane;
    
    private OutageExportSettingsPanel settingsPanel;
    private JPanel selectionPanel;
    private JLabel fieldsValidationLabel;

    private boolean componentAction;
    private Iterable<IExportableItem> exportableItems;

    /**
     * View constructor
     * @param title the view title
     * @param doc   the view document
     */
    public OutageScheduleExportView(String title, OutageScheduleExportDocument doc) throws BcbException {
        super(title, doc, HelpIds.HID_SCHEDULE_ALARMS_OUTAGE_EXPORT);
        setPreferredSize(VIEW_MINIMUM_SIZE);
        setMinimumSize(VIEW_MINIMUM_SIZE);
    }
    
    @Override
    protected final void initGui() {
        fieldsValidationLabel = new JLabel();

        JTabbedPane tabPanel = new JTabbedPane();
        
        JPanel tempSchedulePanel = new JPanel(new GridBagLayout());
        getSchedulePanel().setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        tempSchedulePanel.add(getSchedulePanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        tempSchedulePanel.add(Box.createGlue(), new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        
        settingsPanel = new OutageExportSettingsPanel(fieldsValidationLabel, new Date(), new Date());
        settingsPanel.addActionListener(e -> checkFormValidity());
        settingsPanel.addItemListener(e -> updateActions());
        settingsPanel.addChangeListener(e -> updateActions());
        treePanel = new JPanel(new BorderLayout());
        treePanel.setBorder(new JfxTitledBorder(ExportLabels.MANUAL_EXPORTABLE_PANEL.toString()));

        itemsTreeModel = new OutageExportableItemsModel();
        itemsTree = new ToggleButtonTree<>(itemsTreeModel);
        treeScrollPane = new JScrollPane(itemsTree);
        itemsTreeModel.setSelectionModel(itemsTree.getToggleButtonTreeSelectionModel());
        itemsTree.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                int index = itemsTree.getRowForLocation(e.getX(), e.getY());
                if (index >= 0) {
                    updateTreePane();
                    itemsTreeModel.reload();
                    isAnyNeSelected();
                    checkFormValidity();
                }
            }
        });
        itemsTree.setClickInToggleButtonOnly(true);
        itemsTree.setRootVisible(true);
        itemsTree.setDigInMode(true);
        itemsTree.getSelectionModel().setSelectionMode(TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
        treePanel.add(treeScrollPane, BorderLayout.CENTER);
        
        selectionPanel = new JPanel(new GridBagLayout());
        selectionPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        selectionPanel.add(settingsPanel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        selectionPanel.add(treePanel, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        selectionPanel.add(fieldsValidationLabel, new GridBagConstraints(0, 2, 2, 1, 1.0, 0.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        
        tabPanel.add(ExportLabels.ALARMS_OUTAGE_EXPORT_SCHEDULE_TAB.toString(), tempSchedulePanel);
        tabPanel.add(ExportLabels.ALARMS_OUTAGE_EXPORT_SETTINGS_TAB.toString(), selectionPanel);
        
        getMainComponent().add(tabPanel, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    }

    @Override
    public final void initGuiNames() {
        getMainComponent().setName("PANEL.OutageSchedule");
        setName("OutageSchedule");
        itemsTree.setName("FIELD.ItemsTree");
    }
    
    private boolean isAnyNeSelected() {
        if(itemsTreeModel.isAnyNodeSelected()) {
            hideWarningIcon(fieldsValidationLabel);
            return true;
        }
        
        showWarningIcon(fieldsValidationLabel, ExportLabels.ALARMS_OUTAGE_EXPORT_NES_SELECTED_WARNING.toString());
        return false;
    }

    /**
     * Shows warning icon plus a label and/or tooltip messages in the specified JfxLabel field.
     */
    private static void showWarningIcon(JLabel warningLabel, String textMessage) {
        warningLabel.setIcon(ResourcesIconFactory.ICON_STATUS_WARNING_16.getImageIcon());
        warningLabel.setText(textMessage);
    }

    /**
     * Hides the icon and messages of the specified JfxLabel field.
     */
    private static void hideWarningIcon(JLabel warningLabel) {
        warningLabel.setIcon(null);
        warningLabel.setText("");
    }

    private void checkFormValidity() {
        componentAction = true;
        updateActions();
    }

    public boolean isComponentAction() {
        return componentAction;
    }

    @Override
    public boolean isFormDirty() {
        //TODO: Add check for differences in selection

        if(isFormValidAndNotDirty() && componentAction) {
            return settingsPanel.areDateFieldsValid() && settingsPanel.isAnySeverityCheckboxSelected() &&
                    settingsPanel.isAnyStateCheckboxSelected() && settingsPanel.isAnyNeSelected(itemsTreeModel.isAnyNodeSelected());
        }

        componentAction = false;
        return settingsPanel.areDateFieldsValid() && settingsPanel.isAnySeverityCheckboxSelected() &&
                settingsPanel.isAnyStateCheckboxSelected() && itemsTreeModel.isAnyNodeSelected() &&
                super.isFormDirty();
    }

    private void loadData(Iterable<IExportableItem> exportableItems, OutageAlarmSettingsDto settingsDto) {
        settingsPanel.setInitDate(new Date(settingsDto.getStartDate()));
        settingsPanel.setEndDate(new Date(settingsDto.getEndDate()));
        settingsPanel.setAutomaticTimeRangeSelected(settingsDto.getAutomaticTimeRange());
        settingsPanel.selectCheckboxes(settingsDto);
        this.exportableItems = exportableItems;
        new LoadFetchData().execute();
    }

    private final class LoadFetchData extends SwingWorker<Boolean, Void> {

        @Override
        protected Boolean doInBackground() throws Exception {
            itemsTreeModel.initFromExportableItems(exportableItems);
            return null;
        }

        @Override
        protected void done() {
            getExportedData();
        }
    }

    private void getExportedData() {
        new SwingWorker<Boolean, Object>() {
            @Override
            protected Boolean doInBackground() {
                updateTreePane();
                return true;
            }
        }.execute();
    }
    
    private void expandAll(JTree tree, TreePath parent) {
        TreeNode node = (TreeNode) parent.getLastPathComponent();
        if (!node.isLeaf()) {
            for (int i = 0; i < node.getChildCount(); i++) {
                TreePath path = parent.pathByAddingChild(node.getChildAt(i));
                expandAll(tree, path);
            }
        }
        tree.expandPath(parent);
    }

    private void updateTreePane() {
        SwingUtilities.invokeLater(() -> {
            expandAll(itemsTree, new TreePath(itemsTree.getModel().getRoot()));
            itemsTree.updateUI();
        });
    }

    public OutageExportableItemsModel getItemsTreeModel() {
        return itemsTreeModel;
    }
    
    @Override
    public void updateData(Object key) {
        super.updateData(key);
        
        if (key instanceof OperationKey) {
            switch ((OperationKey) key) {
            case LOAD_OUTAGE_SETTINGS_ITEMS:
                    loadData(getFrameworkDocument().getMergedAllReceivedNes(), getFrameworkDocument().getSettingsDto());
                    setActivityIndicatorVisible(false);
                break;

            case LOAD_OUTAGE_ALL_NES_ITEMS:
                fetchOutageSettings();
                break;

            default:
                // Wait for the nes list
                setActivityIndicatorVisible(true);
                break;
            }
        }
    }

    private void fetchOutageSettings() {
        FrameworkFetchJob job = new OutageFetchDtoDataJob(getFrameworkDocument());
        try {
            getFrameworkDocument().executeJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Error executing OutageFetchDtoDataJob.", e);
        }
    }

    @Override
    protected void loadScheduleMarkables(IScheduleMarkable[] scheduleMarkables, String reportId) {
        if(reportId.equals(getReportId())){
            getSchedulePanel().setObjects(scheduleMarkables);
        }
    }

    @Override
    public String getReportId() {
        return Constants.ALARMS_OUTAGE_REPORT;
    }

    @Override
    public void callExportJob(ScheduleItem scheduleItem, IScheduleMarkable mark) {
        getFrameworkDocument().scheduleExport(scheduleItem, getReportId(), mark, OutageExportDtoHelper.
                getAlarmSettingsDto(settingsPanel, itemsTreeModel));
    }

    @Override
    public String getCommandClassName() {
        return OutageScheduleExportCommand.class.getName();
    }

    @Override
    public boolean supportsPersistance() {
        return false;
    }

    @Override
    public JTable getDataToPrint() {
        return new JTable();
    }
    
    @Override
    public ImageIcon getViewIcon() {
        return IconFactory.getIconWithOverlay(ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16, ActionType.ALARM);
    }

    @Override
    public void scheduleActions() {
        //TODO
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {
        settingsPanel.getStartDateCalendar().setTimeZone(timeZone);
        settingsPanel.getEndDateCalendar().setTimeZone(timeZone);
    }
}