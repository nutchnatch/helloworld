package com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs;

import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.AbstractPrivateFacadeFetchJob;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportm.client.presentation.export.jobs.IExportJobHandler;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;

public class OutageFetchFilterJob extends AbstractPrivateFacadeFetchJob<ILogRecordFilter, IReportManagerPrivateFacade> {

    /**
     * Job instance counter
     */
    private static final AtomicInteger jobInstanceCounter = new AtomicInteger(0);
    /**
     * Process id
     */
    private static final String OPERATION_ID = OutageFetchFilterJob.class.getSimpleName();
    /**
     * Process name
     */
    private static final String OPERATION_NAME = "Fetch filter data";
    
    /**
     * The class constructor
     * @param jobOwner the document owner
     */
    public OutageFetchFilterJob(@Nonnull final IFrameworkDocument jobOwner) {
        super(IReportManagerPrivateFacade.class, OPERATION_ID + "#" + jobInstanceCounter.getAndIncrement(), OPERATION_NAME, "", jobOwner);
    }
    
    /**
     * (non-Javadoc)
     * see com.ossnms.bicnet.reportm.client.presentation.export.executejobs.RMFetchJob<ReportDataDto>
     */
    @Override
    public ILogRecordFilter invokeMethodFromFacade(@Nonnull final IReportManagerPrivateFacade iPrivateFacade) throws BcbException {
        getLogger().debug(OPERATION_NAME);

        return iPrivateFacade.getAlarmFilter();
    }

    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        IExportJobHandler jobHandler = (IExportJobHandler) visitor;
        return jobHandler.handle(this, result);
    }
}
