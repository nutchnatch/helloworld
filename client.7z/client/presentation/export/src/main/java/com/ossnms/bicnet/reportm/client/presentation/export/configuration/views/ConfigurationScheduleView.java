/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.presentation.export.configuration.views;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.List;
import java.util.TimeZone;

import javax.swing.*;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.framework.client.utils.FrameworkOkCommand;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.models.ExportItemNode;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands.ConfigurationScheduleOpenCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.documents.ConfigurationScheduleDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.views.ScheduleView;
import com.ossnms.bicnet.reportm.client.presentation.export.views.commands.OkCommand;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.util.Constants;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxTitledBorder;

public class ConfigurationScheduleView extends ScheduleView {

    private static final long serialVersionUID = -1838738162085152399L;
    private static final Dimension VIEW_MINIMUM_SIZE = new Dimension(434, 550);

    private ToggleButtonTree<ExportItemNode> itemsTree;
    private ExportableItemsModel itemsTreeModel;
    private JPanel treePanel;
    private JScrollPane treeScrollPane;
    private Iterable<IExportableItem> exportableItems;
    
    /**
     * View constructor
     *
     * @param title the view title
     * @param doc   the view document
     */
    public ConfigurationScheduleView(String title, ConfigurationScheduleDocument doc) throws BcbException {
        super(title, doc, HelpIds.HID_SCHEDULE_CONFIGURATION_EXPORT);
        setPreferredSize(VIEW_MINIMUM_SIZE);
        setMinimumSize(VIEW_MINIMUM_SIZE);
    }
    
    @Override
    protected final void initGui() throws BcbException {
        getMainComponent().setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        
        treePanel = new JPanel(new BorderLayout());
        treePanel.setBorder(new JfxTitledBorder(ExportLabels.MANUAL_EXPORTABLE_PANEL.toString()));

        itemsTreeModel = new ExportableItemsModel();
        itemsTree = new ToggleButtonTree<>(itemsTreeModel);
        treeScrollPane = new JScrollPane(itemsTree);
        itemsTreeModel.setSelectionModel(itemsTree.getToggleButtonTreeSelectionModel());
        itemsTree.setClickInToggleButtonOnly(true);
        itemsTree.setRootVisible(true);
        itemsTree.setDigInMode(true);
        itemsTree.getSelectionModel().setSelectionMode(TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
        treePanel.add(treeScrollPane, BorderLayout.CENTER);
        
        setTreeEnabled(getSchedulePanel().isScheduleActivated());
        
        getMainComponent().add(getSchedulePanel(), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        getMainComponent().add(treePanel, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        getMainComponent().add(getECSContributionPanel(), new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    }
    
    @Override
    public final void initGuiNames() {
        getMainComponent().setName("PANEL.ConfigurationSchedule");
        setName("ConfigurationSchedule");
        itemsTree.setName("FIELD.ItemsTree");
    }
    
    private void setTreeEnabled(boolean isScheduleActive) {
        itemsTree.setToggleButtonsEnabled(isScheduleActive);
        treePanel.setEnabled(isScheduleActive);
    }

    private void loadData(Iterable<IExportableItem> exportableItems) {
        this.exportableItems = exportableItems;
        new LoadFetchData().execute();
    }

    private final class LoadFetchData extends SwingWorker<Boolean, Void> {

        @Override
        protected Boolean doInBackground() throws Exception {

            itemsTreeModel.initFromExportableItems(exportableItems);
            return null;
        }

        @Override
        protected void done() {
            getExportedData();
        }
    }

    private void getExportedData() {
        updateTreePane();
    }

    private void expandAll(JTree tree, TreePath parent) {
        TreeNode node = (TreeNode) parent.getLastPathComponent();
        if (!node.isLeaf()) {
            for (int i = 0; i < node.getChildCount(); i++) {
                TreePath path = parent.pathByAddingChild(node.getChildAt(i));
                expandAll(tree, path);
            }
        }
        tree.expandPath(parent);
    }

    private void updateTreePane() {
        SwingUtilities.invokeLater(() -> {
            expandAll(itemsTree, new TreePath(itemsTree.getModel().getRoot()));
            itemsTree.updateUI();
        });
    }

    public ExportableItemsModel getItemsTreeModel() {
        return itemsTreeModel;
    }
    
    @Override
    public void updateData(Object key) {
        super.updateData(key);
        
        if (key instanceof OperationKey) {
            switch ((OperationKey) key) {
            case LOAD_EXPORTABLE_ITEMS:
                loadData(getFrameworkDocument().getScheduledExportableItems());
                if (!getFrameworkDocument().isStoredData()) {
                    itemsTreeModel.setAllSelected();
                }
                break;
            case LOAD_EXPORT_LOCATION_DATA:
                loadTransferSettings(getFrameworkDocument().getTransferSettingsByExportId(getReportId()));
                break;
            default:
                break;
            }
        }
    }

    @Override
    protected void loadScheduleMarkables(IScheduleMarkable[] scheduleMarkables, String reportId) {
        if(reportId.equals(getReportId())){
            getSchedulePanel().setObjects(scheduleMarkables);
        }
    }

    @Override
    public String getReportId() {
        return Constants.CONFIGURATION_EXPORT_REPORT;
    }

    @Override
    public void callExportJob(ScheduleItem scheduleItem, IScheduleMarkable mark) {
        getFrameworkDocument().scheduleExport(scheduleItem, getReportId(), mark, getItemsTreeModel().getAllSelectedNodes(),
                convertToExportLocationDto(getReportId(), getEcsContribution().getTransferSettings()));
    }

    @Override
    public String getCommandClassName() {
        return ConfigurationScheduleOpenCommand.class.getName();
    }

    @Override
    public boolean supportsPersistance() {
        return false;
    }

    @Override
    public JTable getDataToPrint() {
        return new JTable();
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {

    }

    @Override
    public void scheduleActions() {
        setTreeEnabled(getSchedulePanel().isScheduleActivated());
    }
}