package com.ossnms.bicnet.reportm.client.presentation.export.configuration.documents;

import com.ossnms.bicnet.reportm.client.presentation.export.documents.AbstractExportDocument;
import com.ossnms.bicnet.reportmanager.util.Constants;

/**
 * Document class for handling Configuration Export base window
 */
public class ConfigurationExportDocument extends AbstractExportDocument {

    @Override
    protected String getReportId() {
        return Constants.CONFIGURATION_EXPORT_REPORT;
    }

    @Override
    public void fetchOtherData() {

    }

}
