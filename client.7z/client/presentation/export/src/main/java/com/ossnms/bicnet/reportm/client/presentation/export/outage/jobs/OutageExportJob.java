package com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.AbstractPrivateFacadeFetchJob;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;
import com.ossnms.bicnet.reportmanager.util.Constants;

import javax.annotation.Nonnull;
import java.util.concurrent.atomic.AtomicInteger;

public class OutageExportJob extends AbstractPrivateFacadeFetchJob<Boolean, IReportManagerPrivateFacade> {

    /**
     * Job instance counter
     */
    private static final AtomicInteger jobInstanceCounter = new AtomicInteger(0);
    /**
     * Process id
     */
    private static final String OPERATION_ID = OutageExportJob.class.getSimpleName();
    /**
     * Process name
     */
    private static final String OPERATION_NAME = "Export Outage data";
    
    private final ILogRecordFilter outageExportFilter;
    private final INEId[] nes;

    /**
     * The class constructor
     * @param jobOwner the document owner
     */
    public OutageExportJob(@Nonnull final IFrameworkDocument jobOwner, ILogRecordFilter outageExportFilter,
                           INEId[] nes) {
        super(IReportManagerPrivateFacade.class, OPERATION_ID + "#" + jobInstanceCounter.getAndIncrement(), OPERATION_NAME, "", jobOwner);
        this.outageExportFilter = outageExportFilter;
        this.nes = nes.clone();
    }
    
    /**
     * (non-Javadoc)
     * see com.ossnms.bicnet.reportm.client.presentation.export.executejobs.RMFetchJob<ReportDataDto>
     */
    @Override
    public Boolean invokeMethodFromFacade(@Nonnull final IReportManagerPrivateFacade iPrivateFacade) throws BcbException {
        getLogger().debug(OPERATION_NAME);

        iPrivateFacade.startAlarmOutageReport(getSessionContext(), Constants.ALARMS_OUTAGE_REPORT, outageExportFilter,
                nes);
        return true;
    }

    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        return OperationKey.NOTHING_TO_DO;
    }
}
