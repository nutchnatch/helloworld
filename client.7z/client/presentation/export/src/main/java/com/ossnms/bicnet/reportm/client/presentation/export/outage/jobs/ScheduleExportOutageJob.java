package com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitor;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.RMFetchJob;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.facade.IReportManagerPrivateFacade;

import javax.annotation.Nonnull;
import java.util.concurrent.atomic.AtomicInteger;

public class ScheduleExportOutageJob extends RMFetchJob<Boolean> {

    /**
     * Job instance counter
     */
    private static final AtomicInteger jobInstanceCounter = new AtomicInteger(0);
    /**
     * Process id
     */
    private static final String OPERATION_ID = ScheduleExportOutageJob.class.getSimpleName();
    /**
     * Process name
     */
    private static final String OPERATION_NAME = "Schedule outage export data";

    private final ScheduleItem scheduleItem;

    private final String reportId;


    private final IScheduleMarkable mark;
    private final OutageAlarmSettingsDto outageSettingsDto;

    /**
     * The class constructor
     * @param jobOwner        the document owner
     * @param scheduleItem    the schedule item to schedule
     * @param messages
     * @param outageSettingsDto
     */
    public ScheduleExportOutageJob(@Nonnull final IFrameworkDocument jobOwner, @Nonnull final ScheduleItem scheduleItem,
                                   @Nonnull String reportId, IScheduleMarkable mark, OutageAlarmSettingsDto outageSettingsDto) {
        super(OPERATION_ID + "#" + jobInstanceCounter.getAndIncrement(), OPERATION_NAME, "", jobOwner);

        this.scheduleItem = scheduleItem;
        this.reportId = reportId;
        this.mark = mark;
        this.outageSettingsDto = outageSettingsDto;
    }

    /**
     * (non-Javadoc)
     * see com.ossnms.bicnet.reportm.client.presentation.export.executejobs.RMFetchJob<ReportDataDto>
     */
    @Override
    public Boolean invokeMethodFromFacade(@Nonnull final IReportManagerPrivateFacade iPrivateFacade) throws BcbException {
        getLogger().debug(OPERATION_NAME + ": {}", scheduleItem);

        iPrivateFacade.scheduleOutageAlarm(getSessionContext(), reportId, scheduleItem, mark, outageSettingsDto);

        return true;
    }

    @Override
    public OperationKey dispatch(IJobVisitor visitor, Object result) {
        return OperationKey.NOTHING_TO_DO;
    }
}
