package com.ossnms.bicnet.reportm.client.presentation.export.outage.documents;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.presentation.export.documents.AbstractExportDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageExportJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchFilterJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchNesJob;
import com.ossnms.bicnet.reportmanager.util.Constants;


public class OutageManualExportDocument extends AbstractExportDocument {

    private ILogRecordFilter filter;

    /**
     * Execute Outage Export Data operation
     */
    public void outageGetNes() {
        FrameworkFetchJob job = new OutageFetchNesJob(this);
        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Error executing OutageFetchJob.", e);
        }
    }
    
    /**
     * Execute Outage Export Data operation
     */
    public void outageExportData(ILogRecordFilter outageRecordFilter, INEId[] nes) {
        FrameworkFetchJob job = new OutageExportJob(this, outageRecordFilter, nes);
        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Error executing OutageExportJob.", e);
        }
    }

    /**
     * Execute Outage Export Data operation
     */
    public void outageGetFilter() {
        FrameworkFetchJob job = new OutageFetchFilterJob(this);
        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Error executing OutageExportJob.", e);
        }
    }

    @Override
    public void fetchOtherData() {
    }
    
    @Override
    protected String getReportId() {
        return Constants.ALARMS_OUTAGE_REPORT;
    }
}