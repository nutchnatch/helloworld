/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.presentation.export.inventory.views;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.commands.InventoryScheduleOpenCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.documents.InventoryScheduleDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.views.ScheduleView;
import com.ossnms.bicnet.reportmanager.util.Constants;
import com.ossnms.tools.jfx.JfxUtils;

import javax.swing.*;
import java.awt.*;
import java.util.TimeZone;

public class InventoryScheduleView extends ScheduleView {
    private static final long serialVersionUID = -1838738162085152399L;

    private static final Dimension VIEW_MINIMUM_SIZE = new Dimension(434, 450);

    /**
     * View constructor
     *
     * @param title the view title
     * @param doc   the view document
     * @throws BcbException
     */
    public InventoryScheduleView(String title, InventoryScheduleDocument doc) throws BcbException {
        super(title, doc, HelpIds.HID_SCHEDULE_INVENTORY_EXPORT);
        setPreferredSize(VIEW_MINIMUM_SIZE);
        setMinimumSize(VIEW_MINIMUM_SIZE);
    }
    
    @Override
    public final void initGuiNames() {
        getMainComponent().setName("PANEL.InventorySchedule");
        setName("InventorySchedule");
    }
    
    @Override
    protected final void initGui() throws BcbException {
        getMainComponent().add(getSchedulePanel(), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        getMainComponent().add(getECSContributionPanel(), new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
    }

    @Override
    protected void loadScheduleMarkables(IScheduleMarkable[] scheduleMarkables, String reportId) {
        if (reportId.equals(Constants.INVENTORY_EXPORT_REPORT)) {
            getSchedulePanel().setObjects(scheduleMarkables);
        }
    }

    @Override
    public String getReportId() {
        return Constants.INVENTORY_EXPORT_REPORT;
    }

    @Override
    public void callExportJob(ScheduleItem scheduleItem, IScheduleMarkable mark) {
        getFrameworkDocument().scheduleExport(scheduleItem, getReportId(), mark,
                convertToExportLocationDto(getReportId(), getEcsContribution().getTransferSettings()));
    }

    @Override
    public String getCommandClassName() {
        return InventoryScheduleOpenCommand.class.getName();
    }

    @Override
    public JTable getDataToPrint() {
        return new JTable();
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {

    }

    @Override
    public void scheduleActions() {
        //Nothing to do
    }

    @Override
    public void updateData(Object key) {
        super.updateData(key);

        if (key instanceof OperationKey) {
            switch ((OperationKey) key) {
                case LOAD_EXPORT_LOCATION_DATA:
                    loadTransferSettings(getFrameworkDocument().getTransferSettingsByExportId(getReportId()));
                    break;
                default:
                    break;
            }
        }
    }

}