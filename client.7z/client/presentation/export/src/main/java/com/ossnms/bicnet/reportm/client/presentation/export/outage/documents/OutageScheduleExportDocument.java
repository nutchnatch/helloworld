/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.presentation.export.outage.documents;

import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.presentation.export.documents.ScheduleDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchNesJob;
import com.ossnms.bicnet.reportmanager.util.Constants;

public class OutageScheduleExportDocument extends ScheduleDocument {

    @Override
    protected String getReportId() {
        return Constants.ALARMS_OUTAGE_REPORT;
    }

    @Override public void fetchOtherData() {
        fetNes();
    }

    private void fetNes() {
        FrameworkFetchJob job = new OutageFetchNesJob(this);
        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Error executing OutageFetchNesJob.", e);
        }
    }
}
