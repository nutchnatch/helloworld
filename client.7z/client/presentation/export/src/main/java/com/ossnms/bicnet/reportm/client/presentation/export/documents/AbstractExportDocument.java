package com.ossnms.bicnet.reportm.client.presentation.export.documents;

import static java.util.Optional.ofNullable;

import java.util.Objects;
import java.util.Optional;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.api.documents.AbstractDocument;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.jobs.IJobVisitable;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.ExportDataFetchJob;
import com.ossnms.bicnet.reportm.client.presentation.export.jobs.ExportJobHandlerManager;
import com.ossnms.bicnet.reportm.client.presentation.settings.system.SystemSettingsFetchJob;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.messaging.RMMessageItem;

/**
 * General Document with common behavior for export documents
 */
public abstract class AbstractExportDocument extends AbstractDocument {

    private final ExportJobHandlerManager jobHandlerManager = new ExportJobHandlerManager();

    public Optional<ReportDataDto> getExportData() {
        return jobHandlerManager.getExportData();
    }

    public Iterable<IExportableItem> getManualExportableItems() {
        return jobHandlerManager.getManualExportableItems();
    }

    public Iterable<IExportableItem> getOutageExportableItems() {
        return jobHandlerManager.getOutageExportablePersistedNes();
    }

    public Iterable<IExportableItem> getOutageExportableAllNes() {
        return jobHandlerManager.getOutageExportableAllNes();
    }

    public Iterable<IExportableItem> getMergedAllReceivedNes() {
        return jobHandlerManager.getMergedAllReceivedNes();
    }

    public Iterable<IExportableItem> getScheduledExportableItems() {
        return jobHandlerManager.getScheduledExportableItems();
    }

    public TransferSettings getTransferSettingsByExportId (String exportId) {
        return  jobHandlerManager.getExportLocationMap().get(exportId);
    }

    public OutageAlarmSettingsDto getSettingsDto() {
        return jobHandlerManager.getOutageAlarmSettingsDto();
    }

    public ILogRecordFilter getOutageExportFilter() {
        return jobHandlerManager.getOutageExportFilter();
    }

    @Override
    public void fetchData() {
        FrameworkFetchJob job = new ExportDataFetchJob(this, getReportId());
        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Error executing ExportDataFetchJob job.", e);
        }
    }

    @Override
    public abstract void fetchOtherData();

    @Override
    protected void fetchSystemSettings() {
        addAndExecuteJob(new SystemSettingsFetchJob(this));
    }

    @Override
    public boolean onHandlingRMMessageItem(@Nonnull RMMessageItem arg) throws BcbException {
        Optional<ReportDataDto> currentReport = getReportDataDto(arg)
                .filter(dto -> Objects.equals(dto.getReportId(), getReportId()));
        currentReport.ifPresent(jobHandlerManager::setExportData);

        OperationKey key = currentReport
                .map(r -> OperationKey.HANDLE_NOTIFICATIONS)
                .orElse(OperationKey.NOTHING_TO_DO);

        if (OperationKey.NOTHING_TO_DO != key) {
            fireUpdateData(key);
            return true;
        }
        return false;
    }

    private Optional<ReportDataDto> getReportDataDto(@Nonnull RMMessageItem arg) {
        return Optional.of(arg)
                .map(RMMessageItem::getObject)
                .filter(ReportDataDto.class::isInstance)
                .map(ReportDataDto.class::cast);
    }

    @Override
    public OperationKey handleJobNotifications(@Nonnull IJobVisitable job, @Nonnull Object result) {

        return job.dispatch(jobHandlerManager, result);
    }

    public Optional<SystemSettings> getSystemSettings() {
        return ofNullable(jobHandlerManager.getSystemSettings());
    }

    protected abstract String getReportId();

    public boolean isStoredData() {
        return true;
    }
}