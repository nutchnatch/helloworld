package com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements;

import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;

public interface ExportableElementBuilder<EXPORTABLE_ELEMENT_TYPE> {

    boolean acceptReader(ExportableReaderDto readerDto);
    EXPORTABLE_ELEMENT_TYPE buildItem(Iterable<IExportableReader> readers, ExportableItemDto itemDto);
    EXPORTABLE_ELEMENT_TYPE buildReader(ExportableReaderDto readerDto);
    boolean acceptItem(ExportableItemDto itemDto);
}
