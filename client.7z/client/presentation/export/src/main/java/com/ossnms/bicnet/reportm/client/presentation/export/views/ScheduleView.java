/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.presentation.export.views;

import com.ossnms.bicnet.bcb.facade.platform.ScheduleItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.model.platform.IScheduleMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceContribution;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceProvider;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.helpers.scheduler.FrameworkScheduledJobPanel;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.exceptions.ReportManagerUnexpectedException;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.export.documents.ScheduleDocument;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.JfxOptionsData;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public abstract class ScheduleView extends AbstractExportView {

    private static final long serialVersionUID = -1838738162085152399L;

    /**
     * Constants
     */
    private static final String VIEW_ID = ScheduleView.class.getName();

    /**
     * Components
     */
    private FrameworkScheduledJobPanel schedulePanel;

    /**
     * Ecs Contribution
     */
    private BiCNetPluginExternalCommunicationServiceContribution ecsContribution;

    /**
     * View constructor
     *
     * @param title the view title
     * @param doc the view document
     * @throws BcbException
     */
    public ScheduleView(String title, ScheduleDocument doc, int helpId) throws BcbException {
        super(VIEW_ID, title, doc, helpId);
        initControls();
        createSchedulePanel();
        initGui();
        initScheduleGuiNames();
        initGuiNames();
    }

    /**
     * Add static UI components name
     */
    private final void initScheduleGuiNames() {
        schedulePanel.setName("PANEL.Schedule");
    }

    public abstract void initGuiNames();

    public FrameworkScheduledJobPanel createSchedulePanel() {
        schedulePanel = new FrameworkScheduledJobPanel(RMPluginHelperImpl.getInstance().getCfPluginSite(), ExportLabels.SCHEDULE_EXPORT_TIME.toString(), true, true, true);
        
        schedulePanel.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                scheduleActions();
                updateActions();
            }
        });
        return schedulePanel;
    }
    
    public abstract void scheduleActions();
    
    protected abstract void loadScheduleMarkables(IScheduleMarkable[] scheduleMarkables, String reportId);

    /**
     * Check if there was a change from the original data in form
     *
     * @return {@code true} if form data has changed, {@code false} otherwise
     */
    @Override
    public boolean isFormDirty() {
        return !schedulePanel.isScheduleActivated() && schedulePanel.isPanelDirty()
                || schedulePanel.isScheduleActivated() && schedulePanel.isNextExecutionTimeValid() && schedulePanel.isPanelDirty();
    }

    public boolean isFormValidAndNotDirty() {
        return schedulePanel.isScheduleActivated() && schedulePanel.isNextExecutionTimeValid() && !schedulePanel.isPanelDirty();
    }

    @Override
    public void updateData(Object key) {
        if (key instanceof OperationKey) {
            switch ((OperationKey) key) {
            case LOAD_EXPORT_DATA:
                loadScheduleMarkables(getFrameworkDocument().getScheduleMarkables(), getFrameworkDocument().getReportType());
                setActivityIndicatorVisible(false);
                break;
            case ERROR:
                throw new ReportManagerUnexpectedException("Unexpected error occurred during update data while Scheduling Export.");
            default:
                break;
            }
        }
    }

    public IScheduleMarkable getScheduleItem() {
        schedulePanel.actionApply();
        return schedulePanel.getSchedule();
    }

    @Override
    public ImageIcon getViewIcon() {
        return ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16;
    }

    @Override
    public ActionType getViewAction() {
        return ActionType.SCHEDULED;
    }

    @Override
    public ScheduleDocument getFrameworkDocument() {
        return (ScheduleDocument) super.getFrameworkDocument();
    }

    public void executeDocument(FrameworkFetchJob job) throws FrameworkException {
        super.getFrameworkDocument().executeJob(job);
    }

    public abstract String getReportId();

    public FrameworkScheduledJobPanel getSchedulePanel() {
        return schedulePanel;
    }

    public abstract void callExportJob(ScheduleItem scheduleItem, IScheduleMarkable mark);

    @Override
    public void addClientLogEntry(String s, Exception e) {

    }

    @Override
    public boolean supportsPersistance() {
        return false;
    }

    @Override
    protected String getProfileId() {
        return null;
    }

    @Override
    protected JfxOptionsData getOptionsData() {
        return null;
    }

//    @Override
//    protected void loadLdapSettings(JfxOptionsData jfxOptionsData) {
//
//    }
//
//    @Override
//    protected void saveLdapSettings(JfxOptionsData jfxOptionsData) {
//
//    }

    @Override
    protected void loadSettings(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveSettings(JfxOptionsData aProfile) {

    }


    @Override
    protected void loadFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected IPluginSecurityProvider getSecurityProvider() throws BiCNetPluginException {
        return null;
    }

    @Override
    protected ISecureClientSession getSecureClientSession() throws BiCNetPluginException {
        return null;
    }

    /**
     * Get ECS Contribution Panel
     * @return
     * @throws BcbException
     */
    public JComponent getECSContributionPanel() throws BcbException {
        BiCNetPluginExternalCommunicationServiceProvider pluginExternalCommunicationService = RMPluginHelperImpl.getInstance().getPluginExternalCommunicationService();

        if (pluginExternalCommunicationService == null) {
            throw new BcbException("Unable to get ECS contribution");
        }

        BiCNetPluginExternalCommunicationServiceContribution ecsContribution = pluginExternalCommunicationService.getContribution();

        this.ecsContribution = ecsContribution;

        // configure activate checkbox
        ecsContribution.setEnabled(schedulePanel.isScheduleActivated());
        schedulePanel.addActivateCheckBoxItemListener(checkBoxActivateListener());

        return ecsContribution.getComponent();
    }

    public BiCNetPluginExternalCommunicationServiceContribution getEcsContribution() {
        return ecsContribution;
    }

    public void setEcsContribution(BiCNetPluginExternalCommunicationServiceContribution ecsContribution) {
        this.ecsContribution = ecsContribution;
    }

    public ExportLocationDto convertToExportLocationDto(String inventoryExportReport, TransferSettings transferSettings) {
        ExportLocationDto exportLocationDto = new ExportLocationDto();

        exportLocationDto.setExportId(inventoryExportReport);
        exportLocationDto.setTransferSettings(transferSettings);

        return exportLocationDto;
    }

    public void loadTransferSettings(TransferSettings transferSettings) {
        if (null != transferSettings) {
            getEcsContribution().setTransferSettings(transferSettings);
        }
    }

    public ItemListener checkBoxActivateListener() {
        return e -> getEcsContribution().setEnabled(schedulePanel.isScheduleActivated());
    }
}