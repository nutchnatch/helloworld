package com.ossnms.bicnet.reportm.client.presentation.export.jobs;

import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.executejobs.ConfigurationExportJob;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.ExportDataFetchJob;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.FetchExportLocationDataJob;
import com.ossnms.bicnet.reportm.client.presentation.export.fetchjobs.FetchExportableItemsJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchDtoDataJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchFilterJob;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.jobs.OutageFetchNesJob;
import com.ossnms.bicnet.reportm.client.presentation.settings.system.ISystemSettingsJobHandler;
import com.ossnms.bicnet.reportm.client.presentation.settings.system.SystemSettingsFetchJob;
import com.ossnms.bicnet.reportmanager.api.SystemSettings;
import com.ossnms.bicnet.reportmanager.dto.DcnObject;
import com.ossnms.bicnet.reportmanager.dto.ExportLocationDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.OutageAlarmSettingsDto;
import com.ossnms.bicnet.reportmanager.dto.ReportDataDto;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

import static com.ossnms.bicnet.reportm.client.presentation.export.documents.ExportableElementsBuilder.convertDcnDtos;
import static com.ossnms.bicnet.reportm.client.presentation.export.documents.ExportableElementsBuilder.convertDtos;
import static com.ossnms.bicnet.reportm.client.presentation.export.documents.ExportableElementsBuilder.convertOutageNeDtos;
import static java.util.Optional.ofNullable;

public class ExportJobHandlerManager implements IExportJobHandler, ISystemSettingsJobHandler {

    private ReportDataDto exportData;
    private SystemSettings systemSettings;
    private Iterable<IExportableItem> manualExportableItems;
    private Iterable<IExportableItem> scheduledExportableItems;
    private Iterable<IExportableItem> outageExportablePersistedNes;
    private Iterable<IExportableItem> outageExportableAllNes;
    private ILogRecordFilter outageExportFilter;
    private OutageAlarmSettingsDto outageAlarmSettingsDto;
    private Set<IExportableItem> mergedAllReceivedNes = new LinkedHashSet<>();
    private Map<Integer, IExportableItem> mergedAllReceivedNesMap = new HashMap<>();
    private Map<String, TransferSettings> exportLocationDtoMap = new HashMap<>();

    public Set<IExportableItem> getMergedAllReceivedNes() {
        return mergedAllReceivedNes;
    }

    public Iterable<IExportableItem> getOutageExportableAllNes() {
        return outageExportableAllNes;
    }

    public Map<Integer, IExportableItem> getMergedAllReceivedNesMap() {
        return mergedAllReceivedNesMap;
    }

    public OutageAlarmSettingsDto getOutageAlarmSettingsDto() {
        return outageAlarmSettingsDto;
    }

    public Optional<ReportDataDto> getExportData() {
        return ofNullable(exportData);
    }

    public void setExportData(ReportDataDto exportData) {
        this.exportData = exportData;
    }

    public Iterable<IExportableItem> getManualExportableItems() {
        return manualExportableItems;
    }

    public Iterable<IExportableItem> getOutageExportablePersistedNes() {
        return outageExportablePersistedNes;
    }

    public Iterable<IExportableItem> getScheduledExportableItems() {
        return scheduledExportableItems;
    }

    public Map<String, TransferSettings> getExportLocationMap() {
        return exportLocationDtoMap;
    }

    public ILogRecordFilter getOutageExportFilter() {
        return outageExportFilter;
    }

    public SystemSettings getSystemSettings() {
        return systemSettings;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportJobHandlerManager.class);

    @Override
    public OperationKey handle(ConfigurationExportJob configurationExportJob, Object result) {
        return OperationKey.MANUAL_EXPORT_JOB_EXECUTED;
    }

    @Override
    public OperationKey handle(OutageFetchFilterJob outageFetchFilterJob, Object result) {

        outageExportFilter = (ILogRecordFilter) result;
        return OperationKey.LOAD_ALARM_FILTER;
    }

    @Override
    public OperationKey handle(FetchExportableItemsJob fetchExportableItemsJob, Object result) {

        List<IExportableItem> items = convertDtos((Iterable<ExportableItemDto>) result);
        manualExportableItems = items;
        scheduledExportableItems = items;
        return OperationKey.LOAD_EXPORTABLE_ITEMS;
    }

    @Override
    public OperationKey handle(SystemSettingsFetchJob systemSettingsFetchJob, Object result) {

        systemSettings = (SystemSettings) result;
        return OperationKey.LOAD_SYSTEM_SETTINGS;
    }

    @Override
    public OperationKey handle(OutageFetchNesJob outageFetchNesJob, Object result) {

        outageExportableAllNes = convertDcnDtos((Iterable<DcnObject>)result);
        for (IExportableItem outageExportableAllNe : outageExportableAllNes) {
            mergedAllReceivedNes.add(outageExportableAllNe);
            mergedAllReceivedNesMap.put(outageExportableAllNe.getObjectId(), outageExportableAllNe);
        }
        return OperationKey.LOAD_OUTAGE_ALL_NES_ITEMS;
    }

    @Override
    public OperationKey handle(ExportDataFetchJob exportDataFetchJob, Object result) {

        exportData = (ReportDataDto) result;
        return OperationKey.LOAD_EXPORT_DATA;
    }

    @Override
    public OperationKey handle(OutageFetchDtoDataJob outageFetchDtoDataJob, Object result) {

        outageAlarmSettingsDto = (OutageAlarmSettingsDto) result;
        outageExportablePersistedNes = convertOutageNeDtos(outageAlarmSettingsDto.getNes());
        for (IExportableItem outageExportableAllNe : outageExportablePersistedNes) {
            if(mergedAllReceivedNesMap.containsKey(outageExportableAllNe.getObjectId())){
                mergedAllReceivedNes.remove(mergedAllReceivedNesMap.get(outageExportableAllNe.getObjectId()));
                mergedAllReceivedNes.add(outageExportableAllNe);
            }
        }
        return OperationKey.LOAD_OUTAGE_SETTINGS_ITEMS;
    }

    @Override
    public OperationKey handle(FetchExportLocationDataJob fetchExportLocationDataJob, Object result) {
        if (((List) result).isEmpty()) {
            return OperationKey.NOTHING_TO_DO;
        }
        ((List <ExportLocationDto>) result).forEach(exportLocationDto -> exportLocationDtoMap.put(exportLocationDto.getExportId(), exportLocationDto.getTransferSettings()));
        return OperationKey.LOAD_EXPORT_LOCATION_DATA;
    }
}
