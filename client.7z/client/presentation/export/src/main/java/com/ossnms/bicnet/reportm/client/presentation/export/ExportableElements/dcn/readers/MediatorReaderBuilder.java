package com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.dcn.readers;

import com.ossnms.bicnet.reportm.client.presentation.export.ExportableElements.ExportableElementBuilder;
import com.ossnms.bicnet.reportmanager.dto.ExportableItemDto;
import com.ossnms.bicnet.reportmanager.dto.ExportableReaderDto;
import com.ossnms.bicnet.reportmanager.dto.export.ExportableReaderType;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableReader;
import com.ossnms.bicnet.reportmanager.dto.export.dcn.MediatorExportReader;

public class MediatorReaderBuilder implements ExportableElementBuilder<IExportableReader> {

    @Override
    public boolean acceptReader(ExportableReaderDto readerDto) {
        return readerDto.getReaderType() == ExportableReaderType.MEDIATOR;
    }

    @Override
    public IExportableReader buildItem(Iterable<IExportableReader> readers, ExportableItemDto itemDto) {
        return null;
    }

    @Override
    public IExportableReader buildReader(ExportableReaderDto readerDto) {
        MediatorExportReader mediatorExportReader = new MediatorExportReader();
        mediatorExportReader.setSelection(1);
        return mediatorExportReader;
    }

    @Override
    public boolean acceptItem(ExportableItemDto itemDto) {
        return false;
    }
}
