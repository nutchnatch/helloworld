package com.ossnms.bicnet.reportm.client.presentation.export.outage.views;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecordFilterCondition;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecordFilter;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.command.FrameworkButtonCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommitButton;
import com.ossnms.bicnet.framework.client.utils.FrameworkCloseCommand;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.models.ExportItemNode;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.api.views.AbstractView;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.commands.OutageManualExportCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.outage.documents.OutageManualExportDocument;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.reportmanager.dto.export.IReportManagerExportItem;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.JfxOptionsData;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxLabel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.swing.*;
import javax.swing.event.ChangeListener;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import static java.util.Arrays.stream;
import static javax.swing.SwingUtilities.invokeLater;

public class OutageManualExportView extends AbstractView {
    private static final long serialVersionUID = 8097288812277112526L;
    
    private static final String VIEW_ID = OutageManualExportView.class.getName();
    private static final Logger LOGGER = LoggerFactory.getLogger(OutageManualExportView.class);
    
    private static final int WINDOW_WIDTH = 420;
    private static final int WINDOW_HEIGHT = 350;

    private boolean changeOccured;
    private Iterable<IExportableItem> exportableItems;

    private final JTabbedPane mainComponent = new JTabbedPane();
    
    private JPanel nesPanel = new JPanel(new GridBagLayout());
    private JfxLabel nesSelectedValidationLabel = new JfxLabel();
    protected JfxLabel selectedNesLabel;
    
    private ToggleButtonTree<ExportItemNode> itemsTree;
    private OutageExportableItemsModel itemsTreeModel = new OutageExportableItemsModel();
    
    private OutageExportSettingsPanel settingsPanel;
    
    private final JLabel fieldsValidationLabel = new JLabel();
    
    private final StartCommand startCommand = new StartCommand();
    private final FrameworkCloseCommand frameworkCloseCommand = new FrameworkCloseCommand(this, JfxStringTable.IDS_Close_WITHOUT_MNEMONIC.toString());

    public OutageManualExportView(@Nonnull String title, @Nonnull OutageManualExportDocument doc) throws BcbException {
        super(VIEW_ID, title, doc, false, HelpIds.HID_MANUAL_ALARMS_OUTAGE_EXPORT);
        initSelectableTreeModel();
        getFrameworkDocument().outageGetNes();
        getFrameworkDocument().outageGetFilter();
        initLayout();
        setGuiNames();
        initControls();
        doc.getPluginHelper().getCfPluginSite().addClientPropertyListener(this);
        setActivityIndicatorVisible(true);
    }

    private void initLayout() {
        mainComponent.setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        
        settingsPanel = new OutageExportSettingsPanel(fieldsValidationLabel, new Date(), new Date());
        settingsPanel.selectAllCheckboxes();
        settingsPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        settingsPanel.addItemListener(itemListener);
        settingsPanel.addChangeListener(changeListener);
        
        settingsPanel.add(fieldsValidationLabel, new GridBagConstraints(0, 4, 2, 1, 1.0, 0.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        
        mainComponent.add(ExportLabels.ALARMS_OUTAGE_EXPORT_SETTINGS_TAB.toString(), settingsPanel);
        mainComponent.add(ExportLabels.ALARMS_OUTAGE_EXPORT_NES_TAB.toString(), nesPanel);
        
        createNesTab();
    }
    
    private void createNesTab() {
        nesPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        nesPanel.setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        
        nesSelectedValidationLabel.setMinimumSize(new Dimension(16, 16));
        nesSelectedValidationLabel.setPreferredSize(new Dimension(16, 16));

        itemsTree.setClickInToggleButtonOnly(true);
        itemsTree.setRootVisible(true);
        itemsTree.setDigInMode(true);
        itemsTree.getSelectionModel().setSelectionMode(TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
        itemsTree.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                int index = itemsTree.getRowForLocation(e.getX(), e.getY());
                if (index >= 0) {
                    updateTreePane();
                    itemsTreeModel.reload();
                    isAnyNeSelected();
                    startCommand.updateAction();
                }
            }
        });
        
        selectedNesLabel = new JfxLabel(ExportLabels.ALARMS_OUTAGE_EXPORT_SELECTEDNES.guiName());
        JPanel treePane = new JPanel(new BorderLayout());
        treePane.add(new JScrollPane(itemsTree), BorderLayout.CENTER);
        selectedNesLabel.setLabelAndMnemonicFor(treePane);
        
        nesPanel.add(selectedNesLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        nesPanel.add(treePane, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        nesPanel.add(nesSelectedValidationLabel, new GridBagConstraints(0, 2, 2, 1, 1.0, 0.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
    }

    private void initSelectableTreeModel() {
        itemsTreeModel = new OutageExportableItemsModel();
        itemsTree = new ToggleButtonTree<>(itemsTreeModel);
        itemsTreeModel.setSelectionModel(itemsTree.getToggleButtonTreeSelectionModel());
        itemsTreeModel.setAllSelected();
    }

    private void setGuiNames() {
        mainComponent.setName("PANEL.AlarmsOutageReports");
        settingsPanel.setName("PANEL.TabSettings");
        nesPanel.setName("PANEL.TabNes");
    }
    
    private final ItemListener itemListener = event -> startCommand.updateAction();

    private final ChangeListener changeListener = e -> startCommand.updateAction();

    private boolean isAnyNeSelected() {
        if(itemsTreeModel.isAnyNodeSelected()) {
            hideWarningIcon(nesSelectedValidationLabel);
            return true;
        }
        
        showWarningIcon(nesSelectedValidationLabel, ExportLabels.ALARMS_OUTAGE_EXPORT_NES_SELECTED_WARNING.toString());
        return false;
    }
    
    /**
     * Shows warning icon plus a label and/or tooltip messages in the specified JfxLabel field.
     */
    private static void showWarningIcon(JLabel warningLabel, String textMessage) {
        warningLabel.setIcon(ResourcesIconFactory.ICON_STATUS_WARNING_16.getImageIcon());
        warningLabel.setText(textMessage);
    }

    /**
     * Hides the icon and messages of the specified JfxLabel field.
     */
    private static void hideWarningIcon(JLabel warningLabel) {
        warningLabel.setIcon(null);
        warningLabel.setText("");
    }    
    
    @Override
    public void updateData(Object o) {
        if (o == OperationKey.LOAD_OUTAGE_ALL_NES_ITEMS) {
            loadData(getFrameworkDocument().getOutageExportableAllNes());
            setActivityIndicatorVisible(false);
            
        } else if (o == OperationKey.MANUAL_EXPORT_JOB_EXECUTED) {
            close();
        }
    }

    @Override
    protected void initKeyBindings() {
        getComponent().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "Esc");
        getComponent().getActionMap().put("Esc", frameworkCloseCommand);
    }
    
    @Override
    protected List<?> getFunctionActions() {
        List<Object> functionActions = new ArrayList<>();
        functionActions.add(startCommand);
        return functionActions;
    }
    
    @Override
    protected List<FrameworkCommitButton> getCommitActions() {
        List<FrameworkCommitButton> buttons = new ArrayList<FrameworkCommitButton>();
        buttons.add(new FrameworkCloseCommand(this));
        return buttons;
    }
    
    private class StartCommand extends FrameworkButtonCommand {
        private static final long serialVersionUID = -7767058096569490898L;

        StartCommand() {
            setCmdDetails(ExportLabels.IDS_EXPORT_START_BUTTON.toString(),
                    ExportLabels.IDS_EXPORT_START_BUTTON.toString(), null, null,
                    ExportLabels.ALARMS_OUTAGE_EXPORT_START_BUTTON_TOOLTIP.toString(),
                    ExportLabels.ALARMS_OUTAGE_EXPORT_START_BUTTON_TOOLTIP.toString(), null);
            setToolIcon(IconFactory.getIconWithOverlay(ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16, ActionType.ALARM));
            setPluginHelper(getFrameworkDocument().getPluginHelper());
            setSecurityId(Policies.ALARMS_OUTAGE_DATA.toString());
        }
        
        @Override
        public boolean isEnabled(IManagedObject[] selectedObjects) {
            return super.isEnabled(selectedObjects) && settingsPanel.areDateFieldsValid() && settingsPanel.isAnySeverityCheckboxSelected() && settingsPanel.isAnyStateCheckboxSelected() 
                    && getItemsTreeModel().isAnyNodeSelected();
        }
        
        @Override
        public boolean execute(IManagedObject[] iManagedObjects) {
            LOGGER.debug("Perform start alarm outage report");
            addAlarmFilterConditions();
            INEId[] neIds = stream(getItemsTreeModel().getAllSelectedNodes())
                    .map(IReportManagerExportItem::getObjectId)
                    .map(NEIdItem::new)
                    .toArray(INEId[]::new);
            getFrameworkDocument().outageExportData(getDocumentFilter(), neIds);
            close();
            return true;
        }
    }

    private ILogRecordFilter getDocumentFilter() {
        return getFrameworkDocument().getOutageExportFilter();
    }
    
    private void addAlarmFilterConditions() {
        IAlarmLogRecordFilterCondition alarmCondition = (IAlarmLogRecordFilterCondition) getDocumentFilter().newFilterCondition();
        getDocumentFilter().addFilterCondition(alarmCondition);
        
        alarmCondition.filterByRaisedTimeRange(settingsPanel.getStartDateCalendar().getDate(), settingsPanel.getEndDateCalendar().getDate(), Boolean.FALSE);
        alarmCondition.filterBySeverities(settingsPanel.getAllSeverityCheckboxesSelected().stream().toArray(AlarmSeverity[]::new), Boolean.FALSE);

        alarmCondition.filterByIsAcknowledged(settingsPanel.isAcknowledged());
        alarmCondition.filterByIsCleared(settingsPanel.isCleared());
    }

    @Override
    protected OutageManualExportDocument getFrameworkDocument() {
        return (OutageManualExportDocument) super.getFrameworkDocument();
    }
    
    @Override
    protected ImageIcon getViewIcon() {
        return ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16;
    }

    @Override
    protected ActionType getViewAction() {
        return ActionType.ALARM;
    }

    @Override
    protected JComponent getMainComponent() {
        return mainComponent;
    }
    
    private OutageExportableItemsModel getItemsTreeModel() {
        return itemsTreeModel;
    }

    private void loadData(Iterable<IExportableItem> exportableItems) {
        this.exportableItems = exportableItems;
        new LoadFetchData().execute();
    }

    private final class LoadFetchData extends SwingWorker<Boolean, Void> {

        @Override
        protected Boolean doInBackground() throws Exception {

            itemsTreeModel.initFromExportableItems(exportableItems);
            itemsTreeModel.setAllSelected();
            return null;
        }

        @Override
        protected void done() {
            updateTreePane();
        }
    }

    private void updateTreePane() {
        invokeLater(() -> {
            expandAll(itemsTree, new TreePath(itemsTree.getModel().getRoot()));
            itemsTree.updateUI();
        });
    }
    
    private void expandAll(JTree tree, TreePath parent) {
        TreeNode node = (TreeNode) parent.getLastPathComponent();
        if (!node.isLeaf()) {
            for (int i = 0; i < node.getChildCount(); i++) {
                TreePath path = parent.pathByAddingChild(node.getChildAt(i));
                expandAll(tree, path);
            }
        }
        tree.expandPath(parent);
    }
    
    @Override
    public String getCommandClassName() {
        return OutageManualExportCommand.class.getName();
    }

    @Override
    public boolean supportsPersistance() {
        return false;
    }

    @Override
    public JTable getDataToPrint() {
        return null;
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {
        settingsPanel.getStartDateCalendar().setTimeZone(timeZone);
        settingsPanel.getEndDateCalendar().setTimeZone(timeZone);
    }

    @Override
    public void addClientLogEntry(String aMessage, Exception aEx) {
        
    }

    @Override
    protected String getProfileId() {
        return null;
    }

    @Override
    protected JfxOptionsData getOptionsData() {
        return null;
    }

//    @Override
//    protected void loadLdapSettings(JfxOptionsData aProfile) {
//
//    }
//
//    @Override
//    protected void saveLdapSettings(JfxOptionsData aProfile) {
//
//    }

    @Override
    protected void loadSettings(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveSettings(JfxOptionsData aProfile) {

    }


    @Override
    protected void loadFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected IPluginSecurityProvider getSecurityProvider() throws BiCNetPluginException {
        return null;
    }

    @Override
    protected ISecureClientSession getSecureClientSession() throws BiCNetPluginException {
        return null;
    }
}