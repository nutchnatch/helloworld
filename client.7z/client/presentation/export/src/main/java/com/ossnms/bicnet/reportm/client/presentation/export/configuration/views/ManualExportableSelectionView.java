package com.ossnms.bicnet.reportm.client.presentation.export.configuration.views;

import static javax.swing.SwingUtilities.invokeLater;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.Nonnull;
import javax.swing.*;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.command.FrameworkButtonCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommitButton;
import com.ossnms.bicnet.framework.client.utils.FrameworkCloseCommand;
import com.ossnms.bicnet.reportm.client.api.documents.OperationKey;
import com.ossnms.bicnet.reportm.client.api.models.ExportItemNode;
import com.ossnms.bicnet.reportm.client.api.ui.utils.HelpIds;
import com.ossnms.bicnet.reportm.client.api.views.AbstractView;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands.ConfigurationManualOpenCommand;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.documents.ConfigurationManualExportDocument;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportmanager.dto.export.IExportableItem;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.JfxOptionsData;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxLabel;

public class ManualExportableSelectionView extends AbstractView {
    private static final long serialVersionUID = -8388859387947868358L;
    
    private ToggleButtonTree<ExportItemNode> itemsTree;
    private ExportableItemsModel itemsTreeModel;

    private static final String VIEW_ID = ManualExportableSelectionView.class.getName();
    private static final boolean NOT_RESIZABLE = false;
    private static final Logger LOGGER = LoggerFactory.getLogger(ManualExportableSelectionView.class);
    private static final int WINDOW_WIDTH = 400;
    private static final int WINDOW_HEIGHT = 300;

    private final JPanel mainPanel = new JPanel();
    private JfxLabel selectNesLabel;
    private Iterable<IExportableItem> exportableItems;

    private final ManualCommand manualCommand = new ManualCommand();

    private final FrameworkCloseCommand frameworkCloseCommand = new FrameworkCloseCommand(this, JfxStringTable.IDS_Close_WITHOUT_MNEMONIC.toString());

    public ManualExportableSelectionView(@Nonnull String title, @Nonnull ConfigurationManualExportDocument doc) throws BcbException {
        super(VIEW_ID, title, doc, NOT_RESIZABLE, HelpIds.HID_MANUAL_EXPORT);
        setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        initLayout();
        initControls();
        manualCommand.updateAction();
    }

    @Override
    protected List<?> getFunctionActions() {
        List<Object> functionActions = new ArrayList<>();
        manualCommand.setComponentName("Start");
        functionActions.add(manualCommand);
        return functionActions;
    }

    private void initLayout() {
        removeAll();

        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        itemsTreeModel = new ExportableItemsModel();

        itemsTree = new ToggleButtonTree<>(itemsTreeModel);
        itemsTreeModel.setSelectionModel(itemsTree.getToggleButtonTreeSelectionModel());

        itemsTree.setClickInToggleButtonOnly(true);
        itemsTree.setRootVisible(true);
        itemsTree.setDigInMode(true);
        itemsTree.getSelectionModel().setSelectionMode(TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
        itemsTree.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                int index = itemsTree.getRowForLocation(e.getX(), e.getY());
                if (index >= 0) {
                    updateTreePane();
                    getItemsTreeModel().reload();
                }
            }
        });

        selectNesLabel = new JfxLabel(ExportLabels.MANUAL_EXPORTABLE_LABEL.guiName());
        JPanel treePane = new JPanel(new BorderLayout());
        treePane.add(new JScrollPane(itemsTree), BorderLayout.CENTER);
        selectNesLabel.setLabelAndMnemonicFor(treePane);
        
        mainPanel.add(selectNesLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        mainPanel.add(treePane, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        setGuiNames();
    }

    private void setGuiNames() {
        mainPanel.setName("PANEL.Main");
        setName("ItemSelection");
        itemsTree.setName("FIELD.ItemsTree");
    }

    private ExportableItemsModel getItemsTreeModel() {
        return itemsTreeModel;
    }

    private void loadData(Iterable<IExportableItem> exportableItems) {
        this.exportableItems = exportableItems;
        new LoadFetchData().execute();
    }

    private final class LoadFetchData extends SwingWorker<Boolean, Void> {

        @Override
        protected Boolean doInBackground() throws Exception {
            itemsTreeModel.initFromExportableItems(exportableItems);
            itemsTreeModel.setAllSelected();
            return null;
        }

        @Override
        protected void done() {
            getExportedData();
        }
    }

    private void getExportedData() {
        updateTreePane();
    }

    private void updateTreePane() {
        invokeLater(() -> {
            expandAll(itemsTree, new TreePath(itemsTree.getModel().getRoot()));
            itemsTree.updateUI();
        });
    }

    private void expandAll(JTree tree, TreePath parent) {
        TreeNode node = (TreeNode) parent.getLastPathComponent();
        if (!node.isLeaf()) {
            for (int i = 0; i < node.getChildCount(); i++) {
                TreePath path = parent.pathByAddingChild(node.getChildAt(i));
                expandAll(tree, path);
            }
        }
        tree.expandPath(parent);
    }

    private class ManualCommand extends FrameworkButtonCommand {
        private static final long serialVersionUID = -5661469466349906468L;

        ManualCommand() {
            setCmdDetails(ExportLabels.MANUAL_CONFIGURATION_EXPORT_START_BUTTON.toString(),
                    ExportLabels.MANUAL_CONFIGURATION_EXPORT_START_BUTTON.toString(), null, null,
                    ExportLabels.MANUAL_CONFIGURATION_EXPORT_START_BUTTON_TOOLTIP.toString(),
                    ExportLabels.MANUAL_CONFIGURATION_EXPORT_START_BUTTON_TOOLTIP.toString(), null);
            setPluginHelper(getFrameworkDocument().getPluginHelper());
        }

        @Override
        public boolean execute(IManagedObject[] iManagedObjects) {
            LOGGER.debug("Perform Configuration Export");
            getFrameworkDocument().configurationExportData(getItemsTreeModel().getAllSelectedNodes(), getFrameworkDocument().getEcsContribution().getTransferSettings());
            close();
            return true;
        }
    }

    @Override
    public ConfigurationManualExportDocument getFrameworkDocument() {
        return (ConfigurationManualExportDocument) super.getFrameworkDocument();
    }

    @Override
    protected ImageIcon getViewIcon() {
        return ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16;
    }

    @Override
    protected ActionType getViewAction() {
        return ActionType.UNKNOWN;
    }

    @Override
    public String getCommandClassName() {
        return ConfigurationManualOpenCommand.class.getName();
    }

    @Override
    public boolean supportsPersistance() {
        return false;
    }

    @Override
    public JTable getDataToPrint() {
        return new JTable();
    }

    @Override
    public void timeDisplayChangeActions(TimeZone timeZone) {

    }

    @Override
    protected JComponent getMainComponent() {
        return mainPanel;
    }

    @Override
    protected List<FrameworkCommitButton> getCommitActions() {
        List<FrameworkCommitButton> functionActions = new ArrayList<>();
        functionActions.add(frameworkCloseCommand);
        return functionActions;
    }

    @Override
    protected void initKeyBindings() {
        getComponent().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "Esc");
        getComponent().getActionMap().put("Esc", frameworkCloseCommand);
    }

    @Override
    public void eventOpened() {
        super.eventOpened();
        setActivityIndicatorVisible(true);
    }

    @Override
    public void updateData(Object o) {
        if (o == OperationKey.LOAD_EXPORTABLE_ITEMS) {
            loadData(getFrameworkDocument().getManualExportableItems());
            setActivityIndicatorVisible(false);
        } else if (o == OperationKey.MANUAL_EXPORT_JOB_EXECUTED) {
            close();
        }
    }

    @Override
    public void addClientLogEntry(String s, Exception e) {

    }

    @Override
    protected String getProfileId() {
        return null;
    }

    @Override
    protected JfxOptionsData getOptionsData() {
        return null;
    }

//    @Override
//    protected void loadLdapSettings(JfxOptionsData jfxOptionsData) {
//
//    }
//
//    @Override
//    protected void saveLdapSettings(JfxOptionsData jfxOptionsData) {
//
//    }

    @Override
    protected void loadSettings(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected void saveSettings(JfxOptionsData aProfile) {

    }


    @Override
    protected void loadFilter(JfxOptionsData aProfile) {

    }

    @Override
    protected IPluginSecurityProvider getSecurityProvider() throws BiCNetPluginException {
        return null;
    }

    @Override
    protected ISecureClientSession getSecureClientSession() throws BiCNetPluginException {
        return null;
    }
}
