package com.ossnms.bicnet.reportm.client.presentation.export.inventory.documents;

import com.ossnms.bicnet.bcb.model.ecs.TransferSettings;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceContribution;
import com.ossnms.bicnet.bcb.plugin.ecs.BiCNetPluginExternalCommunicationServiceProvider;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.export.documents.AbstractExportDocument;
import com.ossnms.bicnet.reportmanager.util.Constants;

import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.reportm.client.presentation.export.inventory.fetchjobs.InventoryExportJob;

public class InventoryExportDocument extends AbstractExportDocument {

    private BiCNetPluginExternalCommunicationServiceProvider serviceProvider;
    private BiCNetPluginExternalCommunicationServiceContribution ecsContribution;
    /**
     * Execute Inventory Export Data operation
     * @param transferSettings
     */
    public void inventoryExportData(TransferSettings transferSettings) {
        FrameworkFetchJob job = new InventoryExportJob(this, transferSettings);
        try {
            executeFetchJob(job);
        } catch (FrameworkException e) {
            getLogger().error("Error executing InventoryExportJob.", e);
        }
    }

    @Override
    public void fetchOtherData() {

    }

    @Override
    protected String getReportId() {
        return Constants.INVENTORY_EXPORT_REPORT;
    }

    public void setExternalCommunicationService() {
        serviceProvider =  RMPluginHelperImpl.getInstance().getPluginExternalCommunicationService();
        ecsContribution = serviceProvider.getContribution();
    }

    public BiCNetPluginExternalCommunicationServiceProvider getServiceProvider() {
        return serviceProvider;
    }

    public BiCNetPluginExternalCommunicationServiceContribution getEcsContribution() {
        return ecsContribution;
    }
}
