/*
 * Copyright (C) Coriant
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.bicnet.reportm.client.presentation.export.configuration.commands;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.bicnet.framework.client.command.FrameworkCommand;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandHandler;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandID;
import com.ossnms.bicnet.framework.client.command.FrameworkCommandRegistrar;
import com.ossnms.bicnet.framework.client.command.IFrameworkCommand;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginViewFactory;
import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.bicnet.reportm.client.api.plugin.RMPluginHelperImpl;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.documents.ConfigurationScheduleDocument;
import com.ossnms.bicnet.reportm.client.presentation.export.configuration.views.ConfigurationScheduleView;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory;
import com.ossnms.bicnet.reportm.client.utilities.export.icons.IconFactory.ActionType;
import com.ossnms.bicnet.reportm.client.utilities.i18n.ExportLabels;
import com.ossnms.bicnet.reportm.client.utilities.i18n.Policies;
import com.ossnms.bicnet.resources.ResourcesIconFactory;

/**
 * Responsible for Export Window
 */
public class ConfigurationScheduleOpenCommand extends FrameworkCommand {
    private static final long serialVersionUID = 9012871112654855487L;
    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationManualOpenCommand.class);
    public static final FrameworkCommandID COMMAND_ID = new FrameworkCommandID(ConfigurationScheduleOpenCommand.class.getName());
    
    static {
        ConfigurationScheduleOpenCommand cmd = new ConfigurationScheduleOpenCommand();
        FrameworkCommandRegistrar.getUICmdRegister().registerCmd(cmd);
    }
    
    public ConfigurationScheduleOpenCommand() {
        setCmdDetails(ExportLabels.IDS_EXPORT_SCHEDULE_BUTTON.toString(),
                ExportLabels.IDS_EXPORT_SCHEDULE_BUTTON.toString(), null, null,
                ExportLabels.CONFIGURATION_EXPORT_SCHEDULE_BUTTON_TOOLTIP.toString(),
                ExportLabels.CONFIGURATION_EXPORT_SCHEDULE_BUTTON_TOOLTIP.toString(), null);

        setCommandID(COMMAND_ID);
        setToolIcon(IconFactory.getIconWithOverlay(ResourcesIconFactory.ICON_WINDOW_REPORT_MANAGER_16, ActionType.SCHEDULED));
        setActionListener(new FrameworkCommandHandler(COMMAND_ID));
        setPluginHelper(RMPluginHelperImpl.getInstance());
        setSecurityId(Policies.EXPORT_CONFIGURATION_DATA.toString());
    }

    @Override
    public boolean execute(IManagedObject[] selectedObjects) {
        LOGGER.debug("Open Configuration Schedule Export Window");
        
        FrameworkPluginViewFactory.createView(ConfigurationScheduleDocument.class, ConfigurationScheduleView.class,
                ExportLabels.CONFIGURATION_SCHEDULE_EXPORT_TITLE.toString(), selectedObjects, RMPluginHelperImpl.getInstance(),
                this, BiCNetPluginFrameType.INTERNAL);

        return true;
    }

    @Override
    public IFrameworkCommand clone(IManagedObject[] selectedObjects) {
        return new ConfigurationScheduleOpenCommand();
    }

    /**
     * Brings this view to the front
     * @see com.ossnms.bicnet.framework.client.command.FrameworkCommand#bringViewToFront(com.ossnms.bicnet.bcb.plugin.BiCNetPluginView)
     */
    @Override
    public void bringViewToFront(final BiCNetPluginView view) {
        if (!(view instanceof FrameworkView)) {
            return;
        }
        ((FrameworkView) view).bringToFront();
    }
}