package com.bnpp.cardif.sesame.security;

import javax.xml.ws.BindingProvider;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnppa.sesame.services.standard.proxy.AuthenticationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.AuthenticationServicesWSPService;
import com.bnppa.sesame.services.standard.proxy.AuthorizationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.AuthorizationServicesWSPService;
import com.bnppa.sesame.services.standard.proxy.IdentityServicesWSP;
import com.bnppa.sesame.services.standard.proxy.IdentityServicesWSPService;

@Component
@Scope("singleton")
// default value specified to be obvious.
public class SesameWebServiceFactory
{
    private AuthorizationServicesWSPService authorizationServicesWSPService = new AuthorizationServicesWSPService();

    private IdentityServicesWSPService identityServicesWSPService = new IdentityServicesWSPService();

    private AuthenticationServicesWSPService authenticationServicesWSPService = new AuthenticationServicesWSPService();

    @Value("${sesame-web-service.authorization.url}")
    private String authorizationEndpointUrl;

    @Value("${sesame-web-service.identity.url}")
    private String identityEndpointUrl;

    @Value("${sesame-web-service.authentication.url}")
    private String authenticationEndpointUrl;

    public SesameWebServiceFactory()
    {
    }

    /**
     * Get an {@link AuthenticationServicesWSP} web service client.
     * 
     * @return the proxy
     */
    public AuthenticationServicesWSP getAuthenticationServicesWSP()
    {
        AuthenticationServicesWSP authenticationServicesWSP = authenticationServicesWSPService
                .getAuthenticationServicesWSP();
        BindingProvider authenticationServicesWSPBp = (BindingProvider) authenticationServicesWSP;
        authenticationServicesWSPBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                authenticationEndpointUrl);
        return authenticationServicesWSP;
    }

    /**
     * Get an {@link AuthorizationServicesWSP} web service client.
     * 
     * @return the proxy
     */
    public AuthorizationServicesWSP getAuthorizationServicesWSP()
    {
        AuthorizationServicesWSP authorizationServicesWSP = authorizationServicesWSPService
                .getAuthorizationServicesWSP();
        BindingProvider authorizationServicesWSPBp = (BindingProvider) authorizationServicesWSP;
        authorizationServicesWSPBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                authorizationEndpointUrl);
        return authorizationServicesWSP;
    }

    /**
     * Get an {@link IdentityServicesWSP} web service client.
     * 
     * @return the proxy
     */
    public IdentityServicesWSP getIdentityServicesWSP()
    {
        IdentityServicesWSP identityServicesWSP = identityServicesWSPService.getIdentityServicesWSP();
        BindingProvider identityServicesWSPBp = (BindingProvider) identityServicesWSP;
        identityServicesWSPBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, identityEndpointUrl);
        return identityServicesWSP;
    }

    public String getAuthorizationEndpointUrl()
    {
        return authorizationEndpointUrl;
    }

    public void setAuthorizationEndpointUrl(String authorizationEndpointUrl)
    {
        this.authorizationEndpointUrl = authorizationEndpointUrl;
    }

    public String getIdentityEndpointUrl()
    {
        return identityEndpointUrl;
    }

    public void setIdentityEndpointUrl(String identityEndpointUrl)
    {
        this.identityEndpointUrl = identityEndpointUrl;
    }

    public String getAuthenticationEndpointUrl()
    {
        return authenticationEndpointUrl;
    }

    public void setAuthenticationEndpointUrl(String authenticationEndpointUrl)
    {
        this.authenticationEndpointUrl = authenticationEndpointUrl;
    }
}
