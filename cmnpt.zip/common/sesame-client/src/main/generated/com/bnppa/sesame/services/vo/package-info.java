@javax.xml.bind.annotation.XmlSchema(namespace = "http://vo.services.sesame.bnppa.com")
package com.bnppa.sesame.services.vo;
