
package com.bnppa.sesame.services.standard.proxy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="getJoiningsReturn" type="{http://proxy.standard.services.sesame.bnppa.com}ArrayOf_tns3_nillable_Joining"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getJoiningsReturn"
})
@XmlRootElement(name = "getJoiningsResponse")
public class GetJoiningsResponse {

    @XmlElement(required = true, nillable = true)
    protected ArrayOfTns3NillableJoining getJoiningsReturn;

    /**
     * Gets the value of the getJoiningsReturn property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTns3NillableJoining }
     *     
     */
    public ArrayOfTns3NillableJoining getGetJoiningsReturn() {
        return getJoiningsReturn;
    }

    /**
     * Sets the value of the getJoiningsReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTns3NillableJoining }
     *     
     */
    public void setGetJoiningsReturn(ArrayOfTns3NillableJoining value) {
        this.getJoiningsReturn = value;
    }

}
