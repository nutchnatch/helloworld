
package com.bnppa.sesame.services.standard.proxy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnppa.sesame.services.vo.AccountId;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="accountId" type="{http://vo.services.sesame.bnppa.com}AccountId"/&gt;
 *         &lt;element name="secretResponses" type="{http://proxy.standard.services.sesame.bnppa.com}ArrayOf_tns3_nillable_SecretResponse"/&gt;
 *         &lt;element name="applicationCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="channelType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="channelMessageFormatCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="channelMessageParameters" type="{http://proxy.standard.services.sesame.bnppa.com}ArrayOf_tns4_nillable_KeyValue"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "accountId",
    "secretResponses",
    "applicationCode",
    "channelType",
    "channelMessageFormatCode",
    "channelMessageParameters"
})
@XmlRootElement(name = "resetAndSendPasswordBySecretResponses")
public class ResetAndSendPasswordBySecretResponses {

    @XmlElement(required = true, nillable = true)
    protected AccountId accountId;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfTns3NillableSecretResponse secretResponses;
    @XmlElement(required = true, nillable = true)
    protected String applicationCode;
    @XmlElement(required = true, nillable = true)
    protected String channelType;
    @XmlElement(required = true, nillable = true)
    protected String channelMessageFormatCode;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfTns4NillableKeyValue channelMessageParameters;

    /**
     * Gets the value of the accountId property.
     * 
     * @return
     *     possible object is
     *     {@link AccountId }
     *     
     */
    public AccountId getAccountId() {
        return accountId;
    }

    /**
     * Sets the value of the accountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountId }
     *     
     */
    public void setAccountId(AccountId value) {
        this.accountId = value;
    }

    /**
     * Gets the value of the secretResponses property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTns3NillableSecretResponse }
     *     
     */
    public ArrayOfTns3NillableSecretResponse getSecretResponses() {
        return secretResponses;
    }

    /**
     * Sets the value of the secretResponses property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTns3NillableSecretResponse }
     *     
     */
    public void setSecretResponses(ArrayOfTns3NillableSecretResponse value) {
        this.secretResponses = value;
    }

    /**
     * Gets the value of the applicationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationCode() {
        return applicationCode;
    }

    /**
     * Sets the value of the applicationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationCode(String value) {
        this.applicationCode = value;
    }

    /**
     * Gets the value of the channelType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelType() {
        return channelType;
    }

    /**
     * Sets the value of the channelType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelType(String value) {
        this.channelType = value;
    }

    /**
     * Gets the value of the channelMessageFormatCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelMessageFormatCode() {
        return channelMessageFormatCode;
    }

    /**
     * Sets the value of the channelMessageFormatCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelMessageFormatCode(String value) {
        this.channelMessageFormatCode = value;
    }

    /**
     * Gets the value of the channelMessageParameters property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTns4NillableKeyValue }
     *     
     */
    public ArrayOfTns4NillableKeyValue getChannelMessageParameters() {
        return channelMessageParameters;
    }

    /**
     * Sets the value of the channelMessageParameters property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTns4NillableKeyValue }
     *     
     */
    public void setChannelMessageParameters(ArrayOfTns4NillableKeyValue value) {
        this.channelMessageParameters = value;
    }

}
