@javax.xml.bind.annotation.XmlSchema(namespace = "http://proxy.standard.services.sesame.bnppa.com")
package com.bnppa.sesame.services.standard.proxy;
