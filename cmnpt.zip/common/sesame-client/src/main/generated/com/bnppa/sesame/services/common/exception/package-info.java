@javax.xml.bind.annotation.XmlSchema(namespace = "http://exception.common.services.sesame.bnppa.com")
package com.bnppa.sesame.services.common.exception;
