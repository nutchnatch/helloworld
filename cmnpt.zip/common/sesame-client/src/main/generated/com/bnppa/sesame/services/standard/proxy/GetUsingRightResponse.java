
package com.bnppa.sesame.services.standard.proxy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnppa.sesame.services.common.model.UsingRight;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="getUsingRightReturn" type="{http://model.common.services.sesame.bnppa.com}UsingRight"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getUsingRightReturn"
})
@XmlRootElement(name = "getUsingRightResponse")
public class GetUsingRightResponse {

    @XmlElement(required = true, nillable = true)
    protected UsingRight getUsingRightReturn;

    /**
     * Gets the value of the getUsingRightReturn property.
     * 
     * @return
     *     possible object is
     *     {@link UsingRight }
     *     
     */
    public UsingRight getGetUsingRightReturn() {
        return getUsingRightReturn;
    }

    /**
     * Sets the value of the getUsingRightReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link UsingRight }
     *     
     */
    public void setGetUsingRightReturn(UsingRight value) {
        this.getUsingRightReturn = value;
    }

}
