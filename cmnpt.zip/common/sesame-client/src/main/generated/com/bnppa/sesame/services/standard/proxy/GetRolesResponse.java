
package com.bnppa.sesame.services.standard.proxy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="getRolesReturn" type="{http://proxy.standard.services.sesame.bnppa.com}ArrayOf_xsd_nillable_string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "getRolesReturn"
})
@XmlRootElement(name = "getRolesResponse")
public class GetRolesResponse {

    @XmlElement(required = true, nillable = true)
    protected ArrayOfXsdNillableString getRolesReturn;

    /**
     * Gets the value of the getRolesReturn property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfXsdNillableString }
     *     
     */
    public ArrayOfXsdNillableString getGetRolesReturn() {
        return getRolesReturn;
    }

    /**
     * Sets the value of the getRolesReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfXsdNillableString }
     *     
     */
    public void setGetRolesReturn(ArrayOfXsdNillableString value) {
        this.getRolesReturn = value;
    }

}
