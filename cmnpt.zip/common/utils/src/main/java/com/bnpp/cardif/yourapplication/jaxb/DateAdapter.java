package com.bnpp.cardif.yourapplication.jaxb;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Allows {@link Date} adpatation for JAXB marshalling and unmarshalling. <br/>
 * It is typically used for JAXB bindings
 * 
 */
public class DateAdapter
{
    private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS Z";

    private DateAdapter()
    {
    }

    public static Date parseDateTime(String s)
    {
        if (s == null)
        {
            return null;
        }
        try
        {
            SimpleDateFormat parserSDF = new SimpleDateFormat(DATE_FORMAT);
            parserSDF.setTimeZone(TimeZone.getDefault());
            return parserSDF.parse(s);
        }
        catch (ParseException e)
        {
            throw new IllegalArgumentException("Error parsing date, date : " + s + "cannot be parsed to format : "
                    + DATE_FORMAT);
        }
    }

    public static String printDateTime(Date dt)
    {
        if (dt == null)
        {
            return null;
        }
        SimpleDateFormat parserSDF = new SimpleDateFormat(DATE_FORMAT);
        parserSDF.setTimeZone(TimeZone.getDefault());
        return parserSDF.format(dt);
    }
}
