package com.bnpp.cardif.yourapplication.exception;

/**
 * Base class for all the application exceptions.
 * 
 * @author 831743
 *
 */
public abstract class ApplicationException extends Exception
{
    private static final long serialVersionUID = 5093584926530576256L;

    private String code;

    /**
     * Empty constructor
     */
    protected ApplicationException()
    {
    }

    /**
     * constructor
     * 
     * @param message
     */
    protected ApplicationException(String message)
    {
        super(message);
    }

    /**
     * constructor
     * 
     * @param message
     * @param cause
     */
    protected ApplicationException(String message, Throwable cause)
    {
        super(message, cause);
    }

    /**
     * constructor
     * 
     * @param code
     * @param message
     * @param cause
     */
    protected ApplicationException(String code, String message, Throwable cause)
    {
        super(message, cause);
        this.code = code;
    }

    /**
     * @return the code
     */
    public String getCode()
    {
        return code;
    }

    /**
     * @param code
     *            the code to set
     */
    public void setCode(String code)
    {
        this.code = code;
    }

}