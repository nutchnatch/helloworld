Samples &amp; Walkthroughs
============================


validate-request-middleware
--------------------------
Comprises the following purposes:
-> ensuring that every request complies with Swagger API definition, or returns appropriate HTTP error codes when it occours;
-> retrieving all the parameters provided with the requests;
-> retrieving and verifying all the parameter values (query items) provided in the requests.


To run this tool, follow these steps:
1- install node express:
	npm install express --save
2- install swagger middleware express:
	npm install swagger-express-middleware --save
3- run 
	node validate-request-middleware.js
	
It will be listening on: http://localhost:8000

Example of a call: with curl:
curl -X GET \
  'http://localhost:8000/business-scope/v1/folders?pageNumber=1&pageSize=20' \
  -H 'cache-control: no-cache' \
  -H 'postman-token: 17b5149d-141c-5558-bf44-c17d6c2f13c6' \
  -H 'x-api-key: 1234'