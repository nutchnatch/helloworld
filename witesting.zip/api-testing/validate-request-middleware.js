'use strict';
/*************************************************************************************
 * Ensures that every request compiles wuth Sugar web API, or returns appropriate HTTP 
 * error codes if needed.
 *************************************************************************************/

// Enable debug output
process.env.DEBUG = 'swagger:middleware';

var util       = require('util');
var express    = require('express');
var middleware = require('swagger-express-middleware');
var app        = express();

middleware('sugar-web-api-schema.yaml', app, function(err, middleware) {
    // Check metadata
    app.use(middleware.metadata());
    
    // Parse requests
    app.use(middleware.parseRequest());

    // Validate request
    app.use(middleware.validateRequest());

    // An HTML page to help you produce a validation error
    app.use(function(req, res, next) {
        res.type('html');
        res.send(
            '<h1>Request Middleware Validation. No problems detected on the supported request.</h1>' + 

            // Inspect request parameters
            '<h1>Parsed Query Params:</h1>' +
            '<pre>' + util.inspect(req.query) + '</pre>' + 
            '<h1>Parsed Query Body:</h1>' +
            '<pre>' + util.inspect(req.body) + '</pre>' + 

            // Supported Parameters
            util.format('<h1>%s has %d parameters</h1><pre>%s</pre>',
                req.swagger.pathName,
                req.swagger.params.length,
            util.inspect(req.swagger.params))
        );
    });
  

    // Error handler to display the validation error as HTML
    app.use(function(err, req, res, next) {
        res.status(err.status);
        res.send(
            '<h1>' + err.status + ' Error</h1>' +
            '<pre>' + err.message + '</pre>'
        );
    });

    app.listen(8000, function() {
        console.log('Go to http://localhost:8000');
    });
});