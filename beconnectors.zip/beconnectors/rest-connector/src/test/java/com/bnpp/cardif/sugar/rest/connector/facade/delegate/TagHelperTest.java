package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.SimpleTag;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagValueType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.web.context.SaveContextOnUpdateOrErrorResponseWrapper;

import java.util.Collections;
import java.util.Optional;
import java.util.stream.Stream;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.is;

/**
 * Created by b48489 on 21-12-2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class TagHelperTest extends AbstractTestHelper{

    @InjectMocks private TagHelper tagHelper;
    @Before
    public void setUp() {

        super.testSetUp();
    }

    @Test
    public void testGetTags() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        Tag tag = tagHelper.getTags(Collections.singletonList(TAG_SYMBOLIC_NAME), SCOPE).findFirst().get();
        assertThat(tag.getName(), is(TAG_SYMBOLIC_NAME));
        assertThat(tag.getType(), is(TagValueType.BOOLEAN.toString()));
    }

    @Test
    public void testGetAllTags() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        Tag tag = tagHelper.getAllTags(SCOPE).findFirst().get();
        assertThat(tag.getName(), is(TAG_SYMBOLIC_NAME));
        assertThat(tag.getType(), is(TagValueType.BOOLEAN.toString()));
    }

    @Test
    public void testGetTagByName() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        SimpleTag simpleTag = tagHelper.getTagsByName(Collections.singletonList(TAG_SYMBOLIC_NAME), SCOPE, "",
                "");
        assertThat(simpleTag.getTag().getName(), is(TAG_SYMBOLIC_NAME));
        assertThat(simpleTag.getTag().getType(), is(TagValueType.BOOLEAN.toString()));
    }
}
