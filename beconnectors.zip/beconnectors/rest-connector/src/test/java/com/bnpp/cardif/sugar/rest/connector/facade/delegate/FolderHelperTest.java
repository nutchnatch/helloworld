package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.filter.model.AllowedOperators;
import com.bnpp.cardif.sugar.rest.web.model.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * Created by b48489 on 21-12-2017.
 */

import org.junit.Test;

import java.util.stream.Stream;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.DOCUMENT_REMOVED_FROM_FOLDER;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.FOLDER_NOT_FOUND;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.TAG_BAD_FORMAT;
import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FolderHelperTest extends AbstractTestHelper {

    @InjectMocks private FolderHelper folderHelper;

    @Before
    public void setUp() {

        super.testSetUp();
    }

    @Test
    public void testGetFolders() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        PagedFolders pagedFolders = folderHelper.getFolders(1, 10, "", SCOPE, FOLDER_NAME,
                AllowedOperators.EQUALS_TO.getName(), CREATION_DATE, CREATION_DATE_OPERATION, FOLDER_TYPE, TAG_LIST,
                OPERATION_LIST, SORT_LIST, "", " ");
        assertTrue(pagedFolders.getStatus());
        assertNull(pagedFolders.getDetails());
        assertThat(pagedFolders.getPaging().getPageSize(), is(1));
        assertThat(pagedFolders.getFolders().get(0).getId(), is(getFolderId().getValue()));
    }

    @Test
    public void testGetFolderById() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        SimpleFolder simpleFolder = folderHelper.getFolderById(FOLDER_ID, "", SCOPE, ISSUER, SCHEME, "", "");
        assertTrue(simpleFolder.getStatus());
        assertNull(simpleFolder.getDetails());
        assertThat(simpleFolder.getFolder().getId(), is(FOLDER_ID));
    }

    @Test
    public void testFailGetFolderById() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        String wrongFolderId = "FakeFolder";
        SimpleFolder simpleFolder = folderHelper.getFolderById(wrongFolderId, "", SCOPE, ISSUER, SCHEME, "", "");
        assertFalse(simpleFolder.getStatus());
        assertThat(simpleFolder.getDetails(), is(FOLDER_NOT_FOUND.format()));
    }

    @Test
    public void testGetDocumentsFromFolderId() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureGetDocumentsByIds();
        PagedDocuments pagedDocuments = folderHelper.getDocumentsFromFolderId(FOLDER_ID, 1, 10, "", SCOPE, ISSUER, SCHEME, "", "");
        assertTrue(pagedDocuments.getStatus());
        assertNull(pagedDocuments.getDetails());
        assertThat(pagedDocuments.getDocuments().get(0).getId(), is(DOC_ID));
    }

    @Test
    public void testFolderUpdate() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureUpdateFolder();
        buildComposedFolderData();
        when(tagsHelperService.getTags(POLICY_TAG_LIST, SCOPE))
                .thenReturn(Stream.of(buildTag()))
                .thenReturn(Stream.of(buildTag()));
        FolderCreationResult folderCreationResult = folderHelper.updateFolder(FOLDER_ID, buildComposedFolderData(), "", SCOPE, "Close", ISSUER, SCHEME, "", "");
        assertTrue(folderCreationResult.getStatus());
        assertNull(folderCreationResult.getDetails());
        assertThat(folderCreationResult.getFolderId(), is(FOLDER_ID));
    }

    @Test
    public void testDeleteDocumentFromFolder() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureGetDocumentList();
        SimpleResponseResult simpleResponseResult = folderHelper.deleteDocumentFromFolder(FOLDER_ID, DOC_ID, SCOPE, SCHEME, ISSUER);
        assertTrue(simpleResponseResult.getStatus());
        assertThat(simpleResponseResult.getDetails(), is(DOCUMENT_REMOVED_FROM_FOLDER.format()));
    }

    private ComposedFolderData buildComposedFolderData() {

        ComposedFolderData composedFolderData = new ComposedFolderData();
        composedFolderData.setFolderTypeVersion(VERSION);
        composedFolderData.setTagList(TAG_LIST);
        composedFolderData.setFolderName(FODER_UPDATE_NAME);
        composedFolderData.setFolderTypeIssuer(ISSUER);
        composedFolderData.setFolderTypeId(FOLDER_TYPE);
        return composedFolderData;
    }
}
