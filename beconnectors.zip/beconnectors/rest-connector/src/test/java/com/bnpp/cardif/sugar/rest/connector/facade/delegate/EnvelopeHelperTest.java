package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.Collections;
import java.util.stream.Stream;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.DOCUMENTS_NOT_FOUND;
import static org.junit.Assert.*;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.*;

/**
 * Created by b48489 on 19-12-2017.
 */

@RunWith(MockitoJUnitRunner.class)
public class EnvelopeHelperTest extends AbstractTestHelper {

    @InjectMocks private EnvelopeHelper envelopeHelper;

    @Before
    public void setup() {

        super.testSetUp();
    }

    @Test
    public void testGetEnvelopes() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceFind(getEnvelope());

        PagedEnvelopes pagedEnvelopes = envelopeHelper.getEnvelopes(SCOPE, SORT_LIST, PAGE_NUMBER, PAGE_SIZE,
                CREATION_DATE, ENV_TYPE, CREATION_DATE_OPERATION, TAG_LIST, OPERATION_LIST);
        assertTrue(pagedEnvelopes.getStatus());
        assertNull(pagedEnvelopes.getDetails());
        assertThat(pagedEnvelopes.getPaging().getPageSize(), is(1));
        assertThat(pagedEnvelopes.getEnvelopes().get(0).getId(), is(getEnvelopeId().getValue()));
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testFailedWrongTagFormatGetEnvelopes() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceFind(getEnvelope());
        String wrongTagNameFormat = "policy";

        envelopeHelper.getEnvelopes(SCOPE, SORT_LIST, PAGE_NUMBER, PAGE_SIZE, CREATION_DATE, ENV_TYPE,
                CREATION_DATE_OPERATION, Collections.singletonList(wrongTagNameFormat), OPERATION_LIST);
    }

    @Test
    public void getTestDocumentsByEnvelopeId() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getEnvelopeId(), getEnvelope());

        PagedDocuments pagedDocuments = new PagedDocuments();
        pagedDocuments.setDocuments(Collections.singletonList(buildDocument()));
        pagedDocuments.setStatus(true);
        when(documentHelper.getDocumentsByIdList(SCOPE, Collections.singletonList(getDocId()))).thenReturn(pagedDocuments);
        PagedDocuments pagedEnvelopes = envelopeHelper.getDocumentsByEnvelopeId(ENVELOPE_ID, SCOPE, SORT_LIST, PAGE_NUMBER, PAGE_SIZE, ISSUER, SCHEME);
        assertTrue(pagedEnvelopes.getStatus());
        assertNull(pagedEnvelopes.getDetails());
        assertThat(pagedEnvelopes.getDocuments().get(0).getEnvelopeID(), is(getEnvelopeId().getValue()));
        assertThat(pagedEnvelopes.getDocuments().get(0).getName(), is(DOC_NAME));
    }

    @Test
    public void getTestFailedDocumentsByEnvelopeIdNotFound() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getEnvelopeId(), getEnvelope());

        String wrongEnvId = "415674d1-64e4-49yt-a174-515f9c874800";

        PagedDocuments pagedDocuments = new PagedDocuments();
        pagedDocuments.setDocuments(Collections.singletonList(buildDocument()));
        pagedDocuments.setStatus(true);
        when(documentHelper.getDocumentsByIdList(SCOPE, Collections.singletonList(getDocId()))).thenReturn(pagedDocuments);
        PagedDocuments pagedDocuments1 = envelopeHelper.getDocumentsByEnvelopeId(wrongEnvId, SCOPE, SORT_LIST, PAGE_NUMBER, PAGE_SIZE, ISSUER, SCHEME);
        assertFalse(pagedDocuments1.getStatus());
        assertThat(pagedDocuments1.getDetails(), is(DOCUMENTS_NOT_FOUND.format()));
    }

    @Test
    public void getTestFailedDocumentsNotFoundByEnvelopeId() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getEnvelopeId(), getEnvelope());

        getEnvelope().setChildObject(null);
        PagedDocuments pagedEnvelopes = envelopeHelper.getDocumentsByEnvelopeId(ENVELOPE_ID, SCOPE, SORT_LIST, PAGE_NUMBER, PAGE_SIZE, ISSUER, SCHEME);
        assertFalse(pagedEnvelopes.getStatus());
        assertThat(pagedEnvelopes.getDetails(), is(DOCUMENTS_NOT_FOUND.format()));
        assertNull(pagedEnvelopes.getDocuments());
    }

    @Test
    public void testGetEnvelopeById() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getEnvelopeId(), getEnvelope());

        SimpleEnvelope simpleEnvelope = envelopeHelper.getEnvelopeById(ENVELOPE_ID, SCOPE, ISSUER, SCHEME);
        assertTrue(simpleEnvelope.getStatus());
        assertThat(simpleEnvelope.getEnvelope().getId(), is(ENVELOPE_ID));
        assertNull(simpleEnvelope.getDetails());
    }

    @Test
    public void testUpdate() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getEnvelopeId(), getEnvelope());

        ComposedEnvelopeData composedEnvelopeData = buildComposedEnvelopeData();

        when(tagsHelperService.getTags(POLICY_TAG_LIST, SCOPE))
                .thenReturn(Stream.of(buildTag()))
                .thenReturn(Stream.of(buildTag()));
        EnvelopeOperationResult envelopeOperationResult = envelopeHelper.updateEnvelope(ENVELOPE_ID, composedEnvelopeData, "", SCOPE,
                "", "", ISSUER, SCHEME);
        assertTrue(envelopeOperationResult.getStatus());
        assertThat(envelopeOperationResult.getEnvelopeId(), is(ENV_UPDATE_NAME));
    }

    @Test
    public void testDeleteEnvelope() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getEnvelopeId(), getEnvelope());
        configureDocumentServiceDelete(getDocument());

        EnvelopeOperationResult envelopeOperationResult = envelopeHelper.deleteEnvelope(ENVELOPE_ID, "",
                SCOPE, ISSUER, SCHEME, "", "");

        assertTrue(envelopeOperationResult.getStatus());
        assertNull(envelopeOperationResult.getDetails());
        assertThat(envelopeOperationResult.getEnvelopeId(), is(ENVELOPE_ID));
    }

    private ComposedEnvelopeData buildComposedEnvelopeData() {
        ComposedEnvelopeData composedEnvelopeData = new ComposedEnvelopeData();
        composedEnvelopeData.setTagList(TAG_LIST);
        composedEnvelopeData.setDocuments(Collections.singletonList(buildComposedDocument()));
        composedEnvelopeData.setEnvelopeTypeIssuer(ISSUER);
        composedEnvelopeData.setEnvConfidentiality(ComposedEnvelopeData.EnvConfidentialityEnum.CONFIDENTIAL);
        return composedEnvelopeData;
    }
}
