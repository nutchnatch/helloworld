package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

/**
 * Created by b48489 on 14-12-2017.
 */
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.filter.model.AllowedOperators;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.DOCUMENTS_NOT_FOUND;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.DOCUMENT_NOT_FOUND;
import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import static org.junit.Assert.assertTrue;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

@RunWith(MockitoJUnitRunner.class)
public class DocumentHelperTest extends AbstractTestHelper {

    @InjectMocks private DocumentHelper documentHelper;

    @Before
    public void setUp() {

        super.testSetUp();
    }

    @Test
    public void testGetDocumentById() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getDocId(), getDocument());

        SimpleDocument simpleDocument = documentHelper.getDocumentById(SCOPE, DOC_ID, ISSUER, SCHEME);
        assertThat(simpleDocument.getDocument().getId(), is(DOC_ID));
        assertTrue(simpleDocument.getStatus());
    }

    @Test
    public void testFailGetDocumentById() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        String wrongDocId = "67e0t5r3-c241-4405-9590-7b14c6je574b";

        SimpleDocument simpleDocument = documentHelper.getDocumentById(SCOPE, wrongDocId, ISSUER, SCHEME);
        assertNull(simpleDocument.getDocument());
        assertFalse(simpleDocument.getStatus());
        assertThat(simpleDocument.getDetails(), is(DOCUMENT_NOT_FOUND.format()));
    }

    @Test
    public void testGetDocumentsByIdList() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getDocId(), getDocument());
        Id docId = new Id(DOC_ID, ISSUER, SCHEME);
        PagedDocuments pagedDocuments = documentHelper.getDocumentsByIdList(SCOPE, Collections.singletonList(docId));
        assertThat(pagedDocuments.getPaging().getPageSize(), is(1));
        assertTrue(pagedDocuments.getStatus());
    }

    @Test
    public void testFailGetDocumentsByIdList() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getDocId(), getDocument());
        String wrongDocId = "67e0t5r3-c241-4405-9590-7b14c6je574b";

        Id docId = new Id(wrongDocId, ISSUER, SCHEME);
        List<Id> documentIdList = new ArrayList<>();
        documentIdList.add(docId);

        PagedDocuments pagedDocuments = documentHelper.getDocumentsByIdList(SCOPE, documentIdList);
        assertNull(pagedDocuments.getDocuments());
        assertFalse(pagedDocuments.getStatus());
        assertThat(pagedDocuments.getDetails(), is(DOCUMENTS_NOT_FOUND.format()));
    }

    @Test
    public void testDeleteDocument() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceDelete(getDocument());
        configureDocumentServiceGet(getDocId(), getDocument());

        DocumentOperationResult documentOperationResult = documentHelper.deleteDocument(DOC_ID, SCOPE, ISSUER, SCHEME);
        assertTrue(documentOperationResult.getStatus());
        assertThat(documentOperationResult.getEnvelopeId(), is(ENVELOPE_ID));
        assertThat(documentOperationResult.getDocumentId(), is(DOC_ID));
    }

    @Test(expected = SugarTechnicalException.class)
    public void testFailDeleteDocument() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceDelete(getDocument());
        configureDocumentServiceGet(getDocId(), getDocument());
        String wrongDocId = "67e0t5r3-c241-4405-9590-7b14c6je574b";

        DocumentOperationResult documentOperationResult = documentHelper.deleteDocument(wrongDocId, SCOPE, ISSUER, SCHEME);
        assertFalse(documentOperationResult.getStatus());
        assertNull(documentOperationResult.getDocumentId());
        assertNull(documentOperationResult.getEnvelopeId());
    }

    @Test
    public void testSimpleGetDocuments() throws SugarFunctionalException, SugarTechnicalException {

        List<String> sortList = Collections.singletonList("+CreatnDate");
        List<String> tagList = Collections.singletonList("policy=policy value");
        List<String> operatorList = Collections.singletonList("EqualsTo");

        prepareResources();
        configureDocumentServiceFind(getDocument());

        PagedDocuments pagedDocuments = documentHelper.getDocuments(SCOPE, sortList, 1, 10, null, null, DOC_TYPE,
                null, null, null, tagList, operatorList);

        assertTrue(pagedDocuments.getStatus());
        assertThat(pagedDocuments.getPaging().getPageSize(), is(1));
        assertNull(pagedDocuments.getDetails());
    }

    @Test
    public void testComplexGetDocuments() throws SugarFunctionalException, SugarTechnicalException {

        List<String> sortList = Collections.singletonList("+CreatnDate");
        List<String> tagList = Collections.singletonList("policy=policy value");
        List<String> operatorList = Collections.singletonList(AllowedOperators.EQUALS_TO.getName());
        String docName = "TestDocName";
        String nameOperator = AllowedOperators.CONTAINS.getName();

        LocalDate creationDate = LocalDate.parse("2017/06/01", DATE_FORMATTER);
        String creationDateOperator = AllowedOperators.GREATER_THAN.getName();

        prepareResources();
        configureDocumentServiceFind(getDocument());

        PagedDocuments pagedDocuments = documentHelper.getDocuments(SCOPE, sortList, 1, 10, docName, nameOperator, DOC_TYPE,
                null, creationDate, creationDateOperator, tagList, operatorList);

        assertTrue(pagedDocuments.getStatus());
        assertThat(pagedDocuments.getPaging().getPageSize(), is(1));
        assertNull(pagedDocuments.getDetails());
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void testWrongTagFormatFailedGetDocuments() throws SugarFunctionalException, SugarTechnicalException {

        List<String> sortList = Collections.singletonList("+CreatnDate");
        List<String> tagList = Collections.singletonList("policy");
        List<String> operatorList = Collections.singletonList(AllowedOperators.EQUALS_TO.getName());

        prepareResources();
        configureDocumentServiceFind(getDocument());

        PagedDocuments pagedDocuments = documentHelper.getDocuments(SCOPE, sortList, 1, 10, null, null, DOC_TYPE,
                null, null, null, tagList, operatorList);
    }

    @Test
    public void testUpdateDocument() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        configureDocumentServiceGet(getDocId(), getDocument());
        LocalDate creationDate = LocalDate.parse("2017/06/01", DATE_FORMATTER);

        ComposedDocumentData composedDocumentData = buildComposedDocumentData(creationDate, "policy=policy value", LANGUAGE);

        when(tagsHelperService.getTags(POLICY_TAG_LIST, SCOPE))
                .thenReturn(Stream.of(buildTag()))
                .thenReturn(Stream.of(buildTag()));
        DocumentOperationResult documentOperationResult = documentHelper.updateDocument(DOC_ID, composedDocumentData,
                "", SCOPE, "", "", ISSUER, SCHEME);
        assertTrue(documentOperationResult.getStatus());
        assertThat(documentOperationResult.getDocumentId(), is(DOC_ID_UPDATED));
        assertNull(documentOperationResult.getDetails());
    }

    @Test(expected = SugarTechnicalException.class)
    public void testFailBadTagFormatUpdateDocument() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        LocalDate creationDate = LocalDate.parse("2017/06/01", DATE_FORMATTER);

        ComposedDocumentData composedDocumentData = buildComposedDocumentData(creationDate, "policy", LANGUAGE);

        documentHelper.updateDocument(DOC_ID, composedDocumentData,
                "", SCOPE, "", "", ISSUER, SCHEME);
    }

    @Test(expected = SugarTechnicalException.class)
    public void testFailBadLanguageFormatUpdateDocument() throws SugarFunctionalException, SugarTechnicalException {

        prepareResources();
        LocalDate creationDate = LocalDate.parse("2017/06/01", DATE_FORMATTER);

        ComposedDocumentData composedDocumentData = buildComposedDocumentData(creationDate, "policy", "english");

        documentHelper.updateDocument(DOC_ID, composedDocumentData,
                "", SCOPE, "", "", ISSUER, SCHEME);
    }

    private ComposedDocumentData buildComposedDocumentData(LocalDate creationDate, String tag, String language) {

        ComposedDocumentData composedDocumentData = new ComposedDocumentData();
        composedDocumentData.setName(DOC_NAME_UPDATED);
        composedDocumentData.setDocumentLanguage(language);
        composedDocumentData.setDocumentTypeId(DOC_TYPE);
        composedDocumentData.setDocumentTypeIssuer(ISSUER);
        composedDocumentData.setDocumentTypeVersion("0");
        composedDocumentData.setRetentionStartDate(creationDate);
        composedDocumentData.setTagList(Collections.singletonList(tag));
        return composedDocumentData;
    }
}
