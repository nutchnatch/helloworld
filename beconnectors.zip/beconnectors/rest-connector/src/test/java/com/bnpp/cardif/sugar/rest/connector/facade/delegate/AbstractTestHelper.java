package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.rest.api.DocumentFileHelperService;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.connector.filter.model.AllowedOperators;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.MCOFolderType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOAllowedValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagValueType;
import org.mockito.Mock;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Stream;

import static java.time.format.DateTimeFormatter.ofPattern;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

/**
 * Created by b48489 on 19-12-2017.
 */
abstract class AbstractTestHelper {

    @Mock private DocumentService documentService;
    @Mock private EnvelopeHelper envelopeHelper;
    @Mock DocumentFileHelperService fileHelperService;
    @Mock DocumentHelper documentHelper;
    @Mock TagsHelperService tagsHelperService;
    @Mock private FolderService folderService;
    @Mock private TagclassService tagclassService;
    @Mock private SecurityContext securityContext;
    @Mock private Authentication authentication;

    final String SCOPE = "Syldavia";
    final String ISSUER = "CARDIF";
    final String SCHEME = "Sugar";

    final String DOC_ID = "37e06513-c241-4405-9590-7b14cdfe574b";
    final String ENVELOPE_ID = "015714d1-64e4-4925-a174-515f9c874800";
    final String FOLDER_ID = "045g14d1-64e4-4321-a1g4-51yf9c974s00";
    private final String DOC_FILE_ID = "364c0e0a-ed75-4b6d-8ced-1846752fd31e";
    final String DOC_TYPE = "71c3c79f-c7fd-48bb-a4e8-6a335698ea81";
    final String ENV_TYPE = "81c3c7if-c7fd-48bb-a6e8-6a33f69tea81";
    final String FOLDER_TYPE = "61c3c7i7-c7f5-488b-a6e8-6a33fi9t7ao1";
    final String ENV_NAME = "TestEnvName";
    final String DOC_NAME = "TestDocName";
    final String FOLDER_NAME = "TestFolderName";
    final String VERSION = "0";
    final String DOC_NAME_UPDATED = "TestDocNameUpdated";
    final String ENV_UPDATE_NAME = "updatedId";
    final String FODER_UPDATE_NAME = "updatedFolderName";
    final String DOC_ID_UPDATED = "57e06513-c241-4005-9590-7b17cdfe5r4b";
    final String LANGUAGE = "en";
    final DateTimeFormatter DATE_FORMATTER = ofPattern("yyyy/MM/dd");
    final int PAGE_NUMBER = 1;
    final int PAGE_SIZE = 10;
    final List<String> SORT_LIST = Collections.singletonList("+CreatnDate");
    final List<String> TAG_LIST = Collections.singletonList("policy=policy value");
    final List<String> POLICY_TAG_LIST = Collections.singletonList("policy");
    final String TAG_SYMBOLIC_NAME = "TagSymbolicName";
    final List<String> OPERATION_LIST = Collections.singletonList(AllowedOperators.EQUALS_TO.getName());

    LocalDate CREATION_DATE = LocalDate.parse("2017/06/01", DATE_FORMATTER);
    String CREATION_DATE_OPERATION = AllowedOperators.GREATER_THAN.getName();
    private Document document;
    private Document envelope;
    private Folder folder;

    void testSetUp() {

        String token = "6cpbmit27r6dafl03fchs8jrlgg4tj9p";
        AuthenticatedUser authenticatedUser = new AuthenticatedUser("userTest", "passTest", token,
                "user1stName", "userLastName", null, "version");

        when(authentication.getPrincipal()).thenReturn(authenticatedUser);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
    }

    Id getEnvelopeId() {
        return new Id(ENVELOPE_ID, ISSUER, SCHEME);
    }

    Id getDocId() {
        return new Id(DOC_ID, ISSUER, SCHEME);
    }

    FolderId getFolderId() {
        return new FolderId(FOLDER_ID, ISSUER, SCHEME);
    }

    Tag buildTag() {
        Tag tag = new Tag();
        tag.setName("1stTag");
        tag.setType("1stTagType");
        tag.setValue("1stTagValue");
        return tag;
    }

    Document createdAndUpdateDocument() {

        Document updatedDocument = CommonHelper.createDocument(DOC_FILE_ID, SCOPE);
        String updatedDocName = "DOC_NAME_UPDATED";
        updateDocument(updatedDocument, updatedDocName);
        Id updatedDocId = new Id(DOC_ID_UPDATED, ISSUER, SCHEME);
        updatedDocument.setId(updatedDocId);
        return updatedDocument;
    }

    void updateDocument(Document document, String docName) {

        String fileURI = "37e56513-c241-4905-9790-7b14hdfe574b";
        MCODocumentType.FileData fileData = new MCODocumentType.FileData(Collections.EMPTY_LIST, Collections.singletonList(fileURI));
        Id docId = getDocId();
        Id envelopeId = getEnvelopeId();
        MCODocumentType.ParentId parentId = new MCODocumentType.ParentId(envelopeId);
        document.setId(docId);
        document.setFileData(fileData);
        document.setParentId(parentId);
        document.getData().setName(docName);
    }

    void updateEnvelope(Document envelope, String envelopeName, Id envelopeId) {

        envelope.setId(envelopeId);
        envelope.getData().setName(envelopeName);
    }

    void updateFolder(Folder folder, String folderName, FolderId folderId) {

        folder.setFolderId(folderId);
        folder.getData().setName(folderName);
        List<Id> docIdList = new ArrayList<>();
        docIdList.add(getDocId());
        MCOFolderType.ChildComponents childComponents = new MCOFolderType.ChildComponents(Collections.singletonList(document),
                docIdList);
        folder.setChildComponents(childComponents);
    }

    Document createAndUpdateEnvelope() {

        Document envelope = CommonHelper.createEnvelope(null, SCOPE);
        Id envId = getEnvelopeId();
        envId.setValue(ENV_UPDATE_NAME);
        envelope.setId(envId);
        envelope.getData().setName("UpdatedEnvelopeName");
        return envelope;
    }

    void prepareResources() throws SugarFunctionalException, SugarTechnicalException {

        document = CommonHelper.createDocument(DOC_FILE_ID, SCOPE);
        updateDocument(document, DOC_NAME);
        MCODocumentType.ChildObject childObject = new MCODocumentType.ChildObject(Collections.singletonList(document), null);

        envelope = CommonHelper.createEnvelope(childObject, SCOPE);
        ComposedFolderData composedFolderData = getComposedFolderData();
        updateEnvelope(envelope, ENV_NAME, getEnvelopeId());
        when(envelopeHelper.fetchEnvelope(ENVELOPE_ID, SCOPE, ISSUER, SCHEME)).thenReturn(Stream.of(envelope));

        Tag tag = buildTag();
        when(tagsHelperService.getAllTags(SCOPE)).thenReturn(Stream.of(tag));
        when(tagsHelperService.getTags(POLICY_TAG_LIST, SCOPE)).thenReturn(Stream.of(buildTag()));

        Document updatedDocument = createdAndUpdateDocument();
        when(documentService.update(Collections.singletonList(document))).thenReturn(Collections.singletonList(updatedDocument));
        when(documentService.update(Collections.singletonList(envelope))).thenReturn(Collections.singletonList(createAndUpdateEnvelope()));
        SearchResults<Folder> folderSearchResults = new SearchResults<>();

        folder = CommonHelper.createFolder(tagsHelperService, composedFolderData, SCOPE);
        folderSearchResults.setResults(Collections.singletonList(folder));
        updateFolder(folder, FOLDER_NAME, getFolderId());
        when(folderService.find(any(Criteria.class), any(OrderClause.class), anyLong(), anyLong())).thenReturn(folderSearchResults);
        when(folderService.get(Collections.singletonList(getFolderId()), SCOPE)).thenReturn(Collections.singletonList(folder));

        TagClass tagClass = buildTagClass();
        when(tagclassService.getBySymbolicName(SCOPE, Collections.singletonList(TAG_SYMBOLIC_NAME), false)).thenReturn(Collections.singletonList(tagClass));
        when(tagclassService.getAll(SCOPE)).thenReturn(Collections.singletonList(tagClass));
    }

    private TagClass buildTagClass() {

        ClassId classId = new ClassId("tag", ISSUER, 0);
        MCOI18NLabel mcoi18NLabel = new MCOI18NLabel("Tag Label", LANGUAGE);
        MCOAllowedValue allowedValue = new MCOAllowedValue(Collections.singletonList(mcoi18NLabel), TAG_SYMBOLIC_NAME);
        return new TagClass(classId, SCOPE, true, Collections.singletonList(mcoi18NLabel),
                TagValueType.BOOLEAN, Collections.singletonList(allowedValue), "Pattern", TAG_SYMBOLIC_NAME);
    }

    void configureUpdateFolder() throws SugarTechnicalException, SugarFunctionalException {
        updateFolder(folder, FODER_UPDATE_NAME, getFolderId());
        when(folderService.update(Collections.singletonList(folder), SCOPE)).thenReturn(Collections.singletonList(folder));
    }

    private ComposedFolderData getComposedFolderData() {
        ComposedFolderData composedFolderData = new ComposedFolderData();
        composedFolderData.setTagList(TAG_LIST);
        composedFolderData.setFolderName(FOLDER_NAME);
        composedFolderData.setFolderTypeId(FOLDER_TYPE);
        composedFolderData.setFolderTypeIssuer(ISSUER);
        composedFolderData.setFolderTypeVersion(VERSION);
        return composedFolderData;
    }

    void configureDocumentServiceFind(Document document) throws SugarFunctionalException, SugarTechnicalException {

        SearchResults<Document> searchResults = new SearchResults<>(Collections.singletonList(document), 1);
        when(documentService.find(any(Criteria.class), any(OrderClause.class), anyLong(), anyLong())).thenReturn(searchResults);
    }

    void configureDocumentServiceDelete(Document document) throws SugarFunctionalException, SugarTechnicalException {
        when(documentService.delete(Collections.singletonList(getDocId()), SCOPE)).thenReturn(Collections.singletonList(document));
    }

    void configureDocumentServiceGet(Id id, Document document) throws SugarFunctionalException, SugarTechnicalException {

        when(documentService.get(SCOPE, Collections.singletonList(id), true,
                false)).thenReturn(Collections.singletonList(document));
    }

    void configureGetDocumentsByIds() throws SugarFunctionalException, SugarTechnicalException {

        PagedDocuments pagedDocuments = buildPagedDocuments();
        when(documentHelper.getDocumentsByIdList(SCOPE, Collections.singletonList(getDocId()))).thenReturn(pagedDocuments);
    }

    void configureGetDocumentList() throws SugarFunctionalException, SugarTechnicalException {

        when(documentHelper.getDocumentList(SCOPE, Collections.singletonList(getDocId()))).thenReturn(Stream.of(document));
    }

    private PagedDocuments buildPagedDocuments() {
        PagedDocuments pagedDocuments = new PagedDocuments();
        pagedDocuments.setDocuments(Collections.singletonList(buildDocument()));
        pagedDocuments.setStatus(true);
        Paging paging = new Paging();
        paging.setPageSize(1);
        return pagedDocuments;
    }

    Document getDocument() {
        return document;
    }

    Document getEnvelope() {
        return envelope;
    }

    ComposedDocument buildComposedDocument() {

        ComposedDocument composedDocument = new ComposedDocument();
        composedDocument.setTagList(TAG_LIST);
        composedDocument.setName(DOC_NAME);
        composedDocument.setDocumentLanguage(LANGUAGE);
        composedDocument.setDocumentTypeId(DOC_TYPE);
        composedDocument.setId(DOC_ID);
        return composedDocument;
    }

    com.bnpp.cardif.sugar.rest.web.model.Document buildDocument() {

        com.bnpp.cardif.sugar.rest.web.model.Document document = new com.bnpp.cardif.sugar.rest.web.model.Document();
        document.setId(getDocId().getValue());
        document.setName(DOC_NAME);
        document.setEnvelopeID(getEnvelopeId().getValue());
        document.setDocTypeId(DOC_TYPE);
        return document;
    }
}
