package com.bnpp.cardif.sugar.rest.connector.util;

import com.bnpp.cardif.sugar.domain.exception.*;

/**
 * Created by b48489 on 08-11-2017.
 */
public final class ExceptionHandler {

    public static <T> T raiseFunctionalException(FunctionalErrorCode functionalErrorCode, String... messages) throws
            SugarFunctionalException {

        throw ExceptionBuilder.createFunctionalException(
                functionalErrorCode, messages);
    }

    public static <T> T raiseTechnicalException(TechnicalErrorCode technicalErrorCode, String... messages) throws SugarTechnicalException {

        throw ExceptionBuilder.createTechnicalException(
                technicalErrorCode, messages);
    }
}
