package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.facade.delegate.EnvelopeHelper;
import com.bnpp.cardif.sugar.rest.web.api.EnvelopesApi;
import com.bnpp.cardif.sugar.rest.web.model.*;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * Created by b48489 on 28-08-2017.
 */

@RestController
public class EnvelopeController implements EnvelopesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnvelopeController.class);
    @Autowired private EnvelopeHelper envelopeHelper;

    public ResponseEntity<EnvelopeOperationResult> deleteEnvelope(@ApiParam(value = "Envelope ID.",required=true ) @PathVariable("envelopeId") String envelopeId,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Dugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(envelopeHelper.deleteEnvelope(envelopeId, X_CARDIF_CONSUMER, scope, classTypeIssuer,
                    scheme, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            return ErrorResultBuilder.buildEnvelopeOperationErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildEnvelopeOperationErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    public ResponseEntity<DocumentFileCreationResult> addFileToEnvelope(@ApiParam(value = "Envelope ID.",required=true ) @PathVariable("envelopeId") String envelopeId,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID,
            @ApiParam(value = "file detail") @RequestPart("file") MultipartFile file) {

        try {
            return ResponseEntity.ok(envelopeHelper.addFileToEnvelope(envelopeId, X_CARDIF_CONSUMER, scope, classTypeIssuer,
                    scheme, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID, file));
        }
        catch (SugarFunctionalException e) {
            return ErrorResultBuilder.buildDocumentFileCreationErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException | IOException e) {
            return ErrorResultBuilder.buildDocumentFileCreationErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override
    public ResponseEntity<PagedDocuments> getDocumentsFromEnvelope(
            @ApiParam(value = "Envelope ID.",required=true ) @PathVariable("envelopeId") String envelopeId,
            @NotNull@ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue="1") Integer pageNumber,
            @NotNull @Min(0) @Max(100)@ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue="10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @Size(min=1,max=3)@ApiParam(value = "Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try{
            return ResponseEntity.ok(envelopeHelper.getDocumentsByEnvelopeId(envelopeId, scope, sort, pageNumber, pageSize, classTypeIssuer, scheme));

        } catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GetEnvelopeById", e);
            return ErrorResultBuilder.buildPagedDocumentsErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildPagedDocumentsErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    public ResponseEntity<SimpleEnvelope> getEnvelopeById(@ApiParam(value = "Envelope ID.",required=true ) @PathVariable("envelopeId") String envelopeId,
            @NotNull@ApiParam(value = "Scope of Dugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true) @RequestParam(value = "classTypeIssuer", required = true) String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(envelopeHelper.getEnvelopeById(envelopeId, scope, classTypeIssuer, scheme));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GetEnvelopeById", e);
            return ErrorResultBuilder.buildSimpleEnvelopeErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildSimpleEnvelopeErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override
    public ResponseEntity<PagedEnvelopes> getEnvelopes(

            @NotNull@ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue="1") Integer pageNumber,
            @NotNull @Min(0) @Max(100)@ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue="10") Integer pageSize,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @Pattern(regexp="[0-9]{4}/[0-9]{2}/[0-9]{2}")@ApiParam(value = "Creation date") @RequestParam(value = "creationDate", required = false) LocalDate creationDate,
            @ApiParam(value = "Filter query definition.", allowableValues = "GreatherThan, LessThan") @RequestParam(value = "creationDateOperator", required = false) String creationDateOperator,
            @ApiParam(value = "Envelope type ID.") @RequestParam(value = "envelopeTypeID", required = false) String envelopeTypeID,
            @ApiParam(value = "Representation of a tag with name and value.") @RequestParam(value = "tagEntries", required = false) List<String> tagEntries,
            @ApiParam(value = "Filter query definition.", allowableValues = "Contains, EqualsTo, StartsWith, EndsWith, Display, GreatherThan, LessThan") @RequestParam(value = "tagsOperators", required = false) List<String> tagsOperators,
            @Size(min=1,max=3)@ApiParam(value = "Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(envelopeHelper.getEnvelopes(scope, sort, pageNumber, pageSize, creationDate,
                    envelopeTypeID, creationDateOperator, tagEntries, tagsOperators));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation getDocuments", e);
            return ErrorResultBuilder.buildPagedEnvelopesErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildPagedEnvelopesErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<EnvelopeOperationResult> updateEnvelope(@ApiParam(value = "Envelope ID.",required=true ) @PathVariable("envelopeId") String envelopeId,
            @ApiParam(value = "" ,required=true )  @Valid @RequestBody ComposedEnvelopeData envelopeData,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Dugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true) @RequestParam(value = "classTypeIssuer", required = true) String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(envelopeHelper.updateEnvelope(envelopeId, envelopeData, X_CARDIF_CONSUMER, scope, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID, classTypeIssuer, scheme));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation updateEnvelope", e);
            return ErrorResultBuilder.buildEnvelopeOperationErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildEnvelopeOperationErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }
}