package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.Document;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.web.model.SimpleDocument;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import java.util.List;
import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class CriteriaBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Item item) {
            super(item);
        }

        @Override protected Builder self() {
            return this;
        }

        @Override public Criteria build() {

            return Optional.ofNullable(this.getItem()).isPresent()
                    ? simpleDocumentInstance(this)
                    : raiseIllegalStateException();
        }

        private Criteria raiseIllegalStateException() throws IllegalStateException {
            throw new IllegalStateException("Invalid builder since item is null");
        }
    }

    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<Criteria> {

        private Item item;
        private List<Criterion> criterionList;
        private boolean any;

        Prototype(Item item) {
            this.item = item;
        }

        public Item getItem() {
            return item;
        }

        public List<Criterion> getCriterionList() {
            return criterionList;
        }

        public E criterionList(List<Criterion> criterionList) {
            this.criterionList = criterionList;
            return self();
        }

        public boolean isAny() {
            return any;
        }

        public E any(boolean any) {
            this.any = any;
            return self();
        }

        protected abstract E self();
    }

    private static Criteria simpleDocumentInstance(Prototype<?> builder) {

        Criteria criteria = new Criteria();
        criteria.setAny(builder.isAny());
        criteria.setItem(builder.getItem());
        builder.getCriterionList().forEach(criteria.getCriterionList()::add);
        return criteria;
    }
}
