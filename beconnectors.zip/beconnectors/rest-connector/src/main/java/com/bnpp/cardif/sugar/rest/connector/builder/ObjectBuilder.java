package com.bnpp.cardif.sugar.rest.connector.builder;

/**
 * ObjectBuilder interface defines the content of the builder objects
 */
public interface ObjectBuilder<TYPE> {

    /**
     * {@Link ObjectBuilder} implementers shall implements a build method.
     * Stands for:
     * - evaluates current builder state;
     * - builds the instance of object;
     * @return instance of {@link TYPE}
     * @throws IllegalStateException if Builder state is not valid on the build
     */
    TYPE build();
}
