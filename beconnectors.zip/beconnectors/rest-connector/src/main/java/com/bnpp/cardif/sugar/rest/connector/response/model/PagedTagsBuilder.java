package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.*;

import java.util.List;
import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class PagedTagsBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }

        @Override protected Builder self() {
            return this;
        }

        @Override public PagedTags build() {

            return Optional.ofNullable(this.getStatus()).isPresent() ? pagedDocumentsInstance(this) : raiseIllegalStateException();
        }

        private PagedTags raiseIllegalStateException() {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<PagedTags> {

        private Boolean status;
        private List<AssociatedTag> tags;
        private Paging paging;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public Paging getPaging() {
            return paging;
        }

        public E paging(Paging paging) {
            this.paging = paging;
            return self();
        }

        public List<AssociatedTag> getTags() {
            return tags;
        }

        public E tags(List<AssociatedTag> tags) {
            this.tags = tags;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static PagedTags pagedDocumentsInstance(Prototype<?> builder) {

        PagedTags pagedTags = new PagedTags();
        return pagedTags
                .details(builder.getDetails())
                .status(builder.getStatus())
                .errorCause(builder.getErrorCause())
                .tags(builder.getTags());
    }
}
