package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.*;

import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class SimpleEnvelopeBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }

        @Override protected Builder self() {
            return this;
        }

        @Override public SimpleEnvelope build() {

            return Optional.ofNullable(this.getStatus()).isPresent()
                    ? simpleEnvelopeInstance(this)
                    : raiseIllegalStateException();
        }

        private SimpleEnvelope raiseIllegalStateException() throws IllegalStateException {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<SimpleEnvelope> {

        private Boolean status;
        private Envelope envelope;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public Envelope getEnvelope() {
            return envelope;
        }

        public E envelope(Envelope envelope) {
            this.envelope = envelope;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static SimpleEnvelope simpleEnvelopeInstance(Prototype<?> builder) {

        SimpleEnvelope simpleEnvelope = new SimpleEnvelope();
        return simpleEnvelope
                .details(builder.getDetails())
                .status(builder.getStatus())
                .envelope(builder.getEnvelope())
                .errorCause(builder.getErrorCause());
    }
}
