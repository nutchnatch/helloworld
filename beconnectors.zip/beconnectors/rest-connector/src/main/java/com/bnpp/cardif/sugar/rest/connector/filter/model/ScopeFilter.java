package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;

import java.util.Collections;

/**
 * Created by b48489 on 23-10-2017.
 */
public class ScopeFilter {

    public static final String SCOPE_CRITERION_NAME = "Scope";

    public static Criterion buildEqualsScopeCriterion(String scope) {

        return CriteriaStringTypeHelper.buildEqualsToCriterion(
                Levels.ATTRIBUTE,
                SCOPE_CRITERION_NAME,
                Collections.singletonList(scope));
    }
}
