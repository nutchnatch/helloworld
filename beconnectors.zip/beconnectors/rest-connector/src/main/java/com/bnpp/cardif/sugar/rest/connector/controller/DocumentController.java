package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.facade.delegate.DocumentHelper;
import com.bnpp.cardif.sugar.rest.web.api.DocumentsApi;
import com.bnpp.cardif.sugar.rest.web.model.*;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import javax.validation.constraints.*;
import java.time.LocalDate;
import java.util.List;
import javax.validation.constraints.Pattern;

/**
 * Created by b48489 on 16-08-2017.
 */

@RestController public class DocumentController implements DocumentsApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentController.class);

    @Autowired DocumentHelper documentHelper;

    @Override
    public ResponseEntity<SimpleDocument> getDocumentByID(@ApiParam(value = "Document ID.",required=true ) @PathVariable("docId") String docId,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Dugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true) @RequestParam(value = "classTypeIssuer", required = true) String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(documentHelper.getDocumentById(scope, docId, classTypeIssuer, scheme));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation Get_Document_By_Id", e);
            return ErrorResultBuilder.buildSimpleDocumentErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildSimpleDocumentErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override
    public ResponseEntity<PagedDocuments> getDocuments(
            @NotNull@ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue="1") Integer pageNumber,
            @NotNull @Min(0) @Max(100)@ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue="10") Integer pageSize,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @ApiParam(value = "Provided name.") @RequestParam(value = "name", required = false) String name,
            @ApiParam(value = "Filter query definition.", allowableValues = "Contains, EqualsTo, StartsWith, EndsWith, Display") @RequestParam(value = "nameOperator", required = false) String nameOperator, @Pattern(regexp="[0-9]{4}/[0-9]{2}/[0-9]{2}")@ApiParam(value = "Creation date") @RequestParam(value = "creationDate", required = false) LocalDate creationDate,
            @ApiParam(value = "Filter query definition.", allowableValues = "GreatherThan, LessThan") @RequestParam(value = "creationDateOperator", required = false) String creationDateOperator,
            @ApiParam(value = "Document type.") @RequestParam(value = "docTypeId", required = false) String docTypeId,
            @ApiParam(value = "Language of the tag.") @RequestParam(value = "language", required = false) String language,
            @ApiParam(value = "Confidentiality.") @RequestParam(value = "confidentiality", required = false) String confidentiality,
            @ApiParam(value = "Representation of a tag with name and value.") @RequestParam(value = "tagEntries", required = false) List<String> tagEntries,
            @ApiParam(value = "Filter query definition.", allowableValues = "Contains, EqualsTo, StartsWith, EndsWith, Display, GreatherThan, LessThan") @RequestParam(value = "tagsOperators", required = false) List<String> tagsOperators,
            @Size(min=1,max=3)@ApiParam(value = "Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            if(tagEntries != null && tagsOperators == null || tagEntries != null && (
                    tagEntries.size() != tagsOperators.size() || !documentHelper.validateTags(tagEntries))) {

                return ResponseEntity.badRequest().build();
            }

            return ResponseEntity.ok(documentHelper.getDocuments(scope, sort, pageNumber, pageSize, name, nameOperator, docTypeId,
                    confidentiality, creationDate, creationDateOperator, tagEntries, tagsOperators));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GetDocuments", e);
            return ErrorResultBuilder.buildPagedDocumentsErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildPagedDocumentsErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override
    public ResponseEntity<DocumentOperationResult> updateDocument(@ApiParam(value = "Document ID.",required=true ) @PathVariable("docId") String docId,
            @ApiParam(value = "" ,required=true )  @Valid @RequestBody ComposedDocumentData documentData,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Dugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true) @RequestParam(value = "classTypeIssuer", required = true) String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(documentHelper.updateDocument(docId, documentData, X_CARDIF_CONSUMER, scope,
                    X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID, classTypeIssuer, scheme));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation UpdateDocument", e);
            return ErrorResultBuilder.buildDocumentOperationErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildDocumentOperationErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
    }

    @Override
    public ResponseEntity<DocumentOperationResult> deleteDocument(

            @ApiParam(value = "Document ID.",required=true ) @PathVariable("docId") String docId,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID
            ) {

        try {
            return ResponseEntity.ok(documentHelper.deleteDocument(docId, scope, classTypeIssuer, scheme));
        }
        catch (SugarFunctionalException e) {
            return ErrorResultBuilder.buildDocumentOperationErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildDocumentOperationErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }
}
