package com.bnpp.cardif.sugar.rest.api;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.SimpleTag;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.stream.Stream;

/**
 * Created by b48489 on 06-09-2017.
 *
 * Description of operation applicable for tags.
 */
public interface TagsHelperService {

    /**
     * Get tags through its name.
     * @param tagNameList - list of tag name.
     * @param scope - Sugar working scope.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return SimpleTag
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    SimpleTag getTagsByName(List<String> tagNameList, @Nonnull String scope, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Get all existing tags.
     * @param scope - Sugar working scope.
     * @return Stream<Tag>
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    Stream<Tag> getAllTags(@Nonnull String scope) throws SugarFunctionalException, SugarTechnicalException;

    /**
     *  Get tags through tag name list.
     * @param tagNameList - list of tag name.
     * @param scope - Sugar working scope.
     * @return Stream<Tag>
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    Stream<Tag> getTags(@Nonnull List<String> tagNameList, @Nonnull String scope) throws SugarFunctionalException, SugarTechnicalException;
}
