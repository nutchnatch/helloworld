package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.google.common.collect.ImmutableMap;

import java.util.Collections;
import java.util.Map;

/**
 * Created by b48489 on 27-10-2017.
 */
public class NameFilter {

    private static final String NAME_CRITERION_NAME = "Name";

    private static Criterion buildContainsNameCriterion(String name) {

        return CriteriaStringTypeHelper.buildContainsCriterion(
                Levels.DATA,
                NAME_CRITERION_NAME,
                Collections.singletonList(name));
    }

    private static Criterion buildEqualsToNameCriterion(String name) {

        return CriteriaStringTypeHelper.buildEqualsToCriterion(
                Levels.DATA,
                NAME_CRITERION_NAME,
                Collections.singletonList(name));
    }

    private static Criterion buildStartsWithNameCriterion(String name) {

        return CriteriaStringTypeHelper.buildStartsWithCriterion(
                Levels.DATA,
                NAME_CRITERION_NAME,
                Collections.singletonList(name));
    }

    private static Criterion buildEndsWithNameCriterion(String name) {

        return CriteriaStringTypeHelper.buildEndsWithCriterion(
                Levels.DATA,
                NAME_CRITERION_NAME,
                Collections.singletonList(name));
    }

    private static Criterion buildDiaplaysCriterion(String name) {

        return CriteriaStringTypeHelper.buildDisplaysCriterion(
                Levels.DATA,
                NAME_CRITERION_NAME,
                Collections.singletonList(name));
    }

    public static Map<Enum, Criterion> buildNameOperationConfiguration(String name) {

        return new ImmutableMap.Builder<Enum, Criterion>()
                .put(AllowedOperators.CONTAINS, buildContainsNameCriterion(name))
                .put(AllowedOperators.EQUALS_TO, buildEqualsToNameCriterion(name))
                .put(AllowedOperators.STARTS_WITH, buildStartsWithNameCriterion(name))
                .put(AllowedOperators.ENDS_WITH, buildEndsWithNameCriterion(name))
                .put(AllowedOperators.DISPLAY, buildDiaplaysCriterion(name))
                .build();
    }
}
