package com.bnpp.cardif.sugar.rest.connector.filter.model;

/**
 * Created by b48489 on 27-10-2017.
 */
public enum AllowedOperators {

    NOT_EQUALS_TO("NotEqualsTo"),
    EQUALS_TO("EqualsTo"),
    CONTAINS("Contains"),
    LESS_THAN("LessThan"),
    GREATER_THAN("GreatherThan"),
    STARTS_WITH("StartsWith"),
    ENDS_WITH("EndsWith"),
    DISPLAY("Display");

    private String name;

    AllowedOperators(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static AllowedOperators getValueOf(String name) {

        for(AllowedOperators operator : AllowedOperators.values()) {
            if (operator.getName().equals(name)) {
                return operator;
            }
        }
        return null;
    }
}
