package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.rest.web.model.AssociatedTag;
import com.bnpp.cardif.sugar.rest.web.model.EnvelopeType;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

import javax.annotation.Nonnull;
import java.util.*;
import java.util.function.Function;
import static java.util.stream.Collectors.toList;

/**
 * Created by b48489 on 24-08-2017.
 */
public class ConvertEnvelopeTypesToRestWebApi implements Function<DocumentClass, EnvelopeType> {

    private static Map tagMap = Collections.EMPTY_MAP;

    public ConvertEnvelopeTypesToRestWebApi(Map<String, Tag> tagMap) {
        ConvertEnvelopeTypesToRestWebApi.tagMap = tagMap;
    }

    private static void fillExisting(DocumentClass documentClass, EnvelopeType existingeEnvelopeType) {

        existingeEnvelopeType.setDisplayNameList(CommonConverterHelper.buildDisplayNameItemList(documentClass.getShortLabel()));
        existingeEnvelopeType.setTagList(buildAssociatedTagList(documentClass));
        existingeEnvelopeType.setName(documentClass.getLongLabel());
        existingeEnvelopeType.setId(documentClass.getClassId().getValue());
        existingeEnvelopeType.setIssuer(documentClass.getClassId().getIssuer());
        existingeEnvelopeType.setVersion(Integer.toString(documentClass.getClassId().getVersId()));
        Optional.ofNullable(documentClass.getStatus()).ifPresent(status -> existingeEnvelopeType.setState(status.getCode()));
        existingeEnvelopeType.setActive(documentClass.isActive());
    }

    private static EnvelopeType convert(@Nonnull DocumentClass documentClass) {
        EnvelopeType apiEnvelopeType = new EnvelopeType();
        List<AssociatedTag> tmpList = new ArrayList<>();
        apiEnvelopeType.setTagList(tmpList);
        fillExisting(documentClass, apiEnvelopeType);
        return apiEnvelopeType;
    }

    private static List<AssociatedTag> buildAssociatedTagList(@Nonnull DocumentClass document) {
        return document.getTagReference().stream()
                .map((tagReference) -> CommonConverterHelper.buildAssociatedTag(tagReference, tagMap))
                .collect(toList());
    }

    @Override public EnvelopeType apply(DocumentClass documentClass) {
        return convert(documentClass);
    }
}
