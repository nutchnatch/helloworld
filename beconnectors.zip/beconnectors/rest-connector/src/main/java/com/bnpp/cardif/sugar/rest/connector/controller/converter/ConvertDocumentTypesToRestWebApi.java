package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.rest.web.model.AssociatedTag;
import com.bnpp.cardif.sugar.rest.web.model.DocumentType;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

import javax.annotation.Nonnull;
import java.util.*;
import java.util.function.Function;

import static java.util.stream.Collectors.toList;

/**
 * Created by b48489 on 24-08-2017.
 */
public class ConvertDocumentTypesToRestWebApi implements Function<DocumentClass, DocumentType> {

    private static Map tagMap = Collections.EMPTY_MAP;

    public ConvertDocumentTypesToRestWebApi(Map<String, Tag> tagMap) {
        ConvertDocumentTypesToRestWebApi.tagMap = tagMap;
    }

    private static void fillExisting(DocumentClass documentClass, DocumentType existingeDocumentType) {

        existingeDocumentType.setDisplayNameList(CommonConverterHelper.buildDisplayNameItemList(documentClass.getShortLabel()));
        existingeDocumentType.setTagList(buildAssociatedTagList(documentClass));
        existingeDocumentType.setName(documentClass.getLongLabel());
        existingeDocumentType.setId(documentClass.getClassId().getValue());
        existingeDocumentType.setIssuer(documentClass.getClassId().getIssuer());
        existingeDocumentType.setVersion(Integer.toString(documentClass.getClassId().getVersId()));
        Optional.ofNullable(documentClass.getStatus()).ifPresent(state -> existingeDocumentType.setState(state.getCode()));
        existingeDocumentType.setActive(documentClass.isActive());
    }

    private static DocumentType convert(@Nonnull DocumentClass documentClass) {
        DocumentType apiDocumentType = new DocumentType();
        List<AssociatedTag> tmpList = new ArrayList<>();
        apiDocumentType.setTagList(tmpList);
        fillExisting(documentClass, apiDocumentType);
        return apiDocumentType;
    }

    private static List<AssociatedTag> buildAssociatedTagList(@Nonnull DocumentClass document) {
        return document.getTagReference().stream()
                .map((tagReference) -> CommonConverterHelper.buildAssociatedTag(tagReference, tagMap))
                .collect(toList());
    }

    @Override public DocumentType apply(DocumentClass documentClass) {
        return convert(documentClass);
    }
}
