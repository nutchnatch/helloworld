package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.response.model.PagedTagsBuilder;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

/**
 * Created by b48489 on 07-09-2017.
 */
public final class CommonConverterHelper {

    static List<DisplayNameItem> buildDisplayNameItemList(@Nonnull List<MCOI18NLabel> labelList) {

        return labelList.stream()
                .map(CommonConverterHelper::buildDisplayNameItem)
                .collect(toList());
    }

    private static DisplayNameItem buildDisplayNameItem(@Nonnull MCOI18NLabel existingLabel) {

        DisplayNameItem displayNameItem = new DisplayNameItem();
        displayNameItem.setLanguage(existingLabel.getLanguage());
        displayNameItem.setValue(existingLabel.getValue());
        return displayNameItem;
    }

    static List<String> extractDocumentIdList(List<Id> idList) {

        return idList.stream()
                .map(Id::getValue)
                .collect(Collectors.toList());
    }

    static List<String> extractIdFromDocumentList(List<Document> documentList) {

        return documentList.stream()
                .map(Document::getId)
                .map(Id::getValue)
                .collect(Collectors.toList());
    }

    static List<TagElement> extractTags(List<com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag> tagList,
            Map tagMap) {

        return tagList.stream()
                .map(tag -> CommonConverterHelper.buildTagElement(tag, tagMap))
                .collect(Collectors.toList());
    }

    private static TagElement buildTagElement(com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag tag, Map tagMap) {

        Tag otherTag = (Tag) tagMap.get(tag.getName());
        otherTag.setName(tag.getName());
        TagElement tagElement = new TagElement();
        tagElement.setTag(otherTag);
        tagElement.setTagValue(tag.getValue());
        return tagElement;
    }

    static AssociatedTag buildAssociatedTag(@Nonnull MCOTagReference tagReference, Map tagMap) {

        AssociatedTag associatedTag = new AssociatedTag();
        Tag tag = (Tag) tagMap.get(tagReference.getSymbolicName());
        associatedTag.setMandatory(Boolean.toString(tagReference.isMandatory()));
        associatedTag.setTag(tag);
        return associatedTag;
    }

    public static PagedTags getContainingTag(List<AssociatedTag> tagList, @Nonnull Integer pageSize) throws SugarFunctionalException,
            SugarTechnicalException {

        return buildPagedTags(pageSize, tagList);
    }

    private static PagedTags buildPagedTags(@Nonnull Integer pageSize, List<AssociatedTag> filteredTagList) {

        Paging paging = new Paging();
        paging.setPageSize(pageSize);
        paging.setTotalItems(filteredTagList.size());

        return new PagedTagsBuilder.Builder(true)
                        .tags(filteredTagList)
                        .paging(paging)
                        .build();
    }
}
