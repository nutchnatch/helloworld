package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.commands.documentfile.AddDocumentFile;
import com.bnpp.cardif.sugar.commands.envelope.AddEnvelope;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConvertDocumentFileToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.util.ExceptionHandler;
import com.bnpp.cardif.sugar.rest.api.DocumentFileHelperService;
import com.bnpp.cardif.sugar.rest.web.model.DocumentFileCreationResult;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import javax.annotation.Nonnull;
import java.io.*;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.FILE_UPLOAD_VALIDITY_WARN;

/**
 * Created by b48489 on 29-08-2017.
 */
@Component("documentFileHelper")
@Scope("singleton")
public class DocumentFileHelper implements DocumentFileHelperService {

    @Autowired private DocumentFileService documentFileService;
    @Autowired private DocumentService documentService;

    @Override public DocumentFileCreationResult addDocumentFile(@Nonnull MultipartFile upfile, @Nonnull String scope) throws IOException,
            SugarTechnicalException, SugarFunctionalException{

        final List<DocumentFile> documentFileList = CommonHelper.buildDocumentFileList(upfile, scope);
        return createAndStoreDocumentFile(documentFileList, scope);
    }

    private DocumentFileCreationResult createAndStoreDocumentFile(@Nonnull List<DocumentFile> documentFileList,
            @Nonnull String scope) throws SugarFunctionalException, SugarTechnicalException {

            Optional<DocumentFileCreationResult> optionalReturn = submitFile(documentFileList);
            return optionalReturn.isPresent()
                    ? createAndStoreEnvelope(optionalReturn.get(), scope)
                    : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00101);
    }

    @Override public Optional<DocumentFileCreationResult> submitFile(@Nonnull List<DocumentFile> documentFileList)
            throws SugarFunctionalException, SugarTechnicalException {

        final AddDocumentFile<RestCallContext> addFileCommand = new AddDocumentFile<>(new RestCallContext(),
                documentFileService, documentFileList);

        return toApiFileCreationResponse(StreamSupport.stream(
                    addFileCommand.call().spliterator(), false)).findFirst();
    }

    private DocumentFileCreationResult createAndStoreEnvelope(@Nonnull DocumentFileCreationResult documentFileCreationResult,
            @Nonnull String scope) throws SugarFunctionalException, SugarTechnicalException {

        List<Document> documentList = Collections.singletonList(CommonHelper.createDocument(documentFileCreationResult.getDocumentFileId(), scope));
        MCODocumentType.ChildObject childObject = new MCODocumentType.ChildObject(documentList, null);
        List<Document> envelopeList = Collections.singletonList(CommonHelper.createEnvelope(childObject, scope));

        final AddEnvelope<RestCallContext> addEnvelopeCommand = new AddEnvelope<>(new RestCallContext(),
                documentService, envelopeList);

        List<Document> objects = addEnvelopeCommand.call();
        objects.forEach(envelope -> fillData(documentFileCreationResult, envelope));

        return documentFileCreationResult;
    }

    private void fillData(@Nonnull DocumentFileCreationResult fileCreationResponse, @Nonnull Document input) {

        fill(input.getCategory(), fileCreationResponse, cat -> cat.equals(Category.ENVELOPE),
                (DocumentFileCreationResult docFile) -> {
                    docFile.setEnvelopeId(input.getId().getValue());
                    docFile.setEnvelopeStatus(input.getData().getValidityCode().toString());
                });

        fill(input.getCategory(), fileCreationResponse, cat -> cat.equals(Category.DOCUMENT),
                (DocumentFileCreationResult docFileResult) -> {
                    docFileResult.setDocumentId(input.getId().getValue());
                    docFileResult.setDocumentStatus(input.getData().getValidityCode().toString());
                });
    }

    private void fill(Category category, DocumentFileCreationResult fileCreationResponse, Predicate<Category> p,
            DocumentFileProcessor processor) {

        if(p.test(category)) {
            processor.process(fileCreationResponse);
            fileCreationResponse.setDetails(FILE_UPLOAD_VALIDITY_WARN.format());
        }
    }

    private static Stream<DocumentFileCreationResult> toApiFileCreationResponse(Stream<DocumentFile> documentFileStream) {
        return documentFileStream.map(new ConvertDocumentFileToRestWebApi());
    }
}