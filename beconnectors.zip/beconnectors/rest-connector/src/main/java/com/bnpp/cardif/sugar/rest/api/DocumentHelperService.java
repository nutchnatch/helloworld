package com.bnpp.cardif.sugar.rest.api;


import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

import javax.annotation.Nonnull;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;

/**
 * Created by b48489 on 17-08-2017.
 *
 * Provides operations to be performed on documents.
 */
public interface DocumentHelperService {

 /**
  * Get document through its ID.
  * @param scope - Sugar working scope.
  * @param docId - document's unique identification.
  * @param issuer - class type issuer.
  * @param scheme - database schema.
  * @return SimpleDocument
  * @throws SugarTechnicalException - technical error occurred.
  * @throws SugarFunctionalException - functional error occurred.
  */
   SimpleDocument getDocumentById(@Nonnull String scope, @Nonnull String docId, String issuer, String scheme)
            throws SugarFunctionalException, SugarTechnicalException;

 /**
  * Get documents through a list of document IDs.
  * @param scope - Sugar working scope.
  * @param idList - list of document ids.
  * @return PagedDocuments
  * @throws SugarTechnicalException - technical error occurred.
  * @throws SugarFunctionalException - functional error occurred.
  */
    PagedDocuments getDocumentsByIdList(@Nonnull String scope, @Nonnull List<Id> idList)
            throws SugarFunctionalException, SugarTechnicalException;

 /**
  * Get existing documents.
  * @param scope - Sugar working scope.
  * @param sort - sort order to be set on returned objects.
  * @param pageNumber - page number.
  * @param pageSize - page size.
  * @param name - document's name.
  * @param nameOperator - operator search parameter to be applied on name.
  * @param docType - document type ID.
  * @param confidentiality - confidentiality.
  * @param creationDate - creation date.
  * @param creationDateOperator - operator search parameter to be applied on creation date.
  * @param tags - tags search parameter.
  * @param tagsOperators - operator search parameter to be applied on tags.
  * @return PagedDocuments
  * @throws SugarTechnicalException - technical error occurred.
  * @throws SugarFunctionalException - functional error occurred.
  */
    PagedDocuments getDocuments(@Nonnull String scope, List<String> sort, int pageNumber, int pageSize, String name, String nameOperator,
            String docType, String confidentiality, LocalDate creationDate, String creationDateOperator, List<String> tags,
            List<String> tagsOperators) throws SugarFunctionalException, SugarTechnicalException;

 /**
  * Updates document.
  * @param docId - document unique identification.
  * @param documentData - document's associated data.
  * @param X_CARDIF_CONSUMER - cardif's consumer header.
  * @param scope - sugar working scope.
  * @param X_CARDIF_REQUEST_ID - cardif's request id header.
  * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
  * @param issuer - class type issuer.
  * @param scheme - database schema.
  * @return DocumentOperationResult
  * @throws SugarTechnicalException - technical error occurred.
  * @throws SugarFunctionalException - functional error occurred.
  */
    DocumentOperationResult updateDocument(@Nonnull String docId, @Nonnull ComposedDocumentData documentData,
            String X_CARDIF_CONSUMER, @Nonnull String scope, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID,
            String issuer, String scheme) throws SugarFunctionalException, SugarTechnicalException;

 /**
  * Delete document through its ID.
  * @param documentId - document unique identification.
  * @param scope - Sugar working scope.
  * @param issuer - class type issuer.
  * @param scheme - database schema.
  * @return DocumentOperationResult
  * @throws SugarTechnicalException - technical error occurred.
  * @throws SugarFunctionalException - functional error occurred.
  */
    DocumentOperationResult deleteDocument(String documentId, String scope, String issuer, String scheme) throws SugarFunctionalException, SugarTechnicalException;

 /**
  * Get documents through document id list.
  * @param scope - Sugar working scope.
  * @param idList - document id list.
  * @return Stream<Document>
  * @throws SugarTechnicalException - technical error occurred.
  * @throws SugarFunctionalException - functional error occurred.
  */
    Stream<Document> getDocumentList(@Nonnull String scope, @Nonnull List<Id> idList) throws SugarFunctionalException, SugarTechnicalException;
}
