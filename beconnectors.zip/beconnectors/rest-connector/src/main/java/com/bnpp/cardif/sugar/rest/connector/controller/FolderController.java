package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.facade.delegate.FolderHelper;
import com.bnpp.cardif.sugar.rest.web.api.FoldersApi;
import com.bnpp.cardif.sugar.rest.web.model.*;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.time.LocalDate;
import java.util.List;

/**
 * Created by b48489 on 29-09-2017.
 */

@Controller
public class FolderController implements FoldersApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(FolderController.class);
    @Autowired private FolderHelper folderHelper;

    @Override public ResponseEntity<PagedFolders> getFolders(

            @NotNull@ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue="1") Integer pageNumber,
            @NotNull @Min(0) @Max(100)@ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue="10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @ApiParam(value = "Provided name.") @RequestParam(value = "name", required = false) String name,
            @ApiParam(value = "Filter query definition.", allowableValues = "Contains, EqualsTo, StartsWith, EndsWith, Display") @RequestParam(value = "nameOperator", required = false) String nameOperator,
            @Pattern(regexp="[0-9]{4}/[0-9]{2}/[0-9]{2}")@ApiParam(value = "Creation date") @RequestParam(value = "creationDate", required = false) LocalDate creationDate,
            @ApiParam(value = "Filter query definition.", allowableValues = "GreatherThan, LessThan") @RequestParam(value = "creationDateOperator", required = false) String creationDateOperator,
            @ApiParam(value = "Folder's type identification.") @RequestParam(value = "folderTypeID", required = false) String folderTypeID,
            @ApiParam(value = "Representation of a tag with name and value.") @RequestParam(value = "tagEntries", required = false) List<String> tagEntries,
            @ApiParam(value = "Filter query definition.", allowableValues = "Contains, EqualsTo, StartsWith, EndsWith, Display, GreatherThan, LessThan") @RequestParam(value = "tagsOperators", required = false) List<String> tagsOperators,
            @Size(min=1,max=3)@ApiParam(value = "Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(folderHelper.getFolders(pageNumber, pageSize, X_CARDIF_CONSUMER, scope, name, nameOperator,
                    creationDate, creationDateOperator, folderTypeID, tagEntries, tagsOperators, sort, X_CARDIF_REQUEST_ID,
                    X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GetFolders", e);
            return ErrorResultBuilder.buildPagedFoldersErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildPagedFoldersErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<SimpleFolder> getFolderById(@ApiParam(value = "Folder ID",required=true ) @PathVariable("folderId") String folderId,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(folderHelper.getFolderById(folderId, X_CARDIF_CONSUMER, scope, classTypeIssuer, scheme,
                    X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            return ErrorResultBuilder.buildSimpleFolderErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildSimpleFolderErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<SimpleResponseResult> deleteDocumentFromFolder(
            @ApiParam(value = "",required=true ) @PathVariable("folderId") String folderId,
            @ApiParam(value = "",required=true ) @PathVariable("documentId") String documentId,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try{
            return ResponseEntity.ok(folderHelper.deleteDocumentFromFolder(folderId, documentId, scope, scheme, classTypeIssuer));
        }
        catch(SugarFunctionalException e) {
            return ErrorResultBuilder.buildSimpleResponseErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch(SugarTechnicalException e) {
            return ErrorResultBuilder.buildSimpleResponseErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<PagedDocuments> getDocumentsFromFolderId(
            @ApiParam(value = "Folder ID.",required=true ) @PathVariable("folderId") String folderId,
            @NotNull@ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue="1") Integer pageNumber,
            @NotNull @Min(0) @Max(100)@ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue="10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @Size(min=1,max=3)@ApiParam(value = "Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(folderHelper.getDocumentsFromFolderId(folderId, pageNumber, pageSize, X_CARDIF_CONSUMER,
                    scope, classTypeIssuer, scheme, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            return ErrorResultBuilder.buildPagedDocumentsErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildPagedDocumentsErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<DocumentAttachedToFoldersResult> attachDocumentToFolder(
            @ApiParam(value = "Folder ID.",required=true ) @PathVariable("folderId") String folderId,
            @NotNull@ApiParam(value = "Array of Documents to be attached to folder.", required = true) @RequestParam(value = "documentIds", required = true) List<String> documentIds,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(folderHelper.attachDocumentToFolder(folderId, X_CARDIF_CONSUMER, scope, classTypeIssuer,
                    scheme, documentIds, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            return ErrorResultBuilder.buildDocumentAttachedToFoldersErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildDocumentAttachedToFoldersErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<FolderCreationResult> addFolder(@ApiParam(value = "" ,required=true )  @Valid @RequestBody ComposedFolderData folderData,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @NotNull@ApiParam(value = "Identifies the version of the template.", required = true, defaultValue = "0") @RequestParam(value = "templateVersion", required = true, defaultValue="0") String templateVersion,
            @ApiParam(value = "Array of Documents to be attached to folder.") @RequestParam(value = "documentIds", required = false) List<String> documentIds,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(folderHelper.addFolder(folderData, X_CARDIF_CONSUMER, scope, classTypeIssuer, scheme,
                    templateVersion, documentIds, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            return ErrorResultBuilder.buildFolderCreationResultErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildFolderCreationResultErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<FolderCreationResult> updateFolder(@ApiParam(value = "Folder ID",required=true ) @PathVariable("folderId") String folderId,
            @ApiParam(value = "" ,required=true )  @Valid @RequestBody ComposedFolderData folderData,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies database schema set on application configuration.", required = true, defaultValue = "Sugar") @RequestParam(value = "scheme", required = true, defaultValue="Sugar") String scheme,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,@ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID,
            @ApiParam(value = "Folder Status Code. If it has \"Close\" value, the folder will be closed.", allowableValues = "Close") @RequestParam(value = "folderFreezeCode", required = false) String folderFreezeCode) {

        try {
            return ResponseEntity.ok(folderHelper.updateFolder(folderId, folderData, X_CARDIF_CONSUMER, scope, folderFreezeCode,
                    classTypeIssuer, scheme, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            return ErrorResultBuilder.buildFolderCreationResultErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildFolderCreationResultErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

}
