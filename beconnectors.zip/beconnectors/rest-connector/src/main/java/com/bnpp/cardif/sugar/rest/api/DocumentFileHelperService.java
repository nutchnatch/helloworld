package com.bnpp.cardif.sugar.rest.api;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.DocumentFileCreationResult;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

/**
 * Created by b48489 on 29-08-2017.
 *
 * Responsible for operations to be performed around document files.
 */
public interface DocumentFileHelperService {

    /**
     * Adds Document file to application. This file is attached to a document tha will be contained on an envelope.
     * @param upfile - MultipartFile to be uploaded.
     * @param scope - Sugar working scope.
     * @return DocumentFileCreationResult
     * @throws IOException - when occurs an error creating file.
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    DocumentFileCreationResult addDocumentFile(@Nonnull MultipartFile upfile, @Nonnull String scope) throws IOException,
            SugarTechnicalException, SugarFunctionalException;

    /**
     * Submits a list of document file to the application.
     * @param documentFileList - list of document file to be uploaded.
     * @return Optional<DocumentFileCreationResult>
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional errpor occurred.
     */
    Optional<DocumentFileCreationResult> submitFile(@Nonnull List<DocumentFile> documentFileList)
            throws SugarFunctionalException, SugarTechnicalException;

}
