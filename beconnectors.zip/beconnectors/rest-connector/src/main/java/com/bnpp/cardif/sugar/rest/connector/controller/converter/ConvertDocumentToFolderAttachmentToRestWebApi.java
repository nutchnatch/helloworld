package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.rest.web.model.DocumentAttachedToFoldersResult;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by b48489 on 29-08-2017.
 */
public class ConvertDocumentToFolderAttachmentToRestWebApi implements Function<Folder, DocumentAttachedToFoldersResult> {

    @Override public DocumentAttachedToFoldersResult apply(Folder folder) {
        return folder != null ? convert(folder) : null;
    }

    private static DocumentAttachedToFoldersResult convert(Folder folder) {
        DocumentAttachedToFoldersResult documentAttachedToFoldersResult = new DocumentAttachedToFoldersResult();
        fillExisting(folder, documentAttachedToFoldersResult);
        return documentAttachedToFoldersResult;
    }

    private static void fillExisting(Folder folder, DocumentAttachedToFoldersResult documentAttachedToFoldersResult) {

        documentAttachedToFoldersResult.setStatus(true);
        List<String> idList = folder.getChildComponents().getId().stream()
                .map(Id::getValue)
                .collect(Collectors.toList());
        documentAttachedToFoldersResult.setDocumentIdArray(idList);
        documentAttachedToFoldersResult.setFolderId(folder.getFolderId().getValue());
    }
}
