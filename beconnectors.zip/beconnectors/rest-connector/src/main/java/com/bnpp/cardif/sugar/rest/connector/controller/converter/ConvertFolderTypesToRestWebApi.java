package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.rest.web.model.AssociatedTag;
import com.bnpp.cardif.sugar.rest.web.model.FolderType;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static java.util.stream.Collectors.toList;

/**
 * Created by b48489 on 24-08-2017.
 */
public class ConvertFolderTypesToRestWebApi implements Function<FolderClass, FolderType> {

    private static Map tagMap = Collections.EMPTY_MAP;

    public ConvertFolderTypesToRestWebApi(Map<String, Tag> tagMap) {
        ConvertFolderTypesToRestWebApi.tagMap = tagMap;
    }

    private static void fillExisting(FolderClass folderClass, FolderType existingeFolderType) {

        existingeFolderType.setDisplayNameList(CommonConverterHelper.buildDisplayNameItemList(folderClass.getShortLabel()));
        existingeFolderType.setTagList(buildAssociatedTagList(folderClass));
        existingeFolderType.setName(folderClass.getLongLabel());
        existingeFolderType.setId(folderClass.getClassId().getValue());
        existingeFolderType.setIssuer(folderClass.getClassId().getIssuer());
        existingeFolderType.setVersion(Integer.toString(folderClass.getClassId().getVersId()));
    }

    private static FolderType convert(@Nonnull FolderClass folderClass) {
        FolderType apiFolderType = new FolderType();
        List<AssociatedTag> tmpList = new ArrayList<>();
        apiFolderType.setTagList(tmpList);
        fillExisting(folderClass, apiFolderType);
        return apiFolderType;
    }

    private static List<AssociatedTag> buildAssociatedTagList(@Nonnull FolderClass folderClass) {
        return folderClass.getTagReference().stream()
                .map((tagReference) -> CommonConverterHelper.buildAssociatedTag(tagReference, tagMap))
                .collect(toList());
    }

    @Override public FolderType apply(FolderClass documentClass) {
        return convert(documentClass);
    }
}
