package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.*;

import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class SimpleEnvelopeTypeBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }

        @Override public SimpleEnvelopeType build() {
            return Optional.ofNullable(this.getStatus()).isPresent()
                    ? simpleEnvelopeTypeInstance(this)
                    : raiseIllegalStateException();
        }

        @Override protected Builder self() {
            return this;
        }

        private SimpleEnvelopeType raiseIllegalStateException() {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    private static abstract class Prototype<E extends Prototype<E>> implements ObjectBuilder<SimpleEnvelopeType> {

        private Boolean status;
        private String details;
        private ErrorCause errorCause;
        private EnvelopeType envelopeType;

        Prototype(Boolean status) {
            this.status = status;
        }

        public EnvelopeType getEnvelopeType() {
            return envelopeType;
        }

        public E envelopeType(EnvelopeType envelopeType) {
            this.envelopeType = envelopeType;
            return self();
        }

        public Boolean getStatus() {
            return status;
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static SimpleEnvelopeType simpleEnvelopeTypeInstance(Prototype<?> builder) {

        SimpleEnvelopeType simpleEnvelopeType = new SimpleEnvelopeType();
        return simpleEnvelopeType
                .status(builder.getStatus())
                .details(builder.getDetails())
                .errorCause(builder.getErrorCause())
                .envelopeType(builder.getEnvelopeType());
    }
}
