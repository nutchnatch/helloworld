package com.bnpp.cardif.sugar.rest.connector.util;

/**
 * Created by b48489 on 14-09-2017.
 */
public class Constants {

    public static final String DOC_STATUS_CODE = "NEW";
    public static final String CONF_DNT_LTY_LVL = "PUBLIC";
    public static final String DIRECTION_CODE = "IN";
}
