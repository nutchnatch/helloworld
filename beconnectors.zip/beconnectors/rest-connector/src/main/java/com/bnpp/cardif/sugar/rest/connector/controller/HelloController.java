package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.rest.web.api.HelloApi;
import com.bnpp.cardif.sugar.rest.web.model.HelloWorldResponse;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by b48489 on 10-08-2017.
 */

@RestController
public class HelloController implements HelloApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(HelloController.class);

    @Override public ResponseEntity<HelloWorldResponse> hello(@ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @ApiParam(value = "The name of the person to whom to say hello") @RequestParam(value = "nameReal", required = false) String nameReal,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        LOGGER.debug("I am answering from Hello rest endpoint. How are you doing?");
        HelloWorldResponse helloWorldResponse = new HelloWorldResponse();
        helloWorldResponse.setMessage("Hello " + nameReal + ", your request has been received. Congratulations.");

        return ResponseEntity.ok(helloWorldResponse);
    }
}
