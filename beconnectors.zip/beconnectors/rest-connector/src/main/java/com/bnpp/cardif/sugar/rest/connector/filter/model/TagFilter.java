package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.google.common.collect.ImmutableMap;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.Map;

/**
 * Created by b48489 on 23-10-2017.
 */
public final class TagFilter {

    private static Criterion buildContainsCriterion(String tagName, String tagValue) {

        return CriteriaStringTypeHelper.buildContainsCriterion(
                Levels.TAG,
                tagName,
                Collections.singletonList(tagValue));
    }

    private static Criterion buildEqualToCriterion(String tagName, String tagValue) {

        return CriteriaStringTypeHelper.buildEqualsToCriterion(
                Levels.TAG,
                tagName,
                Collections.singletonList(tagValue));
    }

    private static Criterion buildStartsWithCriterion(String tagName, String tagValue) {

        return CriteriaStringTypeHelper.buildStartsWithCriterion(
                Levels.TAG,
                tagName,
                Collections.singletonList(tagValue));
    }

    private static Criterion buildEndsWithCriterion(String tagName, String tagValue) {

        return CriteriaStringTypeHelper.buildEndsWithCriterion(
                Levels.TAG,
                tagName,
                Collections.singletonList(tagValue));
    }

    private static Criterion buildDisplayDateCriterion(String tagName, String tagValue) {

        return CriteriaStringTypeHelper.buildDisplaysCriterion(
                Levels.TAG,
                tagName,
                Collections.singletonList(tagValue));
    }

    private static Criterion buildGreatherThanCriterion(String tagName, String tagValue) {

        return CriteriaDateTypeHelper.buildGreatherThanCriterion(
                Levels.TAG,
                tagName,
                Collections.singletonList(tagValue));
    }

    private static Criterion buildLessThanCriterion(String tagName, String tagValue) {

        return CriteriaDateTypeHelper.buildLessThanCriterion(
                Levels.TAG,
                tagName,
                Collections.singletonList(tagValue));
    }

    public static Map<Enum, Criterion> buildTagFilterConfiguration(String tagName, String tagValue) {

        return new ImmutableMap.Builder<Enum, Criterion>()
                .put(AllowedOperators.CONTAINS, buildContainsCriterion(tagName, tagValue))
                .put(AllowedOperators.EQUALS_TO, buildEqualToCriterion(tagName, tagValue))
                .put(AllowedOperators.STARTS_WITH, buildStartsWithCriterion(tagName, tagValue))
                .put(AllowedOperators.ENDS_WITH, buildEndsWithCriterion(tagName, tagValue))
                .put(AllowedOperators.DISPLAY, buildDisplayDateCriterion(tagName, tagValue))
                .put(AllowedOperators.GREATER_THAN, buildGreatherThanCriterion(tagName, tagValue))
                .put(AllowedOperators.LESS_THAN, buildLessThanCriterion(tagName, tagValue))
                .build();
    }
}
