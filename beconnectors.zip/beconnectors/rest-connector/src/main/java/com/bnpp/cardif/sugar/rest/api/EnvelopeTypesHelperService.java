package com.bnpp.cardif.sugar.rest.api;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.PagedEnvelopeTypes;
import com.bnpp.cardif.sugar.rest.web.model.PagedTags;
import com.bnpp.cardif.sugar.rest.web.model.SimpleEnvelopeType;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 06-09-2017.
 *
 * Describes operations that can be performed on envelope types.
 */
public interface EnvelopeTypesHelperService {

    /**
     * Get existing envelope types through search parameters.
     * @param scope - Sugar working scope.
     * @param pageNumber - page number.
     * @param pageSize - page size.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param name - envelope type name.
     * @param sort - sort order to be set on returned objects.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return PagedEnvelopeTypes
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    PagedEnvelopeTypes getEnvelopeTypes(@Nonnull String scope, @Nonnull Integer pageNumber, @Nonnull Integer pageSize,
            String X_CARDIF_CONSUMER, String name, List<String> sort, String X_CARDIF_REQUEST_ID,
            String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Get envelope type  through its ID.
     * @param envelopeTypeId - envelope type ID.
     * @param scope - Sugar working scope.
     * @param classTypeIssuer - class type issuer.
     * @param templateVersion - template version.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return SimpleEnvelopeType
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    SimpleEnvelopeType getEnvelopeTypeByID(@Nonnull String envelopeTypeId, @Nonnull String scope, @Nonnull String classTypeIssuer,
            @Nonnull String templateVersion, String X_CARDIF_CONSUMER, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws
            SugarFunctionalException, SugarTechnicalException;

    /**
     * Search envelope type's tags.
     * @param envelopeTypeId - envelope type ID.
     * @param pageNumber - page number.
     * @param pageSize - page size.
     * @param X_CARDIF_CONSUMER - - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param sort - sort order to be set on returned objects.
     * @param classTypeIssuer - class type issuer.
     * @param templateVersion - template version.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return PagedTags
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    PagedTags searchEnvelopeTags(@Nonnull String envelopeTypeId, @Nonnull Integer pageNumber, @Nonnull Integer pageSize,
            String X_CARDIF_CONSUMER, @Nonnull String scope, List<String> sort, @Nonnull String classTypeIssuer, @Nonnull String templateVersion,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException, SugarTechnicalException;
}
