package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.commands.envelope.DeleteEnvelope;
import com.bnpp.cardif.sugar.commands.envelope.GetEnvelope;
import com.bnpp.cardif.sugar.commands.envelope.GetPaginatedAndSortedEnvelopes;
import com.bnpp.cardif.sugar.commands.envelope.UpdateEnvelope;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.domain.exception.*;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConvertEnvelopeToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.filter.model.*;
import com.bnpp.cardif.sugar.rest.connector.response.model.*;
import com.bnpp.cardif.sugar.rest.connector.util.ExceptionHandler;
import com.bnpp.cardif.sugar.rest.api.DocumentFileHelperService;
import com.bnpp.cardif.sugar.rest.api.DocumentHelperService;
import com.bnpp.cardif.sugar.rest.api.EnvelopeHelperService;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.*;
import com.google.common.collect.ImmutableMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.*;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

/**
 * Created by b48489 on 17-08-2017.
 */
@Component("envelopeHelper")
@Scope("singleton")
public class EnvelopeHelper implements EnvelopeHelperService {

    @Autowired private DocumentService documentService;
    @Autowired private DocumentHelperService documentHelperService;
    @Autowired private DocumentFileHelperService fileHelperService;
    @Autowired private TagsHelperService tagsHelperService;

    @Override public PagedEnvelopes getEnvelopes(String scope, List<String> sort, int pageNumber, int pageSize,
            LocalDate creationDate, String envelopeTypeID, String creationDateOperator, List<String> tagEntries, List<String> tagsOperators)
            throws SugarFunctionalException, SugarTechnicalException {

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        return buildPagedEnvelopes(toApiEnvelope(getNativePaginatedSortedEnvelopes(scope, sort, pageNumber, pageSize,
                creationDate, envelopeTypeID, creationDateOperator, tagEntries, tagsOperators), tagMap)
                    .collect(toList()));
    }

    @Override public Stream<Document> getNativePaginatedSortedEnvelopes(String scope, List<String> sort, int pageNumber,
            int pageSize, LocalDate creationDate, String envelopeTypeID, String creationDateOperator, List<String> tagEntries,
            List<String> tagsOperators) throws SugarFunctionalException, SugarTechnicalException {

        final Criteria criteria = new CriteriaBuilder.Builder(Item.ENVELOPE)
                .criterionList(getFilterCriterionList(scope, creationDate, envelopeTypeID, creationDateOperator,
                        tagEntries, tagsOperators))
                .build();

        final OrderClause orderClause = CommonHelper.buildOrderClause(sort);

        pageNumber = CommonHelper.buildPageNumber(pageNumber);
        final int endPage = pageNumber + pageSize;

        return applyCriteriaAndGetEnvelopes(pageNumber, criteria, orderClause, endPage);
    }

    private List<Criterion> getFilterCriterionList(@Nonnull String scope, LocalDate creationDate, String envelopeTypeID,
            String creationDateOperator, List<String> tagEntries, List<String> tagsOperators) {

        List<Criterion> criterionList = new ArrayList<>();
        CommonHelper.buildUnderConstructionCriterion(criterionList);
        criterionList.add(ScopeFilter.buildEqualsScopeCriterion(scope));
        CommonHelper.buildClassTypeCriterion(envelopeTypeID, criterionList);
        CommonHelper.buildCreationDateCriterion(creationDate, creationDateOperator, criterionList);
        Map<String, String> tagMap = CommonHelper.createTagMap(tagEntries, tagsOperators);
        CommonHelper.buildTagsCriterion(tagEntries, criterionList, tagMap);
        return criterionList;
    }

    private Stream<Document> applyCriteriaAndGetEnvelopes(int pageNumber, Criteria criteria, OrderClause orderClause,
            int endPageNumber) throws SugarFunctionalException, SugarTechnicalException {

        GetPaginatedAndSortedEnvelopes<RestCallContext> command = new GetPaginatedAndSortedEnvelopes<>(new RestCallContext(), documentService,
                criteria, orderClause, pageNumber, endPageNumber);

        return StreamSupport.stream(command.call().spliterator(), false);
    }

    @Override public PagedDocuments getDocumentsByEnvelopeId(@Nonnull String envelopeId, String scope,
            List<String> sort, int pageNumber, int pageSize, String issuer, String scheme)
            throws SugarFunctionalException, SugarTechnicalException {

        SimpleEnvelope simpleEnvelope = getEnvelopeById(envelopeId, scope, issuer, scheme);
        Optional<Envelope> optionalEnvelopes = Optional.ofNullable(simpleEnvelope.getEnvelope());

        return optionalEnvelopes.isPresent() && documentIdsExist(simpleEnvelope)
                ? getDocuments(scope, issuer, scheme, getOptionalListOfDocumentId(simpleEnvelope).get())
                : new PagedDocumentsBuilder.Builder(false)
                        .details(DOCUMENTS_NOT_FOUND.format())
                        .build();
    }

    private boolean documentIdsExist(SimpleEnvelope simpleEnvelope) {
        return getOptionalListOfDocumentId(simpleEnvelope).isPresent() && !getOptionalListOfDocumentId(simpleEnvelope)
                .get().isEmpty();
    }

    private Optional<List<String>> getOptionalListOfDocumentId(SimpleEnvelope simpleEnvelope) {
        return Optional.ofNullable(simpleEnvelope.getEnvelope().getListOfDocumentId()) ;
    }

    private PagedDocuments getDocuments(String scope, String issuer, String scheme, List<String> docList)
            throws SugarFunctionalException, SugarTechnicalException {

        List<Id> docIdList = CommonHelper.getIdList(issuer, scheme, docList);
        return documentHelperService.getDocumentsByIdList(scope, docIdList);
    }

    private PagedEnvelopes buildPagedEnvelopes(@Nonnull List<com.bnpp.cardif.sugar.rest.web.model.Envelope> envelopeList) {

        return envelopeList.isEmpty()
                ? new PagedEnvelopesBuilder.Builder(false)
                        .details(ENVELOPE_NOT_FOUND.format())
                        .build()
                : createPagedEnvelopes(envelopeList);
    }

    private PagedEnvelopes createPagedEnvelopes(@Nonnull List<Envelope> envelopeList) {

        Paging paging = new Paging();
        paging.setPageSize(envelopeList.size());

        return new PagedEnvelopesBuilder.Builder(true)
                    .envelopes(envelopeList)
                    .paging(paging)
                    .build();
    }

    @Override public SimpleEnvelope getEnvelopeById(@Nonnull String envelopeId, @Nonnull String scope, String issuer,
            String scheme) throws SugarFunctionalException, SugarTechnicalException{

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        Optional<Envelope> optionalReturn = toApiEnvelope(fetchEnvelope(envelopeId, scope, issuer, scheme), tagMap).findFirst();
        return optionalReturn.isPresent()
                ? new SimpleEnvelopeBuilder.Builder(true)
                        .envelope(optionalReturn.get())
                        .build()
                : new SimpleEnvelopeBuilder.Builder(false)
                        .details(ENVELOPE_NOT_FOUND.format())
                        .build();
    }

    @Override
    public Stream<Document> fetchEnvelope(@Nonnull String envelopeId, @Nonnull String scope, String issuer,
            String scheme) throws SugarFunctionalException, SugarTechnicalException {

        final GetEnvelope<RestCallContext> command = buildGetEnvelopeCommand(envelopeId, scope, issuer, scheme);
        return StreamSupport.stream(command.call().spliterator(), false);
    }

    private GetEnvelope<RestCallContext> buildGetEnvelopeCommand(@Nonnull String envelopeId, @Nonnull String scope,
            String issuer, String scheme) {

        final List<Id> envelopeIdList = CommonHelper.buildIdList(envelopeId, issuer, scheme);
        return new GetEnvelope<>(new RestCallContext(), documentService, envelopeIdList, scope);
    }

    @Override public EnvelopeOperationResult updateEnvelope(@Nonnull String envelopeId, @Nonnull ComposedEnvelopeData composedEnvelopeData,
            String X_CARDIF_CONSUMER, @Nonnull String scope, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID,
            String issuer, String scheme)
            throws SugarFunctionalException, SugarTechnicalException{

            final GetEnvelope<RestCallContext> command = buildGetEnvelopeCommand(envelopeId, scope, issuer, scheme);
            Optional<Document> optionalEnvelope = StreamSupport.stream(command.call().spliterator(), false).findFirst();

            return optionalEnvelope.isPresent()
                    ? buildEnvelopeResult(Optional.of(
                            prepareAndUpdateEnvelope(scope, composedEnvelopeData, optionalEnvelope.get())))
                    : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00901);
    }

    @Override public DocumentFileCreationResult addFileToEnvelope(@Nonnull String envelopeId, String X_CARDIF_CONSUMER,
            @Nonnull String scope, @Nonnull String classTypeIssuer, @Nonnull String scheme, String X_CARDIF_REQUEST_ID,
            String X_CARDIF_EXT_REQ_ID, @Nonnull MultipartFile file) throws SugarFunctionalException, SugarTechnicalException, IOException{

            final List<DocumentFile> documentFileList = CommonHelper.buildDocumentFileList(file, scope);
            Optional<DocumentFileCreationResult> fileCreationResult = fileHelperService.submitFile(documentFileList);

            return fileCreationResult.isPresent()
                    ? processAndUpdateEnvelope(envelopeId, scope, classTypeIssuer, scheme, fileCreationResult.get().getDocumentFileId())
                    : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00102, " - ", ENVLEOPE_CANNOT_BE_UPDATED.format());
    }

    @Override public EnvelopeOperationResult deleteEnvelope(@Nonnull String envelopeId, String X_CARDIF_CONSUMER,
            @Nonnull String scope, @Nonnull String issuer, @Nonnull String scheme, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException {

        Optional<Document> optionalEnvelope = fetchEnvelope(envelopeId, scope, issuer, scheme).findFirst();

        return optionalEnvelope.isPresent() && optionalEnvelope.get().getData().getValidityCode() == ValdtyCode.UNDER_CONSTRUCTION
                ? new EnvelopeOperationResultBuilder.Builder(true)
                        .envelopeId(deleteEnvelope(envelopeId, scope, issuer, scheme))
                        .build()
                : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00901);
    }

    private String deleteEnvelope(@Nonnull String envelopeId, @Nonnull String scope, @Nonnull String issuer,
            @Nonnull String scheme) throws SugarFunctionalException, SugarTechnicalException {

        List<Id> idList = Collections.singletonList(CommonHelper.createId(envelopeId, issuer, scheme));

        DeleteEnvelope<RestCallContext> command = new DeleteEnvelope<>(new RestCallContext(), documentService, idList, scope);
        command.call();
        return envelopeId;
    }

    private DocumentFileCreationResult processAndUpdateEnvelope(@Nonnull String envelopeId, @Nonnull String scope,
            @Nonnull String classTypeIssuer,@Nonnull String scheme, @Nonnull String fileId) throws SugarFunctionalException, SugarTechnicalException {

            Document document = CommonHelper.createDocument(fileId, scope);
            Optional<Document> optionalEnvelope = fetchEnvelope(envelopeId, scope, classTypeIssuer, scheme).findFirst();

            return optionalEnvelope.isPresent() && optionalEnvelope.get().getData().getValidityCode() == ValdtyCode.UNDER_CONSTRUCTION
                    ? addDocumentToEnvelope(document, optionalEnvelope.get(), fileId)
                    : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00901);
    }

    private DocumentFileCreationResult addDocumentToEnvelope(@Nonnull Document document, @Nonnull Document envelope,
            @Nonnull String fileId) throws SugarFunctionalException, SugarTechnicalException{

        Optional.ofNullable(envelope.getChildObject().getDocument()).ifPresent(docList -> docList.add(document));
        return buildDocumentCreationResult(updateEnvelope(envelope), document, fileId);
    }

    private DocumentFileCreationResult buildDocumentCreationResult(@Nonnull Document updatedEnvelope,
            @Nonnull Document document, @Nonnull String fileId) {

        return new DocumentFileCreationResultBuilder.Builder(true)
                .envelopeId(updatedEnvelope.getId().getValue())
                .documentId(document.getId().getValue())
                .documentFileId(fileId)
                .docStatus(document.getData().getValidityCode().toString())
                .envStatus(updatedEnvelope.getData().getValidityCode().toString())
                .build();
    }

    private EnvelopeOperationResult buildEnvelopeResult(Optional<Document> optionalUpdatedEnvelope) {

        return optionalUpdatedEnvelope.isPresent()
                ? new EnvelopeOperationResultBuilder.Builder(true)
                        .envelopeId(optionalUpdatedEnvelope.get().getId().getValue())
                        .build()
                : new EnvelopeOperationResultBuilder.Builder(false)
                        .details(ENVELOPE_NOT_FOUND.format())
                        .build();
    }

    private DocumentFileCreationResult buildFailedResult() {

        return new DocumentFileCreationResultBuilder.Builder(false)
                .details(NOT_POSSIBLE_ATTACH_DOCUMENT_TO_ENVELOPE.format())
                .build();
    }

    private Document prepareAndUpdateEnvelope(@Nonnull String scope, @Nonnull ComposedEnvelopeData composedEnvelopeData,
            @Nonnull Document envelope) throws
            SugarTechnicalException, SugarFunctionalException {

        prepareEnvelope(scope, composedEnvelopeData, envelope);
        return updateEnvelope(envelope);
    }

    private Document updateEnvelope(@Nonnull Document envelope)
            throws SugarTechnicalException, SugarFunctionalException {

        List<Document> envelopeList = new ArrayList<>();
        envelopeList.add(envelope);

        final UpdateEnvelope<RestCallContext> updateEnvelope = new UpdateEnvelope<>(new RestCallContext(),
                documentService, envelopeList);
        return updateEnvelope.call();
    }

    private void prepareEnvelope(String scope, ComposedEnvelopeData composedEnvelopeData, Document envelope)
            throws SugarTechnicalException, SugarFunctionalException {

        Map<String, ComposedDocument> documentMap = composedEnvelopeData.getDocuments().stream()
                .collect(Collectors.toMap(ComposedDocument::getId, doc -> doc));

        List<Document> documentList = new ArrayList<>();
        for(Document document : envelope.getChildObject().getDocument()) {
            if(!documentMap.containsKey(document.getId().getValue())) {
                ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00104);
            }
            documentList.add(document);
        }

        ImmutableMap.Builder<String, List<Tag>> mapBuilder = new ImmutableMap.Builder<>();
        for(ComposedDocument document : composedEnvelopeData.getDocuments()) {

            if(!CommonHelper.containsLanguage(document.getDocumentLanguage())) {
                ExceptionHandler.raiseFunctionalException(FunctionalErrorCode.F00805);
            }

            mapBuilder.put(document.getId(), CollectionUtils.isEmpty(document.getTagList())
                    ? new ArrayList<>()
                    : CommonHelper.buildTagList(tagsHelperService, document.getTagList(), scope));
        }

        Map<String, List<Tag>> tagMap = mapBuilder.build();

        CommonHelper.updateEnvelopeData(composedEnvelopeData, envelope, CommonHelper.buildTagList(tagsHelperService, composedEnvelopeData.getTagList(), scope));
        documentList.forEach(doc -> CommonHelper.updateDocumentData(doc, documentMap.get(doc.getId().getValue()).getDocumentLanguage(),
                documentMap.get(doc.getId().getValue()).getDocumentTypeVersion(), documentMap.get(doc.getId().getValue()).getDocumentTypeIssuer(),
                documentMap.get(doc.getId().getValue()).getDocumentTypeId(), documentMap.get(doc.getId().getValue()).getName(), documentMap.get(doc.getId().getValue()).getRetentionStartDate(), tagMap.get(doc.getId().getValue())));
    }

    private Stream<Envelope> toApiEnvelope(Stream<Document> envelopeStream, Map<String, Tag> tagMap) {
        return envelopeStream
                .map(new ConvertEnvelopeToRestWebApi(tagMap));
    }

}