package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.commands.folder.AddFolder;
import com.bnpp.cardif.sugar.commands.folder.GetFolders;
import com.bnpp.cardif.sugar.commands.folder.GetFoldersById;
import com.bnpp.cardif.sugar.commands.folder.UpdateFolder;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.domain.exception.*;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConvertDocumentToFolderAttachmentToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConverterFolderToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.filter.model.*;
import com.bnpp.cardif.sugar.rest.connector.i18n.Messages;
import com.bnpp.cardif.sugar.rest.connector.response.model.*;
import com.bnpp.cardif.sugar.rest.connector.util.ExceptionHandler;
import com.bnpp.cardif.sugar.rest.api.DocumentHelperService;
import com.bnpp.cardif.sugar.rest.api.FolderHelperService;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpp.cardif.sugar.rest.web.model.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.*;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

/**
 * Created by b48489 on 29-09-2017.
 */
@Component("folderHelper")
@Scope("singleton")
public class FolderHelper implements FolderHelperService {

    private static Logger LOGGER = LoggerFactory.getLogger(FolderHelper.class);
    @Autowired private FolderService folderService;
    @Autowired private DocumentHelperService documentHelperService;
    @Autowired private TagsHelperService tagsHelperService;

    @Override public PagedFolders getFolders(@Nonnull Integer pageNumber, Integer pageSize, String X_CARDIF_CONSUMER,
            @Nonnull String scope, String name, String nameOperator, LocalDate creationDate,
            String creationDateOperator, String folderTypeID, List<String> tagEntries, List<String> tagsOperators, List<String> sort,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException, SugarTechnicalException {

        pageNumber = CommonHelper.buildPageNumber(pageNumber);
        final long endPage = pageNumber + pageSize;

        final Criteria criteria = new CriteriaBuilder.Builder(Item.FOLDER)
                .criterionList(getFilterCriterionList(scope, name, nameOperator, folderTypeID, creationDate, creationDateOperator,
                        tagEntries, tagsOperators))
                .build();

        final OrderClause orderClause = CommonHelper.buildOrderClause(sort);
        final GetFolders<RestCallContext> command = new GetFolders<>(new RestCallContext(), folderService, criteria,
                orderClause, pageNumber, endPage);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        return buildPagedFolders(toApiFolder(StreamSupport.stream(command.call().spliterator(), false), tagMap).collect(Collectors.toList()));
    }

    private List<Criterion> getFilterCriterionList(@Nonnull String scope, String name, String nameOperator, String folderType,
            LocalDate creationDate, String creationDateOperator, List<String> tags, List<String> tagsOperators) {

        List<Criterion> criterionList = new ArrayList<>();

        criterionList.add(ScopeFilter.buildEqualsScopeCriterion(scope));
        CommonHelper.buildNameCriterion(name, nameOperator, criterionList);
        CommonHelper.buildClassTypeCriterion(folderType, criterionList);
        CommonHelper.buildCreationDateCriterion(creationDate, creationDateOperator, criterionList);
        Map<String, String> tagMap = CommonHelper.createTagMap(tags, tagsOperators);
        CommonHelper.buildTagsCriterion(tags, criterionList, tagMap);

        return criterionList;
    }

    @Override public SimpleFolder getFolderById(@Nonnull String folderId, String X_CARDIF_CONSUMER,
            @Nonnull String scope, @Nonnull String issuer, @Nonnull String scheme, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException {

            Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
            Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

            Optional<Folder> folderOptional = toApiFolder(fetchFolder(folderId, scope, issuer, scheme), tagMap).findFirst();
            return folderOptional.isPresent()
                    ? new SimpleFolderBuilder.Builder(true)
                            .folder(folderOptional.get())
                            .build()
                    : new SimpleFolderBuilder.Builder(false)
                            .details(FOLDER_NOT_FOUND.format())
                            .build();
    }

    private Stream<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> fetchFolder(@Nonnull String folderId,
            @Nonnull String scope, @Nonnull String issuer, @Nonnull String scheme) throws SugarFunctionalException, SugarTechnicalException{

        List<FolderId> folderIdList = CommonHelper.buildFolderIdList(folderId, issuer, scheme);
        final GetFoldersById<RestCallContext> command = new GetFoldersById<RestCallContext>(new RestCallContext(),
                folderService, folderIdList, scope);

        return StreamSupport.stream(command.call().spliterator(), false);
    }

    @Override public PagedDocuments getDocumentsFromFolderId(@Nonnull String folderId, @Nonnull Integer pageNumber,
            @Nonnull Integer pageSize, String X_CARDIF_CONSUMER, String scope, @Nonnull String issuer, @Nonnull String scheme,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException, SugarTechnicalException {

        SimpleFolder simpleFolder = getFolderById(folderId, X_CARDIF_CONSUMER, scope, issuer, scheme, X_CARDIF_REQUEST_ID,
                X_CARDIF_EXT_REQ_ID);
        Optional<List<String>> optionalDocList = Optional.ofNullable(simpleFolder.getFolder().getListOfDocumentId());

        return optionalDocList.isPresent() && !optionalDocList.get().isEmpty()
                ? getDocuments(scope, issuer, scheme, optionalDocList.get())
                : new PagedDocumentsBuilder.Builder(false)
                        .details(DOCUMENT_FROM_FOLDER_NOT_FOUND.format())
                        .build();
    }

    @Override public DocumentAttachedToFoldersResult attachDocumentToFolder(@Nonnull String folderId,
            String X_CARDIF_CONSUMER, @Nonnull String scope, @Nonnull String classTypeIssuer, @Nonnull String scheme,
            @Nonnull List<String> documentIds, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException {

        Optional<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> optionalFolder =
                fetchFolder(folderId, scope, classTypeIssuer, scheme).findFirst();

        List<Id> docIdList = CommonHelper.getIdList(classTypeIssuer, scheme, documentIds);

        return optionalFolder.isPresent() && areDocumentsReady(optionalFolder.get(), scope, docIdList)
                ? updateFolderWithDocuments(docIdList, scope, folderService, optionalFolder.get())
                : ExceptionHandler.raiseFunctionalException(FunctionalErrorCode.F00108);
    }

    private boolean areDocumentsReady(@Nonnull com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder,
            @Nonnull String scope, @Nonnull List<Id> documentIds)
            throws SugarFunctionalException, SugarTechnicalException{

        if(documentIds.isEmpty() || !documentsExist(documentIds, scope)) {
            ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00104);
        }

        return true;
    }

    @Override public FolderCreationResult addFolder(@Nonnull ComposedFolderData composedFolderData, String X_CARDIF_CONSUMER,
            @Nonnull String scope, @Nonnull String issuer, @Nonnull String scheme, @Nonnull String version, List<String> documentIds,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException, SugarTechnicalException {

        if(documentIds != null && !documentsExist(documentIds, issuer, scope, scheme)) {
            ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00104);
        }

        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder =
                CommonHelper.createFolder(tagsHelperService, composedFolderData, scope);

        createChildComponentIfNull(folder);
        Optional.ofNullable(documentIds).ifPresent(docIds -> addDocumentsToFolder(issuer, scheme, docIds, folder));

        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> folderList =
                Collections.singletonList(folder);
        AddFolder<RestCallContext> command = new AddFolder<>(new RestCallContext(), folderService, folderList);
        Optional<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> optionalFolder =
                StreamSupport.stream(command.call().spliterator(), false).findFirst();

        return optionalFolder.isPresent()
                ? buildFolderCreationResult(optionalFolder.get().getFolderId().getValue())
                : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00301);
    }

    private boolean documentsExist(List<String> documentIds, @Nonnull String issuer, @Nonnull String scope, @Nonnull String scheme)
            throws SugarFunctionalException, SugarTechnicalException {

        return isDocumentListOfSameSize(documentIds.size(), scope, buildIdList(documentIds, issuer, scheme));
    }

    private boolean documentsExist(List<Id> documentIds, String scope)
            throws SugarFunctionalException, SugarTechnicalException {

        return isDocumentListOfSameSize(documentIds.size(), scope, documentIds);
    }

    private boolean isDocumentListOfSameSize(int documentIdsSize, String scope, List<Id> idList)
            throws SugarFunctionalException, SugarTechnicalException {

        int pageSize = documentHelperService.getDocumentList(scope, idList).collect(toList()).size();
        return pageSize == documentIdsSize;
    }

    private List<Id> buildIdList(List<String> documentIds, String issuer, String scheme) {

        final List<Id> idList = new ArrayList<>();
        Optional.ofNullable(documentIds).ifPresent(docIds -> idList.addAll(docIds.stream()
                .map(docId -> CommonHelper.buildIdList(docId, issuer, scheme))
                .flatMap(Collection::stream)
                .collect(toList())));
        return idList;
    }

    private void addDocumentsToFolder(@Nonnull String issuer, @Nonnull String scheme, @Nonnull List<String> documentIds,
            com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder) {

        List<Id> docIdList = CommonHelper.getIdList(issuer, scheme, documentIds);
        addDocIdsToFolder(docIdList, folder.getChildComponents().getId());
    }

    private void addDocIdsToFolder(List<Id> documentIds, List<Id> existingIdList) {
        if(existingIdList == null) {
            existingIdList = new ArrayList<>();
        }
        List<Id> finalIdList = existingIdList;
        documentIds.stream()
                .filter(docId -> !finalIdList.contains(docId))
                .forEach(existingIdList::add);
    }

    private void createChildComponentIfNull(
            com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder) {

        folder.setChildComponents(
                Optional.ofNullable(folder.getChildComponents()).orElse(new MCOFolderType.ChildComponents(null, null)));
    }

    @Override public FolderCreationResult updateFolder(@Nonnull String folderId, @Nonnull ComposedFolderData folderData,
            String X_CARDIF_CONSUMER, @Nonnull String scope, String folderFreezeCode, @Nonnull String issuer,
            @Nonnull String scheme, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException {

        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder = checkIfFolderIsReady(folderId, scope, issuer, scheme);
        return applyChangesAndUpdateFolder(scope, folder, folderData, folderFreezeCode);
    }

    private com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder checkIfFolderIsReady(@Nonnull String folderId,
            @Nonnull String scope, @Nonnull String issuer, @Nonnull String schema)
            throws SugarFunctionalException, SugarTechnicalException {

        Optional<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> optionalFolder = fetchFolder(folderId,
                scope, issuer, schema).findFirst();

        return (!optionalFolder.isPresent() || (optionalFolder.isPresent() && optionalFolder.get().getData().getStatusCode().equals(FolderStatusCodeType.CLOSE)))
                ? ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00304)
                : optionalFolder.get();
    }

    @Override public SimpleResponseResult deleteDocumentFromFolder(@Nonnull String folderId, @Nonnull String documentId,
            @Nonnull String scope, @Nonnull String schema, @Nonnull String issuer) throws SugarFunctionalException, SugarTechnicalException {

        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder = checkIfFolderIsReady(folderId, scope, issuer, schema);

        if(!documentsExist(Collections.singletonList(documentId), issuer, scope, schema)) {
            ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00104);
        }

        Optional<Id> optionalTargetId = getDocumentIdFromFolder(documentId, folder);
        optionalTargetId.ifPresent(folder.getChildComponents().getId()::remove);

        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> folderList = Collections.singletonList(folder);
        UpdateFolder<RestCallContext> command = new UpdateFolder<>(new RestCallContext(), folderService, folderList, scope);
        StreamSupport.stream(command.call().spliterator(), false);

        return new SimpleResultBuilder.Builder(true)
                .details(Messages.DOCUMENT_REMOVED_FROM_FOLDER.format())
                .build();
    }

    private Optional<Id> getDocumentIdFromFolder(@Nonnull String documentId,
            com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder)
            throws SugarTechnicalException {

        Optional<Id> docId = folder.getChildComponents().getId().stream()
                .filter(id -> id.getValue().equals(documentId))
                .findFirst();

        return docId.isPresent()
                ? docId
                : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00103);
    }

    private FolderCreationResult applyChangesAndUpdateFolder(@Nonnull String scope, com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder,
            ComposedFolderData composedFolderData, String folderFreezeCode) throws SugarFunctionalException, SugarTechnicalException {

        CommonHelper.updateFolderData(tagsHelperService, scope, composedFolderData, folder, folderFreezeCode);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> folderList = Collections
                .singletonList(folder);
        UpdateFolder<RestCallContext> command = new UpdateFolder<>(new RestCallContext(), folderService, folderList, scope);

        Optional<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> optionalFolder =
                StreamSupport.stream(command.call().spliterator(), false).findFirst();

        return optionalFolder.isPresent()
                ? buildFolderCreationResult(optionalFolder.get().getFolderId().getValue())
                : buildFailedFolderCreationResult();
    }

    private FolderCreationResult buildFolderCreationResult(String folderId) {

        return new FolderCreationResultBuilder.Builder(true)
                        .folderId(folderId)
                        .build();
    }

    private FolderCreationResult buildFailedFolderCreationResult() {

        return new FolderCreationResultBuilder.Builder(false)
                        .details(FOLDER_NOT_FOUND.format())
                        .build();
    }

    private DocumentAttachedToFoldersResult updateFolderWithDocuments(@Nonnull List<Id> docList, @Nonnull String scope, @Nonnull FolderService folderService,
            @Nonnull com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder folder)
            throws SugarFunctionalException, SugarTechnicalException {

        docList.forEach(id -> {
            if(!folder.getChildComponents().getId().contains(id)) {
                folder.getChildComponents().getId().add(id);
            }
        });

        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> folderList = Collections
                .singletonList(folder);
        UpdateFolder<RestCallContext> command = new UpdateFolder<>(new RestCallContext(), folderService, folderList, scope);

        Optional<DocumentAttachedToFoldersResult> optionalResult = toApiDocumentAttachedToFolder(
                StreamSupport.stream(command.call().spliterator(), false)).findFirst();

        return optionalResult.orElse(buildEmptyDocToFolderResult());
    }

    private DocumentAttachedToFoldersResult buildEmptyDocToFolderResult() {

        return new DocumentAttachedToFoldersResultBuilder.Builder(false)
                .details(DOCUMENT_NOT_ATTACHED_TO_FOLDERS.format())
                .build();
    }

    private PagedDocuments getDocuments(String scope, String issuer, String scheme, List<String> docList)
            throws SugarFunctionalException, SugarTechnicalException {

        List<Id> docIdList = CommonHelper.getIdList(issuer, scheme, docList);
        return documentHelperService.getDocumentsByIdList(scope, docIdList);
    }

    private PagedFolders buildPagedFolders(@Nonnull List<Folder> folderList) {

        return folderList.isEmpty()
                ? new PagedFoldersBuilder.Builder(false)
                        .details(FOLDERS_NOT_FOUND.format())
                        .build()
                : createPagedFolders(folderList);
    }

    private PagedFolders createPagedFolders(@Nonnull List<Folder> folderList) {

        Paging paging = new Paging();
        paging.setPageSize(folderList.size());

        return new PagedFoldersBuilder.Builder(true)
                .folders(folderList)
                .paging(paging)
                .build();
    }

    private Stream<Folder> toApiFolder(Stream<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> folderStream,
            Map<String, Tag> tagMap) {
        return folderStream.map(new ConverterFolderToRestWebApi(tagMap));
    }

    private Stream<DocumentAttachedToFoldersResult> toApiDocumentAttachedToFolder(Stream<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> folderStream) {
        return folderStream.map(new ConvertDocumentToFolderAttachmentToRestWebApi());
    }
}
