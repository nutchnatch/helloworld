package com.bnpp.cardif.sugar.rest.connector.facade.delegate;
import com.bnpp.cardif.sugar.commands.tag.GetTags;
import com.bnpp.cardif.sugar.commands.tag.GetTagsByName;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConvertTagClassToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.response.model.SimpleTagBuilder;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.TAGS_NOT_FOUND;
import static java.util.stream.Collectors.toList;

/**
 * Created by b48489 on 06-09-2017.
 */
@Component("tagHelper")
@Scope("singleton")
public class TagHelper implements TagsHelperService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TagHelper.class);
    @Autowired private TagclassService tagClassService;

    @Override public SimpleTag getTagsByName(List<String> tagNameList, @Nonnull String scope,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException,
            SugarTechnicalException{

        return buildSimpleTag(getTags(tagNameList, scope).collect(toList()));
    }

    @Override public Stream<Tag> getTags(@Nonnull List<String> tagNameList, @Nonnull String scope) throws
            SugarFunctionalException, SugarTechnicalException {

        final GetTagsByName<RestCallContext> command = new GetTagsByName<>(new RestCallContext(), tagClassService, scope, tagNameList);

        return toApiTags(StreamSupport.stream(command.call().spliterator(), false));
    }

    @Override public Stream<Tag> getAllTags(@Nonnull String scope) throws SugarFunctionalException, SugarTechnicalException{

        final GetTags<RestCallContext> getTagsCommand = new GetTags<>(new RestCallContext(), tagClassService, scope);
        return toApiTags(StreamSupport.stream(getTagsCommand.call().spliterator(), false));
    }

    private SimpleTag buildSimpleTag(@Nonnull List<Tag> tagList) {

        return tagList.isEmpty()
                ? new SimpleTagBuilder.Builder(false)
                        .details(TAGS_NOT_FOUND.format())
                        .build()
                : new SimpleTagBuilder.Builder(true)
                        .tag(tagList.stream().findFirst().get())
                        .build();
    }

    private Stream<Tag> toApiTags(Stream<TagClass> tagClasses) {
        return tagClasses.map(new ConvertTagClassToRestWebApi());
    }
}
