package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.annotation.Nonnull;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.commands.envelopetype.GenericGetDocumentTypesById;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.filter.model.AllowedOperators;
import com.bnpp.cardif.sugar.rest.connector.filter.model.ClassTypeFilter;
import com.bnpp.cardif.sugar.rest.connector.filter.model.DateFilter;
import com.bnpp.cardif.sugar.rest.connector.filter.model.NameFilter;
import com.bnpp.cardif.sugar.rest.connector.filter.model.TagFilter;
import com.bnpp.cardif.sugar.rest.connector.filter.model.ValidityCodeFilter;
import com.bnpp.cardif.sugar.rest.connector.i18n.Languages;
import com.bnpp.cardif.sugar.rest.connector.util.Constants;
import com.bnpp.cardif.sugar.rest.connector.util.ExceptionHandler;
import com.bnpp.cardif.sugar.rest.web.model.AssociatedTag;
import com.bnpp.cardif.sugar.rest.web.model.ComposedEnvelopeData;
import com.bnpp.cardif.sugar.rest.web.model.ComposedFolderData;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;

/**
 * Created by b48489 on 30-08-2017.
 */
final class CommonHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(CommonHelper.class);

    private static final String REGEX_EXPRESSION = "[a-zA-Z]*=.+";
    private static final String FOLDER_CLOSE_STATE = "Close";
    private static final String SUGAR_TMP_FILE = "SugarTmpFile";

    static Document createEnvelope(MCODocumentType.ChildObject childObject, String scope) {

        Document envelope = new Document();
        DocumentStatusType documentStatusType = new DocumentStatusType(Constants.DOC_STATUS_CODE, new Date(), null, null, null);
        envelope.setStatus(documentStatusType);
        ElectronicDocumentDataType data = new ElectronicDocumentDataType(null, Constants.CONF_DNT_LTY_LVL,
                Constants.DIRECTION_CODE, new Date(), new Date(), new Date(), new Date(), Languages.EN.getLanguageCode(), null, null, null, null, null,
                ValdtyCode.UNDER_CONSTRUCTION, null, null);
        envelope.setData(data);
        envelope.setChildObject(childObject);
        envelope.setScope(scope);
        envelope.setCategory(Category.ENVELOPE);
        return envelope;
    }

    static Document createDocument(String docFileId, String scope) {

        Document document = new Document();
        DocumentStatusType documentStatusType = new DocumentStatusType(Constants.DOC_STATUS_CODE, new Date(), null, null, null);
        document.setStatus(documentStatusType);
        ElectronicDocumentDataType data = new ElectronicDocumentDataType(null, null,
                null, new Date(), new Date(), new Date(), new Date(), Languages.EE.getLanguageCode(), null, null, null, null, null,
                ValdtyCode.UNDER_CONSTRUCTION, null, null);
        document.setData(data);
        document.setScope(scope);
        List<String> docFileIdList = new ArrayList<>();
        docFileIdList.add(docFileId);
        MCODocumentType.FileData fileData = new MCODocumentType.FileData(null, docFileIdList);
        document.setFileData(fileData);
        document.setCategory(Category.DOCUMENT);
        return document;
    }

    static Folder createFolder(TagsHelperService tagsHelperService, ComposedFolderData composedFolderData, String scope)
    throws SugarFunctionalException, SugarTechnicalException{

        ClassId classId = new ClassId(composedFolderData.getFolderTypeId(), composedFolderData.getFolderTypeIssuer(),
                Integer.valueOf(composedFolderData.getFolderTypeVersion()));
        FolderDataType folderDataType = new FolderDataType(classId, composedFolderData.getFolderName(), TokenCreator.getUsername(),
                null, null, new Date(), null, null,null, FolderStatusCodeType.OPEN);
        Folder folder = new Folder();
        folder.setScope(scope);
        folder.setData(folderDataType);
        List<com.bnpp.cardif.sugar.rest.web.model.Tag> folderTagList = CommonHelper.buildTagList(tagsHelperService, composedFolderData.getTagList(), scope);
        folder.setTags(new Tags(convertFromApiTags(folderTagList)));
        return folder;
    }

    private static List<Tag> convertTags(List<AssociatedTag> tagList) {

        return tagList.stream()
                .map(AssociatedTag::getTag)
                .map(tag -> new Tag(tag.getValue(), tag.getName()))
                .collect(Collectors.toList());
    }

    private static List<Tag> convertFromApiTags(List<com.bnpp.cardif.sugar.rest.web.model.Tag> tagList) {

        return tagList.stream()
                .map(tag -> new Tag(tag.getValue(), tag.getName()))
                .collect(Collectors.toList());
    }

    static void updateEnvelopeData(ComposedEnvelopeData composedEnvelopeData, Document envelope, List<com.bnpp.cardif.sugar.rest.web.model.Tag> tagList) {

        updateEnvelopeFields(composedEnvelopeData, envelope);
        updateFromTagNameList(envelope, tagList);
    }

    private static void updateEnvelopeFields(ComposedEnvelopeData composedEnvelopeData, Document envelope) {

        envelope.getStatus().setEffctveDate(new Date());
        ClassId classId = new ClassId(composedEnvelopeData.getEnvelopeTypeId(), composedEnvelopeData.getEnvelopeTypeIssuer(),
                Integer.valueOf(composedEnvelopeData.getEnvelopeTypeVersion()));
        envelope.getData().setClassId(classId);
        envelope.getData().setConfdntltyLvl(composedEnvelopeData.getEnvConfidentiality().name());
        envelope.getData().setDirectionCode(composedEnvelopeData.getEnvDirectionCode());
        envelope.getData().setCreator(TokenCreator.getUsername());
        envelope.getData().setLastModifier(TokenCreator.getUsername());
        envelope.getData().setValidityCode(ValdtyCode.VALID);
    }

    static void updateFolderData(TagsHelperService tagsHelperService, String scope, ComposedFolderData composedFolderData,
            Folder folder, String folderFreezeCode) throws SugarFunctionalException, SugarTechnicalException {

        folder.getData().setName(composedFolderData.getFolderName());
        ClassId classId = new ClassId(composedFolderData.getFolderTypeId(), composedFolderData.getFolderTypeIssuer(),
                Integer.valueOf(composedFolderData.getFolderTypeVersion()));
        folder.getData().setClassId(classId);
        List<com.bnpp.cardif.sugar.rest.web.model.Tag> folderTagList = CommonHelper.buildTagList(tagsHelperService, composedFolderData.getTagList(), scope);
        folder.getTags().getTag().addAll(convertFromApiTags(folderTagList));
        Optional.ofNullable(folderFreezeCode).ifPresent(code -> {
            if(code.equals(FOLDER_CLOSE_STATE)) {
                folder.getData().setStatusCode(FolderStatusCodeType.CLOSE);
            }
        });
    }

    static void updateDocumentData(@Nonnull Document doc, String language, @Nonnull String docTypeVersion,
            @Nonnull String docTypeIssuer, @Nonnull String docTypeId, @Nonnull String docName, LocalDate retentionStartDate,
            @Nonnull List<com.bnpp.cardif.sugar.rest.web.model.Tag> tagList) {

        updateDocFields(doc, language, docTypeVersion, docTypeIssuer, docTypeId, docName, retentionStartDate);
        updateFromTagNameList(doc, tagList);
    }

    public static boolean containsLanguage(String language) {

        for(Languages lan : Languages.values()) {
            if(language.equals(lan.getLanguageCode())) {
                return true;
            }
        }
        return false;
    }

    private static void updateDocFields(@Nonnull Document doc, String language, @Nonnull String docTypeVersion,
            @Nonnull String docTypeIssuer, @Nonnull String docTypeId, @Nonnull String docName, LocalDate retentionStartDate) {

        doc.getData().setClassId(buildClassId(docTypeVersion, docTypeIssuer, docTypeId));
        doc.getData().setClassId(doc.getData().getClassId());
        Optional.ofNullable(language).ifPresent(lan -> doc.getData().setLangCode(lan));
        doc.getData().setName(docName);
        doc.getData().setCreator(TokenCreator.getUsername());
        doc.getData().setLastModifier(TokenCreator.getUsername());
        doc.getData().setValidityCode(ValdtyCode.VALID);
        Optional.ofNullable(retentionStartDate).ifPresent(date -> doc.getData().setRetentionStartDate(Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant())));
    }

    private static ClassId buildClassId(@Nonnull String docTypeVersion, @Nonnull String docTypeIssuer,
            @Nonnull String docTypeId) {

        return new ClassId(docTypeId, docTypeIssuer, Integer.valueOf(docTypeVersion));
    }

    private static void updateFromTagNameList(Document doc, List<com.bnpp.cardif.sugar.rest.web.model.Tag> tagList) {

        if(!CollectionUtils.isEmpty(tagList)) {
            List<Tag> documentTagList = CommonHelper.convertFromApiTags(tagList);
            doc.setTags(new Tags(documentTagList));
        }
    }

    static List<Id> buildIdList(@Nonnull String docId, String issuer, String scheme) {

        List<Id> idList = new ArrayList<>();
        Id id = createId(docId, issuer, scheme);
        idList.add(id);
        return idList;
    }

    static List<FolderId> buildFolderIdList(@Nonnull String id, String issuer, String scheme) {

        List<FolderId> idList = new ArrayList<>();
        FolderId folderId = createFolderId(id, issuer, scheme);
        idList.add(folderId);
        return idList;
    }

    static Id createId(@Nonnull String docId, String issuer, String scheme) {
        return new Id(docId, issuer, scheme);
    }

    private static FolderId createFolderId(String idValue, String issuer, String scheme) {
        return new FolderId(idValue, issuer, scheme);
    }

    static List<Id> getIdList(String issuer, String scheme, List<String> docList) {

        return docList.stream()
                .map(docId -> createId(docId, issuer, scheme))
                .collect(Collectors.toList());
    }

    static OrderClause buildOrderClause(List<String> sort) {

        //TODO - extracts sort direction and sort attributes properly
        String sortEntry = sort.get(0);
        sortEntry = sortEntry.substring(1, sortEntry.length());
        return new OrderClause(Levels.DATA, sortEntry, Types.TIMESTAMP, false);
    }

    private static FileDataSource createFileDataSource(InputStream inputStream) throws SugarTechnicalException,SugarFunctionalException {

        File tmpFile = new File(SUGAR_TMP_FILE);
        try {
            Files.copy(inputStream, tmpFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return new FileDataSource(tmpFile);
        }
        catch (IOException e) {
            LOGGER.error("Error creating File Data Source", e);
            throw new SugarFunctionalException(e.getMessage(), e.getCause());
        }
    }

    static List<DocumentFile> buildDocumentFileList(@Nonnull MultipartFile file, @Nonnull String scope)
            throws SugarTechnicalException, SugarFunctionalException, IOException {

        List<DocumentFile> documentFileList = new ArrayList<>();
        FileDataSource fileDataSource = CommonHelper.createFileDataSource(file.getInputStream());
        DocumentFile documentFile = new DocumentFile();
        documentFile.setContent(new DataHandler(fileDataSource));
        documentFile.setScope(scope);
        documentFile.setName(file.getName());
        documentFileList.add(documentFile);
        return documentFileList;
    }

    static GenericGetDocumentTypesById<RestCallContext> buildGetDocumentTypeCommand(@Nonnull String envelopeTypeId, @Nonnull String scope,
            @Nonnull DocumentClassService documentClassService, @Nonnull String classTypeIssuer, @Nonnull String templateVersion) {

        List<ClassId> classIdList = new ArrayList<>();
        ClassId classId = new ClassId(envelopeTypeId, classTypeIssuer, Integer.valueOf(templateVersion));
        classIdList.add(classId);
        return new GenericGetDocumentTypesById<>(new RestCallContext(), documentClassService,
                scope, classIdList);
    }

    static boolean validateTags(List<String> tagEntries) {

        final java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(REGEX_EXPRESSION);
        return tagEntries.stream()
                .filter(tagEntry -> !pattern.matcher(StringUtils.trim(tagEntry)).matches())
                .collect(Collectors.toList()).isEmpty();
    }

    static long getDateMilliSeconds(LocalDate creationDate) {
        return creationDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    static Map<String, String> createTagMap(List<String> tags, List<String> tagsOperators) {

        return Optional.ofNullable(tags).isPresent() ? tags.stream()
                .collect(Collectors.toMap(tag -> tag, tag -> tagsOperators.get(tags.indexOf(tag)))) : null;
    }

    static String getEntryFromTagMap(Map<String, String> tagMap, String[] array) {
        return tagMap.get(array[0] + "=" + array[1]);
    }

    static void buildTagsCriterion(List<String> tagEntries, List<Criterion> criterionList,
            Map<String, String> tagMap) {

        Optional.ofNullable(tagEntries).ifPresent(elements -> elements.stream()
                .map(tag -> tag.split("="))
                .map(array -> TagFilter.buildTagFilterConfiguration(array[0], array[1]).get(
                        Optional.ofNullable(AllowedOperators.getValueOf(CommonHelper.getEntryFromTagMap(tagMap, array)))
                                .orElse(AllowedOperators.EQUALS_TO)))
                .forEach(criterionList::add));
    }

    static void buildCreationDateCriterion(LocalDate creationDate, String creationDateOperator,
            List<Criterion> criterionList) {

        Optional.ofNullable(creationDate).ifPresent(value ->
                criterionList.add(DateFilter.buildDateOperationConfiguration(Long.toString(CommonHelper.getDateMilliSeconds(value))).get(
                        Optional.ofNullable(AllowedOperators.getValueOf(creationDateOperator))
                                .orElse(AllowedOperators.GREATER_THAN))));
    }

    static void buildClassTypeCriterion(String classType, List<Criterion> criterionList) {

        Optional.ofNullable(classType).ifPresent(type -> Optional.of(type)
                .filter(StringUtils::isNotEmpty)
                .ifPresent(value -> criterionList.add(ClassTypeFilter.buildEqualsClassTypeCriterion(value))));
    }

    static void buildUnderConstructionCriterion(List<Criterion> criterionList) {

        criterionList.add(ValidityCodeFilter.buildValidityCodeOperationConfiguration(ValdtyCode.UNDER_CONSTRUCTION)
                .get(AllowedOperators.NOT_EQUALS_TO));
    }

    static void buildNameCriterion(String name, String nameOperator, List<Criterion> criterionList) {

        Optional.ofNullable(name).ifPresent(nameValue -> Optional.of(nameValue)
                .filter(StringUtils::isNotEmpty)
                .ifPresent(value ->
                        criterionList.add(NameFilter.buildNameOperationConfiguration(value).get(
                                Optional.ofNullable(AllowedOperators.getValueOf(nameOperator))
                                        .orElse(AllowedOperators.CONTAINS)))));
    }

    private static List<com.bnpp.cardif.sugar.rest.web.model.Tag> findTags(TagsHelperService tagsHelperService,
            @Nonnull String scope, List<String> tagNameList) throws SugarFunctionalException, SugarTechnicalException {

        List<com.bnpp.cardif.sugar.rest.web.model.Tag> tagList = tagsHelperService.getTags(tagNameList, scope).collect(toList());
        return !CollectionUtils.isEmpty(tagNameList) && tagNameList.size() != tagList.size()
                ? ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00803)
                : tagList;
    }

    static List<com.bnpp.cardif.sugar.rest.web.model.Tag> buildTagList(TagsHelperService tagsHelperService,
            List<String> composedTagNameList, String scope) throws SugarFunctionalException, SugarTechnicalException {

        Map<String, String> tagNameValueMap = CollectionUtils.isEmpty(composedTagNameList)
                ? new HashMap<>()
                : composedTagNameList.stream()
                .map(tag -> tag.split("="))
                .collect(toMap(array -> array[0], array -> array[1]));

        List<String> tagNameList = tagNameValueMap.keySet().stream()
                .collect(toList());

        List<com.bnpp.cardif.sugar.rest.web.model.Tag> tagList = findTags(tagsHelperService, scope, tagNameList);

        tagList.forEach(tag -> tag.setValue(tagNameValueMap.get(tag.getName())));
        return tagList;
    }

    static int buildPageNumber(int pageNumber) {
       return pageNumber > 0 ? -- pageNumber : pageNumber;
    }
}
