package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.rest.web.model.DocumentFileCreationResult;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

import java.util.function.Function;

/**
 * Created by b48489 on 29-08-2017.
 */
public class ConvertDocumentFileToRestWebApi implements Function<DocumentFile, DocumentFileCreationResult> {

    @Override public DocumentFileCreationResult apply(DocumentFile documentFile) {
        return documentFile != null ? convert(documentFile) : null;
    }

    private static DocumentFileCreationResult convert(DocumentFile documentFile) {
        DocumentFileCreationResult documentFileCreationResult = new DocumentFileCreationResult();
        fillExisting(documentFile, documentFileCreationResult);
        return documentFileCreationResult;
    }

    private static void fillExisting(DocumentFile documentFile, DocumentFileCreationResult documentFileCreationResult) {
        documentFileCreationResult.setDocumentFileId(documentFile.getURI());
        documentFileCreationResult.setStatus(true);
    }
}
