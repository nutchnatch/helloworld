package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.*;

import java.util.Arrays;
import java.util.List;

/**
 * Created by b48489 on 20-10-2017.
 */
public final class CriteriaDateTypeHelper {

    public static Criterion buildDisplaysCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.DISPLAY)
                .type(Types.TIMESTAMP)
                .values(values)
                .build();
    }

    public static Criterion buildGreatherThanCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.GREATER_THAN)
                .type(Types.TIMESTAMP)
                .values(values)
                .build();
    }

    public static Criterion buildLessThanCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.LESS_THAN)
                .type(Types.TIMESTAMP)
                .values(values)
                .build();
    }
}
