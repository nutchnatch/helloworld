package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.facade.delegate.TagHelper;
import com.bnpp.cardif.sugar.rest.web.api.TagsApi;
import com.bnpp.cardif.sugar.rest.web.model.SimpleTag;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.Collections;

/**
 * Created by b48489 on 06-09-2017.
 */
@RestController
public class TagController implements TagsApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(TagController.class);
    @Autowired TagHelper tagHelper;

    @Override
    public ResponseEntity<SimpleTag> getTagsByName(@ApiParam(value = "Name that identifies the tag uniquely.",required=true ) @PathVariable("tagName") String tagName,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Dugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(tagHelper.getTagsByName(Collections.singletonList(tagName), scope, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GetTagsByName", e);
            return ErrorResultBuilder.buildSimpleTagErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildSimpleTagErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }
}