package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.Document;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.web.model.SimpleDocument;
import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class SimpleDocumentBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }

        @Override protected Builder self() {
            return this;
        }

        @Override public SimpleDocument build() {

            return Optional.ofNullable(this.getStatus()).isPresent()
                    ? simpleDocumentInstance(this)
                    : raiseIllegalStateException();
        }

        private SimpleDocument raiseIllegalStateException() throws IllegalStateException {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<SimpleDocument> {

        private Boolean status;
        private Document document;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public Document getDocument() {
            return document;
        }

        public E document(Document document) {
            this.document = document;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static SimpleDocument simpleDocumentInstance(Prototype<?> builder) {

        SimpleDocument simpleDocument = new SimpleDocument();
        simpleDocument.setDetails(builder.getDetails());
        simpleDocument.setStatus(builder.getStatus());
        simpleDocument.setErrorCause(builder.getErrorCause());
        simpleDocument.setDocument(builder.getDocument());

        return simpleDocument;
    }
}
