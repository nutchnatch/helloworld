package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.rest.web.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * Created by b48489 on 25-09-2017.
 */
public final class ErrorResultBuilder {

    static final String FUNCTIONAL_TYPE = "FE";
    static final String TECHNICAL_TYPE = "TE";

    private static ErrorCause buildErrorResult(HttpStatus errorStatus, String message,
            StackTraceElement[] stackTraceElements, String errorType, String errorCode) {

        ErrorStack errorStack = new ErrorStack()
                .code(errorCode)
                .message(message)
                .detail(Arrays.stream(stackTraceElements).map(StackTraceElement::toString).collect(Collectors.toList()));

        return new ErrorCause()
                .code(errorStatus.toString())
                .errorDate(LocalDate.now())
                .errorType(errorType)
                .stack(errorStack);
    }

    private static ErrorCause buildErrorCause(Exception e, String errorType, String errorCode) {
        return ErrorResultBuilder.buildErrorResult(
                HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e.getStackTrace(), errorType, errorCode);
    }

    static ResponseEntity<DocumentAttachedToFoldersResult> buildDocumentAttachedToFoldersErrorResult(
            SugarException e, String errorType) {

        DocumentAttachedToFoldersResult documentAttachedToFoldersResult = new DocumentAttachedToFoldersResult();
        documentAttachedToFoldersResult.setStatus(false);
        documentAttachedToFoldersResult.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(documentAttachedToFoldersResult);
    }

    static ResponseEntity<PagedDocuments> buildPagedDocumentsErrorResult(
            SugarException e, String errorType) {

        PagedDocuments pagedDocuments = new PagedDocuments();
        pagedDocuments.setStatus(false);
        pagedDocuments.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(pagedDocuments);
    }

    static ResponseEntity<SimpleFolder> buildSimpleFolderErrorResult(
            SugarException e, String errorType) {

        SimpleFolder simpleFolder = new SimpleFolder();
        simpleFolder.setStatus(false);
        simpleFolder.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(simpleFolder);
    }

    static ResponseEntity<SimpleResponseResult> buildSimpleResponseErrorResult(
            SugarException e, String errorType) {

        SimpleResponseResult simpleResponseResult = new SimpleResponseResult();
        simpleResponseResult.setStatus(false);
        simpleResponseResult.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(simpleResponseResult);
    }

    static ResponseEntity<PagedFolders> buildPagedFoldersErrorResult(
            SugarException e, String errorType) {

        PagedFolders pagedFolders = new PagedFolders();
        pagedFolders.setStatus(false);
        pagedFolders.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(pagedFolders);
    }

    static ResponseEntity<SimpleFolderType> buildSimpleFolderTypeErrorResult(
            SugarException e, String errorType) {

        SimpleFolderType simpleFolderType = new SimpleFolderType();
        simpleFolderType.setStatus(false);
        simpleFolderType.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(simpleFolderType);
    }

    static ResponseEntity<PagedFolderType> buildPagedFolderTypeErrorResult(
            SugarException e, String errorType) {

        PagedFolderType pagedFolderType = new PagedFolderType();
        pagedFolderType.setStatus(false);
        pagedFolderType.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(pagedFolderType);
    }

    static ResponseEntity<PagedTags> buildPagedTagsErrorResult(
            SugarException e, String errorType) {

        PagedTags pagedTags = new PagedTags();
        pagedTags.setStatus(false);
        pagedTags.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(pagedTags);
    }

    static ResponseEntity<SimpleTag> buildSimpleTagErrorResult(
            SugarException e, String errorType) {

        SimpleTag simpleTag = new SimpleTag();
        simpleTag.setStatus(false);
        simpleTag.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(simpleTag);
    }
    static ResponseEntity<SimpleEnvelopeType> buildSimpleEnvelopeTypeErrorResult(
            SugarException e, String errorType) {

        SimpleEnvelopeType simpleEnvelopeType = new SimpleEnvelopeType();
        simpleEnvelopeType.setStatus(false);
        simpleEnvelopeType.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(simpleEnvelopeType);
    }

    static ResponseEntity<PagedEnvelopeTypes> buildPagedEnvelopeTypesErrorResult(
            SugarException e, String errorType) {

        PagedEnvelopeTypes pagedEnvelopeTypes = new PagedEnvelopeTypes();
        pagedEnvelopeTypes.setStatus(false);
        pagedEnvelopeTypes.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(pagedEnvelopeTypes);
    }

    static ResponseEntity<SimpleEnvelope> buildSimpleEnvelopeErrorResult(
            SugarException e, String errorType) {

        SimpleEnvelope simpleEnvelope = new SimpleEnvelope();
        simpleEnvelope.setStatus(false);
        simpleEnvelope.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(simpleEnvelope);
    }

    static ResponseEntity<PagedEnvelopes> buildPagedEnvelopesErrorResult(
            SugarException e, String errorType) {

        PagedEnvelopes pagedEnvelopes = new PagedEnvelopes();
        pagedEnvelopes.setStatus(false);
        pagedEnvelopes.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(pagedEnvelopes);
    }

    static ResponseEntity<EnvelopeOperationResult> buildEnvelopeOperationErrorResult(
            SugarException e, String errorType) {

        EnvelopeOperationResult envelopeOperationResult = new EnvelopeOperationResult();
        envelopeOperationResult.setStatus(false);
        envelopeOperationResult.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(envelopeOperationResult);
    }

    static ResponseEntity<SimpleDocumentType> buildSimpleDocumentTypeErrorResult(
            SugarException e, String errorType) {

        SimpleDocumentType simpleDocumentType = new SimpleDocumentType();
        simpleDocumentType.setStatus(false);
        simpleDocumentType.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(simpleDocumentType);
    }

    static ResponseEntity<SimpleDocument> buildSimpleDocumentErrorResult(
            SugarException e, String errorType) {

        SimpleDocument simpleDosimpleDocument = new SimpleDocument();
        simpleDosimpleDocument.setStatus(false);
        simpleDosimpleDocument.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(simpleDosimpleDocument);
    }

    static ResponseEntity<PagedDocumentTypes> buildPagedDocumentTypesErrorResult(
            SugarException e, String errorType) {

        PagedDocumentTypes pagedDocumentTypes = new PagedDocumentTypes();
        pagedDocumentTypes.setStatus(false);
        pagedDocumentTypes.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(pagedDocumentTypes);
    }

    static ResponseEntity<DocumentFileCreationResult> buildDocumentFileCreationErrorResult(
            Exception e, String errorType) {

        DocumentFileCreationResult fileCreationResult = new DocumentFileCreationResult();
        fileCreationResult.setStatus(false);
        fileCreationResult.setErrorCause(buildErrorCause(e, errorType, HttpStatus.INTERNAL_SERVER_ERROR.toString()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(fileCreationResult);
    }

    static ResponseEntity<DocumentOperationResult> buildDocumentOperationErrorResult(
            SugarException e, String errorType) {

        DocumentOperationResult documentOperationResult = new DocumentOperationResult();
        documentOperationResult.setStatus(false);
        documentOperationResult.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(documentOperationResult);
    }

    static ResponseEntity<FolderCreationResult> buildFolderCreationResultErrorResult(
            SugarException e, String errorType) {

        FolderCreationResult folderCreationResult = new FolderCreationResult();
        folderCreationResult.setStatus(false);
        folderCreationResult.setErrorCause(buildErrorCause(e, errorType, e.getCode()));
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(folderCreationResult);
    }
}
