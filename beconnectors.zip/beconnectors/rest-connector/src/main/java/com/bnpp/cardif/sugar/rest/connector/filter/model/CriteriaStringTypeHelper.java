package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.*;

import java.util.Arrays;
import java.util.List;

/**
 * Created by b48489 on 20-10-2017.
 */
public final class CriteriaStringTypeHelper {

    private static Criteria builtCriteriaFromCriterionArray(Item item, Criterion... criterion) {

        return new CriteriaBuilder.Builder(item)
                .criterionList(Arrays.asList(criterion))
                .build();
    }

    private static Criteria builtCriteriaFromCriterionList(Item item, List<Criterion> criterionList) {

        return new CriteriaBuilder.Builder(item)
                .criterionList(criterionList)
                .build();
    }

    private static Criterion buildCriterion(final Levels level, final String name, final Operators operator, final Types type,
            final List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(operator)
                .type(type)
                .values(values)
                .build();
    }

    public static Criterion buildStartDateCriterion(final Levels level, final String name, final List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.STARTS_WITH)
                .type(Types.TIMESTAMP)
                .values(values)
                .build();
    }

    public static Criterion buildContainsCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.CONTAINS)
                .type(Types.STRING)
                .values(values)
                .build();
    }

    public static Criterion buildStartsWithCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.STARTS_WITH)
                .type(Types.STRING)
                .values(values)
                .build();
    }

    public static Criterion buildEndsWithCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.ENDS_WITH)
                .type(Types.STRING)
                .values(values)
                .build();
    }

    public static Criterion buildDisplaysCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.DISPLAY)
                .type(Types.STRING)
                .values(values)
                .build();
    }

    public static Criterion buildEqualsToCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.EQUALS_TO)
                .type(Types.STRING)
                .values(values)
                .build();
    }

    public static Criterion buildNotEqualsToCriterion(final Levels level, final String name, List<String> values) {

        return new CriterionBuilder.Builder(level)
                .name(name)
                .operator(Operators.NOT_EQUALS_TO)
                .type(Types.STRING)
                .values(values)
                .build();
    }
}
