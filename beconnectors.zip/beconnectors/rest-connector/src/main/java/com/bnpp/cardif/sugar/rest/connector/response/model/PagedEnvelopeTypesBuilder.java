package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.*;

import java.util.List;
import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class PagedEnvelopeTypesBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }

        @Override public PagedEnvelopeTypes build() {
            return Optional.ofNullable(this.getStatus()).isPresent()
                    ? pagedEnvelopeTypesInstance(this)
                    : raiseIllegalStateException();
        }

        @Override protected Builder self() {
            return this;
        }

        private PagedEnvelopeTypes raiseIllegalStateException() {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    private static abstract class Prototype<E extends Prototype<E>> implements ObjectBuilder<PagedEnvelopeTypes> {

        private Boolean status;
        private List<EnvelopeType> envelopeTypes;
        private Paging paging;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public List<EnvelopeType> getEnvelopeTypes() {
            return envelopeTypes;
        }

        public E envelopeTypes(List<EnvelopeType> envelopeTypes) {
            this.envelopeTypes = envelopeTypes;
            return self();
        }

        public Paging getPaging() {
            return paging;
        }

        public E paging(Paging paging) {
            this.paging = paging;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static PagedEnvelopeTypes pagedEnvelopeTypesInstance(Prototype<?> builder) {

        PagedEnvelopeTypes pagedEnvelopeTypes = new PagedEnvelopeTypes();
        return pagedEnvelopeTypes
                .status(builder.getStatus())
                .details(builder.getDetails())
                .errorCause(builder.getErrorCause())
                .paging(builder.getPaging())
                .envelopeTypes(builder.getEnvelopeTypes());
    }
}
