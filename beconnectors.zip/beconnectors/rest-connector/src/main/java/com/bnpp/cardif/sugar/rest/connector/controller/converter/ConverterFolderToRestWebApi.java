package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.EDMS2IdentificationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

import java.time.ZoneId;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Created by b48489 on 29-09-2017.
 */
public class ConverterFolderToRestWebApi implements Function<Folder, com.bnpp.cardif.sugar.rest.web.model.Folder> {


    private static Map tagMap = Collections.EMPTY_MAP;

    public ConverterFolderToRestWebApi(Map<String, Tag> tagMap) {
        ConverterFolderToRestWebApi.tagMap = tagMap;
    }

    private static void fillExisting(Folder folder, com.bnpp.cardif.sugar.rest.web.model.Folder existingFolder) {

        existingFolder.setId(folder.getFolderId().getValue());
        existingFolder.setCreationDate(folder.getData().getCreatnDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        Optional.ofNullable(folder.getData().getStatusCode()).ifPresent(code -> existingFolder.setStatus(code.toString()));
        Optional.ofNullable(folder.getData().getClassId()).ifPresent(type -> existingFolder.setFolderTypeId(type.getValue()));
        Optional.ofNullable(folder.getData().getName()).ifPresent(existingFolder::setName);
        Optional.ofNullable(folder.getData().getOwner()).ifPresent(existingFolder::setOwner);
        Optional.ofNullable(folder.getData().getUpdtDate()).ifPresent(date -> existingFolder.setLastUpdateDate(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
        Optional.ofNullable(folder.getData().getRetentionEndDate()).ifPresent(date -> existingFolder.setRetentionDate(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
        Optional.ofNullable(folder.getTags()).ifPresent(tags -> existingFolder.setTagList(CommonConverterHelper.extractTags(tags.getTag(), tagMap)));
        Optional.ofNullable(folder.getChildComponents()).ifPresent(components ->
                Optional.ofNullable(components.getId()).ifPresent(idList -> existingFolder.setListOfDocumentId(extractListOfDocuments(idList))));
    }

    private static List<String> extractListOfDocuments(List<Id> idList) {
        return idList.stream()
                .map(EDMS2IdentificationType::getValue)
                .collect(Collectors.toList());
    }

    private static com.bnpp.cardif.sugar.rest.web.model.Folder convert(Folder folder) {
        com.bnpp.cardif.sugar.rest.web.model.Folder apiFolder = new com.bnpp.cardif.sugar.rest.web.model.Folder();
        fillExisting(folder, apiFolder);
        return apiFolder;
    }

    @Override public com.bnpp.cardif.sugar.rest.web.model.Folder apply(Folder folder) {
        return folder != null ? convert(folder) : null;
    }
}
