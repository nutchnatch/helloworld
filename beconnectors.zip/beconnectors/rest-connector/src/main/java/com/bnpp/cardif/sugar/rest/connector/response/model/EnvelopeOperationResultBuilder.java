package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.EnvelopeOperationResult;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;

import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class EnvelopeOperationResultBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }

        @Override protected Builder self() {
            return this;
        }

        @Override public EnvelopeOperationResult build() {
            return Optional.ofNullable(this.getStatus()).isPresent() ? envelopeOperationResultInstance(this) :
                    raiseIllegalStateException();
        }

        private EnvelopeOperationResult raiseIllegalStateException() {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected static abstract class Prototype<E extends Prototype<E>> implements
            ObjectBuilder<EnvelopeOperationResult> {

        private Boolean status;
        private String envelopeId;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public String getEnvelopeId() {
            return envelopeId;
        }

        public E envelopeId(String envelopeId) {
            this.envelopeId = envelopeId;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static EnvelopeOperationResult envelopeOperationResultInstance(Prototype<?> builder) {

        EnvelopeOperationResult envelopeOperationResult = new EnvelopeOperationResult();
        return envelopeOperationResult.details(builder.getDetails())
                .envelopeId(builder.getEnvelopeId())
                .errorCause(builder.getErrorCause())
                .status(builder.getStatus());
    }
}
