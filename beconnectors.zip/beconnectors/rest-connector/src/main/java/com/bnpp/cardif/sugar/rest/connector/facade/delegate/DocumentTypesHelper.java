package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.commands.envelopetype.GenericGetDocumentTypes;
import com.bnpp.cardif.sugar.commands.envelopetype.GenericGetDocumentTypesById;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.CommonConverterHelper;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConvertDocumentTypesToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.i18n.Messages;
import com.bnpp.cardif.sugar.rest.connector.response.model.PagedDocumentTypesBuilder;
import com.bnpp.cardif.sugar.rest.connector.response.model.PagedTagsBuilder;
import com.bnpp.cardif.sugar.rest.connector.response.model.SimpleDocumentTypeBuilder;
import com.bnpp.cardif.sugar.rest.api.DocumentTypesHelperService;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.DOCUMENT_TYPES_NOT_FOUND;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.TAGS_NOT_FOUND;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

/**
 * Created by b48489 on 08-09-2017.
 */
@Component("documentTypesHelper")
@Scope("singleton")
public class DocumentTypesHelper implements DocumentTypesHelperService {

    @Autowired private DocumentClassService documentClassService;
    @Autowired private TagsHelperService tagsHelperService;

    @Override public PagedDocumentTypes getDocumentTypes(String name, @Nonnull Integer pageNumber, @Nonnull Integer pageSize,
            String X_CARDIF_CONSUMER, String scope, String symbolicName, List<String> sort, String X_CARDIF_REQUEST_ID,
            String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException,
            SugarTechnicalException {

        final GenericGetDocumentTypes<RestCallContext> command = new GenericGetDocumentTypes<>(new RestCallContext(), documentClassService,
                scope, Category.DOCUMENT, true);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        pageNumber = CommonHelper.buildPageNumber(pageNumber);
        final int endPage = pageNumber + pageSize;

        return buildPagedDocumentTypes(applyFilterName(name, command, tagMap).collect(toList()), endPage);
    }

    private Stream<DocumentType> applyFilterName(String name, GenericGetDocumentTypes<RestCallContext> command, Map<String, Tag> tagMap)
            throws SugarFunctionalException, SugarTechnicalException{

        return Optional.ofNullable(name).isPresent()
                ? getDocumentTypeStream(command, tagMap).filter(folderType -> folderType.getName().equals(name))
                : getDocumentTypeStream(command, tagMap);
    }

    private Stream<DocumentType> getDocumentTypeStream(GenericGetDocumentTypes<RestCallContext> command,
            Map<String, Tag> tagMap) throws SugarFunctionalException, SugarTechnicalException {

        return toApiDocumentType(StreamSupport.stream(command.call().spliterator(), false), tagMap);
    }

    @Override public SimpleDocumentType getDocumentTypeById(String documentTypeId, @Nonnull String scope, @Nonnull String classTypeIssuer,
            @Nonnull String templateVersion, String X_CARDIF_CONSUMER, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException {

            Optional<DocumentType> optionalDocType = getDocumentType(documentTypeId, scope, classTypeIssuer, templateVersion);

            return optionalDocType.isPresent()
                    ? new SimpleDocumentTypeBuilder.Builder(true)
                            .documentType(optionalDocType.get())
                            .build()
                    : new SimpleDocumentTypeBuilder.Builder(false)
                            .details(Messages.DOCUMENT_TYPE_NOT_FOUND.format())
                            .build();
    }

    @Override public PagedTags searchDocumentTags(String documentTypeId, @Nonnull Integer pageNumber,
            @Nonnull Integer pageSize, String X_CARDIF_CONSUMER, @Nonnull String scope, List<String> sort,
            @Nonnull String classTypeIssuer, @Nonnull String templateVersion, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException, SugarTechnicalException {

        Optional<DocumentType> optionalDocType = getDocumentType(documentTypeId, scope, classTypeIssuer, templateVersion);

        pageNumber = CommonHelper.buildPageNumber(pageNumber);
        final int endPage = pageNumber + pageSize;

        return optionalDocType.isPresent()
                ? CommonConverterHelper.getContainingTag(optionalDocType.get().getTagList(), endPage)
                : new PagedTagsBuilder.Builder(false)
                            .details(TAGS_NOT_FOUND.format())
                            .build();
    }

    private PagedDocumentTypes buildPagedDocumentTypes(@Nonnull List<DocumentType> documentTypeList, @Nonnull Integer pageSize) {

        return documentTypeList.isEmpty()
                ? new PagedDocumentTypesBuilder.Builder(false)
                        .details(DOCUMENT_TYPES_NOT_FOUND.format())
                        .build()
                : createPagedDocumentTypes(documentTypeList, pageSize);
    }

    private PagedDocumentTypes createPagedDocumentTypes(@Nonnull List<DocumentType> documentTypeList,
            @Nonnull Integer pageSize) {

        Paging paging = new Paging();
        paging.setPageSize(pageSize);
        paging.setTotalItems(documentTypeList.size());

        return new PagedDocumentTypesBuilder.Builder(true)
                .documentTypes(documentTypeList)
                .paging(paging)
                .build();
    }

    private Optional<DocumentType> getDocumentType(@Nonnull String envelopeTypeId, @Nonnull String scope, @Nonnull String classTypeIssuer,
            @Nonnull String templateVersion) throws SugarFunctionalException, SugarTechnicalException {
        final GenericGetDocumentTypesById<RestCallContext> command = CommonHelper.buildGetDocumentTypeCommand(envelopeTypeId, scope, documentClassService,
                classTypeIssuer, templateVersion);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        return toApiDocumentType(StreamSupport.stream(command.call().spliterator(), false), tagMap).findFirst();
    }

    private Stream<DocumentType> toApiDocumentType(Stream<DocumentClass> documentClassStream, Map<String, Tag> tagMap) {
        return documentClassStream.map(new ConvertDocumentTypesToRestWebApi(tagMap));
    }
}
