package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.*;

import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class SimpleTagBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }

        @Override protected Builder self() {
            return this;
        }

        @Override public SimpleTag build() {

            return Optional.ofNullable(this.getStatus()).isPresent()
                    ? simpleEnvelopeInstance(this)
                    : raiseIllegalStateException();
        }

        private SimpleTag raiseIllegalStateException() throws IllegalStateException {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<SimpleTag> {

        private Boolean status;
        private Tag tag;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public Tag getTag() {
            return tag;
        }

        public E tag(Tag tag) {
            this.tag = tag;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static SimpleTag simpleEnvelopeInstance(Prototype<?> builder) {

        SimpleTag simpleTag = new SimpleTag();
        return simpleTag
                .details(builder.getDetails())
                .status(builder.getStatus())
                .tag(builder.getTag())
                .errorCause(builder.getErrorCause());
    }
}
