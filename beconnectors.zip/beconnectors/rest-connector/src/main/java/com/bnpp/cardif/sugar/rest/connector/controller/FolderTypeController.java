package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.api.FolderTypeHelperService;
import com.bnpp.cardif.sugar.rest.web.api.FolderTypesApi;
import com.bnpp.cardif.sugar.rest.web.model.PagedFolderType;
import com.bnpp.cardif.sugar.rest.web.model.PagedTags;
import com.bnpp.cardif.sugar.rest.web.model.SimpleFolderType;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * Created by b48489 on 02-10-2017.
 */

@Controller
public class FolderTypeController implements FolderTypesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(FolderTypeController.class);
    @Autowired private FolderTypeHelperService folderTypeHelperService;

    @Override public ResponseEntity<SimpleFolderType> getFolderTypeByID(@ApiParam(value = "Folder type identification.",required=true ) @PathVariable("folderTypeId") String folderTypeId,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies the version of the template.", required = true, defaultValue = "0") @RequestParam(value = "templateVersion", required = true, defaultValue="0") String templateVersion,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(folderTypeHelperService.getFolderTypeByID(folderTypeId, X_CARDIF_CONSUMER, scope,
                    classTypeIssuer, templateVersion, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GetFolderTypeByID", e);
            return ErrorResultBuilder.buildSimpleFolderTypeErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildSimpleFolderTypeErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<PagedFolderType> getFolderTypes(
            @NotNull@ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue="1") Integer pageNumber,
            @NotNull @Min(0) @Max(100)@ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue="10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @ApiParam(value = "Provided name.") @RequestParam(value = "name", required = false) String name,
            @Size(min=1,max=3)@ApiParam(value = "Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(folderTypeHelperService.getFolderTypes(name, pageNumber, pageSize, X_CARDIF_CONSUMER,
                    scope, sort));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GetFolderTypes", e);
            return ErrorResultBuilder.buildPagedFolderTypeErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildPagedFolderTypeErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<PagedTags> searchFolderTags(@ApiParam(value = "Folder type ID.",required=true ) @PathVariable("folderTypeId") String folderTypeId,
            @NotNull@ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue="1") Integer pageNumber,
            @NotNull @Min(0) @Max(100)@ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue="10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true, defaultValue = "CARDIF") @RequestParam(value = "classTypeIssuer", required = true, defaultValue="CARDIF") String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies the version of the template.", required = true, defaultValue = "0") @RequestParam(value = "templateVersion", required = true, defaultValue="0") String templateVersion,
            @Size(min=1,max=3)@ApiParam(value = "Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(folderTypeHelperService.searchFolderTags(folderTypeId, pageNumber, pageSize, scope,
                    classTypeIssuer, templateVersion, sort));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GetFolderTypes", e);
            return ErrorResultBuilder.buildPagedTagsErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Error processing operation GetFolderTypes", e);
            return ErrorResultBuilder.buildPagedTagsErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }
}
