package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.rest.web.model.AllowableTagValue;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOAllowedValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.function.Function;

import static java.util.stream.Collectors.toList;

/**
 * Created by b48489 on 24-08-2017.
 */
public class ConvertTagClassToRestWebApi implements Function<TagClass, Tag> {

    private static void fillExisting(TagClass tagClass, Tag existingTag) {

        existingTag.setName(tagClass.getSymbolicName());
        existingTag.setType(tagClass.getTagType().value());
        existingTag.setDiplayNameItem(CommonConverterHelper.buildDisplayNameItemList(tagClass.getLabel()));
        existingTag.setChoicelist(ConvertTagClassToRestWebApi.buildAllowableTagValueList(tagClass.getAllowedValue()));
    }

    private static Tag convert(@Nonnull TagClass tagClass) {
        Tag apiTag = new Tag();
        fillExisting(tagClass, apiTag);
        return apiTag;
    }

    private static List<AllowableTagValue> buildAllowableTagValueList(List<MCOAllowedValue> allowedValueList) {

        return allowedValueList.stream()
                .map(ConvertTagClassToRestWebApi::buildAllowableTagValues)
                .collect(toList());
    }

    private static AllowableTagValue buildAllowableTagValues(MCOAllowedValue allowedValue) {
        AllowableTagValue allowableTagValues = new AllowableTagValue();
        allowableTagValues.setSymbolicName(allowedValue.getSymbolicName());
        allowableTagValues.setDisplayNameValues(CommonConverterHelper.buildDisplayNameItemList(allowedValue.getLabel()));
        return allowableTagValues;
    }

    @Override public Tag apply(TagClass tagClass) {
        return convert(tagClass);
    }
}
