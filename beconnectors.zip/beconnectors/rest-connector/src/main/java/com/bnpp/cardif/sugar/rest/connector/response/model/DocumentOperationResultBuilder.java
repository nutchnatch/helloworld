package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.DocumentOperationResult;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;

import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class DocumentOperationResultBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }


        @Override protected Builder self() {
            return this;
        }

        @Override public DocumentOperationResult build() {
            return Optional.ofNullable(this.getStatus()).isPresent() ? documentOperationResultInstance(this) :
                    raiseIllegalStateException();
        }

        private DocumentOperationResult raiseIllegalStateException() {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected static abstract class Prototype<E extends Prototype<E>> implements
            ObjectBuilder<DocumentOperationResult> {

        private Boolean status;
        private String documentId;
        private String envelopeId;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public String getDocumentId() {
            return documentId;
        }

        public E documentId(String documentId) {
            this.documentId = documentId;
            return self();
        }

        public String getEnvelopeId() {
            return envelopeId;
        }

        public E envelopeId(String envelopeId) {
            this.envelopeId = envelopeId;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static DocumentOperationResult documentOperationResultInstance(Prototype<?> builder) {

        DocumentOperationResult documentOperationResult = new DocumentOperationResult();
        return documentOperationResult.details(builder.getDetails())
                .documentId(builder.getDocumentId())
                .envelopeId(builder.getEnvelopeId())
                .errorCause(builder.getErrorCause())
                .status(builder.getStatus());
    }
}
