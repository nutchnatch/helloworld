package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sugar.rest.web.model.Envelope;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

/**
 * Created by b48489 on 24-08-2017.
 */
public class ConvertEnvelopeToRestWebApi implements Function<Document, com.bnpp.cardif.sugar.rest.web.model.Envelope> {

    private static Map tagMap = Collections.EMPTY_MAP;

    public ConvertEnvelopeToRestWebApi(Map<String, Tag> tagMap) {
        ConvertEnvelopeToRestWebApi.tagMap = tagMap;
    }

    private static void fillExisting(Document document, com.bnpp.cardif.sugar.rest.web.model.Envelope existingEnvelope) {

        existingEnvelope.setId(document.getId().getValue());
        existingEnvelope.setCreationDate(document.getData().getCreatnDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
        existingEnvelope.setConfidentiality(document.getData().getConfdntltyLvl());
        Optional.ofNullable(document.getData().getValidityCode()).ifPresent(code -> existingEnvelope.setStatus(code.toString()));
        Optional.ofNullable(document.getData().getUpdtDate()).ifPresent(date -> existingEnvelope.setUpdatingDate(date.toInstant().atZone(
                ZoneId.systemDefault()).toLocalDate()));
        Optional.ofNullable(document.getData().getName()).ifPresent(existingEnvelope::setEnvTypeSymbolicName);
        Optional.ofNullable(document.getData().getClassId()).ifPresent(classId -> existingEnvelope.setEnvTypeId(classId.getValue()));
        Optional.ofNullable(document.getChildObject()).ifPresent(child -> Optional.ofNullable(child.getDocument()).ifPresent(docList ->
                existingEnvelope.setListOfDocumentId(CommonConverterHelper.extractIdFromDocumentList(docList))));

        addDocIdsIfNotExisting(document, existingEnvelope);

        Optional.ofNullable(document.getTags()).ifPresent(tags -> existingEnvelope.setTagList(CommonConverterHelper.extractTags(tags.getTag(),
                tagMap)));
        Optional.ofNullable(document.getData().getClassId()).ifPresent(type -> existingEnvelope.setEnvTypeId(type.getValue()));
    }

    private static void addDocIdsIfNotExisting(Document document, Envelope existingEnvelope) {

        if(!CollectionUtils.isEmpty(existingEnvelope.getListOfDocumentId())) {
            return;
        }
//        if(!existingEnvelope.getListOfDocumentId().isEmpty()) {
//            return;
//        }

        Optional.ofNullable(document.getChildObject()).ifPresent(child -> Optional.ofNullable(child.getId()).ifPresent(idList ->
        existingEnvelope.setListOfDocumentId(CommonConverterHelper.extractDocumentIdList(idList))));
    }

    private static com.bnpp.cardif.sugar.rest.web.model.Envelope convert(Document document) {
        com.bnpp.cardif.sugar.rest.web.model.Envelope apiEnvelope = new com.bnpp.cardif.sugar.rest.web.model.Envelope();
        fillExisting(document, apiEnvelope);
        return apiEnvelope;
    }

    @Override public com.bnpp.cardif.sugar.rest.web.model.Envelope apply(Document document) {
        return document != null ? convert(document) : null;
    }
}
