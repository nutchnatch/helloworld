package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.rest.web.model.DocumentFileCreationResult;

/**
 * Created by b48489 on 14-09-2017.
 */

@FunctionalInterface
public interface DocumentFileProcessor {

    void process(DocumentFileCreationResult documentFile);
}
