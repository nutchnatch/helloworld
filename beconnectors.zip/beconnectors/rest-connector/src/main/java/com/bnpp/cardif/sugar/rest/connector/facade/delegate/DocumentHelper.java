package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.commands.document.DeleteDocument;
import com.bnpp.cardif.sugar.commands.document.GetDocuments;
import com.bnpp.cardif.sugar.commands.document.GetDocumentsById;
import com.bnpp.cardif.sugar.commands.document.UpdateDocument;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConvertDocumentToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.filter.model.*;
import com.bnpp.cardif.sugar.rest.connector.response.model.DocumentOperationResultBuilder;
import com.bnpp.cardif.sugar.rest.connector.response.model.PagedDocumentsBuilder;
import com.bnpp.cardif.sugar.rest.connector.response.model.SimpleDocumentBuilder;
import com.bnpp.cardif.sugar.rest.connector.util.ExceptionHandler;
import com.bnpp.cardif.sugar.rest.api.DocumentHelperService;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.*;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

/**
 * Created by b48489 on 17-08-2017.
 */
@Component("documentHelper")
@Scope("singleton")
public class DocumentHelper implements DocumentHelperService {

    @Autowired private DocumentService documentService;
    @Autowired private EnvelopeHelper envelopeHelper;
    @Autowired private TagsHelperService tagsHelperService;

    @Override public SimpleDocument getDocumentById(@Nonnull String scope, @Nonnull String docId, String issuer,
            String scheme) throws SugarFunctionalException, SugarTechnicalException {

        final GetDocumentsById<RestCallContext> command = buildGetDocumentCommand(scope, docId, issuer, scheme);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        Optional<com.bnpp.cardif.sugar.rest.web.model.Document> optionalReturn =
                toApiDocument(StreamSupport.stream(command.call().spliterator(), false), tagMap, scope).findFirst();

        return optionalReturn.isPresent()
                ? new SimpleDocumentBuilder.Builder(true)
                            .document(optionalReturn.get())
                            .build()
                : new SimpleDocumentBuilder.Builder(false)
                            .details(DOCUMENT_NOT_FOUND.format())
                            .build();
    }

    private GetDocumentsById<RestCallContext> buildGetDocumentCommand(@Nonnull String scope, @Nonnull String docId, String issuer, String scheme) {
        final List<Id> idList = CommonHelper.buildIdList(docId, issuer, scheme);

        return new GetDocumentsById<>(new RestCallContext(), documentService, idList, scope);
    }

    @Override public PagedDocuments getDocumentsByIdList(@Nonnull String scope, @Nonnull List<Id> idList)
            throws SugarFunctionalException, SugarTechnicalException {

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        return buildPagedDocuments(toApiDocument(getDocumentList(scope, idList), tagMap, scope)
                    .collect(toList()));
    }

    @Override public Stream<Document> getDocumentList(@Nonnull String scope, @Nonnull List<Id> idList)
            throws SugarFunctionalException, SugarTechnicalException {

        final GetDocumentsById<RestCallContext> command = new GetDocumentsById<>(new RestCallContext(), documentService, idList, scope);
        return StreamSupport.stream(command.call().spliterator(), false);
    }

    @Override public DocumentOperationResult deleteDocument(String documentId, String scope, String issuer,
            String scheme) throws SugarFunctionalException, SugarTechnicalException {

        List<Id> idList = Collections.singletonList(CommonHelper.createId(documentId, issuer, scheme));
        Optional<Document> optionalEnvelope = getEnvelopeContainingDocument(documentId, scope, issuer, scheme);

        return optionalEnvelope.isPresent() && optionalEnvelope.get().getData().getValidityCode() == ValdtyCode.UNDER_CONSTRUCTION
                ? buildDocumentFromOptional(deleteDocument(idList, scope), documentId, optionalEnvelope.get().getId().getValue())
                : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00105);
    }

    private Optional<Document> deleteDocument(@Nonnull List<Id> idList, @Nonnull String scope) throws SugarFunctionalException, SugarTechnicalException {

        DeleteDocument<RestCallContext> command = new DeleteDocument<>(new RestCallContext(), documentService, idList, scope);
        return command.call().stream().findFirst();
    }

    private Optional<Document> getEnvelopeContainingDocument(String documentId, String scope, String issuer, String scheme)
            throws SugarFunctionalException, SugarTechnicalException {

        final GetDocumentsById<RestCallContext> command = buildGetDocumentCommand(scope, documentId, issuer, scheme);
        Optional<Document> optionalDocument = StreamSupport.stream(command.call().spliterator(), false).findFirst();
        return optionalDocument.isPresent() ? envelopeHelper.fetchEnvelope(optionalDocument.get().getParentId().getId().getValue(),
                scope, issuer, scheme).findFirst() : Optional.empty();
    }

    @Override public PagedDocuments getDocuments(@Nonnull String scope, List<String> sort, int pageNumber, int pageSize,
            String name, String nameOperator, String docType, String confidentiality, LocalDate creationDate,
            String creationDateOperator, List<String> tags, List<String> tagsOperators)
            throws SugarFunctionalException, SugarTechnicalException {

        final Criteria criteria = new CriteriaBuilder.Builder(Item.DOCUMENT)
                .criterionList(getFilterCriterionList(scope, name, nameOperator, docType, creationDate, creationDateOperator,
                        tags, tagsOperators))
                .build();

        final OrderClause orderClause = CommonHelper.buildOrderClause(sort);

        pageNumber = CommonHelper.buildPageNumber(pageNumber);
        final int endPage = pageNumber + pageSize;

        final GetDocuments<RestCallContext> command = new GetDocuments<>(new RestCallContext(), documentService,
                criteria, orderClause, pageNumber, endPage);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        return buildPagedDocuments(toApiDocument(StreamSupport.stream(command.call().spliterator(), false), tagMap, scope)
                    .collect(toList()));
    }

    private List<Criterion> getFilterCriterionList(@Nonnull String scope, String name, String nameOperator, String docType, LocalDate creationDate,
            String creationDateOperator, List<String> tags, List<String> tagsOperators) {

        List<Criterion> criterionList = new ArrayList<>();
        CommonHelper.buildUnderConstructionCriterion(criterionList);
        criterionList.add(ScopeFilter.buildEqualsScopeCriterion(scope));
        CommonHelper.buildNameCriterion(name, nameOperator, criterionList);
        CommonHelper.buildClassTypeCriterion(docType, criterionList);
        CommonHelper.buildCreationDateCriterion(creationDate, creationDateOperator, criterionList);
        Map<String, String> tagMap = CommonHelper.createTagMap(tags, tagsOperators);
        CommonHelper.buildTagsCriterion(tags, criterionList, tagMap);

        return criterionList;
    }

    public boolean validateTags(List<String> tagEntries) {
        return CommonHelper.validateTags(tagEntries);
    }

    @Override public DocumentOperationResult updateDocument(@Nonnull String docId,
            @Nonnull ComposedDocumentData documentData, String X_CARDIF_CONSUMER, @Nonnull String scope,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID, String issuer, String scheme)
            throws SugarFunctionalException, SugarTechnicalException {

            GetDocumentsById<RestCallContext> command = buildGetDocumentCommand(scope, docId, issuer, scheme);
            Optional<Document> optionalDocument = StreamSupport.stream(command.call().spliterator(), false).findFirst();

            return optionalDocument.isPresent()
                    ? buildDocumentResult(updateDocument(documentData, optionalDocument.get(), scope))
                    : ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00102);
    }

    private DocumentOperationResult buildDocumentFromOptional(Optional<Document> documentOptional, String documentId,
            String envelopeId) {

        return documentOptional.isPresent()
                ? new DocumentOperationResultBuilder.Builder(true)
                        .documentId(documentId)
                        .envelopeId(envelopeId)
                        .build()
                : new DocumentOperationResultBuilder.Builder(false)
                        .details(DOCUMENT_NOT_FOUND.format())
                        .build();
    }

    private DocumentOperationResult buildDocumentResult(@Nonnull Document document) {

        return new DocumentOperationResultBuilder.Builder(true)
                        .documentId(document.getId().getValue())
                        .envelopeId(document.getParentId().getId().getValue())
                        .build();
    }

    private Document updateDocument(@Nonnull ComposedDocumentData documentData, @Nonnull Document document, @Nonnull String scope) throws
            SugarFunctionalException, SugarTechnicalException {

        prepareDocumentToUpdate(documentData, document, scope);
        List<Document> documentList = new ArrayList<>();
        documentList.add(document);

        final UpdateDocument<RestCallContext> command = new UpdateDocument<>(new RestCallContext(), documentService, documentList);
        return command.call();
    }

    private void prepareDocumentToUpdate(@Nonnull ComposedDocumentData documentData, @Nonnull Document document, @Nonnull String scope)
            throws SugarFunctionalException, SugarTechnicalException {

        if(!CommonHelper.validateTags(documentData.getTagList())) {
            ExceptionHandler.raiseTechnicalException(TechnicalErrorCode.T00804);
        }

        if(!CommonHelper.containsLanguage(documentData.getDocumentLanguage())) {
            ExceptionHandler.raiseFunctionalException(FunctionalErrorCode.F00805);
        }

        List<Tag> tagList = CommonHelper.buildTagList(tagsHelperService, documentData.getTagList(), scope);

        CommonHelper.updateDocumentData(document, documentData.getDocumentLanguage(), documentData.getDocumentTypeVersion(),
                documentData.getDocumentTypeIssuer(), documentData.getDocumentTypeId(), documentData.getName(), documentData.getRetentionStartDate(), tagList);
    }

    private PagedDocuments buildPagedDocuments(@Nonnull List<com.bnpp.cardif.sugar.rest.web.model.Document> documentList) {

        return documentList.isEmpty()
                ? new PagedDocumentsBuilder.Builder(false)
                .details(DOCUMENTS_NOT_FOUND.format())
                .build()
                : createPagedDocuments(documentList);
    }

    private PagedDocuments createPagedDocuments(
            @Nonnull List<com.bnpp.cardif.sugar.rest.web.model.Document> documentList) {

        Paging paging = new Paging();
        paging.setPageSize(documentList.size());

        return new PagedDocumentsBuilder.Builder(true)
                .documents(documentList)
                .paging(paging)
                .build();
    }

    private Stream<com.bnpp.cardif.sugar.rest.web.model.Document> toApiDocument(Stream<Document> documentStream,
            Map<String, Tag> tagMap, String scope) {

        return documentStream
                .map(new ConvertDocumentToRestWebApi(tagMap, scope));
    }
}
