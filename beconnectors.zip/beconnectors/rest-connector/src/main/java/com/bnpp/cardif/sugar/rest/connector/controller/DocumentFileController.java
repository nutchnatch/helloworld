package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.facade.delegate.DocumentFileHelper;
import com.bnpp.cardif.sugar.rest.web.api.DocumentFilesApi;
import com.bnpp.cardif.sugar.rest.web.model.DocumentFileCreationResult;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;
import java.io.IOException;

@RestController
public class DocumentFileController implements DocumentFilesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentFileController.class);
    @Autowired private DocumentFileHelper documentFileHelper;

    @Override public ResponseEntity<DocumentFileCreationResult> addDocumentFile(
            @NotNull @ApiParam(value = "Scope of Dugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue = "Syldavia") String scope,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String X_CARDIF_CONSUMER,
            @ApiParam("file detail") @RequestPart("file") MultipartFile file,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(documentFileHelper.addDocumentFile(file, scope));
        }
        catch (IOException e) {
            LOGGER.error("Error posting a document file", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Error posting a document file", e);
            return ErrorResultBuilder.buildDocumentFileCreationErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error posting a document file", e);
            return ErrorResultBuilder.buildDocumentFileCreationErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }
}
