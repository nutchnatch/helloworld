package com.bnpp.cardif.sugar.rest.api;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.PagedFolderType;
import com.bnpp.cardif.sugar.rest.web.model.PagedTags;
import com.bnpp.cardif.sugar.rest.web.model.SimpleFolderType;
import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 02-10-2017.
 *
 * Describes operations to be performed on folder type.
 */
public interface FolderTypeHelperService {

    /**
     * Get folder type through its ID.
     * @param folderTypeId - folder type ID.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param issuer - class type issuer.
     * @param version - folder type's template version.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return SimpleFolderType
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    SimpleFolderType getFolderTypeByID(@Nonnull String folderTypeId, String X_CARDIF_CONSUMER, @Nonnull String scope,
            @Nonnull String issuer, @Nonnull String version,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException,
            SugarTechnicalException;

    /**
     * Get folder types.
     * @param name - folder types' name.
     * @param pageNumber - page number.
     * @param pageSize - page size.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param sort - Sugar working scope.
     * @return PagedFolderType
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    PagedFolderType getFolderTypes(String name, @Nonnull Integer pageNumber, @Nonnull Integer pageSize, String X_CARDIF_CONSUMER, @Nonnull String scope, List<String> sort) throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Search existing folder type tags.
     * @param folderTypeId - folder type ID.
     * @param pageNumber - page number.
     * @param pageSize - page size.
     * @param scope - Sugar working scope.
     * @param issuer - class type issuer.
     * @param version - folder type's template version.
     * @param sort - Sugar working scope.
     * @return PagedTags
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    PagedTags searchFolderTags(@Nonnull String folderTypeId, @Nonnull Integer pageNumber, Integer pageSize, @Nonnull String scope,
            @Nonnull String issuer, @Nonnull String version, List<String> sort) throws SugarFunctionalException, SugarTechnicalException;
}
