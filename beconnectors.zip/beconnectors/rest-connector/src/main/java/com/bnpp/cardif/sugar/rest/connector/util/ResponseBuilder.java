package com.bnpp.cardif.sugar.rest.connector.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.DOCUMENT_NOT_FOUND;

/**
 * Created by b48489 on 19-10-2017.
 */
public final class ResponseBuilder {

    public static <T> ResponseEntity<T> wrapOkResponse(T response) {

        return ResponseEntity.ok(response);
    }

    public static <T> ResponseEntity<T> wrapOkNotFoundResponse(T response) {

        return ResponseEntity.status(HttpStatus.NO_CONTENT).header(DOCUMENT_NOT_FOUND.format()).build();
    }
}
