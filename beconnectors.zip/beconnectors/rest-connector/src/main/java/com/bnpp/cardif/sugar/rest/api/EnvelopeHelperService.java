package com.bnpp.cardif.sugar.rest.api;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Nonnull;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;

/**
 * Created by b48489 on 17-08-2017.
 *
 * Describes operations to be performed on envelopes.
 */
public interface EnvelopeHelperService {

    /**
     * Get envelopes through search parameters.
     * @param scope - Sugar working scope.
     * @param sort - sort order to be set on returned objects.
     * @param pageNumber - page number.
     * @param pageSize - page size.
     * @param creationDate - creation date.
     * @param envelopeTypeID - envelope type ID.
     * @param creationDateOperator - operator search parameter to be applied on creation date.
     * @param tagEntries - tag entries search parameter.
     * @param tagsOperators - - operator search parameter to be applied on tags.
     * @return PagedEnvelopes
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    PagedEnvelopes getEnvelopes(String scope, List<String> sort, int pageNumber, int pageSize, LocalDate creationDate,
            String envelopeTypeID, String creationDateOperator, List<String> tagEntries, List<String> tagsOperators) throws
            SugarFunctionalException, SugarTechnicalException;

    /**
     * Get documents envelope ID.
     * @param envelopeId - envelope unique ID.
     * @param scope - Sugar working scope.
     * @param sort - sort order to be set on returned objects.
     * @param pageNumber - page number.
     * @param pageSize - page size.
     * @param issuer - class type issuer.
     * @param scheme - database scheme.
     * @return PagedDocuments
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    PagedDocuments getDocumentsByEnvelopeId(@Nonnull String envelopeId, String scope, List<String> sort, int pageNumber,
            int pageSize, String issuer, String scheme) throws
            SugarFunctionalException, SugarTechnicalException;

    /**
     * Get envelope through its ID.
     * @param envelopeId - envelope's ID search parameter.
     * @param scope - Sugar working scope.
     * @param issuer - class type issuer.
     * @param scheme - database scheme.
     * @return SimpleEnvelope
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    SimpleEnvelope getEnvelopeById(@Nonnull String envelopeId, @Nonnull String scope, String issuer, String scheme)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Updates a specified envelope.
     * @param envelopeId - envelope unique ID.
     * @param composedEnvelopeData - associated document data.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar wroking scope.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @param issuer - class type issuer.
     * @param scheme - database scheme.
     * @return EnvelopeOperationResult
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    EnvelopeOperationResult updateEnvelope(@Nonnull String envelopeId, @Nonnull ComposedEnvelopeData composedEnvelopeData,
            String X_CARDIF_CONSUMER, @Nonnull String scope, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID,
            String issuer, String scheme) throws
            SugarFunctionalException, SugarTechnicalException;

    /**
     * Add File to an existing envelope.
     * @param envelopeId - envelope unique ID.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param classTypeIssuer - class type issuer.
     * @param scheme - database scheme.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @param file - file to be uploaded.
     * @return DocumentFileCreationResult
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     * @throws IOException - exception may occur when creating file.
     */
    DocumentFileCreationResult addFileToEnvelope(@Nonnull String envelopeId, String X_CARDIF_CONSUMER,
            @Nonnull String scope, @Nonnull String classTypeIssuer, @Nonnull String scheme, String X_CARDIF_REQUEST_ID,
            String X_CARDIF_EXT_REQ_ID, @Nonnull MultipartFile file) throws SugarFunctionalException, SugarTechnicalException, IOException;

    /**
     * Delete envelope through its ID.
     * @param envelopeId - envelope unique ID.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param issuer - class type issuer.
     * @param scheme - database scheme.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return EnvelopeOperationResult
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    EnvelopeOperationResult deleteEnvelope(@Nonnull String envelopeId, String X_CARDIF_CONSUMER, @Nonnull String scope,
            @Nonnull String issuer, @Nonnull String scheme, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     *Get paginated envelopes.
     * @param scope - Sugar working scope.
     * @param sort - sort order to be set on returned objects.
     * @param pageNumber - page number.
     * @param pageSize - page size.
     * @param creationDate - creation date.
     * @param envelopeTypeID - envelope type ID.
     * @param creationDateOperator - operator search parameter to be applied on creation date.
     * @param tagEntries - tags search parameter.
     * @param tagsOperators - operator search parameter to be applied on tags.
     * @return Stream<Document>
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    Stream<Document> getNativePaginatedSortedEnvelopes(String scope, List<String> sort, int pageNumber, int pageSize,
            LocalDate creationDate, String envelopeTypeID, String creationDateOperator, List<String> tagEntries, List<String> tagsOperators) throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Fetch envelope through its unique ID.
     * @param envelopeId - envelope unique ID.
     * @param scope - Sugar working scope.
     * @param issuer - class type issuer.
     * @param scheme - database scheme.
     * @return Stream<Document>
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    Stream<Document> fetchEnvelope(@Nonnull String envelopeId, @Nonnull String scope, String issuer,
            String scheme) throws SugarFunctionalException, SugarTechnicalException;
}