package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;

import java.util.Collections;

/**
 * Created by b48489 on 27-10-2017.
 */
public class ClassTypeFilter {

    private static final String CLASS_ID_CRITERION_NAME = "ClassId";

    public static Criterion buildEqualsClassTypeCriterion(String classId) {

        return CriteriaStringTypeHelper.buildEqualsToCriterion(
                Levels.DATA, CLASS_ID_CRITERION_NAME,
                Collections.singletonList(classId));
    }
}