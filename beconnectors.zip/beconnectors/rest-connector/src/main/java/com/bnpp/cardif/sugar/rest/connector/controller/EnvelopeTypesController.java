package com.bnpp.cardif.sugar.rest.connector.controller;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.facade.delegate.EnvelopeTypesHelper;
import com.bnpp.cardif.sugar.rest.web.api.EnvelopeTypesApi;
import com.bnpp.cardif.sugar.rest.web.model.PagedEnvelopeTypes;
import com.bnpp.cardif.sugar.rest.web.model.PagedTags;
import com.bnpp.cardif.sugar.rest.web.model.SimpleEnvelopeType;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * Created by b48489 on 06-09-2017.
 */
@RestController
public class EnvelopeTypesController implements EnvelopeTypesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnvelopeTypesController.class);

    @Autowired private EnvelopeTypesHelper envelopeTypesHelper;

    @Override public ResponseEntity<SimpleEnvelopeType> getEnvelopeTypeByID(
            @ApiParam(value = "Envelope type identification.",required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @ApiParam(value = "Application that is performing the request.",required = true,defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER",required = true) String X_CARDIF_CONSUMER,
            @NotNull @ApiParam(value = "Scope of Dugar deployment.",required = true,defaultValue = "Syldavia") @RequestParam(value = "scope",required = true,defaultValue = "Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true) @RequestParam(value = "classTypeIssuer", required = true) String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies the version of the template.", required = true) @RequestParam(value = "templateVersion", required = true) String templateVersion,
            @ApiParam(value = "Request Identifier.",defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID",required = false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier.",defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID",required = false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(envelopeTypesHelper.getEnvelopeTypeByID(envelopeTypeId,scope, classTypeIssuer, templateVersion, X_CARDIF_CONSUMER,
                    X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation getDocumentTypeByID", e);
            return ErrorResultBuilder.buildSimpleEnvelopeTypeErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildSimpleEnvelopeTypeErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<PagedEnvelopeTypes> getEnvelopeTypes(
            @NotNull@ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue="1") Integer pageNumber,
            @NotNull @Min(0) @Max(100)@ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue="10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request." ,required=true, defaultValue="SUGAR") @RequestHeader(value="X-CARDIF-CONSUMER", required=true) String X_CARDIF_CONSUMER,
            @NotNull@ApiParam(value = "Scope of Sugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue="Syldavia") String scope,
            @ApiParam(value = "Provided name.") @RequestParam(value = "name", required = false) String name,
            @Size(min=1,max=3)@ApiParam(value = "Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier." , defaultValue="SUGAR-123-456") @RequestHeader(value="X-CARDIF-REQUEST-ID", required=false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier." , defaultValue="SUGAR-000-123-456") @RequestHeader(value="X-CARDIF-EXT-REQ-ID", required=false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(envelopeTypesHelper.getEnvelopeTypes(scope, pageNumber, pageSize, X_CARDIF_CONSUMER, name, sort,
                    X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation GenericGetDocumentTypes", e);
            return ErrorResultBuilder.buildPagedEnvelopeTypesErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildPagedEnvelopeTypesErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }

    @Override public ResponseEntity<PagedTags> searchEnvelopeTags(
            @ApiParam(value = "Envelope type ID.", required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @NotNull @ApiParam(value = "Page number", required = true, defaultValue = "1") @RequestParam(value = "pageNumber", required = true, defaultValue = "1") Integer pageNumber,
            @NotNull @Min(0L) @Max(100L) @ApiParam(value = "Number of items returned.", required = true, defaultValue = "10") @RequestParam(value = "pageSize", required = true, defaultValue = "10") Integer pageSize,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String X_CARDIF_CONSUMER,
            @NotNull @ApiParam(value = "Scope of Dugar deployment.", required = true, defaultValue = "Syldavia") @RequestParam(value = "scope", required = true, defaultValue = "Syldavia") String scope,
            @NotNull@ApiParam(value = "Identifies the class type issuer, usually who do th request.", required = true) @RequestParam(value = "classTypeIssuer", required = true) String classTypeIssuer,
            @NotNull@ApiParam(value = "Identifies the version of the template.", required = true) @RequestParam(value = "templateVersion", required = true) String templateVersion,
            @Size(min = 1, max = 3) @ApiParam("Sort query definition.") @RequestParam(value = "sort", required = false) List<String> sort,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String X_CARDIF_REQUEST_ID,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String X_CARDIF_EXT_REQ_ID) {

        try {
            return ResponseEntity.ok(envelopeTypesHelper.searchEnvelopeTags(envelopeTypeId, pageNumber, pageSize, X_CARDIF_CONSUMER,
                    scope, sort, classTypeIssuer, templateVersion, X_CARDIF_REQUEST_ID, X_CARDIF_EXT_REQ_ID));
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Error processing operation searchEnvelopeTags", e);
            return ErrorResultBuilder.buildPagedTagsErrorResult(e, ErrorResultBuilder.FUNCTIONAL_TYPE);
        }
        catch (SugarTechnicalException e) {
            return ErrorResultBuilder.buildPagedTagsErrorResult(e, ErrorResultBuilder.TECHNICAL_TYPE);
        }
    }
}