package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.Document;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.web.model.PagedDocuments;
import com.bnpp.cardif.sugar.rest.web.model.Paging;
import java.util.List;
import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class PagedDocumentsBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }

        @Override protected Builder self() {
            return this;
        }

        @Override public PagedDocuments build() {

            return Optional.ofNullable(this.getStatus()).isPresent() ? pagedDocumentsInstance(this) : raiseIllegalStateException();
        }

        private PagedDocuments raiseIllegalStateException() {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<PagedDocuments> {

        private Boolean status;
        private List<Document> documents;
        private Paging paging;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public List<Document> getDocuments() {
            return documents;
        }

        public E documents(List<Document> documents) {
            this.documents = documents;
            return self();
        }

        public Paging getPaging() {
            return paging;
        }

        public E paging(Paging paging) {
            this.paging = paging;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static PagedDocuments pagedDocumentsInstance(Prototype<?> builder) {

        PagedDocuments pagedDocuments = new PagedDocuments();
        pagedDocuments.setDetails(builder.getDetails());
        pagedDocuments.setStatus(builder.getStatus());
        pagedDocuments.setErrorCause(builder.getErrorCause());
        pagedDocuments.setDocuments(builder.getDocuments());
        pagedDocuments.setPaging(builder.getPaging());
        return pagedDocuments;
    }
}
