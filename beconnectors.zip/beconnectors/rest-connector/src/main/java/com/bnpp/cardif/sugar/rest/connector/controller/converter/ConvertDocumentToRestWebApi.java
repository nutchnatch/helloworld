package com.bnpp.cardif.sugar.rest.connector.controller.converter;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.rest.web.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;

import java.time.ZoneId;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

/**
 * Created by b48489 on 24-08-2017.
 */
public class ConvertDocumentToRestWebApi implements Function<Document, com.bnpp.cardif.sugar.rest.web.model.Document> {

    private static Map tagMap = Collections.EMPTY_MAP;
    private static String scope;
    private static final String ARRENDAR_URL = "/ARenderHMI/ARender.jsp?scope=";
    private static final String TOKEN = "&token=";
    private static final String URI = "&uri=";

    public ConvertDocumentToRestWebApi(Map<String, Tag> tagMap, String scope) {
        ConvertDocumentToRestWebApi.tagMap = tagMap;
        ConvertDocumentToRestWebApi.scope = scope;
    }

    private static void fillExisting(Document document, com.bnpp.cardif.sugar.rest.web.model.Document existingDocument) {

        Optional.ofNullable(document.getId().getValue()).ifPresent(existingDocument::setId);
        Optional.ofNullable(document.getData().getCreatnDate()).ifPresent(date -> existingDocument.setCreationDate(date.toInstant().atZone(
                ZoneId.systemDefault()).toLocalDate()));
        Optional.ofNullable(document.getData().getConfdntltyLvl()).ifPresent(existingDocument::setConfidentiality);
        Optional.ofNullable(document.getFileData().getURI()).ifPresent(uriList -> existingDocument.setDocFileID(uriList.get(0)));
        Optional.ofNullable(document.getData().getClassId()).ifPresent(classId -> existingDocument.setDocTypeId(classId.getValue()));
        Optional.ofNullable(document.getTags()).ifPresent(tags -> existingDocument.setTagList(CommonConverterHelper.extractTags(tags.getTag(),
                tagMap)));
        Optional.ofNullable(document.getData().getRetentionEndDate()).ifPresent(date ->
                existingDocument.setRetentionEndDate(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
        Optional.ofNullable(document.getData().getRetentionStartDate()).ifPresent(date ->
                existingDocument.setRetentionStartDate(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()));
        Optional.ofNullable(document.getData().getName()).ifPresent(existingDocument::setName);
        existingDocument.setEnvelopeID(document.getParentId().getId().getValue());
        Optional.ofNullable(document.getData().getLangCode()).ifPresent(existingDocument::setLanguage);
        Optional.ofNullable(document.getData().getValidityCode()).ifPresent(validity -> existingDocument.setStatus(validity.toString()));

        TokenType tokenType = TokenCreator.getTokenType();
        Optional.ofNullable(document.getFileData().getURI()).ifPresent(uriList -> existingDocument.setDocFileUrl(
                ARRENDAR_URL + scope + TOKEN + tokenType.getToken() + URI + uriList.get(0)));
    }

    private static com.bnpp.cardif.sugar.rest.web.model.Document convert(Document document) {
        com.bnpp.cardif.sugar.rest.web.model.Document apiDocument = new com.bnpp.cardif.sugar.rest.web.model.Document();
        fillExisting(document, apiDocument);
        return apiDocument;
    }

    @Override public com.bnpp.cardif.sugar.rest.web.model.Document apply(Document document) {
        return document != null ? convert(document) : null;
    }
}
