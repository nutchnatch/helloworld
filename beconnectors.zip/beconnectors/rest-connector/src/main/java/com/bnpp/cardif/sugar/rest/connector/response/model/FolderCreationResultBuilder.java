package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.web.model.FolderCreationResult;

import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class FolderCreationResultBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }


        @Override protected Builder self() {
            return this;
        }

        @Override public FolderCreationResult build() {
            return Optional.ofNullable(this.getStatus()).isPresent() ? documentOperationResultInstance(this) :
                    raiseIllegalStateException();
        }

        private FolderCreationResult raiseIllegalStateException() {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected static abstract class Prototype<E extends Prototype<E>> implements ObjectBuilder<FolderCreationResult> {

        private Boolean status;
        private String folderId;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public String getFolderId() {
            return folderId;
        }

        public E folderId(String folderId) {
            this.folderId = folderId;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static FolderCreationResult documentOperationResultInstance(Prototype<?> builder) {

        FolderCreationResult folderCreationResult = new FolderCreationResult();
        return folderCreationResult.details(builder.getDetails())
                .folderId(builder.getFolderId())
                .errorCause(builder.getErrorCause())
                .status(builder.getStatus());
    }
}
