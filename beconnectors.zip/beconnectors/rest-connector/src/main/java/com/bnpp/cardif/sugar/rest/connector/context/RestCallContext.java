package com.bnpp.cardif.sugar.rest.connector.context;

import com.bnpp.cardif.sugar.core.context.CallContext;

/**
 * Created by b48489 on 18-08-2017.
 */
public class RestCallContext implements CallContext {

}
