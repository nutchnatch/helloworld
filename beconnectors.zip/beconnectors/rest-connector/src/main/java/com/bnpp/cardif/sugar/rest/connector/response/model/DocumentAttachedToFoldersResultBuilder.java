package com.bnpp.cardif.sugar.rest.connector.response.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.DocumentAttachedToFoldersResult;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;
import java.util.List;
import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class DocumentAttachedToFoldersResultBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Boolean status) {
            super(status);
        }


        @Override protected Builder self() {
            return this;
        }

        @Override public DocumentAttachedToFoldersResult build() {
            return Optional.ofNullable(this.getStatus()).isPresent() ? documentOperationResultInstance(this) :
                    raiseIllegalStateException();
        }

        private DocumentAttachedToFoldersResult raiseIllegalStateException() {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected static abstract class Prototype<E extends Prototype<E>> implements
            ObjectBuilder<DocumentAttachedToFoldersResult> {

        private Boolean status;
        private String folderId;
        private List<String> documentIdArray;
        private String details;
        private ErrorCause errorCause;

        Prototype(Boolean status) {
            this.status = status;
        }

        public Boolean getStatus() {
            return status;
        }

        public String getFolderId() {
            return folderId;
        }

        public E folderId(String folderId) {
            this.folderId = folderId;
            return self();
        }

        public List<String> getDocumentIdArray() {
            return documentIdArray;
        }

        public E documentIdArray(List<String> documentIdArray) {
            this.documentIdArray = documentIdArray;
            return self();
        }

        public String getDetails() {
            return details;
        }

        public E details(String details) {
            this.details = details;
            return self();
        }

        public ErrorCause getErrorCause() {
            return errorCause;
        }

        public E errorCause(ErrorCause errorCause) {
            this.errorCause = errorCause;
            return self();
        }

        protected abstract E self();
    }

    private static DocumentAttachedToFoldersResult documentOperationResultInstance(Prototype<?> builder) {

        DocumentAttachedToFoldersResult documentAttachedToFoldersResult = new DocumentAttachedToFoldersResult();
        return documentAttachedToFoldersResult.details(builder.getDetails())
                .folderId(builder.getFolderId())
                .documentIdArray(builder.getDocumentIdArray())
                .errorCause(builder.getErrorCause())
                .status(builder.getStatus());
    }
}
