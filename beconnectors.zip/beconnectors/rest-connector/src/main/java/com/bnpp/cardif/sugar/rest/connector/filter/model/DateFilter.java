package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.google.common.collect.ImmutableMap;

import java.util.Collections;
import java.util.Map;

/**
 * Created by b48489 on 27-10-2017.
 */
public class DateFilter {

    private static final String CREATEN_DATE = "CreatnDate";

    private static Criterion buildDisplayCreatenDateCriterion(String name) {

        return CriteriaDateTypeHelper.buildDisplaysCriterion(
                Levels.DATA,
                CREATEN_DATE,
                Collections.singletonList(name));
    }

    private static Criterion buildGreaterThanCreatenDateCriterion(String name) {

        return CriteriaDateTypeHelper.buildGreatherThanCriterion(
                Levels.DATA,
                CREATEN_DATE,
                Collections.singletonList(name));
    }

    private static Criterion buildLessThanCreatenDateCriterion(String name) {

        return CriteriaDateTypeHelper.buildLessThanCriterion(
                Levels.DATA,
                CREATEN_DATE,
                Collections.singletonList(name));
    }

    public static Map<Enum, Criterion> buildDateOperationConfiguration(String name) {

        return new ImmutableMap.Builder<Enum, Criterion>()
                .put(AllowedOperators.GREATER_THAN, buildGreaterThanCreatenDateCriterion(name))
                .put(AllowedOperators.LESS_THAN, buildLessThanCreatenDateCriterion(name))
                .put(AllowedOperators.DISPLAY, buildDisplayCreatenDateCriterion(name))
                .build();
    }
}