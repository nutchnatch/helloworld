package com.bnpp.cardif.sugar.rest.connector.facade.delegate;
import com.bnpp.cardif.sugar.commands.envelopetype.GenericGetDocumentTypes;
import com.bnpp.cardif.sugar.commands.envelopetype.GenericGetDocumentTypesById;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.CommonConverterHelper;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConvertEnvelopeTypesToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.response.model.PagedEnvelopeTypesBuilder;
import com.bnpp.cardif.sugar.rest.connector.response.model.PagedTagsBuilder;
import com.bnpp.cardif.sugar.rest.connector.response.model.SimpleEnvelopeTypeBuilder;
import com.bnpp.cardif.sugar.rest.api.EnvelopeTypesHelperService;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.ENVELOPE_NOT_FOUND;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.ENVELOPE_TYPES_NOT_FOUND;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.TAGS_NOT_FOUND;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

/**
 * Created by b48489 on 06-09-2017.
 */
@Component("envelopeTypesHelper")
@Scope("singleton")
public class EnvelopeTypesHelper implements EnvelopeTypesHelperService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnvelopeTypesHelper.class);
    @Autowired private DocumentClassService documentClassService;
    @Autowired private TagsHelperService tagsHelperService;

    @Override public PagedEnvelopeTypes getEnvelopeTypes(@Nonnull String scope, @Nonnull Integer pageNumber, @Nonnull Integer pageSize,
            String X_CARDIF_CONSUMER, String name, List<String> sort, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException, SugarTechnicalException {

        final GenericGetDocumentTypes<RestCallContext> command = new GenericGetDocumentTypes<>(new RestCallContext(), documentClassService,
                scope, Category.ENVELOPE, true);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        pageNumber = CommonHelper.buildPageNumber(pageNumber);
        final int endPage = pageNumber + pageSize;

        return buildPagedEnvelopeTypes(applyFilterName(name, command, tagMap).collect(toList()),
                    pageNumber, endPage);
    }

    private Stream<EnvelopeType> getEnvelopeTypeStream(GenericGetDocumentTypes<RestCallContext> command,
            Map<String, Tag> tagMap) throws SugarFunctionalException, SugarTechnicalException {

        return toApiEnvelopeType(StreamSupport.stream(command.call().spliterator(), false), tagMap);
    }

    private Stream<EnvelopeType> applyFilterName(String name, GenericGetDocumentTypes<RestCallContext> command, Map<String, Tag> tagMap)
            throws SugarFunctionalException, SugarTechnicalException{

        return Optional.ofNullable(name).isPresent()
                ? getEnvelopeTypeStream(command, tagMap).filter(folderType -> folderType.getName().equals(name))
                : getEnvelopeTypeStream(command, tagMap);
    }

    @Override public SimpleEnvelopeType getEnvelopeTypeByID(@Nonnull String envelopeTypeId, @Nonnull String scope,
            @Nonnull String classTypeIssuer, @Nonnull String templateVersion, String X_CARDIF_CONSUMER,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException,
            SugarTechnicalException {

            Optional<EnvelopeType> optionalEnvType = getEnvelopeType(envelopeTypeId, scope, classTypeIssuer, templateVersion);
            return optionalEnvType.isPresent()
                    ? new SimpleEnvelopeTypeBuilder.Builder(true)
                            .envelopeType(optionalEnvType.get())
                            .build()
                    : new SimpleEnvelopeTypeBuilder.Builder(false)
                            .details(ENVELOPE_NOT_FOUND.format())
                            .build();
    }

    @Override public PagedTags searchEnvelopeTags(@Nonnull String envelopeTypeId, @Nonnull Integer pageNumber, @Nonnull Integer pageSize, String X_CARDIF_CONSUMER,
            @Nonnull String scope, List<String> sort, @Nonnull String classTypeIssuer, @Nonnull String templateVersion,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException, SugarTechnicalException {

        Optional<EnvelopeType> optionalEnvType = getEnvelopeType(envelopeTypeId, scope, classTypeIssuer, templateVersion);

        pageNumber = CommonHelper.buildPageNumber(pageNumber);
        final int endPage = pageNumber + pageSize;

        return optionalEnvType.isPresent()
                ? CommonConverterHelper.getContainingTag(optionalEnvType.get().getTagList(), endPage)
                : new PagedTagsBuilder.Builder(false)
                        .details(TAGS_NOT_FOUND.format())
                        .build();
    }

    private PagedEnvelopeTypes buildPagedEnvelopeTypes(@Nonnull List<EnvelopeType> envelopeTypeList, @Nonnull Integer pageNumer,
            @Nonnull Integer pageSize) {

        return envelopeTypeList.isEmpty()
                ? new PagedEnvelopeTypesBuilder.Builder(false)
                        .details(ENVELOPE_TYPES_NOT_FOUND.format())
                        .build()
                : createPagedEnvelopeTypes(envelopeTypeList, pageSize);
    }

    private PagedEnvelopeTypes createPagedEnvelopeTypes(@Nonnull List<EnvelopeType> envelopeTypeList,
            @Nonnull Integer pageSize) {

        Paging paging = new Paging();
        paging.setPageSize(pageSize);
        paging.setTotalItems(envelopeTypeList.size());

        return new PagedEnvelopeTypesBuilder.Builder(true)
                .envelopeTypes(envelopeTypeList)
                .paging(paging)
                .build();
    }

    private Optional<EnvelopeType> getEnvelopeType(@Nonnull String envelopeTypeId, @Nonnull String scope, @Nonnull String classTypeIssuer,
            @Nonnull String templateVersion) throws SugarFunctionalException, SugarTechnicalException {

        final GenericGetDocumentTypesById<RestCallContext> command = CommonHelper.buildGetDocumentTypeCommand(envelopeTypeId, scope, documentClassService,
                classTypeIssuer, templateVersion);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        return toApiEnvelopeType(StreamSupport.stream(command.call().spliterator(), false), tagMap).findFirst();
    }

    private Stream<EnvelopeType> toApiEnvelopeType(Stream<DocumentClass> documentClassStream, Map<String, Tag> tagMap) {
        return documentClassStream.map(new ConvertEnvelopeTypesToRestWebApi(tagMap));
    }
}
