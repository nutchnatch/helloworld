package com.bnpp.cardif.sugar.rest.api;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.web.model.*;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Nonnull;
import java.time.LocalDate;
import java.util.List;

/**
 * Created by b48489 on 29-09-2017.
 */
public interface FolderHelperService {

    /**
     * Describes operations to be performed on folders.
     * @param pageNumber - page number.
     * @param pageSize - page size.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param name - folder's name.
     * @param nameOperator - operator search parameter to be applied on folder's name.
     * @param creationDate - creation date.
     * @param creationDateOperator - operator search parameter to be applied on creation date.
     * @param folderTypeID - folder type ID.
     * @param tagEntries - tag search parameter.
     * @param tagsOperators - operator search parameter to be applied on tags.
     * @param sort - sort order to be set on returned objects.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return PagedFolders
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    PagedFolders getFolders(@Nonnull Integer pageNumber, Integer pageSize, String X_CARDIF_CONSUMER,
            @Nonnull String scope, String name, String nameOperator, LocalDate creationDate,
            String creationDateOperator, String folderTypeID, List<String> tagEntries, List<String> tagsOperators, List<String> sort,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Get folder through its unique ID.
     * @param folderId - folder ID.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param issuer - class type issuer.
     * @param scheme - database schema.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return SimpleFolder
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    SimpleFolder getFolderById(@Nonnull String folderId, String X_CARDIF_CONSUMER, @Nonnull String scope, String issuer,
            String scheme, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Get documents from specific folder through its ID.
     * @param folderId - folder unique ID.
     * @param pageNumber - page number
     * @param pageSize - page size.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param issuer - class type issuer.
     * @param scheme - database schema.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return PagedDocuments
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    PagedDocuments getDocumentsFromFolderId(@Nonnull String folderId, @Nonnull Integer pageNumber, @Nonnull Integer pageSize,
            String X_CARDIF_CONSUMER, String scope, @Nonnull String issuer, @Nonnull String scheme, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Attach one or mre documents to an existing. folder.
     * @param folderId - folder unique ID.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param classTypeIssuer - class type issuer.
     * @param scheme - class type issuer.
     * @param documentIds - document ID list.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return DocumentAttachedToFoldersResult
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    DocumentAttachedToFoldersResult attachDocumentToFolder(@Nonnull String folderId, String X_CARDIF_CONSUMER,
            @Nonnull String scope, @Nonnull String classTypeIssuer, @Nonnull String scheme, @Nonnull List<String> documentIds,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Add a new folder.
     * @param composedFolderData - folder's associated data.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param issuer - class type issuer.
     * @param scheme - class type issuer.
     * @param version - folder type's template version.
     * @param documentIds - list of document ID.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return FolderCreationResult
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    FolderCreationResult addFolder(@Nonnull ComposedFolderData composedFolderData, String X_CARDIF_CONSUMER, @Nonnull String scope,
            @Nonnull String issuer, @Nonnull String scheme, @Nonnull String version, List<String> documentIds, String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Update folder.
     * @param folderId - folder ID.
     * @param folderData - associated folder data.
     * @param X_CARDIF_CONSUMER - cardif's consumer header.
     * @param scope - Sugar working scope.
     * @param folderFreezeCode - folder' state.
     * @param issuer - class type issuer.
     * @param scheme - database schema.
     * @param X_CARDIF_REQUEST_ID - cardif's request id header.
     * @param X_CARDIF_EXT_REQ_ID - cardif's external request id header.
     * @return FolderCreationResult
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    FolderCreationResult updateFolder(@Nonnull String folderId, @Nonnull ComposedFolderData folderData,
            String X_CARDIF_CONSUMER, @Nonnull String scope, String folderFreezeCode, @Nonnull String issuer, @Nonnull String scheme,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID)
            throws SugarFunctionalException, SugarTechnicalException;

    /**
     * Delete document from existing folder.
     * @param folderId - folder ID.
     * @param documentId - document ID.
     * @param scope - Sugar working scope.
     * @param schema - class type issuer.
     * @param issuer - database schema.
     * @return SimpleResponseResult
     * @throws SugarTechnicalException - technical error occurred.
     * @throws SugarFunctionalException - functional error occurred.
     */
    SimpleResponseResult deleteDocumentFromFolder(@Nonnull String folderId, @Nonnull String documentId,
            @Nonnull String scope, @Nonnull String schema, @Nonnull String issuer)
            throws SugarFunctionalException, SugarTechnicalException;


}
