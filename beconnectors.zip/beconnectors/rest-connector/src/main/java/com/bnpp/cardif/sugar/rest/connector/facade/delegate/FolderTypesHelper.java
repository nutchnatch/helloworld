package com.bnpp.cardif.sugar.rest.connector.facade.delegate;

import com.bnpp.cardif.sugar.commands.foldertype.GetFolderTypes;
import com.bnpp.cardif.sugar.commands.foldertype.GetFolderTypesById;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.rest.connector.context.RestCallContext;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.CommonConverterHelper;
import com.bnpp.cardif.sugar.rest.connector.controller.converter.ConvertFolderTypesToRestWebApi;
import com.bnpp.cardif.sugar.rest.connector.response.model.PagedFolderTypesBuilder;
import com.bnpp.cardif.sugar.rest.connector.response.model.PagedTagsBuilder;
import com.bnpp.cardif.sugar.rest.connector.response.model.SimpleFolderTypeBuilder;
import com.bnpp.cardif.sugar.rest.api.FolderTypeHelperService;
import com.bnpp.cardif.sugar.rest.api.TagsHelperService;
import com.bnpp.cardif.sugar.rest.web.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.FOLDER_NOT_FOUND;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.FOLDER_TYPE_NOT_FOUND;
import static com.bnpp.cardif.sugar.rest.connector.i18n.Messages.TAGS_NOT_FOUND;
import static java.util.stream.Collectors.toMap;

/**
 * Created by b48489 on 02-10-2017.
 */
@Component("folderTypesHelper")
@Scope("singleton")
public class FolderTypesHelper implements FolderTypeHelperService {

    @Autowired private FolderClassService folderClassService;
    @Autowired private TagsHelperService tagsHelperService;

    @Override public SimpleFolderType getFolderTypeByID(@Nonnull String folderTypeId, String X_CARDIF_CONSUMER,
            @Nonnull String scope, @Nonnull String issuer, @Nonnull String version,
            String X_CARDIF_REQUEST_ID, String X_CARDIF_EXT_REQ_ID) throws SugarFunctionalException,
            SugarTechnicalException {

        Optional<FolderType> optionalFolderType = getFolderType(folderTypeId, scope, issuer, version);

        return optionalFolderType.isPresent()
                ? new SimpleFolderTypeBuilder.Builder(true)
                        .folderType(optionalFolderType.get())
                        .build()
                : new SimpleFolderTypeBuilder.Builder(false)
                        .details(FOLDER_NOT_FOUND.format())
                        .build();
    }

    @Override public PagedFolderType getFolderTypes(String name, @Nonnull Integer pageNumber, @Nonnull Integer pageSize,
            String X_CARDIF_CONSUMER, @Nonnull String scope, List<String> sort) throws SugarFunctionalException, SugarTechnicalException {

        GetFolderTypes<RestCallContext> command = new GetFolderTypes<>(new RestCallContext(), folderClassService, scope);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        return buildFolderTypes(applyFilterName(name, command, tagMap).collect(
                    Collectors.toList()));
    }

    private Stream<FolderType> applyFilterName(String name, GetFolderTypes<RestCallContext> command, Map<String, Tag> tagMap)
    throws SugarFunctionalException, SugarTechnicalException{

        return Optional.ofNullable(name).isPresent()
                ? getFolderTypeStream(command, tagMap).filter(folderType -> folderType.getName().equals(name))
                : getFolderTypeStream(command, tagMap);
    }

    private Stream<FolderType> getFolderTypeStream(GetFolderTypes<RestCallContext> command, Map<String, Tag> tagMap)
            throws SugarFunctionalException, SugarTechnicalException {

        return toApiFolderType(StreamSupport.stream(command.call().spliterator(), false), tagMap);
    }

    @Override public PagedTags searchFolderTags(@Nonnull String folderTypeId, @Nonnull Integer pageNumber,
            Integer pageSize, @Nonnull String scope, @Nonnull String issuer, @Nonnull String version,
            List<String> sort) throws SugarFunctionalException, SugarTechnicalException {

        Optional<FolderType> optionalFolderType = getFolderType(folderTypeId, scope, issuer, version);

        return optionalFolderType.isPresent()
                ? CommonConverterHelper.getContainingTag(optionalFolderType.get().getTagList(), pageSize)
                : new PagedTagsBuilder.Builder(false)
                        .details(TAGS_NOT_FOUND.format())
                        .build();
    }

    private Optional<FolderType> getFolderType(@Nonnull String envelopeTypeId, @Nonnull String scope, @Nonnull String classTypeIssuer,
            @Nonnull String templateVersion) throws SugarFunctionalException, SugarTechnicalException{

        List<ClassId> classIdList = new ArrayList<>();
        ClassId classId = new ClassId(envelopeTypeId, classTypeIssuer, Integer.valueOf(templateVersion));
        classIdList.add(classId);

        GetFolderTypesById<RestCallContext> command = new GetFolderTypesById<>(new RestCallContext(), folderClassService,
                scope, classIdList);

        Stream<Tag> tagStream = tagsHelperService.getAllTags(scope);
        Map<String, Tag> tagMap = tagStream.collect(toMap(Tag::getName, tag->tag));

        return toApiFolderType(StreamSupport.stream(command.call().spliterator(), false), tagMap).findFirst();
    }

    private PagedFolderType buildFolderTypes(List<FolderType> folderTypeList) {

        return folderTypeList.isEmpty()
                ? new PagedFolderTypesBuilder.Builder(false)
                        .details(FOLDER_TYPE_NOT_FOUND.format())
                        .build()
                : createPagedFolderType(folderTypeList);
    }

    private PagedFolderType createPagedFolderType(List<FolderType> folderTypeList) {

        Paging paging = new Paging();
        paging.setPageSize(folderTypeList.size());

        return new PagedFolderTypesBuilder.Builder(true)
                        .folderType(folderTypeList)
                        .paging(paging)
                        .build();
    }

    private Stream<FolderType> toApiFolderType(Stream<FolderClass> folderClassStream, Map<String, Tag> tagMap) {
        return folderClassStream.map(new ConvertFolderTypesToRestWebApi(tagMap));
    }
}
