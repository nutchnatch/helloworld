package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.google.common.collect.ImmutableMap;

import java.util.Collections;
import java.util.Map;

/**
 * Created by b48489 on 27-10-2017.
 */
public class ValidityCodeFilter {

    private static final String VALIDITY_CODE_CRITERION_NAME = "ValidityCode";

    private static Criterion buildNotEqualsValidityCodeCriterion(ValdtyCode valdtyCode) {

        return CriteriaStringTypeHelper.buildNotEqualsToCriterion(
                Levels.DATA,
                VALIDITY_CODE_CRITERION_NAME,
                Collections.singletonList(valdtyCode.toString()));
    }

    private static Criterion buildEqualsValidityCodeCriterion(ValdtyCode valdtyCode) {

        return CriteriaStringTypeHelper.buildEqualsToCriterion(
                Levels.DATA,
                VALIDITY_CODE_CRITERION_NAME,
                Collections.singletonList(valdtyCode.toString()));
    }

    public static Map<Enum, Criterion> buildValidityCodeOperationConfiguration(ValdtyCode valdtyCode) {

        return new ImmutableMap.Builder<Enum, Criterion>()
                .put(AllowedOperators.EQUALS_TO, buildEqualsValidityCodeCriterion(valdtyCode))
                .put(AllowedOperators.NOT_EQUALS_TO, buildNotEqualsValidityCodeCriterion(valdtyCode))
                .build();
    }
}
