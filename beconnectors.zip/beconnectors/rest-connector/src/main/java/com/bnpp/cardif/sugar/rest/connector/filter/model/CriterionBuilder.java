package com.bnpp.cardif.sugar.rest.connector.filter.model;

import com.bnpp.cardif.sugar.rest.connector.builder.ObjectBuilder;
import com.bnpp.cardif.sugar.rest.web.model.Document;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.web.model.SimpleDocument;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import java.util.List;
import java.util.Optional;

/**
 * Created by b48489 on 18-10-2017.
 */
public class CriterionBuilder {

    public static class Builder extends Prototype<Builder> {

        public Builder(Levels levels) {
            super(levels);
        }

        @Override protected Builder self() {
            return this;
        }

        @Override public Criterion build() {

            return Optional.ofNullable(this.getLevel()).isPresent()
                    ? simpleDocumentInstance(this)
                    : raiseIllegalStateException();
        }

        private Criterion raiseIllegalStateException() throws IllegalStateException {
            throw new IllegalStateException("Invalid builder since status is null");
        }
    }

    protected abstract static class Prototype<E extends Prototype<E>> implements ObjectBuilder<Criterion> {

        private Levels level;
        private String name;
        private Operators operator;
        private Types type;
        private List<String> values;

        Prototype(Levels level) {
            this.level = level;
        }

        public Levels getLevel() {
            return level;
        }

        public String getName() {
            return name;
        }

        public E name(String name) {
            this.name = name;
            return self();
        }

        public Operators getOperator() {
            return operator;
        }

        public E operator(Operators operator) {
            this.operator = operator;
            return self();
        }

        public Types getType() {
            return type;
        }

        public E type(Types type) {
            this.type = type;
            return self();
        }

        public List<String> getValues() {
            return values;
        }

        public E values(List<String> values) {
            this.values = values;
            return self();
        }

        protected abstract E self();
    }

    private static Criterion simpleDocumentInstance(Prototype<?> builder) {

        Criterion criterion = new Criterion();
        criterion.setName(builder.getName());
        criterion.setLevel(builder.getLevel());
        criterion.setOperator(builder.getOperator());
        criterion.setType(builder.getType());
        builder.getValues().forEach(criterion.getValues()::add);
        return criterion;
    }
}
