package com.bnpp.cardif.sugar.ws.server.documentannotation;

import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.documentannotation.DocumentAnnotationService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.DocumentAnnotation;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.SugarDocument;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.FindByDocumentFileIdRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.FindByDocumentFileIdResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.SugarDocumentAnnotation;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.UpdateResponse;

/**
 * Default implementation of {@link SugarDocument} SOAP WS interface
 * 
 * @author Christopher Laszczuk
 * 
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarDocumentAnnotation", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/documentannotation/v1", name = "sugar-documentAnnotation", portName = "SugarDocumentAnnotation", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.SugarDocumentAnnotation")
public class SugarDocumentAnnotationServer implements SugarDocumentAnnotation {

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarDocumentAnnotationServer.class);

    @Autowired
    private DocumentAnnotationService documentAnnotationService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public CreateResponse create(CreateRequest createRequest, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<DocumentAnnotation> storedDocumentsAnnotations = documentAnnotationService
                    .create(createRequest.getDocumentAnnotation());

            CreateResponse response = new CreateResponse();
            response.getDocumentAnnotation().addAll(storedDocumentsAnnotations);
            return response;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public FindByDocumentFileIdResponse findByDocumentFileId(FindByDocumentFileIdRequest parameters,
            TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<DocumentAnnotation> storedDocumentsAnnotations = documentAnnotationService
                    .findByDocumentFileId(parameters.getDocumentFileId());

            FindByDocumentFileIdResponse response = new FindByDocumentFileIdResponse();
            response.getDocumentAnnotation().addAll(storedDocumentsAnnotations);
            return response;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetResponse get(GetRequest parameters, TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<DocumentAnnotation> storedDocumentsAnnotations = documentAnnotationService.get(parameters.getId());

            GetResponse response = new GetResponse();
            response.getDocumentAnnotation().addAll(storedDocumentsAnnotations);
            return response;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public DeleteResponse delete(DeleteRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<? extends Boolean> storedDocumentsAnnotations = documentAnnotationService
                    .delete(parameters.getDocumentAnnotation());

            DeleteResponse response = new DeleteResponse();
            response.getDeleted().addAll(storedDocumentsAnnotations);
            return response;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public UpdateResponse update(UpdateRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<DocumentAnnotation> storedDocumentsAnnotations = documentAnnotationService
                    .update(parameters.getDocumentAnnotation());

            UpdateResponse response = new UpdateResponse();
            response.getDocumentAnnotation().addAll(storedDocumentsAnnotations);
            return response;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}