package com.bnpp.cardif.sugar.ws.server.task;

import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.task.TaskService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetAllInBasketRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetAllInBasketResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetWithDocRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetWithDocResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.LockRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.LockResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.SugarTask;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.TransferRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.TransferResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UnlockAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UnlockAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UnlockRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UnlockResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UpdateStatusRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UpdateStatusResponse;

/**
 * 
 * @author 831743
 *
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarTask", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/task/v1", name = "sugar-task", portName = "SugarTask", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.task.v1.SugarTask")
public class SugarTaskServer implements SugarTask {

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarTaskServer.class);

    @Autowired
    private TaskService taskService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public UnlockResponse unlock(UnlockRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            taskService.unlock(parameters.getScope(), parameters.getTaskId());
            UnlockResponse response = new UnlockResponse();
            response.setScope(parameters.getScope());
            response.getTaskId().addAll(parameters.getTaskId());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot unlock tasks ", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot unlock tasks ", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot unlock tasks ", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot unlock tasks ", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public LockResponse lock(LockRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            taskService.lock(parameters.getScope(), parameters.getTaskId(), parameters.getLocker());
            LockResponse response = new LockResponse();
            response.setScope(parameters.getScope());
            response.getTaskId().addAll(parameters.getTaskId());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot lock tasks ", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot lock tasks ", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot lock tasks ", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot lock tasks ", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetResponse get(GetRequest parameters, TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            List<Task> fetchedTask = taskService.get(parameters.getScope(), parameters.getTaskId());
            GetResponse response = new GetResponse();
            response.getTask().addAll(fetchedTask);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get requested tasks", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get requested tasks", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get requested tasks", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get requested tasks", parameters.getTaskId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public UpdateStatusResponse updateStatus(UpdateStatusRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            String status = taskService.updateStatus(parameters.getScope(), parameters.getTaskId(),
                    parameters.getStatus());
            UpdateStatusResponse response = new UpdateStatusResponse();
            response.setStatus(status);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot update tasks {} with new status {}", parameters.getTaskId(), parameters.getStatus(),
                    e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot update tasks {} with new status {}", parameters.getTaskId(), parameters.getStatus(),
                    e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot update tasks {} with new status {}", parameters.getTaskId(), parameters.getStatus(),
                    e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot update tasks {} with new status {}", parameters.getTaskId(), parameters.getStatus(),
                    e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public TransferResponse transfer(TransferRequest parameters, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            taskService.transfer(parameters.getScope(), parameters.getTaskId(), parameters.getBasketId());
            TransferResponse response = new TransferResponse();
            response.getTaskId().addAll(parameters.getTaskId());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot transfer tasks {} to basket {}", parameters.getTaskId(), parameters.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot transfer tasks {} to basket {}", parameters.getTaskId(), parameters.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot transfer tasks {} to basket {}", parameters.getTaskId(), parameters.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot transfer tasks {} to basket {}", parameters.getTaskId(), parameters.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetAllInBasketResponse getAllInBasket(GetAllInBasketRequest parameters, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            SearchResults<Task> fetchedTask = taskService.getTasksInBasket(parameters.getScope(),
                    parameters.getBasketId(), (int) parameters.getStart(), (int) parameters.getMax());

            GetAllInBasketResponse response = new GetAllInBasketResponse();
            response.getTask().addAll(fetchedTask.getObjects());
            response.setNbFind(fetchedTask.getFound());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot fetch tasks contained in basket {}", parameters.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot fetch tasks contained in basket {}", parameters.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot fetch tasks contained in basket {}", parameters.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot fetch tasks contained in basket {}", parameters.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public CreateResponse create(CreateRequest parameters, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            taskService.create(parameters.getTask());
            CreateResponse response = new CreateResponse();
            response.getTask().addAll(parameters.getTask());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot create supplied tasks {}", parameters.getTask(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot create supplied tasks {}", parameters.getTask(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot create supplied tasks {}", parameters.getTask(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot create supplied tasks {}", parameters.getTask(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetWithDocResponse getWithDoc(GetWithDocRequest parameters, TokenType tokenType)
            throws TechFaultMessage, FuncFaultMessage {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public UnlockAllResponse unlockAll(UnlockAllRequest parameters, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            taskService.unlockAll(parameters.getScope(), parameters.getUserName());
            return new UnlockAllResponse();
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot unlock tasks for user {}", parameters.getUserName(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot unlock tasks for user {}", parameters.getUserName(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot unlock tasks for user {}", parameters.getUserName(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot unlock tasks for user {}", parameters.getUserName(), e);
            throw FaultMessageBuilder.build(e);
        }

    }
}
