package com.bnpp.cardif.sugar.ws.server.businessscope;

import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.SugarBusinessScope;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.UpdateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

/**
 * 
 * @author Florian Deruette
 * 
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarBusinessScope", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/businessscope/v1", name = "sugar-businessScope", portName = "SugarBusinessScope", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.SugarBusinessScope")
public class SugarBusinessScopeServer implements SugarBusinessScope {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SugarBusinessScopeServer.class);

    @Autowired
    private BusinessScopeService businessScopeService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public AddResponse add(AddRequest addRequest, TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            LOGGER.debug("Trying to add business scope " + addRequest.getBusinessScope());
            businessScopeService.store(addRequest.getBusinessScope());
            AddResponse response = new AddResponse();
            response.getBusinessScope().addAll(addRequest.getBusinessScope());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot store the supplied business scopes {}", addRequest.getBusinessScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot store the supplied business scopes {}", addRequest.getBusinessScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot store the supplied business scopes {}", addRequest.getBusinessScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot store the supplied business scopes {}", addRequest.getBusinessScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public UpdateResponse update(UpdateRequest updateRequest, TokenType tokenType)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(tokenType);

            businessScopeService.update(updateRequest.getBusinessScope());
            UpdateResponse response = new UpdateResponse();
            response.getBusinessScope().addAll(updateRequest.getBusinessScope());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot update the supplied business scopes: {}", updateRequest.getBusinessScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot update the supplied business scopes: {}", updateRequest.getBusinessScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot update the supplied business scopes: {}", updateRequest.getBusinessScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot update the supplied business scopes: {}", updateRequest.getBusinessScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetBySymbolicNameResponse getBySymbolicName(GetBySymbolicNameRequest request, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<BusinessScope> result = businessScopeService.getBySymbolicName(request.getSymbolicNames());
            LOGGER.debug(result.size() + " business scope have been fetched");
            GetBySymbolicNameResponse response = new GetBySymbolicNameResponse();
            response.getBusinessScope().addAll(result);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get for the supplied symbolic names: {}", request.getSymbolicNames(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get for the supplied symbolic names: {}", request.getSymbolicNames(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get for the supplied symbolic names: {}", request.getSymbolicNames(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get for the supplied symbolic names: {}", request.getSymbolicNames(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetAllResponse getAll(TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            LOGGER.debug("Trying to fetch business scope");
            GetAllResponse response = new GetAllResponse();
            List<BusinessScope> businessScope = businessScopeService.getAll();
            response.getBusinessScope().addAll(businessScope);
            LOGGER.debug(response.getBusinessScope().size() + " have been fetched ");
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get all business scopes", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get all business scopes", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get all business scopes", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}
