package com.bnpp.cardif.sugar.ws.server.basket;

import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.basket.BasketService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.SugarBasket;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.UpdateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarBasket", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/basket/v1", name = "sugar-basket", portName = "SugarBasket", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.SugarBasket")
public class SugarBasketServer implements SugarBasket {
    
    @Autowired
    private BasketService basketService;

    @Autowired
    private TokenValidator tokenValidator;

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarBasketServer.class);

    @Override
    public CreateResponse create(CreateRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            LOGGER.info("Storing baskets for scope {}", params.getBasket().get(0).getScope());
            List<Basket> storedBaskets = basketService.create(params.getBasket());
            CreateResponse response = new CreateResponse();
            response.getBasket().addAll(storedBaskets);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("The supplied baskets could not be created", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("The supplied baskets could not be created", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("The supplied baskets could not be created", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("The supplied baskets could not be created", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetAllResponse getAll(GetAllRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<Basket> fetchedBasket = basketService.getAllUnfiltered(params.getScope());
            fetchedBasket = basketService.filterAllowedBasket(fetchedBasket);
            GetAllResponse response = new GetAllResponse();
            response.getBasket().addAll(fetchedBasket);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get all baskets : {}", e.getCause());
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get all baskets : {}", e.getCause());
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get all baskets : {}", e.getCause());
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get all baskets : {}", e.getCause());
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetResponse get(GetRequest params, TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            LOGGER.debug("Fetching baskets");

            basketService.checkReadAccessibility(params.getBasketId(), params.getScope());
            List<Basket> fetchedBaskets = basketService.get(params.getBasketId(), params.getScope());
            GetResponse response = new GetResponse();
            response.getBasket().addAll(fetchedBaskets);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Baskets {} cannot be got from data layer for scope={}", params.getBasketId(),
                    params.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Baskets {} cannot be got from data layer for scope={}", params.getBasketId(),
                    params.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Baskets {} cannot be got from data layer for scope={}", params.getBasketId(),
                    params.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Baskets {} cannot be got from data layer for scope={}", params.getBasketId(),
                    params.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public UpdateResponse update(UpdateRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            LOGGER.info("Updating {} baskets for scope {}", params.getBasket().size(),
                    params.getBasket().get(0).getScope());

            List<Basket> updatedBaskets = basketService.update(params.getBasket());
            UpdateResponse response = new UpdateResponse();
            response.getBasket().addAll(updatedBaskets);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Baskets {} cannot be updated from data layer", params.getBasket(), e);
            throw FaultMessageBuilder.build(e);

        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Baskets {} cannot be updated from data layer", params.getBasket(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Baskets {} cannot be updated from data layer", params.getBasket(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Baskets {} cannot be updated from data layer", params.getBasket(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public DeleteResponse delete(DeleteRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            LOGGER.debug("Deleting baskets {}", params.getBasketId());

            basketService.delete(params.getBasketId(), params.getScope());
            return new DeleteResponse();
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot delete baskets : {}", params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot delete baskets : {}", params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot delete baskets : {}", params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot delete baskets : {}", params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}
