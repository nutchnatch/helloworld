package com.bnpp.cardif.sugar.ws.server.documentfile;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.SugarDocumentFile;

/**
 * Default implementation of {@link SugarDocumentFile} SOAP WS interface
 * 
 * @author Christopher Laszczuk
 * 
 */
@Service
@MTOM(enabled = true)
@WebService(serviceName = "services/SugarDocumentFile", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/documentfile/v1", name = "sugar-documentFile", portName = "SugarDocumentFile", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.SugarDocumentFile")
public class SugarDocumentFileServer implements SugarDocumentFile {

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarDocumentFileServer.class);

    @Autowired
    private DocumentFileService documentFileService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public AddResponse add(AddRequest addRequest, TokenType tokenType) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(tokenType);

            List<DocumentFile> addedFiles = documentFileService.add(addRequest.getDocumentFile());
            AddResponse response = new AddResponse();
            response.getDocumentFile().addAll(addedFiles);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Supplied document files cannot be added", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Supplied document files cannot be added", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Supplied document files cannot be added", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Supplied document files cannot be added", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetResponse get(GetRequest getRequest, TokenType tokenType) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(tokenType);

            List<DocumentFile> fetchedDocumentFiles = documentFileService.get(getRequest.getScope(),
                    getRequest.getURI());

            GetResponse response = new GetResponse();
            response.getDocumentFile().addAll(fetchedDocumentFiles);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot fetch requested files", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot fetch requested files", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot fetch requested files", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot fetch requested files", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public DeleteResponse delete(DeleteRequest deleteRequest, TokenType tokenType)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(tokenType);

            List<URI> deletedUris = documentFileService.delete(deleteRequest.getScope(), deleteRequest.getURI());
            List<Boolean> isDeleted = new ArrayList<Boolean>();
            for (URI uri : deleteRequest.getURI()) {
                if (deletedUris.contains(uri)) {
                    isDeleted.add(true);
                }
                else {
                    isDeleted.add(false);
                }
            }
            DeleteResponse response = new DeleteResponse();
            response.getDeleted().addAll(isDeleted);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot delete requested files", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot delete requested files", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot delete requested files", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot delete requested files", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}
