package com.bnpp.cardif.sugar.ws.server.documentclass;

import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchResponse.DocumentClasses;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SetActiveRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SetActiveResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SugarDocumentClass;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.UpdateResponse;

/**
 * Default implementation of {@link SugarDocumentClass} SOAP WS interface
 * 
 * @author Romain
 * 
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarDocumentClass", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/documentclass/v1", name = "sugar-documentClass", portName = "SugarDocumentClass", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SugarDocumentClass")
public class SugarDocumentClassServer implements SugarDocumentClass {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SugarDocumentClassServer.class);

    @Autowired
    private DocumentClassService documentClassService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public SearchResponse search(SearchRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        String scope = parameters.getScope();
        boolean isActiveOnly = parameters.isActiveOnly();

        try {
            getTokenValidator().validate(securityToken);

            List<DocumentClass> result = documentClassService.search(scope, parameters.getCategory(), isActiveOnly);
            SearchResponse searchResponse = new SearchResponse();
            DocumentClasses documentClasses = new DocumentClasses();
            documentClasses.getDocumentClass().addAll(result);
            searchResponse.setDocumentClasses(documentClasses);
            searchResponse.setNbFind(result.size());
            return searchResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error(
                    "The search of document class cannot be executed "
                            + "according to scope={}, category={} and isActive={}",
                    scope, parameters.getCategory(), isActiveOnly, e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error(
                    "The search of document class cannot be executed "
                            + "according to scope={}, category={} and isActive={}",
                    scope, parameters.getCategory(), isActiveOnly, e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error(
                    "The search of document class cannot be executed "
                            + "according to scope={}, category={} and isActive={}",
                    scope, parameters.getCategory(), isActiveOnly, e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error(
                    "The search of document class cannot be executed "
                            + "according to scope={}, category={} and isActive={}",
                    scope, parameters.getCategory(), isActiveOnly, e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public AddResponse add(AddRequest parameters, TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            AddResponse response = new AddResponse();
            response.getDocumentClass().addAll(documentClassService.add(parameters.getDocumentClass()));
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Supplied document classes cannot be added", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Supplied document classes cannot be added", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Supplied document classes cannot be added", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Supplied document classes cannot be added", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetResponse get(GetRequest parameters, TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<DocumentClass> result = documentClassService.get(parameters.getScope(), parameters.getClassId());
            GetResponse getResponse = new GetResponse();
            getResponse.getDocumentClass().addAll(result);
            return getResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Document classes cannot be fetched for ids={}", parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Document classes cannot be fetched for ids={}", parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Document classes cannot be fetched for ids={}", parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Document classes cannot be fetched for ids={}", parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public UpdateResponse update(UpdateRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<DocumentClass> updatedClasses = documentClassService.update(parameters.getDocumentClass(),
                    parameters.isCreateNewVersion());
            UpdateResponse response = new UpdateResponse();
            response.getDocumentClass().addAll(updatedClasses);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Supplied document classes cannot be updated", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Supplied document classes cannot be updated", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Supplied document classes cannot be updated", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Supplied document classes cannot be updated", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public DeleteResponse delete(DeleteRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SetActiveResponse setActive(SetActiveRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            documentClassService.activate(parameters.getScope(), parameters.getClassId(), parameters.isActivate());
            return new SetActiveResponse();
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Document classes cannot be activated/disabled for ids={}", parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Document classes cannot be activated/disabled for ids={}", parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Document classes cannot be activated/disabled for ids={}", parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Document classes cannot be activated/disabled for ids={}", parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}
