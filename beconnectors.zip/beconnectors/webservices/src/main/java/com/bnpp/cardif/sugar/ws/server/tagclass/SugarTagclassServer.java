package com.bnpp.cardif.sugar.ws.server.tagclass;

import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.SugarTagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.UpdateResponse;

/**
 * 
 * @author Florian Deruette
 * 
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarTagclass", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/tagclass/v1", name = "sugar-tagClass", portName = "SugarTagClass", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.SugarTagClass")
public class SugarTagclassServer implements SugarTagClass {

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarTagclassServer.class);

    @Autowired
    private TagclassService tagclassService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public CreateResponse create(CreateRequest createRequest, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            tagclassService.store(createRequest.getTagClass());
            CreateResponse response = new CreateResponse();
            response.getTagClass().addAll(createRequest.getTagClass());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("The supplied tag classes cannot be stored", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("The supplied tag classes cannot be stored", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("The supplied tag classes cannot be stored", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("The supplied tag classes cannot be stored", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetAllResponse getAll(GetAllRequest getAllRequest, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<TagClass> tagclasses = tagclassService.getAll(getAllRequest.getScope());
            GetAllResponse response = new GetAllResponse();
            response.getTagClass().addAll(tagclasses);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("All tag classes cannot be got", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("All tag classes cannot be got", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("All tag classes cannot be got", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("All tag classes cannot be got", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetResponse get(GetRequest getRequest, TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<TagClass> tagclasses = tagclassService.get(getRequest.getScope(), getRequest.getClassId());
            GetResponse response = new GetResponse();
            response.getTagClass().addAll(tagclasses);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Requested tag classes cannot be got {}", getRequest.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Requested tag classes cannot be got {}", getRequest.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Requested tag classes cannot be got {}", getRequest.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Requested tag classes cannot be got {}", getRequest.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetBySymbolicNameResponse getBySymbolicName(GetBySymbolicNameRequest request, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<TagClass> tagclasses = tagclassService.getBySymbolicName(request.getScope(),
                    request.getSymbolicNames(), true);
            GetBySymbolicNameResponse response = new GetBySymbolicNameResponse();
            response.getTagClass().addAll(tagclasses);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot fetch tag classes by symbolic names: {}", request.getSymbolicNames(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot fetch tag classes by symbolic names: {}", request.getSymbolicNames(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot fetch tag classes by symbolic names: {}", request.getSymbolicNames(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot fetch tag classes by symbolic names: {}", request.getSymbolicNames(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public UpdateResponse update(UpdateRequest updateRequest, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            tagclassService.update(updateRequest.getTagClass());
            UpdateResponse response = new UpdateResponse();
            response.getTagClass().addAll(updateRequest.getTagClass());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot update supplied tag clases", updateRequest.getTagClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot update supplied tag clases", updateRequest.getTagClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot update supplied tag clases", updateRequest.getTagClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot update supplied tag clases", updateRequest.getTagClass(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}
