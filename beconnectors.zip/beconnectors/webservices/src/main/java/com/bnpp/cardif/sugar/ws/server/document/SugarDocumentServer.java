package com.bnpp.cardif.sugar.ws.server.document;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ChildObject;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.FindRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.FindResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.FindStreamedRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.FindStreamedResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.ReindexRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.ReindexResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.StoreRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.StoreResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.SugarDocument;

/**
 * Default implementation of {@link SugarDocument} SOAP WS interface
 * 
 * @author Christopher Laszczuk
 * 
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarDocument", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/document/v1", name = "sugar-document", portName = "SugarDocument", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.document.v1.SugarDocument")
public class SugarDocumentServer implements SugarDocument {

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarDocumentServer.class);

    @Autowired
    private DocumentService documentService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public StoreResponse store(StoreRequest storeRequest, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<Document> storedDocuments = documentService.store(storeRequest.getDocument());

            documentService.fireStoreDocEvent(storedDocuments);

            StoreResponse response = new StoreResponse();
            response.getDocument().addAll(storedDocuments);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Documents cannot be stored due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Documents cannot be stored due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetResponse get(GetRequest getRequest, TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<Document> fetchedDocuments;
            fetchedDocuments = documentService.get(getRequest.getScope(), getRequest.getId(),
                    getRequest.isIncludeChild(), getRequest.isIncludeFile());
            GetResponse getResponse = new GetResponse();
            getResponse.getDocument().addAll(fetchedDocuments);
            return getResponse;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Documents {} cannot be got for scope={} due to a functional exception", getRequest.getId(),
                    getRequest.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Documents {} cannot be got for scope={} due to a technical exception", getRequest.getId(),
                    getRequest.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Documents {} cannot be got for scope={} due to a technical exception", getRequest.getId(),
                    getRequest.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Documents {} cannot be got for scope={} due to a functional exception", getRequest.getId(),
                    getRequest.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public FindResponse find(FindRequest findRequest, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        String errorMessage = "Cannot find documents according to criteria {}";
        try {
            getTokenValidator().validate(securityToken);
            // memorize scope in case the childs are required.
            String scope = extractScopeFromCriteria(findRequest);

            SearchResults<Document> searchResults = documentService.find(findRequest.getCriteria(),
                    findRequest.getOrder(), findRequest.getStart(), findRequest.getMax());

            List<Document> resultList = searchResults.getObjects();
            // add the child documents if required.
            enrichDocumentListWithChilds(findRequest, scope, resultList);
            FindResponse response = new FindResponse();
            response.getDocument().addAll(resultList);
            response.setFound(searchResults.getFound());
            response.setMaxSearch(searchResults.getSearchLimit());

            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error(errorMessage, findRequest.getCriteria(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error(errorMessage, findRequest.getCriteria(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error(errorMessage, findRequest.getCriteria(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error(errorMessage, findRequest.getCriteria(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    private void enrichDocumentListWithChilds(FindRequest findRequest, String scope, List<Document> resultList)
            throws SugarFunctionalException, SugarTechnicalException {
        
        if (findRequest.isIncludeChild()) {
            LOGGER.debug("Enrich result with child list");
            if (scope != null) {
                LOGGER.debug("Scope found for child criteria : {}", scope);
                // add the child documents
                for (Document document : resultList) {
                    ChildObject childObject = document.getChildObject();
                    addChildDocument(scope, childObject);
                }
            }
        }
    }

    private void addChildDocument(String scope, ChildObject childObject)
            throws SugarFunctionalException, SugarTechnicalException {
        if (childObject != null && childObject.getId() != null && !childObject.getId().isEmpty()) {
            List<Id> childIdList = childObject.getId();
            LOGGER.debug("childIdList : {}", childIdList);
            List<Document> childDocumentList = documentService.get(scope, childIdList, true, false);
            if(childDocumentList != null && !childDocumentList.isEmpty()) {
                List<Document> childObjectDocumentList = childObject.getDocument();
                if(childObjectDocumentList == null) {
                    childObjectDocumentList = new ArrayList<>();
                }
                childObjectDocumentList.clear();
                childObjectDocumentList.addAll(childDocumentList);
            }
        }
    }

    private String extractScopeFromCriteria(FindRequest findRequest) {
        String scope = null;
        if (findRequest.isIncludeChild()) {
            LOGGER.debug("memorize scope for child list");
            // get Scope criteria
            Criteria criteria = findRequest.getCriteria();
            List<Criterion> criterionList = criteria.getCriterionList();
            for (Criterion criterion : criterionList) {
                LOGGER.debug("criterion : {}", criterion);
                if (criterion.getName() != null && criterion.getName().equals("Scope")
                        && criterion.getValues() != null && !criterion.getValues().isEmpty()) {
                    scope = criterion.getValues().get(0);
                    break;
                }
            }
        }
        return scope;
    }

    @Override
    public ReindexResponse reindex(ReindexRequest reindexRequest, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        String functionnalErrorMessage = "Documents cannot be updated due to a functional exception";
        String technicalErrorMessage = "Documents cannot be updated due to a technical exception";
        try {
            getTokenValidator().validate(securityToken);

            List<Document> updatedDocuments = documentService.update(reindexRequest.getDocument());
            ReindexResponse reindexResponse = new ReindexResponse();
            reindexResponse.getDocument().addAll(updatedDocuments);
            LOGGER.info("Number of document(s) reIndexed {}", reindexResponse.getDocument().size());
            return reindexResponse;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error(functionnalErrorMessage, e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error(technicalErrorMessage, e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error(technicalErrorMessage, e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error(functionnalErrorMessage, e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public DeleteResponse delete(DeleteRequest deleteRequest, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<Document> deletedDocuments = documentService.delete(deleteRequest.getId(), deleteRequest.getScope());
            DeleteResponse response = new DeleteResponse();
            response.getDocument().addAll(deletedDocuments);
            LOGGER.info("Number of document(s) deleted {}", deletedDocuments.size());
            return response;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Documents cannot be deleted due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Documents cannot be deleted due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Documents cannot be deleted due to a technical exception", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Documents cannot be deleted due to a functional exception", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public FindStreamedResponse findStreamed(FindStreamedRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        // TODO Auto-generated method stub
        return null;
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}