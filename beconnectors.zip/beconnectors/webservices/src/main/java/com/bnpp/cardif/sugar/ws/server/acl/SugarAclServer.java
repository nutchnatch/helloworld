package com.bnpp.cardif.sugar.ws.server.acl;

import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.AssignToBasketRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.AssignToBasketResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.AssignToClassRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.AssignToClassResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.ChangeDefaultAclRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.ChangeDefaultAclResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.GetByBasketIdRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.GetByBasketIdResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.GetByClassIdRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.GetByClassIdResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.GetDefaultRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.GetDefaultResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.SugarAcl;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarAcl", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/acl/v1", name = "sugar-acl", portName = "SugarAcl", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.SugarAcl")
public class SugarAclServer implements SugarAcl {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SugarAclServer.class);

    @Autowired
    private AclService aclService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public GetByClassIdResponse getByClassId(GetByClassIdRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            GetByClassIdResponse response = new GetByClassIdResponse();
            for (ClassId id : params.getClassId()) {
                response.getAccessControlList()
                        .add(aclService.getByClassId(params.getScope(), id, params.isIsInstanceValue()));
            }
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("No ACL can be fetched for {} and isInstance=", params.getClassId(),
                    params.isIsInstanceValue(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("No ACL can be fetched for {} and isInstance=", params.getClassId(),
                    params.isIsInstanceValue(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("No ACL can be fetched for {} and isInstance=", params.getClassId(),
                    params.isIsInstanceValue(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("No ACL can be fetched for {} and isInstance=", params.getClassId(),
                    params.isIsInstanceValue(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetByBasketIdResponse getByBasketId(GetByBasketIdRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            GetByBasketIdResponse response = new GetByBasketIdResponse();

            for (BasketId id : params.getBasketId()) {
                response.getAccessControlList().add(aclService.getByBasketId(params.getScope(), id));
            }
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("No ACL can be fetched for {}", params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("No ACL can be fetched for {}", params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("No ACL can be fetched for {}", params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("No ACL can be fetched for {}", params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetAllResponse getAll(GetAllRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            List<AccessControlList> result = aclService.getAll(params.getScope());
            GetAllResponse response = new GetAllResponse();
            response.getAccessControlList().addAll(result);
            return response;
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("No ACL can be got for {}", params.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("No ACL can be got for {}", params.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("No ACL can be got for {}", params.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("No ACL can be got for {}", params.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public AssignToClassResponse assignToClass(AssignToClassRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            AccessControlList result = aclService.assignToClass(params.getScope(), params.getAclId(),
                    params.getClassId(), params.isIsInstanceValue());
            AssignToClassResponse response = new AssignToClassResponse();
            response.setAccessControlList(result);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("In scope={}, the ACL  {} cannot be assigned to {}", params.getScope(), params.getAclId(),
                    params.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("In scope={}, the ACL  {} cannot be assigned to {}", params.getScope(), params.getAclId(),
                    params.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("In scope={}, the ACL  {} cannot be assigned to {}", params.getScope(), params.getAclId(),
                    params.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("In scope={}, the ACL  {} cannot be assigned to {}", params.getScope(), params.getAclId(),
                    params.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public AssignToBasketResponse assignToBasket(AssignToBasketRequest params, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            LOGGER.info("Assigning Acl with id " + params.getAclId() + " to class id : " + params.getBasketId());

            AccessControlList result = aclService.assignToBasket(params.getScope(), params.getAclId(),
                    params.getBasketId());
            AssignToBasketResponse response = new AssignToBasketResponse();
            response.setAccessControlList(result);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("In scope={}, the ACL: {} cannot be assigned to basket: {}", params.getScope(),
                    params.getAclId(), params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("In scope={}, the ACL: {} cannot be assigned to basket: {}", params.getScope(),
                    params.getAclId(), params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("In scope={}, the ACL: {} cannot be assigned to basket: {}", params.getScope(),
                    params.getAclId(), params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("In scope={}, the ACL: {} cannot be assigned to basket: {}", params.getScope(),
                    params.getAclId(), params.getBasketId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetDefaultResponse getDefault(GetDefaultRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {

        try {
            tokenValidator.validate(securityToken);

            GetDefaultResponse response = new GetDefaultResponse();
            response.setAccessControlList(aclService.getDefault(parameters.getScope()));
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("getDefault error:", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("getDefault error:", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("getDefault error:", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("getDefault error:", e);
            throw FaultMessageBuilder.build(e);
        }

    }

    @Override
    public ChangeDefaultAclResponse changeDefaultAcl(ChangeDefaultAclRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            AccessControlList acl = aclService.setDefaultACL(parameters.getScope(), parameters.getAclId());
            ChangeDefaultAclResponse response = new ChangeDefaultAclResponse();
            response.setAccessControlList(acl);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("changeDefaultAcl error:", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("changeDefaultAcl error:", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("changeDefaultAcl error:", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("changeDefaultAcl error:", e);
            throw FaultMessageBuilder.build(e);
        }

    }
}
