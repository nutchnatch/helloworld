package com.bnpp.cardif.sugar.ws.server.folder;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.MCOFolderType.ChildComponents;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ChildObject;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.FindRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.FindResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.SugarFolder;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateResponse;

/**
 * 
 * @author 831743
 *
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarFolder", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/folder/v1", name = "sugar-folder", portName = "SugarFolder", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.SugarFolder")
public class SugarFolderServer implements SugarFolder {

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarFolderServer.class);

    @Autowired
    private FolderService folderService;
    
    @Autowired
    private DocumentService documentService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public CreateResponse create(CreateRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            CreateResponse addResponse = new CreateResponse();
            List<Folder> addedFolders = folderService.add(parameters.getFolder());
            addResponse.getFolder().addAll(addedFolders);
            return addResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Folders cannot be stored", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Folders cannot be stored", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Folders cannot be stored", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Folders cannot be stored", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public DeleteResponse delete(DeleteRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public GetResponse get(GetRequest parameters, TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<Folder> folders = folderService.get(parameters.getFolderId(), parameters.getScope());
            GetResponse getResponse = new GetResponse();
            getResponse.getFolder().addAll(folders);
            return getResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Folders cannot be fetched", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Folders cannot be fetched", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Folders cannot be fetched", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Folders cannot be fetched", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public UpdateResponse update(UpdateRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            UpdateResponse updateResponse = new UpdateResponse();
            List<Folder> updatedFolders = folderService.update(parameters.getFolder(),
                    parameters.getFolder().get(0).getScope());
            updateResponse.getFolder().addAll(updatedFolders);
            return updateResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot update the supplied folders {}", parameters.getFolder(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot update the supplied folders {}", parameters.getFolder(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot update the supplied folders {}", parameters.getFolder(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot update the supplied folders {}", parameters.getFolder(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public FindResponse find(FindRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        String errorMsg = "Cannot find folders according to supplied parameters and criteria={}";
        try {
            getTokenValidator().validate(securityToken);
            // memorize scope in case the childs are required.
            String scope = extractScopeFromCriteria(parameters);

            SearchResults<Folder> searchResults = folderService.find(parameters.getCriteria(), parameters.getOrder(),
                    (int) parameters.getStart(), (int) parameters.getMax());

            List<Folder> resultList = searchResults.getObjects();
            // add the child documents if required.
            enrichFolderListWithChilds(parameters, scope, resultList);
            FindResponse response = new FindResponse();
            response.getFolder().addAll(resultList);
            response.setFound(searchResults.getFound());
            response.setMaxSearch(searchResults.getSearchLimit());
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error(errorMsg,
                    parameters.getCriteria(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error(errorMsg,
                    parameters.getCriteria(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error(errorMsg,
                    parameters.getCriteria(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error(errorMsg,
                    parameters.getCriteria(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    private String extractScopeFromCriteria(FindRequest parameters) {
        String scope = null;
        if (parameters.isIncludeChild()) {
            LOGGER.debug("memorize scope for child list");
            // get Scope criteria
            Criteria criteria = parameters.getCriteria();
            List<Criterion> criterionList = criteria.getCriterionList();
            for (Criterion criterion : criterionList) {
                LOGGER.debug("criterion : {}", criterion);
                if (criterion.getName() != null && criterion.getName().equals("Scope")
                        && criterion.getValues() != null && !criterion.getValues().isEmpty()) {
                    scope = criterion.getValues().get(0);
                    break;
                }
            }
        }
        return scope;
    }

    private void enrichFolderListWithChilds(FindRequest parameters, String scope, List<Folder> resultList)
            throws SugarFunctionalException, SugarTechnicalException {

        if (parameters.isIncludeChild()) {
            LOGGER.debug("Enrich result with child list");
            if (scope != null) {
                LOGGER.debug("Scope found for child criteria : {}", scope);
                // add the child documents
                for (Folder folder : resultList) {
                    ChildComponents childObject = folder.getChildComponents();
                    addChildDocument(scope, childObject);
                }
            }
        }
    }

    private void addChildDocument(String scope, ChildComponents childObject)
            throws SugarFunctionalException, SugarTechnicalException {
        
        if (childObject != null && childObject.getId() != null && !childObject.getId().isEmpty()) {
            List<Id> childIdList = childObject.getId();
            LOGGER.debug("childIdList : {}", childIdList);
            List<Document> childDocumentList = documentService.get(scope, childIdList, true, false);
            if(childDocumentList != null && !childDocumentList.isEmpty()) {
                List<Document> childObjectDocumentList = childObject.getDocument();
                if(childObjectDocumentList == null) {
                    childObjectDocumentList = new ArrayList<>();
                }
                childObjectDocumentList.clear();
                childObjectDocumentList.addAll(childDocumentList);
            }
        }
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}
