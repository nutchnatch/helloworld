package com.bnpp.cardif.sugar.ws.server.reporting;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01101;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.fact.ReportingService;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetBasketRatioReportRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetBasketRatioReportResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetBasketRatioRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetBasketRatioResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetDocumentStockIndicatorRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetDocumentStockIndicatorResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetDocumentStockReportRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetDocumentStockReportResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetEnvelopeFlowsReportRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetEnvelopeFlowsReportResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetEnvelopeFlowsRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetEnvelopeFlowsResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetFolderStockIndicatorRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetFolderStockIndicatorResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetFolderStockReportRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetFolderStockReportResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetReportingSummaryRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetReportingSummaryResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.SugarReporting;

/**
 * 
 * @author 831743
 *
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarReporting", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/reporting/v1", name = "sugar-reporting", portName = "SugarReporting", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.SugarReporting")
public class SugarReportingServer implements SugarReporting {

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarReportingServer.class);

    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private final SimpleDateFormat dateFormater = new SimpleDateFormat(DATE_FORMAT);

    @Autowired
    private ReportingService reportingService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public GetEnvelopeFlowsResponse getEnvelopeFlowsIndicators(GetEnvelopeFlowsRequest parameters,
            TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            List<EnvelopeFlows> envelopeFlowsByPeriod = reportingService.getEnvelopeFlowsByPeriod(parameters.getScope(),
                    parseDate(parameters.getStartingDate()), parseDate(parameters.getEndingDate()));
            GetEnvelopeFlowsResponse response = new GetEnvelopeFlowsResponse();
            response.getEnvelopeFlows().addAll(envelopeFlowsByPeriod);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get envelope flows indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get envelope flows indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get envelope flows indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get envelope flows indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }

    }

    @Override
    public GetBasketRatioResponse getBasketRatioIndicators(GetBasketRatioRequest parameters, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            List<BasketRatio> basketRatios = reportingService.getBasketRatio(parameters.getScope(),
                    parseDate(parameters.getStartingDate()), parseDate(parameters.getEndingDate()));
            GetBasketRatioResponse response = new GetBasketRatioResponse();
            response.getBasketRatio().addAll(basketRatios);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get basket ration indicators for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get basket ration indicators for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get basket ration indicators for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get basket ration indicators for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetFolderStockIndicatorResponse getFolderStockIndicators(GetFolderStockIndicatorRequest parameters,
            TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            List<FolderStock> stock = reportingService.getFolderStockIndicators(parameters.getScope(),
                    parseDate(parameters.getStartingDate()), parseDate(parameters.getEndingDate()));
            GetFolderStockIndicatorResponse response = new GetFolderStockIndicatorResponse();
            response.getFolderStock().addAll(stock);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get folder stock indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get folder stock indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get folder stock indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get folder stock indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetDocumentStockIndicatorResponse getDocumentStockIndicators(GetDocumentStockIndicatorRequest parameters,
            TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            List<DocumentStock> documentStocks = reportingService.getDocumentStockIndicators(parameters.getScope(),
                    parseDate(parameters.getStartingDate()), parseDate(parameters.getEndingDate()));
            GetDocumentStockIndicatorResponse response = new GetDocumentStockIndicatorResponse();
            response.getDocumentStock().addAll(documentStocks);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get document stock indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get folder stock indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get document stock indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get document stock indicator for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetReportingSummaryResponse getReportingSummary(GetReportingSummaryRequest parameters,
            TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        GetReportingSummaryResponse response = new GetReportingSummaryResponse();
        try {
            tokenValidator.validate(securityToken);

            response.setSummary(reportingService.getReportingSummary(parameters.getScope()));
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get reporting summary for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get reporting summary for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get reporting summary for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }

        return response;
    }

    @Override
    public GetBasketRatioReportResponse getBasketRatioReport(GetBasketRatioReportRequest parameters,
            TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            DocumentFile report = reportingService.getBasketRatioReport(parameters.getScope(),
                    parseDate(parameters.getStartingDate()), parseDate(parameters.getEndingDate()));
            GetBasketRatioReportResponse response = new GetBasketRatioReportResponse();
            response.setDocumentFile(report);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get basket ratio report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get basket ratio report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get basket ratio report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get basket ratio report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetEnvelopeFlowsReportResponse getEnvelopeFlowsReport(GetEnvelopeFlowsReportRequest parameters,
            TokenType securityToken) throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(securityToken);

            DocumentFile report = reportingService.getEnvelopeFlowsReport(parameters.getScope(),
                    parseDate(parameters.getStartingDate()), parseDate(parameters.getEndingDate()));
            GetEnvelopeFlowsReportResponse response = new GetEnvelopeFlowsReportResponse();
            response.setDocumentFile(report);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetFolderStockReportResponse getFolderStockReport(GetFolderStockReportRequest parameters,
            TokenType tokenType) throws TechFaultMessage, FuncFaultMessage {

        try {
            tokenValidator.validate(tokenType);

            DocumentFile report = reportingService.getFolderStockReport(parameters.getScope(),
                    parseDate(parameters.getStartingDate()), parseDate(parameters.getEndingDate()));
            GetFolderStockReportResponse response = new GetFolderStockReportResponse();
            response.setDocumentFile(report);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetDocumentStockReportResponse getDocumentStockReport(GetDocumentStockReportRequest parameters,
            TokenType tokenType) throws TechFaultMessage, FuncFaultMessage {
        try {
            tokenValidator.validate(tokenType);

            DocumentFile report = reportingService.getDocumentStockReport(parameters.getScope(),
                    parseDate(parameters.getStartingDate()), parseDate(parameters.getEndingDate()));
            GetDocumentStockReportResponse response = new GetDocumentStockReportResponse();
            response.setDocumentFile(report);
            return response;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get envelope flows report for scope {}", parameters.getScope(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    private Date parseDate(String date) throws SugarTechnicalException {
        try {
            if (date != null) {
                return dateFormater.parse(date);
            }

            return null;
        }
        catch (ParseException e) {
            throw ExceptionBuilder.createTechnicalException(T01101, date, DATE_FORMAT, e);
        }
        catch (NullPointerException e) {
            throw ExceptionBuilder.createTechnicalException(T01101, date, DATE_FORMAT, e);
        }
    }

}