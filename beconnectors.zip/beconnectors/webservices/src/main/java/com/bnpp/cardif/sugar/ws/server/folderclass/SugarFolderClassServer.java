package com.bnpp.cardif.sugar.ws.server.folderclass;

import java.util.List;

import javax.jws.WebService;
import javax.xml.ws.soap.MTOM;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.ws.server.FaultMessageBuilder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SearchRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SearchResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SetActiveRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SetActiveResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SugarFolderClass;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.UpdateResponse;

/**
 * Default implementation of {@link SugarFolderClass} SOAP WS interface
 * 
 * @author Romain
 * 
 */
@Service
@MTOM(enabled = false)
@WebService(serviceName = "services/SugarFolderClass", targetNamespace = "http://sugar.assurance.bnpparibas.com/internal/service/app/folderclass/v1", name = "sugar-folderClass", portName = "SugarFolderClass", endpointInterface = "com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SugarFolderClass")
public class SugarFolderClassServer implements SugarFolderClass {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SugarFolderClassServer.class);

    @Autowired
    private FolderClassService folderClassService;

    @Autowired
    private TokenValidator tokenValidator;

    @Override
    public CreateResponse create(CreateRequest parameters, TokenType securityToken)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<FolderClass> folderClasses = folderClassService.add(parameters.getFolderClass());
            CreateResponse createResponse = new CreateResponse();
            createResponse.getFolderClass().addAll(folderClasses);
            return createResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot add the supplied folder classes ", parameters.getFolderClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot add the supplied folder classes ", parameters.getFolderClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot add the supplied folder classes ", parameters.getFolderClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot add the supplied folder classes ", parameters.getFolderClass(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public UpdateResponse update(UpdateRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<FolderClass> folderClasses = folderClassService.update(parameters.getFolderClass(),
                    parameters.isCreateNewVersion());
            UpdateResponse updateResponse = new UpdateResponse();
            updateResponse.getFolderClass().addAll(folderClasses);
            return updateResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Supplied folder classes cannot be updated", parameters.getFolderClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Supplied folder classes cannot be updated", parameters.getFolderClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Supplied folder classes cannot be updated", parameters.getFolderClass(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Supplied folder classes cannot be updated", parameters.getFolderClass(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public GetResponse get(GetRequest parameters, TokenType securityToken) throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<FolderClass> folderClasses = folderClassService.get(parameters.getClassId(), parameters.getScope());
            GetResponse getResponse = new GetResponse();
            getResponse.getFolderClass().addAll(folderClasses);
            return getResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get folder classes for scope={} and ids={}", parameters.getScope(),
                    parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get folder classes for scope={} and ids={}", parameters.getScope(),
                    parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get folder classes for scope={} and ids={}", parameters.getScope(),
                    parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get folder classes for scope={} and ids={}", parameters.getScope(),
                    parameters.getClassId(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public SearchResponse search(SearchRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public GetAllResponse getAll(GetAllRequest parameters, TokenType securityToken)
            throws FuncFaultMessage, TechFaultMessage {
        try {
            getTokenValidator().validate(securityToken);

            List<FolderClass> classes = folderClassService.getAll(parameters.getScope(), parameters.isActiveOnly());
            GetAllResponse getResponse = new GetAllResponse();
            getResponse.getFolderClass().addAll(classes);
            return getResponse;
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot get all folder classes for scope={} and isActiveOnly={}", parameters.getScope(),
                    parameters.isActiveOnly(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Cannot get all folder classes for scope={} and isActiveOnly={}", parameters.getScope(),
                    parameters.isActiveOnly(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Cannot get all folder classes for scope={} and isActiveOnly={}", parameters.getScope(),
                    parameters.isActiveOnly(), e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Cannot get all folder classes for scope={} and isActiveOnly={}", parameters.getScope(),
                    parameters.isActiveOnly(), e);
            throw FaultMessageBuilder.build(e);
        }
    }

    @Override
    public SetActiveResponse setActive(SetActiveRequest parameters, TokenType tokenType)
            throws TechFaultMessage, FuncFaultMessage {
        try {
            getTokenValidator().validate(tokenType);

            folderClassService.setActive(parameters.getClassId(), parameters.isActive(), parameters.getScope());
            return new SetActiveResponse();
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Folder classes: {} cannot be {} ", parameters.getClassId(),
                    parameters.isActive() ? "activated" : "deactivated", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (SugarFunctionalException e) {
            LOGGER.error("Folder classes: {} cannot be {} ", parameters.getClassId(),
                    parameters.isActive() ? "activated" : "deactivated", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (TechnicalException e) {
            LOGGER.error("Folder classes: {} cannot be {} ", parameters.getClassId(),
                    parameters.isActive() ? "activated" : "deactivated", e);
            throw FaultMessageBuilder.build(e);
        }
        catch (FunctionalException e) {
            LOGGER.error("Folder classes: {} cannot be {} ", parameters.getClassId(),
                    parameters.isActive() ? "activated" : "deactivated", e);
            throw FaultMessageBuilder.build(e);
        }
    }

    public TokenValidator getTokenValidator() {
        return tokenValidator;
    }
}
