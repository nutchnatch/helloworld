package com.bnpp.cardif.sugar.ws.server.businessscope;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.UpdateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

@RunWith(MockitoJUnitRunner.class)
public class SugarBusinessScopeTest {
    @Mock
    private BusinessScopeService businessScopeService;

    @Mock
    private TokenValidator tokenValidator;

    @InjectMocks
    private final SugarBusinessScopeServer sugarBusinessScopeServer = new SugarBusinessScopeServer();

    @Before
    public void prepare() throws SugarTechnicalException, TechnicalException, FunctionalException {
        doNothing().when(tokenValidator).validate(any(TokenType.class));
    }

    @Test
    public void testGetAll() throws FuncFaultMessage, TechFaultMessage, SugarTechnicalException {
        List<BusinessScope> tagclasses = new ArrayList<BusinessScope>();
        when(businessScopeService.getAll()).thenReturn(tagclasses);

        com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetAllResponse response = sugarBusinessScopeServer
                .getAll(new TokenType());

        verify(businessScopeService).getAll();
        assertNotNull(response.getBusinessScope());
    }

    @Test
    public void testGetBySymbolicName()
            throws TechFaultMessage, FuncFaultMessage, SugarTechnicalException, SugarFunctionalException {
        GetBySymbolicNameRequest request = new GetBySymbolicNameRequest();
        List<String> names = new ArrayList<String>();
        names.add("SymbolicName");
        request.getSymbolicNames().addAll(names);
        List<BusinessScope> businessScopes = new ArrayList<BusinessScope>();

        when(businessScopeService.getBySymbolicName(anyListOf(String.class))).thenReturn(businessScopes);
        GetBySymbolicNameResponse response = sugarBusinessScopeServer.getBySymbolicName(request, new TokenType());

        verify(businessScopeService).getBySymbolicName(request.getSymbolicNames());
        assertNotNull(response.getBusinessScope());
    }

    @Test
    public void testUpdate()
            throws TechFaultMessage, FuncFaultMessage, SugarTechnicalException, SugarFunctionalException {
        UpdateRequest request = new UpdateRequest();
        List<BusinessScope> businessScopes = new ArrayList<BusinessScope>();
        request.getBusinessScope().addAll(businessScopes);

        UpdateResponse response = sugarBusinessScopeServer.update(request, new TokenType());

        verify(businessScopeService).update(request.getBusinessScope());
        assertNotNull(response.getBusinessScope());
    }

    @Test
    public void testAdd() throws TechFaultMessage, FuncFaultMessage, SugarTechnicalException, SugarFunctionalException {
        AddRequest request = new AddRequest();
        List<BusinessScope> tagclasses = new ArrayList<BusinessScope>();
        request.getBusinessScope().addAll(tagclasses);
        AddResponse response = sugarBusinessScopeServer.add(request, new TokenType());

        verify(businessScopeService).store(request.getBusinessScope());
        assertNotNull(response.getBusinessScope());
    }
}
