package com.bnpp.cardif.sugar.ws.server.folderclass;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.folderclass.test.FolderClassMockUtility;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetResponse;

@RunWith(MockitoJUnitRunner.class)
public class SugarFolderClassServerTest {
    private final String SCOPE = "Syldavia";

    @Mock
    private FolderClassService folderClassService;

    @Mock
    private TokenValidator tokenValidator;

    @InjectMocks
    private SugarFolderClassServer sugarFolderClassServer = new SugarFolderClassServer();

    @Before
    public void prepare() throws SugarTechnicalException, TechnicalException, FunctionalException {
        doNothing().when(tokenValidator).validate(any(TokenType.class));
    }

    @Test
    public void testCreate() throws Exception {
        FolderClass folderAdded = FolderClassMockUtility.buildFolderClassContractManagement();
        List<FolderClass> foldersAdded = new ArrayList<FolderClass>();
        foldersAdded.add(folderAdded);
        when(folderClassService.add(anyListOf(FolderClass.class))).thenReturn(foldersAdded);
        CreateRequest parameters = new CreateRequest();
        FolderClass folderClassToAdd = FolderClassMockUtility.buildFolderClassContractManagement();
        folderClassToAdd.setClassId(null);
        parameters.getFolderClass().add(folderClassToAdd);
        CreateResponse createResponse = sugarFolderClassServer.create(parameters, new TokenType());
        assertNotNull(createResponse);
        assertNotNull(createResponse.getFolderClass());
        assertFalse(createResponse.getFolderClass().isEmpty());
        assertNotNull(createResponse.getFolderClass().get(0));
        assertNotNull(createResponse.getFolderClass().get(0).getClassId());
    }

    @Test
    public void testUpdate() throws Exception {
        FolderClass folderUpdated = FolderClassMockUtility.buildFolderClassContractManagement();
        folderUpdated.setType("MyTypeUpdated");
        List<FolderClass> foldersUpdated = new ArrayList<FolderClass>();
        foldersUpdated.add(folderUpdated);
        when(folderClassService.add(anyListOf(FolderClass.class))).thenReturn(foldersUpdated);
        CreateRequest parameters = new CreateRequest();
        FolderClass folderClassToUpdate = FolderClassMockUtility.buildFolderClassContractManagement();
        parameters.getFolderClass().add(folderClassToUpdate);
        CreateResponse addResponse = sugarFolderClassServer.create(parameters, new TokenType());
        assertNotNull(addResponse);
        assertNotNull(addResponse.getFolderClass());
        assertFalse(addResponse.getFolderClass().isEmpty());
        assertNotNull(addResponse.getFolderClass().get(0));
        assertEquals(folderUpdated.getType(), addResponse.getFolderClass().get(0).getType());
    }

    @Test
    public void testGet() throws Exception {
        List<FolderClass> folderClassesFetched = new ArrayList<FolderClass>();
        folderClassesFetched.add(FolderClassMockUtility.buildFolderClassContractManagement());
        when(folderClassService.get(anyListOf(ClassId.class), anyString())).thenReturn(folderClassesFetched);

        GetRequest getRequest = new GetRequest();
        getRequest.setScope(SCOPE);
        getRequest.getClassId().add(FolderClassMockUtility.buildFolderClassId());
        GetResponse getResponse = sugarFolderClassServer.get(getRequest, new TokenType());
        assertNotNull(getResponse);
        assertNotNull(getResponse.getFolderClass());
        assertFalse(getResponse.getFolderClass().isEmpty());
        assertNotNull(getResponse.getFolderClass().get(0));
    }

    @Test
    public void testGetAll() throws Exception {
        List<FolderClass> folderClassesFetched = new ArrayList<FolderClass>();
        folderClassesFetched.add(FolderClassMockUtility.buildFolderClassContractManagement());
        when(folderClassService.getAll(anyString(), anyBoolean())).thenReturn(folderClassesFetched);

        GetAllRequest getRequest = new GetAllRequest();
        getRequest.setScope(SCOPE);
        GetAllResponse getResponse = sugarFolderClassServer.getAll(getRequest, new TokenType());
        assertNotNull(getResponse);
        assertNotNull(getResponse.getFolderClass());
        assertFalse(getResponse.getFolderClass().isEmpty());
        assertNotNull(getResponse.getFolderClass().get(0));
    }

    @Test
    public void testSearch() throws Exception {
        // TODO : To do !
    }

}
