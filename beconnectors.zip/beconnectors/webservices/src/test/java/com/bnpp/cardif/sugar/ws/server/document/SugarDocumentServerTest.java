package com.bnpp.cardif.sugar.ws.server.document;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.FindRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.FindResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.ReindexRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.ReindexResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.StoreRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.StoreResponse;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class SugarDocumentServerTest {
    private static final String SCOPE = "SYLDAVIA";

    @Mock
    private DocumentService documentService;

    @Mock
    private TokenValidator tokenValidator;

    @InjectMocks
    private SugarDocumentServer sugarDocumentServer = new SugarDocumentServer();

    @Before
    public void prepare() throws SugarTechnicalException, TechnicalException, FunctionalException {
        doNothing().when(tokenValidator).validate(any(TokenType.class));
    }

    @Test
    public void testStore()
            throws SugarTechnicalException, FuncFaultMessage, TechFaultMessage, SugarFunctionalException {
        StoreRequest request = new StoreRequest();
        request.getDocument().add(new Document());
        List<Document> storedDocument = new ArrayList<Document>();
        storedDocument.add(new Document());
        when(documentService.store(anyListOf(Document.class))).thenReturn(storedDocument);

        StoreResponse response = sugarDocumentServer.store(request, new TokenType());

        verify(documentService).store(request.getDocument());
        assertEquals(storedDocument, response.getDocument());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = TechFaultMessage.class)
    public void testStoreFailsFromCoreOnTechnicalError() throws Exception {
        when(documentService.store(anyListOf(Document.class))).thenThrow(SugarTechnicalException.class);
        sugarDocumentServer.store(mock(StoreRequest.class), new TokenType());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = FuncFaultMessage.class)
    public void testStoreFailsFromCoreOnFunctionalError() throws Exception {
        when(documentService.store(anyListOf(Document.class))).thenThrow(SugarFunctionalException.class);
        sugarDocumentServer.store(mock(StoreRequest.class), new TokenType());
    }

    @Test
    public void testGet() throws SugarFunctionalException, FuncFaultMessage, TechFaultMessage, SugarTechnicalException {
        Document document = DocumentMockUtil.buildClaimDocument();
        List<Document> listDocument = Lists.newArrayList(document);
        GetRequest request = new GetRequest();
        request.setIncludeChild(false);
        request.setScope(SCOPE);
        request.setIncludeFile(false);
        request.getId().add(document.getId());
        when(documentService.get(anyString(), anyListOf(Id.class), anyBoolean(), anyBoolean()))
                .thenReturn(listDocument);

        GetResponse response = sugarDocumentServer.get(request, new TokenType());

        verify(documentService).get(SCOPE, request.getId(), request.isIncludeChild(), request.isIncludeFile());
        assertEquals(1, response.getDocument().size());
        assertEquals(document.getId(), response.getDocument().get(0).getId());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = TechFaultMessage.class)
    public void testGetFailsFromTechFault() throws Exception {
        GetRequest getRequest = new GetRequest();
        when(documentService.get(anyString(), anyListOf(Id.class), anyBoolean(), anyBoolean()))
                .thenThrow(SugarTechnicalException.class);
        sugarDocumentServer.get(getRequest, new TokenType());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = FuncFaultMessage.class)
    public void testGetFailsFromFunctFault() throws Exception {
        GetRequest getRequest = new GetRequest();
        when(documentService.get(anyString(), anyListOf(Id.class), anyBoolean(), anyBoolean()))
                .thenThrow(SugarFunctionalException.class);
        sugarDocumentServer.get(getRequest, new TokenType());
    }

    @Test
    public void testFind() throws Exception {
        SearchResults<Document> results = new SearchResults<Document>();
        results.setResults(Lists.newArrayList(DocumentMockUtil.buildClaimDocument()));
        results.setFound(16);
        when(documentService.find(any(Criteria.class), any(OrderClause.class), anyLong(), anyLong()))
                .thenReturn(results);

        FindResponse response = sugarDocumentServer.find(mock(FindRequest.class), new TokenType());
        assertEquals(results.getObjects(), response.getDocument());
        assertEquals(results.getFound(), response.getFound());
    }

    @Test
    public void testReindex()
            throws SugarTechnicalException, FuncFaultMessage, TechFaultMessage, SugarFunctionalException {
        ReindexRequest request = new ReindexRequest();
        List<Document> updatedDocuments = new ArrayList<Document>();
        updatedDocuments.add(DocumentMockUtil.buildClaimDocument());
        request.getDocument().addAll(updatedDocuments);
        when(documentService.update(anyListOf(Document.class))).thenReturn(updatedDocuments);
        ReindexResponse response = sugarDocumentServer.reindex(request, new TokenType());

        verify(documentService).update(request.getDocument());
        assertEquals(updatedDocuments, response.getDocument());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = FuncFaultMessage.class)
    public void testReindexFailsFromFunctFault() throws Exception {
        ReindexRequest reindexRequest = new ReindexRequest();
        when(documentService.update(anyListOf(Document.class))).thenThrow(SugarFunctionalException.class);
        sugarDocumentServer.reindex(reindexRequest, new TokenType());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = TechFaultMessage.class)
    public void testReindexFailsFromTechFault() throws Exception {
        ReindexRequest reindexRequest = new ReindexRequest();

        when(documentService.update(anyListOf(Document.class))).thenThrow(SugarTechnicalException.class);
        sugarDocumentServer.reindex(reindexRequest, new TokenType());
    }

    @After
    public void tearDown() {
        reset(documentService);
    }
}
