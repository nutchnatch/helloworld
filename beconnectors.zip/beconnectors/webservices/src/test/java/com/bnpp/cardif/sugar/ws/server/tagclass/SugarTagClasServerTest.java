package com.bnpp.cardif.sugar.ws.server.tagclass;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.UpdateResponse;

@RunWith(MockitoJUnitRunner.class)
public class SugarTagClasServerTest {

    @Mock
    private TagclassService tagclassService;

    @Mock
    private TokenValidator tokenValidator;

    @InjectMocks
    private SugarTagclassServer sugarTagclassServer = new SugarTagclassServer();

    @Before
    public void prepare() throws SugarTechnicalException, TechnicalException, FunctionalException {
        doNothing().when(tokenValidator).validate(any(TokenType.class));
    }

    @Test
    public void testGetAll()
            throws FuncFaultMessage, TechFaultMessage, SugarTechnicalException, SugarFunctionalException {
        String scope = "Syldavia";

        GetAllRequest request = new GetAllRequest();
        request.setScope(scope);
        List<TagClass> tagclasses = new ArrayList<TagClass>();
        when(tagclassService.getAll(anyString())).thenReturn(tagclasses);
        GetAllResponse response = sugarTagclassServer.getAll(request, new TokenType());

        verify(tagclassService).getAll(request.getScope());
        assertNotNull(response.getTagClass());
    }

    @Test
    public void testGetBySymbolicName()
            throws TechFaultMessage, FuncFaultMessage, SugarTechnicalException, SugarFunctionalException {
        String scope = "Syldavia";
        GetBySymbolicNameRequest request = new GetBySymbolicNameRequest();
        request.setScope(scope);
        List<String> names = new ArrayList<String>();
        names.add("SymbolicName");
        request.getSymbolicNames().addAll(names);
        List<TagClass> tagclasses = new ArrayList<TagClass>();
        when(tagclassService.getBySymbolicName(anyString(), anyListOf(String.class), Mockito.anyBoolean()))
                .thenReturn(tagclasses);
        GetBySymbolicNameResponse response = sugarTagclassServer.getBySymbolicName(request, new TokenType());

        verify(tagclassService).getBySymbolicName(request.getScope(), request.getSymbolicNames(), true);
        assertNotNull(response.getTagClass());
    }

    @Test
    public void testGet() throws TechFaultMessage, FuncFaultMessage, SugarTechnicalException, SugarFunctionalException {
        String scope = "Syldavia";
        GetRequest request = new GetRequest();
        request.setScope(scope);
        List<ClassId> tagIds = new ArrayList<ClassId>();
        tagIds.add(new ClassId());
        request.getClassId().addAll(tagIds);
        List<TagClass> tagclasses = new ArrayList<TagClass>();
        when(tagclassService.get(anyString(), anyListOf(ClassId.class))).thenReturn(tagclasses);
        GetResponse response = sugarTagclassServer.get(request, new TokenType());

        verify(tagclassService).get(request.getScope(), request.getClassId());

        assertNotNull(response.getTagClass());
    }

    @Test
    public void testUpdate()
            throws TechFaultMessage, FuncFaultMessage, SugarTechnicalException, SugarFunctionalException {
        UpdateRequest request = new UpdateRequest();
        List<TagClass> tagclasses = new ArrayList<TagClass>();
        request.getTagClass().addAll(tagclasses);
        UpdateResponse response = sugarTagclassServer.update(request, new TokenType());
        verify(tagclassService).update(request.getTagClass());

        assertNotNull(response.getTagClass());
    }

    @Test
    public void testCreate()
            throws TechFaultMessage, FuncFaultMessage, SugarTechnicalException, SugarFunctionalException {
        CreateRequest request = new CreateRequest();
        List<TagClass> tagclasses = new ArrayList<TagClass>();

        request.getTagClass().addAll(tagclasses);
        CreateResponse response = sugarTagclassServer.create(request, new TokenType());

        verify(tagclassService).store(request.getTagClass());

        assertNotNull(response.getTagClass());
    }
}
