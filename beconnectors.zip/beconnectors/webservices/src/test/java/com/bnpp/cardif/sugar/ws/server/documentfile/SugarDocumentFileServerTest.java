package com.bnpp.cardif.sugar.ws.server.documentfile;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.GetResponse;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class SugarDocumentFileServerTest {
    @Mock
    private DocumentFileService documentFileService;

    @Mock
    private TokenValidator tokenValidator;

    @InjectMocks
    private SugarDocumentFileServer sugarDocumentFileServer = new SugarDocumentFileServer();

    @Before
    public void prepare() throws SugarTechnicalException, TechnicalException, FunctionalException {
        doNothing().when(tokenValidator).validate(any(TokenType.class));
    }

    @Test
    public void testAdd() throws FuncFaultMessage, TechFaultMessage, SugarTechnicalException, SugarFunctionalException {
        AddRequest request = new AddRequest();
        request.getDocumentFile().add(new DocumentFile());
        when(documentFileService.add(anyListOf(DocumentFile.class))).thenReturn(request.getDocumentFile());

        AddResponse response = sugarDocumentFileServer.add(request, new TokenType());

        verify(documentFileService).add(request.getDocumentFile());
        assertEquals(request.getDocumentFile(), response.getDocumentFile());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = TechFaultMessage.class)
    public void testAddFailsFromCore()
            throws FuncFaultMessage, TechFaultMessage, SugarTechnicalException, SugarFunctionalException {
        when(documentFileService.add(anyListOf(DocumentFile.class))).thenThrow(SugarTechnicalException.class);
        sugarDocumentFileServer.add(new AddRequest(), new TokenType());
    }

    @Test
    public void testGetOneDocumentFile()
            throws FuncFaultMessage, TechFaultMessage, SugarTechnicalException, SugarFunctionalException {

        URI uri = new URI();
        uri.setValue("My URI !!");
        String scope = "/SYLDAVIA";
        DocumentFile documentFile = new DocumentFile();
        documentFile.setScope(scope);

        List<URI> uris = Lists.newArrayList(uri);
        List<DocumentFile> addedDocumentFiles = Lists.newArrayList(documentFile);
        when(documentFileService.get(scope, uris)).thenReturn(addedDocumentFiles);

        GetRequest getRequest = new GetRequest();
        getRequest.setScope(scope);
        getRequest.getURI().add(uri);

        GetResponse getResponse = sugarDocumentFileServer.get(getRequest, new TokenType());
        assertEquals(addedDocumentFiles, getResponse.getDocumentFile());
        verify(documentFileService).get(scope, uris);
    }

    @SuppressWarnings("unchecked")
    @Test(expected = TechFaultMessage.class)
    public void testGetFailFromCore()
            throws FuncFaultMessage, TechFaultMessage, SugarTechnicalException, SugarFunctionalException {
        when(documentFileService.get(anyString(), anyListOf(URI.class))).thenThrow(SugarTechnicalException.class);
        sugarDocumentFileServer.get(mock(GetRequest.class), new TokenType());
    }
}
