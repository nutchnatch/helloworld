package com.bnpp.cardif.sugar.ws.server.documentclass;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchResponse;

@RunWith(MockitoJUnitRunner.class)
public class SugarDocumentClassServerTest {
    @Mock
    private DocumentClassService documentClassService;

    @Mock
    private TokenValidator tokenValidator;

    @InjectMocks
    private SugarDocumentClassServer sugarDocumentClassServer = new SugarDocumentClassServer();

    @Before
    public void prepare() throws SugarTechnicalException, TechnicalException, FunctionalException {
        doNothing().when(tokenValidator).validate(any(TokenType.class));
    }

    @Test
    public void testSearchOK() throws Exception {
        List<DocumentClass> listOfClasses = new ArrayList<DocumentClass>();
        listOfClasses.add(new DocumentClass());
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean())).thenReturn(listOfClasses);

        SearchRequest searchrequest = new SearchRequest();
        searchrequest.setActiveOnly(true);
        SearchResponse searchResponse = sugarDocumentClassServer.search(searchrequest, new TokenType());

        assertNotNull(searchResponse);
        assertNotNull(searchResponse.getDocumentClasses());
        assertNotNull(searchResponse.getDocumentClasses().getDocumentClass());
        assertFalse(searchResponse.getDocumentClasses().getDocumentClass().isEmpty());
    }

    @Test(expected = TechFaultMessage.class)
    public void testSearchKOTechFault() throws Exception {
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenThrow(new SugarTechnicalException(""));

        SearchRequest searchrequest = new SearchRequest();
        searchrequest.setActiveOnly(true);
        SearchResponse searchResponse = sugarDocumentClassServer.search(searchrequest, new TokenType());

        assertNotNull(searchResponse);
        assertNotNull(searchResponse.getDocumentClasses());
        assertNotNull(searchResponse.getDocumentClasses().getDocumentClass());
        assertFalse(searchResponse.getDocumentClasses().getDocumentClass().isEmpty());
    }

    @Test(expected = FuncFaultMessage.class)
    public void testSearchKOFuncFault() throws Exception {
        when(documentClassService.search(anyString(), any(Category.class), anyBoolean()))
                .thenThrow(new SugarFunctionalException("", null));

        SearchRequest searchrequest = new SearchRequest();
        searchrequest.setActiveOnly(true);
        SearchResponse searchResponse = sugarDocumentClassServer.search(searchrequest, new TokenType());

        assertNotNull(searchResponse);
        assertNotNull(searchResponse.getDocumentClasses());
        assertNotNull(searchResponse.getDocumentClasses().getDocumentClass());
        assertFalse(searchResponse.getDocumentClasses().getDocumentClass().isEmpty());
    }
}
