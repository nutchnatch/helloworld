package com.bnpp.cardif.sugar.ws.server.basket;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.basket.BasketService;
import com.bnpp.cardif.sugar.domain.basket.test.BasketMockUtility;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.UpdateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class SugarBasketServerTest {
    private static final String SCOPE = "Syldavia";

    @Mock
    private BasketService basketService;

    @Mock
    private TokenValidator tokenValidator;

    @InjectMocks
    private SugarBasketServer sugarBasketServer = new SugarBasketServer();

    @Before
    public void prepare() throws SugarTechnicalException, TechnicalException, FunctionalException {
        doNothing().when(tokenValidator).validate(any(TokenType.class));
    }

    @Test
    public void testGetAll()
            throws SugarTechnicalException, FuncFaultMessage, TechFaultMessage, SugarFunctionalException {
        GetAllRequest request = new GetAllRequest();
        request.setScope(SCOPE);
        Basket basket = new Basket();
        basket.setSymbolicName("Claim");
        basket.setBasketId(new BasketId());
        basket.getBasketId().setIssuer("CARDIF");
        basket.getBasketId().setValue("myID");
        basket.setScope(SCOPE);
        when(basketService.getAllUnfiltered(anyString())).thenReturn(Lists.newArrayList(basket));
        when(basketService.filterAllowedBasket(anyListOf(Basket.class))).thenReturn(Lists.newArrayList(basket));
        GetAllResponse response = sugarBasketServer.getAll(request, new TokenType());
        verify(basketService).getAllUnfiltered(request.getScope());
        assertFalse(response.getBasket().isEmpty());
    }

    @Test
    public void testCreate()
            throws SugarTechnicalException, FuncFaultMessage, TechFaultMessage, SugarFunctionalException {
        CreateRequest createRequest = new CreateRequest();
        ArrayList<Basket> listOfBasketToCreate = new ArrayList<Basket>();
        Basket basket = new Basket();
        basket.setSymbolicName("Claim");
        basket.setScope(SCOPE);
        listOfBasketToCreate.add(basket);
        createRequest.getBasket().addAll(listOfBasketToCreate);
        ArrayList<Basket> listOfBasketCreated = new ArrayList<Basket>();
        listOfBasketCreated.add(basket);
        listOfBasketCreated.get(0).setBasketId(new BasketId());
        when(basketService.create(anyListOf(Basket.class))).thenReturn(Lists.newArrayList(listOfBasketCreated));
        CreateResponse addResponse = sugarBasketServer.create(createRequest, new TokenType());
        verify(basketService).create(listOfBasketToCreate);
        assertNotNull(addResponse);
        assertNotNull(addResponse.getBasket());
        assertFalse(addResponse.getBasket().isEmpty());
        assertNotNull(addResponse.getBasket().get(0).getBasketId());
    }

    @Test
    public void testGet() throws Exception {
        List<Basket> fetchedFolders = new ArrayList<Basket>();
        fetchedFolders.add(BasketMockUtility.buildClaimBasket());
        when(basketService.get(anyListOf(BasketId.class), anyString())).thenReturn(fetchedFolders);

        GetRequest getRequest = new GetRequest();
        getRequest.setScope(SCOPE);
        GetResponse getResponse = sugarBasketServer.get(getRequest, new TokenType());

        verify(basketService).get(getRequest.getBasketId(), SCOPE);
        assertNotNull(getResponse);
        assertNotNull(getResponse.getBasket());
        assertNotNull(getResponse.getBasket().get(0));
        assertNotNull(getResponse.getBasket().get(0).getBasketId());
        assertNotNull(getResponse.getBasket().get(0).getSymbolicName());
    }

    @Test
    public void testUpdate()
            throws SugarTechnicalException, FuncFaultMessage, TechFaultMessage, SugarFunctionalException {
        UpdateRequest addRequest = new UpdateRequest();
        ArrayList<Basket> listOfBasketToUpdate = new ArrayList<Basket>();
        Basket basket = new Basket();
        basket.setBasketId(new BasketId());
        basket.getBasketId().setIssuer("CARDIF");
        basket.getBasketId().setValue("myID");
        basket.setSymbolicName("Claim");
        basket.setScope(SCOPE);
        listOfBasketToUpdate.add(basket);
        addRequest.getBasket().addAll(listOfBasketToUpdate);
        when(basketService.update(anyListOf(Basket.class))).thenReturn(Lists.newArrayList(listOfBasketToUpdate));
        UpdateResponse updateResponse = sugarBasketServer.update(addRequest, new TokenType());
        verify(basketService).update(listOfBasketToUpdate);
        assertNotNull(updateResponse);
        assertNotNull(updateResponse.getBasket());
        assertFalse(updateResponse.getBasket().isEmpty());
    }

    @Test
    public void testDelete()
            throws SugarTechnicalException, FuncFaultMessage, TechFaultMessage, SugarFunctionalException {
        DeleteRequest deleteRequest = new DeleteRequest();
        deleteRequest.setScope(SCOPE);
        ArrayList<BasketId> listOfBasketIdToDelete = new ArrayList<BasketId>();
        BasketId basketId = new BasketId();
        basketId.setIssuer("CARDIF");
        basketId.setValue("myID");
        listOfBasketIdToDelete.add(basketId);
        deleteRequest.getBasketId().addAll(listOfBasketIdToDelete);
        ArrayList<Boolean> listOfDeleted = new ArrayList<Boolean>();
        listOfDeleted.add(true);
        // when(basketService.delete(anyListOf(BasketId.class), anyString())
        // .thenReturn(Lists.newArrayList(listOfDeleted));
        DeleteResponse addResponse = sugarBasketServer.delete(deleteRequest, new TokenType());
        verify(basketService).delete(listOfBasketIdToDelete, SCOPE);
        assertNotNull(addResponse);
    }
}
