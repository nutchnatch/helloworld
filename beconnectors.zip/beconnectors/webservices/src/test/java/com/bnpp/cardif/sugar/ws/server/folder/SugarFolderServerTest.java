package com.bnpp.cardif.sugar.ws.server.folder;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sesame.security.soap.TokenValidator;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.folder.test.FolderMockUtility;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateResponse;

@RunWith(MockitoJUnitRunner.class)
public class SugarFolderServerTest {
    private static final String SCOPE = "SYLDAVIA";

    @Mock
    private FolderService folderService;

    @Mock
    private TokenValidator tokenValidator;

    @InjectMocks
    private SugarFolderServer sugarFolderServer = new SugarFolderServer();

    @Before
    public void prepare() throws SugarTechnicalException, TechnicalException, FunctionalException {
        doNothing().when(tokenValidator).validate(any(TokenType.class));
    }

    @Test
    public void testAdd() throws Exception {
        List<Folder> storedFolders = new ArrayList<Folder>();
        storedFolders.add(new Folder());
        when(folderService.add(anyListOf(Folder.class))).thenReturn(storedFolders);

        CreateRequest addRequest = new CreateRequest();
        CreateResponse addResponse = sugarFolderServer.create(addRequest, new TokenType());

        verify(folderService).add(addRequest.getFolder());
        assertNotNull(addResponse);
    }

    @SuppressWarnings("unchecked")
    @Test(expected = TechFaultMessage.class)
    public void testAddFailsFromCoreOnTechnicalError() throws Exception {
        when(folderService.add(anyListOf(Folder.class))).thenThrow(SugarTechnicalException.class);
        sugarFolderServer.create(mock(CreateRequest.class), new TokenType());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = FuncFaultMessage.class)
    public void testAddFailsFromCoreOnFunctionalError() throws Exception {
        when(folderService.add(anyListOf(Folder.class))).thenThrow(SugarFunctionalException.class);
        sugarFolderServer.create(mock(CreateRequest.class), new TokenType());
    }

    @Test
    public void testUpdate() throws Exception {
        List<Folder> updatedFolders = new ArrayList<Folder>();
        updatedFolders.add(FolderMockUtility.buildClaimFolder(1));
        when(folderService.update(anyListOf(Folder.class), anyString())).thenReturn(updatedFolders);

        UpdateRequest updateRequest = new UpdateRequest();
        updateRequest.getFolder().addAll(updatedFolders);
        UpdateResponse updateResponse = sugarFolderServer.update(updateRequest, new TokenType());

        List<Folder> folderToUpdate = updateRequest.getFolder();
        verify(folderService).update(folderToUpdate, "Syldavia");
        assertNotNull(updateResponse);
        assertNotNull(updateResponse.getFolder());
        assertNotNull(updateResponse.getFolder().get(0));
        assertNotNull(updateResponse.getFolder().get(0).getData());
        assertNotNull(updateResponse.getFolder().get(0).getData().getUpdtDate());
    }

    @Ignore
    @SuppressWarnings("unchecked")
    @Test(expected = TechFaultMessage.class)
    public void testUpdateFailsFromCoreOnTechnicalError() throws Exception {
        when(folderService.update(anyListOf(Folder.class), anyString())).thenThrow(SugarTechnicalException.class);
        sugarFolderServer.update(mock(UpdateRequest.class), new TokenType());
    }

    @Ignore
    @SuppressWarnings("unchecked")
    @Test(expected = FuncFaultMessage.class)
    public void testupdateFailsFromCoreOnFunctionalError() throws Exception {
        when(folderService.update(anyListOf(Folder.class), anyString())).thenThrow(SugarFunctionalException.class);
        sugarFolderServer.update(mock(UpdateRequest.class), new TokenType());
    }

    @Test
    public void testGet() throws Exception {
        List<Folder> getFolders = new ArrayList<Folder>();
        getFolders.add(FolderMockUtility.buildClaimFolder(1));
        when(folderService.get(anyListOf(FolderId.class), anyString())).thenReturn(getFolders);

        GetRequest getRequest = new GetRequest();
        getRequest.setScope(SCOPE);
        GetResponse getResponse = sugarFolderServer.get(getRequest, new TokenType());

        verify(folderService).get(getRequest.getFolderId(), SCOPE);
        assertNotNull(getResponse);
        assertNotNull(getResponse.getFolder());
        assertNotNull(getResponse.getFolder().get(0));
        assertNotNull(getResponse.getFolder().get(0).getData());
        assertNotNull(getResponse.getFolder().get(0).getFolderId());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = TechFaultMessage.class)
    public void testGetFailsFromCoreOnTechnicalError() throws Exception {
        when(folderService.get(anyListOf(FolderId.class), anyString())).thenThrow(SugarTechnicalException.class);
        sugarFolderServer.get(mock(GetRequest.class), new TokenType());
    }

    @SuppressWarnings("unchecked")
    @Test(expected = FuncFaultMessage.class)
    public void testGetFailsFromCoreOnFunctionalError() throws Exception {
        when(folderService.get(anyListOf(FolderId.class), anyString())).thenThrow(SugarFunctionalException.class);
        sugarFolderServer.get(mock(GetRequest.class), new TokenType());
    }
}
