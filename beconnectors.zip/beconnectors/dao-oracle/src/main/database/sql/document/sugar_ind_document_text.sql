-- set timing on

-- /*
-- SUGAR DOCUMENTS INDEXATION SCRIPTS
-- 2014-12  BNPAPRIBAS CARDIF

-- reminder :
-- alter table DOCUMENTS add UPDATEDATE DATE;
-- update documents set UPDATEDATE=SYSDATE;
-- alter table DOCUMENTS modify UPDATEDATE not null;

-- */


-- /**

-- SUGAR DATASTORE

-- One specific procedure to do the filtering indexing ... this is mandatory to
--> remove useless tag from indexing (Id & ChildObject)  (PErformance and useless expansion of wordlist)
--> create specific "attribute" for number and date tag to allow search using > & < operator

-- INVERTED INDEX SYSTEM AND METHOD FOR NUMERIC ATTRIBUTES
-- */
begin
  begin
    ctx_ddl.drop_preference('${USR_META}.sugar_datastore');
    exception
       when others then
          null;
   end;
  --ctx_ddl.create_preference('${USR_META}.sugar_datastore','DIRECT_DATASTORE');
  ctx_ddl.create_preference('${USR_META}.sugar_datastore','USER_DATASTORE');
  ctx_ddl.set_attribute('${USR_META}.sugar_datastore', 'procedure', '${USR_META}.PKG_DOCUMENT.DOFILTERINDRDOC'); 
  ctx_ddl.set_attribute('${USR_META}.sugar_datastore', 'output_type', 'CLOB_LOC');
end;
/



-- /**
-- USELESS

-- !!! NOT MORE USED ... USER_DATASTORE INSTEAS
-- SUGAR FILTER
-- One specific procedure to do the iltering indexing ... this is mandatory to
--> remove useless tag from indexing (Id & ChildObject)  (PErformance and useless expansion of wordlist)
--> create specific "attribute" for number and date tag to allow search using > & < operator

-- INVERTED INDEX SYSTEM AND METHOD FOR NUMERIC ATTRIBUTES

-- */
begin
  begin
    ctx_ddl.drop_preference('sugar_filter');
    exception
       when others then
          null;
   end;
-- /*ctx_ddl.create_preference('sugar_filter', 'procedure_filter');
-- ctx_ddl.set_attribute('sugar_filter', 'procedure', '${USR_META}.PKG_INDEX_DOCUMENT.FILTER');
-- ctx_ddl.set_attribute('sugar_filter', 'input_type', 'clob');
-- ctx_ddl.set_attribute('sugar_filter', 'output_type', 'clob');
-- ctx_ddl.set_attribute('sugar_filter', 'rowid_parameter', 'TRUE');
-- ctx_ddl.set_attribute('sugar_filter', 'charset_parameter', 'TRUE');*/
end;
/


-- /**

-- SUGAR STORAGE

--> BIG_IO and SEPERATE_OFFSETS TO AVOID HUGE WORDLIST.... 
--> compression of IX index.


-- */
begin
 begin
    ctx_ddl.drop_preference('${USR_META}.sugar_storage');
    exception
       when others then
          null;
   end;
 ctx_ddl.create_preference('${USR_META}.sugar_storage','BASIC_STORAGE');
 
 -- TO BE DONE : must isolate INDEX from USERS tablespace
 ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'I_TABLE_CLAUSE', 'tablespace "${META_TABLESPACE_INDEX}" storage (initial 20M next 20M PCTINCREASE 50  buffer_pool keep) '); 
 ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'K_TABLE_CLAUSE', 'tablespace "${META_TABLESPACE_INDEX}" storage (initial 5M next   5M PCTINCREASE 50  )  '); 
 ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'R_TABLE_CLAUSE', 'tablespace "${META_TABLESPACE_INDEX}" storage (initial 5M  next  5M PCTINCREASE 50  ) '); 
 ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'N_TABLE_CLAUSE', 'tablespace "${META_TABLESPACE_INDEX}" storage (initial 5M  next  5M PCTINCREASE 50  ) '); 
 ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'I_INDEX_CLAUSE', 'tablespace "${META_TABLESPACE_INDEX}" storage (initial 20M next 20M PCTINCREASE 50   buffer_pool keep)  compress 2'); 
 ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'P_TABLE_CLAUSE', 'tablespace "${META_TABLESPACE_INDEX}" storage (initial 5M  next  5M PCTINCREASE 50  ) '); 
 -- to be challenge...
 ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'BIG_IO', 'YES');
 ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'SEPARATE_OFFSETS', 'YES');

 -- is compatible with transactionnal ?
ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'STAGE_ITAB', 'YES');
ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'G_TABLE_CLAUSE', 'storage (initial 20M next 20M PCTINCREASE 50 buffer_pool keep)' );
ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'G_INDEX_CLAUSE', 'storage (initial 20M next 20M PCTINCREASE 50 buffer_pool keep)');
-- for Oracle 12.2 compatibility
ctx_ddl.set_attribute('${USR_META}.sugar_storage', 'STAGE_ITAB_MAX_ROWS', '0');
end;
/

-- /**

-- SUGAR WORDLIST

--> PREFIX_INDEX to allow quic search using % feature 



-- */
begin 
 begin
    ctx_ddl.drop_preference('${USR_META}.sugar_wordlist');
    exception
       when others then
          null;
   end;
ctx_ddl.create_preference('${USR_META}.sugar_wordlist', 'BASIC_WORDLIST'); 
ctx_ddl.set_attribute('${USR_META}.sugar_wordlist','PREFIX_INDEX','TRUE');
ctx_ddl.set_attribute('${USR_META}.sugar_wordlist','PREFIX_MIN_LENGTH',2);
ctx_ddl.set_attribute('${USR_META}.sugar_wordlist','PREFIX_MAX_LENGTH', 3);
ctx_ddl.set_attribute('${USR_META}.sugar_wordlist','SUBSTRING_INDEX', 'YES');
end;
/

-- /**

-- SUGAR LEXER

--> PREFIX_INDEX to allow quic search using % feature 



-- */
begin
  begin
    ctx_ddl.drop_preference('${USR_META}.sugar_lexer');
    exception
       when others then
          null;
   end;
ctx_ddl.create_preference('${USR_META}.sugar_lexer', 'BASIC_LEXER');
ctx_ddl.set_attribute( '${USR_META}.sugar_lexer', 'BASE_LETTER', 'true' );
ctx_ddl.set_attribute( '${USR_META}.sugar_lexer', 'printjoins', '_-');
ctx_ddl.set_attribute( '${USR_META}.sugar_lexer', 'index_themes', 'NO');
ctx_ddl.set_attribute( '${USR_META}.sugar_lexer', 'index_text', 'YES'); 
ctx_ddl.set_attribute( '${USR_META}.sugar_lexer', 'index_stems', '0');

end;
/


-- /**

-- SUGAR SECTION GROUP

--> PATH_SECTION_GROUP - for tag xml query 



-- */ 
begin
begin
    ctx_ddl.drop_section_group('${USR_META}.sugar_section_group');
    exception
       when others then
          null;
   end;
  CTX_DDL.create_section_group('${USR_META}.sugar_section_group', 'PATH_SECTION_GROUP');
  --CTX_DDL.add_sdata_section('${USR_META}.sugar_section_group','UpdtDate','common:UpdtDate','VARCHAR2'); 
  --  a utiliser si champ formater en 2014-09-03 14:25:18
  --- not usefull and only available in Oracle 12c
  -- CTX_DDL.add_sdata_section('${USR_META}.sugar_section_group','UpdtDate','common:UpdtDate','DATE');   
   --CTX_DDL.add_stop_section('${USR_META}.sugar_section_group','doc:Id');
   
  
end;
/

-- stoplist so far is empty (how manage language ?)
begin
begin
    ctx_ddl.drop_stoplist('${USR_META}.sugar_stoplist');
    exception
       when others then
          null;
   end;
  CTX_DDL.create_stoplist('${USR_META}.sugar_stoplist');  
  
end;
/

-- drop index documents_idx_otext force 
-- /


-- index creation
-- note : transactional --> avoid fragmentation of $I table link to sync mechanism
--                          a temporary table is created to accept nex record and is flush each synch process ( every 30 minutes)
create index ${USR_META}.documents_idx_otext on ${USR_META}.documents (XML_CONTENT) 
  indextype is ctxsys.context 
  --  to add if partition enable
  --local
  filter  by UPDATEDATE 
   order by UPDATEDATE DESC
               parameters ('
               DATASTORE ${USR_META}.sugar_datastore 
               STORAGE ${USR_META}.sugar_storage
               WORDLIST ${USR_META}.sugar_wordlist
               SECTION GROUP ${USR_META}.sugar_section_group
               LEXER ${USR_META}.sugar_lexer               
               STOPLIST ${USR_META}.sugar_stoplist               
               memory 128m      
               sync (on commit) ')                              
               parallel 4
/

	call  CTX_DDL.ADD_AUTO_OPTIMIZE('${USR_META}.documents_idx_otext')
/

-- /* following should be used in case of partitioned database 
-- exec ctx_ddl.add_auto_optimize( 'documents_idx_otext','pSylvadia' );
-- exec ctx_ddl.add_auto_optimize( 'documents_idx_otext','pDemo' );
-- exec ctx_ddl.add_auto_optimize( 'documents_idx_otext','pGopal' );

-- exec ctx_ddl.remove_auto_optimize( 'documents_idx_otext','pGopal' );
-- exec ctx_ddl.remove_auto_optimize( 'documents_idx_otext','pDemo' );
-- exec ctx_ddl.remove_auto_optimize( 'documents_idx_otext','pSylvadia' );
-- */

-- begin
   -- dbms_stats.gather_table_stats (
      -- ownname    => USER,
      -- tabname    => 'DOCUMENTS',
      -- method_opt => 'for all columns'   ); 
-- end; 


-- /*
-- begin
   -- dbms_stats.delete_table_stats (
      -- ownname    => USER,
      -- tabname    => 'DOCUMENTS'  ); 
-- end; 
-- /
-- */
