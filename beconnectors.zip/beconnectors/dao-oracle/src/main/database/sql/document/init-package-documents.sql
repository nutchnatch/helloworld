CREATE OR REPLACE PACKAGE ${USR_META}.PKG_DOCUMENT
IS

  
    -- 2014  -  SUGAR PROJECT
    -- V1.1
    -- BNPPARIBAS CARDIF
    
    -- PACKAGE FOR DOCUMENT MANAGMENT
    
    -- DDL DOCUMENT MANAGEMENT 
    -- SEARCH DOCUMENT ENGINE
  


  DOCUMENT_NS CONSTANT VARCHAR2(800):=
  'xmlns="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1" xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1"';
  NOT_DELETED_CRITERIA CONSTANT VARCHAR2(800) :=     '  ( HASPATH   (doc:Document/doc:Status/common:Code!="DELETED") ) '  ;
  SCOPE_CRITERIA_S CONSTANT VARCHAR2(800) :=     '  ( HASPATH   (doc:Document/@Scope="'  ;
  SCOPE_CRITERIA_E CONSTANT VARCHAR2(800) :=     '") ) '  ;
  
  
  DEFAULT_DOCUMENT_TABLE CONSTANT VARCHAR2(800) :=  'documents';
  -- oracle context index name
  -- need for hint optimization over 5.000.000 records....
  DEFAULT_DOCUMENT_INDEX CONSTANT VARCHAR2(800) :=  'documents_idx_otext';
  

  ORDER_BY_CLAUSE_NS CONSTANT VARCHAR2(800):='  declare namespace doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1"; (: :)
                                       declare namespace common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"; (: :) ';   


 
 
      
        -- EXECUTE a SEARCH of documents based on a specific xml query
      
    -- <?xml version="1.0"?>
    -- <query  pageStart="1" pageSize="62" maxLimitSearch="2000" lang="FRENCH">
      -- <filter logicalOperator="AND">    
                -- <filter>
                  -- <path>/doc:Document/common:Tags</path>
                  -- <operator>=</operator>
                  -- <operand type="string">BA%</operand>    
            -- </filter>            
      
           -- <filter>
                  -- <path>/doc:Document/common:Tags/common:Tag[@name="ExpireDate"]</path>
                  -- <operator>></operator>
                  -- <operand type="date">2014-01-01</operand>    
            -- </filter>            
      
      -- </filter>
      
      -- <order>
        -- <orderKey>score desc</orderKey>
        -- <orderKey>/doc:Document/common:Tags/common:Tag[@name="LastName"]</orderKey>
      -- </order>
-- </query>

  PROCEDURE find(
    p_request  in varchar2 default null, 
-- request (XML)
    pout_documentCursor OUT SYS_REFCURSOR,  
-- cursor out 
    pout_resultCount OUT NUMBER,               
										-- OUT nb count find
   
    p_traceLevel integer default 0 ,     
											-- trace level
                                          -- /* usage : if >0 then dbms_output.put_line is used 
                                                     -- if <0 then db table  SUGARDBLOG is used  
                                                    -- if =0 no trace is provided (even in case of exception ....)
                                                    
                                                    -- if abs( p_traceLevel) =1 --> only exception are logged
                                                    -- if abs( p_traceLevel) =2 -->  exception and info are logged
                                                    -- if abs( p_traceLevel) =3 -->  exception , inf, debug o are logged */
     p_requestId  in varchar2 default null 
											-- request ID .. any token text (likee UUID).. if null, a random new one is created
                                          -- /* for JAVA USAGE.. provide any identifier that can be relevant to share with Oracle Procedure 
                                             -- for trace in db trace table (SUGARDBLOG)
                                          -- */
                                       
   );       
   
 
 -- /*** ********************************
  -- CRUD OPERATIONS
 -- ***********************************/
 
  PROCEDURE store(
      p_DOCUMENTS IN ${USR_APP}.ClobArray,
    p_traceLevel integer default 0  );
  
   PROCEDURE store_single(
      p_DOCUMENT IN Clob,
    p_traceLevel integer default 0  );  
    
  PROCEDURE GET(
      p_scope     IN VARCHAR2,
      DocumentIds IN ${USR_APP}.VarcharArray,
      DocumentsFetched OUT SYS_refcursor,
    p_traceLevel integer default 0  ) ;
 
  PROCEDURE UPDATE_DOC(
      documentsToStore IN ${USR_APP}.ClobArray ,
    p_traceLevel integer default 0  );
 
    
  PROCEDURE UPDATE_DOC_SINGLE(
      documentToStore IN Clob ,
    p_traceLevel integer default 0  );
    
  PROCEDURE DELETE_DOC(
      p_scope     IN VARCHAR2,
      DocumentIds IN ${USR_APP}.VarcharArray,
    p_traceLevel integer default 0  ) ;
  
  
    -- /**
  
  -- get a xml for indexing based on therowid of a document
  
  -- (FUNCTION USED BY ORACLE  INDEXER BY  USER_DATATSTORE parameter)
  
  -- **/
  procedure doFilterIndrDoc(DocRowid IN ROWID,  xmlIndex  IN OUT NOCOPY CLOB) ;
 
END PKG_DOCUMENT; 
/

CREATE OR REPLACE PACKAGE body ${USR_META}.PKG_DOCUMENT
IS



-- /********************************************************************************************************************************
 -- EXECUTE a SEARCH of documents based on a specific xml query
      
    -- <?xml version="1.0"?>
    -- <query  pageStart="1" pageSize="62" maxLimitSearch="2000" lang="FRENCH">
      -- <filter logicalOperator="AND">    
                -- <filter>
                  -- <path>/doc:Document/common:Tags</path>
                  -- <operator>=</operator>
                  -- <operand type="string">BA%</operand>    
            -- </filter>            
      
           -- <filter>
                  -- <path>/doc:Document/common:Tags/common:Tag[@name="ExpireDate"]/common:Value</path>
                  -- <operator>></operator>
                  -- <operand type="date">2014-01-01</operand>    
            -- </filter>            
      
      -- </filter>
      
      -- <order>
       -- <!-- use xpath expression combined or not with structured field, comma separated.
                                           -- /* Usage : you can mix both xpath and  strutured column..  provide also scoring order
                                                -- sample 1 : '/doc:Document/common:Tags/common:Tag[@name="Firstname"]/common:Value asc, 
                                                      -- /doc:Document/common:Tags/common:Tag[@name="Lastname"]/common:Value desc, 
                                                      -- updatedate desc'
                                                      
                                                -- sample 2: score desc,   updatedate desc  -->
        -- <orderKey>score desc</orderKey>
        -- <orderKey>/doc:Document/common:Tags/common:Tag[@name="LastName"]</orderKey>
      -- </order>
-- </query>
-- *****************************************************************************************************************************************/
 PROCEDURE find(
    p_request  in varchar2 default null, 
-- request (xml)
    pout_documentCursor OUT SYS_REFCURSOR,  
-- cursor out 
    pout_resultCount OUT NUMBER,               
-- OUT nb count find
   
    p_traceLevel integer default 0 ,    
		-- trace level
                                          -- /* usage : if >0 then dbms_output.put_line is used 
                                                     -- if <0 then db table  SUGARDBLOG is used  
                                                    -- if =0 no trace is provided (even in case of exception ....)
                                                    
                                                    -- if abs( p_traceLevel) =1 --> only exception are logged
                                                    -- if abs( p_traceLevel) =2 -->  exception and info are logged
                                                    -- if abs( p_traceLevel) =3 -->  exception , inf, debug o are logged */
     p_requestId  in varchar2 default null   
	 --request ID .. any token text (like UUID).. if null, a random new one is created
                                          -- /* for JAVA USAGE.. provide any identifier that can be relevant to share with Oracle Procedure 
                                             -- for trace in db trace table (SUGARDBLOG)
                                          -- */
                                     
   ) is
   
     lrequestId varchar2(80);
     
     lstartRequest timestamp;
    
     docRequest     DBMS_XMLDOM.DOMDocument;
     docelemRequest DBMS_XMLDOM.DOMElement;
     nodelist      DBMS_XMLDOM.DOMNodeList;
     node   DBMS_XMLDOM.DOMNode;
    
     lpagestart      INTEGER;            
     lpagesize       INTEGER;
     lmaxLimitSearch INTEGER;
     llang           VARCHAR2(80);
     lscope          VARCHAR2(80);
     lfilter         VARCHAR2(16000);
     lorder          VARCHAR2(16000);
     lfilterSpecific varchar2(16000);
     
  begin
      
      -- record the current timestamp for tracking performance
      lstartRequest := current_timestamp;
      
      -- create a new request if not provided for track log follow      
      if (p_requestId is null) then 
        lrequestId :=dbms_random.string('X',32);
      else
        lrequestId := p_requestId;
      END IF;  
      
      ${USR_META}.PKG_TOOLS.traceLog(lrequestId,p_traceLevel,2, '> start search documents with request id '||lrequestId||(CASE when (p_traceLevel>=3) then ' : '||p_request else '' end));
      
      -- parseXML  and
      -- Create DOMDocument handle
      docRequest     := DBMS_XMLDOM.newDOMDocument(p_request); 
      docelemRequest := DBMS_XMLDOM.getDocumentElement(docRequest);
      
      --1) find attributes
      --   ***************
      lpagestart :=${USR_META}.PKG_TOOLS.getIntAttrValue(docelemRequest,'pageStart',1);
      lpagesize :=${USR_META}.PKG_TOOLS.getIntAttrValue(docelemRequest,'pageSize',10);
      lmaxLimitSearch :=${USR_META}.PKG_TOOLS.getIntAttrValue(docelemRequest,'maxLimitSearch',1000);
      lscope :=${USR_META}.PKG_TOOLS.getStrAttrValue(docelemRequest,'scope',null);
      
      -- lang :  can be usefull for stemming or soundex search ?? 
      llang :=${USR_META}.PKG_TOOLS.getStrAttrValue(docelemRequest,'lang','ENGLISH');
      
      -- 2) add  CONSTANT CRITERIA to filter : NOT DELETED and SCOPE 
      -- ***********************************************************     
      lfilter:=NOT_DELETED_CRITERIA;
      if (lscope is not null) then
          lfilter:=lfilter || 'AND '||SCOPE_CRITERIA_S||lscope||SCOPE_CRITERIA_E;
      end if;
      
      -- 3) find  filter tag to start recursivly to find specifc sub-filter.
      -- ***********************************************************     
      --get specific filters from request
      lfilterSpecific:=${USR_META}.PKG_TOOLS.getFilter(docelemRequest);
      if (lfilterSpecific is not null) then
          lfilter:=lfilter || 'AND '||lfilterSpecific;
      end if;
      
          
      -- 4) order element
      -- ****************          
      lorder:= ${USR_META}.PKG_TOOLS.getOrder(docelemRequest,ORDER_BY_CLAUSE_NS);    
        
      -- 5) LET'S GO DO THE SEARCH !
      -- ***************************
      ${USR_META}.PKG_TOOLS.searchOject( lscope,lpagestart,lpagesize,lfilter,lorder,lmaxLimitSearch,pout_documentCursor,pout_resultCount,llang,lrequestId,p_traceLevel,DEFAULT_DOCUMENT_TABLE,DEFAULT_DOCUMENT_INDEX);
  
      -- don't forget to free the dom...
      DBMS_XMLDOM.freedocument(docRequest);
     ${USR_META}.PKG_TOOLS.traceLog( lrequestId,p_traceLevel,2,'< end search documents ('|| pout_resultCount ||' found) in ' ||(current_timestamp - lstartRequest) ||' ms ');     

  
  end;


-- /********************************
  -- STORE a set of document  (XML)
-- *********************************/
PROCEDURE store(
    p_DOCUMENTS IN ${USR_APP}.ClobArray,
    p_traceLevel integer default 0  )
AS
  l_xml      XMLType;
  l_scope    VARCHAR2(80);
  l_idValue  VARCHAR2(36);
  l_idScheme VARCHAR2(80);
  l_idIssuer VARCHAR2(80);
BEGIN

  
  FOR elem IN 1 .. p_DOCUMENTS.count  LOOP
    l_xml      := XMLType(p_DOCUMENTS(elem));
    
    -- denormalization column for performance enhancement
    l_scope    := l_xml.extract('/doc:Document/@Scope',DOCUMENT_NS).getStringVal();
    
    l_idValue :=  l_xml.extract('/doc:Document/doc:Id/text()',DOCUMENT_NS).getStringVal();
    l_idScheme := l_xml.extract('/doc:Document/doc:Id/@Scheme',DOCUMENT_NS).getStringVal();
    l_idIssuer := l_xml.extract('/doc:Document/doc:Id/@Issuer',DOCUMENT_NS).getStringVal();
    
    ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'store new document  ('||l_Scope||'/'||l_idValue||'/'||l_idScheme||'/'||l_idIssuer);
    INSERT   INTO DOCUMENTS        (        SCOPE,        ID_VALUE,        ID_SCHEME,        ID_ISSUER,        XML_CONTENT,        UPDATEDATE       )
               VALUES              (        l_Scope,      l_idValue,       l_idScheme,       l_idIssuer,       l_xml,              SYSDATE      );
  END LOOP;
END;

PROCEDURE store_single(
    p_DOCUMENT IN Clob,
    p_traceLevel integer default 0  )
AS
  l_xml      XMLType;
  l_scope    VARCHAR2(80);
  l_idValue  VARCHAR2(36);
  l_idScheme VARCHAR2(80);
  l_idIssuer VARCHAR2(80);
BEGIN

  
    l_xml      := XMLType(p_DOCUMENT);
    
    -- denormalization column for performance enhancement
    l_scope    := l_xml.extract('/doc:Document/@Scope',DOCUMENT_NS).getStringVal();
    
    l_idValue :=  l_xml.extract('/doc:Document/doc:Id/text()',DOCUMENT_NS).getStringVal();
    l_idScheme := l_xml.extract('/doc:Document/doc:Id/@Scheme',DOCUMENT_NS).getStringVal();
    l_idIssuer := l_xml.extract('/doc:Document/doc:Id/@Issuer',DOCUMENT_NS).getStringVal();
    
    ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'store new document  ('||l_Scope||'/'||l_idValue||'/'||l_idScheme||'/'||l_idIssuer);
    INSERT   INTO DOCUMENTS        (        SCOPE,        ID_VALUE,        ID_SCHEME,        ID_ISSUER,        XML_CONTENT,        UPDATEDATE       )
               VALUES              (        l_Scope,      l_idValue,       l_idScheme,       l_idIssuer,       l_xml,              SYSDATE      );

END;

-- /**************************************
  -- GET a set of document  (XML) by  ID
-- **************************************/
PROCEDURE GET(
    p_scope     IN VARCHAR2,
    DocumentIds IN ${USR_APP}.VarcharArray,
    DocumentsFetched OUT SYS_refcursor,
    p_traceLevel integer default 0    )
AS
id XMLType;

BEGIN
  ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'get document  ('||p_scope||')');
  OPEN DocumentsFetched FOR SELECT /*+INDEX(t document_pk)*/ t.XML_CONTENT.getClobVal() FROM documents t WHERE
  (ID_VALUE,ID_SCHEME,ID_ISSUER) IN
  (
    SELECT
       extractValue(XMLType(column_value),'/doc:Id', DOCUMENT_NS ),
       extractValue(XMLType(column_value),'/doc:Id/@Scheme', DOCUMENT_NS ),
       extractValue(XMLType(column_value),'/doc:Id/@Issuer', DOCUMENT_NS )
    FROM
      TABLE(documentids)
  )
  AND p_scope=t.SCOPE 
  AND 
  (
    extract(XML_CONTENT , '/doc:Document/doc:Status/common:Code/text()' ,
    'xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"'
    ).getStringVal()!='DELETED' OR existsnode(XML_CONTENT , '/doc:Document/doc:Status/common:Code' ,
    'xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"'
    )=0
  )
  ;
END GET;


-- /**************************************
  -- UPDATE a set of document  (XML) 
-- **************************************/
PROCEDURE UPDATE_DOC(
    documentsToStore IN ${USR_APP}.ClobArray ,
    p_traceLevel integer default 0  )
AS
  
  l_xml      XMLType;
  l_scope    VARCHAR2(80);
  l_idValue  VARCHAR2(36);
  l_idScheme VARCHAR2(80);
  l_idIssuer VARCHAR2(80);
BEGIN
  FOR i IN 1 .. documentsToStore.count
  LOOP
    l_xml := XMLType(documentstostore(i));
    l_scope    := l_xml.extract('/doc:Document/@Scope',DOCUMENT_NS).getStringVal();
    l_idValue :=  l_xml.extract('/doc:Document/doc:Id/text()',DOCUMENT_NS).getStringVal();
    l_idScheme := l_xml.extract('/doc:Document/doc:Id/@Scheme',DOCUMENT_NS).getStringVal();
    l_idIssuer := l_xml.extract('/doc:Document/doc:Id/@Issuer',DOCUMENT_NS).getStringVal();
    
    
     ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'update document  ('||l_Scope||'/'||l_idValue||'/'||l_idScheme||'/'||l_idIssuer);
    UPDATE /*+INDEX(t document_pk)*/ documents t
      SET
        XML_CONTENT=l_xml,
        UPDATEDATE=SYSDATE
      WHERE t.ID_VALUE = l_idValue
      AND t.ID_SCHEME =  l_idScheme
      AND t.ID_ISSUER = l_idIssuer
      AND t.SCOPE = l_scope;

  END LOOP ;
END UPDATE_DOC;

-- /**************************************
  -- UPDATE a set of document  (XML) 
-- **************************************/
PROCEDURE UPDATE_DOC_SINGLE(
    documentToStore IN Clob,
    p_traceLevel integer default 0  )
AS
  
  l_xml      XMLType;
  l_scope    VARCHAR2(80);
  l_idValue  VARCHAR2(36);
  l_idScheme VARCHAR2(80);
  l_idIssuer VARCHAR2(80);
BEGIN
    l_xml := XMLType(documentToStore);
    l_scope    := l_xml.extract('/doc:Document/@Scope',DOCUMENT_NS).getStringVal();
    l_idValue :=  l_xml.extract('/doc:Document/doc:Id/text()',DOCUMENT_NS).getStringVal();
    l_idScheme := l_xml.extract('/doc:Document/doc:Id/@Scheme',DOCUMENT_NS).getStringVal();
    l_idIssuer := l_xml.extract('/doc:Document/doc:Id/@Issuer',DOCUMENT_NS).getStringVal();
    
    
     ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'update document  ('||l_Scope||'/'||l_idValue||'/'||l_idScheme||'/'||l_idIssuer);
    UPDATE /*+INDEX(t document_pk)*/ documents t
      SET
        XML_CONTENT=l_xml,
        UPDATEDATE=SYSDATE
      WHERE t.ID_VALUE = l_idValue
      AND t.ID_SCHEME =  l_idScheme
      AND t.ID_ISSUER = l_idIssuer
      AND t.SCOPE = l_scope;

END UPDATE_DOC_SINGLE;

-- /**************************************
  -- DELETE a set of document  (XML) 
-- **************************************/

PROCEDURE DELETE_DOC(
    p_scope     IN VARCHAR2,
    DocumentIds IN ${USR_APP}.VarcharArray  ,
    p_traceLevel integer default 0 )
AS
BEGIN

 ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,1, 'delete document  ('||p_scope||')');
 
  DELETE
  FROM
    documents t
  WHERE
  (ID_VALUE,ID_SCHEME,ID_ISSUER) IN
  (
    SELECT
      extractValue(XMLType(column_value),'/doc:Id', DOCUMENT_NS ),
      extractValue(XMLType(column_value),'/doc:Id/@Scheme', DOCUMENT_NS ),
      extractValue(XMLType(column_value),'/doc:Id/@Issuer', DOCUMENT_NS )
    FROM
      TABLE(documentids)
  )
  AND p_scope=t.SCOPE;
END DELETE_DOC;



-- /*************************************************************************
 -- Filter  a xml document before indexing based on the rowid of a document
-- (FUNCTION USED BY THE ORACLE INDEXER SEE THE USER_DATATSTORE parameter)
-- *************************************************************************/
procedure doFilterIndrDoc(docRowid IN ROWID,  xmlIndex  IN OUT NOCOPY CLOB) is
 
 lxml xmltype;
 cursor c1 is select xml_content from documents where rowid =docRowid;

 begin
 
 -- find xmlcontent.
open c1;
fetch c1 into lxml;
close c1;
 
 --temporary clob created foroutput 
 --if (xmlIndex is null) then
    DBMS_LOB.CREATETEMPORARY(xmlIndex, true, DBMS_LOB.CALL);  
--END IF;    

--filtering the xml to provide a nex xml index 
${USR_META}.PKG_TOOLS.filter(lxml,xmlIndex);
  
 exception
        when others then
          ${USR_META}.PKG_TOOLS.traceLog('DOCROWID='||docRowid,-1,1, SQLERRM);
      raise;
 end;
    



END PKG_DOCUMENT; 
/
