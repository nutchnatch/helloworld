insert into REP_ENVELOPES_DOCUMENTS_VW(SCOPE,DATA_DATE,DIRECTION_CODE,LONG_LABEL,envelopes_nbr,documents_nbr,documents_size) values('Syldavia',to_date('2014-07-31','YYYY-MM-DD'),'IN','test',10, 20, 90)
/
insert into REP_ENVELOPES_DOCUMENTS_VW(SCOPE,DATA_DATE,DIRECTION_CODE,LONG_LABEL,envelopes_nbr,documents_nbr,documents_size) values('Syldavia',to_date('2014-07-31','YYYY-MM-DD'),'IN','test',15, 41, 954)
/
insert into REP_ENVELOPES_DOCUMENTS_VW(SCOPE,DATA_DATE,DIRECTION_CODE,LONG_LABEL,envelopes_nbr,documents_nbr,documents_size) values('Syldavia',to_date('2014-07-31','YYYY-MM-DD'),'IN','test',45, 24, 54)
/
insert into REP_ENVELOPES_DOCUMENTS_VW(SCOPE,DATA_DATE,DIRECTION_CODE,LONG_LABEL,envelopes_nbr,documents_nbr,documents_size) values('Syldavia',to_date('2014-07-31','YYYY-MM-DD'),'IN','test',545, 5445, 545)
/
insert into REP_ENVELOPES_DOCUMENTS_VW(SCOPE,DATA_DATE,DIRECTION_CODE,LONG_LABEL,envelopes_nbr,documents_nbr,documents_size) values('Syldavia',to_date('2014-07-31','YYYY-MM-DD'),'IN','test',544, 5445, 545)
/
insert into REP_ENVELOPES_DOCUMENTS_VW(SCOPE,DATA_DATE,DIRECTION_CODE,LONG_LABEL,envelopes_nbr,documents_nbr,documents_size) values('Syldavia',to_date('2014-07-31','YYYY-MM-DD'),'IN','test2',546, 5445, 545)
/
