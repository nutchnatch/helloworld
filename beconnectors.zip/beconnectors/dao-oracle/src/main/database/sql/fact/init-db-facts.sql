create table ${USR_REP}.facts 
(
	Scope    	VARCHAR2(80),
	UserName	VARCHAR2(50),
  	ObjectType    	VARCHAR2(50),
  	Action        	VARCHAR2(50),
  	CreationDate  	NUMBER,
  	CONTENT       	VARCHAR2(2550),
	XML_CONTENT		XMLTYPE
)
TABLESPACE ${REP_TABLESPACE_DATA}
/
CREATE INDEX ${USR_REP}.facts_scope ON ${USR_REP}.FACTS(Scope)
TABLESPACE ${REP_TABLESPACE_INDEX}
/

