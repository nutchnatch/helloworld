CREATE TABLE ${USR_ACL}.ACLS
        (
                SCOPE           VARCHAR2(80),
                ID_VALUE        VARCHAR2(36),
                ID_SCHEME       VARCHAR2(80),
                ID_ISSUER       VARCHAR2(80),
                XML_CONTENT     XMLTYPE,
                constraint acl_pk primary key (SCOPE, ID_VALUE, ID_SCHEME, ID_ISSUER) 
	)  
        XMLTYPE COLUMN XML_CONTENT STORE AS BINARY XML
        TABLESPACE ${ACL_TABLESPACE_DATA}  
/

CREATE OR REPLACE type ${USR_APP}.VarcharArray as table of varchar2(3000);
/

CREATE INDEX ${USR_ACL}.acls_scope ON ${USR_ACL}.ACLS(SCOPE) TABLESPACE ${ACL_TABLESPACE_INDEX}
/

