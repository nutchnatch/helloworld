DELETE FROM ACLS
/
DELETE FROM ACL_MAPPINGS
/

Insert into ACLS(SCOPE, ID_VALUE, ID_SCHEME, ID_ISSUER, XML_CONTENT) values
 (
'Syldavia',
'9f879aa1-f736-41e9-babc-f5cf9d7093b6',
'DefaultScheme',
'Arondor',
XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
 <acl:AccessControlList xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" Name="ACL for doc classes" Scope="Syldavia">
  <acl:AclId Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>
  <acl:CreatnDate>2014-04-18 18:31:37.792 CEST</acl:CreatnDate>
  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>CREATE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>DELETE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>ADMINISTRATION</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UREAD</acl:Principal>
    <acl:Permission>CREATE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UREAD</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

 <acl:AccessControlEntry>
    <acl:Principal>UWRITE</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UWRITE</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>



</acl:AccessControlList>
'))
/

Insert into ACLS(SCOPE, ID_VALUE, ID_SCHEME, ID_ISSUER, XML_CONTENT) values 
(
'Syldavia',
'8a1475b1-d5b4-49bb-ad5e-9aa899444021',
'DefaultScheme',
'Arondor',
XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
 <acl:AccessControlList xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" Name="ACL for doc instances" Scope="Syldavia">
  <acl:AclId Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>
  <acl:CreatnDate>2014-04-18 18:31:37.792 CEST</acl:CreatnDate>
  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>DELETE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>SUGAR_USER_ROLE</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>SUGAR_USER_ROLE</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UREAD</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UREAD</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

</acl:AccessControlList>
'))
/

Insert into ACLS(SCOPE, ID_VALUE, ID_SCHEME, ID_ISSUER, XML_CONTENT) values 
(
'Syldavia',
'75b18a14-d5b4-49bb-ad5e-40219aa89944',
'DefaultScheme',
'Arondor',
XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
 <acl:AccessControlList xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" Name="ACL for BusinessScope" Scope="Syldavia">
  <acl:AclId Issuer="Arondor" Scheme="DefaultScheme">75b18a14-d5b4-49bb-ad5e-40219aa89944</acl:AclId>
  <acl:CreatnDate>2014-04-18 18:31:37.792 CEST</acl:CreatnDate>

 <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_GESTIONNAIRE</acl:Principal>
    <acl:Permission>CREATE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>ADMINISTRATION</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>DELETE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

</acl:AccessControlList>
'))
/

Insert into ACLS(SCOPE, ID_VALUE, ID_SCHEME, ID_ISSUER, XML_CONTENT) values 
(
'Syldavia',
'86c29b25-e6c5-50cc-be6f-51320bb90055',
'DefaultScheme',
'Arondor',
XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
 <acl:AccessControlList xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" Name="ACL for user" Scope="Syldavia">
  <acl:AclId Issuer="Arondor" Scheme="DefaultScheme">86c29b25-e6c5-50cc-be6f-51320bb90055</acl:AclId>
  <acl:CreatnDate>2014-04-18 18:31:37.792 CEST</acl:CreatnDate>

 <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_GESTIONNAIRE</acl:Principal>
    <acl:Permission>CREATE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>ADMINISTRATION</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UREAD</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UWRITE</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_GESTIONNAIRE</acl:Principal>
    <acl:Permission>READ</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UWRITE</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_GESTIONNAIRE</acl:Principal>
    <acl:Permission>WRITE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

 <acl:AccessControlEntry>
    <acl:Principal>UWRITE</acl:Principal>
    <acl:Permission>CREATE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>UWRITE</acl:Principal>
    <acl:Permission>DELETE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>

  <acl:AccessControlEntry>
    <acl:Principal>ICONNECT_ROLE</acl:Principal>
    <acl:Permission>DELETE</acl:Permission>
    <acl:Grant>ALLOW</acl:Grant>
  </acl:AccessControlEntry>


</acl:AccessControlList>
'))
/

-- Mapping document classes
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>'),
'CLASS',
'Syldavia' ,
'0c210550-c591-4747-b40e-10813de53d71',
'CARDIF',
'-1',
'0'
)
/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>'),
'INSTANCE',
'Syldavia' ,
'0c210550-c591-4747-b40e-10813de53d71',
'CARDIF',
'-1',
'0'
)

/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>'),
'CLASS',
'Syldavia' ,
'878504d1-a284-46d6-b10f-c857f57e337a',
'CARDIF',
'-1',
'0'
)
/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>'),
'INSTANCE',
'Syldavia' ,
'878504d1-a284-46d6-b10f-c857f57e337a',
'CARDIF',
'-1',
'0'
)
/

INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>'),
'CLASS',
'Syldavia' ,
'71c3c79f-c7fd-48bb-a4e8-6a335698ea81',
'CARDIF',
'-1',
'0'
)
/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>'),
'INSTANCE',
'Syldavia' ,
'71c3c79f-c7fd-48bb-a4e8-6a335698ea81',
'CARDIF',
'-1',
'0'
)
/

INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>'),
'CLASS',
'Syldavia' ,
'c67c3811-1459-483d-b907-a701ebf47bed',
'CARDIF',
'-1',
'0'
)
/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>'),
'INSTANCE',
'Syldavia' ,
'c67c3811-1459-483d-b907-a701ebf47bed',
'CARDIF',
'-1',
'0'
)
/

INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>'),
'CLASS',
'Syldavia' ,
'636c7975-d653-4bdc-bd4d-1ec9efc83dde',
'CARDIF',
'-1',
'0'
)
/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>'),
'INSTANCE',
'Syldavia' ,
'636c7975-d653-4bdc-bd4d-1ec9efc83dde',
'CARDIF',
'-1',
'0'
)
/

-------------------------------------







INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>'),
'CLASS',
'Syldavia' ,
'05440c0e-bfd8-446d-a1fe-dd45d7335983',
'CARDIF',
'-1',
'0'
)
/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>'),
'INSTANCE',
'Syldavia' ,
'05440c0e-bfd8-446d-a1fe-dd45d7335983',
'CARDIF',
'-1',
'0'
)
/

INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>'),
'CLASS',
'Syldavia' ,
'b21ba156-f5be-407e-a0b5-6c74aedea9ee',
'CARDIF',
'-1',
'0'
)
/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>'),
'INSTANCE',
'Syldavia' ,
'b21ba156-f5be-407e-a0b5-6c74aedea9ee',
'CARDIF',
'-1',
'0'
)
/

INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">9f879aa1-f736-41e9-babc-f5cf9d7093b6</acl:AclId>'),
'CLASS',
'Syldavia' ,
'7a770afa-b0c6-4442-bd4c-5a3ae2132d61',
'CARDIF',
'-1',
'0'
)
/
INSERT INTO ACL_MAPPINGS VALUES(XMLTYPE('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><acl:AclId xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" 
Issuer="Arondor" Scheme="DefaultScheme">8a1475b1-d5b4-49bb-ad5e-9aa899444021</acl:AclId>'),
'INSTANCE',
'Syldavia' ,
'7a770afa-b0c6-4442-bd4c-5a3ae2132d61',
'CARDIF',
'-1',
'0'
)
/









