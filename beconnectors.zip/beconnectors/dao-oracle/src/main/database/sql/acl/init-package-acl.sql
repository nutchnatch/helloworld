-- WARNING : will throw critical error because primary key already exist
--DECLARE 
--  num_rows integer;
--BEGIN
--   SELECT count(*)
--      INTO num_rows
--   from user_constraints where table_name='${USR_ACL}.ACL_MAPPINGS';

--   IF num_rows = 0 THEN 
--       EXECUTE IMMEDIATE 'ALTER TABLE ${USR_ACL}.ACL_MAPPINGS ADD CONSTRAINT acl_mapping_pk primary key (SCOPE, CONTEXT, ID_VALUE, ID_ISSUER, ID_SCHEME, VERSID)';
--   END IF;
--END;
--/

CREATE OR REPLACE PACKAGE ${USR_ACL}.PKG_ACL
IS
  ACL_NS CONSTANT VARCHAR2(800):=
  'xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1"';
  PROCEDURE STORE(
      ACL_ARG IN CLOB );
  PROCEDURE UPDATE_ACL(
    ACL_ARG IN CLOB );
  PROCEDURE GET(
      ACLID_ARG IN VARCHAR2,
      SCOPE_ARG IN VARCHAR2,
      ACL_ARG OUT CLOB );
  PROCEDURE ASSIGN(
      ACLID_ARG    IN VARCHAR2,
      OBJECTID_ARG IN VARCHAR2,
      CONTEXT_ARG  IN VARCHAR2,
      SCOPE_ARG    IN VARCHAR2 );
  PROCEDURE SEARCH(
      OBJECTID_ARG IN VARCHAR2,
      CONTEXT_ARG  IN VARCHAR2,
      SCOPE_ARG    IN VARCHAR2,
      ACLID_ARG OUT VARCHAR2 );
  PROCEDURE GETALL(
      p_scope IN VARCHAR2,
      AclsFetched OUT SYS_refcursor ) ;
  PROCEDURE REMOVE(
      OBJECTID_ARG IN VARCHAR2,
      CONTEXT_ARG  IN VARCHAR2,
      SCOPE_ARG    IN VARCHAR2);
END PKG_ACL; 
/


CREATE OR REPLACE PACKAGE body ${USR_ACL}.PKG_ACL
IS


PROCEDURE STORE(
    ACL_ARG IN CLOB )
AS
  xml XMLTYPE;
  scope     VARCHAR2(80);
  id_value  VARCHAR2(36);
  id_scheme VARCHAR2(80);
  id_issuer VARCHAR2(80);
BEGIN
  xml      := XMLType(ACL_ARG);
  scope    := xml.extract('/acl:AccessControlList/@Scope',ACL_NS).getStringVal();
  id_value := xml.extract('/acl:AccessControlList/acl:AclId/text()',ACL_NS)
  .getStringVal();
  id_scheme := xml.extract('/acl:AccessControlList/acl:AclId/@Scheme',ACL_NS)
  .getStringVal();
  id_issuer := xml.extract('/acl:AccessControlList/acl:AclId/@Issuer',ACL_NS)
  .getStringVal();
  INSERT
  INTO
    ACLS VALUES
    (
      scope,
      id_value,
      id_scheme,
      id_issuer,
      xml
    );
END STORE;

PROCEDURE UPDATE_ACL(
    ACL_ARG IN CLOB )
AS
  nCount NUMBER;
  l_xml XMLTYPE;
  l_scope     VARCHAR2(80);
  l_id_value  VARCHAR2(36);
  l_id_scheme VARCHAR2(80);
  l_id_issuer VARCHAR2(80);
BEGIN

 l_xml      := XMLType(ACL_ARG);
  l_scope    := l_xml.extract('/acl:AccessControlList/@Scope',ACL_NS).getStringVal();
  l_id_value := l_xml.extract('/acl:AccessControlList/acl:AclId/text()',ACL_NS)
  .getStringVal();
  l_id_scheme := l_xml.extract('/acl:AccessControlList/acl:AclId/@Scheme',ACL_NS)
  .getStringVal();
  l_id_issuer := l_xml.extract('/acl:AccessControlList/acl:AclId/@Issuer',ACL_NS)
  .getStringVal();
 

		UPDATE ACLS t
		SET
		t.XML_CONTENT = l_xml
	      WHERE

	        t.ID_VALUE    = l_id_value
	      AND t.ID_SCHEME = l_id_scheme
	      AND t.ID_ISSUER = l_id_issuer
	      AND t.scope     = l_scope;
 

END UPDATE_ACL;



PROCEDURE GET
  (
    ACLID_ARG IN  VARCHAR2,
    SCOPE_ARG IN  VARCHAR2,
    ACL_ARG   OUT CLOB
  )
AS
  xml XMLTYPE;
BEGIN
  xml:= XMLType(ACLID_ARG);
  SELECT
    p.XML_CONTENT.getclobVal()
  INTO
    ACL_ARG
  FROM
    ACLS p
  WHERE
    ID_VALUE    IN extractValue(xml, '/acl:AclId/text()', ACL_NS)
  AND ID_SCHEME IN extractValue(xml, '/acl:AclId/@Scheme', ACL_NS)
  AND ID_ISSUER IN extractValue(xml, '/acl:AclId/@Issuer', ACL_NS)
  AND SCOPE      = SCOPE_ARG;
END GET;


PROCEDURE ASSIGN(
    ACLID_ARG    IN VARCHAR2,
    OBJECTID_ARG IN VARCHAR2,
    CONTEXT_ARG  IN VARCHAR2,
    SCOPE_ARG    IN VARCHAR2 )
AS
  xml XMLTYPE;
  id_value  VARCHAR2(36);
  id_scheme VARCHAR2(80);
  id_issuer VARCHAR2(80);
  versid    VARCHAR2(80);
BEGIN
  xml                           := XMLType(OBJECTID_ARG);
  id_value                      := xml.extract('/*/text()').getStringVal();
  id_issuer                     := xml.extract('/*/@Issuer').getStringVal();
  IF (xml.extract('/*/@Scheme') IS NOT NULL) THEN
    id_scheme                   := xml.extract('/*/@Scheme').getStringVal();
  ELSE
    id_scheme := '-1';
  END IF;
  IF (xml.extract('/*/@VersId') IS NOT NULL) THEN
    versid                      := xml.extract('/*/@VersId').getStringVal();
  ELSE
    versid := '-1';
  END IF;
  INSERT
  INTO
    ACL_MAPPINGS VALUES
    (
      XMLType(ACLID_ARG),
      CONTEXT_ARG,
      SCOPE_ARG,
      id_value,
      id_issuer,
      id_scheme,
      versid
    );
END ASSIGN;


PROCEDURE SEARCH
  (
    OBJECTID_ARG IN VARCHAR2,
    CONTEXT_ARG  IN VARCHAR2,
    SCOPE_ARG    IN VARCHAR2,
    ACLID_ARG OUT VARCHAR2
  )
AS
  xml XMLTYPE;
BEGIN
  xml:= XMLType(OBJECTID_ARG);
  SELECT /*+ INDEX(t acl_mapping_pk) */ t.ACLID.getStringVal()
  INTO
    ACLID_ARG
  FROM
    ACL_MAPPINGS t
  WHERE
    t.CONTEXT = ''
    || CONTEXT_ARG
    || ''
  AND t.SCOPE      = SCOPE_ARG
  AND t.ID_VALUE  IN extractValue(xml,'/*/text()')
  AND t.ID_ISSUER IN extractValue(xml,'/*/@Issuer')
  AND
    (
      t.ID_SCHEME IN extractValue(xml,'/*/@Scheme')
    OR t.VERSID   IN extractValue(xml,'/*/@VersId')
    ) ;
EXCEPTION
WHEN NO_DATA_FOUND THEN
 ACLID_ARG := NULL;
END search;


PROCEDURE GETALL(
    p_scope IN VARCHAR2,
    AclsFetched OUT SYS_refcursor )
IS
BEGIN
  OPEN AclsFetched FOR SELECT t.XML_CONTENT.getclobval() FROM ACLS t WHERE
  t.scope=p_scope;
END getall;


PROCEDURE REMOVE(
    OBJECTID_ARG IN VARCHAR2,
    CONTEXT_ARG  IN VARCHAR2,
    SCOPE_ARG    IN VARCHAR2)
AS
  xml XMLTYPE;
BEGIN
  xml:= XMLType(OBJECTID_ARG);
  DELETE
  FROM
    ACL_MAPPINGS
  WHERE
    CONTEXT = ''
    || CONTEXT_ARG
    || ''
  AND SCOPE      = SCOPE_ARG
  AND ID_VALUE  IN extractValue(xml,'/*/text()')
  AND ID_ISSUER IN extractValue(xml,'/*/@Issuer')
  AND
    (
      ID_SCHEME IN extractValue(xml,'/*/@Scheme')
    OR VERSID   IN extractValue(xml,'/*/@VersId')
    );
END remove;
END PKG_ACL; 
/
