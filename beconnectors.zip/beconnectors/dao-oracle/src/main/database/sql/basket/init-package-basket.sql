CREATE OR REPLACE PACKAGE ${USR_META}.PKG_BASKET
IS
  BASKET_NS CONSTANT VARCHAR2(800):=
  'xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1" '
  ;
  PROCEDURE GETALL(
      scopeIn IN VARCHAR2,
      BasketFetched OUT SYS_refcursor );
  PROCEDURE STORE(
      p_BASKETS IN ${USR_APP}.ClobArray );
  PROCEDURE STORE_SINGLE(
      p_BASKET IN Clob );
  PROCEDURE GET(
      p_scope   IN VARCHAR2,
      ID_VALUEs IN ${USR_APP}.VarcharArray,
      BasketFetched OUT SYS_refcursor );
  PROCEDURE UPDATE_BASKET(
      basketsToUpdate IN ${USR_APP}.ClobArray );
  PROCEDURE UPDATE_BASKET_SINGLE(
      basketToUpdate IN Clob);
  PROCEDURE DELETE_BASKET(
      p_scope         IN VARCHAR2,
      basketsToDelete IN ${USR_APP}.VarcharArray );
  PROCEDURE COUNTTASK(
      scopeIn    IN VARCHAR2,
      issuerIn   IN VARCHAR2,
      schemeIn   IN VARCHAR2,
      ID_VALUEIn IN VARCHAR2,
      counter OUT NUMBER );
END PKG_BASKET; 
/


CREATE OR REPLACE PACKAGE BODY ${USR_META}.PKG_BASKET
AS


PROCEDURE GETALL(
    scopeIn IN VARCHAR2,
    BasketFetched OUT SYS_refcursor)
IS
BEGIN
  OPEN BasketFetched FOR SELECT t.XML_CONTENT.getClobVal() FROM BASKETS t
  WHERE t.SCOPE=scopeIn;
END GETALL;


PROCEDURE STORE(
    p_BASKETS IN ${USR_APP}.ClobArray)
AS
  xml XMLTYPE;
  scope     VARCHAR2(80);
  id_value  VARCHAR2(36);
  id_scheme VARCHAR2(80);
  id_issuer VARCHAR2(80);
BEGIN
  FOR elem IN 1 .. p_BASKETS.count
  LOOP
    xml      := XMLType(p_BASKETS(elem));
    scope    := xml.extract('/basket:Basket/@Scope',BASKET_NS).getStringVal();
    id_value := xml.extract('/basket:Basket/basket:BasketId/text()',BASKET_NS)
    .getStringVal();
    id_scheme := xml.extract('/basket:Basket/basket:BasketId/@Scheme',BASKET_NS
    ) .getStringVal();
    id_issuer := xml.extract('/basket:Basket/basket:BasketId/@Issuer',BASKET_NS
    ) .getStringVal();
    INSERT
    INTO
      BASKETS
      (
        SCOPE,
        ID_VALUE,
        ID_SCHEME,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_scheme,
        id_issuer,
        xml
      );
  END LOOP;
END;

PROCEDURE STORE_SINGLE(
    p_BASKET IN Clob)
AS
  xml XMLTYPE;
  scope     VARCHAR2(80);
  id_value  VARCHAR2(36);
  id_scheme VARCHAR2(80);
  id_issuer VARCHAR2(80);
BEGIN
    xml      := XMLType(p_BASKET);
    scope    := xml.extract('/basket:Basket/@Scope',BASKET_NS).getStringVal();
    id_value := xml.extract('/basket:Basket/basket:BasketId/text()',BASKET_NS)
    .getStringVal();
    id_scheme := xml.extract('/basket:Basket/basket:BasketId/@Scheme',BASKET_NS
    ) .getStringVal();
    id_issuer := xml.extract('/basket:Basket/basket:BasketId/@Issuer',BASKET_NS
    ) .getStringVal();
    INSERT
    INTO
      BASKETS
      (
        SCOPE,
        ID_VALUE,
        ID_SCHEME,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_scheme,
        id_issuer,
        xml
      );
END;

PROCEDURE GET
  (
    p_scope   IN VARCHAR2,
    ID_VALUEs IN ${USR_APP}.VarcharArray,
    BasketFetched OUT SYS_refcursor
  )
AS
BEGIN
  OPEN BasketFetched FOR SELECT t.XML_CONTENT.getClobVal
  (
  )
  FROM BASKETS t WHERE (t.ID_VALUE,t.ID_SCHEME,t.ID_ISSUER) IN
  (
    SELECT
      extractValue(xmltype(column_value),'/basket:BasketId',BASKET_NS),
      extractValue(xmltype(column_value),'/basket:BasketId/@Scheme',BASKET_NS),
      extractValue(xmltype(column_value),'/basket:BasketId/@Issuer',BASKET_NS)   
    FROM
      TABLE(ID_VALUEs)
  )
  AND t.SCOPE = p_scope;
END GET;


PROCEDURE UPDATE_BASKET
  (
    basketsToUpdate IN ${USR_APP}.ClobArray
  )
AS
  nCount NUMBER;
  xml XMLTYPE;
  p_scope     VARCHAR2(80);
  p_id_value  VARCHAR2(36);
  p_id_scheme VARCHAR2(80);
  p_id_issuer VARCHAR2(80);
BEGIN
  FOR i IN 1 .. basketsToUpdate.count
  LOOP
    xml := XMLType
    (
      basketsToUpdate(i)
    )
    ;
    p_scope    := xml.extract('/basket:Basket/@Scope',BASKET_NS).getStringVal();
    p_id_value := xml.extract('/basket:Basket/basket:BasketId/text()',BASKET_NS
    ).getStringVal();
    p_id_scheme := xml.extract('/basket:Basket/basket:BasketId/@Scheme',
    BASKET_NS).getStringVal();
    p_id_issuer := xml.extract('/basket:Basket/basket:BasketId/@Issuer',
    BASKET_NS).getStringVal();
    SELECT
      COUNT(*)
    INTO
      nCount
    FROM
      BASKETS t
    WHERE
      t.ID_VALUE    = p_id_value
    AND t.ID_SCHEME = p_id_scheme
    AND t.ID_ISSUER = p_id_issuer
    AND t.scope     = p_scope;
    IF(nCount       > 0) THEN
      UPDATE
        BASKETS t
      SET
        t.XML_CONTENT = xml
      WHERE
        t.ID_VALUE    = p_id_value
      AND t.ID_SCHEME = p_id_scheme
      AND t.ID_ISSUER = p_id_issuer
      AND t.scope     = p_scope;
    ELSE
      INSERT
      INTO
        BASKETS
        (
          SCOPE,
          ID_VALUE,
          ID_SCHEME,
          ID_ISSUER,
          XML_CONTENT
        )
        VALUES
        (
          p_scope,
          p_id_value,
          p_id_scheme,
          p_id_issuer,
          xml
        );
    END IF;
  END LOOP;
END UPDATE_BASKET;

PROCEDURE UPDATE_BASKET_SINGLE
  (
    basketToUpdate IN Clob
  )
AS
  nCount NUMBER;
  xml XMLTYPE;
  p_scope     VARCHAR2(80);
  p_id_value  VARCHAR2(36);
  p_id_scheme VARCHAR2(80);
  p_id_issuer VARCHAR2(80);
BEGIN
    xml := XMLType(basketToUpdate);
    p_scope    := xml.extract('/basket:Basket/@Scope',BASKET_NS).getStringVal();
    p_id_value := xml.extract('/basket:Basket/basket:BasketId/text()',BASKET_NS
    ).getStringVal();
    p_id_scheme := xml.extract('/basket:Basket/basket:BasketId/@Scheme',
    BASKET_NS).getStringVal();
    p_id_issuer := xml.extract('/basket:Basket/basket:BasketId/@Issuer',
    BASKET_NS).getStringVal();
    SELECT
      COUNT(*)
    INTO
      nCount
    FROM
      BASKETS t
    WHERE
      t.ID_VALUE    = p_id_value
    AND t.ID_SCHEME = p_id_scheme
    AND t.ID_ISSUER = p_id_issuer
    AND t.scope     = p_scope;
    IF(nCount       > 0) THEN
      UPDATE
        BASKETS t
      SET
        t.XML_CONTENT = xml
      WHERE
        t.ID_VALUE    = p_id_value
      AND t.ID_SCHEME = p_id_scheme
      AND t.ID_ISSUER = p_id_issuer
      AND t.scope     = p_scope;
    ELSE
      INSERT
      INTO
        BASKETS
        (
          SCOPE,
          ID_VALUE,
          ID_SCHEME,
          ID_ISSUER,
          XML_CONTENT
        )
        VALUES
        (
          p_scope,
          p_id_value,
          p_id_scheme,
          p_id_issuer,
          xml
        );
    END IF;
END UPDATE_BASKET_SINGLE;

PROCEDURE DELETE_BASKET
  (
    p_scope         IN VARCHAR2,
    basketsToDelete IN ${USR_APP}.VarcharArray
  )
IS
BEGIN
  DELETE
  FROM
    BASKETS t
  WHERE
    (t.ID_VALUE,t.ID_SCHEME,t.ID_ISSUER) IN
    (
      SELECT
        EXTRACTVALUE(xmltype(column_value), '/basket:BasketId', BASKET_NS),
        EXTRACTVALUE(xmltype(column_value), '/basket:BasketId/@Scheme', BASKET_NS),
         EXTRACTVALUE(xmltype(column_value), '/basket:BasketId/@Issuer', BASKET_NS)
      FROM
        TABLE(basketsToDelete)
    )
  AND t.SCOPE = p_scope;
END DELETE_BASKET;


PROCEDURE COUNTTASK(
    scopeIn    IN VARCHAR2,
    issuerIn   IN VARCHAR2,
    schemeIn   IN VARCHAR2,
    ID_VALUEIn IN VARCHAR2,
    counter OUT NUMBER)
IS
BEGIN
  SELECT
    COUNT(*)
  INTO
    counter
  FROM
    TASKS t
  WHERE
    t.SCOPE       =scopeIn
  AND t.ID_ISSUER = issuerIn
  AND t.ID_SCHEME =schemeIn
  AND t.ID_VALUE  =ID_VALUEIn;
END;


END PKG_BASKET; 
/
