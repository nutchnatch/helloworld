Insert into BASKETS (SCOPE,ID_VALUE,ID_SCHEME,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'c16b687a-603e-4834-be65-34ec9b171c6c',
'Sugar',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><basket:Basket SymbolicName="Contract" Scope="Syldavia" xmlns:folder="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1" xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1" xmlns:businessscope="http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1" xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1">
   <basket:BasketId Issuer="CARDIF" Scheme="Sugar">c16b687a-603e-4834-be65-34ec9b171c6c</basket:BasketId>
   <basket:DisplayName language="EN">
      <i18n:value>Contract</i18n:value>
   </basket:DisplayName>
   <basket:DisplayName language="FR">
      <i18n:value>Contrat</i18n:value>
   </basket:DisplayName>
</basket:Basket>'))
/


Insert into BASKETS (SCOPE,ID_VALUE,ID_SCHEME,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'd94f6401-a05e-42ae-ab12-31e739444f71',
'Sugar',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><basket:Basket SymbolicName="Claim" Scope="Syldavia" xmlns:folder="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1" xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1" xmlns:businessscope="http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1" xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1">
   <basket:BasketId Issuer="CARDIF" Scheme="Sugar">d94f6401-a05e-42ae-ab12-31e739444f71</basket:BasketId>
   <basket:DisplayName language="EN">
      <i18n:value>Claim</i18n:value>
   </basket:DisplayName>
   <basket:DisplayName language="FR">
      <i18n:value>Constat</i18n:value>
   </basket:DisplayName>
</basket:Basket>'))
/

Insert into BASKETS (SCOPE,ID_VALUE,ID_SCHEME,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'57a73bd2-5442-42d0-b605-4d11c7773c3c',
'Sugar',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><basket:Basket SymbolicName="Invalid docs" Scope="Syldavia" xmlns:folder="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1" xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1" xmlns:businessscope="http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1" xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1">
   <basket:BasketId Issuer="CARDIF" Scheme="Sugar">57a73bd2-5442-42d0-b605-4d11c7773c3c</basket:BasketId>
   <basket:DisplayName language="EN">
      <i18n:value>Invalid documents</i18n:value>
   </basket:DisplayName>
   <basket:DisplayName language="FR">
      <i18n:value>Documents invalides</i18n:value>
   </basket:DisplayName>
</basket:Basket>'))
/

