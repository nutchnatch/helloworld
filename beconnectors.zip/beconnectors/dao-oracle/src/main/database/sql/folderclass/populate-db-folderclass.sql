Insert into FOLDERCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'7a770afa-b0c6-4442-bd4c-5a3ae2132d61',
'0',
'CARDIF',
XMLType('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<folderclass:FolderClass Scope="Syldavia" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18NLabel="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1" xmlns:folderclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolderclass/v1">
	<common:ClassId Issuer="CARDIF" VersId="0">7a770afa-b0c6-4442-bd4c-5a3ae2132d61</common:ClassId>
	<folderclass:Type>Contract Management</folderclass:Type>
	<folderclass:ShortLabel language="EN">
		<i18NLabel:value>Contract Management</i18NLabel:value>
	</folderclass:ShortLabel>
	<folderclass:LongLabel>Contract Management</folderclass:LongLabel>
	<folderclass:RetentionDuration TimeUnit="MONTH">2</folderclass:RetentionDuration>
	<folderclass:CreationDate>2014-05-23 15:42:55.072 CEST</folderclass:CreationDate>
	<folderclass:UpdateDate>2014-05-23 15:42:55.072 CEST</folderclass:UpdateDate>
	<folderclass:IndexValidatorType>java</folderclass:IndexValidatorType>
	<folderclass:active>true</folderclass:active>
    <folderclass:TagReference symbolicName="policy" mandatory="true" multivalued="true"/>
    <folderclass:TagReference symbolicName="SubscriberId" mandatory="false" multivalued="true"/>
    <folderclass:TagReference symbolicName="SubscriberName" mandatory="false" multivalued="true"/>
</folderclass:FolderClass>'))
/

Insert into FOLDERCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'fd60a369-a6c8-4d69-a1f3-d869905f4acc',
'0',
'CARDIF',
XMLType('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<folderclass:FolderClass Scope="Syldavia" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18NLabel="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1" xmlns:folderclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolderclass/v1">
	<common:ClassId Issuer="CARDIF" VersId="0">fd60a369-a6c8-4d69-a1f3-d869905f4acc</common:ClassId>
	<folderclass:Type>Claim Management</folderclass:Type>
	<folderclass:ShortLabel language="EN">
		<i18NLabel:value>ClaimManagement</i18NLabel:value>
	</folderclass:ShortLabel>
	<folderclass:LongLabel>Claim Management</folderclass:LongLabel>
	<folderclass:RetentionDuration TimeUnit="MONTH">2</folderclass:RetentionDuration>
	<folderclass:CreationDate>2014-05-23 15:42:55.072 CEST</folderclass:CreationDate>
	<folderclass:UpdateDate>2014-05-23 15:42:55.072 CEST</folderclass:UpdateDate>
	<folderclass:IndexValidatorType>java</folderclass:IndexValidatorType>
	<folderclass:active>true</folderclass:active>
    <folderclass:TagReference symbolicName="policy" mandatory="false" multivalued="true"/>
    <folderclass:TagReference symbolicName="ClaimType" mandatory="true" multivalued="true"/>
    <folderclass:TagReference symbolicName="SubscriberId" mandatory="true" multivalued="true"/>
    <folderclass:TagReference symbolicName="BeneficiaryId" mandatory="false" multivalued="true"/>
    <folderclass:TagReference symbolicName="BeneficiaryName" mandatory="false" multivalued="true"/>
</folderclass:FolderClass>'))
/

Insert into FOLDERCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'fd60a369-a6c8-4d69-a1f3-d869905f4acd',
'0',
'CARDIF',
XMLType('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<folderclass:FolderClass Scope="Syldavia" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18NLabel="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1" xmlns:folderclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolderclass/v1">
	<common:ClassId Issuer="CARDIF" VersId="0">fd60a369-a6c8-4d69-a1f3-d869905f4acd</common:ClassId>
	<folderclass:Type>Litigation Management</folderclass:Type>
	<folderclass:ShortLabel language="EN">
		<i18NLabel:value>LitigationManagement</i18NLabel:value>
	</folderclass:ShortLabel>
	<folderclass:LongLabel>Litigation Management</folderclass:LongLabel>
  	<folderclass:RetentionDuration TimeUnit="MONTH">2</folderclass:RetentionDuration>
	<folderclass:CreationDate>2014-05-23 15:42:55.072 CEST</folderclass:CreationDate>
	<folderclass:UpdateDate>2014-05-23 15:42:55.072 CEST</folderclass:UpdateDate>
	<folderclass:IndexValidatorType>java</folderclass:IndexValidatorType>
	<folderclass:active>true</folderclass:active>
    <folderclass:TagReference symbolicName="policy" mandatory="false" multivalued="true"/>
    <folderclass:TagReference symbolicName="SubscriberId" mandatory="true" multivalued="true"/>
    <folderclass:TagReference symbolicName="LitigationType" mandatory="true" multivalued="true"/>
    <folderclass:TagReference symbolicName="DebtorId" mandatory="false" multivalued="true"/>
    <folderclass:TagReference symbolicName="DebtorName" mandatory="false" multivalued="true"/>
</folderclass:FolderClass>'))
/
