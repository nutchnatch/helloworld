CREATE TABLE ${USR_META}.FOLDERCLASSES (
  SCOPE         VARCHAR2(80),
  ID_VALUE      VARCHAR2(36),
  ID_VERSION    VARCHAR2(80),
  ID_ISSUER     VARCHAR2(80),
  XML_CONTENT   XMLTYPE,
  ACTIVE        AS (extractValue(XML_CONTENT , '/folderclass:FolderClass/folderclass:active' ,'xmlns:folderclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolderclass/v1"')) VIRTUAL,
  constraint folderclass_pk primary key (SCOPE, ID_VALUE, ID_VERSION, ID_ISSUER) 
  )
  XMLTYPE COLUMN XML_CONTENT STORE AS BINARY XML
  TABLESPACE ${META_TABLESPACE_DATA}  
/
CREATE INDEX ${USR_META}.folderclasses_scope ON ${USR_META}.FOLDERCLASSES(SCOPE) TABLESPACE ${META_TABLESPACE_INDEX}
/

