CREATE OR REPLACE PACKAGE ${USR_META}.PKG_FOLDERCLASS
IS
  CLASS_NS CONSTANT VARCHAR2(800):=
  'xmlns:folderclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolderclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"'
  ;
  PROCEDURE ADD(
      p_FOLDERCLASSES IN ${USR_APP}.ClobArray);
  
  PROCEDURE ADD_SINGLE(
      p_FOLDERCLASS IN Clob);

  PROCEDURE GET(
      p_scope        IN VARCHAR2,
      FolderClassIds IN ${USR_APP}.VarcharArray,
      FolderClassesFetched OUT SYS_refcursor);
      
  PROCEDURE GETALLVERSIONS(
      p_scope        IN VARCHAR2,
      FolderClassIds IN ${USR_APP}.VarcharArray,
      FolderClassesFetched OUT SYS_refcursor);

  PROCEDURE UPDATE_FOLDER_CLASSES(
      folderClassesToUpdate IN ${USR_APP}.ClobArray);
      
  PROCEDURE UPDATE_FOLDER_CLASS(
      folderClassToUpdate IN Clob);

  PROCEDURE GETALL(
      p_scope      IN VARCHAR2,
      isActiveOnly IN VARCHAR2,
      FolderClassesFetched OUT SYS_refcursor);

  PROCEDURE SET_ACTIVE(
      FolderClassIds IN ${USR_APP}.VarcharArray,
      activeValue    IN VARCHAR2,
      p_scope        IN VARCHAR2,
      updateDate     IN VARCHAR2);

END PKG_FOLDERCLASS; 
/


CREATE OR REPLACE PACKAGE BODY ${USR_META}.PKG_FOLDERCLASS
AS


PROCEDURE ADD(
    p_FOLDERCLASSES IN ${USR_APP}.ClobArray)
AS
  xml XMLType;
  scope      VARCHAR2(80);
  id_value   VARCHAR2(36);
  id_version VARCHAR2(80);
  id_issuer  VARCHAR2(80);
BEGIN
  FOR elem IN 1 .. p_FOLDERCLASSES.count
  LOOP
    xml   :=XMLType(p_FOLDERCLASSES(elem));
    scope := xml.extract('/folderclass:FolderClass/@Scope',CLASS_NS)
    .getStringVal();
    id_value := xml.extract('/folderclass:FolderClass/common:ClassId/text()',
    CLASS_NS).getStringVal();
    id_version := xml.extract('/folderclass:FolderClass/common:ClassId/@VersId'
    ,CLASS_NS).getStringVal();
    id_issuer := xml.extract('/folderclass:FolderClass/common:ClassId/@Issuer',
    CLASS_NS).getStringVal();
    INSERT
    INTO
      FOLDERCLASSES
      (
        SCOPE,
        ID_VALUE,
        ID_VERSION,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_version,
        id_issuer,
        xml
      );
  END LOOP;
END;


PROCEDURE ADD_SINGLE(
    p_FOLDERCLASS IN Clob)
AS
  xml XMLType;
  scope      VARCHAR2(80);
  id_value   VARCHAR2(36);
  id_version VARCHAR2(80);
  id_issuer  VARCHAR2(80);
BEGIN
    xml   :=XMLType(p_FOLDERCLASS);
    scope := xml.extract('/folderclass:FolderClass/@Scope',CLASS_NS)
    .getStringVal();
    id_value := xml.extract('/folderclass:FolderClass/common:ClassId/text()',
    CLASS_NS).getStringVal();
    id_version := xml.extract('/folderclass:FolderClass/common:ClassId/@VersId'
    ,CLASS_NS).getStringVal();
    id_issuer := xml.extract('/folderclass:FolderClass/common:ClassId/@Issuer',
    CLASS_NS).getStringVal();
    INSERT
    INTO
      FOLDERCLASSES
      (
        SCOPE,
        ID_VALUE,
        ID_VERSION,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_version,
        id_issuer,
        xml
      );
END;

PROCEDURE GET
  (
    p_scope        IN VARCHAR2,
    FolderClassIds IN ${USR_APP}.VarcharArray,
    FolderClassesFetched OUT SYS_refcursor
  )
AS
BEGIN
  OPEN FolderClassesFetched FOR SELECT /*+INDEX(t folderclass_pk)*/ t.XML_CONTENT.getClobVal
  (
  )
  FROM FOLDERCLASSES t WHERE (t.ID_VALUE, t.ID_ISSUER, t.ID_VERSION) IN
  (
    SELECT
      extractValue(xmltype(column_value),'/common:ClassId',CLASS_NS),
      extractValue(xmltype(column_value),'/common:ClassId/@Issuer',CLASS_NS),
      extractValue(xmltype(column_value),'/common:ClassId/@VersId',CLASS_NS)
       FROM
      TABLE(FolderClassIds)
  )
  AND t.SCOPE = p_scope;
END GET;

PROCEDURE GETALLVERSIONS
  (
    p_scope        IN VARCHAR2,
    FolderClassIds IN ${USR_APP}.VarcharArray,
    FolderClassesFetched OUT SYS_refcursor
  )
AS
BEGIN
  OPEN FolderClassesFetched FOR SELECT /*+INDEX(t folderclass_pk)*/ t.XML_CONTENT.getClobVal
  (
  )
  FROM FOLDERCLASSES t WHERE (t.ID_VALUE, t.ID_ISSUER) IN
  (
    SELECT
      extractValue(xmltype(column_value),'/common:ClassId',CLASS_NS),
      extractValue(xmltype(column_value),'/common:ClassId/@Issuer',CLASS_NS)
       FROM
      TABLE(FolderClassIds)
  )
  AND t.SCOPE = p_scope;
END GETALLVERSIONS;

PROCEDURE UPDATE_FOLDER_CLASSES
  (
    folderClassesToUpdate IN ${USR_APP}.ClobArray
  )
AS
  xml XMLType;
BEGIN
  FOR i IN 1 .. folderClassesToUpdate.count
  LOOP
    xml :=xmltype
    (
      folderClassesToUpdate(i)
    )
    ;

    UPDATE /*+INDEX(t folderclass_pk)*/ FOLDERCLASSES t
    SET
      XML_CONTENT=xml
            WHERE
              t.ID_VALUE = extractValue(xml, '/folderclass:FolderClass/common:ClassId',CLASS_NS)
            AND t.ID_ISSUER = extractValue(xml,'/folderclass:FolderClass/common:ClassId/@Issuer',CLASS_NS)
            AND t.ID_VERSION = extractValue(xml,'/folderclass:FolderClass/common:ClassId/@VersId',CLASS_NS)
            AND t.SCOPE = extractValue(xml, '/folderclass:FolderClass/@Scope',CLASS_NS) ;

  END LOOP;
END UPDATE_FOLDER_CLASSES;

PROCEDURE UPDATE_FOLDER_CLASS
  (
    folderClassToUpdate IN Clob
  )
AS
  xml XMLType;
BEGIN
    xml :=xmltype(folderClassToUpdate);
    UPDATE /*+INDEX(t folderclass_pk)*/ FOLDERCLASSES t
    SET
      XML_CONTENT=xml
            WHERE
              t.ID_VALUE = extractValue(xml, '/folderclass:FolderClass/common:ClassId',CLASS_NS)
            AND t.ID_ISSUER = extractValue(xml,'/folderclass:FolderClass/common:ClassId/@Issuer',CLASS_NS)
            AND t.ID_VERSION = extractValue(xml,'/folderclass:FolderClass/common:ClassId/@VersId',CLASS_NS)
            AND t.SCOPE = extractValue(xml, '/folderclass:FolderClass/@Scope',CLASS_NS) ;
            
END UPDATE_FOLDER_CLASS;

PROCEDURE GETALL(
    p_scope      IN VARCHAR2,
    isActiveOnly IN VARCHAR2,
    FolderClassesFetched OUT SYS_refcursor)
AS
BEGIN
  IF (isActiveOnly='true') THEN
    OPEN FolderClassesFetched FOR SELECT F.XML_CONTENT.getClobVal() FROM
    FOLDERCLASSES F WHERE F.SCOPE = p_scope AND F.ACTIVE='true';
  ELSE
    OPEN FolderClassesFetched FOR SELECT F.XML_CONTENT.getClobVal() FROM
    FOLDERCLASSES F WHERE F.scope = p_scope AND F.ID_VERSION =
    (
      SELECT
        MAX(CAST(F2.ID_VERSION AS INT))
      FROM
        FOLDERCLASSES F2
      WHERE
        F.ID_VALUE = F2.ID_VALUE
      AND F.ID_ISSUER = F2.ID_ISSUER
      AND F2.SCOPE = p_scope
    )
    ;
  END IF;
END GETALL;


PROCEDURE SET_ACTIVE(
    FolderClassIds IN ${USR_APP}.VarcharArray,
    activeValue    IN VARCHAR2,
    p_scope        IN VARCHAR2,
    updateDate     IN VARCHAR2)
AS
  XML_TMP XMLType;
  id XMLType;
BEGIN
  FOR i IN 1 .. FolderClassIds.count
  LOOP
    id := xmltype(FolderClassIds(i));
    SELECT
      t.XML_CONTENT
    INTO
      XML_TMP
    FROM
      FOLDERCLASSES t
    WHERE
      t.ID_VALUE     = extractValue(id, '/common:ClassId',CLASS_NS)
    AND t.ID_ISSUER  = extractValue(id, '/common:ClassId/@Issuer',CLASS_NS)
    AND t.ID_VERSION = extractValue(id, '/common:ClassId/@VersId',CLASS_NS)
    AND t.SCOPE      = p_scope;
    UPDATE
      FOLDERCLASSES t
    SET
      XML_CONTENT = UPDATEXML(XML_TMP,
      '/folderclass:FolderClass/folderclass:active/text()', activeValue,
      '/folderclass:FolderClass/folderclass:UpdateDate/text()', updateDate, CLASS_NS)
    WHERE
      t.ID_VALUE     = extractValue(id, '/common:ClassId',CLASS_NS)
    AND t.ID_ISSUER  = extractValue(id, '/common:ClassId/@Issuer',CLASS_NS)
    AND t.ID_VERSION = extractValue(id, '/common:ClassId/@VersId',CLASS_NS)
    AND t.SCOPE      = p_scope;
  END LOOP;
END SET_ACTIVE;


END PKG_FOLDERCLASS; 
/
