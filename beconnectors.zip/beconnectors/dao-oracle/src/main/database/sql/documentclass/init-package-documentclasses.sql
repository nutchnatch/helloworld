CREATE OR REPLACE PACKAGE ${USR_META}.PKG_DOCUMENTCLASS
IS
  CLASS_NS CONSTANT VARCHAR2(800):=
  'xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"'
  ;
  PROCEDURE GET(
      p_scope  IN VARCHAR2,
      ClassIds IN ${USR_APP}.VarcharArray,
      ClassesFetched OUT SYS_refcursor ) ;
  PROCEDURE GETALLVERSIONS(
      p_scope  IN VARCHAR2,
      ClassIds IN ${USR_APP}.VarcharArray,
      ClassesFetched OUT SYS_refcursor ) ;
  PROCEDURE STORE(
      DOCUMENTCLASSARG IN ${USR_APP}.ClobArray );
  PROCEDURE STORE_SINGLE(
      DOCUMENTCLASSARG IN Clob );
  PROCEDURE SEARCH(
      SCOPEARG    IN VARCHAR2,
      CATEGORYARG IN VARCHAR2,
      ACTIVE      IN VARCHAR2,
      documentClassCursor OUT SYS_REFCURSOR );
  PROCEDURE UPDATE_CLASSES(
      DocumentClassesToUpdate IN ${USR_APP}.ClobArray);
  PROCEDURE UPDATE_CLASSES_SINGLE(
      DocumentClassToUpdate IN Clob);
  PROCEDURE SETACTIVE(
      p_scope     IN VARCHAR2,
      ClassID_ARG IN ${USR_APP}.VarcharArray,
      activate    IN VARCHAR2,
      updateDate  IN VARCHAR2);
  PROCEDURE DELETECLASS(
      p_scope     IN VARCHAR2,
      ClassID_ARG IN ${USR_APP}.VarcharArray);
END PKG_DOCUMENTCLASS; 
/

CREATE OR REPLACE PACKAGE body ${USR_META}.PKG_DOCUMENTCLASS
IS


PROCEDURE STORE(
    DOCUMENTCLASSARG IN ${USR_APP}.ClobArray )
AS
  xml XMLTYPE;
  scope      VARCHAR2(80);
  id_value   VARCHAR2(36);
  id_version VARCHAR2(80);
  id_issuer  VARCHAR2(80);
BEGIN
  FOR elem IN 1 .. DOCUMENTCLASSARG.count
  LOOP
    xml   := XMLType(DOCUMENTCLASSARG(elem));
    scope := xml.extract('/docclass:DocumentClass/docclass:Scope/text()',
    CLASS_NS) .getStringVal();
    id_value := xml.extract('/docclass:DocumentClass/common:ClassId/text()',
    CLASS_NS).getStringVal();
    id_version := xml.extract('/docclass:DocumentClass/common:ClassId/@VersId',
    CLASS_NS).getStringVal();
    id_issuer := xml.extract('/docclass:DocumentClass/common:ClassId/@Issuer',
    CLASS_NS).getStringVal();
    INSERT
    INTO
      DOCUMENTCLASSES
      (
        SCOPE,
        ID_VALUE,
        ID_VERSION,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_version,
        id_issuer,
        xml
      );
  END LOOP;
END;

PROCEDURE STORE_SINGLE(
    DOCUMENTCLASSARG IN Clob)
AS
  xml XMLTYPE;
  scope      VARCHAR2(80);
  id_value   VARCHAR2(36);
  id_version VARCHAR2(80);
  id_issuer  VARCHAR2(80);
BEGIN
    xml   := XMLType(DOCUMENTCLASSARG);
    scope := xml.extract('/docclass:DocumentClass/docclass:Scope/text()',
    CLASS_NS) .getStringVal();
    id_value := xml.extract('/docclass:DocumentClass/common:ClassId/text()',
    CLASS_NS).getStringVal();
    id_version := xml.extract('/docclass:DocumentClass/common:ClassId/@VersId',
    CLASS_NS).getStringVal();
    id_issuer := xml.extract('/docclass:DocumentClass/common:ClassId/@Issuer',
    CLASS_NS).getStringVal();
    INSERT
    INTO
      DOCUMENTCLASSES
      (
        SCOPE,
        ID_VALUE,
        ID_VERSION,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_version,
        id_issuer,
        xml
      );
END;

PROCEDURE SEARCH
  (
    SCOPEARG    IN VARCHAR2,
    CATEGORYARG IN VARCHAR2,
    ACTIVE      IN VARCHAR2,
    documentClassCursor OUT SYS_REFCURSOR
  )
AS
  selectClause CLOB :=
  'SELECT results.XML_CONTENT.getClobVal() FROM DOCUMENTCLASSES results where 1=1 '
  ;
BEGIN
  IF (SCOPEARG   IS NOT NULL) THEN
    selectClause := selectClause || ' AND results.SCOPE=''' || SCOPEARG || ''''
    ;
  END IF;
  IF (CATEGORYARG IS NOT NULL) THEN
    selectClause  := selectClause || ' AND results.CATEGORY=''' || CATEGORYARG
    || '''';
  END IF;
  IF(ACTIVE       ='true') THEN
    selectClause := selectClause || 'AND results.ACTIVE='''|| ACTIVE ||'''';
  ELSE
    selectClause := selectClause ||
    'AND results.ID_VERSION = (select max(CAST(t.ID_VERSION AS INT)) from documentclasses t where results.ID_VALUE=t.ID_VALUE and results.ID_ISSUER=t.ID_ISSUER and t.SCOPE='''
    || SCOPEARG || ''' )';
  END IF;
  OPEN documentClassCursor FOR selectClause;
END search;


PROCEDURE UPDATE_CLASSES
  (
    DocumentClassesToUpdate IN ${USR_APP}.ClobArray
  )
AS
  xml XMLType;
BEGIN
  FOR i IN 1 .. DocumentClassesToUpdate.count
  LOOP
    xml :=xmltype
    (
      DocumentClassesToUpdate(i)
    )
    ;
    UPDATE /*+INDEX(t documentclass_pk)*/ documentClasses t
    SET
      t.XML_CONTENT=xml
    WHERE
      t.ID_VALUE = extractValue(xml, '/docclass:DocumentClass/common:ClassId',
      CLASS_NS)
    AND t.ID_ISSUER = extractValue(xml,
      '/docclass:DocumentClass/common:ClassId/@Issuer',CLASS_NS)
    AND t.ID_VERSION = extractValue(xml,
      '/docclass:DocumentClass/common:ClassId/@VersId',CLASS_NS)
    AND t.SCOPE = extractValue(xml, '/docclass:DocumentClass/docclass:Scope',
      CLASS_NS) ;
  END LOOP;
END;

PROCEDURE UPDATE_CLASSES_SINGLE
  (
    DocumentClassToUpdate IN Clob
  )
AS
  xml XMLType;
BEGIN
    xml :=xmltype(DocumentClassToUpdate);
    
    UPDATE /*+INDEX(t documentclass_pk)*/ documentClasses t
    SET
      t.XML_CONTENT=xml
    WHERE
      t.ID_VALUE = extractValue(xml, '/docclass:DocumentClass/common:ClassId',
      CLASS_NS)
    AND t.ID_ISSUER = extractValue(xml,
      '/docclass:DocumentClass/common:ClassId/@Issuer',CLASS_NS)
    AND t.ID_VERSION = extractValue(xml,
      '/docclass:DocumentClass/common:ClassId/@VersId',CLASS_NS)
    AND t.SCOPE = extractValue(xml, '/docclass:DocumentClass/docclass:Scope',
      CLASS_NS) ;
END;


PROCEDURE GET(
    p_scope  IN VARCHAR2,
    ClassIds IN ${USR_APP}.VarcharArray,
    ClassesFetched OUT SYS_refcursor )
AS
BEGIN
  OPEN ClassesFetched FOR SELECT /*+INDEX(t documentclass_pk)*/ t.XML_CONTENT.getClobVal() FROM
  documentClasses t WHERE (t.ID_VALUE, t.ID_ISSUER, t.ID_VERSION) IN
  (
    SELECT
      extractValue(xmltype(column_value),'common:ClassId',CLASS_NS),
      extractValue(xmltype(column_value),'common:ClassId/@Issuer',CLASS_NS),
      extractValue(xmltype(column_value),'common:ClassId/@VersId',CLASS_NS)
    FROM
      TABLE(ClassIds)
  )
  AND p_scope=t.SCOPE;
END GET;

PROCEDURE GETALLVERSIONS(
    p_scope  IN VARCHAR2,
    ClassIds IN ${USR_APP}.VarcharArray,
    ClassesFetched OUT SYS_refcursor )
AS
BEGIN
  OPEN ClassesFetched FOR SELECT /*+INDEX(t documentclass_pk)*/ t.XML_CONTENT.getClobVal() FROM
  documentClasses t WHERE (t.ID_VALUE, t.ID_ISSUER) IN
  (
    SELECT
      extractValue(xmltype(column_value),'common:ClassId',CLASS_NS),
      extractValue(xmltype(column_value),'common:ClassId/@Issuer',CLASS_NS)
    FROM
      TABLE(ClassIds)
  )
  AND p_scope=t.SCOPE;
END GETALLVERSIONS;


PROCEDURE SETACTIVE(
    p_scope     IN VARCHAR2,
    ClassID_ARG IN ${USR_APP}.VarcharArray,
    activate    IN VARCHAR2,
    updateDate  IN VARCHAR2)
AS
  XML_TMP XMLType;
  id XMLType;
BEGIN
  FOR i IN 1 .. ClassID_ARG.count
  LOOP
    id := xmltype(ClassID_ARG(i));
    SELECT
      t.XML_CONTENT
    INTO
      XML_TMP
    FROM
      documentclasses t
    WHERE
      t.ID_VALUE     = extractValue(id, '/common:ClassId',CLASS_NS)
    AND t.ID_ISSUER  = extractValue(id, '/common:ClassId/@Issuer',CLASS_NS)
    AND t.ID_VERSION = extractValue(id, '/common:ClassId/@VersId',CLASS_NS)
    AND t.SCOPE      = p_scope;
    UPDATE
      DOCUMENTCLASSES t
    SET
      XML_CONTENT = UPDATEXML(XML_TMP,
      '/docclass:DocumentClass/docclass:Active/text()', activate,
      '/docclass:DocumentClass/docclass:LastUpdateDate/text()', updateDate,
      CLASS_NS)
    WHERE
      t.ID_VALUE     = extractValue(id, '/common:ClassId',CLASS_NS)
    AND t.ID_ISSUER  = extractValue(id, '/common:ClassId/@Issuer',CLASS_NS)
    AND t.ID_VERSION = extractValue(id, '/common:ClassId/@VersId',CLASS_NS)
    AND t.SCOPE      = p_scope;
  END LOOP;
END SETACTIVE;


PROCEDURE DELETECLASS(
    p_scope     IN VARCHAR2,
    ClassID_ARG IN ${USR_APP}.VarcharArray)
AS
  id XMLType;
BEGIN
  FOR i IN 1 .. ClassID_ARG.count
  LOOP
    id := xmltype(ClassID_ARG(i));
    DELETE
      DOCUMENTCLASSES t
    WHERE
      t.ID_VALUE     = extractValue(id, '/common:ClassId',CLASS_NS)
    AND t.ID_ISSUER  = extractValue(id, '/common:ClassId/@Issuer',CLASS_NS)
    AND t.ID_VERSION = extractValue(id, '/common:ClassId/@VersId',CLASS_NS)
    AND t.SCOPE      = p_scope;
  END LOOP;
END DELETECLASS;

END PKG_DOCUMENTCLASS; 
/
