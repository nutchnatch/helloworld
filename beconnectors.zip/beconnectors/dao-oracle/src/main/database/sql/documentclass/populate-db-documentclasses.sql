Insert into DOCUMENTCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'0c210550-c591-4747-b40e-10813de53d71',
'0',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><docclass:DocumentClass xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1">
   <common:ClassId Issuer="CARDIF" VersId="0">0c210550-c591-4747-b40e-10813de53d71</common:ClassId>
   <docclass:ShortLabel language="FR">
      <i18n:value>Contrat</i18n:value>
   </docclass:ShortLabel>
   <docclass:ShortLabel language="EN">
      <i18n:value>Contract</i18n:value>
   </docclass:ShortLabel>
   <docclass:LongLabel>Contract</docclass:LongLabel>
   <docclass:Scope>Syldavia</docclass:Scope>
   <docclass:Active>true</docclass:Active>
   <docclass:Category>DOCUMENT</docclass:Category>
	<docclass:RetentionDuration TimeUnit="MONTH">1</docclass:RetentionDuration>
   <docclass:CreateDate>2014-05-26 12:38:25.547 CEST</docclass:CreateDate>
   <docclass:TagReference symbolicName="policy" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="ContractType" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="ContractEndDate" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="SubscriberId" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="SubscriberName" mandatory="true" multivalued="true"/>
</docclass:DocumentClass>'))
/

Insert into DOCUMENTCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'878504d1-a284-46d6-b10f-c857f57e337a',
'0',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><docclass:DocumentClass xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1">
   <common:ClassId Issuer="CARDIF" VersId="0">878504d1-a284-46d6-b10f-c857f57e337a</common:ClassId>
   <docclass:ShortLabel language="FR">
      <i18n:value>Email</i18n:value>
   </docclass:ShortLabel>
   <docclass:ShortLabel language="EN">
      <i18n:value>Email</i18n:value>
   </docclass:ShortLabel>
   <docclass:LongLabel>Email</docclass:LongLabel>
   <docclass:Scope>Syldavia</docclass:Scope>
   <docclass:Active>true</docclass:Active>
   <docclass:Category>ENVELOPE</docclass:Category>
	<docclass:FirstLevel>true</docclass:FirstLevel>
	<docclass:RetentionDuration TimeUnit="MONTH">1</docclass:RetentionDuration>
   <docclass:CreateDate>2014-05-26 12:41:30.196 CEST</docclass:CreateDate>
   <docclass:TagReference symbolicName="partner" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="email" mandatory="true" multivalued="true"/>
</docclass:DocumentClass>'))
/

Insert into DOCUMENTCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'71c3c79f-c7fd-48bb-a4e8-6a335698ea81',
'0',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><docclass:DocumentClass xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1">
   <common:ClassId Issuer="CARDIF" VersId="0">71c3c79f-c7fd-48bb-a4e8-6a335698ea81</common:ClassId>
   <docclass:ShortLabel language="FR">
      <i18n:value>Constat</i18n:value>
   </docclass:ShortLabel>
   <docclass:ShortLabel language="EN">
      <i18n:value>Claim</i18n:value>
   </docclass:ShortLabel>
   <docclass:LongLabel>Claim</docclass:LongLabel>
   <docclass:Scope>Syldavia</docclass:Scope>
   <docclass:Active>true</docclass:Active>
   <docclass:Category>DOCUMENT</docclass:Category>
	<docclass:RetentionDuration TimeUnit="MONTH">1</docclass:RetentionDuration>
   <docclass:CreateDate>2014-05-26 12:39:52.864 CEST</docclass:CreateDate>
   <docclass:TagReference symbolicName="policy" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="ClaimType" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="ContractType" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="SubscriberId" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="SubscriberName" mandatory="true" multivalued="true"/>
</docclass:DocumentClass>'))
/

Insert into DOCUMENTCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'c67c3811-1459-483d-b907-a701ebf47bed',
'0',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><docclass:DocumentClass xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1">
   <common:ClassId Issuer="CARDIF" VersId="0">c67c3811-1459-483d-b907-a701ebf47bed</common:ClassId>
   <docclass:ShortLabel language="FR">
      <i18n:value>Rapport Medical</i18n:value>
   </docclass:ShortLabel>
   <docclass:ShortLabel language="EN">
      <i18n:value>Medical Report</i18n:value>
   </docclass:ShortLabel>
   <docclass:LongLabel>Medical Report</docclass:LongLabel>
   <docclass:Scope>Syldavia</docclass:Scope>
   <docclass:Active>true</docclass:Active>
   <docclass:Category>DOCUMENT</docclass:Category>
<docclass:RetentionDuration TimeUnit="MONTH">1</docclass:RetentionDuration>
   <docclass:CreateDate>2014-05-26 12:40:56.254 CEST</docclass:CreateDate>
   <docclass:TagReference symbolicName="policy" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="ContractType" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="SubscriberId" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="SubscriberName" mandatory="true" multivalued="true"/>
</docclass:DocumentClass>'))
/

Insert into DOCUMENTCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'636c7975-d653-4bdc-bd4d-1ec9efc83dde',
'0',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><docclass:DocumentClass xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1">
   <common:ClassId Issuer="CARDIF" VersId="0">636c7975-d653-4bdc-bd4d-1ec9efc83dde</common:ClassId>
   <docclass:ShortLabel language="FR">
      <i18n:value>Web Form</i18n:value>
   </docclass:ShortLabel>
   <docclass:ShortLabel language="EN">
      <i18n:value>Web Form</i18n:value>
   </docclass:ShortLabel>
   <docclass:LongLabel>Web Form</docclass:LongLabel>
   <docclass:Scope>Syldavia</docclass:Scope>
   <docclass:Active>true</docclass:Active>
   <docclass:Category>ENVELOPE</docclass:Category>
   <docclass:FirstLevel>true</docclass:FirstLevel>
	<docclass:RetentionDuration TimeUnit="MONTH">1</docclass:RetentionDuration>
   <docclass:CreateDate>2014-05-26 12:42:17.448 CEST</docclass:CreateDate>
   <docclass:TagReference symbolicName="parentApp" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="partner" mandatory="true" multivalued="true"/>
</docclass:DocumentClass>'))
/

Insert into DOCUMENTCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'05440c0e-bfd8-446d-a1fe-dd45d7335983',
'0',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><docclass:DocumentClass xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1">
   <common:ClassId Issuer="CARDIF" VersId="0">05440c0e-bfd8-446d-a1fe-dd45d7335983</common:ClassId>
   <docclass:ShortLabel language="FR">
      <i18n:value>Subscription Form</i18n:value>
   </docclass:ShortLabel>
   <docclass:ShortLabel language="EN">
      <i18n:value>Subscription Form</i18n:value>
   </docclass:ShortLabel>
   <docclass:LongLabel>Subscription Form</docclass:LongLabel>
   <docclass:Scope>Syldavia</docclass:Scope>
   <docclass:Active>true</docclass:Active>
   <docclass:Category>DOCUMENT</docclass:Category>
	<docclass:RetentionDuration TimeUnit="MONTH">1</docclass:RetentionDuration>
   <docclass:CreateDate>2014-05-26 12:37:36.090 CEST</docclass:CreateDate>
   <docclass:TagReference symbolicName="ContractType" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="ProspectId" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="ProspectName" mandatory="true" multivalued="true"/>
</docclass:DocumentClass>'))
/

Insert into DOCUMENTCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'b21ba156-f5be-407e-a0b5-6c74aedea9ee',
'0',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><docclass:DocumentClass xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1">
   <common:ClassId Issuer="CARDIF" VersId="0">b21ba156-f5be-407e-a0b5-6c74aedea9ee</common:ClassId>
   <docclass:ShortLabel language="FR">
      <i18n:value>Courrier Papier</i18n:value>
   </docclass:ShortLabel>
   <docclass:ShortLabel language="EN">
      <i18n:value>Paper Mail</i18n:value>
   </docclass:ShortLabel>
   <docclass:LongLabel>Paper Mail</docclass:LongLabel>
   <docclass:Scope>Syldavia</docclass:Scope>
   <docclass:Active>true</docclass:Active>
   <docclass:Category>ENVELOPE</docclass:Category>
   <docclass:FirstLevel>true</docclass:FirstLevel>
   <docclass:CreateDate>2014-05-26 12:43:12.631 CEST</docclass:CreateDate>
   <docclass:RetentionDuration TimeUnit="MONTH">1</docclass:RetentionDuration>
   <docclass:TagReference symbolicName="adress" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="partner" mandatory="true" multivalued="true"/>
</docclass:DocumentClass>'))
/

Insert into DOCUMENTCLASSES (SCOPE,ID_VALUE,ID_VERSION,ID_ISSUER,XML_CONTENT) values (
'Syldavia',
'54rba156-f5be-407e-a0b5-6c74aedea942',
'0',
'CARDIF',
XMLType('<?xml version = "1.0" encoding = "UTF-8" standalone = "yes"?><docclass:DocumentClass xmlns:docclass="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1">
   <common:ClassId Issuer="CARDIF" VersId="0">54rba156-f5be-407e-a0b5-6c74aedea942</common:ClassId>
   <docclass:ShortLabel language="FR">
      <i18n:value>Classe inactive</i18n:value>
   </docclass:ShortLabel>
   <docclass:ShortLabel language="EN">
      <i18n:value>unactive class</i18n:value>
   </docclass:ShortLabel>
   <docclass:LongLabel>unactive class</docclass:LongLabel>
   <docclass:Scope>Syldavia</docclass:Scope>
   <docclass:Active>false</docclass:Active>
   <docclass:Category>ENVELOPE</docclass:Category>
   <docclass:FirstLevel>true</docclass:FirstLevel>
	<docclass:RetentionDuration TimeUnit="MONTH">1</docclass:RetentionDuration>
   <docclass:CreateDate>2014-05-26 12:43:12.631 CEST</docclass:CreateDate>
   <docclass:TagReference symbolicName="adress" mandatory="true" multivalued="true"/>
   <docclass:TagReference symbolicName="partner" mandatory="true" multivalued="true"/>
</docclass:DocumentClass>'))
/
