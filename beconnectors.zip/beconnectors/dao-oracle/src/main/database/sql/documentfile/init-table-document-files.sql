CREATE TABLE ${USR_DOC}.DOCUMENTFILES (
  ELEMENT       XMLType ,
  SCOPE         VARCHAR2(180),
  URI           VARCHAR2(136),
  BINARY        BLOB,
  constraint documentfile_pk primary key (SCOPE, URI) 
)
TABLESPACE ${DOC_TABLESPACE_DATA}
/
