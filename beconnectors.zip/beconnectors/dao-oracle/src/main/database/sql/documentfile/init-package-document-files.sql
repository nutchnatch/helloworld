CREATE OR REPLACE
PACKAGE ${USR_DOC}.PKG_DOCUMENTFILE
IS
  PROCEDURE store
        (
	        p_ELEMENT	IN VARCHAR2 ,
	        p_BINARY	IN DOCUMENTFILES.BINARY%type DEFAULT NULL 
        );

	PROCEDURE GET
	(
   	 	SCOPE_IN        IN VARCHAR2 , 
            	URI_IN          IN VARCHAR2, 
   		ELEMENT_OUT     out VARCHAR2,
    	        DATA_OUT        out BLOB
	);
	
	PROCEDURE DELETE_FILE
	(
   	 	SCOPE_IN        IN VARCHAR2 , 
    	        URI_IN          IN VARCHAR2 
   	);
END PKG_DOCUMENTFILE;
/

CREATE OR REPLACE PACKAGE body ${USR_DOC}.PKG_DOCUMENTFILE
IS
  PROCEDURE store(
	p_ELEMENT		IN VARCHAR2,
	p_BINARY		IN DOCUMENTFILES.BINARY%type DEFAULT NULL )
AS
  xml XMLType := XMLType(p_ELEMENT);
BEGIN
  INSERT
  INTO
    DOCUMENTFILES
    (
      ELEMENT,
      SCOPE,
      URI,
      BINARY
    )
    VALUES
    (
      xml,
      xml.extract('/file:DocumentFile/@Scope', 'xmlns:file="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"').getStringVal(),
      xml.extract('/file:DocumentFile/common:URI/text()', 'xmlns:file="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"').getStringVal(),
      p_BINARY
    );
END;
PROCEDURE GET
(
    SCOPE_IN IN VARCHAR2 , 
    URI_IN IN VARCHAR2, 
    ELEMENT_OUT out VARCHAR2,
    DATA_OUT out BLOB
)
AS 
    TMP_XML XMLType;
BEGIN
    SELECT ELEMENT, BINARY INTO TMP_XML, data_out  FROM DOCUMENTFILES t WHERE t.SCOPE=SCOPE_IN and t.URI=URI_IN;
    ELEMENT_OUT:= TMP_XML.getStringVal();
END;

PROCEDURE DELETE_FILE
	(
   	 	SCOPE_IN IN VARCHAR2 , 
            	URI_IN IN VARCHAR2 
   	)
   AS
   BEGIN 
	   DELETE from DOCUMENTFILES t where t.SCOPE=SCOPE_IN and t.URI=URI_IN;
   end;
END PKG_DOCUMENTFILE;
/

