CREATE OR REPLACE PACKAGE  ${USR_META}.PKG_TOOLS


    -- 2014  -  SUGAR PROJECT
    -- V1.0
    -- BNPPARIBAS CARDIF
    -- PACKAGE HELPER FOR SUGAR DOCUMENT AND FOLDER MANAGEMENT
    -- SEARCH GENERIC ENGINE
    -- TRACELOG MECHANISM
  



IS


  -- minimum base date for indexation (= 01/01/1800)
    MIN_JULIAN_DATE CONSTANT INTEGER :=2378497;

    -- size encoding for date  2^20 =256.000 days.. 
    -- max date = MIN_JULIAN_DATE +2^ENCODING_DATE_SIZE
    -- with MIN_JULIAN_DATE=01/01/1800 and ENCODING_DATE_SIZE=20   max = 01/01/2500 
    ENCODING_DATE_SIZE CONSTANT INTEGER :=20; 
    
    ENCODING_NUMBER_SIZE CONSTANT INTEGER :=40;

    -- encoding base can be from 2   to 36
    -- for space reduction... avoid any base lower than 10, prefer use the maximum  36
    -- for indexing performance use 10.
    ENCODING_BASE CONSTANT INTEGER :=10;
  
    -- base string for to_base     function.
    base36str CONSTANT varchar(36) := '0123456789abcdefghijklmnopqrstuvwxyz';




-- /**
  -- Dom Help Function  for attribute
  -- INTERNAL USE
-- */

function getStrAttrValue(elem DBMS_XMLDOM.DOMElement,nameAttr varchar2,def varchar2) return varchar2;
function getIntAttrValue(elem DBMS_XMLDOM.DOMElement,nameAttr varchar2,def integer) return integer;

-- /**
   -- Get filter ( contains ) from xml request.
   -- INTERNAL USE
-- */
function getFilter(elemFilter DBMS_XMLDOM.DOMElement) return varchar2;


-- /*******************************************************************
   -- Get Order string
   -- replace expresion with corresponding xmlquery if required
   -- INTERNAL USE
-- ****************************************************************/
function getOrder(docelemRequest DBMS_XMLDOM.DOMElement, p_OrderNs varchar2) return varchar2;


-- /*************************************************************************************************
 -- TRACE LOG PROCEDURE
       -- ptraceLevel >0  --> trace using dbms_output
       -- ptraceLevel <0 --> trace in dbtable
       -- ptraceLevel =0 --> no trace
       
       -- NB : AUTONOMOUS_TRANSACTION ( no rollback in case of  any exception outside the proc)
-- **************************************************************************************************/

-- Get number of cursor for active session
PROCEDURE GETCURRENTSESSIONCURSOR(SCOPE_USER IN VARCHAR2, NB_CURSOR OUT NUMBER);

procedure traceLog( p_requestId  in varchar2 ,ptraceLevel integer, ptraceRequired integer, ptextTrace varchar2);

-- /*********************************************************************************************************
  -- DO a XML text search on object (doc, folder,etc) 
  -- with
      -- pagination
      -- filters (contains clause)
      -- order
-- **********************************************************************************************************
-- */
 PROCEDURE  searchOject(
    p_scope     IN VARCHAR2,              
			-- scope
    p_pagestart     IN NUMBER,            
			-- pagination : first element
    p_pagesize       IN NUMBER,           
			-- pagination : size of the page  NB!!! :use 0 if you just want to make simple count !
    p_filters     IN VARCHAR2,              
			-- filters : any xpath expression link to the contains 
    p_orderClause IN VARCHAR2,              
			-- order clause 
    p_limitSearch    IN NUMBER,       
			-- limit the search to values...  
                                        -- /*sample : 1000
                                        -- NB   : this is usefull to avoid useless sorting (order by) billion of record 
                                        -- it will dramatically impact performance asa an order clause is provided*/
    pout_objectCursor OUT SYS_REFCURSOR,  
			-- cursor out 
    pout_resultCount OUT NUMBER,               
			-- OUT nb count find
    p_lang in varchar2 default 'ENGLISH', 
			-- lang (for soundex, sterm, etc..)
    p_requestId  in varchar2 default null, 
			-- request ID .. any token text (likee UUID).. if null, a random new one is created
                                          -- /* for JAVA USAGE.. provide any identifier that can be relevant to share with Oracle Procedure 
                                          -- for trace in db trace table (SUGARDBLOG)
                                          -- */
    p_traceLevel integer default 0 ,     
			-- trace level
                                          -- /* usage : if >0 then dbms_output.put_line is used 
                                                     -- if <0 then db table  SUGARDBLOG is used  
                                                    -- if =0 no trace is provided (even in case of exception ....)
                                                    
                                                    -- if abs( p_traceLevel) =1 --> only exception are logged
                                                    -- if abs( p_traceLevel) =2 -->  exception and info are logged
                                                    -- if abs( p_traceLevel) =3 -->  exception , inf, debug o are logged */
    p_tableQuery    in varchar2  ,                     
			-- /* table where to do the search  DOCUMENTS, FOLDER by default */
    p_indexName   in varchar2                         
			-- /* CONTEXT INDEX TO USE */
    
                                            
   );

  
     -- encoding method used by filter
     function encodeValue ( numValue INTEGER ,psize simple_integer , pbase simple_integer) return varchar2 ;
     
     --encoding method use by search engine
     function encodeGTorLtValue ( numValue INTEGER, bigger INTEGER,psize simple_integer , pbase simple_integer) return varchar2;
     
     -- to base function
     function to_base( no in INTEGER , pbase simple_integer ) return varchar2;
   
     --generic filtering function for indeing using context (user_datastore)  
     procedure filter(xmlContent IN XMLTYPE,output IN OUT NOCOPY CLOB) ;
END PKG_TOOLS;
/

CREATE OR REPLACE PACKAGE body ${USR_META}.PKG_TOOLS
IS

-- /************************************************
   -- Get a string attribute from a tag element
-- **************************************************/
function getStrAttrValue(elem DBMS_XMLDOM.DOMElement,nameAttr varchar2,def varchar2) return varchar2
is
  ltagAttrValue varchar2(4000);
begin
   ltagAttrValue:=DBMS_XMLDOM.GETATTRIBUTE(elem,nameAttr);
   if (ltagAttrValue is null) then
      ltagAttrValue:=def;
   end if;
   
   return ltagAttrValue;
end;


-- /****************************************************
   -- Get an integer attribute from a tag element
-- *****************************************************/
function getIntAttrValue(elem DBMS_XMLDOM.DOMElement,nameAttr varchar2,def integer) return integer
is
  ltagAttrValue varchar2(4000) ;
  ltagValue integer;
begin
   ltagAttrValue :=getStrAttrValue(elem,nameAttr,def||'');
   ltagValue:=to_number(ltagAttrValue);
   return ltagValue;
end;


PROCEDURE GETCURRENTSESSIONCURSOR
  (
    SCOPE_USER IN VARCHAR2,
    NB_CURSOR OUT NUMBER
  )
IS
    CURRENT_SID NUMBER;
    CURRENT_SERIAL NUMBER;
BEGIN
    SELECT sid, serial# INTO CURRENT_SID, CURRENT_SERIAL
        FROM v$session WHERE audsid = sys_context('userenv','sessionid');
    SELECT a.value INTO NB_CURSOR FROM v$session s JOIN v$sesstat a ON s.sid = a.sid
        JOIN v$statname b ON a.statistic# = b.statistic#
        WHERE b.name = 'opened cursors current' AND s.username = SCOPE_USER
        AND s.sid = CURRENT_SID and s.serial# = CURRENT_SERIAL;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            NB_CURSOR := 0;
END;
     
-- /*******************************************************
   -- Get SQL CONTAINS filter ( contains ) from xml Query request.
   -- INTERNAL USE
-- *********************************************************/
function getFilter(elemFilter DBMS_XMLDOM.DOMElement) return varchar2

is
  nodelist      DBMS_XMLDOM.DOMNodeList;
  lchildTag    DBMS_XMLDOM.DOMNode; 
  lchildelem    DBMS_XMLDOM.DOMElement;
  llength       INTEGER;
  lfilter      VARCHAR2(16000) :=null;
  loperand  VARCHAR2(16000) :=null;
  loperator     VARCHAR2(160);
  ltypeOperand   VARCHAR2(160);
  lpathValue VARCHAR2(16000) :=null;
  lmask  VARCHAR2(160);
  lgt   integer;
  lvalueGtorLt integer;
  lbequal boolean;
  
begin
   
   --finding child "filter" tag
   -- if find --> group tag principle
   --      no --> single filter .
   nodelist := DBMS_XMLDOM.GETCHILDRENBYTAGNAME(elemFilter, 'filter');
   -- GROUP FILTER
   -- /*
        -- <filter logicalOperator="AND">
             -- <filter>
                        -- ...
             -- </filter>      
              
              -- <filter>
                        -- ...
             -- </filter>      
      -- </filter>
   -- */
   if (not DBMS_XMLDOM.isNull(nodeList) and  DBMS_XMLDOM.GetLength(nodeList)>0) then
     llength := DBMS_XMLDOM.GetLength(nodeList);
     -- inner bracket
     lfilter:='( ';
        
     FOR i IN 0 .. llength - 1 LOOP
         lchildTag := DBMS_XMLDOM.Item(nodeList, i);
         lchildelem := DBMS_XMLDOM.MAKEELEMENt(lchildTag);
        
         -- group operator
         if (i>0) then
              lfilter := lfilter||' 
              '||getStrAttrValue(elemFilter,'logicalOperator','AND')||' ';
          end if;
          
           -- recursive call 
          lfilter:=lfilter || getFilter(lchildelem);
          
     END LOOP;
       -- outer bracket
     lfilter:=lfilter||' )';
  
   --SIMPLE FILTER
    -- /*
        -- <path></path>
        -- <operator></operator>
        -- <operand type=""></operand>  
     -- */
   else
   
      -- operand
      nodelist :=   DBMS_XMLDOM.GETCHILDRENBYTAGNAME(elemFilter, 'operand');
      if (not DBMS_XMLDOM.isNull(nodeList)) then
          loperand:=DBMS_XMLDOM.getNodeValue(DBMS_XMLDOM.GETFIRSTCHILD(DBMS_XMLDOM.item(nodelist, 0)));
          if loperand is not null then              
              ltypeOperand :=lower(getStrAttrValue(DBMS_XMLDOM.makeelement(DBMS_XMLDOM.item(nodelist, 0)),'type','string'));
          end if;
      end if;
      
       -- operator
      nodelist :=   DBMS_XMLDOM.GETCHILDRENBYTAGNAME(elemFilter, 'operator');
      if (not DBMS_XMLDOM.isNull(nodeList)) then
          loperator := DBMS_XMLDOM.GetNodeValue(DBMS_XMLDOM.GETFIRSTCHILD(DBMS_XMLDOM.item(nodelist, 0)));
      end if;
    
     -- path 
      nodelist :=   DBMS_XMLDOM.GETCHILDRENBYTAGNAME(elemFilter, 'path');
      if (not DBMS_XMLDOM.isNull(nodeList)) then
        lpathValue := DBMS_XMLDOM.GetNodeValue(DBMS_XMLDOM.GETFIRSTCHILD(DBMS_XMLDOM.item(nodelist, 0)));
       
      end if;
     
     --  operator treatment
     --  DEFAULT
      if ((loperator is null or loperator='=') and lpathValue is not null) then
            loperator :='INPATH';
      end if;
      
    
      -- GREATER(or equal) THAN OR LOWER (or equal) THAN
      if (substr(loperator,1,1) ='>' or substr(loperator,1,1) ='<') then 
      
          -- GREATER or LOWER ?
          if (substr(loperator,1,1) = '>' ) then
            --greater
            lgt:=1;
          else
            --lower
            lgt:=0;
          end if;
          
          -- EQUAL ?
          if (substr(loperator,2,1) = '=' ) then
              lbequal:=true;
           else   
              lbequal :=false;
          end if;
          
          --DATE or DATETIME ?
          if (lower(ltypeOperand)='date' or lower(ltypeOperand)='datetime') then
            if (ltypeOperand='date')  then           
              lmask:='YYYY-MM-DD';
             
            else
              lmask:='YYYY-MM-DD HH24:MI:SS';
            end if;        
             lpathValue:=lpathValue||'/@tokenDate';
             lvalueGtorLt :=to_number(to_char(to_date(loperand,lmask),'j')) -MIN_JULIAN_DATE;             
      
         end if; 
          
          --NUMBER ?
          if (lower(ltypeOperand)='number') then
             lpathValue:=lpathValue||'/@tokenNumber';
			 IF(INSTR(loperand,'.')>0) THEN
              loperand:= SUBSTR(loperand,1,INSTR(loperand,'.')-1) ;
              END IF;
			IF(instr(loperand,',')>0) THEN
              loperand:= SUBSTR(loperand,1,INSTR(loperand,',')-1);
              END IF;
             lvalueGtorLt :=to_number(loperand);   
          end if;
             
          -- +1 if >=  ...
          if (lbequal and lgt=1) then
                 lvalueGtorLt:=lvalueGtorLt-1;
          end if;
           
           --... -1 if <=  
          if (lbequal and lgt=0) then
                 lvalueGtorLt:=lvalueGtorLt+1;
          end if;
          
          -- go !
          if (lower(ltypeOperand)='date' and lvalueGtorLt>=0) then
              loperand:=encodeGTorLtValue(lvalueGtorLt,lgt,ENCODING_DATE_SIZE,ENCODING_BASE);
              loperator :='INPATH';
          end if;    
          
         -- go !
          if (lower(ltypeOperand)='number' and lvalueGtorLt>=0)  then
              loperand:=encodeGTorLtValue(lvalueGtorLt,lgt,ENCODING_NUMBER_SIZE,ENCODING_BASE);
              loperator :='INPATH';
          end if;    
     else 
           -- EQUAL OPERATOR APPLIED
           
           --DATE
           if ( lower(ltypeOperand)='date') then
             lpathValue:=lpathValue||'/@valueDate';
             loperand:=to_number(to_char(to_date(loperand,'YYYY-MM-DD'),'J'))-MIN_JULIAN_DATE;
           end if;
         
           -- NUMBER
           if ( lower(ltypeOperand)='number') then 
             lpathValue:=lpathValue||'/@valueNumber';
             loperand:=to_char(trunc(to_number(loperand)));
           end if;
      
     end if;
     
     --ADD OPERAND +  OPERATOR +PATH
     if (loperand is not null) then  
       lfilter:='("'|| loperand ||'")';
     end if;  
     
     if (loperator is not null) then  
       lfilter:=lfilter||' '|| loperator ||' ';
     end if; 
   
     if ( lpathValue is not null) then  
      lfilter:=lfilter||'( '|| lpathValue ||' )';
     end if;  
   end if;
   
   return lfilter;
end;


-- /*************************************************************
   -- Get SQL Order string from Query Request
   -- replace expresion with corresponding xmlquery if required
   -- INTERNAL USE
-- **************************************************************/
function getOrder(docelemRequest DBMS_XMLDOM.DOMElement, p_OrderNs varchar2) return varchar2

 is
  nodelist      DBMS_XMLDOM.DOMNodeList;
  lchildTag    DBMS_XMLDOM.DOMNode; 
  elemFilter DBMS_XMLDOM.DOMElement;
  llength       INTEGER;
  lorder      VARCHAR2(16000) :=null;
  lorderCl  VARCHAR2(16000) :=null;
  ldirection varchar2(80);

begin

  --default order 
    lorder:= 'updatedate desc';
  
   NodeList :=DBMS_XMLDOM.getElementsByTagName(docelemRequest, 'order');
      if (not DBMS_XMLDOM.isNull(nodeList)) then        
       elemFilter:= DBMS_XMLDOM.MAKEELEMENt(DBMS_XMLDOM.item(nodelist, 0));   
        
    --finding child "orderKey" tag
       nodelist := DBMS_XMLDOM.GETCHILDRENBYTAGNAME(elemFilter, 'orderKey');
       if (not DBMS_XMLDOM.isNull(nodeList) and  DBMS_XMLDOM.GetLength(nodeList)>0) then
         llength := DBMS_XMLDOM.GetLength(nodeList);
         lorder:='';
        
         FOR i IN 0 .. llength - 1 LOOP
             lchildTag := DBMS_XMLDOM.Item(nodeList, i);
             lorderCl := DBMS_XMLDOM.getNodeValue(DBMS_XMLDOM.GETFIRSTCHILD(lchildTag));
          
             -- tokenize order by clause
            IF ( lorderCl IS NOT NULL) THEN
              
              if (lorder is not null) then
                  lorder:=lorder||',';
              end if;
            
              -- removing useless blank
              lorderCl :=rtrim(lorderCl);
    
              -- direction .. ASC by default
              ldirection := getStrAttrValue( DBMS_XMLDOM.makeElement(lchildTag),'direction','ASC')  ;
              
              -- expression xpath ? (le order contien un / quelque part...
              -- alors on fait une xquery et on CAST (xmlcast)
              if (instr(lorderCl,'/')!=0) then
                  lorderCl  := ' xmlcast(xmlquery('''|| p_OrderNs || ' 
                                    for $i in '||lorderCl||' return $i''  PASSING xml_content   RETURNING CONTENT ) as varchar2(2000)) ';                    
               end if;
               
               -- direction can be desc or asc
               lorder:=lorder || lorderCl||' '||ldirection;
               end if;
            END LOOP;
       end if;
   
      end if;
      
  
return lorder;

end;


-- /*************************************************************************************************
 -- TRACE LOG PROCEDURE
       -- ptraceLevel >0  --> trace using dbms_output
       -- ptraceLevel <0 --> trace in dbtable
       -- ptraceLevel =0 --> no trace
       
       -- NB : AUTONOMOUS_TRANSACTION ( no rollback in case of  any exception outside the proc)
-- **************************************************************************************************/

procedure traceLog( p_requestId  in varchar2 ,ptraceLevel integer, ptraceRequired integer, ptextTrace varchar2) as
PRAGMA AUTONOMOUS_TRANSACTION;
begin

  --good level ?
  if (abs(ptraceLevel)>=ptraceRequired) then 
    -- dbms output
    if (ptraceLevel>0) then
      dbms_output.put_line( current_timestamp || ' | ' ||p_requestId||' | '|| ptextTrace );       
      --  dbms_output.put_line( current_timestamp || ' | ' ||p_requestId||' | '|| replace(replace(ptextTrace,chr(13),' '),chr(10),' ') );        
    -- db table  
    else  
       insert into ${USR_REP}.SUGARDBLOG values (current_timestamp,p_requestId,abs(ptraceRequired),substr(ptextTrace,1,4000));
      commit;
    end if;  
  end if;
end;




-- /*********************************************************************************************************
  -- DO a XML text search on object (doc, folder,etc) 
  -- with
      -- pagination
      -- filters (contains clause)
      -- order
-- **********************************************************************************************************
-- */
 PROCEDURE  searchOject(
    p_scope     IN VARCHAR2,              
			-- scope
    p_pagestart     IN NUMBER,            
			-- pagination : first element
    p_pagesize       IN NUMBER,           
			-- pagination : size of the page  NB!!! :use 0 if you just want to make simple count !
    p_filters     IN VARCHAR2,              
			-- filters : any xpath expression link to the contains 
    p_orderClause IN VARCHAR2,              
			-- order clause 
    p_limitSearch    IN NUMBER,       
			-- limit the search to values...  
                                        -- /*sample : 1000
                                           -- NB   : this is usefull to avoid useless sorting (order by) billion of record 
                                                  -- it will dramatically impact performance asa an order clause is provided*/
    pout_objectCursor OUT SYS_REFCURSOR,  
			-- cursor out 
    pout_resultCount OUT NUMBER,               
			-- OUT nb count find
    p_lang in varchar2 default 'ENGLISH', 
			-- lang (for soundex, sterm, etc..)
    p_requestId  in varchar2 default null, 
			-- request ID .. any token text (likee UUID).. if null, a random new one is created
                                          -- /* for JAVA USAGE.. provide any identifier that can be relevant to share with Oracle Procedure 
                                             -- for trace in db trace table (SUGARDBLOG)
                                          -- */
    p_traceLevel integer default 0 ,     
			-- trace level
                                          -- /* usage : if >0 then dbms_output.put_line is used 
                                                     -- if <0 then db table  SUGARDBLOG is used  
                                                    -- if =0 no trace is provided (even in case of exception ....)
                                                    
                                                    -- if abs( p_traceLevel) =1 --> only exception are logged
                                                    -- if abs( p_traceLevel) =2 -->  exception and info are logged
                                                    -- if abs( p_traceLevel) =3 -->  exception , inf, debug o are logged */
    p_tableQuery    in varchar2  ,                    
			-- /* table where to do the search  DOCUMENTS, FOLDER by default */
    p_indexName   in varchar2                        
			-- /* CONTEXT INDEX TO USE */
    
                                            
   )
AS
  
	TEXTQUERY             VARCHAR2(16000);
	CLAUSEWHEREQUERY      VARCHAR2(16000);
	INDEXHINT             VARCHAR2(16000)   := CASE WHEN P_INDEXNAME IS NULL THEN '' ELSE '/*+INDEX( results '||P_INDEXNAME||')*/' END;
	SELECTOBJECTQUERY     VARCHAR2(16000)   := 'SELECT '||INDEXHINT|| ' results.XML_CONTENT as xml_content, score(1) as score ';
	SELECTOBJECTQUERYEND  VARCHAR2(16000)   := ' FROM '|| p_tableQuery || '  results where  rownum<=:p_max  and CONTAINS (results.XML_CONTENT, :textQuery , 1)>0';   
	paginationBeginning   VARCHAR2(16000)   := ' SELECT a.xml_content.getClobVal() AS xml_content_val, a.SCORE, a.R__  FROM  ( ';
	paginationEnd         VARCHAR2(16000)   := ' ) a WHERE r__ < ' || (p_pagestart + p_pagesize) || '   and r__ >= ' || p_pagestart;
	ORDERBEGINING         VARCHAR2(16000)   := 'SELECT b.xml_content, b.score , row_number() over ( ';
	ORDERMIDDLE           VARCHAR2(16000)   := ') AS r__ FROM  ( ';
	ORDEREND              VARCHAR2(16000)   := ') b';
   
BEGIN

      -- /*** 
        -- PREPARATION
        -------    
       -- **/
  -- 1)   FILTERING WITH CONTAINS SPECIFIC CLAUSE PROVIDED
  
  IF (p_filters IS NOT NULL) THEN
      textQuery :='<query>
     <textquery lang="'||p_lang||'">
     ' || p_filters ;
  
    textQuery:=textQuery ||'</textquery>
     <score datatype="INTEGER" algorithm="COUNT"/>
     </query>';
   
    end if;
	
	
	   -- /*** 
        -- EXECUTION
        -------    
    -- **/
 -- END 1 ) COUNT REQUEST 
 -- *********************
  begin
   pout_resultCount:= CTX_QUERY.COUNT_HITS( p_indexName,     textQuery,     TRUE);
     exception
        when others then
      traceLog(p_requestId,p_traceLevel,1, 'error during count with textquery :'||textQuery);
      traceLog(p_requestId,p_traceLevel,1, SQLERRM);
      raise;
  end;
    
    
  --2) order clause
  -- tokenize order by clause
	IF(POUT_RESULTCOUNT > P_LIMITSEARCH) THEN
    	IF (P_ORDERCLAUSE IS NOT NULL) THEN
			SELECTOBJECTQUERY := SELECTOBJECTQUERY || ',updatedate' || SELECTOBJECTQUERYEND;
			ORDERBEGINING := ORDERBEGINING ||'ORDER BY '||P_ORDERCLAUSE||',updatedate DESC'|| ORDERMIDDLE;
		else
			SELECTOBJECTQUERY := SELECTOBJECTQUERY || ',updatedate'  || SELECTOBJECTQUERYEND;
			ORDERBEGINING := ORDERBEGINING || ' ORDER BY  updatedate DESC '|| ORDERMIDDLE;
		end if;
	else
		IF (P_ORDERCLAUSE IS NOT NULL) THEN
			SELECTOBJECTQUERY  := SELECTOBJECTQUERY|| ',updatedate' ||SELECTOBJECTQUERYEND;
			ORDERBEGINING  := ORDERBEGINING || ' ORDER BY ' || P_ORDERCLAUSE ||ORDERMIDDLE;
		END IF; 
	END IF;
	selectObjectQuery:=ORDERBEGINING||selectObjectQuery||ORDEREND;

  --3) pagination
  selectObjectQuery:=paginationBeginning||selectObjectQuery||paginationEnd;
  
  traceLog(p_requestId,p_traceLevel, 3,'        table query => '||p_tableQuery);
  traceLog(p_requestId,p_traceLevel, 3,'              scope => '||p_scope);
  traceLog(p_requestId,p_traceLevel, 3,'          textQuery => '||textQuery);
  traceLog(p_requestId,p_traceLevel, 3,'      p_limitsearch => '||p_limitsearch);
  
  
 
  
   --END 2 ) DOCUMENTS REQUEST 
  -- ************************
  -- if page size=0 then  we juste want to have a quick count
  if (p_pagesize>0) then
     traceLog(p_requestId,p_traceLevel, 3,p_tableQuery|| ' SQL request => '||selectObjectQuery);
     begin
         OPEN pout_objectCursor FOR selectObjectQuery using p_limitsearch, textQuery;     
     exception
        when others then
      traceLog(p_requestId,p_traceLevel,1, selectObjectQuery);
      traceLog(p_requestId,p_traceLevel,1, SQLERRM);
      raise;
     end; 
          
  end if;
 
 
 END;



-- /*********************************************************************************************

    -- PROCEDURE_FILTER for SUGAR INDEXING
    
    -- Specific procedure used by CONTEXT INDEX ORACLE during indexing
    -- see special configuration and parameter for SUGAR_DATATSTORE index Creation
    
    -- USEFULL FOR BOTH DOCUMENT AND FOLDER
    
    -->remove useless TAG in XML before indexing like document id
       -- usefull for avoiding extension of the worlist table (context index) DR$XXXXX$I table
    -- recode date and number to allow range search.

-- ***********************************************************************************************/
procedure filter( xmlContent XMLTYPE ,output IN OUT NOCOPY CLOB) is
 
  doc     DBMS_XMLDOM.DOMDocument;
docelem DBMS_XMLDOM.DOMElement;
nodelist      DBMS_XMLDOM.DOMNodeList;
node   DBMS_XMLDOM.DOMNode;
l_childTag DBMS_XMLDOM.DOMNode;
l_childValue  DBMS_XMLDOM.DOMNode;
l_length  INTEGER :=0;
l_text_content varchar2(16000);
sToken  varchar2(16000);
ldate date;
lValueNumber INTEGER  :=0;
lValueDate INTEGER  :=0;
i INTEGER  :=0;

begin
 
 
   -- Create DOMDocument handle
  doc     := DBMS_XMLDOM.newDOMDocument( xmlContent);
  docelem := DBMS_XMLDOM.getDocumentElement(doc);
    -- remove prefix ? may be not!
  --DBMS_XMLDOM.SETPREFIX (DBMS_XMLDOM.MAKENODE(docelem),null);
  
  -- remove namespace from  indexing ... because completly useless
  DBMS_XMLDOM.REMOVEATTRIBUTE  (docelem,'xmlns:common');
  DBMS_XMLDOM.REMOVEATTRIBUTE  (docelem,'xmlns:doc');
  DBMS_XMLDOM.REMOVEATTRIBUTE  (docelem,'xmlns:folder');
 
 
  -- remove  Doc Id element
  -- usless: a search on id will used firstly the pk ... !! not the context index
  nodelist := DBMS_XMLDOM.getElementsByTagName(docelem, 'Document/Id');
  if (not DBMS_XMLDOM.isNull(nodeList)) then
       node := DBMS_XMLDOM.item(nodelist, 0);
        if (not DBMS_XMLDOM.isNull(node)) then
          -- REMOVE
           node := DBMS_XMLDOM.removechild(DBMS_XMLDOM.getParentNode(node),node);
        end if;
  END IF;
  -- remove FolderId element
   nodelist := DBMS_XMLDOM.getElementsByTagName(docelem, 'FolderId');
  if (not DBMS_XMLDOM.isNull(nodeList)) then
       node := DBMS_XMLDOM.item(nodelist, 0);
        if (not DBMS_XMLDOM.isNull(node)) then
          -- REMOVE
           node := DBMS_XMLDOM.removechild(DBMS_XMLDOM.getParentNode(node),node);
        END IF;
  end if;
 

  --- remove  child object ( use for document)      
  nodelist := DBMS_XMLDOM.getElementsByTagName(docelem, 'ChildObject');
  if (not DBMS_XMLDOM.isNull(nodeList)) then
       node := DBMS_XMLDOM.item(nodelist, 0);
        if (not DBMS_XMLDOM.isNull(node)) then
           -- REMOVE
           node := DBMS_XMLDOM.removechild(DBMS_XMLDOM.getParentNode(node),node);
        end if;
  end if;
  
  --  specific indexation using 
  --- date and Number tokenization
   nodelist := DBMS_XMLDOM.getElementsByTagName(docelem, '*');
   if (not DBMS_XMLDOM.isNull(nodeList)) then
            l_length := DBMS_XMLDOM.GetLength(nodeList);
            FOR i IN 0 .. l_length - 1 LOOP
              l_childTag := DBMS_XMLDOM.Item(nodeList, i);
              
              -- remove prefix ? may be not!
              --DBMS_XMLDOM.SETPREFIX (l_childTag,null);


                  l_childValue :=DBMS_XMLDOM.getFirstChild(l_childTag);
                  if (  not DBMS_XMLDOM.isNull(l_childValue)) then
      
                    -- GO !!
                   IF DBMS_XMLDOM.GetNodeType(l_childValue) IN (DBMS_XMLDOM.TEXT_NODE, DBMS_XMLDOM.CDATA_SECTION_NODE) THEN
                    l_text_content := DBMS_XMLDOM.GetNodeValue(l_childValue);
                   sToken:=null;                 
                  
                    
                        --DATE ? 
                        --   go to encode for range search
                        -- NB : ONLY DATE PART IS INDEXED !!!!!
                        --      TIME IS REMOVE FROM INDEXING BECAUSE USELESS !!!
                        begin                          
                            ldate := to_date (substr(l_text_content,1,10),'YYYY-MM-DD');                          
                            lValueDate :=trunc(to_number(to_char(ldate,'j')))- MIN_JULIAN_DATE;
                            if (lValueDate>=0) then 
                              sToken :=encodevalue(lValueDate,ENCODING_DATE_SIZE,ENCODING_BASE);                                              
                              DBMS_XMLDOM.SETATTRIBUTE(DBMS_XMLDOM.MAKEELEMENt(l_childTag),'tokenDate',sToken);                        
                              DBMS_XMLDOM.SETATTRIBUTE(DBMS_XMLDOM.MAKEELEMENt(l_childTag),'valueDate',lValueDate);
                              -- remove value form node.. because uselesss
                              DBMS_XMLDOM.setNodeValue(l_childValue,null);
                            end if;
                        exception
                          when others then
                            null;
                        end;
                        
                         --NUMBER ?
                        --   go to encode for range search
                        -- NB : ONLY INTEGER PART IS INDEXED
                        --      REAL PART iSremoved
                         if ( sToken is null ) then
                            begin
								IF(INSTR(L_TEXT_CONTENT,'.')>0) THEN
									l_text_content:= SUBSTR(L_TEXT_CONTENT,1,INSTR(L_TEXT_CONTENT,'.')-1) ;
								END IF;
								IF(instr(l_text_content,',')>0) THEN
									l_text_content:= SUBSTR(L_TEXT_CONTENT,1,INSTR(L_TEXT_CONTENT,',')-1);
								END IF;
                                lValueNumber := trunc(to_number (l_text_content));
                                if (lValueNumber>=0) then 
                                    sToken :=encodevalue(lValueNumber,ENCODING_NUMBER_SIZE,ENCODING_BASE);
                                    DBMS_XMLDOM.SETATTRIBUTE(DBMS_XMLDOM.MAKEELEMENt(l_childTag),'tokenNumber',sToken);
                                    DBMS_XMLDOM.SETATTRIBUTE(DBMS_XMLDOM.MAKEELEMENt(l_childTag),'valueNumber',lValueNumber);
                                end if;
                            exception
                              when others then
                                null;
                            end;                        
                        end if; 
                                          
                    END IF;
                end if;
            END LOOP;
   end if;
  
  DBMS_XMLDOM.WRITETOCLOB(doc,output);
  --dbms_output.put_line(output);
  DBMS_XMLDOM.freedocument(doc);
end ;


 

-- /** ********************************************************
   -- encoding using Matsuda Algorithm FOR INDEXING PART
   -- limit for encoding is :
        --only positive value
        -- no decimal
        -- maximum number to encode is 2^psize 
        -- pbase can be used to encode in any base from 2 to 36.
-- **************************************************************/

function encodeValue ( numValue INTEGER ,psize simple_integer , pbase simple_integer) return varchar2 is
   

lencodedvalue varchar2(4000);
lpower INTEGER ;

begin
  
    -- /** This is a "specific" and "enhanced" implementation of Matsuda Algotithm 
      
      -- This implementation is based on an algorithm that allow a base32 declinaison of the numeric encoded
    -- **/

    lpower:=power(2,psize-1);
    if (numValue>=(lpower*2)) then
     return '';
     end if;
		for j in 1..psize loop
        
                   
          --encode base 32
          --lencodedvalue:=lencodedvalue||to_base32(hashValue);
          
          
          -- /**
          -- 0
          -- 00
          -- 001
          -- 00101
          -- 101010
          -- 0010001
          -- ...
          -- become
          -- 1 0               ->2
          -- 1 00              ->4
          -- 1 001             ->7
          -- 1 00101           ->...
          -- 1 101010
          -- 1 0010001
          -- before being translated to integer (and encoded in base32)
          -- */          
            --PERFORMANCE BOOST
          PRAGMA INLINE (TO_BASE, 'YES');  
          --              use space separator                                                    --  1         -- 000000001 ----
          if (pbase=10) then
              lencodedvalue:=(case when lencodedvalue is not null then lencodedvalue||' ' end)||  ( trunc (numValue / lpower)+ power(2,j) );
          else                      
              lencodedvalue:=(case when lencodedvalue is not null then lencodedvalue||' ' end)|| to_base(  trunc (numValue / lpower)+ power(2,j),pbase);
          end if;
          
          lpower:=lpower/2;
          
		end loop;
  return lencodedvalue;
end;


-- /** ********************************************************
   -- encoding using Matsuda Algorithm FOR SEARCH PART
   -- limit for encoding is :
        --only positive value
        -- no decimal
        -- maximum number to encode is 2^psize 
        -- pbase can be used to encode in any base from 2 to 36.
-- **************************************************************/
function encodeGTorLtValue( numValue INTEGER,bigger INTEGER,psize simple_integer , pbase simple_integer) return varchar2 is

val  integer;
valAdd integer;
lencodedvalue varchar2(4000);
lpower INTEGER ;

begin
   lpower:=power(2,psize-1);
    if (numValue>=(lpower*2)) then
     return '';
     end if;
   for j in 1..psize loop
          valAdd:=-1;
          val := trunc (numValue / lpower);
          
          -- Matsuda : greater requested and last bit =0      
          if ( ( bitand(val,1)!=1) and bigger=1) then
            valAdd:=   power(2,j)+ val+1;
          end if;
          
          -- Matsuda : lower requested and last bit =1  
          if ( bitand(val,1)=1 and bigger=0) then
              valAdd:=  power(2,j) + val-1;
          end if;
         
          if (valAdd>0) then
              --PERFORMANCE BOOST
              PRAGMA INLINE (TO_BASE, 'YES');   
              -- use | separator    because act as OR operator                              
              lencodedvalue:=(case when lencodedvalue is not null then lencodedvalue||'|' end)|| to_base(valAdd,pbase);
           end if;
          
           lpower:=lpower/2;
		end loop;
    return lencodedvalue;
end;

-- /** ********************************************************
  -- Convert an integer to any base  from 2 to 36.
-- **************************************************************/
function to_base( no in INTEGER , pbase simple_integer) return varchar2 as
 s varchar2(512);
 x INTEGER  := no;
 
 begin
 if( pbase=10) then
  return no;
 end if;
   loop
     s :=  substr( base36str, mod( x, pbase ) + 1, 1 ) || s;
     x := trunc(x / pbase);
     exit when x = 0;
   end loop;
  
   return s;
end ;

END PKG_TOOLS;
/