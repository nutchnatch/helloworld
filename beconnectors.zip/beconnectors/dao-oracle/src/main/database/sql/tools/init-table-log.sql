-- log table for find search request
create table ${USR_REP}.SUGARDBLOG
(
logtime     timestamp,
requestId   varchar2(80),
logLevel integer,
logtext  VARCHAR(4000)
)
TABLESPACE ${REP_TABLESPACE_DATA}
/

