create or replace type ${USR_APP}.ClobArray as table of CLOB;
/

CREATE OR REPLACE PACKAGE ${USR_META}.PKG_TAGCLASS
IS
TAGCLASS_NS CONSTANT VARCHAR2(800):=
  'xmlns:TagClass="http://ea.assurance.bnpparibas.com/internal/schema/mco/tagclass/v1" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"'
  ;
	PROCEDURE STORE(
		TAGCLASSESARG IN ${USR_APP}.ClobArray
		);
		
	PROCEDURE STORE_SINGLE(
		TAGCLASSARG IN Clob
		);
		
	PROCEDURE UPDATE_TAGCLASS(
		TAGCLASSARG IN ${USR_APP}.ClobArray
		);
	
	PROCEDURE UPDATE_SINGLE(
		TAGCLASSARG IN Clob
		);
		
	PROCEDURE GETTAG(
   		TagIds IN ${USR_APP}.VarcharArray,
   		ScopeArg IN VARCHAR2,
		TagCursor OUT SYS_REFCURSOR
		);
		
	PROCEDURE GETALL(
   		ScopeArg IN VARCHAR2,
		TagCursor OUT SYS_REFCURSOR
		);
		
	PROCEDURE GETBYNAME(
   		TagIds IN ${USR_APP}.VarcharArray,
   		ScopeArg IN VARCHAR2,
		TagCursor OUT SYS_REFCURSOR
		);

END PKG_TAGCLASS;
/

CREATE OR REPLACE PACKAGE body ${USR_META}.PKG_TAGCLASS
IS


PROCEDURE STORE(
    TAGCLASSESARG IN ${USR_APP}.ClobArray)
AS
  xml XMLTYPE;
  scope      VARCHAR2(80);
  id_value   VARCHAR2(36);
  id_version VARCHAR2(80);
  id_issuer  VARCHAR2(80);
BEGIN
  FOR elem IN 1 .. TAGCLASSESARG.count
  LOOP
    xml   := XMLType(TAGCLASSESARG(elem));
    scope := xml.extract('/TagClass:TagClass/TagClass:Scope/text()',TAGCLASS_NS
    ).getStringVal();
    id_value := xml.extract('/TagClass:TagClass/common:ClassId/text()',
    TAGCLASS_NS) .getStringVal();
    id_version := xml.extract('/TagClass:TagClass/common:ClassId/@VersId',
    TAGCLASS_NS) .getStringVal();
    id_issuer := xml.extract('/TagClass:TagClass/common:ClassId/@Issuer',
    TAGCLASS_NS) .getStringVal();
    INSERT
    INTO
      TAGCLASSES
      (
        SCOPE,
        ID_VALUE,
        ID_VERSION,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_version,
        id_issuer,
        xml
      );
  END LOOP;
END;

PROCEDURE STORE_SINGLE(
    TAGCLASSARG IN Clob)
AS
  xml XMLTYPE;
  scope      VARCHAR2(80);
  id_value   VARCHAR2(36);
  id_version VARCHAR2(80);
  id_issuer  VARCHAR2(80);
BEGIN
    xml   := XMLType(TAGCLASSARG);
    scope := xml.extract('/TagClass:TagClass/TagClass:Scope/text()',TAGCLASS_NS
    ).getStringVal();
    id_value := xml.extract('/TagClass:TagClass/common:ClassId/text()',
    TAGCLASS_NS) .getStringVal();
    id_version := xml.extract('/TagClass:TagClass/common:ClassId/@VersId',
    TAGCLASS_NS) .getStringVal();
    id_issuer := xml.extract('/TagClass:TagClass/common:ClassId/@Issuer',
    TAGCLASS_NS) .getStringVal();
    INSERT
    INTO
      TAGCLASSES
      (
        SCOPE,
        ID_VALUE,
        ID_VERSION,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_version,
        id_issuer,
        xml
      );
END;

PROCEDURE UPDATE_TAGCLASS
  (
    TAGCLASSARG IN ${USR_APP}.ClobArray
  )
AS
  xml XMLTYPE;
BEGIN
  FOR elem IN 1 .. TAGCLASSARG.count
  LOOP
    xml:= XMLType
    (
      TAGCLASSARG(elem)
    )
    ;
    UPDATE
      TAGCLASSES t
    SET
      t.XML_CONTENT=xmltype(TAGCLASSARG(elem))
    WHERE
      t.ID_ISSUER = extractValue(xml,
      '/TagClass:TagClass/common:ClassId/@Issuer', TAGCLASS_NS)
    AND t.ID_VERSION = extractValue(xml,
      '/TagClass:TagClass/common:ClassId/@VersId', TAGCLASS_NS)
    AND t.ID_VALUE = extractValue(xml,
      '/TagClass:TagClass/common:ClassId/text()', TAGCLASS_NS)
    AND t.SCOPE = extractValue(xml, '/TagClass:TagClass/TagClass:Scope/text()',
      TAGCLASS_NS) ;
  END LOOP;
END UPDATE_TAGCLASS;

PROCEDURE UPDATE_SINGLE
  (
    TAGCLASSARG IN Clob
  )
AS
  xml XMLTYPE;
BEGIN
	xml:= XMLType
    (
      TAGCLASSARG
    )
    ;
    UPDATE
      TAGCLASSES t
    SET
      t.XML_CONTENT=xmltype(TAGCLASSARG)
    WHERE
      t.ID_ISSUER = extractValue(xml,
      '/TagClass:TagClass/common:ClassId/@Issuer', TAGCLASS_NS)
    AND t.ID_VERSION = extractValue(xml,
      '/TagClass:TagClass/common:ClassId/@VersId', TAGCLASS_NS)
    AND t.ID_VALUE = extractValue(xml,
      '/TagClass:TagClass/common:ClassId/text()', TAGCLASS_NS)
    AND t.SCOPE = extractValue(xml, '/TagClass:TagClass/TagClass:Scope/text()',
      TAGCLASS_NS) ;

END UPDATE_SINGLE;


PROCEDURE GETTAG(
    TagIds   IN ${USR_APP}.VarcharArray,
    ScopeArg IN VARCHAR2,
    TagCursor OUT SYS_REFCURSOR )
IS
BEGIN
  OPEN TagCursor FOR SELECT p.XML_CONTENT.getClobVal() FROM TAGCLASSES p
  WHERE (p.ID_VALUE,p.ID_VERSION,p.ID_ISSUER) IN
  (
    SELECT
      extractValue(xmltype(column_value), '/common:ClassId/text()', TAGCLASS_NS),
      extractValue(xmltype(column_value), '/common:ClassId/@VersId', TAGCLASS_NS),
      extractValue(xmltype(column_value), '/common:ClassId/@Issuer', TAGCLASS_NS)
    FROM
      TABLE(TagIds)
  )
  AND p.SCOPE = ScopeArg ;
END;


PROCEDURE GETBYNAME(
    TagIds   IN ${USR_APP}.VarcharArray,
    ScopeArg IN VARCHAR2,
    TagCursor OUT SYS_REFCURSOR )
IS
BEGIN
  OPEN TagCursor FOR SELECT p.XML_CONTENT.getClobVal() FROM TAGCLASSES p
  WHERE p.NAME IN
  (
    SELECT
      column_value
    FROM
      TABLE(TagIds)
  )
  AND p.SCOPE = ScopeArg ;
END;


PROCEDURE GETALL(
    ScopeArg IN VARCHAR2,
    TagCursor OUT SYS_REFCURSOR )
IS
BEGIN
  OPEN TagCursor FOR SELECT p.XML_CONTENT.getClobVal() FROM TAGCLASSES p
  WHERE p.SCOPE = ScopeArg;
END;


END PKG_TAGCLASS; 
/
