CREATE OR REPLACE PACKAGE ${USR_META}.PKG_FOLDER
IS
  -- /*
  
    -- 2014  -  SUGAR PROJECT
    -- V1.1
    -- BNPPARIBAS CARDIF
    
    -- PACKAGE FOR FOLDER MANAGMENT
    
    -- DDL FOLDER MANAGEMENT 
    -- SEARCH FOLDER ENGINE
  
  -- */


  FOLDER_NS CONSTANT VARCHAR2(800):=
  'xmlns="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1" xmlns:folder="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1"';
  NOT_DELETED_CRITERIA CONSTANT VARCHAR2(800) :=     '  ( HASPATH   (folder:Folder/folder:Status/common:Code!="DELETED") ) '  ;
  SCOPE_CRITERIA_S CONSTANT VARCHAR2(800) :=     '  ( HASPATH   (folder:Folder/@Scope="'  ;
  SCOPE_CRITERIA_E CONSTANT VARCHAR2(800) :=     '") ) '  ;
  
  
  DEFAULT_FOLDER_TABLE CONSTANT VARCHAR2(800) :=  'folders';
  -- oracle context index name
  -- need for hint optimization over 5.000.000 records....
  DEFAULT_FOLDER_INDEX CONSTANT VARCHAR2(800) :=  'folders_idx_otext';
  

  ORDER_BY_CLAUSE_NS CONSTANT VARCHAR2(800):='  declare namespace folder="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1"; (: :)
                                       declare namespace common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1"; (: :) ';   


 
 
      
  -- /*
      -- EXECUTE a SEARCH of folders based on a specific xml query
      
    -- <?xml version="1.0"?>
    -- <query  pageStart="1" pageSize="62" maxLimitSearch="2000" lang="FRENCH">
      -- <filter logicalOperator="AND">    
                -- <filter>
                  -- <path>/folder:Folder/common:Tags</path>
                  -- <operator>=</operator>
                  -- <operand type="string">BA%</operand>    
            -- </filter>            
      
           -- <filter>
                  -- <path>/folder:Folder/common:Tags/common:Tag[@name="ExpireDate"]</path>
                  -- <operator>></operator>
                  -- <operand type="date">2014-01-01</operand>    
            -- </filter>            
      
      -- </filter>
      
      -- <order>
        -- <orderKey>score desc</orderKey>
        -- <orderKey>/folder:Folder/common:Tags/common:Tag[@name="LastName"]</orderKey>
      -- </order>
-- </query>
  -- */
  PROCEDURE find(
    p_request  in varchar2 default null, 
		-- request (XML)
    pout_folderCursor OUT SYS_REFCURSOR,  
		-- cursor out 
    pout_resultCount OUT NUMBER,               
		-- OUT nb count find
   
    p_traceLevel integer default 0 ,     
		-- trace level
                                          -- /* usage : if >0 then dbms_output.put_line is used 
                                                     -- if <0 then db table  SUGARDBLOG is used  
                                                    -- if =0 no trace is provided (even in case of exception ....)
                                                    
                                                    -- if abs( p_traceLevel) =1 --> only exception are logged
                                                    -- if abs( p_traceLevel) =2 -->  exception and info are logged
                                                    -- if abs( p_traceLevel) =3 -->  exception , inf, debug o are logged */
     p_requestId  in varchar2 default null  
		-- request ID .. any token text (likee UUID).. if null, a random new one is created
                                          -- /* for JAVA USAGE.. provide any identifier that can be relevant to share with Oracle Procedure 
                                             -- for trace in db trace table (SUGARDBLOG)
                                          -- */
                                       
   );       
   
 
 -- /*** ********************************
  -- CRUD OPERATIONS
 -- ***********************************/
 
  PROCEDURE add(
      p_FOLDERS IN ${USR_APP}.ClobArray,
    p_traceLevel integer default 0  );
      
    PROCEDURE ADD_SINGLE(
      p_FOLDER IN Clob,
    p_traceLevel integer default 0  );
      
  PROCEDURE GET(
      p_scope     IN VARCHAR2,
      FolderIds IN ${USR_APP}.VarcharArray,
      FoldersFetched OUT SYS_refcursor,
    p_traceLevel integer default 0  ) ;
 
  PROCEDURE UPDATE_FOLDER(
      foldersToStore IN ${USR_APP}.ClobArray ,
    p_traceLevel integer default 0  );
    
   PROCEDURE UPDATE_FOLDER_SINGLE(
      folderToStore IN Clob,
    p_traceLevel integer default 0  );
  PROCEDURE DELETE_FOLDER(
      p_scope     IN VARCHAR2,
      FolderIds IN ${USR_APP}.VarcharArray,
    p_traceLevel integer default 0  ) ;
  
  PROCEDURE GETBYNAME(
    p_scope IN VARCHAR2,
    p_name  IN VARCHAR2,
    FetchedFolder OUT CLOB,
    p_traceLevel integer default 0 );
    -- /**
  
  -- get a xml for indexing based on the rowid of a folder
  
  -- (FUNCTION USED BY ORACLE  INDEXER BY  USER_DATATSTORE parameter)
  
  -- **/
  procedure doFilterIndrFolder(DocRowid IN ROWID,  xmlIndex  IN OUT NOCOPY CLOB) ;
 
END PKG_FOLDER; 
/

create or replace
PACKAGE body ${USR_META}.PKG_FOLDER
IS
-- /********************************************************************************************************************************
 -- EXECUTE a SEARCH of folder based on a specific xml query
      
    -- <?xml version="1.0"?>
    -- <query  pageStart="1" pageSize="62" maxLimitSearch="2000" lang="FRENCH">
      -- <filter logicalOperator="AND">    
                -- <filter>
                  -- <path>/folder:Folder/common:Tags</path>
                  -- <operator>=</operator>
                  -- <operand type="string">BA%</operand>    
            -- </filter>            
      
           -- <filter>
                  -- <path>/folder:Folder/common:Tags/common:Tag[@name="ExpireDate"]/common:Value</path>
                  -- <operator>></operator>
                  -- <operand type="date">2014-01-01</operand>    
            -- </filter>            
      
      -- </filter>
      
      -- <order>
       -- <!-- use xpath expression combined or not with structured field, comma separated.
                                           -- /* Usage : you can mix both xpath and  strutured column..  provide also scoring order
                                                -- sample 1 : '/folder:Folder/common:Tags/common:Tag[@name="Firstname"]/common:Value asc, 
                                                      -- /folder:Folder/common:Tags/common:Tag[@name="Lastname"]/common:Value desc, 
                                                      -- updatedate desc'
                                                      
                                                -- sample 2: score desc,   updatedate desc  -->
        -- <orderKey>score desc</orderKey>
        -- <orderKey>/folder:Folder/common:Tags/common:Tag[@name="LastName"]</orderKey>
      -- </order>
-- </query>
-- *****************************************************************************************************************************************/
 PROCEDURE find(
    p_request  in varchar2 default null, 
		-- request (xml)
    pout_folderCursor OUT SYS_REFCURSOR,  
		-- cursor out 
    pout_resultCount OUT NUMBER,               
		-- OUT nb count find
   
    p_traceLevel integer default 0 ,    
				-- trace level
                                          -- /* usage : if >0 then dbms_output.put_line is used 
                                                     -- if <0 then db table  SUGARDBLOG is used  
                                                    -- if =0 no trace is provided (even in case of exception ....)
                                                    
                                                    -- if abs( p_traceLevel) =1 --> only exception are logged
                                                    -- if abs( p_traceLevel) =2 -->  exception and info are logged
                                                    -- if abs( p_traceLevel) =3 -->  exception , inf, debug o are logged */
    p_requestId  in varchar2 default null  
			-- request ID .. any token text (like UUID).. if null, a random new one is created
                                          -- /* for JAVA USAGE.. provide any identifier that can be relevant to share with Oracle Procedure 
                                             -- for trace in db trace table (SUGARDBLOG)
                                          -- */
                                     
   ) is
   
     lrequestId varchar2(80);
     lstartRequest timestamp;
    
     folderRequest     DBMS_XMLDOM.DOMDocument;
     folderElemRequest DBMS_XMLDOM.DOMElement;
     nodelist      DBMS_XMLDOM.DOMNodeList;
     node   DBMS_XMLDOM.DOMNode;
    
     lpagestart      INTEGER;            
     lpagesize       INTEGER;
     lmaxLimitSearch INTEGER;
     llang           VARCHAR2(80);
     lscope          VARCHAR2(80);
     lfilter         VARCHAR2(16000);
     lorder          VARCHAR2(16000);
     lfilterSpecific VARCHAR2(16000);
     
     
  begin
      
      -- record the current timestamp for tracking performance
      lstartRequest := current_timestamp;
      
      -- create a new request if not provided for track log follow
      if (p_requestId is null) then 
        lrequestId :=dbms_random.string('X',32);
      else
        lrequestId := p_requestId;
      END IF;  
      
      ${USR_META}.PKG_TOOLS.traceLog(lrequestId,p_traceLevel,2, '> start search folders with request id '||lrequestId||(CASE when (p_traceLevel>=3) then ' : '||p_request else '' end));
      
      -- parseXML  and
      -- Create DOMDocument handle
      folderRequest     := DBMS_XMLDOM.newDOMDocument(p_request); 
      folderElemRequest := DBMS_XMLDOM.getDocumentElement(folderRequest);
      
      --1) find attributes
      --   ***************
      lpagestart :=${USR_META}.PKG_TOOLS.getIntAttrValue(folderElemRequest,'pageStart',1);
      lpagesize :=${USR_META}.PKG_TOOLS.getIntAttrValue(folderElemRequest,'pageSize',10);
      lmaxLimitSearch :=${USR_META}.PKG_TOOLS.getIntAttrValue(folderElemRequest,'maxLimitSearch',1000);
      lscope :=${USR_META}.PKG_TOOLS.getStrAttrValue(folderElemRequest,'scope',null);
      
      -- lang :  can be usefull for stemming or soundex search ?? 
      llang :=${USR_META}.PKG_TOOLS.getStrAttrValue(folderElemRequest,'lang','ENGLISH');
      
      -- 2) add  CONSTANT CRITERIA : SCOPE 
      -- ***********************************************************     
      
      if (lscope is not null) then
          lfilter:=SCOPE_CRITERIA_S||lscope||SCOPE_CRITERIA_E;
      end if;
      
      -- 3) find  filter tag to start recursivly to find specifc sub-filter.
      -- ***********************************************************     
      --get specific filters from request
      lfilterSpecific:=${USR_META}.PKG_TOOLS.getFilter(folderElemRequest);
      if (lfilterSpecific is not null) then
        if (lfilter is not null) then
            lfilter:=lfilter || 'AND '||lfilterSpecific;
        else    
            lfilter:=lfilterSpecific;
        end if;    
      end if;
      
      -- 4) order element
      -- ****************      
      lorder := ${USR_META}.PKG_TOOLS.getOrder(folderElemRequest,ORDER_BY_CLAUSE_NS);    
      
      -- 5) LET'S GO DO THE SEARCH !
      -- ***************************
      ${USR_META}.PKG_TOOLS.searchOject( lscope,lpagestart,lpagesize,lfilter,lorder,lmaxLimitSearch,pout_folderCursor,pout_resultCount,llang,lrequestId,p_traceLevel,DEFAULT_FOLDER_TABLE,DEFAULT_FOLDER_INDEX);
  
      -- don't forget to free the dom...
      DBMS_XMLDOM.freeDocument(folderRequest);
     ${USR_META}.PKG_TOOLS.traceLog( lrequestId,p_traceLevel,2,'< end search folders ('|| pout_resultCount ||' found) in ' ||(current_timestamp - lstartRequest) ||' ms ');     

  
  end;


-- /********************************
  -- STORE a set of folders  (XML)
-- *********************************/
PROCEDURE add(
    p_FOLDERS IN ${USR_APP}.ClobArray,
    p_traceLevel integer default 0  )
AS
  l_xml      XMLType;
  l_scope    VARCHAR2(80);
  l_idValue  VARCHAR2(36);
  l_idScheme VARCHAR2(80);
  l_idIssuer VARCHAR2(80);
BEGIN

  
  FOR elem IN 1 .. p_FOLDERS.count  LOOP
    l_xml      := XMLType(p_FOLDERS(elem));
    
    -- denormalization column for performance enhancement
    l_scope    := l_xml.extract('/folder:Folder/@Scope',FOLDER_NS).getStringVal();
    
    l_idValue :=  l_xml.extract('/folder:Folder/folder:FolderId/text()',FOLDER_NS).getStringVal();
    l_idScheme := l_xml.extract('/folder:Folder/folder:FolderId/@Scheme',FOLDER_NS).getStringVal();
    l_idIssuer := l_xml.extract('/folder:Folder/folder:FolderId/@Issuer',FOLDER_NS).getStringVal();
    
    ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'store new folder  ('||l_Scope||'/'||l_idValue||'/'||l_idScheme||'/'||l_idIssuer);
    INSERT   INTO FOLDERS        (        SCOPE,        ID_VALUE,        ID_SCHEME,        ID_ISSUER,        XML_CONTENT,        UPDATEDATE       )
               VALUES              (        l_Scope,      l_idValue,       l_idScheme,       l_idIssuer,       l_xml,              SYSDATE      );
  END LOOP;
END;

-- /********************************
  -- STORE a set of folders  (XML)
-- *********************************/
PROCEDURE ADD_SINGLE(
    p_FOLDER IN Clob,
    p_traceLevel integer default 0  )
AS
  l_xml      XMLType;
  l_scope    VARCHAR2(80);
  l_idValue  VARCHAR2(36);
  l_idScheme VARCHAR2(80);
  l_idIssuer VARCHAR2(80);
BEGIN

  
    l_xml      := XMLType(p_FOLDER);
    
    -- denormalization column for performance enhancement
    l_scope    := l_xml.extract('/folder:Folder/@Scope',FOLDER_NS).getStringVal();
    
    l_idValue :=  l_xml.extract('/folder:Folder/folder:FolderId/text()',FOLDER_NS).getStringVal();
    l_idScheme := l_xml.extract('/folder:Folder/folder:FolderId/@Scheme',FOLDER_NS).getStringVal();
    l_idIssuer := l_xml.extract('/folder:Folder/folder:FolderId/@Issuer',FOLDER_NS).getStringVal();
    
    ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'store new folder  ('||l_Scope||'/'||l_idValue||'/'||l_idScheme||'/'||l_idIssuer);
    INSERT   INTO FOLDERS        (        SCOPE,        ID_VALUE,        ID_SCHEME,        ID_ISSUER,        XML_CONTENT,        UPDATEDATE       )
               VALUES              (        l_Scope,      l_idValue,       l_idScheme,       l_idIssuer,       l_xml,              SYSDATE      );

END ADD_SINGLE;

-- /**************************************
  -- GET a set of folder  (XML) by  ID
-- **************************************/
PROCEDURE GET(
    p_scope     IN VARCHAR2,
    FolderIds IN ${USR_APP}.VarcharArray,
    FoldersFetched OUT SYS_refcursor,
    p_traceLevel integer default 0    )
AS
id XMLType;

BEGIN
  ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'get folder  ('||p_scope||')');
  OPEN FoldersFetched FOR SELECT /*+INDEX(t folder_pk)*/ t.XML_CONTENT.getClobVal() FROM folders t WHERE
  (ID_VALUE,ID_SCHEME,ID_ISSUER) IN
  (
    SELECT
       extractValue(XMLType(column_value),'/folder:FolderId', FOLDER_NS ),
       extractValue(XMLType(column_value),'/folder:FolderId/@Scheme', FOLDER_NS ),
       extractValue(XMLType(column_value),'/folder:FolderId/@Issuer', FOLDER_NS )
    FROM
      TABLE(folderids)
  )
  AND p_scope=t.SCOPE 
  
  ;
END GET;


-- /**************************************
  -- UPDATE a set of folder  (XML) 
-- **************************************/
PROCEDURE UPDATE_FOLDER(
    foldersToStore IN ${USR_APP}.ClobArray ,
    p_traceLevel integer default 0  )
AS
  
  l_xml      XMLType;
  l_scope    VARCHAR2(80);
  l_idValue  VARCHAR2(36);
  l_idScheme VARCHAR2(80);
  l_idIssuer VARCHAR2(80);
BEGIN
  FOR i IN 1 .. foldersToStore.count
  LOOP
    l_xml := XMLType(folderstostore(i));
    l_scope    := l_xml.extract('/folder:Folder/@Scope',FOLDER_NS).getStringVal();
    l_idValue :=  l_xml.extract('/folder:Folder/folder:FolderId/text()',FOLDER_NS).getStringVal();
    l_idScheme := l_xml.extract('/folder:Folder/folder:FolderId/@Scheme',FOLDER_NS).getStringVal();
    l_idIssuer := l_xml.extract('/folder:Folder/folder:FolderId/@Issuer',FOLDER_NS).getStringVal();
    
    
     ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'update folder  ('||l_Scope||'/'||l_idValue||'/'||l_idScheme||'/'||l_idIssuer);
    UPDATE /*+INDEX(t folder_pk)*/ folders t
      SET
        XML_CONTENT=l_xml,
        UPDATEDATE=SYSDATE
      WHERE t.ID_VALUE = l_idValue
      AND t.ID_SCHEME =  l_idScheme
      AND t.ID_ISSUER = l_idIssuer
      AND t.SCOPE = l_scope;

  END LOOP ;
END UPDATE_FOLDER;


-- /**************************************
  -- UPDATE a set of folder  (XML) 
-- **************************************/
PROCEDURE UPDATE_FOLDER_SINGLE(
    folderToStore IN Clob ,
    p_traceLevel integer default 0  )
AS
  
  l_xml      XMLType;
  l_scope    VARCHAR2(80);
  l_idValue  VARCHAR2(36);
  l_idScheme VARCHAR2(80);
  l_idIssuer VARCHAR2(80);
BEGIN

    l_xml := XMLType(foldertostore);
    l_scope    := l_xml.extract('/folder:Folder/@Scope',FOLDER_NS).getStringVal();
    l_idValue :=  l_xml.extract('/folder:Folder/folder:FolderId/text()',FOLDER_NS).getStringVal();
    l_idScheme := l_xml.extract('/folder:Folder/folder:FolderId/@Scheme',FOLDER_NS).getStringVal();
    l_idIssuer := l_xml.extract('/folder:Folder/folder:FolderId/@Issuer',FOLDER_NS).getStringVal();
    
    
     ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,2, 'update folder  ('||l_Scope||'/'||l_idValue||'/'||l_idScheme||'/'||l_idIssuer);
    UPDATE /*+INDEX(t folder_pk)*/ folders t
      SET
        XML_CONTENT=l_xml,
        UPDATEDATE=SYSDATE
      WHERE t.ID_VALUE = l_idValue
      AND t.ID_SCHEME =  l_idScheme
      AND t.ID_ISSUER = l_idIssuer
      AND t.SCOPE = l_scope;

END UPDATE_FOLDER_SINGLE;
-- /**************************************
  -- UPDATE a set of folder  (XML) 
-- **************************************/

PROCEDURE DELETE_FOLDER(
    p_scope     IN VARCHAR2,
    FolderIds IN ${USR_APP}.VarcharArray  ,
    p_traceLevel integer default 0 )
AS
BEGIN

 ${USR_META}.PKG_TOOLS.traceLog(null,p_traceLevel,1, 'delete folder  ('||p_scope||')');
 
  DELETE
  FROM
    folders t
  WHERE
  (ID_VALUE,ID_SCHEME,ID_ISSUER) IN
  (
    SELECT
      extractValue(XMLType(column_value),'/folder:FolderId', FOLDER_NS ),
      extractValue(XMLType(column_value),'/folder:FolderId/@Scheme', FOLDER_NS ),
      extractValue(XMLType(column_value),'/folder:FolderId/@Issuer', FOLDER_NS )
    FROM
      TABLE(folderids)
  )
  AND p_scope=t.SCOPE;
END DELETE_FOLDER;

-- /********************************************************************
  -- FIND A FOLDER BY HIS NAME
  -- WILDCARD AND ANY SEARCH  compatible with CONTEXT QUERY IS ALLOWED
  -- ONLY 1 (first row found) folder (xml_content) is retrieved.
-- ********************************************************************/


PROCEDURE GETBYNAME(
    p_scope IN VARCHAR2,
    p_name  IN VARCHAR2,
    FetchedFolder OUT CLOB,
    p_traceLevel integer default 0      
			-- trace level
                                          -- /* usage : if >0 then dbms_output.put_line is used 
                                                     -- if <0 then db table  SUGARDBLOG is used  
                                                    -- if =0 no trace is provided (even in case of exception ....)
                                                    
                                                    -- if abs( p_traceLevel) =1 --> only exception are logged
                                                    -- if abs( p_traceLevel) =2 -->  exception and info are logged
                                                    -- if abs( p_traceLevel) =3 -->  exception , inf, debug o are logged */
					)
AS

lfilter varchar2 (16000);
BEGIN
   
   
    if (p_scope is not null) then
        lfilter:=SCOPE_CRITERIA_S||p_scope||SCOPE_CRITERIA_E|| ' AND ';        
    end if;
   
  lfilter:=lfilter||' ("'||p_name||'") INPATH (/folder:Folder/folder:Data/common:Name)';
    
  ${USR_META}.PKG_TOOLS.traceLog(-1,p_traceLevel,2, 'search folders with name="'||p_name||'" filter =  '||lfilter);
  
  SELECT
  t.xml_content.getClobVal() into FetchedFolder
FROM FOLDERS  t
where contains (xml_content,lfilter)>=0 and rownum<=1;

EXCEPTION
WHEN NO_DATA_FOUND THEN
  FetchedFolder := NULL;
END ;





-- /*************************************************************************

-- Filter  a xml folder before indexing based on the rowid of a folder

-- (FUNCTION USED BY THE ORACLE INDEXER SEE THE USER_DATATSTORE parameter)

-- *************************************************************************/
procedure doFilterIndrFolder(docRowid IN ROWID,  xmlIndex  IN OUT NOCOPY CLOB) is
 
 lxml xmltype;
 cursor c1 is select xml_content from folders where rowid =docRowid;

 begin
 
 -- find xmlcontent.
open c1;
fetch c1 into lxml;
close c1;
 
 --temporary clob created foroutput  
 DBMS_LOB.CREATETEMPORARY(xmlIndex, TRUE, DBMS_LOB.CALL);

--filtering the xml to provide a nex xml index 
${USR_META}.PKG_TOOLS.filter(lxml,xmlIndex);
  
 exception
        when others then
          ${USR_META}.PKG_TOOLS.traceLog('DOCROWID='||docRowid,-1,1, SQLERRM);
      raise;
 end;
    



END PKG_FOLDER;
/