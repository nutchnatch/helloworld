CREATE TABLE ${USR_META}.TASKS (
  SCOPE         VARCHAR2(80),
  ID_VALUE      VARCHAR2(36),
  ID_SCHEME     VARCHAR2(80),
  ID_ISSUER     VARCHAR2(80),
  XML_CONTENT   XMLTYPE,
  basketid      AS (extractValue(XML_CONTENT , '/task:Task/basket:BasketId' ,'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1"')) VIRTUAL,
  basketscheme      AS (extractValue(XML_CONTENT , '/task:Task/basket:BasketId/@Scheme' ,'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1"')) VIRTUAL,
  basketissuer      AS (extractValue(XML_CONTENT , '/task:Task/basket:BasketId/@Issuer' ,'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1"')) VIRTUAL,
  docid      AS (extractValue(XML_CONTENT , '/task:Task/task:DocID/doc:Id' ,'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1"')) VIRTUAL,
  docIssuer      AS (extractValue(XML_CONTENT , '/task:Task/task:DocID/doc:Id/@Issuer' ,'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1"')) VIRTUAL,
  docScheme      AS (extractValue(XML_CONTENT , '/task:Task/task:DocID/doc:Id/@Scheme' ,'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1"')) VIRTUAL,
   create_date as (extractValue(XML_CONTENT, '/task:Task/task:CreatnDate','xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"')) VIRTUAL,
   status as (extractValue(XML_CONTENT,'/task:Task/task:Status/text()','xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"')) VIRTUAL,
   locker as (extractValue(XML_CONTENT,'/task:Task/task:LockerName','xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"')) VIRTUAL,
 update_date as (extractValue(XML_CONTENT,'/task:Task/task:UpdtDate','xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"')) VIRTUAL,
   constraint task_pk primary key (SCOPE, ID_VALUE, ID_SCHEME, ID_ISSUER) 
  )
  XMLTYPE COLUMN XML_CONTENT STORE AS BINARY XML
  TABLESPACE ${META_TABLESPACE_DATA}  
/

CREATE INDEX ${USR_META}.tasks_scope ON ${USR_META}.TASKS(SCOPE)
TABLESPACE ${META_TABLESPACE_INDEX}
/
CREATE INDEX ${USR_META}.tasks_id ON ${USR_META}.TASKS(DOCID)
TABLESPACE ${META_TABLESPACE_INDEX}
/
