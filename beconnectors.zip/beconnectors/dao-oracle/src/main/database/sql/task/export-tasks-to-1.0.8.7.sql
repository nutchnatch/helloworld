ALTER TABLE tasks add locker as (extractValue(XML_CONTENT,
          '/task:Task/task:LockerName',
          'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"'
          )) VIRTUAL
/