CREATE OR REPLACE PACKAGE ${USR_META}.PKG_TASK
IS
  TASK_NS CONSTANT VARCHAR2(800):=
  'xmlns:folder="http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1" xmlns:acl="http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1" xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:doc="http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1" xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1" xmlns:businessscope="http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1"'
  ;
  PROCEDURE STORETASKS(
      taskArg IN ${USR_APP}.ClobArray);
  PROCEDURE STORETASKS_SINGLE(
      taskArg IN Clob);

  PROCEDURE GET(
      scopeIn IN VARCHAR2,
      taskIds IN ${USR_APP}.VarcharArray,
      TasksFetched OUT SYS_refcursor );

PROCEDURE UPDATETASKS(
      taskArg IN ${USR_APP}.ClobArray);
	  
PROCEDURE UPDATETASKS_SINGLE(
      taskArg IN Clob);
      
  PROCEDURE UPDATESTATUS(
      scopeIn  IN VARCHAR2,
      taskIds  IN ${USR_APP}.VarcharArray,
      statusIn IN VARCHAR2 );

  PROCEDURE LOCKTASK(
      scopeIn    IN VARCHAR2,
      taskIds    IN ${USR_APP}.VarcharArray,
      lockerName IN VARCHAR2 );

  PROCEDURE UNLOCKTASK(
      scopeIn IN VARCHAR2,
      taskIds IN ${USR_APP}.VarcharArray );

  PROCEDURE TRANSFER(
      scopeIn        IN VARCHAR2,
      taskIds        IN ${USR_APP}.VarcharArray,
      basketIdValue  IN VARCHAR2,
      basketIdScheme IN VARCHAR2,
      basketIdIssuer IN VARCHAR2 );

  PROCEDURE GETTASKSINBASKET(
      p_start    IN NUMBER,
    p_max      IN NUMBER,
    scopeIn    IN VARCHAR2,
    issuerIn   IN VARCHAR2,
    schemeIn   IN VARCHAR2,
    basketIdIn IN VARCHAR2,
	EXCLUDE_CLOSE      IN VARCHAR2,
    taskFetched OUT SYS_refcursor,
    counter OUT NUMBER );

  PROCEDURE GETTASKFORDOC(
      scopeIn IN VARCHAR2,
      docIds  IN VARCHAR2,
      TasksFetched OUT SYS_refcursor );
	  
	  
	  PROCEDURE GETTASKBYUSER(
      scopeIn IN VARCHAR2,
	  userName  IN VARCHAR2,
      TasksFetched OUT SYS_refcursor );
END PKG_TASK; 
/
CREATE OR REPLACE PACKAGE BODY ${USR_META}.PKG_TASK
AS


PROCEDURE STORETASKS(
    taskArg IN ${USR_APP}.ClobArray)
AS
  xml XMLTYPE;
  scope     VARCHAR2(80);
  id_value  VARCHAR2(36);
  id_scheme VARCHAR2(80);
  id_issuer VARCHAR2(80);
BEGIN
  FOR elem IN 1 .. taskArg.count
  LOOP
    xml      := XMLType(taskArg(elem));
    scope    := xml.extract('/task:Task/@Scope',TASK_NS).getStringVal();
    id_value := xml.extract('/task:Task/task:TaskId/text()',TASK_NS)
    .getStringVal();
    id_scheme := xml.extract('/task:Task/task:TaskId/@Scheme',TASK_NS)
    .getStringVal();
    id_issuer := xml.extract('/task:Task/task:TaskId/@Issuer',TASK_NS)
    .getStringVal();
    INSERT
    INTO
      TASKS
      (
        SCOPE,
        ID_VALUE,
        ID_SCHEME,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_scheme,
        id_issuer,
        xml
      );
  END LOOP;
END STORETASKS;

PROCEDURE STORETASKS_SINGLE(
    taskArg IN Clob)
AS
  xml XMLTYPE;
  scope     VARCHAR2(80);
  id_value  VARCHAR2(36);
  id_scheme VARCHAR2(80);
  id_issuer VARCHAR2(80);
BEGIN
    xml      := XMLType(taskArg);
    scope    := xml.extract('/task:Task/@Scope',TASK_NS).getStringVal();
    id_value := xml.extract('/task:Task/task:TaskId/text()',TASK_NS)
    .getStringVal();
    id_scheme := xml.extract('/task:Task/task:TaskId/@Scheme',TASK_NS)
    .getStringVal();
    id_issuer := xml.extract('/task:Task/task:TaskId/@Issuer',TASK_NS)
    .getStringVal();
    INSERT
    INTO
      TASKS
      (
        SCOPE,
        ID_VALUE,
        ID_SCHEME,
        ID_ISSUER,
        XML_CONTENT
      )
      VALUES
      (
        scope,
        id_value,
        id_scheme,
        id_issuer,
        xml
      );
END STORETASKS_SINGLE;

PROCEDURE UPDATETASKS(
      taskArg IN ${USR_APP}.ClobArray)
AS
  l_xml XMLTYPE;
  l_scope     VARCHAR2(80);
  l_id_value  VARCHAR2(36);
  l_id_scheme VARCHAR2(80);
  l_id_issuer VARCHAR2(80);
BEGIN
  FOR elem IN 1 .. taskArg.count
  LOOP
    l_xml      := XMLType(taskArg(elem));
    l_scope    := l_xml.extract('/task:Task/@Scope',TASK_NS).getStringVal();
    l_id_value := l_xml.extract('/task:Task/task:TaskId/text()',TASK_NS)
    .getStringVal();
    l_id_scheme := l_xml.extract('/task:Task/task:TaskId/@Scheme',TASK_NS)
    .getStringVal();
    l_id_issuer := l_xml.extract('/task:Task/task:TaskId/@Issuer',TASK_NS)
    .getStringVal();
   UPDATE  /*+ INDEX(t task_pk) */ TASKS t
    SET
      t.XML_CONTENT=l_xml
	 WHERE t.ID_VALUE = l_id_value
      AND t.ID_SCHEME = l_id_scheme
      AND t.ID_ISSUER = l_id_issuer
      AND t.SCOPE = l_scope;
	  
  END LOOP;
END UPDATETASKS;

PROCEDURE UPDATETASKS_SINGLE(
      taskArg IN Clob)
AS
  l_xml XMLTYPE;
  l_scope     VARCHAR2(80);
  l_id_value  VARCHAR2(36);
  l_id_scheme VARCHAR2(80);
  l_id_issuer VARCHAR2(80);
BEGIN
    l_xml      := XMLType(taskArg);
    l_scope    := l_xml.extract('/task:Task/@Scope',TASK_NS).getStringVal();
    l_id_value := l_xml.extract('/task:Task/task:TaskId/text()',TASK_NS)
    .getStringVal();
    l_id_scheme := l_xml.extract('/task:Task/task:TaskId/@Scheme',TASK_NS)
    .getStringVal();
    l_id_issuer := l_xml.extract('/task:Task/task:TaskId/@Issuer',TASK_NS)
    .getStringVal();
   UPDATE  /*+ INDEX(t task_pk) */ TASKS t
    SET
      t.XML_CONTENT=l_xml
	 WHERE t.ID_VALUE = l_id_value
      AND t.ID_SCHEME = l_id_scheme
      AND t.ID_ISSUER = l_id_issuer
      AND t.SCOPE = l_scope;
	  
END UPDATETASKS_SINGLE;


PROCEDURE GET
  (
    scopeIn IN VARCHAR2,
    taskIds IN ${USR_APP}.VarcharArray,
    TasksFetched OUT SYS_refcursor
  )
IS
BEGIN
  OPEN  TasksFetched FOR SELECT /*+ INDEX(t task_pk) */  t.XML_CONTENT.getClobVal
  (
  )
  FROM TASKS t WHERE (t.ID_VALUE,t.ID_SCHEME,t.ID_ISSUER) IN
  (
    SELECT
      extractValue(xmltype(column_value),'/task:TaskId',TASK_NS),
       extractValue(xmltype(column_value),'/task:TaskId/@Scheme',TASK_NS),
       extractValue(xmltype(column_value),'/task:TaskId/@Issuer',TASK_NS)
       
    FROM
      TABLE(taskIds)
  )
  AND scopeIn=t.SCOPE;
END GET;


PROCEDURE GETTASKFORDOC
  (
    scopeIn IN VARCHAR2,
    docIds  IN VARCHAR2,
    TasksFetched OUT SYS_refcursor
  )
AS
        xml XMLType;
BEGIN
  xml := XMLType(docIds);
  OPEN TasksFetched FOR SELECT t.XML_CONTENT.getClobVal
  (
  )
  FROM TASKS t WHERE t.docid = extractValue(xml,'doc:Id' ,TASK_NS)
  AND t.docIssuer = extractValue(xml,'doc:Id/@Issuer' ,TASK_NS)
  AND t.docScheme = extractValue(xml,'doc:Id/@Scheme' ,TASK_NS)
  AND scopeIn=t.SCOPE AND t.status <> 'CLOSE';
END GETTASKFORDOC;

PROCEDURE GETTASKBYUSER(
      scopeIn IN VARCHAR2,
	  userName  IN VARCHAR2,
      TasksFetched OUT SYS_refcursor )
AS
BEGIN
 
  OPEN TasksFetched FOR SELECT t.XML_CONTENT.getClobVal
  (
  )
  FROM TASKS t WHERE t.locker = userName
  AND scopeIn=t.SCOPE;
END GETTASKBYUSER;


PROCEDURE UPDATESTATUS
  (
    scopeIn  IN VARCHAR2,
    taskIds  IN ${USR_APP}.VarcharArray,
    statusIn IN VARCHAR2
  )
AS
  XML_TMP XMLType;
  id XMLType;
BEGIN
  FOR i IN 1 .. taskIds.count
  LOOP
    id := xmltype
    (
      taskIds(i)
    )
    ;
    SELECT /*+ INDEX(t task_pk) */  t.XML_CONTENT
    INTO
      XML_TMP
    FROM
      TASKS t
    WHERE
      t.ID_VALUE    = extractValue(id, '/task:TaskId',TASK_NS)
    AND t.ID_ISSUER = extractValue(id, '/task:TaskId/@Issuer',TASK_NS)
    AND t.ID_SCHEME = extractValue(id, '/task:TaskId/@Scheme',TASK_NS)
    AND t.SCOPE     = scopeIn;
   UPDATE  /*+ INDEX(t task_pk) */ TASKS t
    SET
      XML_CONTENT = UPDATEXML(XML_TMP,'/task:Task/task:Status/text()',statusIn,
      TASK_NS)
    WHERE
      t.ID_VALUE    = extractValue(id, '/task:TaskId',TASK_NS)
    AND t.ID_ISSUER = extractValue(id, '/task:TaskId/@Issuer',TASK_NS)
    AND t.ID_SCHEME = extractValue(id, '/task:TaskId/@Scheme',TASK_NS)
    AND t.SCOPE     = scopeIn;
  END LOOP;
END UPDATESTATUS;


PROCEDURE LOCKTASK(
    scopeIn    IN VARCHAR2,
    taskIds    IN ${USR_APP}.VarcharArray,
    lockerName IN VARCHAR2)
AS
  XML_TMP XMLType;
  id XMLType;
BEGIN
  FOR i IN 1 .. taskIds.count
  LOOP
            id := xmltype
            (
              taskIds(i)
            )
            ;
            SELECT /*+ INDEX(t task_pk) */  t.XML_CONTENT
            INTO
              XML_TMP
            FROM
              TASKS t
            WHERE
              t.ID_VALUE    = extractValue(id, '/task:TaskId',TASK_NS)
            AND t.ID_ISSUER = extractValue(id, '/task:TaskId/@Issuer',TASK_NS)
            AND t.ID_SCHEME = extractValue(id, '/task:TaskId/@Scheme',TASK_NS)
            AND t.SCOPE     = scopeIn
            AND existsnode(t.XML_CONTENT,'/task:Task/task:LockerName',
            'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"'
            )=0;
	
          UPDATE /*+ INDEX(t task_pk) */ TASKS t
          SET
            t.XML_CONTENT = APPENDCHILDXML(XML_TMP, '/task:Task', XMLType(
            '<task:LockerName xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1">'
            ||lockerName
            ||'</task:LockerName>'),
            'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"'
            )
          WHERE
              t.ID_VALUE    = extractValue(id, '/task:TaskId',TASK_NS)
            AND t.ID_ISSUER = extractValue(id, '/task:TaskId/@Issuer',TASK_NS)
            AND t.ID_SCHEME = extractValue(id, '/task:TaskId/@Scheme',TASK_NS)
            AND t.SCOPE     = scopeIn
          AND existsnode(t.XML_CONTENT,'/task:Task/task:LockerName',
            'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"'
            )=0;
  END LOOP;
 EXCEPTION
   WHEN NO_DATA_FOUND THEN return;
END LOCKTASK;


PROCEDURE UNLOCKTASK(
    scopeIn IN VARCHAR2,
    taskIds IN ${USR_APP}.VarcharArray)
IS
BEGIN
  UPDATE
    TASKS t
  SET
    t.XML_CONTENT= DELETEXML(t.XML_CONTENT,'/task:Task/task:LockerName',
    'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"'
    )
  WHERE
    (t.ID_VALUE,t.ID_SCHEME,t.ID_ISSUER) IN
    (
      SELECT
        extractValue(xmltype(column_value),'/task:TaskId',TASK_NS),
        extractValue(xmltype(column_value),'/task:TaskId/@Scheme',TASK_NS),
        extractValue(xmltype(column_value),'/task:TaskId/@Issuer',TASK_NS)
      FROM
        TABLE(taskIds)
    )
  AND scopeIn=t.SCOPE;
END UNLOCKTASK;


PROCEDURE TRANSFER(
    scopeIn        IN VARCHAR2,
    taskIds        IN ${USR_APP}.VarcharArray,
    basketIdValue  IN VARCHAR2,
    basketIdScheme IN VARCHAR2,
    basketIdIssuer IN VARCHAR2)
AS
  XML_TMP XMLType;
  id XMLType;
BEGIN
  FOR i IN 1 .. taskIds.count
  LOOP
    id := xmltype
    (
      taskIds(i)
    )
    ;
    SELECT /*+ INDEX(t task_pk) */  t.XML_CONTENT
    INTO
      XML_TMP
    FROM
      TASKS t
    WHERE
      t.ID_VALUE    = extractValue(id, '/task:TaskId',TASK_NS)
    AND t.ID_ISSUER = extractValue(id, '/task:TaskId/@Issuer',TASK_NS)
    AND t.ID_SCHEME = extractValue(id, '/task:TaskId/@Scheme',TASK_NS)
    AND t.SCOPE     = scopeIn;
  UPDATE /*+ INDEX(t task_pk) */ TASKS t
  SET
    t.XML_CONTENT=updateXML(XML_TMP, '/task:Task/basket:BasketId/text()',
    basketIdValue, '/task:Task/basket:BasketId/@Scheme',basketIdScheme,
    '/task:Task/basket:BasketId/@Issuer',basketIdIssuer,
    'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1" xmlns:basket="http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1"'
    )
	WHERE
      t.ID_VALUE    = extractValue(id, '/task:TaskId',TASK_NS)
    AND t.ID_ISSUER = extractValue(id, '/task:TaskId/@Issuer',TASK_NS)
    AND t.ID_SCHEME = extractValue(id, '/task:TaskId/@Scheme',TASK_NS)
    AND t.SCOPE     = scopeIn;
	  END LOOP;
END TRANSFER;


PROCEDURE GETTASKSINBASKET(
    p_start    IN NUMBER,
    p_max      IN NUMBER,
    scopeIn    IN VARCHAR2,
    issuerIn   IN VARCHAR2,
    schemeIn   IN VARCHAR2,
    basketIdIn IN VARCHAR2,
	EXCLUDE_CLOSE      IN VARCHAR2,
    taskFetched OUT SYS_refcursor,
    counter OUT NUMBER)
IS
BEGIN
  IF(EXCLUDE_CLOSE       ='true') THEN
  OPEN taskFetched FOR SELECT * FROM
  (
       SELECT
      a.*,
      rownum r__
    FROM
      (
        SELECT
          t.XML_CONTENT.getClobVal()
        FROM
          TASKS t
        WHERE
          status!='CLOSE'
        AND t.SCOPE        =scopeIn
        AND t.basketissuer = issuerIn
        AND t.basketscheme =schemeIn
        AND t.basketId     =basketIdIn
        ORDER BY
          create_date DESC
      )
      a
    WHERE
      rownum <=(p_start+p_max)
  )
  WHERE r__> p_start;
  SELECT
    COUNT(*)
  INTO
    counter
  FROM
    TASKS t
  WHERE
    t.SCOPE          =scopeIn
  AND t.basketissuer = issuerIn
  AND t.basketscheme = schemeIn
  AND t.basketId     =basketIdIn
  AND status!='CLOSE';
ELSE 
OPEN taskFetched FOR SELECT * FROM
  (
 
SELECT
      a.*,
      rownum r__
    FROM
      (
        SELECT
          t.XML_CONTENT.getClobVal()
        FROM
          TASKS t
        WHERE
         t.SCOPE        =scopeIn
        AND t.basketissuer = issuerIn
        AND t.basketscheme =schemeIn
        AND t.basketId     =basketIdIn
        ORDER BY
          create_date DESC
      )
      a
    WHERE
      rownum <=(p_start+p_max)
  )
  WHERE r__> p_start;
  SELECT
    COUNT(*)
  INTO
    counter
  FROM
    TASKS t
  WHERE
    t.SCOPE          =scopeIn
  AND t.basketissuer = issuerIn
  AND t.basketscheme = schemeIn
  AND t.basketId     =basketIdIn;
 END if;
END GETTASKSINBASKET;

END PKG_TASK; 
/