ALTER TABLE tasks add status as (extractValue(XML_CONTENT,'/task:Task/task:Status/text()',
          'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"'
          )) VIRTUAL
/

ALTER TABLE tasks add create_date as (extractValue(XML_CONTENT,
          '/task:Task/task:CreatnDate',
          'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"'
          )) VIRTUAL
/