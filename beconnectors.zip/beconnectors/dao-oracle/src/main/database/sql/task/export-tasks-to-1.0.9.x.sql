ALTER TABLE tasks add update_date as (extractValue(XML_CONTENT,
          '/task:Task/task:UpdtDate',
          'xmlns:task="http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1"'
          )) VIRTUAL
/