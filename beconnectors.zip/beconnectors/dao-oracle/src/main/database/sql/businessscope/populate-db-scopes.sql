delete from scopes
/
Insert into scopes values ('Syldavia' , xmltype('<?xml version = '1.0' encoding = 'UTF-8' standalone = 'yes'?><businessscope:BusinessScope SymbolicName="Syldavia" xmlns:common="http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1" xmlns:file="http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1" xmlns:i18n="http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1" xmlns:businessscope="http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1">
<businessscope:BusinessScopeId Issuer="CARDIF" Scheme="Sugar">0a369fd6-4d69-a6c8-a1f3-acdd869905f4</businessscope:BusinessScopeId>
<businessscope:OrganisationalUnit>OU</businessscope:OrganisationalUnit>
   <businessscope:Description>Description2</businessscope:Description>
   <businessscope:DisplayName language="FR">
      <i18n:value>Syldavie</i18n:value>
   </businessscope:DisplayName>
      <businessscope:DisplayName language="EN">
      <i18n:value>Syldavia</i18n:value>
   </businessscope:DisplayName>
   <businessscope:Languages>FR</businessscope:Languages>
   <businessscope:Languages>EN</businessscope:Languages>
   <businessscope:CreationDate>2014-05-15 00:00:00.000 +0200</businessscope:CreationDate>
   <businessscope:updateDate>2014-06-05 19:53:32.389 +0200</businessscope:updateDate>
   <businessscope:EncryptionIdentifier>Default Enc Identifier</businessscope:EncryptionIdentifier>
   <businessscope:FileData>
      <businessscope:URI>10fa3fdd-9137-4664-b2d2-f18c1e103fc6</businessscope:URI>
   </businessscope:FileData>
</businessscope:BusinessScope>
'));
