CREATE OR REPLACE PACKAGE ${USR_META}.PKG_SCOPE
IS
  SCOPE_NS CONSTANT VARCHAR2(800):=
  'xmlns:businessscope="http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1"'
  ;

  PROCEDURE STORE(
      SCOPESARG IN ${USR_APP}.ClobArray );
      
  PROCEDURE STORE_SINGLE(
      SCOPEARG IN Clob);

  PROCEDURE GETALL(
      BusinessScopeCursor OUT SYS_REFCURSOR );

  PROCEDURE UPDATE_SCOPE(
      SCOPE_TO_UPDATE IN ${USR_APP}.ClobArray );
  PROCEDURE UPDATE_SCOPE_SINGLE(
      SCOPE_TO_UPDATE IN Clob);

  PROCEDURE GETBYNAME(
      BusinessScopeIds IN ${USR_APP}.VarcharArray,
      BusinessScopeCursor OUT SYS_REFCURSOR );

END PKG_SCOPE; 
/


CREATE OR REPLACE PACKAGE body ${USR_META}.PKG_SCOPE
IS

PROCEDURE STORE(
    SCOPESARG IN ${USR_APP}.ClobArray)
AS
  xml XMLTYPE;
  name VARCHAR2(80);
BEGIN
  FOR elem IN 1 .. SCOPESARG.count
  LOOP
    xml  := XMLType(SCOPESARG(elem));
    name := xml.extract('/businessscope:BusinessScope/@SymbolicName',SCOPE_NS)
    .getStringVal();
    INSERT
    INTO
      SCOPES
      (
        NAME,
        XML_CONTENT
      )
      VALUES
      (
        name,
        xml
      );
  END LOOP;
END;

PROCEDURE STORE_SINGLE(
    SCOPEARG IN Clob)
AS
  xml XMLTYPE;
  name VARCHAR2(80);
BEGIN
     xml  := XMLType(SCOPEARG);
    name := xml.extract('/businessscope:BusinessScope/@SymbolicName',SCOPE_NS)
    .getStringVal();
    INSERT
    INTO
      SCOPES
      (
        NAME,
        XML_CONTENT
      )
      VALUES
      (
        name,
        xml
      );
END;

PROCEDURE GETALL
  (
    BusinessScopeCursor OUT SYS_REFCURSOR
  )
IS
BEGIN
  OPEN BusinessScopeCursor FOR SELECT p.XML_CONTENT.getClobVal
  (
  )
  FROM SCOPES p;
END;


PROCEDURE UPDATE_SCOPE
  (
    SCOPE_TO_UPDATE IN ${USR_APP}.ClobArray
  )
AS
  xml XMLType;
BEGIN
  FOR elem IN 1 .. SCOPE_TO_UPDATE.count
  LOOP
    xml := XMLType
    (
      SCOPE_TO_UPDATE(elem)
    )
    ;
    UPDATE
      SCOPES t
    SET
      t.XML_CONTENT=xml
    WHERE
      t.NAME = EXTRACTVALUE(xml,'/businessscope:BusinessScope/@SymbolicName',
      SCOPE_NS);
  END LOOP;
END UPDATE_SCOPE;

PROCEDURE UPDATE_SCOPE_SINGLE
  (
    SCOPE_TO_UPDATE IN Clob
  )
AS
  xml XMLType;
BEGIN
    xml := XMLType
    (
    	SCOPE_TO_UPDATE
    )
    ;
    UPDATE
      SCOPES t
    SET
      t.XML_CONTENT=xml
    WHERE
      t.NAME = EXTRACTVALUE(xml,'/businessscope:BusinessScope/@SymbolicName',
      SCOPE_NS);
END UPDATE_SCOPE_SINGLE;

PROCEDURE GETBYNAME(
    BusinessScopeIds IN ${USR_APP}.VarcharArray,
    BusinessScopeCursor OUT SYS_REFCURSOR )
IS
BEGIN
  OPEN BusinessScopeCursor FOR SELECT p.XML_CONTENT.getClobVal() FROM SCOPES
  p WHERE NAME IN
  (
    SELECT
      column_value
    FROM
      TABLE(BusinessScopeIds)
  )
  ;
END GETBYNAME;


END PKG_SCOPE; 
/
