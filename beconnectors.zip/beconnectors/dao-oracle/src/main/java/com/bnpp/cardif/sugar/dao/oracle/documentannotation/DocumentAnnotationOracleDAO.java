package com.bnpp.cardif.sugar.dao.oracle.documentannotation;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01201;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01202;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01203;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01204;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.documentannotation.DocumentAnnotationDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentAnnotationDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.EDMS2IdentificationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.DocumentAnnotation;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.Id;

@Component
public class DocumentAnnotationOracleDAO extends AbstractDAO implements DocumentAnnotationDAO {

    private static final String TABLE_NAME = "ANNOTATIONS";

    @Value("${spring.datasource.username.annotation}")
    private String docUser;

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentAnnotationOracleDAO.class);

    @Override
    public List<DocumentAnnotation> create(List<DocumentAnnotation> documentAnnotations)
            throws SugarTechnicalException {
        LOGGER.debug("create {} ", documentAnnotations.size());
        List<DocumentAnnotation> createdDocumentAnnotations = new LinkedList<>();

        // Pre prepared insert statement for the annotations table
        String insertStatement = "insert into " + getTableName() + " (ANNO_ID,DOC_ID,CONTENTSTRING) values (?,?,?)";
        for (DocumentAnnotation documentAnnotation : documentAnnotations) {
            try {
                String annoId = null;
                String docId = null;
                String contentString = null;

                if (documentAnnotation.getId() != null) {
                    annoId = documentAnnotation.getId().getValue();
                }
                if (documentAnnotation.getData() != null) {
                    docId = documentAnnotation.getData().getDocumentFileURI();
                    contentString = documentAnnotation.getData().getContent();
                }
                // insert the document id plus the content into the db
                int rowsAffected = template.update(insertStatement, annoId, docId, contentString);

                // If no exception is thrown then we add the annotations to the
                // success pile
                if (rowsAffected > 0) {
                    createdDocumentAnnotations.add(documentAnnotation);
                }

            }
            catch (DataAccessException e) {
                LOGGER.debug(T01201 + ": Impossible to save annotation" + documentAnnotation.getId(), e);
            }
        }
        return createdDocumentAnnotations;

    }

    @Override
    public List<DocumentAnnotation> update(List<DocumentAnnotation> documentAnnotations)
            throws SugarTechnicalException {

        LOGGER.debug("update {}", documentAnnotations.size());
        LOGGER.debug("Annotations to update : {}", documentAnnotations);
        List<DocumentAnnotation> updatedDocumentAnnotations = new LinkedList<>();
        // Pre prepared update statement for the annotations table
        String updateStatement = "update " + getTableName() + " set CONTENTSTRING=? where DOC_ID=?";
        for (DocumentAnnotation documentAnnotation : documentAnnotations) {
            try {

                // update the content based on the document ID
                // plus the content into the db
                int rowsAffected = template.update(updateStatement, documentAnnotation.getData().getContent(),
                        documentAnnotation.getData().getDocumentFileURI());

                // If no exception is thrown then we add the annotations to the
                // success pile
                if (rowsAffected > 0) {
                    updatedDocumentAnnotations.add(documentAnnotation);
                }
            }
            catch (DataAccessException e) {
                LOGGER.debug(T01202 + ": Impossible to update annotation" + documentAnnotation.getId(), e);
            }
        }

        LOGGER.debug("Rows updated: {}", updatedDocumentAnnotations.size());
        // if all were updated, the return them to the destination
        return updatedDocumentAnnotations;

    }

    @Override
    public List<? extends Boolean> delete(List<DocumentAnnotation> annotations) {
        LOGGER.debug("DELETE {}", annotations.size());

        String query = "DELETE FROM " + getTableName() + " WHERE ANNO_ID = ?";

        List<Boolean> executionResults = new ArrayList<>(annotations.size());
        for (DocumentAnnotation id : annotations) {
            try {
                // update one by one
                int rowsAffected = template.update(query, id.getId().getValue());

                // set response to true
                LOGGER.debug("Rows updated: {}", rowsAffected);
            }
            catch (DataAccessException e) {
                LOGGER.debug(T01203 + ": Impossible to delete annotation" + id, e);
                // set response to false
                executionResults.add(false);
            }
        }

        return executionResults;
    }

    @Override
    public List<DocumentAnnotation> findByDocumentFileId(List<String> documentFileIds) throws SugarTechnicalException {

        LOGGER.debug("GET ANNOTATIONS BY DOCUMENTS FILE IDS: {}", documentFileIds);

        // immediatly return an empty list or else we risk getting a poorly
        // formatted exception
        if (documentFileIds == null || documentFileIds.isEmpty()) {
            return new LinkedList<>();
        }
        try {
            // String to be queried
            StringBuilder query = new StringBuilder("select * from ").append(getTableName()).append(" where ");

            // Variables to be paired with the query
            LinkedList<String> variables = new LinkedList<>();
            for (String id : documentFileIds) {
                query.append("DOC_ID = ?").append(" OR ");
                variables.add(id);
            }
            // Last " OR " that is allways added
            query.setLength(query.length() - 4);
            List<DocumentAnnotation> documentFiles = template.query(query.toString(), variables.toArray(),
                    new RowMapper<DocumentAnnotation>() {

                        @Override
                        public DocumentAnnotation mapRow(ResultSet rs, int row) throws SQLException {
                            DocumentAnnotation documentAnnotation = new DocumentAnnotation();
                            documentAnnotation.setId(new Id(rs.getString("ANNO_ID"), "", ""));
                            DocumentAnnotationDataType dataType = new DocumentAnnotationDataType();
                            dataType.setDocumentFileURI(rs.getString("DOC_ID"));
                            dataType.setContent(rs.getString("CONTENTSTRING"));
                            documentAnnotation.setData(dataType);
                            return documentAnnotation;
                        }

                    });
            LOGGER.debug("FOUND : {}", documentFiles);
            return documentFiles;
        }
        catch (DataAccessException e) {
            LOGGER.error(T01204 + " " + e.getMessage(), e);
            throw ExceptionBuilder.createTechnicalException(T01204, documentFileIds);
        }
    }

    /*
     * Not really used...
     * 
     * Just here because the implementation (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.dao.api.documentannotation.DocumentAnnotationDAO
     * #get(java.util.List)
     */
    @Override
    public List<DocumentAnnotation> get(List<Id> ids) throws SugarTechnicalException {
        LOGGER.debug("GET ANNOTATIONS BY ID: {}", ids);
        try

        {
            StringBuilder query = new StringBuilder("select * from ").append(getTableName()).append(" where ");
            LinkedList<String> variables = new LinkedList<>();
            for (EDMS2IdentificationType id : ids) {
                query.append("ANNO_ID = ?").append(" OR ");
                variables.add(id.getValue());
            }
            // remove end
            query.setLength(query.length() - 4);
            List<DocumentAnnotation> documentFiles = template.query(query.toString(), variables.toArray(),
                    new RowMapper<DocumentAnnotation>() {

                        @Override
                        public DocumentAnnotation mapRow(ResultSet rs, int row) throws SQLException {
                            DocumentAnnotation documentAnnotation = new DocumentAnnotation();
                            documentAnnotation.setId(new Id(rs.getString("ANNO_ID"), "", ""));
                            DocumentAnnotationDataType dataType = new DocumentAnnotationDataType();
                            dataType.setDocumentFileURI(rs.getString("DOC_ID"));
                            dataType.setContent(rs.getString("CONTENTSTRING"));
                            documentAnnotation.setData(dataType);
                            return documentAnnotation;
                        }

                    });
            return documentFiles;
        }
        catch (DataAccessException e) {
            LOGGER.error(T01204 + " " + e.getMessage(), e);
            throw ExceptionBuilder.createTechnicalException(T01204, ids);
        }

    }

    /*
     * Fix around to solve the problem that is storing the document files and
     * annotations on a diferent schema
     */
    protected String getTableName() {
        return docUser + "." + TABLE_NAME;
    }

    public String getDocUser() {
        return docUser;
    }

    public void setDocUser(String docUser) {
        this.docUser = docUser;
    }

}
