package com.bnpp.cardif.sugar.dao.oracle.fact;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00909;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00910;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00911;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.fact.FactDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.JAXBStringWriter;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.Fact;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

/**
 * Specific implementation of {@link FactDAO} based on a classic SQL table. All
 * methods use standard JDBC {@link PreparedStatement}
 * 
 * @author Christopher Laszczuk
 * 
 */
@Component
public class FactOracleDAO extends AbstractDAO implements FactDAO {
    
    private String table = "FACTS";

    @Override
    public void store(String scope, Fact fact) throws SugarTechnicalException {
        try {
            String insert;
            if (ObjectType.FILE.equals(fact.getType())) {
                insert = "insert into facts (Scope, CreationDate, ObjectType, Action,Content, UserName) values (?,?,?,?,?,?)";
            }
            else {
                insert = "insert into facts (Scope, CreationDate, ObjectType, Action,XML_Content, UserName) values (?,?,?,?,?,?)";

            }
            ArrayList<Object> variables = new ArrayList<>();
            variables.add(scope);
            variables.add(fact.getCreationDate().getTime());
            variables.add(fact.getType().toString());
            variables.add(fact.getAction().toString());
            variables.add(getSerializedObjectId(fact));
            variables.add(fact.getUser());
            template.update(insert, variables.toArray());
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00909, fact.getType(), scope, e);
        }
    }

    @Override
    public List<Fact> getAll(String scope) throws SugarTechnicalException {
        try {
            String query = "select * from facts where scope= ? ORDER BY CreationDate, ObjectType";

            String[] variables = { scope };
            List<Fact> facts = template.query(query, variables, new RowMapper<Fact>() {

                @Override
                public Fact mapRow(ResultSet rs, int row) throws SQLException {
                    Fact fact = new Fact(new Date(rs.getLong("CreationDate")));
                    fact.setType(ObjectType.valueOf(rs.getString("ObjectType")));
                    fact.setAction(Action.valueOf(rs.getString("Action")));
                    fact.setObjectId(rs.getString("CONTENT"));
                    fact.setUser(rs.getString("UserName"));
                    return fact;
                }

            });
            return facts;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00910, scope, e);
        }
    }

    @Override
    public String getUserObjectAction(FACT_OBJECT object, String action, String id) throws SugarTechnicalException {
        List<String> result;
        try {
            StringBuilder query = new StringBuilder("SELECT username FROM FACTS WHERE EXTRACTVALUE(XML_CONTENT,'/");
            query.append(object.getNameId()).append("','").append(object.getNamespace()).append("') = ? ");
            query.append("AND ACTION = ? ORDER BY CREATIONDATE DESC");
            String[] variables = { id, action };

            result = template.query(query.toString(), variables, new RowMapper<String>() {
                @Override
                public String mapRow(ResultSet rs, int row) throws SQLException {
                    return rs.getString(1);
                }
            });

            if (!result.isEmpty() && result.get(0) != null) {
                return result.get(0);
            }
            return null;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00909, e);
        }
    }

    @Override
    public Date getTaskUpdateDate(String scope, TaskId taskId) throws SugarTechnicalException {
        List<Long> result;
        try {
            String query = "SELECT MAX(creationdate) FROM facts," + "XMLTABLE( "
                    + "XMLNAMESPACES('http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1' AS \"task\"),"
                    + " '/task:TaskId' PASSING xml_content  COLUMNS taskid path '/task:TaskId')"
                    + " where objecttype='TASK' and taskid=? " + "and scope=?" + " GROUP BY taskid";
            String[] variables = { taskId.getValue(), scope };
            result = template.query(query, variables, new RowMapper<Long>() {
                @Override
                public Long mapRow(ResultSet rs, int row) throws SQLException {
                    return rs.getLong(1);
                }

            });

            return new Date(result.get(0));
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00910, scope, e);
        }
    }

    private String getSerializedObjectId(Fact fact) throws SugarTechnicalException {
        switch (fact.getType()) {
        case BASKET:
            JAXBStringWriter<BasketId> basketIdWriter = getWriter(BasketId.class);
            return basketIdWriter.write((BasketId) fact.getObjectId());
        case BUSINESS_SCOPE:
            JAXBStringWriter<BusinessScopeId> bSIdWriter = getWriter(BusinessScopeId.class);
            return bSIdWriter.write((BusinessScopeId) fact.getObjectId());

        case DOCUMENT:
            JAXBStringWriter<Id> docIdWriter = getWriter(Id.class);
            return docIdWriter.write((Id) fact.getObjectId());
        case DOCUMENT_CLASS:
            JAXBStringWriter<ClassId> docClassIdWriter = getWriter(ClassId.class);
            return docClassIdWriter.write((ClassId) fact.getObjectId());
        case ENVELOPE:
            JAXBStringWriter<Id> envIdWriter = getWriter(Id.class);
            return envIdWriter.write((Id) fact.getObjectId());
        case ENVELOPE_CLASS:
            JAXBStringWriter<ClassId> envClassIdWriter = getWriter(ClassId.class);
            return envClassIdWriter.write((ClassId) fact.getObjectId());
        case FILE:
            return (String) fact.getObjectId();
        case FOLDER:
            JAXBStringWriter<FolderId> folderIdWriter = getWriter(FolderId.class);
            return folderIdWriter.write((FolderId) fact.getObjectId());
        case FOLDER_CLASS:
            JAXBStringWriter<ClassId> folderClassIdWriter = getWriter(ClassId.class);
            return folderClassIdWriter.write((ClassId) fact.getObjectId());
        case TAG_CLASS:
            JAXBStringWriter<ClassId> tagClassIdWriter = getWriter(ClassId.class);
            return tagClassIdWriter.write((ClassId) fact.getObjectId());
        case TASK:
            JAXBStringWriter<TaskId> taskIdWriter = getWriter(TaskId.class);
            return taskIdWriter.write((TaskId) fact.getObjectId());
        default:
            throw ExceptionBuilder.createTechnicalException(T00911, fact.getType());
        }
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }
}
