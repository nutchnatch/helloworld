package com.bnpp.cardif.sugar.dao.oracle.task;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00506;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00507;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00508;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00509;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00510;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00511;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00512;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00513;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.task.TaskDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

@Component
public class TaskOracleDAO extends AbstractDAO implements TaskDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskOracleDAO.class);

    private static final String TASK_ARG = "taskArg";

    private static final String TASKS_FETCHED = "TasksFetched";

    private static final String VARCHARARRAY = ".VARCHARARRAY";

    private static final String TASK_IDS = "taskIds";

    private static final String SCOPE_IN = "scopeIn";

    private class StoreSingleTaskProc extends StoredProcedure {

        public StoreSingleTaskProc() {
            super(getDataSource(), "PKG_TASK.STORETASKS_SINGLE");
            declareParameter(new SqlParameter(TASK_ARG, Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(Task task) throws SugarTechnicalException {
            final String write = getWriter(Task.class).write(task);
            Map in = new HashMap();
            in.put(TASK_ARG, new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    /**
     * @inheritDoc
     */
    public void storeTasks(List<Task> tasks) throws SugarTechnicalException {
        LOGGER.info("Trying to store {} tasks", tasks.size());
        try {
            StoreSingleTaskProc singleTaskProc = new StoreSingleTaskProc();
            for (Task task : tasks) {
                singleTaskProc.run(task);
            }
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00506, e);
        }
    }

    private class GetProc extends StoredProcedure {

        public GetProc() {
            super(getDataSource(), "PKG_TASK.get");
            declareParameter(new SqlParameter(SCOPE_IN, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(TASK_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlOutParameter(TASKS_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<Task> run(String scope, List<TaskId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (TaskId id : ids) {
                serializedIds.add(getWriter(TaskId.class).write(id));
            }

            Map in = new HashMap();
            in.put(SCOPE_IN, scope);
            in.put(TASK_IDS, new SqlArrayValue(serializedIds.toArray()));
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(TASKS_FETCHED);
            List<Task> unwrappedTasks = new ArrayList<>(serializedResults.size());
            for (String unwrappedTask : serializedResults) {
                unwrappedTasks.add(getReader(Task.class).read(unwrappedTask));
            }

            return unwrappedTasks;
        }

    }

    /**
     * @inheritDoc
     */
    @SuppressWarnings("squid:S1192")
    @Override
    public List<Task> get(String scope, List<TaskId> tasksId) throws SugarTechnicalException {
        try {
            GetProc getProc = new GetProc();
            List<Task> fetchedTasks = getProc.run(scope, tasksId);

            LOGGER.info("{} tasks have been fetched from database", fetchedTasks.size());
            return fetchedTasks;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00507, e);
        }
    }

    private class GetTasksForDocProc extends StoredProcedure {

        public GetTasksForDocProc() {
            super(getDataSource(), "PKG_TASK.GETTASKFORDOC");
            declareParameter(new SqlParameter(SCOPE_IN, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("docIds", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(TASKS_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<Task> run(String scope, Id docId) throws SugarTechnicalException {

            Map in = new HashMap();
            in.put(SCOPE_IN, scope);
            in.put("docIds", getWriter(Id.class).write(docId));
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(TASKS_FETCHED);
            List<Task> unwrappedTasks = new ArrayList<>(serializedResults.size());
            for (String unwrappedTask : serializedResults) {
                unwrappedTasks.add(getReader(Task.class).read(unwrappedTask));
            }

            return unwrappedTasks;
        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public List<Task> getTasksForDoc(String scope, Id docId) throws SugarTechnicalException {
        try {
            LOGGER.debug("Fetching task for documents {}", docId);
            GetTasksForDocProc tasksForDocProc = new GetTasksForDocProc();
            List<Task> fetchedTasks = tasksForDocProc.run(scope, docId);

            LOGGER.info("{} tasks have been fetched from database", fetchedTasks.size());
            return fetchedTasks;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00508, docId, e);
        }
    }

    private class UpdateStatusProc extends StoredProcedure {

        public UpdateStatusProc() {
            super(getDataSource(), "PKG_TASK.UPDATESTATUS");
            declareParameter(new SqlParameter(SCOPE_IN, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(TASK_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlParameter("statusIn", OracleTypes.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String scope, List<TaskId> ids, String status) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (TaskId id : ids) {
                serializedIds.add(getWriter(TaskId.class).write(id));
            }

            Map in = new HashMap();
            in.put(SCOPE_IN, scope);
            in.put(TASK_IDS, new SqlArrayValue(serializedIds.toArray()));
            in.put("statusIn", status);
            this.execute(in);

        }
    }

    /**
     * @inheritDoc
     */
    @Override
    public void updateStatus(String scope, List<TaskId> tasksId, String status) throws SugarTechnicalException {
        try {
            UpdateStatusProc updateStatusProc = new UpdateStatusProc();
            LOGGER.info("Updating tasks: {} ", tasksId.size());
            updateStatusProc.run(scope, tasksId, status);
            LOGGER.info("Tasks updated");
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00509, status, tasksId, e);
        }
    }

    private class LockProc extends StoredProcedure {

        public LockProc() {
            super(getDataSource(), "PKG_TASK.LOCKTASK");
            declareParameter(new SqlParameter(SCOPE_IN, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(TASK_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlParameter("lockerName", OracleTypes.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String scope, List<TaskId> ids, String lockerName) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (TaskId id : ids) {
                serializedIds.add(getWriter(TaskId.class).write(id));
            }

            Map in = new HashMap();
            in.put(SCOPE_IN, scope);
            in.put(TASK_IDS, new SqlArrayValue(serializedIds.toArray()));
            in.put("lockerName", lockerName);
            this.execute(in);

        }

    }

    @Override
    /**
     * @inheritDoc
     */
    public void lock(String scope, List<TaskId> ids, String lockerName) throws SugarTechnicalException {
        try {
            LOGGER.info("locking task with id : {} and scope {}", ids, scope);
            LockProc lockProc = new LockProc();
            lockProc.run(scope, ids, lockerName);
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00510, ids, lockerName, e);
        }
    }

    private class UnlockProc extends StoredProcedure {

        public UnlockProc() {
            super(getDataSource(), "PKG_TASK.UNLOCKTASK");
            declareParameter(new SqlParameter(SCOPE_IN, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(TASK_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String scope, List<TaskId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (TaskId id : ids) {
                serializedIds.add(getWriter(TaskId.class).write(id));
            }

            Map in = new HashMap();
            in.put(SCOPE_IN, scope);
            in.put(TASK_IDS, new SqlArrayValue(serializedIds.toArray()));
            this.execute(in);

        }
    }

    @Override
    /**
     * @inheritDoc
     */
    public void unlock(String scope, List<TaskId> ids) throws SugarTechnicalException {
        try {
            LOGGER.info("unlocking tasks with id : {} and scope {}", ids, scope);
            UnlockProc unlockProc = new UnlockProc();
            unlockProc.run(scope, ids);
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00511, ids, e);
        }
    }

    private class TransferProc extends StoredProcedure {

        public TransferProc() {
            super(getDataSource(), "PKG_TASK.TRANSFER");
            declareParameter(new SqlParameter(SCOPE_IN, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(TASK_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlParameter("basketIdValue", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("basketIdScheme", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("basketIdIssuer", OracleTypes.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String scope, List<TaskId> ids, String basketIdValue, String basketIdScheme,
                String basketIdIssuer) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (TaskId id : ids) {
                serializedIds.add(getWriter(TaskId.class).write(id));
            }

            Map in = new HashMap();
            in.put(SCOPE_IN, scope);
            in.put(TASK_IDS, new SqlArrayValue(serializedIds.toArray()));
            in.put("basketIdValue", basketIdValue);
            in.put("basketIdScheme", basketIdScheme);
            in.put("basketIdIssuer", basketIdIssuer);
            this.execute(in);

        }
    }

    @Override
    /**
     * @inheritDoc
     */
    public void transfer(String scope, List<TaskId> ids, BasketId basketId) throws SugarTechnicalException {
        try {
            TransferProc transferProc = new TransferProc();
            LOGGER.info("Transfering tasks with id : {} and scope {}", ids, scope);
            transferProc.run(scope, ids, basketId.getValue(), basketId.getScheme(), basketId.getIssuer());
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00512, ids, basketId, e);
        }
    }

    private class GetTasksInBasketProc extends StoredProcedure {

        public GetTasksInBasketProc() {
            super(getDataSource(), "PKG_TASK.GETTASKSINBASKET");
            declareParameter(new SqlParameter("p_start", OracleTypes.NUMBER));
            declareParameter(new SqlParameter("p_max", OracleTypes.NUMBER));
            declareParameter(new SqlParameter(SCOPE_IN, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("issuerIn", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("schemeIn", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("basketIdIn", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("EXCLUDE_CLOSE", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(TASKS_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            declareParameter(new SqlOutParameter("counter", OracleTypes.NUMBER));
            compile();
        }

        List<Task> unwrappedTasks;

        long counter;

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(int start, int end, String scope, String issuer, String scheme, String basketValue,
                String EXCLUDE_CLOSE) throws SugarTechnicalException {

            Map in = new HashMap();
            in.put("p_start", start);
            in.put("p_max", end);
            in.put(SCOPE_IN, scope);
            in.put("issuerIn", issuer);
            in.put("schemeIn", scheme);
            in.put("basketIdIn", basketValue);
            in.put("EXCLUDE_CLOSE", EXCLUDE_CLOSE);
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(TASKS_FETCHED);
            counter = ((BigDecimal) out.get("counter")).longValue();
            unwrappedTasks = new ArrayList<>(serializedResults.size());
            for (String unwrappedTask : serializedResults) {
                unwrappedTasks.add(getReader(Task.class).read(unwrappedTask));
            }

        }

        public List<Task> getTasks() {
            return unwrappedTasks;
        }

        public long getCounter() {
            return counter;
        }
    }

    @Override
    /**
     * @inheritDoc
     */
    public SearchResults<Task> getTasksInBasket(String scope, BasketId basketId, int start, int max,
            Boolean includeClosed) throws SugarTechnicalException {
        try {

            LOGGER.info("fetching task from {} to {}", start, max);
            GetTasksInBasketProc tasksInBasketProc = new GetTasksInBasketProc();
            tasksInBasketProc.run(start, max, scope, basketId.getIssuer(), basketId.getScheme(), basketId.getValue(),
                    includeClosed.toString().toLowerCase());

            List<Task> fetchedTasks = tasksInBasketProc.getTasks();
            long found = tasksInBasketProc.getCounter();

            LOGGER.info("{} : Tasks were fetched from database", fetchedTasks.size());

            return new SearchResults<>(fetchedTasks, found);
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00513, basketId, e);
        }
    }

    private class UpdateSingleTaskProc extends StoredProcedure {

        public UpdateSingleTaskProc() {
            super(getDataSource(), "PKG_TASK.UPDATETASKS_SINGLE");
            declareParameter(new SqlParameter(TASK_ARG, Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(Task task) throws SugarTechnicalException {
            final String write = getWriter(Task.class).write(task);
            Map in = new HashMap();
            in.put(TASK_ARG, new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void update(List<Task> tasksToUpdate) throws SugarTechnicalException {
        LOGGER.info("Trying to update {}  tasks", tasksToUpdate.size());
        try {
            UpdateSingleTaskProc singleTaskProc = new UpdateSingleTaskProc();
            for (Task task : tasksToUpdate) {
                singleTaskProc.run(task);
            }
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00506, e);
        }

    }

    private class GetTasksByUser extends StoredProcedure {

        public GetTasksByUser() {
            super(getDataSource(), "PKG_TASK.GETTASKBYUSER");
            declareParameter(new SqlParameter(SCOPE_IN, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("userName", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(TASKS_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<Task> run(String scope, String userName) throws SugarTechnicalException {

            Map in = new HashMap();
            in.put(SCOPE_IN, scope);
            in.put("userName", userName);
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(TASKS_FETCHED);
            List<Task> unwrappedTasks = new ArrayList<>(serializedResults.size());
            for (String unwrappedTask : serializedResults) {
                unwrappedTasks.add(getReader(Task.class).read(unwrappedTask));
            }

            return unwrappedTasks;
        }
    }

    @Override
    public List<Task> getByUser(String scope, String userName) throws SugarTechnicalException {
        try {
            LOGGER.debug("Fetching task for user {}", userName);
            GetTasksByUser getTasksByUser = new GetTasksByUser();
            List<Task> fetchedTasks = getTasksByUser.run(scope, userName);
            LOGGER.info("{} tasks have been fetched from database", fetchedTasks.size());
            return fetchedTasks;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00508, userName, e);
        }
    }

    @Override
    public List<TaskId> fetchIdsByScope(String scope) throws SugarTechnicalException {
        try {
            StringBuilder query = new StringBuilder("SELECT ID_VALUE, ID_SCHEME, ID_ISSUER FROM TASKS WHERE SCOPE = ?");

            List<TaskId> res;
            res = template.query(query.toString(), new Object[] { scope }, new RowMapper<TaskId>() {

                @Override
                public TaskId mapRow(ResultSet rs, int row) throws SQLException {

                    TaskId id = new TaskId();
                    id.setValue(rs.getString(1));
                    id.setScheme(rs.getString(2));
                    id.setIssuer(rs.getString(3));
                    return id;

                }
            });
            return res;

        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00507, e);
        }
    }
}
