package com.bnpp.cardif.sugar.dao.oracle.util;

import java.util.Map;

import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

/**
 * Provide ability to map a name space to a custom prefix
 * 
 * @author Christopher Laszczuk
 * 
 */
public class SugarNameSpacePrefixMapper extends NamespacePrefixMapper {
    
    private Map<String, String> prefixes;

    @Override
    public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
        String prefix = prefixes.get(namespaceUri);
        return prefix != null && !prefix.isEmpty() ? prefix : suggestion;
    }

    public Map<String, String> getPrefixes() {
        return prefixes;
    }

    public void setPrefixes(Map<String, String> prefixes) {
        this.prefixes = prefixes;
    }

}
