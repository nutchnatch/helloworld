package com.bnpp.cardif.sugar.dao.oracle.documentclass;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00201;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00202;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00203;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00204;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00205;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00206;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.documentclass.DocumentClassDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.jaxb.DateAdapter;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

/**
 * DocumentClass Oracle DAO Backend TODO Methods are set synchronized, this
 * shall be optimized
 * 
 * @author Francois Barre
 * 
 */
@Component
public class DocumentClassOracleDAO extends AbstractDAO implements DocumentClassDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentClassOracleDAO.class);
    
    private static final String CLASS_ID_ARG = "ClassID_ARG";
    private static final String VARCHARARRAY = ".VARCHARARRAY";
    private static final String CLASSES_FETCHED = "ClassesFetched";
    private static final String CLASS_IDS = "ClassIds";
    private static final String P_SCOPE = "p_scope";

    private class StoreSingleProc extends StoredProcedure {

        public StoreSingleProc() {
            super(getDataSource(), "PKG_DOCUMENTCLASS.STORE_SINGLE");
            declareParameter(new SqlParameter("DOCUMENTCLASSARG", Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(DocumentClass documentClass) throws SugarTechnicalException {
            final String write = getWriter(DocumentClass.class).write(documentClass);

            Map in = new HashMap();
            in.put("DOCUMENTCLASSARG", new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public synchronized void store(List<DocumentClass> documentClasses) throws SugarTechnicalException {

        LOGGER.debug("Storing {} document classes in database", documentClasses.size());
        try {
            StoreSingleProc storeSingleProc = new StoreSingleProc();
            for (DocumentClass documentClass : documentClasses) {
                storeSingleProc.run(documentClass);
            }
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00201, documentClasses, e);
        }
        LOGGER.info("{} document classes have been stored in database", documentClasses.size());

    }

    private class SearchProc extends StoredProcedure {

        public SearchProc() {
            super(getDataSource(), "PKG_DOCUMENTCLASS.SEARCH");
            declareParameter(new SqlParameter("SCOPEARG", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("CATEGORYARG", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("ACTIVE", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter("documentClassCursor", OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<DocumentClass> run(String scope, Category category, Boolean isActiveOnly)
                throws SugarTechnicalException {
            Map in = new HashMap();
            in.put("SCOPEARG", scope);
            in.put("CATEGORYARG", category != null ? category.toString() : null);
            in.put("ACTIVE", isActiveOnly.toString().toLowerCase());
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get("documentClassCursor");
            List<DocumentClass> unwrappedDocumentClasses = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocumentClasses.add(getReader(DocumentClass.class).read(serializedDocument));
            }

            return unwrappedDocumentClasses;
        }
    }

    @Override
    public synchronized List<DocumentClass> search(String scope, Category category, Boolean isActiveOnly)
            throws SugarTechnicalException {

        try {

            SearchProc searchProc = new SearchProc();

            List<DocumentClass> results = searchProc.run(scope, category, isActiveOnly);
            LOGGER.info("{} document classes have been fetched from database from search", results.size());
            return results;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00206, scope, category, isActiveOnly, e);
        }

    }

    private class UpdateSingleProc extends StoredProcedure {

        public UpdateSingleProc() {
            super(getDataSource(), "PKG_DOCUMENTCLASS.UPDATE_CLASSES_SINGLE");
            declareParameter(new SqlParameter("DocumentClassToUpdate", Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(DocumentClass documentClass) throws SugarTechnicalException {
            final String write = getWriter(DocumentClass.class).write(documentClass);

            Map in = new HashMap();
            in.put("DocumentClassToUpdate", new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void update(List<DocumentClass> classes) throws SugarTechnicalException {
        try {
            UpdateSingleProc updateSingleProc = new UpdateSingleProc();
            for (DocumentClass documentClass : classes) {
                updateSingleProc.run(documentClass);
            }

            LOGGER.info("{} document classes have been updated in database", classes.size());
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00202, e);
        }
    }

    private class GetProc extends StoredProcedure {

        public GetProc() {
            super(getDataSource(), "PKG_DOCUMENTCLASS.GET");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(CLASS_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlOutParameter(CLASSES_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<DocumentClass> run(String scope, List<ClassId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (ClassId id : ids) {
                serializedIds.add(getWriter(ClassId.class).write(id));
            }
            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put(CLASS_IDS, new SqlArrayValue(serializedIds.toArray()));
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(CLASSES_FETCHED);
            List<DocumentClass> unwrappedDocumentClasses = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocumentClasses.add(getReader(DocumentClass.class).read(serializedDocument));
            }

            return unwrappedDocumentClasses;
        }
    }

    @Override
    public List<DocumentClass> get(String scope, List<ClassId> ids) throws SugarTechnicalException {
        try {
            LOGGER.info("Trying to fetch {} document classes", ids.size());

            GetProc getProc = new GetProc();

            List<DocumentClass> results = getProc.run(scope, ids);
            LOGGER.info("{} document classes have been fetched from database", results.size(), "classes");
            return results;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00203, ids, e);
        }
    }

    private class GetAllVersionsProc extends StoredProcedure {

        public GetAllVersionsProc() {
            super(getDataSource(), "PKG_DOCUMENTCLASS.GETALLVERSIONS");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(CLASS_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlOutParameter(CLASSES_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<DocumentClass> run(String scope, List<ClassId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (ClassId id : ids) {
                serializedIds.add(getWriter(ClassId.class).write(id));
            }
            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put(CLASS_IDS, new SqlArrayValue(serializedIds.toArray()));
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(CLASSES_FETCHED);
            List<DocumentClass> unwrappedDocumentClasses = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocumentClasses.add(getReader(DocumentClass.class).read(serializedDocument));
            }

            return unwrappedDocumentClasses;
        }
    }

    @Override
    public List<DocumentClass> getAllVersions(String scope, List<ClassId> ids) throws SugarTechnicalException {
        try {
            LOGGER.info("Trying to fetch all versions of document classes", ids);
            GetAllVersionsProc getAllVersionsProc = new GetAllVersionsProc();

            List<DocumentClass> results = getAllVersionsProc.run(scope, ids);
            LOGGER.info("{} document classes have been fetched from database", results.size(), "classes");
            return results;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00203, ids, e);
        }
    }

    private class SetActiveProc extends StoredProcedure {

        public SetActiveProc() {
            super(getDataSource(), "PKG_DOCUMENTCLASS.SETACTIVE");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(CLASS_ID_ARG, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlParameter("activate", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("updateDate", OracleTypes.VARCHAR));
            compile();
        }

        public void run(String scope, List<ClassId> ids, boolean activate) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (ClassId id : ids) {
                serializedIds.add(getWriter(ClassId.class).write(id));
            }
            Map<String, Object> in = new HashMap<>();
            in.put(P_SCOPE, scope);
            in.put(CLASS_ID_ARG, new SqlArrayValue<String>(serializedIds.toArray(new String[ids.size()])));
            in.put("activate", Boolean.toString(activate));
            in.put("updateDate", DateAdapter.printDateTime(new Date()));
            this.execute(in);
        }
    }

    @Override
    public void setActive(String scope, List<ClassId> ids, boolean activate) throws SugarTechnicalException {
        try {
            SetActiveProc activeProc = new SetActiveProc();
            activeProc.run(scope, ids, activate);
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00204, ids, activate, e);
        }
    }

    private class DeleteProc extends StoredProcedure {

        public DeleteProc() {
            super(getDataSource(), "PKG_DOCUMENTCLASS.DELETECLASS");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(CLASS_ID_ARG, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String scope, List<ClassId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (ClassId id : ids) {
                serializedIds.add(getWriter(ClassId.class).write(id));
            }
            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put(CLASS_ID_ARG, new SqlArrayValue(serializedIds.toArray()));
            this.execute(in);
        }
    }

    @Override
    public void remove(String scope, List<ClassId> ids) throws SugarTechnicalException {
        try {

            DeleteProc deleteProc = new DeleteProc();
            deleteProc.run(scope, ids);
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00205, ids, e);
        }
    }
}
