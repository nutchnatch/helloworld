package com.bnpp.cardif.sugar.dao.oracle.businessscope;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00601;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00602;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00603;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.businessscope.BusinessScopeDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;

@Component
public class BusinessScopeOracleDAO extends AbstractDAO implements BusinessScopeDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessScopeOracleDAO.class);
    
    private static final String BUSINESS_SCOPE_CURSOR = "BusinessScopeCursor";

    private class StoreSingleProc extends StoredProcedure {

        public StoreSingleProc() {
            super(getDataSource(), "PKG_SCOPE.STORE_SINGLE");
            declareParameter(new SqlParameter("SCOPEARG", Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(BusinessScope businessScope) throws SugarTechnicalException {
            final String write = getWriter(BusinessScope.class).write(businessScope);

            Map in = new HashMap();
            in.put("SCOPEARG", new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void store(List<BusinessScope> businessScopes) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Trying to store {} business scopes {}", businessScopes.size(), businessScopes);

        try {
            StoreSingleProc storeSingleProc = new StoreSingleProc();
            for (BusinessScope businessScope : businessScopes) {
                storeSingleProc.run(businessScope);
            }
        }
        catch (Exception e) {
            throw ExceptionBuilder.createFunctionalException(F00601, businessScopes, e);
        }
    }

    private class GetByNameProc extends StoredProcedure {

        public GetByNameProc() {
            super(getDataSource(), "PKG_SCOPE.getByName");
            declareParameter(
                    new SqlParameter("BusinessScopeIds", OracleTypes.ARRAY, getDbUserName() + ".VARCHARARRAY"));
            declareParameter(new SqlOutParameter(BUSINESS_SCOPE_CURSOR, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<BusinessScope> run(String[] xmlAsStringArra) throws SugarTechnicalException {

            Map in = new HashMap();
            in.put("BusinessScopeIds", new SqlArrayValue(xmlAsStringArra));
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(BUSINESS_SCOPE_CURSOR);
            List<BusinessScope> unwrappedBusiness = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedBusiness.add(getReader(BusinessScope.class).read(serializedDocument));
            }

            return unwrappedBusiness;
        }

    }

    @Override
    public List<BusinessScope> getBySymbolicName(List<String> symbolicNames) throws SugarTechnicalException {
        LOGGER.info("Trying to get business scopes {} ", symbolicNames);

        String[] xmlAsStringArray = new String[symbolicNames.size()];
        for (int i = 0; i < symbolicNames.size(); i++) {
            xmlAsStringArray[i] = symbolicNames.get(i);
        }

        try {
            GetByNameProc byNameProc = new GetByNameProc();
            return byNameProc.run(xmlAsStringArray);
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00602, symbolicNames, e);
        }
    }

    private class GetAllProc extends StoredProcedure {

        public GetAllProc() {
            super(getDataSource(), "PKG_SCOPE.GETALL");
            declareParameter(new SqlOutParameter(BUSINESS_SCOPE_CURSOR, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<BusinessScope> run() throws SugarTechnicalException {

            Map in = new HashMap();
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(BUSINESS_SCOPE_CURSOR);
            List<BusinessScope> unwrappedBusiness = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedBusiness.add(getReader(BusinessScope.class).read(serializedDocument));
            }

            return unwrappedBusiness;
        }

    }

    @Override
    public List<BusinessScope> getAll() throws SugarTechnicalException {
        LOGGER.info("Trying to fetch all business scopes");
        try {
            GetAllProc allProc = new GetAllProc();
            allProc.execute();

            List<BusinessScope> results = allProc.run();
            LOGGER.info("{} BusinessScopes have been fetched", results.size());
            return results;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00603, e);
        }
    }

    private class UpdateSingleProc extends StoredProcedure {

        public UpdateSingleProc() {
            super(getDataSource(), "PKG_SCOPE.UPDATE_SCOPE_SINGLE");
            declareParameter(new SqlParameter("SCOPE_TO_UPDATE", Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(BusinessScope businessScope) throws SugarTechnicalException {
            final String write = getWriter(BusinessScope.class).write(businessScope);

            Map in = new HashMap();
            in.put("SCOPE_TO_UPDATE", new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void update(List<BusinessScope> businessScopes) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.info("Trying to update {} business scopes {}", businessScopes.size(), businessScopes);

        try {
            UpdateSingleProc updateSingleProc = new UpdateSingleProc();
            for (BusinessScope businessScope : businessScopes) {
                updateSingleProc.run(businessScope);
            }
        }
        catch (Exception e) {
            throw ExceptionBuilder.createFunctionalException(F00601, businessScopes, e);
        }

    }
}