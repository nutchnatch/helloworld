package com.bnpp.cardif.sugar.dao.oracle.xpath;

import com.bnpp.cardif.sugar.dao.oracle.util.Namespaces;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;

/**
 * Helper which facilitates building of XPath expression to access to a document
 * field
 * 
 * @author Christopher Laszczuk
 * 
 */
@Deprecated
public class XPathDocumentCriterionHelper implements XPathFieldHelper {
    private static final String COLUMN_NAME = "XML_CONTENT";

    /**
     * Gets the XPtath query for a document allowing to access to a
     * {@link Criterion}.<br/>
     * <br/>
     * This method does not care of criterion value.
     * 
     * @param criterion
     *            The criterion to access
     * @return The XPath query
     */
    @Override
    public String getQuery(Criterion criterion) {
        StringBuilder query = new StringBuilder();
        switch (criterion.getLevel()) {
        case TAG:
            query.append("extract(" + COLUMN_NAME + ", '/doc:Document/common:Tags/common:Tag[@name = \"")
                    .append(criterion.getName()).append("\"]/common:Value/text()',' ").append(Namespaces.DOC)
                    .append(" ').getStringVal()");
            return query.toString();
        case DATA:
            query.append("extract(" + COLUMN_NAME + ", '/doc:Document/doc:Data/common:").append(criterion.getName())
                    .append("/text()',' ").append(Namespaces.DOC).append(" ').getStringVal()");
            return query.toString();
        case ATTRIBUTE:
            query.append("extract(" + COLUMN_NAME + ", '/doc:Document/@").append(criterion.getName()).append("',' ")
                    .append(Namespaces.DOC).append(" ').getStringVal()");
            return query.toString();
        default:
            throw new IllegalArgumentException("Criterion level " + criterion.getLevel() + " is not supported");
        }
    }
}