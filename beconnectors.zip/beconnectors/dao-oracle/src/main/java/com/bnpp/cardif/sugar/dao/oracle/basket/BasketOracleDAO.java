package com.bnpp.cardif.sugar.dao.oracle.basket;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00502;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00503;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.basket.BasketDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;

@Component
public class BasketOracleDAO extends AbstractDAO implements BasketDAO {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(BasketOracleDAO.class);

    private static final String BASKET_PACKAGE_NAME = "PKG_BASKET";
    private static final String BASKET_FETCHED = "BasketFetched";
    private static final String P_SCOPE = "p_scope";

    private class StoreSingleProc extends StoredProcedure {

        public StoreSingleProc() {
            super(getDataSource(), BASKET_PACKAGE_NAME + ".store_single");
            declareParameter(new SqlParameter("p_BASKET", Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(Basket basket) throws SugarTechnicalException {
            final String write = getWriter(Basket.class).write(basket);

            Map in = new HashMap();
            in.put("p_BASKET", new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    /**
     * @inheritDoc
     */
    public void store(List<Basket> basketsToStore) throws SugarTechnicalException {
        try {
            StoreSingleProc storeSingleProc = new StoreSingleProc();
            LOGGER.info("Storing {} baskets", basketsToStore.size());
            for (Basket basket : basketsToStore) {
                storeSingleProc.run(basket);
            }
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00503, e);
        }
    }

    private class GetProc extends StoredProcedure {

        public GetProc() {
            super(getDataSource(), BASKET_PACKAGE_NAME + ".get");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("ID_VALUEs", OracleTypes.ARRAY, getDbUserName() + ".VARCHARARRAY"));
            declareParameter(new SqlOutParameter(BASKET_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<Basket> run(String scope, List<BasketId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (BasketId id : ids) {
                serializedIds.add(getWriter(BasketId.class).write(id));
            }

            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put("ID_VALUEs", new SqlArrayValue(serializedIds.toArray()));
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(BASKET_FETCHED);
            List<Basket> unwrappedDocuments = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocuments.add(getReader(Basket.class).read(serializedDocument));
            }

            return unwrappedDocuments;
        }

    }

    @Override
    /**
     * @inheritDoc
     */
    public List<Basket> get(List<BasketId> ids, String scope) throws SugarTechnicalException {
        LOGGER.debug("Fetching baskets having followings ids : {}", ids);
        try {
            GetProc get = new GetProc();
            List<Basket> fetchedDocuments = get.run(scope, ids);

            LOGGER.info("{} Basket have been fetched from database", fetchedDocuments.size());
            return fetchedDocuments;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00502, ids, e);
        }
    }

    private class GetAllProc extends StoredProcedure {

        public GetAllProc() {
            super(getDataSource(), BASKET_PACKAGE_NAME + ".GETALL");
            declareParameter(new SqlParameter("scopeIn", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(BASKET_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<Basket> run(String scope) throws SugarTechnicalException {

            Map in = new HashMap();
            in.put("scopeIn", scope);
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(BASKET_FETCHED);
            List<Basket> unwrappedDocuments = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocuments.add(getReader(Basket.class).read(serializedDocument));
            }

            return unwrappedDocuments;
        }

    }

    @Override
    /**
     * @inheritDoc
     */
    public List<Basket> getAll(String scope) throws SugarTechnicalException {
        try {
            GetAllProc getAllProc = new GetAllProc();

            LOGGER.debug("Fetching all baskets for scope {} ", scope);
            List<Basket> baskets = getAllProc.run(scope);
            LOGGER.info("{} basket(s) were fetched", baskets.size());
            return baskets;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00503, scope, e);
        }
    }

    private class UpdateSingleProc extends StoredProcedure {

        public UpdateSingleProc() {
            super(getDataSource(), BASKET_PACKAGE_NAME + ".UPDATE_BASKET_SINGLE");
            declareParameter(new SqlParameter("basketToUpdate", Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(Basket basket) throws SugarTechnicalException {
            final String write = getWriter(Basket.class).write(basket);

            Map in = new HashMap();
            in.put("basketToUpdate", new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    /**
     * @inheritDoc
     */
    public void update(List<Basket> basketsToUpdate) throws SugarTechnicalException {
        try {
            UpdateSingleProc updateSingleProc = new UpdateSingleProc();
            LOGGER.info("Storing {} baskets", basketsToUpdate.size());
            for (Basket basket : basketsToUpdate) {
                updateSingleProc.run(basket);
            }
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00503, e);
        }
    }

    private class DeleteProc extends StoredProcedure {

        public DeleteProc() {
            super(getDataSource(), BASKET_PACKAGE_NAME + ".DELETE_BASKET");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("basketsToDelete", OracleTypes.ARRAY, getDbUserName() + ".VARCHARARRAY"));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String scope, List<BasketId> ids) throws SugarTechnicalException {
            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (BasketId id : ids) {
                serializedIds.add(getWriter(BasketId.class).write(id));
            }

            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put("basketsToDelete", new SqlArrayValue(serializedIds.toArray()));
            this.execute(in);
        }

    }

    @Override
    /**
     * @inheritDoc
     */
    public void delete(List<BasketId> ids, String scope) throws SugarTechnicalException {
        DeleteProc deleteProc = new DeleteProc();
        LOGGER.info("Deleting Baskets for the scope {} and having the followings ids : {}", scope, ids);
        try {
            deleteProc.run(scope, ids);
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00503, e);
        }
    }
}
