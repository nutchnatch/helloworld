package com.bnpp.cardif.sugar.dao.oracle.xpath;

import org.springframework.stereotype.Component;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;

@Component("xPathFolderHelper")
public class XPathFolderHelper implements XPathFieldHelper {

    @Override
    public String getQuery(Criterion criterion) {
        StringBuilder pathBuilder = new StringBuilder();

        switch (criterion.getLevel()) {
        case ATTRIBUTE:
            pathBuilder.append("/folder:Folder/@").append(criterion.getName());
            return pathBuilder.toString();

        case DATA:
            pathBuilder.append("/folder:Folder/folder:Data/common:").append(criterion.getName());
            return pathBuilder.toString();
        case TAG:
            pathBuilder.append("/folder:Folder/common:Tags/common:Tag[@name=\"").append(criterion.getName())
                    .append("\"]/common:Value");
            return pathBuilder.toString();
        case CHILD:
            pathBuilder.append("/folder:Folder/folder:ChildComponents/doc:Id[@Issuer=\"")
                    .append(criterion.getValues().get(0)).append("\" and @Scheme=\"")
                    .append(criterion.getValues().get(1)).append("\"]");
            return pathBuilder.toString();
        case QUICK:
            pathBuilder.append("/folder:Folder/common:Tags/common:Tag/common:Value").append(",")
                    .append("/folder:Folder/folder:Data/common:Name");
            return pathBuilder.toString();

        default:
            throw new IllegalArgumentException("Criterion level " + criterion.getLevel() + " is not supported");

        }
    }
}
