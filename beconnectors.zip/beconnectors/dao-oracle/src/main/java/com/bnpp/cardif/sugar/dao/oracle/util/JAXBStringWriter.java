package com.bnpp.cardif.sugar.dao.oracle.util;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00012;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

/**
 * Writer dedicated for a {@link JAXBContext}. This writer allows to transform
 * objects into XML a <code>String</code>.
 * 
 * This class must be carefully used because it instantiates a
 * {@link Marshaller}. It is designed to be reused as needed being auto
 * resettable.
 * 
 * @author Christopher Laszczuk
 * 
 */
public class JAXBStringWriter<T> {
    private final Marshaller marshaller;

    public JAXBStringWriter(Class<T> type) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(type);
        marshaller = context.createMarshaller();
    }

    /**
     * Sets the {@link NamespacePrefixMapper} of object type to marshal
     * according to JAXB API.
     * 
     * @param nameSpacePrefixMapper
     *            Mapper allowing to map name spaces to specific prefixes
     * 
     * @throws PropertyException
     *             when there is an error processing the given property or value
     * @throws IllegalArgumentException
     *             If the name parameter is null
     * @see {@link Marshaller#setProperty(String, Object)} with
     *      <code>"com.sun.xml.bind.namespacePrefixMapper"</code> as property
     *      name
     */
    public void setNameSpacePrefixMapper(NamespacePrefixMapper nameSpacePrefixMapper) throws PropertyException {
        marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", nameSpacePrefixMapper);
    }

    /**
     * Sets the schema location of object type to marshal according to JAXB API.
     * <br/>
     * <br/>
     * <u>Example</u>:
     * <code>http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1 MCODocument.xsd</code>
     * 
     * @param schemaLocation
     *            The location of the XML schema
     * 
     * @throws PropertyException
     *             when there is an error processing the given property or value
     * @throws IllegalArgumentException
     *             If the name parameter is null
     * @see {@link Marshaller#setProperty(String, Object)}
     */
    public void setSchemaLocation(String schemaLocation) throws PropertyException {
        marshaller.setProperty(Marshaller.JAXB_SCHEMA_LOCATION, schemaLocation);
    }

    /**
     * Writes in this writer an object according to a {@link Marshaller}. The
     * first step of this method is to reset the writer.
     * 
     * @param objectToTransform
     *            The object to transform
     * @throws SugarTechnicalException
     *             If the object cannot be serialized to String
     */
    public synchronized String write(T objectToTransform) throws SugarTechnicalException {
        try {
            StringWriter writer = new StringWriter();

            writer.getBuffer().setLength(0);
            marshaller.marshal(objectToTransform, writer);
            return writer.toString();
        }
        catch (Exception e) {
            Class<? extends Object> objectInfo = objectToTransform != null ? objectToTransform.getClass() : null;
            throw ExceptionBuilder.createTechnicalException(T00012, objectInfo, e);
        }
    }

}
