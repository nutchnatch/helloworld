package com.bnpp.cardif.sugar.dao.oracle.util;

import java.io.LineNumberReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.google.common.base.Preconditions;

public class SqlRunner extends AbstractDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(SqlRunner.class);

    public static final String DEFAULT_DELIMITER = "/";

    private final boolean autoCommit;

    private final boolean stopOnError;

    private final String commandDelimiter = SqlRunner.DEFAULT_DELIMITER;

    public SqlRunner(DataSource dataSource, final boolean autoCommit, final boolean stopOnError, String dbUserName,
            Integer maxCursor) throws SQLException {
        Preconditions.checkNotNull(dataSource, "SqlRunner requires an SQL datasource");
        setDataSource(dataSource);
        this.autoCommit = autoCommit;
        this.stopOnError = stopOnError;
        setDbUserName(dbUserName);
        setMaxOpenCursor(maxCursor);
    }

    public void runScript(final Reader reader) throws SQLException, SugarTechnicalException {
        Connection connection = getConnection();
        try {
            connection.setAutoCommit(this.autoCommit);
            runScript(connection, reader);
        }
        finally {
            closeConnection(connection);
        }
    }

    @SuppressWarnings("squid:S134")
    private void runScript(final Connection conn, final Reader reader) {
        StringBuilder command = new StringBuilder();
        try {
            final LineNumberReader lineReader = new LineNumberReader(reader);
            String line;
            while ((line = lineReader.readLine()) != null) {
                String trimmedLine = line.trim();

                if (trimmedLine.startsWith("--") || trimmedLine.startsWith("//") || trimmedLine.startsWith("#")) {
                    LOGGER.debug("Commented line: {}", trimmedLine);
                }
                else if (trimmedLine.endsWith(this.commandDelimiter)) {
                    // Append line without delimiter
                    command.append(line.substring(0, line.lastIndexOf(this.commandDelimiter)));
                    command.append(" ");

                    LOGGER.debug("Command: {}", command);
                    Statement statememt = null;
                    try {
                        statememt = conn.createStatement();
                        executeStatement(command.toString(), statememt);
                    }
                    finally {
                        if (statememt != null) {
                            statememt.close();
                        }
                    }

                    command.setLength(0);
                }
                else {
                    command.append(line);
                    command.append(" ");
                }
            }
            if (!this.autoCommit) {
                conn.commit();
            }
        }
        catch (final Exception e) {
            LOGGER.error("An error occurred on command {}", command, e);
        }
    }

    private void executeStatement(String command, Statement stmt) throws SQLException {
        if (this.stopOnError) {
            stmt.execute(command);
        }
        else {
            try {
                stmt.execute(command);
            }
            catch (final SQLException e) {
                LOGGER.error("An error occurred on command {}", command, e);
            }
        }
    }
}
