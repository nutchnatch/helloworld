package com.bnpp.cardif.sugar.dao.oracle.util;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00013;

import java.io.InputStream;
import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.w3c.dom.Node;

import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;

public class JAXBStringReader<T> {
    private final Unmarshaller unmarshaller;

    private Class<T> type;

    public JAXBStringReader(Class<T> type) throws JAXBException {
        JAXBContext context = JAXBContext.newInstance(type);
        unmarshaller = context.createUnmarshaller();
        this.type = type;
    }

    @SuppressWarnings("unchecked")
    public synchronized T read(String stringToRead) throws SugarTechnicalException {
        try {
            StringReader reader = new StringReader(stringToRead);
            return (T) unmarshaller.unmarshal(reader);
        }
        catch (JAXBException e) {
            throw ExceptionBuilder.createTechnicalException(T00013, type, stringToRead, e);
        }
    }

    @SuppressWarnings("unchecked")
    public synchronized T read(InputStream is) throws JAXBException {
        return (T) unmarshaller.unmarshal(is);
    }

    @SuppressWarnings("unchecked")
    public synchronized T read(Node nodeToRead) throws JAXBException {
        return (T) unmarshaller.unmarshal(nodeToRead);
    }

}
