package com.bnpp.cardif.sugar.dao.oracle.util.token;

import java.util.HashMap;
import java.util.Map;

public class MapTokenResolver {
    protected Map<String, String> tokens = new HashMap<>();

    public MapTokenResolver() {
        // empty constructor
    }

    public String resolveToken(String tokenName) {
        if (tokens == null) {
            throw new IllegalArgumentException("No token map is set");
        }
        return this.tokens.get(tokenName);
    }

    public Map<String, String> getTokens() {
        return tokens;
    }

    public void setTokens(Map<String, String> tokens) {
        this.tokens = tokens;
    }
}