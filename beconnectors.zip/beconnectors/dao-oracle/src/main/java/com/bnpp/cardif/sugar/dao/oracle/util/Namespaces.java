package com.bnpp.cardif.sugar.dao.oracle.util;

public class Namespaces {

    public static final String DOC = "xmlns:doc=\"http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1\", xmlns:common=\"http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1\"";

    public static final String FOLDER = "xmlns:folder=\"http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1\" xmlns:common=\"http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1\"";

    private Namespaces() {
        throw new IllegalAccessError("Utility class");
    }
}
