package com.bnpp.cardif.sugar.dao.oracle.util;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00003;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00009;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00010;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlReturnType;
import org.springframework.jdbc.support.lob.LobHandler;

import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

public abstract class AbstractDAO {
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractDAO.class);

    @Value("${spring.datasource.max.opencursor}")
    private Integer maxOpenCursor;

    @Value("${spring.datasource.username}")
    private String dbUserName;

    /**
     * Value of logs, Higher {@link Math#abs(loglevel)} mean higher level of
     * detail on logs
     * 
     * if loglevel is negative then the logs are recorded on the DB if loglevel
     * is positive then the logs are sended to the dbms console
     */
    @Value("${spring.datasource.loglevel}")
    private Integer loglevel;

    @Autowired
    private DataSource dataSource;

    @Autowired
    protected JdbcTemplate template;

    @Autowired
    protected LobHandler lobHandler;

    private boolean useWriterCache = true;

    private boolean useReaderCache = true;

    @Autowired
    private NamespacePrefixMapper nameSpacePrefixMapper;

    public void init() throws SugarTechnicalException {
        // legacy
    }

    protected Connection getConnection() throws SugarTechnicalException {

        Connection connection = null;
        try {
            for (int i = 0; i < 5; i++) {
                String errMsg = "Unable to get connection from pool";
                connection = getConnectionNoRetry(i, errMsg);
                if (connection != null) {
                    break;
                }
            }
            return connection;
        }
        catch (SQLException e) {
            LOGGER.info("error code" + e.getErrorCode());
            throw ExceptionBuilder.createTechnicalException(T00003, e);
        }

    }

    private Connection getConnectionNoRetry(int i, String errMsg) throws SQLException {
        Connection connection = null;
        try {
            LOGGER.debug("Trying to get Oracle connection...Number of try {}", i);
            connection = dataSource.getConnection();
            if (connection == null) {
                throw new SQLException(errMsg);
            }
        }
        catch (SQLException e) {
            if (i >= 5 || !(e.getErrorCode() == 17143 || e.getMessage().equals(errMsg))) {
                throw e;
            }
            else {
                LOGGER.debug("Trying to get Oracle connection...retrying");
                try {
                    Thread.sleep(10);
                }
                catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
            }

        }
        return connection;
    }

    protected void closeConnection(Connection connection) {
        try {
            LOGGER.trace("Closing existing connection {}", connection);
            connection.close();
        }
        catch (SQLException e) {
            LOGGER.error("Exception caugth when closing connection, error code " + e.getErrorCode(), e);
        }
    }

    private final Map<Class<?>, JAXBStringWriter<?>> writerCache = new HashMap<>();

    @SuppressWarnings("unchecked")
    public synchronized <T> JAXBStringWriter<T> getWriter(Class<T> clazz) throws SugarTechnicalException {
        JAXBStringWriter<T> writer = (JAXBStringWriter<T>) writerCache.get(clazz);
        if (writer != null) {
            return writer;
        }
        try {
            writer = new JAXBStringWriter<>(clazz);
            writer.setNameSpacePrefixMapper(nameSpacePrefixMapper);
            if (useWriterCache) {
                writerCache.put(clazz, writer);
            }
            return writer;
        }
        catch (JAXBException e) {
            throw ExceptionBuilder.createTechnicalException(T00009, clazz, e);
        }
    }

    private final Map<Class<?>, JAXBStringReader<?>> readerCache = new HashMap<>();

    @SuppressWarnings("unchecked")
    public synchronized <T> JAXBStringReader<T> getReader(Class<T> clazz) throws SugarTechnicalException {
        JAXBStringReader<T> reader = (JAXBStringReader<T>) readerCache.get(clazz);
        if (reader != null) {
            return reader;
        }
        try {
            reader = new JAXBStringReader<>(clazz);
            if (useReaderCache) {
                readerCache.put(clazz, reader);
            }
            return reader;
        }
        catch (JAXBException e) {
            throw ExceptionBuilder.createTechnicalException(T00010, clazz, e);
        }
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public DataSource getDataSource() {
        return dataSource;

    }

    /**
     * @return the template
     */
    public JdbcTemplate getTemplate() {
        return template;
    }

    /**
     * @param template
     *            the template to set
     */
    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public synchronized void setUseWriterCache(boolean useWriterCache) {
        this.useWriterCache = useWriterCache;
    }

    public synchronized void setUseReaderCache(boolean useReaderCache) {
        this.useReaderCache = useReaderCache;
    }

    public void setDbUserName(String dbUserName) {
        this.dbUserName = dbUserName;
    }

    public void setMaxOpenCursor(Integer maxOpenCursor) {
        this.maxOpenCursor = maxOpenCursor;
    }

    public String getDbUserName() {
        return dbUserName;
    }

    public Integer getLoglevel() {
        return loglevel;
    }

    public void setLoglevel(Integer loglevel) {
        this.loglevel = loglevel;
    }

    protected class ObjectMapper implements RowMapper<String> {

        int column;

        public ObjectMapper(int column) {
            super();
            this.column = column;
        }

        @Override
        public String mapRow(ResultSet rs, int row) throws SQLException {
            String objectAsString = rs.getString(column);

            return objectAsString;
        }

    }

    protected class ClobReturnType implements SqlReturnType {
        public ClobReturnType() {
            super();
        }

        @Override
        public Object getTypeValue(CallableStatement cs, int paramIndex, int sqlType, String typeName)
                throws SQLException {
            try {
                StringBuilder sb = new StringBuilder();

                final Clob aClob = cs.getClob(paramIndex);
                Reader reader = aClob.getCharacterStream();
                BufferedReader br = new BufferedReader(reader);

                String line;
                while (null != (line = br.readLine())) {
                    sb.append(line);
                }
                br.close();

                return sb.toString();
            }
            catch (IOException e) {
                throw new SQLException(e);
            }
        }

    }

}
