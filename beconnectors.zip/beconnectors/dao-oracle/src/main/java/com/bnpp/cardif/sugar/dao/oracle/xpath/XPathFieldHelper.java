package com.bnpp.cardif.sugar.dao.oracle.xpath;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;

/**
 * Defines a {@link Criterion} helper dedicated to build XPath query
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface XPathFieldHelper {
    /**
     * Gets XPath query allowing to access to the value of a field corresponding
     * to supplied {@link Criterion}
     * 
     * @param criterion
     *            The criterion to access
     * @return The XPath query
     * 
     * @see Criterion#getName()
     */
    String getQuery(Criterion criterion);
}
