package com.bnpp.cardif.sugar.dao.oracle.reporting;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00901;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00904;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00907;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00908;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.reporting.ReportingDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;

@Component
public class ReportingOracleDAO extends AbstractDAO implements ReportingDAO {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportingOracleDAO.class);

    @SuppressWarnings("squid:S2629")
    @Override
    public List<EnvelopeFlows> getEnvelopesAndDocumentFlow(String scope, String startingDate, String endingDate)
            throws SugarTechnicalException {
        String query1 = " SELECT    ENVELOPECLASSES_DATA.ENVELOPECLASS_ID,ENVELOPECLASSES_DATA.ENVELOPECLASS_ISSUER,   ENVELOPES_DATA.ENVELOPEDIRECTION,   ENVELOPES_DATA.ENVELOPES_CREATED,   ENVELOPES_DATA.DOCUMENTS_DOCS,   ENVELOPES_DATA.filesize"
                + " FROM" + " (" + " SELECT DISTINCT ID_VALUE as ENVELOPECLASS_ID,ID_ISSUER as ENVELOPECLASS_ISSUER  "
                + " FROM DOCUMENTCLASSES" + " WHERE scope = ? and category='ENVELOPE'" + " ) ENVELOPECLASSES_DATA"
                + " LEFT JOIN(" + " SELECT" + " ENVELOPES_XML.CLASS_ID AS ENVELOPECLASS_ID,"
                + " ENVELOPES_XML.DIRECTION_CODE AS ENVELOPEDIRECTION,"
                + " COUNT(DISTINCT ENVELOPES_XML.ENV_ID) AS ENVELOPES_CREATED,"
                + " COUNT(ENVELOPES_XML.CHILD_ID) AS DOCUMENTS_DOCS," + " sum(CHILD_DOCUMENTS.filesize) as filesize"
                + " FROM " + " ( SELECT/*+INDEX (SCOPE_ENVELOPES.documents_idx_otext) */ XML_CONTENT"
                + " FROM (select xml_content from documents where scope=?)SCOPE_ENVELOPES"
                + "  WHERE contains(SCOPE_ENVELOPES.XML_CONTENT,'<query>" + " <textquery lang=\"FRENCH\"> "
                + " ( (  HASPATH ( /doc:Document/@Category=\"ENVELOPE\" ) AND HASPATH(/doc:Document/doc:Data/common:ValidityCode != \"UNDER_CONSTRUCTION\") ) )";
        String query2 = " </textquery> <score datatype=\"INTEGER\" algorithm=\"COUNT\"/>" + " </query>',1)>0"
                + " ) ENVELOPES_FILTERED," + "  XMLTABLE("
                + "   XMLNAMESPACES(  'http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1' AS \"common\","
                + "                  'http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1' AS \"doc\"),"
                + " 'for $i in /doc:Document/doc:ChildObject/doc:Id" + " return " + " <row>{" + " $i,"
                + " <envelopeId>{" + " $i/../../doc:Id" + " }</envelopeId>," + " $i/../../doc:Data/common:ClassId,"
                + " $i/../../doc:Data/common:DirectionCode" + " }           " + "  </row>'"
                + "     PASSING ENVELOPES_FILTERED.XML_CONTENT" + "  COLUMNS"
                + "   ENV_ID  PATH '/row/envelopeId/doc:Id'," + "  CLASS_ID  PATH '/row/common:ClassId',"
                + "  DIRECTION_CODE  PATH '/row/common:DirectionCode'," + "   CHILD_ID PATH '/row/doc:Id'"
                + "   ) ENVELOPES_XML" + "  INNER JOIN ("
                + " select id_value,length(binary) as filesize from (select /*+INDEX (SCOPE_DOCUMENTS.documents_idx_otext)*/ id_value,xml_content from (select id_value,xml_content from documents where scope=?)SCOPE_DOCUMENTS "
                + "   where contains(SCOPE_DOCUMENTS.XML_CONTENT,'" + "  <query>" + "   <textquery lang=\"FRENCH\"> "
                + "   ( (  HASPATH ( /doc:Document/@Category=\"DOCUMENT\" ) AND HASPATH(/doc:Document/doc:Data/common:ValidityCode != \"UNDER_CONSTRUCTION\") ) )";
        String query3 = "     </textquery><score datatype=\"INTEGER\" algorithm=\"COUNT\"/>" + " </query>',1)>0"
                + " ) FILTERED_DOCUMENTS, XMLTABLE ( XMLNAMESPACES(  'http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1' AS \"common\","
                + "             'http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1' AS \"doc\"),"
                + "           '/doc:Document'" + "               PASSING FILTERED_DOCUMENTS.xml_content" + "    columns"
                + "           URI PATH'/doc:Document/doc:FileData/doc:URI'"
                + " ) CHILD_XML inner join DOCUMENTFILES ON DOCUMENTFILES.URI=CHILD_XML.URI)CHILD_DOCUMENTS "
                + " on ENVELOPES_XML.CHILD_ID=CHILD_DOCUMENTS.ID_VALUE " + " group by "
                + "   ENVELOPES_XML.CLASS_ID,ENVELOPES_XML.DIRECTION_CODE" + " ) ENVELOPES_DATA "
                + " on ENVELOPES_DATA.ENVELOPECLASS_ID=ENVELOPECLASSES_DATA.ENVELOPECLASS_ID";

        try {

            ArrayList<String> variables = new ArrayList<>();
            variables.add(scope);
            variables.add(scope);
            variables.add(scope);
            String dateQuerry = "";
            if (startingDate != null && endingDate != null) {

                StringBuilder dateQuerryBuilder = new StringBuilder();
                dateQuerryBuilder.append(" and ((\"").append(getDateTokenValue(startingDate, true))
                        .append(" \")inpath (/doc:Document/doc:Data/common:CreatnDate/@tokenDate)) ").append("and ((\"")
                        .append(getDateTokenValue(endingDate, false))
                        .append(" \") inpath (/doc:Document/doc:Data/common:CreatnDate/@tokenDate))");
                dateQuerry = dateQuerryBuilder.toString();

            }
            StringBuilder queryBuilder = new StringBuilder();
            queryBuilder.append(query1).append(dateQuerry).append(query2).append(dateQuerry).append(query3);
            LOGGER.info("Getting envelope stock with query {}", queryBuilder.toString());

            List<EnvelopeFlows> results;
            results = template.query(queryBuilder.toString(), variables.toArray(), new RowMapper<EnvelopeFlows>() {

                @Override
                public EnvelopeFlows mapRow(ResultSet rs, int row) throws SQLException {

                    EnvelopeFlows envelopeFlows = new EnvelopeFlows();
                    envelopeFlows.setDirectionCode(rs.getString(3));
                    envelopeFlows.setClassId(new ClassId(rs.getString(1), rs.getString(2), 0));
                    envelopeFlows.setNumberOfEnvelopes(rs.getLong(4));
                    envelopeFlows.setNumberOfDocuments(rs.getLong(5));
                    envelopeFlows.setSizeOfDocuments(rs.getLong(6));
                    return envelopeFlows;
                }

            });
            return results;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00901, scope, startingDate, endingDate, e);
        }
    }

    private String getDateTokenValue(String date, boolean isGreater) throws SugarTechnicalException {
        String dateQuery = "select pkg_tools.encodeGTorLtValue(to_number(to_char(to_date (?,'YYYY-MM-DD'),'j'))- 2378497,?,20,10) from DUAL";

        try {
            int greaterParam;

            if (isGreater) {

                greaterParam = 1;
            }
            else {
                greaterParam = 0;

            }

            ArrayList<Object> variables = new ArrayList<>();
            variables.add(date);
            variables.add(greaterParam);
            List<String> result;
            result = template.query(dateQuery, variables.toArray(), new RowMapper<String>() {

                @Override
                public String mapRow(ResultSet rs, int row) throws SQLException {
                    return rs.getString(1);
                }
            });

            return result.isEmpty() ? null : result.get(0);
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00901, e);
        }

    }

    @Override
    public List<BasketRatio> getBasketClosedRatios(String scope, String startingDate, String endingDate)
            throws SugarTechnicalException {

        List<BasketRatio> basketRatios;
        try {

            String querry = "SELECT   id_value,id_issuer,id_scheme,opened_tasks,closed_tasks FROM   ( SELECT  id_value,id_scheme,id_issuer FROM baskets WHERE SCOPE=?) baskets_data LEFT JOIN ("
                    + " SELECT basketid, COUNT(id_value) AS opened_tasks FROM tasks WHERE status in ('NEW','PENDING') "
                    + "AND to_timestamp_tz(create_date,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM') "
                    + "< to_timestamp_tz(?,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM')      "
                    + "AND to_timestamp_tz(create_date,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM') "
                    + "> to_timestamp_tz(?,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM') and scope=? "
                    + "GROUP BY basketid )open_data ON open_data.basketid=baskets_data.id_value "
                    + "LEFT JOIN  ( SELECT basketid, COUNT(id_value) AS closed_tasks FROM tasks WHERE "
                    + "status ='CLOSE' AND to_timestamp_tz(update_date,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM') < "
                    + "to_timestamp_tz(?,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM') AND "
                    + "to_timestamp_tz(update_date,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM') >"
                    + "to_timestamp_tz(?,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM')"
                    + "AND scope=? GROUP BY basketid ) T2 ON T2.basketid=baskets_data.id_value ";

            ArrayList<Object> variables = new ArrayList<>();

            LOGGER.info("Basket ratio querry : {}", querry);
            LOGGER.info("end : {}  start : {}", endingDate, startingDate);

            variables.add(scope);
            variables.add(endingDate);
            variables.add(startingDate);
            variables.add(scope);
            variables.add(endingDate);
            variables.add(startingDate);
            variables.add(scope);

            basketRatios = template.query(querry, variables.toArray(), new RowMapper<BasketRatio>() {

                @Override
                public BasketRatio mapRow(ResultSet rs, int row) throws SQLException {
                    BasketRatio basketRatio = new BasketRatio();
                    basketRatio.setBasketId(new BasketId(rs.getString(1), rs.getString(2), rs.getString(3)));
                    basketRatio.setNumberOfOpened(rs.getLong(4));
                    basketRatio.setNumberOfClosed(rs.getLong(5));
                    return basketRatio;
                }
            });
            return basketRatios;

        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00904, scope, startingDate, endingDate, e);
        }
    }

    @SuppressWarnings("squid:S2629")
    @Override
    public List<DocumentStock> getDocumentStockIndicators(String scope, String startingDate, String endingDate)
            throws SugarTechnicalException {
        try {
            ArrayList<Object> variables = new ArrayList<>();
            variables.add(scope);
            variables.add(scope);
            String query1 = "SELECT "
                    + "DOCUMENTCLASSES_DATA.DOCUMENTCLASS_ID, DOCUMENTCLASSES_DATA.DOCUMENTCLASS_ISSUER, T3.DOCUMENT_CREATED,  T3.document_file"
                    + " FROM(" + " SELECT distinct ID_VALUE as DOCUMENTCLASS_ID,id_issuer as DOCUMENTCLASS_ISSUER "
                    + " FROM DOCUMENTCLASSES" + " WHERE scope = ? and category='DOCUMENT'" + " )DOCUMENTCLASSES_DATA"
                    + " LEFT JOIN( SELECT T2.class_id,count(t.id_value) as document_created,sum(LENGTH(DOCUMENTFILES.BINARY)) as document_file   FROM "
                    + "(select id_value,xml_content from (select id_value,xml_content from documents where scope=?) SCOPED_DOCUMENTS  "
                    + "where contains(SCOPED_DOCUMENTS.xml_content," + "'<query><textquery lang=\"FRENCH\">     "
                    + "(HASPATH ( /doc:Document/@Category=\"DOCUMENT\" ) AND HASPATH(/doc:Document/doc:Data/common:ValidityCode != \"UNDER_CONSTRUCTION\" ) )";
            String querry2 = "</textquery></query>')>0) T ,"
                    + " XMLTABLE(XMLNAMESPACES('http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1' AS \"doc\","
                    + " 'http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1' as \"common\"),"
                    + " '/doc:Document'" + " PASSING t.XML_CONTENT" + " COLUMNS "
                    + " URI PATH '/doc:Document/doc:FileData/doc:URI',"
                    + " CLASS_ID PATH '/doc:Document/doc:Data/common:ClassId') T2 LEFT JOIN DOCUMENTFILES ON DOCUMENTFILES.URI=T2.URI GROUP BY T2.CLASS_ID)T3 "
                    + "on DOCUMENTCLASSES_DATA.DOCUMENTCLASS_ID = T3.class_id";

            String dateQuerry = "";

            // We only allow query apend because there is already validation on
            // the variable
            if (startingDate != null && endingDate != null) {
                StringBuilder dateQuerryBuilder = new StringBuilder();
                dateQuerryBuilder.append(" and ((\"").append(getDateTokenValue(startingDate, true))
                        .append(" \")inpath (/doc:Document/doc:Data/common:CreatnDate/@tokenDate)) ").append("and ((\"")
                        .append(getDateTokenValue(endingDate, false))
                        .append(" \") inpath (/doc:Document/doc:Data/common:CreatnDate/@tokenDate))");
                dateQuerry = dateQuerryBuilder.toString();

            }

            StringBuilder querryBuilder = new StringBuilder();
            querryBuilder.append(query1).append(dateQuerry).append(querry2);
            LOGGER.info("Getting Document stock according querry  : {}", querryBuilder.toString());

            List<DocumentStock> result;
            result = template.query(querryBuilder.toString(), variables.toArray(), new RowMapper<DocumentStock>() {

                @Override
                public DocumentStock mapRow(ResultSet rs, int row) throws SQLException {
                    DocumentStock stock = new DocumentStock();
                    stock.setClassId(new ClassId(rs.getString(1), rs.getString(2), 0));
                    stock.setNumberOfDocuments(rs.getLong(3));
                    stock.setSizeOfFiles(rs.getLong(4));
                    return stock;

                }
            });
            return result;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00907, scope, e);
        }
    }

    @SuppressWarnings("squid:S2629")
    @Override
    public List<FolderStock> getFolderStockIndicators(String scope, String startingDate, String endingDate)
            throws SugarTechnicalException {
        try {

            LOGGER.info("Trying to get folder reporting between {} and {}", startingDate, endingDate);
            String querry = " SELECT    FOLDERCLASSES_DATA.FOLDERCLASS_ID, FOLDERCLASSES_DATA.FOLDERCLASS_ISSUER, FOLDERS_DATA.FOLDERS_CREATED"
                    + "  FROM" + " ("
                    + "    SELECT distinct ID_VALUE as FOLDERCLASS_ID, ID_ISSUER as FOLDERCLASS_ISSUER "
                    + "    FROM FOLDERCLASSES" + "    WHERE scope =?" + "  )  " + " FOLDERCLASSES_DATA" + " LEFT JOIN"
                    + " (SELECT" + "   FOLDERS_XML.CLASS_ID as FOLDERCLASS_ID,"
                    + "   count(DISTINCT FOLDERS_XML.FOLDER_ID) as FOLDERS_CREATED" + "  FROM "
                    + "   ( SELECT XML_CONTENT"
                    + "     FROM (select xml_content from FOLDERS where scope=?)SCOPED_FOLDERS"
                    + "     WHERE CONTAINS(SCOPED_FOLDERS.xml_content," + "'<query><textquery lang=\"FRENCH\">";
            String querry2 = "</textquery></query>')>0" + "   ) FOLDERS_FILTERED, " + "   XMLTABLE("
                    + "     XMLNAMESPACES(  'http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1' AS \"folder\","
                    + "                     'http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1' AS \"common\","
                    + "                   'http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1' AS \"doc\"),"
                    + " ' /folder:Folder'" + " PASSING FOLDERS_FILTERED.XML_CONTENT" + " COLUMNS"
                    + " CLASS_ID  PATH '/folder:Folder/folder:Data/common:ClassId',"
                    + " FOLDER_ID PATH '/folder:Folder/folder:FolderId') FOLDERS_XML"
                    + " group by FOLDERS_XML.class_id) FOLDERS_DATA"
                    + " ON FOLDERCLASSES_DATA.FOLDERCLASS_ID = FOLDERS_DATA.FOLDERCLASS_ID";

            ArrayList<String> variables = new ArrayList<>();
            variables.add(scope);
            variables.add(scope);
            String dateQuerry = "";

            // We only allow query apend because there is already validation on
            // the variable
            if (startingDate != null && endingDate != null) {
                StringBuilder dateQuerryBuilder = new StringBuilder();
                dateQuerryBuilder.append("  ((\"").append(getDateTokenValue(startingDate, true))
                        .append(" \")inpath (/folder:Folder/folder:Data/common:CreatnDate/@tokenDate)) ")
                        .append("and ((\"").append(getDateTokenValue(endingDate, false))
                        .append(" \") inpath (/folder:Folder/folder:Data/common:CreatnDate/@tokenDate))");
                dateQuerry = dateQuerryBuilder.toString();

            }

            StringBuilder querryBuilder = new StringBuilder();
            querryBuilder.append(querry).append(dateQuerry).append(querry2);

            LOGGER.info("Getting folder stock with querry {}", querryBuilder.toString());
            List<FolderStock> result = template.query(querryBuilder.toString(), variables.toArray(),
                    new RowMapper<FolderStock>() {

                        @Override
                        public FolderStock mapRow(ResultSet rs, int row) throws SQLException {
                            FolderStock stock = new FolderStock();
                            stock.setClassId(new ClassId(rs.getString(1), rs.getString(2), 0));
                            stock.setNumberOfFolders(rs.getLong(3));
                            return stock;
                        }

                    });
            return result;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00908, scope, e);
        }
    }

    @Override
    public Summary getReportingSummary(String scope) throws SugarTechnicalException {
        String query = "SELECT * FROM (SELECT COUNT(ID_VALUE) as number_tasks FROM TASKS WHERE TASKS.SCOPE=?)T1,"
                + "   (SELECT COUNT(ID_VALUE) AS NUMBER_DOCS FROM (SELECT ID_VALUE, XML_CONTENT FROM DOCUMENTS WHERE SCOPE=?)T"
                + " WHERE CONTAINS(T.XML_CONTENT,' <query> <textquery lang=\"FRENCH\">      ( (  HASPATH ( /doc:Document/@Category=\"DOCUMENT\" ) ) )</textquery> "
                + "</query>',1)>0)T2,"
                + "(SELECT COUNT(ID_VALUE) AS NUMBER_ENVELOPES FROM (SELECT ID_VALUE, XML_CONTENT FROM DOCUMENTS WHERE SCOPE=?)T WHERE  "
                + "CONTAINS(T.XML_CONTENT,' <query>  <textquery lang=\"FRENCH\"> ( (  HASPATH ( /doc:Document/@Category=\"ENVELOPE\" ) ))</textquery> </query>',1)>0)t3,"
                + "(select count(id_value) as number_folders from folders where scope=?)t4";

        try {

            ArrayList<String> variables = new ArrayList<>();
            variables.add(scope);
            variables.add(scope);
            variables.add(scope);
            variables.add(scope);
            LOGGER.info("Getting reporting summary with query : {}", query);
            List<Summary> summary = template.query(query, variables.toArray(), new RowMapper<Summary>() {

                @Override
                public Summary mapRow(ResultSet rs, int row) throws SQLException {
                    Summary summary = new Summary();
                    summary.setNumberOfTasks(rs.getLong("number_tasks"));
                    summary.setNumberOfDocuments(rs.getLong("NUMBER_DOCS"));
                    summary.setNumbereOfEnvelopes(rs.getLong("NUMBER_ENVELOPES"));
                    summary.setNumbereOfFolders(rs.getLong("number_folders"));
                    return summary;
                }
            });
            return summary.isEmpty() ? null : summary.get(0);
        }

        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00908, scope, e);

        }
    }
}
