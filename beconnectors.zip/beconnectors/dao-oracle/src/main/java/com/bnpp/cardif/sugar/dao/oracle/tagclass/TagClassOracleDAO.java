package com.bnpp.cardif.sugar.dao.oracle.tagclass;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00801;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00802;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00803;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00804;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00805;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.tagclass.TagClassDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

@Component
public class TagClassOracleDAO extends AbstractDAO implements TagClassDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(TagClassOracleDAO.class);

    private static final String TAGCLASSARG = "TAGCLASSARG";

    private static final String TAG_CURSOR = "TagCursor";

    private static final String SCOPE_ARG = "ScopeArg";

    private static final String TAG_IDS = "TagIds";

    private class StoreSingleProc extends StoredProcedure {

        public StoreSingleProc() {
            super(getDataSource(), "PKG_TAGCLASS.STORE_SINGLE");
            declareParameter(new SqlParameter(TAGCLASSARG, Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(TagClass tagClass) throws SugarTechnicalException {
            final String write = getWriter(TagClass.class).write(tagClass);

            Map in = new HashMap();
            in.put(TAGCLASSARG, new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void store(List<TagClass> tagClasses) throws SugarTechnicalException, SugarFunctionalException {
        try {
            LOGGER.debug("Trying to store {} tag classes", tagClasses.size());
            StoreSingleProc procedure = new StoreSingleProc();
            for (TagClass tagClass : tagClasses) {
                procedure.run(tagClass);
            }
            LOGGER.info("{} tag classes have been stored", tagClasses.size());
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00801, e);
        }
    }

    private class GetProc extends StoredProcedure {

        public GetProc() {
            super(getDataSource(), "PKG_TAGCLASS.GETTAG");
            declareParameter(new SqlParameter(TAG_IDS, OracleTypes.ARRAY, getDbUserName() + ".VARCHARARRAY"));
            declareParameter(new SqlParameter(SCOPE_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(TAG_CURSOR, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<TagClass> run(String scope, List<ClassId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (ClassId id : ids) {
                serializedIds.add(getWriter(ClassId.class).write(id));
            }

            Map in = new HashMap();
            in.put(TAG_IDS, new SqlArrayValue(serializedIds.toArray()));
            in.put(SCOPE_ARG, scope);
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(TAG_CURSOR);
            List<TagClass> unwrappedDocuments = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocuments.add(getReader(TagClass.class).read(serializedDocument));
            }
            return unwrappedDocuments;
        }

    }

    @Override
    public List<TagClass> get(String scope, List<ClassId> ids) throws SugarTechnicalException {
        try {
            GetProc procedure = new GetProc();
            List<TagClass> result = procedure.run(scope, ids);
            return result;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00803, ids, e);
        }
    }

    private class GetByNameProc extends StoredProcedure {

        public GetByNameProc() {
            super(getDataSource(), "PKG_TAGCLASS.GETBYNAME");
            declareParameter(new SqlParameter(TAG_IDS, OracleTypes.ARRAY, getDbUserName() + ".VARCHARARRAY"));
            declareParameter(new SqlParameter(SCOPE_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(TAG_CURSOR, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<TagClass> run(String scope, String[] xmlAsStringArray) throws SugarTechnicalException {

            Map in = new HashMap();
            in.put(TAG_IDS, new SqlArrayValue(xmlAsStringArray));
            in.put(SCOPE_ARG, scope);
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(TAG_CURSOR);
            List<TagClass> unwrappedDocuments = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocuments.add(getReader(TagClass.class).read(serializedDocument));
            }
            return unwrappedDocuments;
        }

    }

    @Override
    public List<TagClass> getBySymbolicName(String scope, List<String> symbolicNames) throws SugarTechnicalException {
        String[] xmlAsStringArray = new String[symbolicNames.size()];
        for (int i = 0; i < symbolicNames.size(); i++) {
            xmlAsStringArray[i] = symbolicNames.get(i);
        }

        try {
            LOGGER.info("Trying to fetch {}", symbolicNames);
            GetByNameProc procedure = new GetByNameProc();
            List<TagClass> fetchedTagClasses = procedure.run(scope, xmlAsStringArray);
            LOGGER.info("{} tagclasses have been fetched", fetchedTagClasses.size());
            return fetchedTagClasses;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00802, symbolicNames, e);
        }
    }

    private class GetAllProc extends StoredProcedure {

        public GetAllProc() {
            super(getDataSource(), "PKG_TAGCLASS.GETALL");
            declareParameter(new SqlParameter(SCOPE_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(TAG_CURSOR, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<TagClass> run(String scope) throws SugarTechnicalException {

            Map in = new HashMap();
            in.put(SCOPE_ARG, scope);
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(TAG_CURSOR);
            List<TagClass> unwrappedDocuments = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocuments.add(getReader(TagClass.class).read(serializedDocument));
            }
            return unwrappedDocuments;
        }

    }

    @Override
    public List<TagClass> getAll(String scope) throws SugarTechnicalException {
        try {
            LOGGER.debug("Trying to fetch all tag classes for scope: {}", scope);
            GetAllProc procedure = new GetAllProc();
            List<TagClass> results = procedure.run(scope);
            LOGGER.info("{} tag classes have been fetched for scope {}", results.size(), scope);
            return results;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00804, scope, e);
        }
    }

    private class UpdateSingleProc extends StoredProcedure {

        public UpdateSingleProc() {
            super(getDataSource(), "PKG_TAGCLASS.UPDATE_SINGLE");
            declareParameter(new SqlParameter(TAGCLASSARG, Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(TagClass tagClass) throws SugarTechnicalException {
            final String write = getWriter(TagClass.class).write(tagClass);

            Map in = new HashMap();
            in.put(TAGCLASSARG, new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void update(List<TagClass> tagClasses) throws SugarTechnicalException {
        try {
            LOGGER.debug("Trying to update {} tag classes", tagClasses.size());
            UpdateSingleProc procedure = new UpdateSingleProc();
            for (TagClass tagClass : tagClasses) {
                procedure.run(tagClass);
            }
            LOGGER.info("{} tag classes have been updated", tagClasses.size());
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00805, e);
        }

    }
}