package com.bnpp.cardif.sugar.dao.oracle.folder;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00104;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00301;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00302;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00303;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.folder.FolderDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.dao.oracle.xpath.SearchQueryHelper;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Query;
import com.google.common.collect.Lists;

@Component
public class FolderOracleDAO extends AbstractDAO implements FolderDAO {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(FolderOracleDAO.class);
    
    private static final String P_TRACE_LEVEL = "p_traceLevel";

    @Autowired
    private SearchQueryHelper folderSearchQueryhelper;

    private class AddSingleProc extends StoredProcedure {

        public AddSingleProc() {
            super(getDataSource(), "PKG_FOLDER.ADD_SINGLE");
            declareParameter(new SqlParameter("p_FOLDER", Types.CLOB));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, Types.INTEGER));
            compile();
        }

        public void run(Folder folder) throws SugarTechnicalException {
            final String write = getWriter(Folder.class).write(folder);

            Map<String, Object> in = new HashMap<>();
            in.put("p_FOLDER", new SqlLobValue(write, lobHandler));
            in.put(P_TRACE_LEVEL, getLoglevel());
            this.execute(in);
        }
    }

    @Override
    public void add(List<Folder> foldersToAdd) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.info("Storing {} folders", foldersToAdd.size());

        try {
            AddSingleProc addSingleProc = new AddSingleProc();
            for (Folder folder : foldersToAdd) {
                addSingleProc.run(folder);
            }
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00301, e);
        }
    }

    private class UpdateSingleProc extends StoredProcedure {

        public UpdateSingleProc() {
            super(getDataSource(), "PKG_FOLDER.UPDATE_FOLDER_SINGLE");
            declareParameter(new SqlParameter("folderToStore", Types.CLOB));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, Types.INTEGER));
            compile();
        }

        public void run(Folder folder) throws SugarTechnicalException {
            final String write = getWriter(Folder.class).write(folder);

            Map<String, Object> in = new HashMap<>();
            in.put("folderToStore", new SqlLobValue(write, lobHandler));
            in.put(P_TRACE_LEVEL, getLoglevel());
            this.execute(in);
        }
    }

    @Override
    public List<Folder> update(List<Folder> foldersToUpdate, String scope) throws SugarTechnicalException {
        try {
            LOGGER.info("Updating {} folders", foldersToUpdate.size());
            UpdateSingleProc updateSingleProc = new UpdateSingleProc();
            for (Folder folder : foldersToUpdate) {
                updateSingleProc.run(folder);
            }
            return foldersToUpdate;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00303, e);
        }
    }

    private class GetProc extends StoredProcedure {

        public GetProc() {
            super(getDataSource(), "PKG_FOLDER.get");
            declareParameter(new SqlParameter("p_scope", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("FolderIds", OracleTypes.ARRAY, getDbUserName() + ".VARCHARARRAY"));
            declareParameter(new SqlOutParameter("FoldersFetched", OracleTypes.CURSOR, new ObjectMapper(1)));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, OracleTypes.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<Folder> run(String scope, List<FolderId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (FolderId id : ids) {
                serializedIds.add(getWriter(FolderId.class).write(id));
            }

            Map in = new HashMap();
            in.put("p_scope", scope);
            in.put("FolderIds", new SqlArrayValue(serializedIds.toArray()));
            in.put(P_TRACE_LEVEL, getLoglevel());
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get("FoldersFetched");
            List<Folder> unwrappedFolders = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedFolders.add(getReader(Folder.class).read(serializedDocument));
            }

            return unwrappedFolders;
        }

    }

    @Override
    public List<Folder> get(List<FolderId> ids, String scope) throws SugarTechnicalException {

        LOGGER.info("Fetching folders having followings ids : {}", ids);

        try {
            GetProc get = new GetProc();
            List<Folder> fetchedFolders = get.run(scope, ids);

            LOGGER.info("{} document have been fetched from database", fetchedFolders.size());
            return fetchedFolders;
        }
        catch (SugarTechnicalException e) {
            throw ExceptionBuilder.createTechnicalException(T00302, ids, e);
        }
    }

    private class FindProc extends StoredProcedure {

        public FindProc() {
            super(getDataSource(), "PKG_FOLDER.find");
            declareParameter(new SqlParameter("p_request", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter("pout_folderCursor", OracleTypes.CURSOR, new ObjectMapper(1)));
            declareParameter(new SqlOutParameter("pout_resultCount", OracleTypes.INTEGER));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, OracleTypes.INTEGER));
            declareParameter(new SqlParameter("p_requestId", OracleTypes.VARCHAR));
            compile();
        }

        private List<Folder> unwrappedFolders;

        private long resultCount;

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(Query buildQuery, int traceLevel, String requestId) throws SugarTechnicalException {

            String queryAsString = getWriter(Query.class).write(buildQuery);
            LOGGER.info("Query: to {}...", queryAsString);

            Map in = new HashMap();
            in.put("p_request", queryAsString);
            in.put(P_TRACE_LEVEL, traceLevel);
            in.put("p_requestId", requestId);

            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get("pout_folderCursor");
            List<Folder> unwrappedDocuments = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocuments.add(getReader(Folder.class).read(serializedDocument));
            }

            this.unwrappedFolders = unwrappedDocuments;
            this.resultCount = (Integer) out.get("pout_resultCount");
        }

        public long getNumberOfResults() {
            return resultCount;
        }

        public List<Folder> getFoundFolders() {
            return unwrappedFolders;
        }

    }

    @Override
    public SearchResults<Folder> find(String scope, Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException {
        LOGGER.info("Finding {} folders from index={} ...", max, start);
        try {
            Criterion init = null;
            if (!criteria.getCriterionList().isEmpty()) {
                init = criteria.getCriterionList().get(0);
            }
            // detecter si recherche mix (Quick + advanced)
            Query buildQuery;
            if (init != null && Levels.QUICK.equals(init.getLevel()) && criteria.getCriterionList().size() > 1) {
                buildQuery = getQueryHelper().buildMixQuery(scope, criteria, order);
            }
            else {
                buildQuery = getQueryHelper().buildQuery(scope, criteria, order);
            }

            buildQuery.setPageStart((int) (start + 1));
            buildQuery.setPageSize((int) max);
            FindProc findProc = new FindProc();

            LOGGER.info("Finding {} documents from index={}", max, start);
            findProc.run(buildQuery, -3, null);
            List<Folder> foundFolders = findProc.getFoundFolders();

            LOGGER.info("{} documents have been retrieved over {} found results", foundFolders.size(),
                    findProc.getNumberOfResults());

            return new SearchResults<>(foundFolders, findProc.getNumberOfResults(),
                    Long.parseLong(getQueryHelper().getMaxSearch()));
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00104, criteria, e);
        }
    }

    @Override
    public Folder getBySymbolicName(String scope, String symbolicName) throws SugarTechnicalException {
        LOGGER.info("Fetching Folders having name  : {}", symbolicName);

        Criteria criteria = new Criteria();
        criteria.setItem(Item.FOLDER);
        criteria.getCriterionList()
                .add(new Criterion(Levels.DATA, "Name", Operators.EQUALS_TO,
                        com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types.STRING,
                        Lists.newArrayList(symbolicName)));
        SearchResults<Folder> result = this.find(scope, criteria, null, 0, 1);
        return !result.getObjects().isEmpty() ? result.getObjects().get(0) : null;

    }

    @Override
    public List<FolderId> fetchIdsByScope(String scope) throws SugarTechnicalException {

        final List<FolderId> res;
        try {
            StringBuilder query = new StringBuilder(
                    "SELECT ID_VALUE, ID_SCHEME, ID_ISSUER FROM FOLDERS WHERE SCOPE = ?");
            String[] variables = { scope };
            res = template.query(query.toString(), variables, new RowMapper<FolderId>() {

                @Override
                public FolderId mapRow(ResultSet rs, int row) throws SQLException {
                    FolderId id = new FolderId();
                    id.setValue(rs.getString(1));
                    id.setScheme(rs.getString(2));
                    id.setIssuer(rs.getString(3));
                    return id;
                }
            });
            return res;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00302, e);
        }
    }

    public SearchQueryHelper getQueryHelper() {
        return folderSearchQueryhelper;
    }

    public void setQueryHelper(SearchQueryHelper queryHelper) {
        this.folderSearchQueryhelper = queryHelper;
    }
}
