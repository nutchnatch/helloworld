package com.bnpp.cardif.sugar.dao.oracle.folderclass;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00401;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00402;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00403;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00404;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00405;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.folderclass.FolderClassDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.jaxb.DateAdapter;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;

@Component
public class FolderClassOracleDAO extends AbstractDAO implements FolderClassDAO {
    private static final Logger LOGGER = LoggerFactory.getLogger(FolderClassOracleDAO.class);

    private static final String FOLDERCLASS_PACKAGE_NAME = "PKG_FOLDERCLASS";
    private static final String FOLDER_CLASSES_FETCHED = "FolderClassesFetched";
    private static final String VARCHARARRAY = ".VARCHARARRAY";
    private static final String FOLDER_CLASS_IDS = "FolderClassIds";
    private static final String P_SCOPE = "p_scope";

    private class AddSingleProc extends StoredProcedure {

        public AddSingleProc() {
            super(getDataSource(), FOLDERCLASS_PACKAGE_NAME + ".ADD_SINGLE");
            declareParameter(new SqlParameter("p_FOLDERCLASS", Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(FolderClass folderClass) throws SugarTechnicalException {
            final String write = getWriter(FolderClass.class).write(folderClass);

            Map in = new HashMap();
            in.put("p_FOLDERCLASS", new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void add(List<FolderClass> folderClassesToAdd) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.info("Storing {} folder classes ", folderClassesToAdd.size());

        try {
            AddSingleProc procedure = new AddSingleProc();
            for (FolderClass folderClass : folderClassesToAdd) {
                procedure.run(folderClass);
            }
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00401, e);
        }
    }

    private class UpdateSingleProc extends StoredProcedure {

        public UpdateSingleProc() {
            super(getDataSource(), FOLDERCLASS_PACKAGE_NAME + ".UPDATE_FOLDER_CLASS");
            declareParameter(new SqlParameter("folderClassToUpdate", Types.CLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(FolderClass folderClass) throws SugarTechnicalException {
            final String write = getWriter(FolderClass.class).write(folderClass);

            Map in = new HashMap();
            in.put("folderClassToUpdate", new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void update(List<FolderClass> folderClassesToUpdate) throws SugarTechnicalException {
        try {
            LOGGER.info("Updating {} folder classes", folderClassesToUpdate.size());
            UpdateSingleProc procedure = new UpdateSingleProc();
            for (FolderClass folderClass : folderClassesToUpdate) {
                procedure.run(folderClass);
            }
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00403, e);
        }
    }

    private class GetProc extends StoredProcedure {

        public GetProc() {
            super(getDataSource(), FOLDERCLASS_PACKAGE_NAME + ".GET");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(FOLDER_CLASS_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlOutParameter(FOLDER_CLASSES_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<FolderClass> run(String scope, List<ClassId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (ClassId id : ids) {
                serializedIds.add(getWriter(ClassId.class).write(id));
            }

            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put(FOLDER_CLASS_IDS, new SqlArrayValue(serializedIds.toArray()));
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(FOLDER_CLASSES_FETCHED);
            List<FolderClass> unwrappedFolderClasses = new ArrayList<>(serializedResults.size());
            for (String serializedFolder : serializedResults) {
                unwrappedFolderClasses.add(getReader(FolderClass.class).read(serializedFolder));
            }
            return unwrappedFolderClasses;
        }
    }

    @Override
    public List<FolderClass> get(List<ClassId> ids, String scope) throws SugarTechnicalException {
        LOGGER.info("Fetching Folder classes having followings ids : {}", ids);
        try {
            GetProc procedure = new GetProc();
            List<FolderClass> result = procedure.run(scope, ids);
            return result;

        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00402, ids, e);
        }
    }

    private class GetAllVersionProc extends StoredProcedure {

        public GetAllVersionProc() {
            super(getDataSource(), FOLDERCLASS_PACKAGE_NAME + ".GETALLVERSIONS");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(FOLDER_CLASS_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlOutParameter(FOLDER_CLASSES_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<FolderClass> run(String scope, List<ClassId> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (ClassId id : ids) {
                serializedIds.add(getWriter(ClassId.class).write(id));
            }

            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put(FOLDER_CLASS_IDS, new SqlArrayValue(serializedIds.toArray()));
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(FOLDER_CLASSES_FETCHED);
            List<FolderClass> unwrappedFolderClasses = new ArrayList<>(serializedResults.size());
            for (String serializedFolder : serializedResults) {
                unwrappedFolderClasses.add(getReader(FolderClass.class).read(serializedFolder));
            }
            return unwrappedFolderClasses;
        }
    }

    @Override
    public List<FolderClass> getAllVersions(List<ClassId> ids, String scope) throws SugarTechnicalException {
        LOGGER.info("Fetching all Folder class versions for the followings ids : {}", ids);
        try {
            GetAllVersionProc procedure = new GetAllVersionProc();
            List<FolderClass> result = procedure.run(scope, ids);
            return result;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00402, ids, e);
        }
    }

    private class GetAllProc extends StoredProcedure {

        public GetAllProc() {
            super(getDataSource(), FOLDERCLASS_PACKAGE_NAME + ".GETALL");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("isActiveOnly", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(FOLDER_CLASSES_FETCHED, OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<FolderClass> run(String scope, String isActiveOnly) throws SugarTechnicalException {

            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put("isActiveOnly", isActiveOnly);
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get(FOLDER_CLASSES_FETCHED);
            List<FolderClass> unwrappedFolderClasses = new ArrayList<>(serializedResults.size());
            for (String serializedFolder : serializedResults) {
                unwrappedFolderClasses.add(getReader(FolderClass.class).read(serializedFolder));
            }
            return unwrappedFolderClasses;
        }
    }

    @Override
    public List<FolderClass> getAll(String scope, Boolean isActiveOnly)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.info("Fetching All folder classes for the scope : {}", scope);
        try {
            GetAllProc procedure = new GetAllProc();
            List<FolderClass> result = procedure.run(scope, isActiveOnly.toString().toLowerCase());
            return result;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00404, scope, isActiveOnly, e);
        }
    }

    private class SetActiveProc extends StoredProcedure {

        public SetActiveProc() {
            super(getDataSource(), FOLDERCLASS_PACKAGE_NAME + ".SET_ACTIVE");
            declareParameter(new SqlParameter(FOLDER_CLASS_IDS, OracleTypes.ARRAY, getDbUserName() + VARCHARARRAY));
            declareParameter(new SqlParameter("activeValue", OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter("updateDate", OracleTypes.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(List<ClassId> ids, String active, String scope, String updateDate)
                throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (ClassId id : ids) {
                serializedIds.add(getWriter(ClassId.class).write(id));
            }

            Map in = new HashMap();
            in.put(FOLDER_CLASS_IDS, new SqlArrayValue(serializedIds.toArray()));
            in.put("activeValue", active);
            in.put(P_SCOPE, scope);
            in.put("updateDate", updateDate);
            this.execute(in);
        }
    }

    @Override
    public void setActive(List<ClassId> ids, Boolean active, String scope, Date updateDate)
            throws SugarTechnicalException {
        try {
            SetActiveProc procedure = new SetActiveProc();
            procedure.run(ids, active.toString().toLowerCase(), scope, DateAdapter.printDateTime(updateDate));
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00405, ids, active, e);
        }
    }
}
