package com.bnpp.cardif.sugar.dao.oracle.xpath;

import static com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types.TIMESTAMP;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.bnpp.cardif.sugar.domain.model.criteria.CriteriaHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;

/**
 * Specific implementation of {@link CriteriaHelper} which allows build list of
 * criterion for Oracle based on XPath expression.
 * 
 * <br/>
 * <br/>
 * This helper uses {@link XPathDocumentCriterionHelper} or
 * {@link XPathFolderCriterionHelper} to access to a field
 * 
 * @author Christopher Laszczuk
 * @Deprecated
 */
@Deprecated
public class OracleXpathCriteriaHelper implements CriteriaHelper {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(OracleXpathCriteriaHelper.class);

    private static final String START_DATE_TIMESTAMP = "to_timestamp_tz('1970-01-01 00:00:00' , 'YYYY-MM-DD HH24:MI:SS' ) ";

    private final StringBuilder dateQueryBuilder = new StringBuilder(
            "to_timestamp_tz(?,'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM')");

    // TODO : Restore strange if of RMO : child || id
    @Override
    public String serialize(Criteria criteria) {
        if (criteria == null) {
            return null;
        }

        StringBuilder queryBuilder = new StringBuilder();
        StringBuilder sysBuilder = new StringBuilder();

        XPathFieldHelper criterionHelper = getCriterionHelper(criteria.getItem());
        for (Criterion criterion : criteria.getCriterionList()) {
            // Hack : search all folders that a document belongs
            if (criterion.getLevel().equals(Levels.CHILD) && criterion.getName().equals("Id")) {
                queryBuilder.append(criterionHelper.getQuery(criterion));
                queryBuilder.append(getComparaisonString(criterion.getOperator(), criterion.getType(), "1"));
            }
            else if (Levels.DATA.equals(criterion.getLevel()) || Levels.TAG.equals(criterion.getLevel())) {
                queryBuilder.append(queryBuilder.length() == 0 ? "" : (criteria.isAny() ? " OR " : " AND "));

                String xPathQuery = criterionHelper.getQuery(criterion);
                String formattedXPathQuery = getFormattedXPathQueryAccordingToType(xPathQuery, criterion.getType());

                Boolean isFirstCriterionValue = true;
                queryBuilder.append("(");
                for (String criterionValue : criterion.getValues()) {
                    queryBuilder.append(isFirstCriterionValue ? "" : " OR ");
                    queryBuilder.append(formattedXPathQuery);
                    queryBuilder
                            .append(getComparaisonString(criterion.getOperator(), criterion.getType(), criterionValue));
                    isFirstCriterionValue = false;
                }
                queryBuilder.append(")");
            }
            else if (Levels.ATTRIBUTE.equals(criterion.getLevel())) {
                sysBuilder.append(sysBuilder.length() == 0 ? "" : " AND ");
                String xPathQuery = criterionHelper.getQuery(criterion);
                String formattedXPathQuery = getFormattedXPathQueryAccordingToType(xPathQuery, criterion.getType());
                sysBuilder.append("(");
                sysBuilder.append(formattedXPathQuery);
                sysBuilder.append(getComparaisonString(criterion.getOperator(), criterion.getType(),
                        criterion.getValues().get(0)));
                sysBuilder.append(")");
            }

        }

        String str = "";
        if (queryBuilder.length() > 2 && sysBuilder.length() == 0) {
            str = queryBuilder.toString();
        }
        else if (sysBuilder.length() > 0 && queryBuilder.length() <= 2) {
            str = sysBuilder.toString();
        }
        else if (queryBuilder.length() > 2 && sysBuilder.length() > 0) {
            str = '(' + queryBuilder.toString() + ')' + " AND " + '(' + sysBuilder.toString() + ')';
        }

        LOGGER.info("Built XPath query: {}", str);
        return str;
    }

    private XPathFieldHelper getCriterionHelper(Item item) {
        if (Item.FOLDER.equals(item)) {
            return new XPathFolderCriterionHelper();
        }
        return new XPathDocumentCriterionHelper();
    }

    private String getFormattedXPathQueryAccordingToType(String xPathQuery, Types type) {
        switch (type) {
        case STRING:
            return xPathQuery;
        case TIMESTAMP:
            return StringUtils.replace(dateQueryBuilder.toString(), "?", xPathQuery);
        case BOOLEAN:
            return xPathQuery;
        default:
            throw new IllegalArgumentException("The criterion type: " + type + " is not yet supported");
        }
    }

    private String getComparaisonString(Operators operator, Types type, String criterionValue) {
        StringBuilder comparaisonBuilder = new StringBuilder();
        switch (operator) {
        case EQUALS_TO:
            comparaisonBuilder.append("='");
            comparaisonBuilder.append(criterionValue);
            comparaisonBuilder.append("'");
            break;
        case CONTAINS:
            comparaisonBuilder.append(" LIKE '%");
            comparaisonBuilder.append(criterionValue);
            comparaisonBuilder.append("%'");
            break;
        case STARTS_WITH:
            comparaisonBuilder.append(" LIKE '");
            comparaisonBuilder.append(criterionValue);
            comparaisonBuilder.append("%'");
            break;
        case ENDS_WITH:
            comparaisonBuilder.append(" LIKE '%");
            comparaisonBuilder.append(criterionValue);
            comparaisonBuilder.append("'");
            break;
        case GREATER_THAN:
            comparaisonBuilder.append(" > ");
            if (TIMESTAMP.equals(type)) {
                comparaisonBuilder.append(START_DATE_TIMESTAMP);
                comparaisonBuilder.append("+ numtodsinterval(" + criterionValue + "/1000,'SECOND')");
            }
            else {
                comparaisonBuilder.append(criterionValue);
            }
            break;
        case LESS_THAN:
            comparaisonBuilder.append(" < ");
            if (TIMESTAMP.equals(type)) {
                comparaisonBuilder.append(START_DATE_TIMESTAMP);
                comparaisonBuilder.append("+ numtodsinterval(" + criterionValue + "/1000,'SECOND')");
            }
            else {
                comparaisonBuilder.append(criterionValue);
            }
            break;
        default:
            throw new IllegalArgumentException("The XPath query operator " + operator + " is not supported");
        }
        return comparaisonBuilder.toString();
    }

    @Override
    public Criteria parse(String criteria) {
        throw new IllegalAccessError("This method is not and and should not be implemented");
    }
}
