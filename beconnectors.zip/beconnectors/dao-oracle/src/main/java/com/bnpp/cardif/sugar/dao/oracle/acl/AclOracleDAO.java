package com.bnpp.cardif.sugar.dao.oracle.acl;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01001;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01002;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01003;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01005;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01006;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T01007;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.acl.AclDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.JAXBStringWriter;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

/**
 * Oracle Backend implementation
 * 
 * @author Francois Barre
 * 
 */
@Component
public class AclOracleDAO extends AbstractDAO implements AclDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(AclOracleDAO.class);

    private static final String ACL_ARG = "ACL_ARG";
    private static final String SCOPE_ARG = "SCOPE_ARG";
    private static final String ACLID_ARG = "ACLID_ARG";
    private static final String OBJECTID_ARG = "OBJECTID_ARG";
    private static final String CONTEXT_ARG = "CONTEXT_ARG";

    private class StoreProc extends StoredProcedure {

        public StoreProc() {
            super(getDataSource(), "PKG_ACL.store");
            declareParameter(new SqlParameter(ACL_ARG, Types.CLOB));
            compile();
        }

        public void run(AccessControlList accessControlList) throws SugarTechnicalException {
            final String write = getWriter(AccessControlList.class).write(accessControlList);

            Map<String, Object> in = new HashMap<>();
            in.put(ACL_ARG, new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    /**
     * @inheritDoc
     */
    public synchronized void store(AccessControlList acl) throws SugarTechnicalException {
        try {
            StoreProc storeProc = new StoreProc();
            storeProc.run(acl);

        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T01001, e);
        }
    }

    private class UpdateProc extends StoredProcedure {

        public UpdateProc() {
            super(getDataSource(), "PKG_ACL.UPDATE_ACL");
            declareParameter(new SqlParameter(ACL_ARG, Types.CLOB));
            compile();
        }

        public void run(AccessControlList accessControlList) throws SugarTechnicalException {
            final String write = getWriter(AccessControlList.class).write(accessControlList);

            Map<String, Object> in = new HashMap<>();
            in.put(ACL_ARG, new SqlLobValue(write, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public synchronized void update(AccessControlList acl) throws SugarTechnicalException {
        try {
            UpdateProc updateProc = new UpdateProc();
            updateProc.run(acl);

        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T01001, e);
        }
    }

    private class GetProc extends StoredProcedure {

        public GetProc() {
            super(getDataSource(), "PKG_ACL.get");

            declareParameter(new SqlParameter(ACLID_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(SCOPE_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(ACL_ARG, OracleTypes.CLOB, null, new ClobReturnType()));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public AccessControlList run(AclId aclId, String scope) throws SugarTechnicalException {

            String aclIdString = getWriter(AclId.class).write(aclId);

            Map in = new HashMap();
            in.put(ACLID_ARG, aclIdString);
            in.put(SCOPE_ARG, scope);
            Map out = execute(in);

            String serialized = (String) out.get(ACL_ARG);
            return getReader(AccessControlList.class).read(serialized);
        }

    }

    @Override
    /**
     * @inheritDoc
     */
    public synchronized AccessControlList get(AclId aclId, String scope) throws SugarTechnicalException {
        try {

            GetProc getProc = new GetProc();

            return getProc.run(aclId, scope);
        }
        catch (SugarTechnicalException e) {
            throw ExceptionBuilder.createTechnicalException(T01002, aclId, e);
        }
    }

    private class AssignProc extends StoredProcedure {

        public AssignProc() {
            super(getDataSource(), "PKG_ACL.ASSIGN");

            declareParameter(new SqlParameter(ACLID_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(OBJECTID_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(CONTEXT_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(SCOPE_ARG, OracleTypes.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String aclIdString, String objectIDSerialized, AclContext context, String scope)
                throws SugarTechnicalException {

            Map in = new HashMap();
            in.put(ACLID_ARG, aclIdString);
            in.put(OBJECTID_ARG, objectIDSerialized);
            in.put(CONTEXT_ARG, context.toString());
            in.put(SCOPE_ARG, scope);
            this.execute(in);

        }

    }

    protected <T> void doAssign(AclId aclId, T objectId, JAXBStringWriter<T> writer, AclContext context, String scope)
            throws SugarTechnicalException {
        try {

            String aclIdString = getWriter(AclId.class).write(aclId);
            String objectIDSerialized = writer.write(objectId);

            AssignProc assignProc = new AssignProc();
            LOGGER.debug("Mapping ACL {} to object {} with context {} in scope {}", aclId, objectId, context, scope);
            assignProc.run(aclIdString, objectIDSerialized, context, scope);
        }
        catch (SugarTechnicalException e) {
            throw ExceptionBuilder.createTechnicalException(T01003, aclId, objectId, context, e);
        }
    }

    @Override
    /**
     * @inheritDoc
     */
    public void assign(AclId aclId, Id documentId, String scope) throws SugarTechnicalException {
        doAssign(aclId, documentId, getWriter(Id.class), AclContext.DOCUMENT, scope);
    }

    @Override
    /**
     * @inheritDoc
     */
    public void assign(AclId aclId, FolderId folderId, String scope) throws SugarTechnicalException {
        doAssign(aclId, folderId, getWriter(FolderId.class), AclContext.FOLDER, scope);
    }

    @Override
    public void assign(AclId aclId, BasketId basketId, String scope) throws SugarTechnicalException {
        doAssign(aclId, basketId, getWriter(BasketId.class), AclContext.BASKET, scope);
    }

    @Override
    /**
     * @inheritDoc
     */
    public void assign(AclId aclId, ClassId classId, AclContext context, String scope) throws SugarTechnicalException {
        ClassId classId_ = new ClassId(classId.getValue(), classId.getIssuer(), classId.getVersId());
        doAssign(aclId, classId_, getWriter(ClassId.class), context, scope);
    }

    @Override
    /**
     * @inheritDoc
     */
    public void assign(AclId aclId, BusinessScopeId scopeId, String scope, AclContext context)
            throws SugarTechnicalException {
        doAssign(aclId, scopeId, getWriter(BusinessScopeId.class), context, scope);
    }

    private class SearchProc extends StoredProcedure {

        public SearchProc() {
            super(getDataSource(), "PKG_ACL.SEARCH");

            declareParameter(new SqlParameter(OBJECTID_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(CONTEXT_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(SCOPE_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter(ACLID_ARG, OracleTypes.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public <T> AclId run(T objectId, JAXBStringWriter<T> writer, AclContext context, String scope)
                throws SugarTechnicalException {
            String objectIDSerialized = writer.write(objectId);

            Map in = new HashMap();
            in.put(OBJECTID_ARG, objectIDSerialized);
            in.put(CONTEXT_ARG, context.toString());
            in.put(SCOPE_ARG, scope);
            Map<String, Object> out = this.execute(in);
            String aclIdString = (String) out.get(ACLID_ARG);

            if (aclIdString == null) {
                throw ExceptionBuilder.createTechnicalException(T01007, objectId, context, scope);
            }
            return getReader(AclId.class).read(aclIdString);
        }

    }

    protected <T> AclId doSearch(T objectId, JAXBStringWriter<T> writer, AclContext context, String scope)
            throws SugarTechnicalException {

        SearchProc searchProc = new SearchProc();
        return searchProc.run(objectId, writer, context, scope);

    }

    @Override
    /**
     * @inheritDoc
     */
    public AclId searchAcl(Id documentId, String scope) throws SugarTechnicalException {
        return doSearch(documentId, getWriter(Id.class), AclContext.DOCUMENT, scope);
    }

    @Override
    /**
     * @inheritDoc
     */
    public AclId searchAcl(BusinessScopeId businessScopeId, String scope, AclContext context)
            throws SugarTechnicalException {
        return doSearch(businessScopeId, getWriter(BusinessScopeId.class), context, scope);
    }

    @Override
    /**
     * @inheritDoc
     */
    public AclId searchAcl(FolderId folderId, String scope) throws SugarTechnicalException {
        return doSearch(folderId, getWriter(FolderId.class), AclContext.FOLDER, scope);

    }

    @Override
    /**
     * @inheritDoc
     */
    public AclId searchAcl(ClassId classId, AclContext context, String scope) throws SugarTechnicalException {
        LOGGER.debug("Searching ACL matching with id {} {} in scope {}", classId, context, scope);
        AclId result = doSearch(classId, getWriter(ClassId.class), context, scope);
        LOGGER.debug("An ACL with id has been found {}", result);
        return result;
    }

    @Override
    public AclId searchAcl(BasketId basketId, String scope) throws SugarTechnicalException {
        LOGGER.debug("Searching ACL matching with id {} in scope {}", basketId, scope);
        AclId result = doSearch(basketId, getWriter(BasketId.class), AclContext.BASKET, scope);
        LOGGER.debug("An ACL with id has been found {} ", result);
        return result;
    }

    private class GetAllProc extends StoredProcedure {

        public GetAllProc() {
            super(getDataSource(), "PKG_ACL.GETALL");

            declareParameter(new SqlParameter("p_scope", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter("AclsFetched", OracleTypes.CURSOR, new ObjectMapper(1)));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<AccessControlList> run(String scope) throws SugarTechnicalException {
            Map in = new HashMap();
            in.put("p_scope", scope);

            Map<String, Object> out = this.execute(in);
            List<String> serializedResults = (List<String>) out.get("AclsFetched");

            List<AccessControlList> unwrappedAcls = new ArrayList<>(serializedResults.size());
            for (String serializedAcl : serializedResults) {
                unwrappedAcls.add(getReader(AccessControlList.class).read(serializedAcl));
            }

            return unwrappedAcls;
        }

    }

    @Override
    public List<AccessControlList> getAll(String scope) throws SugarTechnicalException {
        try {
            GetAllProc getAllProc = new GetAllProc();
            List<AccessControlList> result = getAllProc.run(scope);

            return result;
        }
        catch (SugarTechnicalException e) {
            throw ExceptionBuilder.createTechnicalException(T01006, scope, e);
        }
    }

    @Override
    public void remove(BasketId basketId, String scope) throws SugarTechnicalException {
        doRemove(basketId, getWriter(BasketId.class), AclContext.BASKET, scope);
    }

    @Override
    public void remove(String scope, ClassId classId, AclContext context) throws SugarTechnicalException {
        doRemove(classId, getWriter(ClassId.class), context, scope);
    }

    private class RemoveProc extends StoredProcedure {

        public RemoveProc() {
            super(getDataSource(), "PKG_ACL.REMOVE");

            declareParameter(new SqlParameter(OBJECTID_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(CONTEXT_ARG, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(SCOPE_ARG, OracleTypes.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public <T> void run(T objectId, JAXBStringWriter<T> writer, AclDAO.AclContext context, String scope)
                throws SugarTechnicalException {

            Map in = new HashMap();
            in.put(OBJECTID_ARG, writer.write(objectId));
            in.put(CONTEXT_ARG, context.toString());
            in.put(SCOPE_ARG, scope);

            this.execute(in);

        }

    }

    private <T> void doRemove(T objectId, JAXBStringWriter<T> writer, AclDAO.AclContext context, String scope)
            throws SugarTechnicalException {
        try {
            RemoveProc removeProc = new RemoveProc();
            removeProc.run(objectId, writer, context, scope);
        }
        catch (SugarTechnicalException e) {
            throw ExceptionBuilder.createTechnicalException(T01005, objectId, scope, e);
        }
    }

    @Override
    public void remove(Id documentId, String scope) throws SugarTechnicalException {
        doRemove(documentId, getWriter(Id.class), AclContext.DOCUMENT, scope);

    }

    @Override
    public void remove(String scope, BusinessScopeId businessScopeId, AclContext context)
            throws SugarTechnicalException {
        doRemove(businessScopeId, getWriter(BusinessScopeId.class), context, scope);

    }
}
