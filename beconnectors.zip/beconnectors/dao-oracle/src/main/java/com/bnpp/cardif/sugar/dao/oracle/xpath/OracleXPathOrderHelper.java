package com.bnpp.cardif.sugar.dao.oracle.xpath;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;

@Deprecated
public class OracleXPathOrderHelper {

    public String serialize(OrderClause order, Item item) {
        if (order == null) {
            return "";
        }
        XPathFieldHelper fieldHelper = getFieldHelper(item);
        String xpath = fieldHelper
                .getQuery(new Criterion(order.getLevel(), order.getName(), null, order.getType(), null));

        String orderClause = getFormatedXPath(xpath, order.getType()) + " " + (order.isAscending() ? "ASC " : "DESC ");
        return orderClause;
    }

    private String getFormatedXPath(String xpath, Types type) {
        switch (type) {
        case TIMESTAMP:
            return " to_timestamp_tz(" + xpath + ",'yyyy-mm-dd hh24:mi:ss.FF3 TZHTZM')";
        default:
            return xpath;
        }
    }

    private XPathFieldHelper getFieldHelper(Item item) {
        if (Item.FOLDER.equals(item)) {
            return new XPathFolderCriterionHelper();
        }
        return new XPathDocumentCriterionHelper();
    }
}
