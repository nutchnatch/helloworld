package com.bnpp.cardif.sugar.dao.oracle.xpath;

import com.bnpp.cardif.sugar.dao.oracle.util.Namespaces;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;

/**
 * Helper which facilitates building of XPath expression to access to a folder
 * field
 * 
 * @author Christopher Laszczuk
 * 
 */
@Deprecated
public class XPathFolderCriterionHelper implements XPathFieldHelper {
    private static final String DOCUMENT_NS = "xmlns:doc=\"http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1\"";

    private static final String COLUMN_NAME = "XML_CONTENT";

    /**
     * Gets the XPtath query for a folder allowing to access to a
     * {@link Criterion}.<br/>
     * <br/>
     * This method does not care of criterion value.
     * 
     * @param criterion
     *            The criterion to access
     * @return The XPath query
     */
    @Override
    public String getQuery(Criterion criterion) {
        StringBuilder query = new StringBuilder();
        switch (criterion.getLevel()) {
        case TAG:
            query.append("extract(" + COLUMN_NAME + ", '/folder:Folder/common:Tags/common:Tag[@name = \"")
                    .append(criterion.getName()).append("\"]/common:Value/text()',' ").append(Namespaces.FOLDER)
                    .append(" ').getStringVal()");
            return query.toString();
        case DATA:
            query.append("extract(" + COLUMN_NAME + ", '/folder:Folder/folder:Data/common:").append(criterion.getName())
                    .append("/text()',' ").append(Namespaces.FOLDER).append(" ').getStringVal()");
            return query.toString();
        case CHILD:
            String folderIssuer = criterion.getValues().get(0);
            String folderScheme = criterion.getValues().get(1);
            String folderId = criterion.getValues().get(2);
            query.append("existsNode(" + COLUMN_NAME + ", '/folder:Folder/folder:ChildComponents/doc:Id[' ")
                    .append("|| 'text() = ' || '''").append(folderId).append("''' ")
                    .append("|| 'and @Issuer = ' || '''").append(folderIssuer).append("''' ")
                    .append("|| 'and @Scheme = ' || '''").append(folderScheme).append("''' ").append("|| ']','")
                    .append(DOCUMENT_NS).append(" ").append(Namespaces.FOLDER).append("')");
            return query.toString();
        case ATTRIBUTE:
            query.append("extract(" + COLUMN_NAME + ", '/folder:Folder/@").append(criterion.getName()).append("',' ")
                    .append(Namespaces.FOLDER).append(" ').getStringVal()");
            return query.toString();
        default:
            throw new IllegalArgumentException("Criterion level " + criterion.getLevel() + " is not supported");
        }
    }
}
