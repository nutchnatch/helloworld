package com.bnpp.cardif.sugar.dao.oracle.xpath;

import org.springframework.stereotype.Component;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;

@Component("xPathDocumentHelper")
public class XPathDocumentHelper implements XPathFieldHelper {

    @Override
    public String getQuery(Criterion criterion) {
        StringBuilder pathBuilder = new StringBuilder();
        switch (criterion.getLevel()) {
        case ATTRIBUTE:
            pathBuilder.append("/doc:Document/@").append(criterion.getName());
            return pathBuilder.toString();

        case DATA:
            pathBuilder.append("/doc:Document/doc:Data/common:").append(criterion.getName());
            return pathBuilder.toString();
        case TAG:
            pathBuilder.append("/doc:Document/common:Tags/common:Tag[@name=\"").append(criterion.getName())
                    .append("\"]/common:Value");
            return pathBuilder.toString();
        case QUICK:
            pathBuilder.append("/doc:Document/common:Tags/common:Tag/common:Value").append(",")
                    .append("/doc:Document/doc:Data/common:Name");
            return pathBuilder.toString();

        default:
            throw new IllegalArgumentException("Criterion level " + criterion.getLevel() + " is not supported");

        }

    }
}
