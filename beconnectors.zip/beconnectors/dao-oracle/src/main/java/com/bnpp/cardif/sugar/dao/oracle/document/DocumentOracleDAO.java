package com.bnpp.cardif.sugar.dao.oracle.document;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00101;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00102;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00104;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00105;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.jdbc.support.oracle.SqlArrayValue;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.document.DocumentDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.dao.oracle.xpath.SearchQueryHelper;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Query;

/**
 * Specific implementation of {@link DocumentDAO} for Oracle
 * 
 * @author Christopher Laszczuk
 * 
 */
@Component
public class DocumentOracleDAO extends AbstractDAO implements DocumentDAO {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentOracleDAO.class);
    
    private static final String DOCUMENT_IDS = "DocumentIds";
    private static final String P_SCOPE = "p_scope";
    private static final String P_TRACE_LEVEL = "p_traceLevel";


    @Autowired
    private SearchQueryHelper documentSearchQueryhelper;

    private class StoreSingleProc extends StoredProcedure {

        public StoreSingleProc() {
            super(getDataSource(), "PKG_DOCUMENT.store_single");
            declareParameter(new SqlParameter("p_DOCUMENT", Types.CLOB));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, Types.INTEGER));
            compile();
        }

        public void run(Document document) throws SugarTechnicalException {
            final String write = getWriter(Document.class).write(document);

            Map<String, Object> in = new HashMap<>();
            in.put("p_DOCUMENT", new SqlLobValue(write, lobHandler));
            in.put(P_TRACE_LEVEL, getLoglevel());
            this.execute(in);
        }
    }

    @Override
    public void store(final List<Document> documentsToStore) throws SugarTechnicalException {
        try {
            LOGGER.debug("Storing {} documents", documentsToStore.size());
            StoreSingleProc proc = new StoreSingleProc();
            for (Document document : documentsToStore) {
                proc.run(document);
            }
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00101, e);
        }
        LOGGER.info("{} documents have stored", documentsToStore.size());

    }

    private class UpdateSingleProc extends StoredProcedure {

        public UpdateSingleProc() {
            super(getDataSource(), "PKG_DOCUMENT.UPDATE_DOC_SINGLE");
            declareParameter(new SqlParameter("documentToStore", Types.CLOB));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, Types.INTEGER));
            compile();
        }

        public void run(Document document) throws SugarTechnicalException {
            final String write = getWriter(Document.class).write(document);

            Map<String, Object> in = new HashMap<>();
            in.put("documentToStore", new SqlLobValue(write, lobHandler));
            in.put(P_TRACE_LEVEL, getLoglevel());
            this.execute(in);
        }
    }

    @Override
    public List<Document> update(List<Document> documentsToUpdate) throws SugarTechnicalException {

        try {
            LOGGER.debug("Updating {} documents", documentsToUpdate.size());
            UpdateSingleProc proc = new UpdateSingleProc();
            for (Document document : documentsToUpdate) {
                proc.run(document);
            }
            return documentsToUpdate;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00102, e);
        }
    }

    private class GetProc extends StoredProcedure {

        public GetProc() {
            super(getDataSource(), "PKG_DOCUMENT.get");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(DOCUMENT_IDS, OracleTypes.ARRAY, getDbUserName() + ".VARCHARARRAY"));
            declareParameter(new SqlOutParameter("DocumentsFetched", OracleTypes.CURSOR, new ObjectMapper(1)));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, OracleTypes.INTEGER));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public List<Document> run(String scope, List<Id> ids) throws SugarTechnicalException {

            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (Id id : ids) {
                serializedIds.add(getWriter(Id.class).write(id));
            }

            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put(DOCUMENT_IDS, new SqlArrayValue(serializedIds.toArray()));
            in.put(P_TRACE_LEVEL, getLoglevel());
            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get("DocumentsFetched");
            List<Document> unwrappedDocuments = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocuments.add(getReader(Document.class).read(serializedDocument));
            }

            return unwrappedDocuments;
        }

    }

    @Override
    public List<Document> fetch(String scope, List<Id> ids) throws SugarTechnicalException {
        LOGGER.debug("Trying to fetch documents from DB with ids={}", ids);
        try {
            GetProc get = new GetProc();
            List<Document> fetchedDocuments = get.run(scope, ids);

            LOGGER.info("{} document have been fetched from database", fetchedDocuments.size());
            return fetchedDocuments;
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00102, ids, scope, e);
        }
    }

    private class FindProc extends StoredProcedure {

        public FindProc() {
            super(getDataSource(), "PKG_DOCUMENT.find");
            declareParameter(new SqlParameter("p_request", OracleTypes.VARCHAR));
            declareParameter(new SqlOutParameter("pout_documentCursor", OracleTypes.CURSOR, new ObjectMapper(1)));
            declareParameter(new SqlOutParameter("pout_resultCount", OracleTypes.INTEGER));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, OracleTypes.INTEGER));
            declareParameter(new SqlParameter("p_requestId", OracleTypes.VARCHAR));
            compile();
        }

        private List<Document> unwrappedDocuments;

        private long resultCount;

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(Query buildQuery, int traceLevel, String requestId) throws SugarTechnicalException {

            String queryAsString = getWriter(Query.class).write(buildQuery);
            LOGGER.info("Query: to {}...", queryAsString);

            Map in = new HashMap();
            in.put("p_request", queryAsString);
            in.put(P_TRACE_LEVEL, traceLevel);
            in.put("p_requestId", requestId);

            Map out = this.execute(in);

            List<String> serializedResults = (List<String>) out.get("pout_documentCursor");
            List<Document> unwrappedDocumentList = new ArrayList<>(serializedResults.size());
            for (String serializedDocument : serializedResults) {
                unwrappedDocumentList.add(getReader(Document.class).read(serializedDocument));
            }

            this.unwrappedDocuments = unwrappedDocumentList;
            this.resultCount = (Integer) out.get("pout_resultCount");
        }

        public long getNumberOfResults() {
            return resultCount;
        }

        public List<Document> getFoundDocuments() {
            return unwrappedDocuments;
        }

    }

    @Override
    public SearchResults<Document> find(final String scope, final Criteria criteria, final OrderClause order,
            final long start, final long max) throws SugarTechnicalException {
        Query buildQuery = null;
        try {

            Criterion init = null;
            if (!criteria.getCriterionList().isEmpty()) {
                init = criteria.getCriterionList().get(0);
            }
            // detecter si recherche mix (Quick + advanced)
            if (init != null && Levels.QUICK.equals(init.getLevel()) && criteria.getCriterionList().size() > 1) {
                buildQuery = getQueryHelper().buildMixQuery(scope, criteria, order);
            }
            else {
                buildQuery = getQueryHelper().buildQuery(scope, criteria, order);
            }

            buildQuery.setPageStart((int) start + 1);

            long maximumNResults = max == 0 ? Long.parseLong(getQueryHelper().getMaxSearch()) : max;

            buildQuery.setPageSize((int) maximumNResults);

            FindProc findProc = new FindProc();

            LOGGER.info("Finding {} documents from index={}", maximumNResults, start);
            findProc.run(buildQuery, -3, null);
            List<Document> foundDocuments = findProc.getFoundDocuments();

            LOGGER.info("{} documents have been retrieved over {} found results", foundDocuments.size(),
                    findProc.getNumberOfResults());

            return new SearchResults<>(foundDocuments, findProc.getNumberOfResults(),
                    Long.parseLong(getQueryHelper().getMaxSearch()));
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00104, criteria, e);
        }
    }

    private class DeleteDocProc extends StoredProcedure {
        public DeleteDocProc() {
            super(getDataSource(), "PKG_DOCUMENT.delete_doc");
            declareParameter(new SqlParameter(P_SCOPE, OracleTypes.VARCHAR));
            declareParameter(new SqlParameter(DOCUMENT_IDS, OracleTypes.ARRAY, getDbUserName() + ".VARCHARARRAY"));
            declareParameter(new SqlParameter(P_TRACE_LEVEL, OracleTypes.INTEGER));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String scope, List<Id> ids) throws SugarTechnicalException {
            ArrayList<String> serializedIds = new ArrayList<>(ids.size());
            for (Id id : ids) {
                serializedIds.add(getWriter(Id.class).write(id));
            }

            Map in = new HashMap();
            in.put(P_SCOPE, scope);
            in.put(DOCUMENT_IDS, new SqlArrayValue(serializedIds.toArray()));
            in.put(P_TRACE_LEVEL, getLoglevel());

            this.execute(in);
        }
    }

    @Override
    public void delete(String scope, List<Id> ids) throws SugarTechnicalException {

        try {
            DeleteDocProc deleteDocProc = new DeleteDocProc();
            deleteDocProc.run(scope, ids);

            LOGGER.info("{} document have been deleted from database", ids.size());
        }
        catch (Exception e) {
            throw ExceptionBuilder.createTechnicalException(T00105, ids, e);
        }

    }

    @Override
    public List<Id> fetchIdsByScope(String scope) throws SugarTechnicalException {

        List<Id> res;
        try {
            StringBuilder query = new StringBuilder(
                    "SELECT ID_VALUE, ID_SCHEME, ID_ISSUER FROM DOCUMENTS WHERE SCOPE = ?");
            String[] variables = { scope };
            res = template.query(query.toString(), variables, new RowMapper<Id>() {

                @Override
                public Id mapRow(ResultSet rs, int row) throws SQLException {
                    Id id = new Id();
                    id.setValue(rs.getString(1));
                    id.setScheme(rs.getString(2));
                    id.setIssuer(rs.getString(3));
                    return id;
                }

            });
            return res;
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00102, e);
        }
    }

    @Override
    public List<String> getUnlinkedDocument() throws SugarTechnicalException {

        List<String> res;
        try {
            StringBuilder query = new StringBuilder(
                    "SELECT DOC_ID FROM (SELECT DOC_ID, PARENT_ID FROM  (SELECT XML_CONTENT FROM DOCUMENTS ");
            query.append(
                    "WHERE CONTAINS(DOCUMENTS.XML_CONTENT, 'HASPATH (/doc:Document[@Category=\"DOCUMENT\"])') > 0");
            query.append(") DOCUMENTS_FILTERED,  XMLTABLE(");
            query.append(
                    "XMLNAMESPACES('http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1' AS \"doc\"),");
            query.append(
                    "'$d' PASSING DOCUMENTS_FILTERED.XML_CONTENT as \"d\" COLUMNS DOC_ID PATH '/doc:Document/doc:Id',");
            query.append(
                    "PARENT_ID PATH '/doc:Document/doc:ParentId/doc:Id') DOCUMENTS_XML) DOCUMENTS_DATA LEFT JOIN (");
            query.append("SELECT ENV_ID FROM (SELECT XML_CONTENT FROM DOCUMENTS ");
            query.append(
                    "WHERE CONTAINS(DOCUMENTS.XML_CONTENT, 'HASPATH (/doc:Document[@Category=\"ENVELOPE\"])') > 0) ENVELOPES_FILTERED, ");
            query.append(
                    "XMLTABLE(XMLNAMESPACES('http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1' AS \"doc\"),");
            query.append(
                    "'$d' PASSING ENVELOPES_FILTERED.XML_CONTENT as \"d\" COLUMNS ENV_ID PATH '/doc:Document/doc:Id', ");
            query.append("ENVPARENT_ID PATH '/doc:Document/doc:ParentId/doc:Id') ENVELOPES_XML ) ENVELOPES_DATA ");
            query.append("ON DOCUMENTS_DATA.PARENT_ID = ENVELOPES_DATA.ENV_ID WHERE ENVELOPES_DATA.ENV_ID is null");

            res = template.query(query.toString(), new RowMapper<String>() {

                @Override
                public String mapRow(ResultSet rs, int row) throws SQLException {
                    return rs.getString(1);

                }
            });
            return res;

        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00104, e);
        }
    }

    @Override
    public List<String> getUnlinkedEnveloppe() throws SugarTechnicalException {
        List<String> res;
        try {
            StringBuilder query = new StringBuilder(
                    "SELECT ID_VALUE as ENV_ID FROM DOCUMENTS WHERE CONTAINS(DOCUMENTS.XML_CONTENT, ");
            query.append("'HASPATH (/doc:Document[@Category=\"ENVELOPE\"]) AND HASPATH(/doc:Document/doc:");
            query.append("Status/common:Code!=\"DELETED\")') > 0 AND NOT EXISTSNODE(DOCUMENTS.XML_CONTENT, ");
            query.append("'/doc:Document/doc:ChildObject/doc:Id', 'xmlns:doc=\"http://ea.assurance.bnpparibas.com/");
            query.append("internal/schema/mco/document/v1\"') > 0 UNION SELECT DISTINCT(ENV_ID) FROM (");
            query.append("SELECT ENV_ID, CHILD_ID FROM (SELECT XML_CONTENT FROM DOCUMENTS WHERE ");
            query.append("CONTAINS(DOCUMENTS.XML_CONTENT, 'HASPATH (/doc:Document[@Category=\"ENVELOPE\"])') > 0");
            query.append(") ENVELOPES_FILTERED, XMLTABLE(XMLNAMESPACES('http://ea.assurance.bnpparibas.com");
            query.append(
                    "/internal/schema/mco/document/v1' AS \"doc\"), 'for $i in /doc:Document/doc:ChildObject/doc:Id");
            query.append(" return <row>{$i,<envelopeId>{$i/../../doc:Id}</envelopeId>}</row>' ");
            query.append("PASSING ENVELOPES_FILTERED.XML_CONTENT COLUMNS ENV_ID  PATH '/row/envelopeId/doc:Id',");
            query.append("CHILD_ID PATH '/row/doc:Id') ENVELOPES_XML) ENVELOPES_DATA LEFT JOIN DOCUMENTS ");
            query.append("ON ENVELOPES_DATA.CHILD_ID = DOCUMENTS.ID_VALUE WHERE DOCUMENTS.ID_VALUE = null");
            res = template.query(query.toString(), new RowMapper<String>() {

                @Override
                public String mapRow(ResultSet rs, int row) throws SQLException {

                    return rs.getString(1);

                }
            });
            return res;

        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00104, e);
        }
    }

    // TODO: DO TEST
    @Override
    public void deleteAll(List<String> ids) throws SugarTechnicalException {
        if (!ids.isEmpty()) {
            Object[] variables = ids.toArray();

            StringBuilder query = new StringBuilder("DELETE FROM DOCUMENTS WHERE ");
            for (int i = 0; i < ids.size(); i++) {
                query.append("ID_VALUE = ? OR ");
            }
            // remove end
            query.setLength(query.length() - 4);

            try {
                template.update(query.toString(), variables);
            }
            catch (DataAccessException e) {
                throw ExceptionBuilder.createTechnicalException(T00105, e);
            }
        }
    }

    public SearchQueryHelper getQueryHelper() {
        return documentSearchQueryhelper;
    }

    public void setQueryHelper(SearchQueryHelper queryHelper) {
        this.documentSearchQueryhelper = queryHelper;
    }
}
