package com.bnpp.cardif.sugar.dao.oracle.xpath;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Directions;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.FilterType;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.LogicalOperators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OperandType;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderType;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderType.OrderKey;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Query;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.google.common.collect.Lists;

public class SearchQueryHelper {
    
    private static final String HASPATH = "HASPATH";

    private static final String INPATH = "INPATH";

    private XPathFieldHelper xpathHelper;

    private static final Logger LOGGER = LoggerFactory.getLogger(SearchQueryHelper.class);

    private String maxSearch;
    
    private String language;

    private SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");

    public void init() throws SugarTechnicalException {
        // Legacy method, should be revised
    }

    public Query buildQuery(String scope, Criteria criteria, OrderClause order) {
        Query query = new Query();
        query.setLang(language);
        query.setMaxLimitSearch(Long.parseLong(maxSearch));
        query.setScope(scope);
        query.setOrder(buildOrderQuery(order));

        FilterType filters = new FilterType();
        setLogicalOperator(criteria, filters);

        for (Criterion criterion : criteria.getCriterionList()) {
            if (criterion.getValues().size() > 1 && !Levels.CHILD.equals(criterion.getLevel())) {
                FilterType filter = new FilterType();
                filter.setLogicalOperator(LogicalOperators.OR);

                for (String value : criterion.getValues()) {
                    filter.getFilter().add(buildFilter(criterion, formateValue(criterion.getType(), value)));
                }
                filters.getFilter().add(filter);

            }
            else if (Levels.CHILD.equals(criterion.getLevel())) {
                LOGGER.debug("building child filter");
                filters.getFilter().add(buildChildFilter(criterion));
                LOGGER.info("BUILT : {}", filters);
            }
            else if (criterion.getValues() != null && !criterion.getValues().isEmpty()) {
                filters.getFilter()
                        .add(buildFilter(criterion, formateValue(criterion.getType(), criterion.getValues().get(0))));
            }
        }

        if (criteria.isSetItem() && !Item.FOLDER.equals(criteria.getItem())) {
            query.setFilter(new FilterType());
            Criterion mand = new Criterion(Levels.ATTRIBUTE, "Category", Operators.EQUALS_TO, Types.STRING,
                    Lists.newArrayList(criteria.getItem().toString()));
            criteria.getCriterionList().add(mand);
            FilterType categoryFilter = buildFilter(mand, mand.getValues().get(0));
            query.getFilter().setLogicalOperator(LogicalOperators.AND);
            query.getFilter().getFilter().add(categoryFilter);
            if (!filters.getFilter().isEmpty()) {
                query.getFilter().getFilter().add(filters);
            }

        }
        else {
            if (!filters.getFilter().isEmpty()) {
                query.setFilter(filters);
            }
        }

        return query;

    }

    private FilterType addCategory(Criteria criteria) {
        FilterType filters = new FilterType();
        // ajout de la catégorie
        filters.setLogicalOperator(LogicalOperators.AND);
        Criterion mand = new Criterion(Levels.ATTRIBUTE, "Category", Operators.EQUALS_TO, Types.STRING,
                Lists.newArrayList(criteria.getItem().toString()));
        FilterType categoryFilter = buildFilter(mand, mand.getValues().get(0));
        filters.getFilter().add(categoryFilter);
        return filters;
    }

    public Query buildMixQuery(String scope, Criteria criteria, OrderClause order) {
        Query query = new Query();
        query.setLang(language);
        query.setMaxLimitSearch(Long.parseLong(maxSearch));
        query.setScope(scope);
        query.setOrder(buildOrderQuery(order));

        List<Criterion> crits = criteria.getCriterionList();
        // Racine : effectue un AND entre les deux recherches
        FilterType baseFilter = new FilterType();
        baseFilter.setLogicalOperator(LogicalOperators.AND);

        // génération de la query pour la quick search
        FilterType categoryQuickFilter = null;
        if (!Item.FOLDER.equals(criteria.getItem())) {
            categoryQuickFilter = this.addCategory(criteria);
        }

        FilterType quickFilter = new FilterType();
        quickFilter.setLogicalOperator(LogicalOperators.OR);
        Criterion quickSearchCriterion = crits.get(0);
        quickFilter.getFilter().add(buildFilter(quickSearchCriterion,
                formateValue(quickSearchCriterion.getType(), quickSearchCriterion.getValues().get(0))));
        if (categoryQuickFilter == null) {
            categoryQuickFilter = quickFilter;
        }
        else {
            categoryQuickFilter.getFilter().add(quickFilter);
        }

        // génération de la query pour la recherche avancée
        FilterType categoryAdvanceFilter = null;
        if (!Item.FOLDER.equals(criteria.getItem())) {
            categoryAdvanceFilter = this.addCategory(criteria);
        }
        FilterType advanceFilter = new FilterType();
        advanceFilter.setLogicalOperator(LogicalOperators.AND);
        for (int idx = 1; idx < crits.size(); idx++) {
            Criterion advanceSearchCriterion = crits.get(idx);
            advanceFilter.getFilter().add(buildFilter(advanceSearchCriterion,
                    formateValue(advanceSearchCriterion.getType(), advanceSearchCriterion.getValues().get(0))));
        }
        if (categoryAdvanceFilter == null) {
            categoryAdvanceFilter = advanceFilter;
        }
        else {
            categoryAdvanceFilter.getFilter().add(advanceFilter);
        }

        baseFilter.getFilter().add(categoryQuickFilter);
        baseFilter.getFilter().add(categoryAdvanceFilter);
        query.setFilter(baseFilter);

        return query;
    }

    private FilterType buildChildFilter(Criterion criterion) {

        FilterType filter = new FilterType();
        filter.setOperator(INPATH);
        filter.setPath(xpathHelper.getQuery(criterion));
        filter.setOperand(new OperandType(formateValue(Types.STRING, criterion.getValues().get(2)), null));
        return filter;

    }

    private void setLogicalOperator(Criteria criteria, FilterType filters) {
        if (!criteria.isAny()) {
            filters.setLogicalOperator(LogicalOperators.AND);
        }
        else {
            filters.setLogicalOperator(LogicalOperators.OR);
        }
    }

    private String formateValue(Types type, String value) {

        switch (type) {

        case STRING:
            return replaceSpecialChar(value);
        case TIMESTAMP:
            return formateDate(value);
        default:
            return value;
        }

    }

    private String replaceSpecialChar(String value) {
        return value.replaceAll("[\\-]", "\\\\-");
    }

    private FilterType buildFilter(Criterion criterion, String value) {

        switch (criterion.getLevel()) {
        case ATTRIBUTE:
            return buildAttributeFilter(criterion, value);
        case DATA:
            return buildDataOrTagFilter(criterion, value);
        case TAG:
            return buildDataOrTagFilter(criterion, value);
        case QUICK:
            return buildQuickSearchFilter(criterion, value);
        case CHILD:
        default:
            throw new IllegalArgumentException("Criterion level " + criterion.getLevel() + " is not supported ");

        }
    }

    private FilterType buildQuickSearchFilter(Criterion criterion, String value) {

        String query = xpathHelper.getQuery(criterion);
        String[] splited = query.split(",");
        FilterType filters = new FilterType();
        filters.setLogicalOperator(LogicalOperators.OR);
        for (int i = 0; i < splited.length; i++) {
            FilterType filter = new FilterType();
            filter.setOperand(new OperandType(value, null));
            filter.setOperator(INPATH);
            filter.setPath(splited[i]);
            filters.getFilter().add(filter);
        }

        return filters;
    }

    private FilterType buildDataOrTagFilter(Criterion criterion, String value) {
        FilterType filter = new FilterType();
        switch (criterion.getType()) {
        case BOOLEAN:

            if (Operators.EQUALS_TO.equals(criterion.getOperator())) {
                filter.setOperator(INPATH);
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperand(new OperandType(value, null));
                return filter;
            }
            else {
                throw new IllegalArgumentException(
                        "Operator " + criterion.getOperator() + " is not supported for Type" + criterion.getType());
            }
        case STRING:
            filter.setOperator(INPATH);
            filter.setPath(getXpathHelper().getQuery(criterion));
            switch (criterion.getOperator()) {
            case CONTAINS:
                filter.setOperand(new OperandType("%" + value + "%", null));
                return filter;
            case ENDS_WITH:
                filter.setOperand(new OperandType("%" + value, null));
                return filter;
            case EQUALS_TO:
                buildStringEqualityFilter(filter, value);
                return filter;
            case STARTS_WITH:
                filter.setOperand(new OperandType(value + "%", null));
                return filter;
            case NOT_EQUALS_TO:
                buildStringNotEqualityFilter(value, filter);
                return filter;
            default:
                throw new IllegalArgumentException(
                        "Operator " + criterion.getOperator() + " is not supported for Type" + criterion.getType());
            }
        case TIMESTAMP:
            filter.setPath(getXpathHelper().getQuery(criterion));
            filter.setOperand(new OperandType(value, "date"));

            switch (criterion.getOperator()) {
            case EQUALS_TO:
                filter.setOperator("=");
                return filter;
            case GREATER_THAN:
                filter.setOperator(">");
                return filter;
            case LESS_THAN:
                filter.setOperator("<");
                return filter;

            default:
                throw new IllegalArgumentException(
                        "Operator " + criterion.getOperator() + " is not supported for Type" + criterion.getType());
            }

        case INTEGER:
            filter.setPath(getXpathHelper().getQuery(criterion));
            filter.setOperand(new OperandType(value, "number"));

            switch (criterion.getOperator()) {
            case EQUALS_TO:
                filter.setOperator("=");
                return filter;
            case GREATER_THAN:
                filter.setOperator(">");
                return filter;
            case LESS_THAN:
                filter.setOperator("<");
                return filter;

            default:
                throw new IllegalArgumentException(
                        "Operator " + criterion.getOperator() + " is not supported for Type" + criterion.getType());
            }

        default:
            throw new IllegalArgumentException("Criterion type " + criterion.getType() + " is not supported");

        }

    }

    private void buildStringNotEqualityFilter(String value, FilterType filter) {
        String path = filter.getPath();
        StringBuilder builder = new StringBuilder();
        builder.append(path).append("!=\"").append(value).append("\"");
        filter.setPath(builder.toString());
        filter.setOperator(HASPATH);
    }

    private void buildStringEqualityFilter(FilterType filter, String value) {
        String path = filter.getPath();
        StringBuilder builder = new StringBuilder();
        builder.append(path).append("=\"").append(value).append("\"");
        filter.setPath(builder.toString());
        filter.setOperator(HASPATH);
    }

    private String formateDate(String value) {
        Date parse = new Date(Long.parseLong(value));
        String formatedDate = dateFormater.format(parse);
        return formatedDate;
    }

    private FilterType buildAttributeFilter(Criterion criterion, String value) {
        FilterType filter = new FilterType();
        String isNotSupportedFor = " is not supported for ";
        switch (criterion.getOperator()) {
        case EQUALS_TO:
            if (Types.STRING.equals(criterion.getType()) || Types.BOOLEAN.equals(criterion.getType())) {
                filter.setOperator(HASPATH);
                filter.setPath(getXpathHelper().getQuery(criterion) + "=\"" + value + "\"");
            }
            else {
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperator("=");
                filter.setOperand(new OperandType(value, "date"));
            }
            return filter;
        case CONTAINS:
            if (Types.STRING.equals(criterion.getType())) {
                filter.setOperator(INPATH);
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperand(new OperandType("%" + value + "%", null));
                return filter;
            }
            else {
                throw new IllegalArgumentException("Operator " + criterion.getOperator() + isNotSupportedFor
                        + criterion.getType() + "criterion type ");
            }

        case ENDS_WITH:
            if (Types.STRING.equals(criterion.getType())) {
                filter.setOperator(INPATH);
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperand(new OperandType("%" + value, null));
                return filter;
            }
            else {
                throw new IllegalArgumentException("Operator " + criterion.getOperator() + isNotSupportedFor
                        + criterion.getType() + "criterion type ");
            }

        case STARTS_WITH:
            if (Types.STRING.equals(criterion.getType())) {
                filter.setOperator(INPATH);
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperand(new OperandType(value + "%", null));
                return filter;
            }
            else {
                throw new IllegalArgumentException("Operator " + criterion.getOperator() + isNotSupportedFor
                        + criterion.getType() + "criterion type ");
            }

        case GREATER_THAN:
            if (Types.TIMESTAMP.equals(criterion.getType())) {
                filter.setOperator("&gt;");
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperand(new OperandType(value, "date"));

                return filter;
            }
            else if (Types.INTEGER.equals(criterion.getType())) {
                filter.setOperator("&gt;");
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperand(new OperandType(value, "number"));
                return filter;
            }

            break;
        case LESS_THAN:
            if (Types.TIMESTAMP.equals(criterion.getType())) {
                filter.setOperator("&lt;");
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperand(new OperandType(value, "date"));
                return filter;
            }
            else if (Types.INTEGER.equals(criterion.getType())) {
                filter.setOperator("&lt;");
                filter.setPath(getXpathHelper().getQuery(criterion));
                filter.setOperand(new OperandType(value, "number"));
                return filter;
            }
            break;
        default:
            break;

        }
        return null;
    }

    private OrderType buildOrderQuery(OrderClause clause) {
        if (clause != null) {
            Criterion criterion = new Criterion();
            criterion.setLevel(clause.getLevel());
            criterion.setName(clause.getName());
            OrderType orderType = new OrderType();

            OrderKey orderKey = new OrderKey();
            orderKey.setValue(getXpathHelper().getQuery(criterion));
            if (clause.isAscending()) {
                orderKey.setDirection(Directions.ASC);
            }
            else {

                orderKey.setDirection(Directions.DESC);

            }
            orderType.getOrderKey().add(orderKey);
            return orderType;
        }
        else {
            return null;
        }

    }

    public XPathFieldHelper getXpathHelper() {
        return xpathHelper;
    }

    public void setXpathHelper(XPathFieldHelper xpathHelper) {
        this.xpathHelper = xpathHelper;
    }

    public String getMaxSearch() {
        return maxSearch;
    }

    public void setMaxSearch(String maxSearch) {
        this.maxSearch = maxSearch;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
