package com.bnpp.cardif.sugar.dao.oracle.documentfile;

import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00701;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00702;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00703;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.activation.DataHandler;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.dao.api.documentfile.DocumentFileDAO;
import com.bnpp.cardif.sugar.dao.oracle.util.AbstractDAO;
import com.bnpp.cardif.sugar.domain.documentfile.InputStreamDataSource;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;

/**
 * This class manages the files of documents according to the data layer.
 * Specific implementation of {@link DocumentFileDAO} for Oracle
 * 
 * @author Christopher Laszczuk
 * 
 */
@Component
public class DocumentFileOracleDAO extends AbstractDAO implements DocumentFileDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentFileOracleDAO.class);

    private static final String URI_IN = "URI_IN";

    private static final String SCOPE_IN = "SCOPE_IN";

    private class StoreSingleProc extends StoredProcedure {

        public StoreSingleProc() {
            super(getDataSource(), "PKG_DOCUMENTFILE.store");
            declareParameter(new SqlParameter("p_ELEMENT", Types.VARCHAR));
            declareParameter(new SqlParameter("p_BINARY", Types.BLOB));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String write, byte[] a) throws SugarTechnicalException {
            Map in = new HashMap();
            in.put("p_ELEMENT", write);
            in.put("p_BINARY", new SqlLobValue(a, lobHandler));
            this.execute(in);
        }
    }

    @Override
    public void store(List<DocumentFile> filesToStore) throws SugarTechnicalException {

        StoreSingleProc storeProcedure = new StoreSingleProc();
        for (final DocumentFile file : filesToStore) {
            try {

                final InputStream inputStream = file.getContent() != null ? file.getContent().getInputStream() : null;
                file.setContent(null);

                if (inputStream != null) {
                    final String write = getWriter(DocumentFile.class).write(file);
                    final byte[] a = IOUtils.toByteArray(inputStream);
                    storeProcedure.run(write, a);
                }
                else {
                    throw ExceptionBuilder.createTechnicalException(T00701);
                }
            }

            catch (IOException e) {
                throw ExceptionBuilder.createTechnicalException(T00701, e);
            }
        }
        LOGGER.info("{} document files have been added to database", filesToStore.size());
    }

    private class GetProcedure extends StoredProcedure {

        public GetProcedure() {
            super(getDataSource(), "PKG_DOCUMENTFILE.GET");

            declareParameter(new SqlParameter(SCOPE_IN, Types.VARCHAR));
            declareParameter(new SqlParameter(URI_IN, Types.VARCHAR));
            declareParameter(new SqlOutParameter("ELEMENT_OUT", Types.VARCHAR));
            declareParameter(new SqlOutParameter("DATA_OUT", Types.BLOB));
            compile();
        }

        private String ELEMENT_OUT;

        private Blob DATA_OUT;

        public void run(String scope, String uri) {
            HashMap<String, Object> inparams = new HashMap<>();
            inparams.put(SCOPE_IN, scope);
            inparams.put(URI_IN, uri);
            Map<String, Object> results = execute(inparams);
            ELEMENT_OUT = (String) results.get("ELEMENT_OUT");
            DATA_OUT = (Blob) results.get("DATA_OUT");
        }

        public DocumentFile getElement() throws SugarTechnicalException {
            return getReader(DocumentFile.class).read(ELEMENT_OUT);
        }

        public DataHandler getData() throws SQLException {
            return new DataHandler(new InputStreamDataSource(DATA_OUT.getBinaryStream()));
        }
    }

    @Override
    public List<DocumentFile> get(String scope, List<URI> uris) throws SugarTechnicalException {
        List<DocumentFile> results = new ArrayList<>();
        GetProcedure getProcedure = new GetProcedure();
        for (URI uri : uris) {
            try {

                getProcedure.run(scope, uri.getValue());

                DocumentFile file = getProcedure.getElement();
                file.setContent(getProcedure.getData());
                results.add(file);
            }
            catch (DataAccessException e) {
                throw ExceptionBuilder.createTechnicalException(T00702, uri.getValue(), scope, e);
            }
            catch (SQLException e) {
                throw ExceptionBuilder.createTechnicalException(T00702, uri.getValue(), scope, e);
            }
        }
        LOGGER.info("Trying to get document file for the scope {} having URIs: {}", scope, uris);
        return results;
    }

    private class DeleteProc extends StoredProcedure {

        public DeleteProc() {
            super(getDataSource(), "PKG_DOCUMENTFILE.DELETE_FILE");
            declareParameter(new SqlParameter(SCOPE_IN, Types.VARCHAR));
            declareParameter(new SqlParameter(URI_IN, Types.VARCHAR));
            compile();
        }

        @SuppressWarnings({ "unchecked", "rawtypes" })
        public void run(String scope, String uri) throws SugarTechnicalException {
            Map in = new HashMap();
            in.put(SCOPE_IN, scope);
            in.put(URI_IN, uri);
            this.execute(in);
        }
    }

    // TODO: to refactor with a List<URI>
    @Override
    public void delete(final String scope, final String uri) throws SugarTechnicalException {
        try {
            DeleteProc procedure = new DeleteProc();
            procedure.run(scope, uri);
        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00703, uri, scope, e);
        }
    }

    @Override
    public List<String> getUnlinkedDocumentFile(String scope) throws SugarTechnicalException {

        List<String> res;

        try {
            StringBuilder query = new StringBuilder("SELECT DOCS.URI FROM ");
            query.append("(SELECT URI, SCOPE FROM DOCUMENTFILES WHERE SCOPE = ?) DOCS LEFT JOIN ");
            query.append(
                    "(SELECT URI, SCOPE FROM (SELECT XML_CONTENT FROM DOCUMENTS WHERE CONTAINS(DOCUMENTS.XML_CONTENT, ");
            query.append(
                    "'HASPATH (/doc:Document[@Category=\"DOCUMENT\"])') > 0 AND DOCUMENTS.SCOPE=?) DOCUMENTS_FILTERED, ");
            query.append(
                    "XMLTABLE(XMLNAMESPACES('http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1' AS \"doc\"), ");
            query.append(
                    "'$d' PASSING DOCUMENTS_FILTERED.XML_CONTENT as \"d\" COLUMNS URI PATH '/doc:Document/doc:FileData/doc:URI', ");
            query.append("SCOPE PATH '/doc:Document/@Scope') DOCUMENTS_XML) DOCUMENTS_DATA ");
            query.append("ON DOCS.URI = DOCUMENTS_DATA.URI WHERE DOCUMENTS_DATA.URI is null");

            String[] variables = { scope, scope };

            res = template.query(query.toString(), variables, new RowMapper<String>() {

                @Override
                public String mapRow(ResultSet rs, int row) throws SQLException {
                    return rs.getString(1);
                }
            });

            return res;

        }
        catch (DataAccessException e) {
            throw ExceptionBuilder.createTechnicalException(T00702, e);
        }
    }

    @Override
    public void deleteAll(List<String> uris, String scopeName) throws SugarTechnicalException {
        if (!uris.isEmpty()) {
            ArrayList<String> variables = new ArrayList<>();
            StringBuilder query = new StringBuilder("DELETE FROM DOCUMENTFILES WHERE SCOPE = ? AND (");
            variables.add(scopeName);
            for (String uri : uris) {
                query.append("URI = ?").append(" OR ");
                variables.add(uri);
            }
            // remove end
            query.setLength(query.length() - 4);
            query.append(")");

            try {
                template.update(query.toString(), variables.toArray());
            }
            catch (DataAccessException e) {
                throw ExceptionBuilder.createTechnicalException(T00703, e);
            }
        }
    }

}
