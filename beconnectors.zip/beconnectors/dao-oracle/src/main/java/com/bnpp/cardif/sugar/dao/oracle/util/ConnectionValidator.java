package com.bnpp.cardif.sugar.dao.oracle.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.util.ResourceBundle;

import oracle.jdbc.OracleTypes;

import org.apache.tomcat.jdbc.pool.Validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;

public class ConnectionValidator implements Validator {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConnectionValidator.class);

    private static int MAX_CURSOR_NB = 100;

    static {
        ResourceBundle bundle = ResourceBundle.getBundle("connectionValidator");
        if (bundle != null) {
            String maxCursorNbStr = bundle.getString("max_cursor_number");
            if (maxCursorNbStr != null && maxCursorNbStr.length() > 0) {
                int maxCursorNb = Integer.parseInt(maxCursorNbStr);
                MAX_CURSOR_NB = maxCursorNb;
            }
        }
    }

    @Override
    public boolean validate(Connection connection, int validateAction) {
        int cursorNb = retrieveCursorDBSession(connection);
        final boolean result = cursorNb < MAX_CURSOR_NB;
        if (result) {
            LOGGER.trace("VALID CONNECTION : NB OF CURSOR : {}", cursorNb);
        }
        else {
            LOGGER.trace("INVALID CONNECTION : NB OF CURSOR : {}", cursorNb);
        }
        return result;
    }

    /**
     * Récupération du nombre de curseurs ouverts pour la session actuelle
     * 
     * @param connection
     *            connection du pool permettant d'aller chercher la session
     * @return Nombre de curseurs ouverts
     * @throws SugarTechnicalException
     *             exception
     */
    private int retrieveCursorDBSession(Connection connection) {
        int nbCursor = MAX_CURSOR_NB;
        try (CallableStatement csSessionDB = connection.prepareCall("{call PKG_TOOLS.GETCURRENTSESSIONCURSOR(?,?)}")) {
            DatabaseMetaData data = connection.getMetaData();

            String dbUserName = data.getUserName();
            csSessionDB.setString(1, dbUserName);
            csSessionDB.registerOutParameter(2, OracleTypes.INTEGER);
            csSessionDB.execute();
            nbCursor = csSessionDB.getInt(2);
            return nbCursor;
        }
        catch (Exception e) {
            LOGGER.error("Error during the connection check ", e);
            return nbCursor;
        }

    }
}
