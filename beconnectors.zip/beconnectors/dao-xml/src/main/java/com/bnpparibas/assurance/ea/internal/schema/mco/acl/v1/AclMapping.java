package com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.google.common.base.Objects;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "AclMapping")
public class AclMapping {
    private final static long serialVersionUID = 1L;

    @XmlElement(name = "Target", required = true)
    protected String target;

    @XmlElement(name = "Context", required = true)
    protected String aclContext;

    @XmlElement(name = "AclId", required = true)
    protected AclId aclId;

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getAclContext() {
        return aclContext;
    }

    public void setAclContext(String aclContext) {
        this.aclContext = aclContext;
    }

    public AclId getAclId() {
        return aclId;
    }

    public void setAclId(AclId aclId) {
        this.aclId = aclId;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("target", target).add("aclContext", aclContext).add("aclId", aclId)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(target, aclContext, aclId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass() != other.getClass()) {
            return false;
        }
        final AclMapping o = ((AclMapping) other);
        return ((Objects.equal(target, o.target) && Objects.equal(aclContext, o.aclContext))
                && Objects.equal(aclId, o.aclId));
    }

}
