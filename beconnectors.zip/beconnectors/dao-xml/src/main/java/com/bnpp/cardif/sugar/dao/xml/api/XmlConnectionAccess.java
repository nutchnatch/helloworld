package com.bnpp.cardif.sugar.dao.xml.api;

public enum XmlConnectionAccess {
    Read, Write
}
