package com.bnpp.cardif.sugar.dao.xml.acl;

import java.util.List;

import com.bnpp.cardif.sugar.dao.api.acl.AclDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclMapping;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

public class AclXmlDAO implements AclDAO {
    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operations
    }

    @Override
    public void store(AccessControlList acl) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            getDataSource().addEntry(connection, acl);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public AccessControlList get(AclId aclId, String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createAclQuery(aclId);

            AccessControlList result = getDataSource().getSingleEntry(connection, expression, AccessControlList.class);
            if (result == null) {
                throw new SugarTechnicalException("Could not get AclId=" + aclId);
            }
            return result;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public List<AccessControlList> getAll(String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createAclGetAllQuery(scope);

            return getDataSource().getEntries(connection, expression, AccessControlList.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private void assign(AclId aclId, AclContext context, String target) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            AclMapping mapping = new AclMapping();
            mapping.setAclId(aclId);
            mapping.setAclContext(context.name());
            mapping.setTarget(target);

            getDataSource().addEntry(connection, mapping);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    private AclId searchAcl(String scope, AclContext context, String objectId) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createAclMappingQuery(context, objectId);

            AclMapping mapping = getDataSource().getSingleEntry(connection, expression, AclMapping.class);
            if (mapping == null) {
                throw ExceptionBuilder.createTechnicalException(TechnicalErrorCode.T01004, objectId, context);
            }
            return mapping.getAclId();
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private void removeAcl(AclContext context, String objectId) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createAclMappingQuery(context, objectId);
            getDataSource().deleteEntry(connection, expression, AclMapping.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    private String serializeId(String scope, BusinessScopeId businessScopeId) {
        return "BS:" + scope;
    }

    private String serializeId(String scope, Id documentId) {
        return "DOC:" + documentId.getValue();
    }

    private String serializeId(String scope, FolderId folderId) {
        return "FOLDER:" + folderId.getValue();
    }

    private String serializeId(String scope, ClassId classId, AclContext context) {
        return "CLASS:" + classId.getValue() + "-" + context.name();
    }

    private String serializeId(String scope, BasketId basketId) {
        return "BASKET:" + basketId.getValue();
    }

    @Override
    public void assign(AclId aclId, BusinessScopeId scopeId, String scope, AclContext context)
            throws SugarTechnicalException {
        assign(aclId, context, serializeId(scope, scopeId));
    }

    @Override
    public void assign(AclId aclId, Id documentId, String scope) throws SugarTechnicalException {
        assign(aclId, AclContext.DOCUMENT, serializeId(scope, documentId));
    }

    @Override
    public void assign(AclId aclId, FolderId folderId, String scope) throws SugarTechnicalException {
        assign(aclId, AclContext.FOLDER, serializeId(scope, folderId));

    }

    @Override
    public void assign(AclId aclId, ClassId classId, AclContext context, String scope) throws SugarTechnicalException {
        assign(aclId, context, serializeId(scope, classId, context));
    }

    @Override
    public void assign(AclId aclId, BasketId basketId, String scope) throws SugarTechnicalException {
        assign(aclId, AclContext.BASKET, serializeId(scope, basketId));
    }

    @Override
    public AclId searchAcl(BusinessScopeId businessScopeId, String scope, AclContext context)
            throws SugarTechnicalException {
        return searchAcl(scope, context, serializeId(scope, businessScopeId));
    }

    @Override
    public AclId searchAcl(Id documentId, String scope) throws SugarTechnicalException {
        return searchAcl(scope, AclContext.DOCUMENT, serializeId(scope, documentId));
    }

    @Override
    public AclId searchAcl(FolderId folderId, String scope) throws SugarTechnicalException {
        return searchAcl(scope, AclContext.FOLDER, serializeId(scope, folderId));
    }

    @Override
    public AclId searchAcl(ClassId classId, AclContext context, String scope) throws SugarTechnicalException {
        return searchAcl(scope, context, serializeId(scope, classId, context));
    }

    @Override
    public AclId searchAcl(BasketId basketId, String scope) throws SugarTechnicalException {
        return searchAcl(scope, AclContext.BASKET, serializeId(scope, basketId));
    }

    @Override
    public void remove(BasketId basketId, String scope) throws SugarTechnicalException {
        removeAcl(AclContext.BASKET, serializeId(scope, basketId));
    }

    @Override
    public void remove(String scope, ClassId classId, AclContext context) throws SugarTechnicalException {
        removeAcl(context, serializeId(scope, classId, context));
    }

    @Override
    public void update(AccessControlList acl) throws SugarTechnicalException {
        String scope = acl.getScope();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);

        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createAclQuery(acl.getAclId());
            AccessControlList result = getDataSource().getSingleEntry(connection, expression, AccessControlList.class);
            if (result != null) {
                doDelete(scope, connection, acl.getAclId());
            }
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
        store(acl);
    }

    private void doDelete(String scope, XmlConnection connection, AclId aclId) throws SugarTechnicalException {
        XPathQuery expression = getDataSource().getExpressionFactory().createAclQuery(aclId);
        dataSource.deleteEntry(connection, expression, AccessControlList.class);
    }

    @Override
    public void remove(Id documentId, String scope) throws SugarTechnicalException {
        removeAcl(AclContext.DOCUMENT, serializeId(scope, documentId));

    }

    @Override
    public void remove(String scope, BusinessScopeId businessScopeId, AclContext context)
            throws SugarTechnicalException {
        // TODO Auto-generated method stub

    }

}
