package com.bnpp.cardif.sugar.dao.xml.tagclass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.tagclass.TagClassDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

public class TagClassXmlDAO implements TagClassDAO {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TagClassXmlDAO.class);

    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public void store(List<TagClass> tagClasses) throws SugarTechnicalException, SugarFunctionalException {
        if (tagClasses.isEmpty()) {
            return;
        }
        String scope = tagClasses.get(0).getScope();
        List<ClassId> classIds = extractClassIds(tagClasses);
        for (ClassId id : classIds) {
            if (Collections.frequency(classIds, id) != 1) {
                throw new SugarTechnicalException("Storing multiple times the tag : " + id);
            }
        }
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<TagClass> fetchedClasses = doGet(connection, scope, classIds);
            if (!fetchedClasses.isEmpty()) {
                throw new SugarTechnicalException("Already stored the following tag classes : " + fetchedClasses);
            }
            doStore(connection, tagClasses);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    private void doStore(XmlConnection connection, List<TagClass> tagClasses) {
        getDataSource().addEntries(connection, tagClasses);
    }

    @Override
    public List<TagClass> getAll(String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createTagSearchQuery(scope);
            List<TagClass> result = getDataSource().getEntries(connection, searchExpression, TagClass.class);
            return result;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public List<TagClass> get(String scope, List<ClassId> tagIds) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            return doGet(connection, scope, tagIds);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private List<TagClass> doGet(XmlConnection connection, String scope, List<ClassId> tagIds) {
        XPathQuery searchExpression = getDataSource().getExpressionFactory().createTagSearchQuery(scope, tagIds);
        List<TagClass> result = getDataSource().getEntries(connection, searchExpression, TagClass.class);
        return result;
    }

    @Override
    public List<TagClass> getBySymbolicName(String scope, List<String> symbolicNames) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory()
                    .createTagSearchBySymbolicNameQuery(scope, symbolicNames);
            List<TagClass> result = getDataSource().getEntries(connection, searchExpression, TagClass.class);

            return result;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private List<ClassId> extractClassIds(List<TagClass> classes) {
        List<ClassId> classIds = new ArrayList<>();
        for (TagClass tagClass : classes) {
            classIds.add(tagClass.getClassId());
        }
        return classIds;
    }

    @Override
    public void update(List<TagClass> tagClasses) throws SugarTechnicalException {
        if (tagClasses.isEmpty()) {
            return;
        }
        String scope = tagClasses.get(0).getScope();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<ClassId> tagIds = extractClassIds(tagClasses);
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createTagSearchQuery(scope, tagIds);
            getDataSource().deleteEntries(connection, searchExpression, TagClass.class);

            doStore(connection, tagClasses);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }
}
