package com.bnpp.cardif.sugar.dao.xml.documentfile;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnpp.cardif.sugar.dao.api.businessscope.BusinessScopeDAO;
import com.bnpp.cardif.sugar.dao.api.document.DocumentDAO;
import com.bnpp.cardif.sugar.dao.api.documentfile.DocumentFileDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.google.common.collect.Lists;

public class DocumentFileXmlDAO implements DocumentFileDAO {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentFileXmlDAO.class);

    private XmlDatasource dataSource;

    @Autowired
    private DocumentDAO documentDAO;

    @Autowired
    private BusinessScopeDAO scopeDAO;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    private List<URI> extractURI(List<DocumentFile> files) {
        List<URI> uris = Lists.newArrayList();
        for (DocumentFile df : files) {
            uris.add(new URI(df.getURI()));
        }
        return uris;
    }

    @Override
    public void store(List<DocumentFile> filesToStore) throws SugarTechnicalException {
        if (filesToStore.isEmpty()) {
            return;
        }
        String scope = filesToStore.get(0).getScope();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<URI> uris = extractURI(filesToStore);
            List<DocumentFile> existing = getDataSource().getEntries(connection,
                    getDataSource().getExpressionFactory().createGetDocumentFileQuery(scope, uris), DocumentFile.class);
            if (!existing.isEmpty()) {
                throw new SugarTechnicalException(
                        "Already has the following DocumentFile Ids : " + extractURI(existing));
            }
            getDataSource().addEntries(connection, filesToStore);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public List<DocumentFile> get(String scope, List<URI> uri) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery query = getDataSource().getExpressionFactory().createGetDocumentFileQuery(scope, uri);
            List<DocumentFile> entries = getDataSource().getEntries(connection, query, DocumentFile.class);
            if (entries.size() != uri.size()) {
                throw new SugarTechnicalException("Missing some URIs from list : " + uri);
            }
            return entries;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void delete(String scope, String uriString) throws SugarTechnicalException {
        List<URI> uris = Lists.newArrayList(new URI(uriString));

        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            XPathQuery query = getDataSource().getExpressionFactory().createGetDocumentFileQuery(scope, uris);
            getDataSource().deleteEntries(connection, query, DocumentFile.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    @Override
    public List<String> getUnlinkedDocumentFile(String scopeName) throws SugarTechnicalException {
        List<BusinessScope> scopes = scopeDAO.getAll();
        Criteria criteria = new Criteria();
        criteria.setItem(Item.DOCUMENT);
        List<String> unlinkedDocumentFiles = new ArrayList<>();
        List<Document> allDocuments = new ArrayList<>();

        for (BusinessScope scope : scopes) {
            allDocuments
                    .addAll(documentDAO.find(scope.getSymbolicName(), criteria, null, 0, Long.MAX_VALUE).getObjects());
        }

        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            XPathQuery query = getDataSource().getExpressionFactory().createGetAllDocumentFileQuery();
            List<DocumentFile> documentFiles = getDataSource().getEntries(connection, query, DocumentFile.class);
            for (DocumentFile documentFile : documentFiles) {
                boolean found = false;
                for (Document document : allDocuments) {
                    if (document.isSetFileData() && document.getFileData().isSetURI()
                            && documentFile.getURI().equals(document.getFileData().getURI().get(0))) {
                        found = true;
                    }
                }
                if (!found) {
                    unlinkedDocumentFiles.add(documentFile.getURI());
                }
            }
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
        return unlinkedDocumentFiles;
    }

    @Override
    public void deleteAll(List<String> uris, String scopeName) throws SugarTechnicalException {

        List<URI> urisAsURI = new ArrayList<>();
        for (String uri : uris) {
            urisAsURI.add(new URI(uri));
        }
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            XPathQuery query = getDataSource().getExpressionFactory().createGetDocumentFileQuery(urisAsURI);
            getDataSource().deleteEntries(connection, query, DocumentFile.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }
}
