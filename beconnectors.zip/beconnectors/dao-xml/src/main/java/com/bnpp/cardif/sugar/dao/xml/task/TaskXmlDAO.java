package com.bnpp.cardif.sugar.dao.xml.task;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.task.TaskDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

public class TaskXmlDAO implements TaskDAO {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskXmlDAO.class);

    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public List<Task> get(String scope, List<TaskId> tasksId) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            return doGet(scope, tasksId, connection);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private List<Task> doGet(String scope, List<TaskId> tasksId, XmlConnection connection) {
        XPathQuery expression = getDataSource().getExpressionFactory().createGetTasksForDocQuerry(scope, tasksId);
        List<Task> results = new ArrayList<>();
        if (tasksId.size() > 0) {
            results = getDataSource().getEntries(connection, expression, Task.class);
        }

        return results;
    }

    @Override
    public void storeTasks(List<Task> tasks) throws SugarTechnicalException {
        long startStore = System.currentTimeMillis();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);

        try {
            List<Task> taskToStore = new ArrayList<>();
            for (Task task : tasks) {
                if (taskToStore.contains(task)) {
                    throw new SugarTechnicalException("Task already stored");
                }
                else {
                    taskToStore.add(task);
                }
            }
            doStore(connection, taskToStore);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
        long endStore = System.currentTimeMillis();
        LOGGER.info("[TaskXMLDAO.store() : Total store for " + tasks.size() + " : " + (endStore - startStore) + "ms");

    }

    private void doStore(XmlConnection connection, List<Task> tasksToStore) throws SugarTechnicalException {
        getDataSource().addEntries(connection, tasksToStore);
    }

    @Override
    public void updateStatus(String scope, List<TaskId> tasksIds, String status) throws SugarTechnicalException {

        if (tasksIds.size() < 1) {
            return;
        }
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {

            List<Task> fetchedTasks = doGet(scope, tasksIds, connection);
            for (Task fetchTask : fetchedTasks) {
                fetchTask.setStatus(status);
            }
            doDelete(scope, connection, tasksIds);
            doStore(connection, fetchedTasks);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private void doDelete(String scope, XmlConnection connection, List<TaskId> taskIdsToDelete)
            throws SugarTechnicalException {
        XPathQuery expression = getDataSource().getExpressionFactory().createGetTasksForDocQuerry(scope,
                taskIdsToDelete);
        int total = getDataSource().deleteEntries(connection, expression, Task.class);
        if (total != taskIdsToDelete.size()) {
            throw new SugarTechnicalException("Could not delete all ids : " + taskIdsToDelete + " : asked="
                    + taskIdsToDelete.size() + ", deleted=" + total);
        }
    }

    @Override
    public void lock(String scope, List<TaskId> tasksId, String lockerName) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<Task> fetchedTasks = doGet(scope, tasksId, connection);
            for (Task fetchTask : fetchedTasks) {
                if (fetchTask.getLockerName() == null) {
                    fetchTask.setLockerName(lockerName);
                }
            }
            doDelete(scope, connection, tasksId);
            doStore(connection, fetchedTasks);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    @Override
    public void unlock(String scope, List<TaskId> tasksId) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {

            List<Task> fetchedTasks = doGet(scope, tasksId, connection);
            for (Task fetchTask : fetchedTasks) {
                fetchTask.setLockerName(null);
            }
            doDelete(scope, connection, tasksId);
            doStore(connection, fetchedTasks);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void transfer(String scope, List<TaskId> tasksId, BasketId basketId) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<Task> fetchedTasks = doGet(scope, tasksId, connection);
            for (Task fetchTask : fetchedTasks) {
                fetchTask.setBasketId(basketId);
            }
            doDelete(scope, connection, tasksId);
            doStore(connection, fetchedTasks);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    @Override
    public SearchResults<Task> getTasksInBasket(String scope, BasketId basketId, int start, int max,
            Boolean includeClosed) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createGetTasksInBasketQuery(scope,
                    basketId);
            return getDataSource().getEntriesPartial(connection, searchExpression, Task.class, start, max);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public List<Task> getTasksForDoc(String scope, Id docId) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createGetTasksForDocQuerry(scope, docId);
            List<Task> results = getDataSource().getEntries(connection, expression, Task.class);
            return results;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void update(List<Task> tasksToUpdate) throws SugarTechnicalException {
        // No operation
    }

    @Override
    public List<Task> getByUser(String scope, String userName) {
        // TODO Auto-generated method stub
        return new ArrayList<>();
    }

    @Override
    public List<TaskId> fetchIdsByScope(String scope) throws SugarTechnicalException {
        // TODO Auto-generated method stub
        return new ArrayList<>();
    }
}
