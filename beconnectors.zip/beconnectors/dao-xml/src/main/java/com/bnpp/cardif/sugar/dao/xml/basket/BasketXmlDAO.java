package com.bnpp.cardif.sugar.dao.xml.basket;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.basket.BasketDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

public class BasketXmlDAO implements BasketDAO {
    private static final Logger LOGGER = LoggerFactory.getLogger(BasketXmlDAO.class);

    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public List<Basket> getAll(String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createBasketGetAllQuery(scope);
            return getDataSource().getEntries(connection, expression, Basket.class);

        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void store(List<Basket> basketsToStore) throws SugarTechnicalException {
        long startStore = System.currentTimeMillis();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);

        try {
            doStore(connection, basketsToStore);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
        long endStore = System.currentTimeMillis();
        LOGGER.info("[BasketXMLDAO.store() : Total store for " + basketsToStore.size() + " : " + (endStore - startStore)
                + "ms");

    }

    private void doStore(XmlConnection connection, List<Basket> basketsToStore) throws SugarTechnicalException {
        getDataSource().addEntries(connection, basketsToStore);
    }

    @Override
    public List<Basket> get(List<BasketId> basketId, String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createBasketGetQuery(scope, basketId);
            return getDataSource().getEntries(connection, expression, Basket.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void update(List<Basket> basketsToUpdate) throws SugarTechnicalException {
        String scope = basketsToUpdate.get(0).getScope();
        List<BasketId> idsToDelete = getSubListOfBasketId(basketsToUpdate);
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doDelete(scope, connection, idsToDelete);
            doStore(connection, basketsToUpdate);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private static List<BasketId> getSubListOfBasketId(List<Basket> baskets) {
        List<BasketId> basketIds = Lists.transform(baskets, new Function<Basket, BasketId>() {
            @Override
            public BasketId apply(Basket basket) {
                if (basket == null) {
                    return null;
                }
                return basket.getBasketId();
            }
        });
        return basketIds;
    }

    private void doDelete(String scope, XmlConnection connection, List<BasketId> basketIdsToDelete)
            throws SugarTechnicalException {
        XPathQuery expression = getDataSource().getExpressionFactory().createBasketGetQuery(scope, basketIdsToDelete);
        int total = getDataSource().deleteEntries(connection, expression, Basket.class);
        if (total != basketIdsToDelete.size()) {
            throw new SugarTechnicalException("Could not delete all ids : " + basketIdsToDelete + " : asked="
                    + basketIdsToDelete.size() + ", deleted=" + total);
        }
    }

    @Override
    public void delete(List<BasketId> basketsIdToDelete, String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doDelete(scope, connection, basketsIdToDelete);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

}
