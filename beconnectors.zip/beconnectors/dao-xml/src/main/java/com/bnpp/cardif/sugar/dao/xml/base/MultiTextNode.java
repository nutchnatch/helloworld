package com.bnpp.cardif.sugar.dao.xml.base;

public interface MultiTextNode {
    void add(String contents);

    Object asXPathVariable();
}
