package com.bnpp.cardif.sugar.dao.xml.simpledom;

import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;

public class DomXmlConnection implements XmlConnection {
    private final org.w3c.dom.Document document;

    public DomXmlConnection(org.w3c.dom.Document document) {
        this.document = document;
    }

    public org.w3c.dom.Document getDocument() {
        return document;
    }
}
