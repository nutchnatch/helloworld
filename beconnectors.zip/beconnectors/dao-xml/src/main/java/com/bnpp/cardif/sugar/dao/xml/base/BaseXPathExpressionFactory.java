package com.bnpp.cardif.sugar.dao.xml.base;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.acl.AclDAO.AclContext;
import com.bnpp.cardif.sugar.dao.xml.api.ExpressionFactory;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery.Context;
import com.bnpp.cardif.sugar.dao.xml.util.CriteriaXPathHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TaskStatus;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

public abstract class BaseXPathExpressionFactory implements ExpressionFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(BaseXPathExpressionFactory.class);

    private boolean useNodeSetForMultipleCriteria = false;

    private final CriteriaXPathHelper criteriaXPathHelper = new CriteriaXPathHelper();

    public static interface ItemSerializer<T> {
        String asString(T t);
    }

    protected ItemSerializer<Id> idSerializer = new ItemSerializer<Id>() {
        @Override
        public String asString(Id t) {
            return t.getValue();
        }
    };

    protected ItemSerializer<FolderId> folderSerializer = new ItemSerializer<FolderId>() {
        @Override
        public String asString(FolderId t) {
            return t.getValue();
        }
    };

    protected final ItemSerializer<ClassId> classIdSerializer = new ItemSerializer<ClassId>() {
        @Override
        public String asString(ClassId t) {
            return t.getValue();
        }
    };

    protected final ItemSerializer<String> stringSerializer = new ItemSerializer<String>() {
        @Override
        public String asString(String t) {
            return t;
        }
    };

    protected final ItemSerializer<URI> uriSerializer = new ItemSerializer<URI>() {
        @Override
        public String asString(URI t) {
            return t.getValue();
        }
    };

    protected abstract XPathQuery createXPathQuery(String xpath, XPathQuery.Context context);

    protected abstract MultiTextNode createTextNodeList();

    protected XPathQuery.Context createContext() {
        return new XPathQuery.Context() {
            private Map<String, Object> map = new HashMap<>();

            @Override
            public XPathQuery.Context put(String name, Object value) {
                map.put(name, value);
                return this;
            }

            @Override
            public Collection<String> getVariables() {
                return map.keySet();
            }

            @Override
            public Object getVariable(String name) {
                return map.get(name);
            }

            @Override
            public Map<String, Object> asMap() {
                return map;
            }
        };
    }

    protected <T> String addXPathMultipleCriteria(XPathQuery.Context context, String predicatePrefix,
            String argumentPrefix, Collection<T> elements, ItemSerializer<T> serializer) {
        return addXPathMultipleCriteria(context, predicatePrefix, argumentPrefix, "", elements, serializer);
    }

    protected <T> String addXPathMultipleCriteria(XPathQuery.Context context, String predicatePrefix,
            String argumentPrefix, String predicateSuffix, Collection<T> elements, ItemSerializer<T> serializer) {
        if (useNodeSetForMultipleCriteria) {
            MultiTextNode textNodeList = createTextNodeList();
            for (T elt : elements) {
                textNodeList.add(serializer.asString(elt));
            }
            context.put(argumentPrefix, textNodeList.asXPathVariable());
            String xpath = predicatePrefix + "$" + argumentPrefix + "/text-node/text()" + predicateSuffix;
            return xpath;
        }
        else {
            String xpath = "";
            boolean first = true;
            int idNumber = 0;
            for (T elt : elements) {
                if (first) {
                    first = false;
                }
                else {
                    xpath += " or ";
                }
                xpath += "(" + predicatePrefix + "$" + argumentPrefix + idNumber + ")";
                context.put(argumentPrefix + idNumber, serializer.asString(elt));
                idNumber++;
            }
            return xpath;
        }
    }

    @Override
    public <T> XPathQuery createCollectionQuery(Class<T> clazz) {
        String xpath = "/colldb:collections/colldb:collection[@name=$collectionName]";
        String collectionName = clazz.getSimpleName().toLowerCase();
        return createXPathQuery(xpath, createContext().put("collectionName", collectionName.toLowerCase()));
    }

    @Override
    public XPathQuery createBusinessScopeGetAllQuery() {
        String xpath = "businessscope:BusinessScope";
        return createXPathQuery(xpath, createContext());
    }

    @Override
    public XPathQuery createBusinessScopeGetBySymbolicNameQuery(List<String> symbolicNames) {
        String xpath = "businessscope:BusinessScope";
        XPathQuery.Context context = createContext();
        xpath += "[";
        xpath += addXPathMultipleCriteria(context, "@SymbolicName=", "symbolicName", symbolicNames, stringSerializer);
        xpath += "]";
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetDocumentQuery(List<Id> ids, String scope) {
        XPathQuery.Context context = createContext();
        String xpath = "doc:Document";
        xpath += "[";
        xpath += addXPathMultipleCriteria(context, "doc:Id/text()=", "ids", ids, idSerializer);
        xpath += "]";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetDocumentQuery(List<String> ids) {
        XPathQuery.Context context = createContext();
        String xpath = "doc:Document";
        xpath += "[";
        for (int i = 0; i < ids.size(); i++) {
            if (i != 0) {
                xpath += " or ";
            }
            xpath += "(doc:Id/text()=$idsValue" + i + ")";
            context.put("idsValue" + i, ids.get(i));
        }
        xpath += "]";
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetAllDocumentsByScopeQuery(String scope) {
        XPathQuery.Context context = createContext();

        String xpath = "doc:Document";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createFolderGetQuery(String scope, List<FolderId> ids) {
        XPathQuery.Context context = createContext();
        String xpath = "folder:Folder";
        xpath += "[";
        for (int i = 0; i < ids.size(); i++) {
            if (i != 0) {
                xpath += " or ";
            }
            xpath += "(folder:FolderId/text()=$idsValue" + i + ") and (folder:FolderId[@Issuer=$idsIssuer" + i
                    + "]) and (folder:FolderId[@Scheme=$idsScheme" + i + "])";
            context.put("idsValue" + i, ids.get(i).getValue());
            context.put("idsIssuer" + i, ids.get(i).getIssuer());
            context.put("idsScheme" + i, ids.get(i).getScheme());
        }
        xpath += "]";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetTasksForDocQuerry(String scope, List<TaskId> ids) {
        XPathQuery.Context context = createContext();
        String xpath = "task:Task";
        xpath += "[";
        for (int i = 0; i < ids.size(); i++) {
            if (i != 0) {
                xpath += " or ";
            }
            xpath += "(task:TaskId/text()=$idsValue" + i + ") and (task:TaskId[@Issuer=$idsIssuer" + i
                    + "]) and (task:TaskId[@Scheme=$idsScheme" + i + "])";
            context.put("idsValue" + i, ids.get(i).getValue());
            context.put("idsIssuer" + i, ids.get(i).getIssuer());
            context.put("idsScheme" + i, ids.get(i).getScheme());
        }
        xpath += "]";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetTasksInBasketQuery(String scope, BasketId basketId) {
        String xpathBase = "task:Task";
        String xpath = xpathBase + "[(basket:BasketId/text()='" + basketId.getValue()
                + "') and (basket:BasketId[@Issuer='" + basketId.getIssuer() + "']) and (basket:BasketId[@Scheme='"
                + basketId.getScheme() + "']) and (task:Status/text()!='" + TaskStatus.CLOSE + "')]";
        Context context = createContext();

        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetTasksForDocQuerry(String scope, Id docId) {
        String xpathBase = "task:Task";
        String xpath = xpathBase + "[(task:DocID/doc:Id/text()='" + docId.getValue()
                + "') and (task:DocID/doc:Id[@Issuer='" + docId.getIssuer() + "']) and (task:DocID/doc:Id[@Scheme='"
                + docId.getScheme() + "']) and (task:Status/text()!='" + TaskStatus.CLOSE + "')]";
        Context context = createContext();

        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createBasketGetQuery(String scope, List<BasketId> ids) {
        XPathQuery.Context context = createContext();
        String xpath = "basket:Basket";
        xpath += "[";
        for (int i = 0; i < ids.size(); i++) {
            if (i != 0) {
                xpath += " or ";
            }
            xpath += "(basket:BasketId/text()=$idsValue" + i + ") and (basket:BasketId[@Issuer=$idsIssuer" + i
                    + "]) and (basket:BasketId[@Scheme=$idsScheme" + i + "])";
            context.put("idsValue" + i, ids.get(i).getValue());
            context.put("idsIssuer" + i, ids.get(i).getIssuer());
            context.put("idsScheme" + i, ids.get(i).getScheme());
        }
        xpath += "]";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createBasketGetAllQuery(String scope) {
        XPathQuery.Context context = createContext();
        String xpath = "basket:Basket";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createFactGetAllQuery(String scope) {
        XPathQuery.Context context = createContext();
        String xpath = "fact:Fact";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createFolderGetBySymbolicNameQuery(String scope, List<String> symbolicNames) {
        String xpath = "folder:Folder";
        XPathQuery.Context context = createContext();
        xpath += "[";
        xpath += addXPathMultipleCriteria(context, "folder:Data/common:Name/text()=", "symbolicName", symbolicNames,
                stringSerializer);
        xpath += "]";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetAllFoldersByScopeQuery(String scope) {
        XPathQuery.Context context = createContext();
        String xpath = "folder:Folder";
        xpath += "[@Scope=$scope]";
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createFolderSearchQuery(String scope, Criteria criteria, OrderClause order) {
        String xpathBase = "folder:Folder";
        String xpath = xpathBase + "[@Scope=$scope]" + criteriaXPathHelper.buildCriteria(criteria);
        Context context = createContext();
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createDocumentQuery(String scope, Criteria criteria, OrderClause order) {
        String xpathBase = "//doc:Document";
        String xpath = xpathBase + "[@Scope=$scope]";
        xpath += "[doc:Status/common:Code/text() !='" + DocumentStatusCode.DELETED.toString() + "']";
        xpath += criteriaXPathHelper.buildCriteria(criteria);
        Context context = createContext();
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createAclQuery(AclId id) {
        String xpath = "acl:AccessControlList[acl:AclId/text()=$id]";
        return createXPathQuery(xpath, createContext().put("id", id.getValue()));
    }

    @Override
    public XPathQuery createAclGetAllQuery(String scope) {
        String xpath = "acl:AccessControlList[@Scope=$scope]";
        return createXPathQuery(xpath, createContext().put("scope", scope));
    }

    @Override
    public XPathQuery createAclMappingQuery(AclContext aclContext, String objectId) {
        LOGGER.info("Searching ACL target: " + objectId + " on context " + aclContext);
        String xpath = "acl:AclMapping[acl:Context/text()=$aclContext]" + "[acl:Target/text()=$target]";
        return createXPathQuery(xpath, createContext().put("aclContext", aclContext.name()).put("target", objectId));
    }

    @Override
    public XPathQuery createDocumentClassSearchQuery(String scope, Category category, Boolean isActiveOnly) {
        XPathQuery.Context context = createContext();
        String xpath = "docclass:DocumentClass[docclass:Scope/text()=$scope]";
        context.put("scope", scope);
        if (category != null) {
            xpath += "[docclass:Category/text()=$category]";
            context.put("category", category.name());
        }
        if (isActiveOnly) {
            xpath += "[docclass:Active/text()='true']";
        }
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createDocumentClassQuery(String scope, List<ClassId> classIds) {
        LOGGER.info("Creating xpathQuery to find classids " + classIds);
        XPathQuery.Context context = createContext();
        String xpath = "docclass:DocumentClass[docclass:Scope/text()=$scope]";
        context.put("scope", scope);
        StringBuilder xpathClassId = new StringBuilder();
        xpathClassId.append("[");
        for (int i = 0; i < classIds.size(); i++) {
            if (i != 0) {
                xpathClassId.append(" or ");
            }
            xpathClassId.append("(common:ClassId/text()='" + classIds.get(i).getValue()
                    + "') and  (common:ClassId[@VersId='" + classIds.get(i).getVersId()
                    + "']) and (common:ClassId[@Issuer='" + classIds.get(i).getIssuer() + "']) ");
        }

        xpathClassId.append("]");
        xpath += xpathClassId.toString();
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createFolderClassQuery(String scope, List<ClassId> classIds) {
        XPathQuery.Context context = createContext();
        String xpath = "folderclass:FolderClass[@Scope=$scope]";
        context.put("scope", scope);
        xpath += "[";
        for (int i = 0; i < classIds.size(); i++) {
            if (i != 0) {
                xpath += " or ";
            }
            xpath += "(common:ClassId/text()=$idsValue" + i + ") and (common:ClassId[@Issuer=$idsIssuer" + i
                    + "]) and (common:ClassId[@VersId=$idsVersId" + i + "])";
            context.put("idsValue" + i, classIds.get(i).getValue());
            context.put("idsIssuer" + i, classIds.get(i).getIssuer());
            context.put("idsVersId" + i, classIds.get(i).getVersId());
        }

        xpath += "]";
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createFolderClassGetAllQuery(String scope, Boolean isActiveOnly) {
        XPathQuery.Context context = createContext();
        String xpath = "folderclass:FolderClass";
        xpath += "[@Scope=$scope]";
        if (isActiveOnly) {
            xpath += "[folderclass:active/text()='" + isActiveOnly + "']";
        }
        context.put("scope", scope);
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createFolderClassGetAllVersionsQuery(String scope, List<ClassId> classIds) {
        XPathQuery.Context context = createContext();
        String xpath = "folderclass:FolderClass[@Scope=$scope]";
        context.put("scope", scope);
        xpath += "[";
        for (int i = 0; i < classIds.size(); i++) {
            if (i != 0) {
                xpath += " or ";
            }
            xpath += "(common:ClassId/text()=$idsValue" + i + ") and (common:ClassId[@Issuer=$idsIssuer" + i + "])";
            context.put("idsValue" + i, classIds.get(i).getValue());
            context.put("idsIssuer" + i, classIds.get(i).getIssuer());
        }
        xpath += "]";
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createDocumentClassGetAllVersionsQuery(String scope, List<ClassId> classIds) {
        XPathQuery.Context context = createContext();
        String xpath = "docclass:DocumentClass[docclass:Scope/text()=$scope]";
        context.put("scope", scope);
        xpath += "[";
        for (int i = 0; i < classIds.size(); i++) {
            if (i != 0) {
                xpath += " or ";
            }
            xpath += "(common:ClassId/text()=$idsValue" + i + ") and (common:ClassId[@Issuer=$idsIssuer" + i + "])";
            context.put("idsValue" + i, classIds.get(i).getValue());
            context.put("idsIssuer" + i, classIds.get(i).getIssuer());
        }
        xpath += "]";
        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createTagSearchQuery(String scope) {
        String xpath = "tagclass:TagClass[tagclass:Scope/text()=$scope]";
        return createXPathQuery(xpath, createContext().put("scope", scope));
    }

    @Override
    public XPathQuery createTagSearchQuery(String scope, List<ClassId> tagIds) {
        String xpath = "tagclass:TagClass[tagclass:Scope/text()=$scope]";
        XPathQuery.Context context = createContext().put("scope", scope);

        xpath += "[";
        xpath += addXPathMultipleCriteria(context, "common:ClassId/text()=", "id", tagIds, classIdSerializer);
        xpath += "]";

        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createTagSearchBySymbolicNameQuery(String scope, List<String> symbolicNames) {
        String xpath = "tagclass:TagClass[tagclass:Scope/text()=$scope]";
        XPathQuery.Context context = createContext().put("scope", scope);

        xpath += "[";
        xpath += addXPathMultipleCriteria(context, "@SymbolicName=", "symbolicName", symbolicNames, stringSerializer);
        xpath += "]";

        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetDocumentFileQuery(String scope, List<URI> uris) {
        String xpath = "file:DocumentFile[@Scope=$scope]";
        XPathQuery.Context context = createContext().put("scope", scope);

        xpath += "[";
        xpath += addXPathMultipleCriteria(context, "common:URI/text()=", "symbolicName", uris, uriSerializer);
        xpath += "]";

        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetDocumentFileQuery(List<URI> uris) {
        String xpath = "file:DocumentFile";
        XPathQuery.Context context = createContext();

        xpath += "[";
        xpath += addXPathMultipleCriteria(context, "common:URI/text()=", "symbolicName", uris, uriSerializer);
        xpath += "]";

        return createXPathQuery(xpath, context);
    }

    @Override
    public XPathQuery createGetAllDocumentFileQuery() {
        String xpath = "file:DocumentFile";
        XPathQuery.Context context = createContext();
        return createXPathQuery(xpath, context);
    }

}
