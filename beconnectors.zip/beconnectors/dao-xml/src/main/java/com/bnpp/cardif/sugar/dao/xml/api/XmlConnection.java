package com.bnpp.cardif.sugar.dao.xml.api;

public interface XmlConnection {
}
