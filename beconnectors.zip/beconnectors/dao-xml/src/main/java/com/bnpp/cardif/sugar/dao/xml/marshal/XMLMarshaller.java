package com.bnpp.cardif.sugar.dao.xml.marshal;

public interface XMLMarshaller<TYPE> {
    void marshal(TYPE object, org.w3c.dom.Node baseNode);

    TYPE unmarshal(org.w3c.dom.Node baseNode);
}
