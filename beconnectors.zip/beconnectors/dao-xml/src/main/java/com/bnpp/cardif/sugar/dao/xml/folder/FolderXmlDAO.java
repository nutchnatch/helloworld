package com.bnpp.cardif.sugar.dao.xml.folder;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.folder.FolderDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.google.common.collect.Lists;

public class FolderXmlDAO implements FolderDAO {
    private static final Logger LOGGER = LoggerFactory.getLogger(FolderXmlDAO.class);

    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public void add(List<Folder> foldersToAdd) throws SugarTechnicalException, SugarFunctionalException {
        long startStore = System.currentTimeMillis();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);

        try {
            doStore(connection, foldersToAdd);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
        long endStore = System.currentTimeMillis();
        LOGGER.info("[FolderXMLDAO.store() : Total store for " + foldersToAdd.size() + " : " + (endStore - startStore)
                + "ms");

    }

    private void doStore(XmlConnection connection, List<Folder> foldersToStore) throws SugarTechnicalException {
        getDataSource().addEntries(connection, foldersToStore);
    }

    @Override
    public List<Folder> update(List<Folder> foldersToUpdate, String scope) throws SugarTechnicalException {
        List<FolderId> idsToDelete = new ArrayList<>();
        for (Folder folderToUpdate : foldersToUpdate) {
            idsToDelete.add(folderToUpdate.getFolderId());
        }
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doDelete(scope, connection, idsToDelete);
            doStore(connection, foldersToUpdate);
            return foldersToUpdate;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private void doDelete(String scope, XmlConnection connection, List<FolderId> folderIdsToDelete)
            throws SugarTechnicalException {
        XPathQuery expression = getDataSource().getExpressionFactory().createFolderGetQuery(scope, folderIdsToDelete);
        int total = getDataSource().deleteEntries(connection, expression, Folder.class);
        if (total != folderIdsToDelete.size()) {
            throw new SugarTechnicalException("Could not delete all ids : " + folderIdsToDelete + " : asked="
                    + folderIdsToDelete.size() + ", deleted=" + total);
        }
    }

    @Override
    public List<Folder> get(List<FolderId> idsOfFolderToGet, String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createFolderGetQuery(scope,
                    idsOfFolderToGet);
            List<Folder> results = getDataSource().getEntries(connection, expression, Folder.class);
            return results;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public SearchResults<Folder> find(String scope, Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createFolderSearchQuery(scope,
                    criteria, order);
            return getDataSource().getEntriesPartial(connection, searchExpression, Folder.class, start, max);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public Folder getBySymbolicName(String scope, String symbolicName) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createFolderGetBySymbolicNameQuery(scope,
                    Lists.newArrayList(symbolicName));
            List<Folder> results = getDataSource().getEntries(connection, expression, Folder.class);
            if (results != null && results.size() > 0) {
                return results.get(0);
            }
            return null;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public List<FolderId> fetchIdsByScope(String scope) throws SugarTechnicalException {
        List<FolderId> fetchedIds = new ArrayList<>();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            LOGGER.debug("Fetching all documents Ids for business scope {}", scope);
            XPathQuery expression = getDataSource().getExpressionFactory().createGetAllFoldersByScopeQuery(scope);
            List<Folder> results = getDataSource().getEntries(connection, expression, Folder.class);
            LOGGER.info("Found a list of {} documents ", results.size());
            for (Folder folder : results) {
                fetchedIds.add(folder.getFolderId());
            }
            return fetchedIds;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }
}
