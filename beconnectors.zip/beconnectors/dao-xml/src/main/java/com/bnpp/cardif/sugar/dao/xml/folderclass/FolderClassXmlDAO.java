package com.bnpp.cardif.sugar.dao.xml.folderclass;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.folderclass.FolderClassDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;

public class FolderClassXmlDAO implements FolderClassDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(FolderClassXmlDAO.class);

    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public void add(List<FolderClass> folderClassesToAdd) throws SugarTechnicalException, SugarFunctionalException {
        if (folderClassesToAdd.isEmpty()) {
            return;
        }
        String scope = folderClassesToAdd.get(0).getScope();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<ClassId> classIds = extractClassIds(folderClassesToAdd);
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createFolderClassQuery(scope,
                    classIds);
            if (getDataSource().countEntries(connection, searchExpression, FolderClass.class) != 0) {
                throw new SugarTechnicalException("At least one of the classes already exist : " + classIds);
            }
            doStore(connection, folderClassesToAdd);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    private void doStore(XmlConnection connection, List<FolderClass> classes) {
        getDataSource().addEntries(connection, classes);
    }

    private List<ClassId> extractClassIds(List<FolderClass> classes) {
        List<ClassId> classIds = new ArrayList<>();
        for (FolderClass folderClass : classes) {
            classIds.add(folderClass.getClassId());
        }
        return classIds;
    }

    @Override
    public void update(List<FolderClass> folderClassesToUpdate) throws SugarTechnicalException {
        if (folderClassesToUpdate.isEmpty()) {
            return;
        }
        String scope = folderClassesToUpdate.get(0).getScope();
        List<ClassId> classIds = extractClassIds(folderClassesToUpdate);
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doRemove(connection, scope, classIds);
            doStore(connection, folderClassesToUpdate);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    private void doRemove(XmlConnection connection, String scope, List<ClassId> classId)
            throws SugarTechnicalException {
        XPathQuery searchExpression = getDataSource().getExpressionFactory().createFolderClassQuery(scope, classId);
        int result = getDataSource().deleteEntries(connection, searchExpression, FolderClass.class);
        if (result != classId.size()) {
            throw new SugarTechnicalException(
                    "Could not delete entries ! deleted=" + result + ", but to delete=" + classId.size());
        }
    }

    @Override
    public List<FolderClass> get(List<ClassId> idsOfFolderclassesToGet, String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            return doGet(connection, scope, idsOfFolderclassesToGet);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private List<FolderClass> doGet(XmlConnection connection, String scope, List<ClassId> classId) {
        XPathQuery searchExpression = getDataSource().getExpressionFactory().createFolderClassQuery(scope, classId);
        return getDataSource().getEntries(connection, searchExpression, FolderClass.class);
    }

    @Override
    public List<FolderClass> getAll(String scope, Boolean isActiveOnly)
            throws SugarTechnicalException, SugarFunctionalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createFolderClassGetAllQuery(scope,
                    isActiveOnly);
            return getDataSource().getEntries(connection, searchExpression, FolderClass.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void setActive(List<ClassId> folderClassIds, Boolean active, String scope, Date updateDate)
            throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<FolderClass> classes = doGet(connection, scope, folderClassIds);
            doRemove(connection, scope, folderClassIds);
            for (FolderClass folderClass : classes) {
                folderClass.setActive(active);
            }
            doStore(connection, classes);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public List<FolderClass> getAllVersions(List<ClassId> ids, String scope) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory()
                    .createFolderClassGetAllVersionsQuery(scope, ids);
            return getDataSource().getEntries(connection, searchExpression, FolderClass.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

}
