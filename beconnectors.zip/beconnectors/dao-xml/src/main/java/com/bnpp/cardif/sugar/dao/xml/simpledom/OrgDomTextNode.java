package com.bnpp.cardif.sugar.dao.xml.simpledom;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.bnpp.cardif.sugar.dao.xml.base.MultiTextNode;

public class OrgDomTextNode implements MultiTextNode {
    private final Document textDocument;

    private final Element rootElement;

    public OrgDomTextNode() {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder loader = factory.newDocumentBuilder();
            textDocument = loader.newDocument();
            rootElement = textDocument.createElement("node-list");
            textDocument.appendChild(rootElement);
        }
        catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void add(String stringContents) {
        Text textNode = textDocument.createTextNode(stringContents);
        Element textNodeElement = textDocument.createElement("text-node");
        textNodeElement.appendChild(textNode);
        rootElement.appendChild(textNodeElement);
    }

    @Override
    public Object asXPathVariable() {
        return new NodeList() {

            @Override
            public Node item(int arg0) {
                return textDocument.getDocumentElement();
            }

            @Override
            public int getLength() {
                return 1;
            }
        };
    }

}
