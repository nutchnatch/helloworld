package com.bnpp.cardif.sugar.dao.xml.document;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnpp.cardif.sugar.dao.api.businessscope.BusinessScopeDAO;
import com.bnpp.cardif.sugar.dao.api.document.DocumentDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.google.common.collect.Lists;

public class DocumentXmlDAO implements DocumentDAO {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentXmlDAO.class);

    private XmlDatasource dataSource;

    @Autowired
    private BusinessScopeDAO scopeDAO;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public void store(List<Document> documentsToStore) throws SugarTechnicalException {
        long startStore = System.currentTimeMillis();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);

        try {
            doStore(connection, documentsToStore);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
        long endStore = System.currentTimeMillis();
        LOGGER.info("[DocumentXMLDAO.store() : Total store for " + documentsToStore.size() + " : "
                + (endStore - startStore) + "ms");
    }

    private void doStore(XmlConnection connection, List<Document> documentsToStore) throws SugarTechnicalException {
        getDataSource().addEntries(connection, documentsToStore);
    }

    @Override
    public SearchResults<Document> find(String scope, Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createDocumentQuery(scope, criteria,
                    order);
            if (max == 0) {
                max = 100;
            }
            return getDataSource().getEntriesPartial(connection, searchExpression, Document.class, start, max);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public List<Document> fetch(String scope, List<Id> ids) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            LOGGER.debug("Fetching a list of {} documents ", ids.size());
            XPathQuery expression = getDataSource().getExpressionFactory().createGetDocumentQuery(ids, scope);
            List<Document> results = getDataSource().getEntries(connection, expression, Document.class);
            LOGGER.info("Found a list of {} documents ", results.size());
            if (results.size() != ids.size()) {
                throw new SugarTechnicalException("Could not get some documents with id=" + ids);
            }
            return results;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public List<Id> fetchIdsByScope(String scope) throws SugarTechnicalException {

        List<Id> fetchedIds = new ArrayList<>();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            LOGGER.debug("Fetching all documents Ids for business scope {}", scope);
            XPathQuery expression = getDataSource().getExpressionFactory().createGetAllDocumentsByScopeQuery(scope);
            List<Document> results = getDataSource().getEntries(connection, expression, Document.class);
            LOGGER.info("Found a list of {} documents ", results.size());
            for (Document document : results) {
                fetchedIds.add(document.getId());
            }
            return fetchedIds;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void delete(String scope, List<Id> docIdsToDelete) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doDelete(scope, connection, docIdsToDelete);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private void doDelete(String scope, XmlConnection connection, List<Id> docIdsToDelete)
            throws SugarTechnicalException {
        XPathQuery expression = getDataSource().getExpressionFactory().createGetDocumentQuery(docIdsToDelete, scope);
        int total = getDataSource().deleteEntries(connection, expression, Document.class);

        if (total != docIdsToDelete.size()) {
            throw new SugarTechnicalException("Could not delete all ids : " + docIdsToDelete + " : asked="
                    + docIdsToDelete.size() + ", deleted=" + total);
        }
    }

    @Override
    public List<Document> update(List<Document> documentsToUpdate) throws SugarTechnicalException {
        String scope = documentsToUpdate.get(0).getScope();
        List<Id> idsToDelete = new ArrayList<>();
        for (Document doc : documentsToUpdate) {
            idsToDelete.add(doc.getId());
        }
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doDelete(scope, connection, idsToDelete);
            doStore(connection, documentsToUpdate);
            return documentsToUpdate;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void deleteAll(List<String> ids) throws SugarTechnicalException {

        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            XPathQuery expression = getDataSource().getExpressionFactory().createGetDocumentQuery(ids);
            int total = getDataSource().deleteEntries(connection, expression, Document.class);

            if (total != ids.size()) {
                throw new SugarTechnicalException(
                        "Could not delete all ids : " + ids + " : asked=" + ids.size() + ", deleted=" + total);
            }
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    @Override
    public List<String> getUnlinkedDocument() throws SugarTechnicalException {
        List<BusinessScope> scopes = scopeDAO.getAll();
        List<Document> allDocuments = getAllComponents(scopes, Item.DOCUMENT);
        List<Document> allEnvelopes = getAllComponents(scopes, Item.ENVELOPE);
        List<Id> existingEnvelopes = new ArrayList<>();
        for (Document envelope : allEnvelopes) {
            existingEnvelopes.add(envelope.getId());
        }
        List<String> unlinkedDocuments = new ArrayList<>();
        for (Document document : allDocuments) {
            if (!document.isSetParentId() || !existingEnvelopes.contains(document.getParentId().getId())) {
                unlinkedDocuments.add(document.getId().getValue());
            }
        }
        return unlinkedDocuments;

    }

    @Override
    public List<String> getUnlinkedEnveloppe() throws SugarTechnicalException {
        List<BusinessScope> scopes = scopeDAO.getAll();
        List<Document> allDocuments = getAllComponents(scopes, Item.DOCUMENT);
        List<Document> allEnvelopes = getAllComponents(scopes, Item.ENVELOPE);
        List<Id> existingDocuments = new ArrayList<>();
        for (Document document : allDocuments) {
            existingDocuments.add(document.getId());
        }
        List<String> unlinkedDocuments = new ArrayList<>();
        for (Document envlope : allEnvelopes) {
            if (!envlope.isSetChildObject()) {
                unlinkedDocuments.add(envlope.getId().getValue());
            }
            else {
                List<Id> childIds = Lists.newArrayList(envlope.getChildObject().getId());
                for (Document child : envlope.getChildObject().getDocument()) {
                    childIds.add(child.getId());
                }
                if (childIds.size() < 1 || !existingDocuments.containsAll(childIds)) {
                    unlinkedDocuments.add(envlope.getId().getValue());
                }
            }
        }
        return unlinkedDocuments;
    }

    private List<Document> getAllComponents(List<BusinessScope> scopes, Item componentCategory)
            throws SugarTechnicalException {
        Criteria criteria = new Criteria();
        criteria.setItem(componentCategory);
        List<Document> allDocuments = new ArrayList<>();

        for (BusinessScope scope : scopes) {
            allDocuments.addAll(find(scope.getSymbolicName(), criteria, null, 0, Long.MAX_VALUE).getObjects());
        }
        return allDocuments;
    }
}
