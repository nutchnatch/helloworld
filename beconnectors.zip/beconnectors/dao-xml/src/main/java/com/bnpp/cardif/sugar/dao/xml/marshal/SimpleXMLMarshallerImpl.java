package com.bnpp.cardif.sugar.dao.xml.marshal;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;

import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

public class SimpleXMLMarshallerImpl<TYPE> implements XMLMarshaller<TYPE> {

    private Marshaller marshaller;

    private Unmarshaller unmarshaller;

    private static final Logger LOGGER = LoggerFactory.getLogger(SimpleXMLMarshallerImpl.class);

    public SimpleXMLMarshallerImpl(Class<TYPE> clazz, NamespacePrefixMapper nameSpacePrefixMapper) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
            marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", nameSpacePrefixMapper);

            unmarshaller = jaxbContext.createUnmarshaller();
        }
        catch (JAXBException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void marshal(TYPE object, Node baseNode) {
        try {
            marshaller.marshal(object, baseNode);
        }
        catch (JAXBException e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public TYPE unmarshal(Node baseNode) {
        try {
            return (TYPE) unmarshaller.unmarshal(baseNode);
        }
        catch (JAXBException e) {
            throw new RuntimeException(e);
        }
    }
}
