package com.bnpp.cardif.sugar.dao.xml.documentclass;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.documentclass.DocumentClassDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

public class DocumentClassXmlDAO implements DocumentClassDAO {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentClassXmlDAO.class);

    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public void store(List<DocumentClass> classes) throws SugarTechnicalException {
        if (classes.isEmpty()) {
            return;
        }
        String scope = classes.get(0).getScope();
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<ClassId> classIds = extractClassIds(classes);
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createDocumentClassQuery(scope,
                    classIds);
            if (getDataSource().countEntries(connection, searchExpression, DocumentClass.class) != 0) {
                throw new SugarTechnicalException("At least one of the classes already exist : " + classIds);
            }
            doStore(connection, classes);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private void doStore(XmlConnection connection, List<DocumentClass> classes) {
        getDataSource().addEntries(connection, classes);
    }

    @Override
    public List<DocumentClass> search(String scope, Category category, Boolean isActiveOnly)
            throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createDocumentClassSearchQuery(scope,
                    category, isActiveOnly);
            List<DocumentClass> result = getDataSource().getEntries(connection, searchExpression, DocumentClass.class);

            /*
             * Here we trim down, manually, all last versions of each class.
             * There is no clean way to do this using XPath
             */
            Map<ClassId, DocumentClass> lastVersions = new HashMap<>();

            for (DocumentClass clazz : result) {
                ClassId seriesId = new ClassId(clazz.getClassId().getValue(), clazz.getClassId().getIssuer(), 0);
                DocumentClass seriesClass = lastVersions.get(seriesId);
                if (seriesClass == null || seriesClass.getClassId().getVersId() < clazz.getClassId().getVersId()) {
                    lastVersions.put(seriesId, clazz);
                }
            }
            List<DocumentClass> finalResult = new ArrayList<>();
            finalResult.addAll(lastVersions.values());
            LOGGER.debug(finalResult.size() + " have been fetched");
            return finalResult;
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void update(List<DocumentClass> classes) throws SugarTechnicalException {
        if (classes.isEmpty()) {
            return;
        }
        String scope = classes.get(0).getScope();
        List<ClassId> classIds = extractClassIds(classes);
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doRemove(connection, scope, classIds);
            doStore(connection, classes);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    private List<ClassId> extractClassIds(List<DocumentClass> classes) {
        List<ClassId> classIds = new ArrayList<>();
        for (DocumentClass documentClass : classes) {
            classIds.add(documentClass.getClassId());
        }
        return classIds;
    }

    @Override
    public List<DocumentClass> get(String scope, List<ClassId> classId) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            LOGGER.debug("Trying to get " + classId.size() + " document classes");
            return doGet(connection, scope, classId);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private List<DocumentClass> doGet(XmlConnection connection, String scope, List<ClassId> classId) {
        XPathQuery searchExpression = getDataSource().getExpressionFactory().createDocumentClassQuery(scope, classId);
        return getDataSource().getEntries(connection, searchExpression, DocumentClass.class);
    }

    @Override
    public void setActive(String scope, List<ClassId> classId, boolean activate) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            List<DocumentClass> classes = doGet(connection, scope, classId);
            doRemove(connection, scope, classId);
            for (DocumentClass documentClass : classes) {
                documentClass.setActive(activate);
            }
            doStore(connection, classes);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void remove(String scope, List<ClassId> classId) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doRemove(connection, scope, classId);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private void doRemove(XmlConnection connection, String scope, List<ClassId> classId)
            throws SugarTechnicalException {
        XPathQuery searchExpression = getDataSource().getExpressionFactory().createDocumentClassQuery(scope, classId);
        int result = getDataSource().deleteEntries(connection, searchExpression, DocumentClass.class);
        if (result != classId.size()) {
            throw new SugarTechnicalException(
                    "Could not delete entries ! deleted=" + result + ", but to delete=" + classId.size());
        }
    }

    @Override
    public List<DocumentClass> getAllVersions(String scope, List<ClassId> ids) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory()
                    .createDocumentClassGetAllVersionsQuery(scope, ids);
            return getDataSource().getEntries(connection, searchExpression, DocumentClass.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

}
