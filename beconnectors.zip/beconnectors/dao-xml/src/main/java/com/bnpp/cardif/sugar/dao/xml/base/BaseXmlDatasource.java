package com.bnpp.cardif.sugar.dao.xml.base;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.xpath.XPathException;
import org.xml.sax.InputSource;

import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.dao.xml.marshal.XMLMarshaller;
import com.bnpp.cardif.sugar.dao.xml.marshal.XMLMarshallerFactory;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.google.common.collect.Lists;

public abstract class BaseXmlDatasource implements XmlDatasource {
    private static final Logger LOGGER = LoggerFactory.getLogger(BaseXmlDatasource.class);

    private boolean showTimings = true;

    @Autowired
    private XMLMarshallerFactory marshallerFactory;

    private String dumpAllContentsPath = null;

    public String getDumpAllContentsPath() {
        return dumpAllContentsPath;
    }

    public void setDumpAllContentsPath(String dumpAllContentsPath) {
        this.dumpAllContentsPath = dumpAllContentsPath;
    }

    protected void dumpAllContent(XmlConnection xmlConnection) {
        try {
            DOMSource domSource = new DOMSource(getDocumentElement(xmlConnection));
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            Writer writer = null;
            if (dumpAllContentsPath != null) {
                writer = new FileWriter(dumpAllContentsPath);
            }
            else {
                writer = new StringWriter();
            }
            StreamResult sr = new StreamResult(writer);

            transformer.transform(domSource, sr);
            LOGGER.debug("Content : " + writer.toString());
        }
        catch (TransformerException e) {
            LOGGER.error("Could not dump content to " + dumpAllContentsPath, e);
        }
        catch (IOException e) {
            LOGGER.error("Could not dump content to " + dumpAllContentsPath, e);
        }
    }

    protected void notifyNewElement(org.w3c.dom.Element element) {

    }

    protected abstract Node getDocumentElement(XmlConnection connection);

    private Element evalToElement(XPathQuery xpathQuery, Node contextNode) {
        LOGGER.debug("Eval to element : expression=" + xpathQuery + ", contextNode=" + contextNode);
        NodeList xpathResult = xpathQuery.evaluate(contextNode);
        if (xpathResult.getLength() != 1) {
            return null;
        }
        Element resultElement = (Element) xpathResult.item(0);
        return resultElement;
    }

    private Element getCollectionElement(XmlConnection connection, Class<?> clazz) {
        XPathQuery xpathQuery = getExpressionFactory().createCollectionQuery(clazz);
        Element collectionElement = evalToElement(xpathQuery, getDocumentElement(connection));
        if (collectionElement == null) {
            throw new RuntimeException("Could not get collection root for class : " + clazz.getName());
        }
        LOGGER.debug("Collection element = " + collectionElement.getNodeName());
        return collectionElement;
    }

    protected <T> void addEntries(XmlConnection connection, Collection<T> elements, Class<T> clazz) {
        XMLMarshaller<T> marshaller = marshallerFactory.getMarshaller(clazz);

        Element collectionElement = getCollectionElement(connection, clazz);

        long startMarshal = System.currentTimeMillis();

        for (T elementToStore : elements) {

            marshaller.marshal(elementToStore, collectionElement);

            Node last = collectionElement.getLastChild();
            if (last != null && last instanceof Element) {
                notifyNewElement((Element) last);
            }
        }
        long endMarshal = System.currentTimeMillis();
        if (showTimings) {
            LOGGER.debug("Timings(class=" + clazz.getSimpleName() + ", addEntries) : totalMarshal="
                    + (endMarshal - startMarshal) + "ms");
        }

    }

    @Override
    public <T> void addEntry(XmlConnection connection, T element) {
        Collection<T> elements = Lists.newArrayList(element);
        addEntries(connection, elements, (Class<T>) element.getClass());
    }

    @Override
    public <T> void addEntries(XmlConnection connection, Collection<T> elements) {
        if (elements.isEmpty()) {
            throw new IllegalArgumentException("Trying to store an empty collection !");
        }
        T firstElement = elements.iterator().next();
        if (firstElement == null) {
            throw new IllegalArgumentException("Trying to store a collection with empty elements !");
        }
        Class<T> elementClass = (Class<T>) firstElement.getClass();
        addEntries(connection, elements, elementClass);
    }

    @Override
    public <T> SearchResults<T> getEntriesPartial(XmlConnection connection, XPathQuery xpathQuery, Class<T> clazz,
            long start, long max) {
        XMLMarshaller<T> unmarshaller = marshallerFactory.getMarshaller(clazz);

        List<T> result = new ArrayList<T>();

        long preEvaluate = System.currentTimeMillis();

        Element collectionElement = getCollectionElement(connection, clazz);
        NodeList xpathResult = xpathQuery.evaluate(collectionElement);

        LOGGER.info("xpath=" + xpathQuery + " on " + collectionElement + " (name="
                + collectionElement.getAttribute("name") + ")" + " gave " + xpathResult.getLength() + " results.");
        long postEvaluate = System.currentTimeMillis();

        long totalUnmarshall = 0;

        for (long idx = start; idx < max + start; idx++) {
            long preUnmarshall = System.currentTimeMillis();

            if (idx >= xpathResult.getLength()) {
                break;
            }
            org.w3c.dom.Element docElement = (Element) xpathResult.item((int) idx);

            if (docElement == null) {
                LOGGER.error("Null docElement at idx=" + idx);
                continue;
            }

            T finalDocument = unmarshaller.unmarshal(docElement);
            result.add(finalDocument);
            long postUnmarshall = System.currentTimeMillis();
            totalUnmarshall += (postUnmarshall - preUnmarshall);
        }

        if (showTimings) {
            LOGGER.debug("Timings(class=" + clazz.getSimpleName() + ", getEntries) : evaluate="
                    + (postEvaluate - preEvaluate) + "ms, unmarshall=" + (totalUnmarshall) + "ms");
        }
        return new SearchResults<T>(result, xpathResult.getLength());
    }

    @Override
    public <T> long countEntries(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz) {
        return getEntriesPartial(connection, searchExpression, clazz, 0, 0).getFound();
    }

    @Override
    public <T> List<T> getEntries(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz) {
        return getEntriesPartial(connection, searchExpression, clazz, 0, Long.MAX_VALUE).getObjects();
    }

    @Override
    public <T> T getSingleEntry(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz) {
        SearchResults<T> searchResults = getEntriesPartial(connection, searchExpression, clazz, 0, 1);
        if (searchResults.getFound() == 1 && searchResults.getObjects().size() == 1) {
            return searchResults.getObjects().get(0);
        }
        LOGGER.warn("No single-result returned : found=" + searchResults.getFound());
        return null;
    }

    @Override
    public <T> int deleteEntries(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz) {
        return doDeleteEntries(connection, searchExpression, clazz, true, true);
    }

    @Override
    public <T> void deleteEntry(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz)
            throws XPathException {
        doDeleteEntries(connection, searchExpression, clazz, false, false);
    }

    private <T> int doDeleteEntries(XmlConnection connection, XPathQuery xpathQuery, Class<T> clazz,
            boolean allowMultiple, boolean allowZero) {
        NodeList xpathResult = xpathQuery.evaluate(getCollectionElement(connection, clazz));
        LOGGER.debug("doDeleteEntries() : xapthResult.getLength()=" + xpathResult.getLength());
        if (!allowZero) {
            if (xpathResult.getLength() == 0) {
                LOGGER.error("Nothing to delete for " + xpathQuery);
                return 0;
                // throw new XPathException((short) 0, "Could not get item :" +
                // xpathQuery);
            }
        }
        if (!allowMultiple) {
            if (xpathResult.getLength() != 1) {
                throw new XPathException((short) 0, "Could not get item :" + xpathQuery);
            }
        }
        for (int idx = 0; idx < xpathResult.getLength(); idx++) {
            Node item = xpathResult.item(idx);
            if (!(item instanceof Element)) {
                throw new XPathException((short) 0, "Invalid item, not a node : " + item);
            }
            org.w3c.dom.Element docElement = (Element) item;

            Node parentNode = docElement.getParentNode();
            parentNode.removeChild(docElement);
        }

        return xpathResult.getLength();
    }

    @Override
    public <T> void insertRawXML(XmlConnection connection, Class<T> clazz, InputStream inputStream) {
        Element collectionElement = getCollectionElement(connection, clazz);

        javax.xml.transform.sax.SAXSource source = new javax.xml.transform.sax.SAXSource();
        source.setInputSource(new InputSource(inputStream));

        javax.xml.transform.dom.DOMResult result = new javax.xml.transform.dom.DOMResult();
        result.setNode(collectionElement);

        try {
            Transformer transformer = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
            transformer.transform(source, result);
        }
        catch (TransformerException e) {
            throw new RuntimeException("Could not inject", e);
        }
    }

}
