package com.bnpp.cardif.sugar.dao.xml.api;

import java.util.Collection;
import java.util.Map;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public interface XPathQuery {
    public interface Context {
        Context put(String name, Object value);

        Collection<String> getVariables();

        Object getVariable(String name);

        Map<String, Object> asMap();
    }

    NodeList evaluate(Node contextNode);
}
