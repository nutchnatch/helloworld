package com.bnpp.cardif.sugar.dao.xml.fact;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.fact.FactDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Fact;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;
import com.google.common.collect.Lists;

public class FactXmlDAO implements FactDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(FactXmlDAO.class);

    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public void store(String scope, Fact fact) throws SugarTechnicalException {
        // no operation
    }

    @Override
    public List<Fact> getAll(String scope) throws SugarTechnicalException {
        return Lists.newArrayList();
    }

    @Override
    public Date getTaskUpdateDate(String scope, TaskId taskId) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getUserObjectAction(FACT_OBJECT object, String action, String id) throws SugarTechnicalException {
        // TODO Auto-generated method stub
        return null;
    }

}
