package com.bnpp.cardif.sugar.dao.xml.simpledom;

import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.bnpp.cardif.sugar.dao.xml.api.ExpressionFactory;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.base.BaseXmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;

public class StandaloneXmlDatasource extends BaseXmlDatasource {
    private static final Logger LOGGER = LoggerFactory.getLogger(StandaloneXmlDatasource.class);

    @Autowired
    private ExpressionFactory expressionFactory;

    private DomXmlConnection xmlConnection;

    private boolean dumpAllContentsAtReleaseConnection = false;

    public boolean isDumpAllContentsAtReleaseConnection() {
        return dumpAllContentsAtReleaseConnection;
    }

    public void setDumpAllContentsAtReleaseConnection(boolean dumpAllContentsAtReleaseConnection) {
        this.dumpAllContentsAtReleaseConnection = dumpAllContentsAtReleaseConnection;
    }

    public StandaloneXmlDatasource() {
        LOGGER.info(this.getClass().getName() + " : Constructor");
    }

    @Override
    public synchronized void init() throws SugarTechnicalException {
        if (xmlConnection != null) {
            LOGGER.error("Already iniitalized !");
            return;
        }
        try {
            LOGGER.info(this.getClass().getName() + " : init()");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder loader = factory.newDocumentBuilder();
            org.w3c.dom.Document baseDocument = loader.newDocument();

            parseDocument(baseDocument, "sugar-mock-database-init.xml");

            xmlConnection = new DomXmlConnection(baseDocument);
        }
        catch (ParserConfigurationException e) {
            LOGGER.error("Could not init", e);
            throw new SugarTechnicalException("Could not initialize", e);
        }
        catch (TransformerException e) {
            LOGGER.error("Could not init", e);
            throw new SugarTechnicalException("Could not initialize", e);
        }
    }

    private void parseDocument(Node targetNode, String resourceName)
            throws TransformerFactoryConfigurationError, TransformerException {
        LOGGER.info("Parsing resource=" + resourceName);
        if (targetNode == null) {
            throw new TransformerException("Null documentElement provided !");
        }
        InputStream sourceInputStream = getClass().getClassLoader().getResourceAsStream(resourceName);

        if (sourceInputStream == null) {
            throw new TransformerException("Could not get resource :" + resourceName);
        }
        InputSource inputSource = new InputSource(sourceInputStream);
        javax.xml.transform.sax.SAXSource source = new javax.xml.transform.sax.SAXSource();
        source.setInputSource(inputSource);

        javax.xml.transform.dom.DOMResult result = new javax.xml.transform.dom.DOMResult();
        result.setNode(targetNode);

        Transformer transformer = javax.xml.transform.TransformerFactory.newInstance().newTransformer();

        transformer.transform(source, result);
    }

    @Override
    public void close() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public void deleteAll() throws SugarTechnicalException {
        xmlConnection = null;
    }

    @Override
    public ExpressionFactory getExpressionFactory() {
        return expressionFactory;
    }

    @Override
    public XmlConnection getConnection(XmlConnectionAccess xmlAccess) {
        if (xmlConnection == null) {
            LOGGER.warn("Null xmlConnection ! performing init()");
            try {
                init();
            }
            catch (SugarTechnicalException e) {
                LOGGER.error("Could not init", e);
                throw new RuntimeException(e);
            }
        }
        return xmlConnection;
    }

    @Override
    protected Node getDocumentElement(XmlConnection connection) {
        if (connection instanceof DomXmlConnection) {
            return ((DomXmlConnection) connection).getDocument();
        }
        throw new IllegalArgumentException("Not supported : connection class=" + connection.getClass().getName());
    }

    @Override
    public void releaseConnection(XmlConnection xmlConnection) {
        /**
         * Nothing to do
         */
        if (dumpAllContentsAtReleaseConnection) {
            dumpAllContent(xmlConnection);
        }
    }
}
