package com.bnpp.cardif.sugar.dao.xml.simpledom;

import java.util.Iterator;

import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathVariableResolver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.xpath.XPathNSResolver;

import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.base.BaseXPathExpressionFactory;
import com.bnpp.cardif.sugar.dao.xml.base.MultiTextNode;

public class JavaxXPathExpressionFactory extends BaseXPathExpressionFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(JavaxXPathExpressionFactory.class);

    @Autowired
    private XPathNSResolver nameSpacePrefixMapper;

    @Override
    protected XPathQuery createXPathQuery(String xpath, XPathQuery.Context context) {
        return new StandaloneXPathQuery(nameSpacePrefixMapper, xpath, context);
    }

    private static class StandaloneXPathQuery implements XPathQuery {
        private final String xpathStringExpression;

        private final NamespaceContext myNamespaceContext;

        private final XPathQuery.Context context;

        public StandaloneXPathQuery(final XPathNSResolver resolver, String xpathExpression,
                XPathQuery.Context context) {
            this.xpathStringExpression = xpathExpression;
            this.context = context;
            this.myNamespaceContext = new NamespaceContext() {
                @Override
                public Iterator<?> getPrefixes(String arg0) {
                    throw new RuntimeException("Not implemented !");
                }

                @Override
                public String getPrefix(String arg0) {
                    throw new RuntimeException("Not implemented !");
                }

                @Override
                public String getNamespaceURI(String arg0) {
                    return resolver.lookupNamespaceURI(arg0);
                }
            };
        }

        @Override
        public NodeList evaluate(Node node) {
            if (node == null) {
                throw new RuntimeException("Node is null !");
            }
            XPathFactory xpathFactory = XPathFactory.newInstance();
            XPath xpath = xpathFactory.newXPath();

            xpath.setNamespaceContext(myNamespaceContext);
            xpath.setXPathVariableResolver(new XPathVariableResolver() {
                @Override
                public Object resolveVariable(QName arg0) {
                    return context.getVariable(arg0.getLocalPart());
                }
            });
            try {
                LOGGER.debug("Evaluating : " + xpathStringExpression);
                javax.xml.xpath.XPathExpression xpathExpression = xpath.compile(xpathStringExpression);
                return (NodeList) xpathExpression.evaluate(node, XPathConstants.NODESET);
            }
            catch (XPathExpressionException e) {
                throw new RuntimeException(e);
            }
        }

        public String toString() {
            return "XPath : " + xpathStringExpression;
        }
    }

    @Override
    protected MultiTextNode createTextNodeList() {
        return new OrgDomTextNode();
    }
}
