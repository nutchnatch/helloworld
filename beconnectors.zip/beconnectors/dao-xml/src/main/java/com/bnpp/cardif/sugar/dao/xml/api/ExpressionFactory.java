package com.bnpp.cardif.sugar.dao.xml.api;

import java.util.List;

import com.bnpp.cardif.sugar.dao.api.acl.AclDAO.AclContext;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

public interface ExpressionFactory {
    <T> XPathQuery createCollectionQuery(Class<T> clazz);

    XPathQuery createBusinessScopeGetAllQuery();

    XPathQuery createBusinessScopeGetBySymbolicNameQuery(List<String> symbolicNames);

    XPathQuery createAclQuery(AclId id);

    XPathQuery createAclGetAllQuery(String scope);

    XPathQuery createAclMappingQuery(AclContext aclContext, String objectId);

    XPathQuery createDocumentClassQuery(String scope, List<ClassId> classIds);

    XPathQuery createDocumentClassSearchQuery(String scope, Category category, Boolean isActiveOnly);

    XPathQuery createTagSearchQuery(String scope);

    XPathQuery createTagSearchQuery(String scope, List<ClassId> tagIds);

    XPathQuery createTagSearchBySymbolicNameQuery(String scope, List<String> symbolicNames);

    XPathQuery createGetDocumentFileQuery(String scope, List<URI> uri);

    XPathQuery createDocumentQuery(String scope, Criteria criteria, OrderClause order);

    XPathQuery createFolderGetQuery(String scope, List<FolderId> ids);

    XPathQuery createFolderSearchQuery(String scope, Criteria criteria, OrderClause order);

    XPathQuery createFolderGetBySymbolicNameQuery(String scope, List<String> symbolicNames);

    XPathQuery createBasketGetQuery(String scope, List<BasketId> ids);

    XPathQuery createBasketGetAllQuery(String scope);

    XPathQuery createFactGetAllQuery(String scope);

    XPathQuery createFolderClassGetAllQuery(String scope, Boolean isActiveOnly);

    XPathQuery createFolderClassGetAllVersionsQuery(String scope, List<ClassId> ids);

    XPathQuery createFolderClassQuery(String scope, List<ClassId> classIds);

    XPathQuery createGetTasksForDocQuerry(String scope, List<TaskId> ids);

    XPathQuery createGetTasksInBasketQuery(String scope, BasketId basketId);

    XPathQuery createGetTasksForDocQuerry(String scope, Id docId);

    XPathQuery createDocumentClassGetAllVersionsQuery(String scope, List<ClassId> classIds);

    XPathQuery createGetAllDocumentsByScopeQuery(String scope);

    XPathQuery createGetAllFoldersByScopeQuery(String scope);

    XPathQuery createGetDocumentQuery(List<Id> ids, String scope);

    XPathQuery createGetDocumentFileQuery(List<URI> uris);

    XPathQuery createGetAllDocumentFileQuery();

    XPathQuery createGetDocumentQuery(List<String> ids);
}
