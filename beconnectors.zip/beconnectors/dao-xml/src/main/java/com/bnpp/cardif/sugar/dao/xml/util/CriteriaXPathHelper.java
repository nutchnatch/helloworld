package com.bnpp.cardif.sugar.dao.xml.util;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.google.common.collect.Lists;

public class CriteriaXPathHelper {
    
    public String buildCriteria(Criteria criteria) {
        
        if (!Item.FOLDER.equals(criteria.getItem()))

        {
            criteria.getCriterionList().add(new Criterion(Levels.ATTRIBUTE, "Category", Operators.EQUALS_TO,
                    Types.STRING, Lists.newArrayList(criteria.getItem().toString())));
        }
        StringBuilder result = new StringBuilder();
        for (Criterion criterion : criteria.getCriterionList()) {

            if (result.length() <= 0) {
                result.append("[(");
            }
            else {
                result.append(") and (");
            }

            if (Item.FOLDER.equals(criteria.getItem()) && "Id".equals(criterion.getName())) {
                result.append("folder:ChildComponents/doc:Id/text() ='" + criterion.getValues().get(2) + "'");
                result.append(") and (");
                result.append("folder:ChildComponents/doc:Id[@Issuer='" + criterion.getValues().get(0) + "']");
                result.append(") and (");
                result.append("folder:ChildComponents/doc:Id[@Scheme='" + criterion.getValues().get(1) + "']");
                continue;
            }
            else if (Item.FOLDER.equals(criteria.getItem()) && "ClassId".equals(criterion.getName())) {
                result.append("folder:Data/common:ClassId/text() ='" + criterion.getValues().get(2) + "'");
                result.append(") and (");
                result.append("folder:Data/common:ClassId[@Issuer='" + criterion.getValues().get(0) + "']");
                result.append(") and (");
                result.append("folder:Data/common:ClassId[@Scheme='" + criterion.getValues().get(1) + "']");
                continue;
            }
            else if ((Item.DOCUMENT.equals(criteria.getItem()) || Item.ENVELOPE.equals(criteria.getItem()))
                    && "ClassId".equals(criterion.getName()) && criterion.getValues().size() == 3) {
                result.append("doc:Data/common:ClassId/text() ='" + criterion.getValues().get(2) + "'");
                result.append(") and (");
                result.append("doc:Data/common:ClassId[@Issuer='" + criterion.getValues().get(0) + "']");
                result.append(") and (");
                result.append("doc:Data/common:ClassId[@VersId='" + criterion.getValues().get(1) + "']");
                break;
            }

            String valueAccessor = null;
            switch (criterion.getLevel()) {
            case ATTRIBUTE:
                valueAccessor = "@" + criterion.getName();
                break;
            case TAG:
                valueAccessor = "common:Tags/common:Tag[@name='" + criterion.getName() + "']/common:Value";
                break;
            case DATA:
                if (Item.FOLDER.equals(criteria.getItem())) {
                    valueAccessor = "folder:Data/common:" + criterion.getName() + "/text()";
                }
                else if (Item.DOCUMENT.equals(criteria.getItem()) || Item.ENVELOPE.equals(criteria.getItem())) {
                    valueAccessor = "doc:Data/common:" + criterion.getName() + "/text()";
                }
                break;
            case CHILD:
                if (Item.FOLDER.equals(criteria.getItem())) {
                    valueAccessor = "folder:ChildComponents/doc:" + criterion.getName() + "/text()";
                }
                break;
            default:
                throw new IllegalArgumentException(
                        "Not implemented : criterion.getLevel()=" + criterion.getLevel() + " .Criteria is " + criteria);
            }

            if (criterion.getValues().size() != 1) {
                throw new IllegalArgumentException(
                        "Not implemented : criterion.getValue().size()=" + criterion.getValues().size());
            }
            switch (criterion.getOperator()) {
            case EQUALS_TO:
                result.append(valueAccessor);
                result.append(" = '");
                result.append(criterion.getValues().get(0));
                result.append("'");
                break;
            case NOT_EQUALS_TO:
                result.append(valueAccessor);
                result.append(" != '");
                result.append(criterion.getValues().get(0));
                result.append("'");
                break;
            case CONTAINS:
                result.append("contains(");
                result.append(valueAccessor);
                result.append(", '");
                result.append(criterion.getValues().get(0));
                result.append("')");
                break;
            default:
                throw new IllegalArgumentException(
                        "Not implemented : criterion.getOperator()=" + criterion.getOperator());
            }
        }
        if (result.length() > 0) {
            result.append(")]");
        }
        return result.toString();
    }
}
