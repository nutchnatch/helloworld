package com.bnpp.cardif.sugar.dao.xml.reporting;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnpp.cardif.sugar.dao.api.basket.BasketDAO;
import com.bnpp.cardif.sugar.dao.api.document.DocumentDAO;
import com.bnpp.cardif.sugar.dao.api.documentclass.DocumentClassDAO;
import com.bnpp.cardif.sugar.dao.api.folder.FolderDAO;
import com.bnpp.cardif.sugar.dao.api.folderclass.FolderClassDAO;
import com.bnpp.cardif.sugar.dao.api.reporting.ReportingDAO;
import com.bnpp.cardif.sugar.dao.api.task.TaskDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TaskStatus;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.google.common.collect.Lists;

public class ReportingXmlDAO implements ReportingDAO {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportingXmlDAO.class);

    private XmlDatasource dataSource;

    private int start = 0;

    private int max = 100;

    @Autowired
    private DocumentClassDAO documentClassDAO;

    @Autowired
    private DocumentDAO documentDAO;

    @Autowired
    private TaskDAO taskDAO;

    @Autowired
    private BasketDAO basketDAO;

    @Autowired
    private FolderDAO folderDAO;

    @Autowired
    private FolderClassDAO folderClassDAO;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public List<EnvelopeFlows> getEnvelopesAndDocumentFlow(String scope, String formatedStartDate,
            String formatedEndDate) throws SugarTechnicalException {

        List<DocumentClass> envelopeDocumentClasses = documentClassDAO.search(scope, Category.ENVELOPE, true);
        LOGGER.info(envelopeDocumentClasses.size() + " document classes have been fetched");

        List<EnvelopeFlows> envelopeAndDocumentFlows = new ArrayList<>();

        envelopeAndDocumentFlows.addAll(getFlows(scope, envelopeDocumentClasses, Item.ENVELOPE));
        return envelopeAndDocumentFlows;
    }

    private List<EnvelopeFlows> getFlows(String scope, List<DocumentClass> documentClasses, Item item)
            throws SugarTechnicalException {
        List<EnvelopeFlows> envelopeFlows = new ArrayList<>();
        Criteria criteria = new Criteria();
        criteria.setItem(Item.DOCUMENT);
        SearchResults<Document> fetchedAllDocuments = documentDAO.find(scope, criteria, null, start, max);
        for (DocumentClass documentClass : documentClasses) {
            LOGGER.info("Fetching components of class " + documentClass.getLongLabel() + " for item " + item);
            EnvelopeFlows envelopeFlow = new EnvelopeFlows();
            envelopeFlow.setClassId(documentClass.getClassId());
            criteria = new Criteria();
            criteria.setItem(item);
            Criterion criterion = new Criterion();
            criterion.setLevel(Levels.DATA);
            criterion.setOperator(Operators.EQUALS_TO);
            criterion.setName("ClassId");
            criterion.setType(Types.STRING);
            List<String> values = Lists.newArrayList(documentClass.getClassId().getIssuer(),
                    documentClass.getClassId().getVersId() + "", documentClass.getClassId().getValue());
            criterion.getValues().addAll(values);
            criteria.getCriterionList().add(criterion);

            SearchResults<Document> fetchedEnvelopes = documentDAO.find(scope, criteria, null, start, max);

            if (Item.ENVELOPE.equals(item)) {
                envelopeFlow.setNumberOfEnvelopes(fetchedEnvelopes.getFound());
            }
            int nbDocOfEnvClass = 0;
            for (Document envelope : fetchedEnvelopes.getObjects()) {
                for (Document document : fetchedAllDocuments.getObjects()) {
                    if (document.getParentId().getId().equals(envelope.getId())) {
                        nbDocOfEnvClass++;
                    }
                }
            }
            envelopeFlow.setNumberOfDocuments(nbDocOfEnvClass);

            LOGGER.info(fetchedEnvelopes.getFound() + " components of class " + documentClass.getLongLabel()
                    + " have been fetched for item " + item);
            envelopeFlows.add(envelopeFlow);
        }
        return envelopeFlows;
    }

    @Override
    public List<BasketRatio> getBasketClosedRatios(String scope, String formatedStartDate, String formatedEndDate)
            throws SugarTechnicalException {

        List<BasketRatio> basketRatios = new ArrayList<>();
        List<Basket> baskets = basketDAO.getAll(scope);
        for (Basket basket : baskets) {

            SearchResults<Task> tasks = taskDAO.getTasksInBasket(scope, basket.getBasketId(), start, max, true);
            List<Task> openTasks = new ArrayList<>();
            List<Task> closeTasks = new ArrayList<>();
            for (Task task : tasks.getObjects()) {
                if (TaskStatus.NEW.toString().equals(task.getStatus())) {
                    openTasks.add(task);
                }
                else if (TaskStatus.CLOSE.toString().equals(task.getStatus())) {
                    closeTasks.add(task);
                }
            }
            BasketRatio basketRatio = new BasketRatio();
            basketRatio.setBasketId(basket.getBasketId());
            basketRatio.setNumberOfOpened(openTasks.size());
            basketRatio.setNumberOfClosed(closeTasks.size());
            basketRatios.add(basketRatio);
        }
        return basketRatios;
    }

    @Override
    public List<DocumentStock> getDocumentStockIndicators(String scope, String startingDate, String endingDate)
            throws SugarTechnicalException {

        List<DocumentClass> documentClasses = documentClassDAO.search(scope, Category.DOCUMENT, false);
        LOGGER.info(documentClasses.size() + " document classes have been fetched");
        List<DocumentStock> documentStocks = new ArrayList<>();
        Item item = Item.DOCUMENT;
        for (DocumentClass documentClass : documentClasses) {
            LOGGER.info("Fetching components of class " + documentClass.getLongLabel() + " for item " + item);
            EnvelopeFlows envelopeFlow = new EnvelopeFlows();
            envelopeFlow.setClassId(documentClass.getClassId());
            Criteria criteria = new Criteria();
            criteria.setItem(item);
            Criterion criterion = new Criterion();
            criterion.setLevel(Levels.DATA);
            criterion.setOperator(Operators.EQUALS_TO);
            criterion.setName("ClassId");
            criterion.setType(Types.STRING);
            List<String> values = Lists.newArrayList(documentClass.getClassId().getIssuer(),
                    documentClass.getClassId().getVersId() + "", documentClass.getClassId().getValue());
            criterion.getValues().addAll(values);
            criteria.getCriterionList().add(criterion);
            SearchResults<Document> fetchedDocuments = documentDAO.find(scope, criteria, null, start, max);
            int length = 0;
            for (Document fetchedDocument : fetchedDocuments.getObjects()) {
                for (DocumentFile documentFile : fetchedDocument.getFileData().getDocumentFile()) {
                    length += documentFile.toString().length();
                }

            }
            DocumentStock documentStock = new DocumentStock(documentClass.getClassId(), fetchedDocuments.getFound(),
                    length);
            documentStocks.add(documentStock);
        }

        return documentStocks;
    }

    @Override
    public List<FolderStock> getFolderStockIndicators(String scope, String startingDate, String endingDate)
            throws SugarTechnicalException {
        List<FolderClass> folderClasses;
        try {
            folderClasses = folderClassDAO.getAll(scope, false);
        }
        catch (SugarFunctionalException e) {
            throw new SugarTechnicalException(e.getMessage(), e);
        }
        LOGGER.info(folderClasses.size() + " folder classes have been fetched");
        List<FolderStock> folderStocks = new ArrayList<>();
        for (FolderClass folderClass : folderClasses) {
            Criteria criteria = new Criteria();
            criteria.setItem(Item.FOLDER);
            Criterion criterion = new Criterion();
            criterion.setLevel(Levels.DATA);
            criterion.setOperator(Operators.EQUALS_TO);
            criterion.setName("ClassId");
            criterion.setType(Types.STRING);
            List<String> values = Lists.newArrayList(folderClass.getClassId().getIssuer(),
                    folderClass.getClassId().getVersId() + "", folderClass.getClassId().getValue());
            criterion.getValues().addAll(values);
            criteria.getCriterionList().add(criterion);
            SearchResults<Folder> fetchedFolder = folderDAO.find(scope, criteria, null, start, max);
            FolderStock folderStock = new FolderStock(folderClass.getClassId(), fetchedFolder.getFound());
            folderStocks.add(folderStock);
        }
        return folderStocks;
    }

    @Override
    public Summary getReportingSummary(String scope) throws SugarTechnicalException {
        Summary summary = new Summary();
        Criteria criteria = new Criteria();
        criteria.setItem(Item.ENVELOPE);
        SearchResults<Document> fetchedEnvelopes = documentDAO.find(scope, criteria, null, start, max);
        summary.setNumbereOfEnvelopes(fetchedEnvelopes.getFound());
        criteria.setItem(Item.DOCUMENT);
        SearchResults<Document> fetchedDocuments = documentDAO.find(scope, criteria, null, start, max);
        summary.setNumberOfDocuments(fetchedDocuments.getFound());

        List<BasketRatio> basketRatios = getBasketClosedRatios(scope, null, null);
        long nbTask = 0;
        for (BasketRatio basketRatio : basketRatios) {
            nbTask += basketRatio.getNumberOfClosed() + basketRatio.getNumberOfOpened();
        }
        summary.setNumberOfTasks(nbTask);
        criteria.setItem(Item.FOLDER);
        SearchResults<Folder> fetchedFolders = folderDAO.find(scope, criteria, null, start, max);
        summary.setNumbereOfFolders(fetchedFolders.getFound());
        return summary;
    }
}
