package com.bnpp.cardif.sugar.dao.xml.util;

import java.util.Map;

import org.w3c.dom.xpath.XPathNSResolver;

import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

/**
 * Provide ability to map a name space to a custom prefix
 * 
 * @author Christopher Laszczuk
 * 
 */
public class SugarNameSpacePrefixMapper extends NamespacePrefixMapper implements XPathNSResolver {
    private Map<String, String> prefixes;

    @Override
    public String getPreferredPrefix(String namespaceUri, String suggestion, boolean requirePrefix) {
        String prefix = prefixes.get(namespaceUri);
        return prefix != null && !prefix.isEmpty() ? prefix : suggestion;
    }

    public Map<String, String> getPrefixes() {
        return prefixes;
    }

    public void setPrefixes(Map<String, String> prefixes) {
        this.prefixes = prefixes;
    }

    @Override
    public String lookupNamespaceURI(String prefix) {
        for (Map.Entry<String, String> entry : prefixes.entrySet()) {
            if (entry.getValue().equals(prefix)) {
                return entry.getKey();
            }
        }
        return null;
    }

}
