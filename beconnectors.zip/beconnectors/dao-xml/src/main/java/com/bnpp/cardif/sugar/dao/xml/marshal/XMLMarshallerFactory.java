package com.bnpp.cardif.sugar.dao.xml.marshal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

public class XMLMarshallerFactory {
    @Autowired
    private NamespacePrefixMapper nameSpacePrefixMapper;

    private Map<Class<?>, XMLMarshaller<?>> xmlMarshallerMap = new HashMap<Class<?>, XMLMarshaller<?>>();

    @SuppressWarnings("unchecked")
    public <TYPE> XMLMarshaller<TYPE> getMarshaller(Class<TYPE> clazz) {
        XMLMarshaller<?> marshaller = xmlMarshallerMap.get(clazz);
        if (marshaller == null) {
            marshaller = new SimpleXMLMarshallerImpl<TYPE>(clazz, nameSpacePrefixMapper);
        }
        return (XMLMarshaller<TYPE>) marshaller;
    }

    public void setInitialClasses(List<Class<?>> classes) {
        for (Class<?> clazz : classes) {
            getMarshaller(clazz);
        }
    }
}
