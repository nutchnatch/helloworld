package com.bnpp.cardif.sugar.dao.xml.businessscope;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.dao.api.businessscope.BusinessScopeDAO;
import com.bnpp.cardif.sugar.dao.xml.api.XPathQuery;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnection;
import com.bnpp.cardif.sugar.dao.xml.api.XmlConnectionAccess;
import com.bnpp.cardif.sugar.dao.xml.api.XmlDatasource;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.google.common.collect.Lists;

public class BusinessScopeXmlDAO implements BusinessScopeDAO {
    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessScopeXmlDAO.class);

    private XmlDatasource dataSource;

    public XmlDatasource getDataSource() {
        return dataSource;
    }

    public void setDataSource(XmlDatasource dataSource) {
        this.dataSource = dataSource;
    }

    public void init() throws SugarTechnicalException {
        // no operation
    }

    @Override
    public void store(List<BusinessScope> businessScopes) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("STORE:" + businessScopes);
        List<String> symbolicNames = extractSymbolicNames(businessScopes);
        for (String symbolicName : symbolicNames) {
            if (Collections.frequency(symbolicNames, symbolicName) != 1) {
                throw new SugarFunctionalException("Storing multiple times the business scope : " + symbolicName, null);
            }
        }

        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            doStore(connection, businessScopes, symbolicNames);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private void doStore(XmlConnection connection, List<BusinessScope> businessScopes, List<String> symbolicNames)
            throws SugarTechnicalException {
        List<BusinessScope> existing = doGetBySymbolicName(connection, symbolicNames);
        if (!existing.isEmpty()) {
            throw new SugarTechnicalException("Already stored the following business scopes : " + existing);
        }
        getDataSource().addEntries(connection, businessScopes);
    }

    @Override
    public List<BusinessScope> getAll() throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory().createBusinessScopeGetAllQuery();
            return getDataSource().getEntries(connection, searchExpression, BusinessScope.class);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    @Override
    public void update(List<BusinessScope> businessScopes) throws SugarTechnicalException, SugarFunctionalException {
        List<String> symbolicNames = extractSymbolicNames(businessScopes);
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Write);
        try {
            XPathQuery searchExpression = getDataSource().getExpressionFactory()
                    .createBusinessScopeGetBySymbolicNameQuery(symbolicNames);
            getDataSource().deleteEntries(connection, searchExpression, BusinessScope.class);
            doStore(connection, businessScopes, symbolicNames);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }

    }

    @Override
    public List<BusinessScope> getBySymbolicName(List<String> symbolicNames) throws SugarTechnicalException {
        XmlConnection connection = getDataSource().getConnection(XmlConnectionAccess.Read);
        try {
            return doGetBySymbolicName(connection, symbolicNames);
        }
        finally {
            getDataSource().releaseConnection(connection);
        }
    }

    private List<BusinessScope> doGetBySymbolicName(XmlConnection connection, List<String> symbolicNames) {
        XPathQuery searchExpression = getDataSource().getExpressionFactory()
                .createBusinessScopeGetBySymbolicNameQuery(symbolicNames);
        return getDataSource().getEntries(connection, searchExpression, BusinessScope.class);
    }

    private List<String> extractSymbolicNames(List<BusinessScope> businessScopes) {
        List<String> symbolicNames = Lists.newArrayList();
        for (BusinessScope bs : businessScopes) {
            symbolicNames.add(bs.getSymbolicName());
        }
        return symbolicNames;
    }
}
