package com.bnpp.cardif.sugar.dao.xml.api;

import java.io.InputStream;
import java.util.Collection;
import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;

public interface XmlDatasource {
    void init() throws SugarTechnicalException;

    void close() throws SugarTechnicalException;

    void deleteAll() throws SugarTechnicalException;

    XmlConnection getConnection(XmlConnectionAccess xmlAccess);

    void releaseConnection(XmlConnection xmlConnection);

    ExpressionFactory getExpressionFactory();

    <T> void addEntry(XmlConnection connection, T element);

    <T> void addEntries(XmlConnection connection, Collection<T> elements);

    <T> SearchResults<T> getEntriesPartial(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz,
            long start, long max);

    /**
     * 
     * @param connection
     * @param searchExpression
     * @param clazz
     * @return null if no entry found
     */
    <T> T getSingleEntry(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz);

    <T> int deleteEntries(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz);

    <T> void deleteEntry(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz);

    <T> void insertRawXML(XmlConnection connection, Class<T> clazz, InputStream inputStream);

    <T> List<T> getEntries(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz);

    <T> long countEntries(XmlConnection connection, XPathQuery searchExpression, Class<T> clazz);
}
