package com.ossnms.web.api.security.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
import java.io.IOException;

/**
 *
 */
@Provider
@PreMatching
public class CORSRequestFilter implements ContainerRequestFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(CORSRequestFilter.class);

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        LOGGER.debug("\n\n\tFILTER >>> CORS REQUEST FILTER\n");

        // When HttpMethod comes as OPTIONS, just acknowledge that it accepts...
        if (requestContext.getRequest().getMethod().equals(HttpMethod.OPTIONS)) {
            LOGGER.debug("Detected OPTIONS method request");

            // Just send a OK signal back to the browser
            requestContext.abortWith( Response.status( Response.Status.OK ).build() );
        }
    }
}
