package com.ossnms.web.api.security.provider;

import com.ossnms.web.api.common.provider.BaseProvider;
import com.ossnms.web.api.security.api.provider.SecurityProvider;
import com.ossnms.web.api.security.api.resources.outbound.VersionInformation;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.api.params.Permission;
import com.ossnms.web.provider.security.api.result.PermissionReply;
import com.ossnms.web.provider.security.operations.SecurityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.util.Arrays;

/**
 * {@inheritDoc}
 */
public class SecurityProviderImpl extends BaseProvider implements SecurityProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityProviderImpl.class);
    public static final String FORMAT_WEB_CLIENT_LOGIN = "Web-Client@%s";

    /**
     * Instance of the SecurityOperationsProvider
     */
    @Inject
    private SecurityOperations securityOperations;

    /**
     *  The current {@link HttpServletRequest}
     */
    @Context
    private HttpServletRequest servletRequest;

    /**
     * {@inheritDoc}
     */
    public SecurityToken logon(String username, String password) {
        LOGGER.info("Login attempt from user {}", username);

        // method parameters validation
        if(username == null || password == null ){
            LOGGER.debug("Login attempt with invalid parameters.");
            return null;
        }

        // object injection validation
        if(securityOperations == null){
            LOGGER.debug("Server not yet available or missing.");
            return null;
        }

        String hostname = "unknown";
        if(servletRequest == null) {
            LOGGER.debug("Servlet Request could not be resolved. Request hostname set to 'unknown'.");
        } else {
            hostname = servletRequest.getRemoteHost();
        }

        SecurityToken token = securityOperations.login(
                username,
                password,
                String.format(FORMAT_WEB_CLIENT_LOGIN, hostname)
        );

        LOGGER.info("Login was {}", token == null ? "unsuccessful" : "successful");
        return token;
    }

    /**
     * {@inheritDoc}
     */
    public SecurityToken validateToken(String token) {
        if(token == null){
            return null;
        }

        return securityOperations.validateToken(token);
    }

    /**
     * {@inheritDoc}
     */
    public SecurityToken validateToken() {
        SecurityToken token = getSecurityToken();

        if(securityOperations == null){
            return null;
        }

        return securityOperations.validateToken(token);
    }

    /**
     * {@inheritDoc}
     */
    public boolean logoff() {
        if(getSecurityToken() != null){
            SecurityToken token = getSecurityToken();

            LOGGER.info("Logout attempt from user {}", token.getUsername());

            securityOperations.logout(token);
            return true;
        }

        LOGGER.warn("Logout failed since the security context was not valid. Unauthenticated user?");
        return false;
    }

    @Override
    public VersionInformation getVersionInformation() {
        com.ossnms.web.provider.security.model.VersionInformation providerVersionInfo;
        providerVersionInfo = securityOperations.getVersionInformation(getSecurityToken());

        return VersionInformation.fromProvider(providerVersionInfo);
    }

    @Override
    public PermissionReply hasAccess(String permission) {
        // extract security token
        SecurityToken token = getSecurityToken();

        if(permission == null || permission.isEmpty()) {
            LOGGER.debug("hasAccess called with null or empty permission");
            return emptyPermissionReply();
        }

        if(token == null) {
            LOGGER.warn("Access check with no security context available");
            return emptyPermissionReply();
        }

        LOGGER.debug("Access check for user {} and permission {}", token.getUsername(), permission);

        // split permission parameter
        Permission[] permissions = Arrays.stream(permission.split(",")).map(
                perm -> new Permission.Builder().setPermission(perm).build()
        ).toArray(Permission[]::new);
        //
        return securityOperations.hasPermission(
                token,
                permissions
        );
    }

    /**
     *
     * @return
     */
    private PermissionReply emptyPermissionReply() {
        return new PermissionReply.Builder().build();
    }
}
