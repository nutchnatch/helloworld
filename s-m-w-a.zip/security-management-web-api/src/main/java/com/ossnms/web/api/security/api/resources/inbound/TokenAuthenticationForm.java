package com.ossnms.web.api.security.api.resources.inbound;

import javax.ws.rs.FormParam;
import java.io.Serializable;

/**
 *
 */
public class TokenAuthenticationForm implements Serializable {

    private static final long serialVersionUID = 605705186101891968L;

    @FormParam("sessionContext") private String token;

    public TokenAuthenticationForm() {}

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
