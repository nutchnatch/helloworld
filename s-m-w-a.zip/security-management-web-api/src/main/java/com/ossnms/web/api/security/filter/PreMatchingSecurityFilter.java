package com.ossnms.web.api.security.filter;

import com.ossnms.web.api.common.context.JWTSessionBasedUserPrincipal;
import com.ossnms.web.api.common.context.SessionBasedSecurityContext;
import com.ossnms.web.api.common.context.SessionBasedUserPrincipal;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.PreMatching;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
import java.io.IOException;

import static com.ossnms.web.api.security.api.constant.SecurityManagementConstants.AUTHORIZATION_SCHEME_BEARER;
import static com.ossnms.web.api.security.api.constant.SecurityManagementConstants.HEADER_KEY_AUTHORIZATION;
import static javax.ws.rs.core.Response.Status.UNAUTHORIZED;

/**
 *
 */
@Provider
@PreMatching
public class PreMatchingSecurityFilter implements ContainerRequestFilter{

    private static final Logger LOGGER = LoggerFactory.getLogger(PreMatchingSecurityFilter.class);

    /**
     *
     * @param requestContext
     * @throws IOException
     */
    public void filter(ContainerRequestContext requestContext) throws IOException {
        LOGGER.debug("\n\n\tFILTER >>> PRE MATCHING SECURITY FILTER\n");

        String authorizationHeader = requestContext.getHeaderString(HEADER_KEY_AUTHORIZATION);

        if (authorizationHeader != null && authorizationHeader.startsWith(AUTHORIZATION_SCHEME_BEARER)) {
            String jwToken = authorizationHeader.replace(AUTHORIZATION_SCHEME_BEARER + ' ', "");

            // validate the jwt
            if(jwToken.isEmpty()){
                LOGGER.warn("A request was attempted without a valid Authorization Header. Aborting.");
                requestContext.abortWith(Response.status(UNAUTHORIZED).build());
                return;
            }

            // parse the security jwt
            SecurityToken token = new SecurityToken.Builder("admin", jwToken).build();

            if(token != null){
                LOGGER.debug("User {} has a valid Security Token. Proceeding.", token.getUsername());
                SessionBasedUserPrincipal userPrincipal = new JWTSessionBasedUserPrincipal(
                        token.getUsername(),
                        token,
                        jwToken
                );
                SessionBasedSecurityContext securityContext = new SessionBasedSecurityContext(
                        userPrincipal
                );
                requestContext.setSecurityContext(securityContext);
            }
        }
    }
}
