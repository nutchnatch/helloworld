package com.ossnms.web.api.security.lookup;

import com.ossnms.web.provider.security.operations.SecurityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Produces;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties;

/**
 *
 */
public class BeanLookup{

    private static final Logger LOGGER = LoggerFactory.getLogger(BeanLookup.class);

    private static final String SECURITY_MANAGER_BEAN_LOOKUP = "ejb:bicnet/securitymgmt/%s!%s";

    /**
     *
     * @return
     */
    @Produces
    private SecurityOperations getSecurityOperations(){
        return getBean(SecurityOperations.class);
    }

    /**
     *
     * @param securityOperationsClass
     * @return
     */
    private SecurityOperations getBean(Class<SecurityOperations> securityOperationsClass) {
        try {
            String name = String.format(SECURITY_MANAGER_BEAN_LOOKUP, securityOperationsClass.getSimpleName(), securityOperationsClass.getCanonicalName());
            return (SecurityOperations) getContext().lookup(name);
        } catch (NamingException e) {
            LOGGER.warn("Could not reach remote bean. Falling back to local lookup");
        }

        try{
            return (SecurityOperations) getContext().lookup(securityOperationsClass.getSimpleName());
        } catch (NamingException e) {
            LOGGER.warn("Could not reach local bean. Lookup fails.");
        }

        return null;
    }

    /**
     *
     * @return
     * @throws NamingException
     */
    private Context getContext() throws NamingException{
        final Properties props = new Properties();
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
        // create the InitialString
        return new InitialContext(props);
    }
}
