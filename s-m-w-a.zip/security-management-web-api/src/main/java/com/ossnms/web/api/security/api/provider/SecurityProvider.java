package com.ossnms.web.api.security.api.provider;

import com.ossnms.web.api.security.api.resources.outbound.VersionInformation;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.api.result.PermissionReply;

import javax.ws.rs.ext.Provider;

/**
 *
 */
@Provider
public interface SecurityProvider {
    /**
     * Logs in a user
     *
     * @param username Identifier of the user to be logged in
     * @param password Password that is to be used to authenticate the previously mentioned user.
     * @return null if login does not succeed and a TNMS Session Context if login succeeds.
     */
    SecurityToken logon(String username, String password);

    /**
     *
     * @param token
     * @return
     */
    SecurityToken validateToken (String token);

    /**
     *
     * @return
     */
    SecurityToken validateToken ();

    /**
     * Logs off a user.
     */
    boolean logoff ();

    /**
     *
     * @return
     */
    VersionInformation getVersionInformation();

    /**
     *
     * @param permission
     * @return
     */
    PermissionReply hasAccess(String permission);
}
