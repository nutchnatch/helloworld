package com.ossnms.web.api.security.mapper;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.notification.NotificationEntityMapper;
import com.ossnms.web.provider.security.model.user.User;

import java.io.Serializable;

/**
 *
 */
public class SecurityEntityMapper implements NotificationEntityMapper{

    @Override
    public boolean accept(EntityBase entityBase) {
        return entityBase instanceof User;
    }

    @Override
    public Serializable map(EntityBase entityBase) {
        return entityBase;
    }
}
