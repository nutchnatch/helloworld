package com.ossnms.web.api.security.api.resources.outbound;

import java.io.Serializable;

/**
 *
 */
public final class VersionInformation implements Serializable {

    private static final long serialVersionUID = -1472846060338765289L;

    private String product;
    private String version;

    public VersionInformation() {
    }

    public VersionInformation setProduct(String product) {
        this.product = product;
        return this;
    }

    public VersionInformation setVersion(String version) {
        this.version = version;
        return this;
    }

    public String getProduct() {
        return product;
    }

    public String getVersion() {
        return version;
    }

    /**
     *
     * @param version
     * @return
     */
    public static VersionInformation fromProvider(com.ossnms.web.provider.security.model.VersionInformation version){
        if(version == null){
            return null;
        }

        return new VersionInformation()
                .setProduct(version.getProductName())
                .setVersion(version.getProductVersion());
    }
}
