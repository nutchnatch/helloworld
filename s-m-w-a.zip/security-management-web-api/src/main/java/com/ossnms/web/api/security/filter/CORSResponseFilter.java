package com.ossnms.web.api.security.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.Provider;
import java.io.IOException;

/**
 * SecuredProvider filter (used by every request) to add cross-origin HTTP headers to the response.
 * This removes network restriction in HTTP requests.
 */
@Provider
public class CORSResponseFilter implements ContainerResponseFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(CORSResponseFilter.class);

    private static final String HEADER_ACCESS_CONTROL_ALLOW_ORIGIN      = "Access-Control-Allow-Origin";
    private static final String HEADER_ACCESS_CONTROL_ALLOW_HEADERS     = "Access-Control-Allow-Headers";
    private static final String HEADER_ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
    private static final String HEADER_ACCESS_CONTROL_ALLOW_METHODS     = "Access-Control-Allow-Methods";
    private static final String HEADER_ACCESS_CONTROL_MAX_AGE           = "Access-Control-Max-Age";

    /**
     * Method that will insert the additional headers in the HTTP response.
     * @param containerRequestContext Data regarding the request that triggered the current response.
     * @param containerResponseContext Data regarding the current response.
     * @throws IOException if an I/O exception occurs.
     */
    public void filter(ContainerRequestContext containerRequestContext, ContainerResponseContext containerResponseContext)
            throws IOException {

        LOGGER.debug("\n\n\tFILTER <<< CORS RESPONSE FILTER\n");

        MultivaluedMap<String,Object> headers = containerResponseContext.getHeaders();

        headers.putSingle(HEADER_ACCESS_CONTROL_ALLOW_ORIGIN, "*");
        headers.putSingle(HEADER_ACCESS_CONTROL_ALLOW_HEADERS, "origin, content-type, accept, authorization, cache-control, if-modified-since");
        headers.putSingle(HEADER_ACCESS_CONTROL_ALLOW_CREDENTIALS, "true");
        headers.putSingle(HEADER_ACCESS_CONTROL_ALLOW_METHODS, "GET, POST, PUT, DELETE");
        headers.putSingle(HEADER_ACCESS_CONTROL_MAX_AGE, "1209600");

    }
}
