package com.ossnms.web.api.security.filter;

import com.ossnms.web.api.common.context.SessionBasedSecurityContext;
import com.ossnms.web.api.common.context.SessionBasedUserPrincipal;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.api.params.Permission;
import com.ossnms.web.provider.security.api.result.PermissionReply;
import com.ossnms.web.provider.security.operations.SecurityOperations;
import org.jboss.resteasy.core.interception.PostMatchContainerRequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;

import static com.ossnms.web.api.security.api.constant.SecurityManagementConstants.RESPONSE_FORBIDDEN;
import static com.ossnms.web.api.security.api.constant.SecurityManagementConstants.RESPONSE_INTERNAL_SERVER_ERROR;
import static com.ossnms.web.api.security.api.constant.SecurityManagementConstants.RESPONSE_UNAUTHORIZED;

/**
 *
 */
@Provider
public class SecurityFilter implements ContainerRequestFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityFilter.class);

    /**
     *
     */
    @Inject
    private SecurityOperations securityOperations;

    /**
     *
     * @param requestContext
     * @throws IOException
     */
    public void filter(ContainerRequestContext requestContext) throws IOException {
        LOGGER.debug("\n\n\tFILTER >>> SECURITY FILTER\n");

        // Annotations - resource methods
        Method method =((PostMatchContainerRequestContext) requestContext).getResourceMethod().getMethod();

        if(method == null){
            requestContext.abortWith(RESPONSE_INTERNAL_SERVER_ERROR);
            return;
        }

        boolean rolesOnMethod       = method.isAnnotationPresent(RolesAllowed.class);
        boolean permitAllOnMethod   = method.isAnnotationPresent(PermitAll.class);
        boolean denyAllOnMethod     = method.isAnnotationPresent(DenyAll.class);

        if (denyAllOnMethod) {
            requestContext.abortWith(RESPONSE_FORBIDDEN);
            return;
        }

        // If there is no annotations the conditions of @PermitAll are applied
        boolean existPermissionAnnotations = rolesOnMethod || permitAllOnMethod;
        SecurityContext securityContext = requestContext.getSecurityContext();

        if(existPermissionAnnotations && !isSecurityContextValid(securityContext)) {
            requestContext.abortWith(RESPONSE_UNAUTHORIZED);
        }

        if(rolesOnMethod && !hasPermissions(securityContext, method.getAnnotation(RolesAllowed.class))) {
            requestContext.abortWith(RESPONSE_FORBIDDEN);
        }
    }

    /**
     *
     * @param securityContext
     * @param rolesAllowed
     * @return
     */
    private boolean hasPermissions(SecurityContext securityContext, RolesAllowed rolesAllowed) {
        SecurityToken securityToken = ((SessionBasedUserPrincipal) securityContext.getUserPrincipal()).getSecurityToken();
        String[] roles = rolesAllowed.value();

        Permission[] permissions = Arrays.stream(roles)
                .map(role -> new Permission.Builder().setPermission(role).build())
                .toArray(Permission[]::new);

        if(securityOperations != null && securityToken != null) {
            PermissionReply permissionReply = securityOperations.hasPermission(securityToken, permissions);
            return permissionReply != null && permissionReply.getPermissionsGranted().size() > 0;
        }

        return false;
    }

    /**
     *
     * @param securityContext
     * @return
     */
    private boolean isSecurityContextValid(SecurityContext securityContext) {
        // if the security context is null, the user principal is null or not of type SessionBasedSecurity
        if(securityContext == null || securityContext.getUserPrincipal() == null || !(securityContext instanceof SessionBasedSecurityContext)){
            return false;
        }
        if(!(securityContext.getUserPrincipal() instanceof SessionBasedUserPrincipal)){
            return false;
        }
        if(securityOperations != null && securityOperations.validateToken(((SessionBasedUserPrincipal) securityContext.getUserPrincipal()).getSecurityToken()) != null) {
            return true;
        }

        return false;
    }
}
