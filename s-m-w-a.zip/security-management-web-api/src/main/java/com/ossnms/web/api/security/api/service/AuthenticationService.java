package com.ossnms.web.api.security.api.service;

import com.ossnms.web.api.security.api.resources.inbound.AuthenticationForm;
import com.ossnms.web.api.security.api.resources.inbound.PermissionParameter;
import com.ossnms.web.api.security.api.resources.inbound.TokenAuthenticationForm;
import org.jboss.resteasy.annotations.Form;

import javax.annotation.security.PermitAll;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Interface that represent the endpoints offered to the authentication call.
 */
@Path("/security")
public interface AuthenticationService {

    /**
     * Endpoint that logs in a user via HTTP Post method.
     *
     * @return A Response object containing a security jwt that should be used to authenticate
     * in the remaining endpoints.
     */
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    Response doLogin(@Form AuthenticationForm authenticationForm);

    /**
     * Enpoint for token validation. The provider entity should be aware of the token type
     *
     * @param authenticationForm the token authentication form
     *
     * @return A response object containing a security JWT that should be used to authorize the
     * remaining endpoints.
     */
    @POST
    @Path("/token")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    Response validateToken(@Form TokenAuthenticationForm authenticationForm);

    /**
     * Endpoint for security token validation
     * @return response with solely the http response code
     */
    @POST
    @Path("/validation")
    @PermitAll
    Response validateToken();

    /**
     * Endpoint that logs out a user represented by the jwt issued in the "login" endpoint
     */
    @POST
    @PermitAll
    @Path("/logout")
    Response doLogout();

    @GET
    @PermitAll
    @Path("/properties")
    @Produces(MediaType.APPLICATION_JSON)
    Response getConfigurationProperties();

    /**
     *
     * @return
     */
    @GET
    @Path("/version")
    @Produces(MediaType.APPLICATION_JSON)
    Response getVersion();

    /**
     * Endpoint to check if the user has a permission
     * @return response with the result
     */
    @GET
    @PermitAll
    @Path("/permission")
    @Produces(MediaType.APPLICATION_JSON)
    Response hasPermission(@BeanParam PermissionParameter permission);
}
