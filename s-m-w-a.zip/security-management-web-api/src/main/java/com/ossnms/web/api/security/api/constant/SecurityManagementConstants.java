package com.ossnms.web.api.security.api.constant;

import javax.ws.rs.core.Response;

import static javax.ws.rs.core.Response.Status.FORBIDDEN;
import static javax.ws.rs.core.Response.Status.INTERNAL_SERVER_ERROR;
import static javax.ws.rs.core.Response.Status.UNAUTHORIZED;

/**
 * Gathers constants for the Security Manager
 */
public final class SecurityManagementConstants {

    private SecurityManagementConstants(){}

    /**
     * String type constants
     */
    public static final String
            HEADER_KEY_AUTHORIZATION = "Authorization",
            HEADER_KEY_WWW_AUTHENTICATE = "WWW-Authenticate",

            AUTHORIZATION_SCHEME_BEARER = "Bearer",

            PARAMETER_PERMISSION = "permission"
    ;


    /**
     * Response type constants
     */
    public static final Response
            RESPONSE_INTERNAL_SERVER_ERROR = Response
                .status(INTERNAL_SERVER_ERROR)
                .build(),
            RESPONSE_FORBIDDEN = Response
                .status(FORBIDDEN)
                .build(),
            RESPONSE_UNAUTHORIZED = Response
                .status(UNAUTHORIZED)
                .header(HEADER_KEY_WWW_AUTHENTICATE, AUTHORIZATION_SCHEME_BEARER)
                .build();

}
