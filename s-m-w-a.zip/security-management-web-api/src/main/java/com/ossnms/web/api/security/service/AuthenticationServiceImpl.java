package com.ossnms.web.api.security.service;


import com.ossnms.web.api.security.api.provider.SecurityProvider;
import com.ossnms.web.api.security.api.resources.inbound.AuthenticationForm;
import com.ossnms.web.api.security.api.resources.inbound.PermissionParameter;
import com.ossnms.web.api.security.api.resources.inbound.TokenAuthenticationForm;
import com.ossnms.web.api.security.api.resources.outbound.VersionInformation;
import com.ossnms.web.api.security.api.service.AuthenticationService;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.api.result.PermissionReply;
import org.jboss.resteasy.annotations.Form;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.core.Response;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.Properties;

import static com.ossnms.web.api.security.api.constant.SecurityManagementConstants.RESPONSE_FORBIDDEN;
import static javax.ws.rs.core.Response.Status.OK;
import static javax.ws.rs.core.Response.Status.UNAUTHORIZED;

/**
 * {@inheritDoc}
 */
public class AuthenticationServiceImpl implements AuthenticationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationServiceImpl.class);

    // set the expiration of each token to 30 minutes
//    private static final int TIME_EXPIRES_IN = 30 * 60000;
    private static final String KEY_VERSION = "VERSION";

    private static final String KEY_OIF_LOCATION = "OIF_LOCATION";
    private static final String KEY_MODE_DEMO = "MODE_DEMO";

    private static final String SYS_OIF_LOCATION = "oif.location";
    private static final String SYS_MODE_DEMO = "mode.demo";

    @Inject
    private SecurityProvider securityProvider;

    /**
     * {@inheritDoc}
     */
    public Response doLogin(AuthenticationForm authenticationForm) {
        SecurityToken token = securityProvider.logon(authenticationForm.getUsername(), authenticationForm.getPassword());

        if(token == null){
            return RESPONSE_FORBIDDEN;
        }

        // once the user was logged on via provider, we can get that information to login the user
        return Response.status(OK).entity(token.getToken()).build();
    }

    /**
     * {@inheritDoc}
     */
    public Response validateToken(@Form TokenAuthenticationForm authenticationForm) {
        SecurityToken token = securityProvider.validateToken(authenticationForm.getToken());

        if(token == null){
            return Response.status(UNAUTHORIZED).build();
        }

        // once the user has validated the token via provider, we can get that information to login the user
        return Response.status(OK).entity(token.getToken()).build();
    }

    /**
     * {@inheritDoc}
     */
    public Response validateToken() {
        SecurityToken token = securityProvider.validateToken();

        if(token == null){
            return Response.status(UNAUTHORIZED).build();
        }

        return Response.status(OK).build();
    }

    /**
     * {@inheritDoc}
     */
    public Response doLogout() {
        // call the security provider to log the user off.
        if(securityProvider.logoff()){
            return Response.status(OK).build();
        }

        LOGGER.debug("Logout failed for the current context");
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getConfigurationProperties() {
        Properties properties = new Properties();

        getVersionInformationProperties(properties);
        getOIFLocationProperties(properties);
        getModeProperties(properties);

        return Response.status(OK).entity(properties).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getVersion() {
        VersionInformation version = securityProvider.getVersionInformation();

        if(version == null){
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }

        return Response.status(OK).entity(version).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response hasPermission(@BeanParam PermissionParameter permission) {
        LOGGER.info("Called 'hasPermission' for {} ", permission);
        if(permission == null || permission.getPermission() == null || permission.getPermission().isEmpty()){
            return Response.status(OK).entity(false).build();
        }

        PermissionReply retValue = securityProvider.hasAccess(permission.getPermission());
        return Response.status(OK).entity(retValue).build();
    }


    /**
     *
     * @param properties
     */
    private void getOIFLocationProperties(Properties properties) {
        // get system properties
        RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean();
        // if the sys property does not exist, then return localhost
        String oifLocation = runtimeBean.getSystemProperties().getOrDefault(SYS_OIF_LOCATION, "localhost");
        properties.put(KEY_OIF_LOCATION, oifLocation);
    }

    /**
     *
     * @param properties
     */
    private void getVersionInformationProperties(Properties properties) {
        // put the version information in the properties bag
        properties.put(KEY_VERSION, securityProvider.getVersionInformation());
    }

    /**
     *
     * @param properties
     */
    private void getModeProperties(Properties properties) {
        properties.put(KEY_MODE_DEMO, Boolean.getBoolean(SYS_MODE_DEMO));
    }
}
