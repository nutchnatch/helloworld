package com.ossnms.web.api.security.api.resources.inbound;

import javax.ws.rs.QueryParam;

import static com.ossnms.web.api.security.api.constant.SecurityManagementConstants.PARAMETER_PERMISSION;

/**
 *
 */
public class PermissionParameter {

    @QueryParam(PARAMETER_PERMISSION) private String permission;

    public String getPermission() {
        return permission;
    }

    public String toString(){
        return getPermission();
    }
}
