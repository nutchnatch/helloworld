package com.ossnms.web.api.security.api.resources.inbound;

import javax.ws.rs.FormParam;
import java.io.Serializable;

/**
 *
 */
public class AuthenticationForm implements Serializable{

    private static final long serialVersionUID = 4299928287732009540L;

    @FormParam("username") private String username;
    @FormParam("password") private String password;
    @FormParam("grant-type") private String grantType;

    public AuthenticationForm() {
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getGrantType() {
        return grantType;
    }
}
