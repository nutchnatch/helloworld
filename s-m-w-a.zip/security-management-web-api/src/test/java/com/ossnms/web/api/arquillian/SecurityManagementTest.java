package com.ossnms.web.api.arquillian;

import com.ossnms.web.api.security.filter.CORSResponseFilter;
import com.ossnms.web.api.security.filter.PreMatchingSecurityFilter;
import com.ossnms.web.api.security.filter.SecurityFilter;
import com.ossnms.web.api.security.lookup.BeanLookup;
import com.ossnms.web.api.security.service.AuthenticationServiceImpl;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 *
 */
public abstract class SecurityManagementTest {

    private static Set<Class<?>> classes;
    static {
        classes = new HashSet<>();

        // resource classes
        classes.add(AuthenticationServiceImpl.class);

        // filter classes
        classes.add(SecurityFilter.class);
        classes.add(PreMatchingSecurityFilter.class);
        classes.add(CORSResponseFilter.class);
    }

    protected static String authenticationToken;

    /**
     * Method the will return the test version of the Customer Portal Rest API.
     *
     * @return
     */
    @Deployment(testable = false)
    public static WebArchive createArchive(){
        return ShrinkWrap.create(WebArchive.class)
                .addClass(BaseApplication.class)
                // add required packages
                .addPackages(true, "com.ossnms.web.api.security")
                .addPackages(true, "com.ossnms.web.api.arquillian")
                .deleteClass(BeanLookup.class)
                // add resources
                .addAsWebInfResource("web.xml")
                .addAsWebInfResource("beans.xml")
                .addAsResource("log4j.xml");
    }

    /**
     * URL that holds the base address where the API was deployed
     */
    @ArquillianResource
    protected URL webAppUrl;

    /**
     *
     */
    @ApplicationPath("")
    public static class BaseApplication extends Application {
        @Override
        public Set<Class<?>> getClasses() {
            return classes;
        }
    }
}
