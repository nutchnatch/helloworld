package com.ossnms.web.api.arquillian;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.api.params.Permission;
import com.ossnms.web.provider.security.api.result.PermissionReply;
import com.ossnms.web.provider.security.model.VersionInformation;
import com.ossnms.web.provider.security.operations.SecurityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 */
public class SecurityOperationsMock implements SecurityOperations {

    /**
     *
     */
    private static final Logger LOGGER  = LoggerFactory.getLogger(SecurityOperationsMock.class);

    public SecurityToken login(String s, String s1, String s2) {
        LOGGER.info("Login attempt for {}@{}", s, s2);

        if(s.equals("admin") && s1.equals("admin")){
            return new SecurityToken.Builder("admin", "test-jwt").build();
        }

        return null;
    }

    public SecurityToken validateToken(String s) {
        if(s.equals("test-token")){
            return new SecurityToken.Builder("admin", "test-token").build();
        }

        return null;
    }

    @Override
    public SecurityToken validateToken(SecurityToken securityToken) {
        if(securityToken.getToken().equals("test-token")){
            return securityToken;
        }

        return null;
    }

    public void logout(SecurityToken securityToken) {
        assert securityToken != null && securityToken.getUsername().equals("admin");
    }

    @Override
    public VersionInformation getVersionInformation(SecurityToken securityToken) {
        return new VersionInformation.Builder("TNMS", "16.0.0.0").build();
    }

    @Override
    public PermissionReply hasPermission(SecurityToken securityToken, Permission... permissions) {
        PermissionReply.Builder builder = new PermissionReply.Builder();

        if(securityToken != null && securityToken.getToken().equals("test-token")) {
            for(Permission permission : permissions) {
                if(permission.getPermission().equals("Web->Authentication")) {
                    builder.addPermissionGranted(permission);
                }
            }
        }

        return builder.build();
    }
}
