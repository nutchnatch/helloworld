package com.ossnms.web.api.security.service;

import com.ossnms.web.api.arquillian.SecurityManagementTest;
import com.ossnms.web.api.security.api.resources.outbound.VersionInformation;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Properties;

import static com.ossnms.web.api.security.api.constant.SecurityManagementConstants.HEADER_KEY_WWW_AUTHENTICATE;
import static javax.ws.rs.core.Response.Status.NOT_FOUND;
import static javax.ws.rs.core.Response.Status.OK;
import static javax.ws.rs.core.Response.Status.UNAUTHORIZED;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 *
 */
@RunWith(Arquillian.class)
public class AuthenticationServiceImplTest extends SecurityManagementTest {

    private static final String SYS_MODE_DEMO = "mode.demo";

    @Test
    @InSequence(0)
    public void shouldInjectUrl(){
        assertNotNull(webAppUrl);
    }

    @Test
    @InSequence(1)
    public void shouldNotFind(){
        Response response = ClientBuilder.newClient().target(webAppUrl + "unknown").request().get();
        assertEquals(NOT_FOUND.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(10)
    public void shouldLogin(){
        Form form = new Form();
        form
                .param("username", "admin")
                .param("password", "admin")
                .param("grantType", "grant");

        Entity<Form> formEntity = Entity.form(form);

        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/login")
                .request()
                .post(formEntity);

        assertEquals(OK.getStatusCode(), response.getStatus());
        String jwToken = response.readEntity(String.class);
        assertNotNull(jwToken);

        authenticationToken = jwToken;
        assertTrue(!jwToken.isEmpty());

        SecurityToken securityToken = new SecurityToken.Builder("admin", jwToken).build();
        assertEquals("admin", securityToken.getUsername());
    }

    @Test
    @InSequence(20)
    public void shouldValidateToken(){
        Form form = new Form();
        form
                .param("sessionContext", "test-token");

        Entity<Form> formEntity = Entity.form(form);

        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/token")
                .request()
                .post(formEntity);

        assertEquals(OK.getStatusCode(), response.getStatus());
        String jwToken = response.readEntity(String.class);
        assertNotNull(jwToken);

        authenticationToken = jwToken;
        assertTrue(!jwToken.isEmpty());

        SecurityToken securityToken = new SecurityToken.Builder("admin", jwToken).build();
        assertEquals("admin", securityToken.getUsername());
    }

    @Test
    @InSequence(30)
    public void shouldLogout(){
        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/logout")
                .request()
                .header("Authorization", "Bearer " + authenticationToken)
                .post(Entity.entity("text", MediaType.TEXT_PLAIN));

        assertEquals(OK.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(31)
    public void shouldFailToLogout(){
        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/logout")
                .request()
                .post(Entity.entity("text", MediaType.TEXT_PLAIN));

        assertEquals(UNAUTHORIZED.getStatusCode(), response.getStatus());
        assertNotNull(response.getHeaderString(HEADER_KEY_WWW_AUTHENTICATE));
    }

    @Test
    @InSequence(40)
    public void shouldGetVersionInformation(){
        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/version")
                .request(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + authenticationToken)
                .get();

        assertEquals(OK.getStatusCode(), response.getStatus());
        VersionInformation version = response.readEntity(VersionInformation.class);
        assertNotNull(version);
        assertEquals("TNMS", version.getProduct());
        assertEquals("16.0.0.0", version.getVersion());
    }

    @Test
    @InSequence(41)
    public void shouldGetVersionInformationWithoutAuthorization(){
        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/version")
                .request(MediaType.APPLICATION_JSON)
                .get();

        assertEquals(OK.getStatusCode(), response.getStatus());
        VersionInformation version = response.readEntity(VersionInformation.class);
        assertNotNull(version);
        assertEquals("TNMS", version.getProduct());
        assertEquals("16.0.0.0", version.getVersion());
    }

    @Test
    @InSequence(50)
    public void shouldGetProperties(){
        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/properties")
                .request(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + authenticationToken)
                .get();

        assertEquals(OK.getStatusCode(), response.getStatus());
        Properties properties = response.readEntity(Properties.class);

        assertNotNull(properties);
        assertNotNull(properties.get("VERSION"));
        assertNotNull(properties.getProperty("OIF_LOCATION"));
        assertEquals("localhost", properties.getProperty("OIF_LOCATION"));
        assertFalse((Boolean) properties.get("MODE_DEMO"));
    }

    @Test
    @InSequence(60)
    public void shouldFailToHaveAccess() {
        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/permission")
                .queryParam("permission", "Failure")
                .request(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + authenticationToken)
                .get();

        assertEquals(200, response.getStatus());
    }

    @Test
    @InSequence(61)
    public void shouldHaveAccess() {
        Response response = ClientBuilder.newClient()
                .target(webAppUrl + "security/permission")
                .queryParam("permission", "Web->Authentication,Web->Bogus1,Web->Bogus2")
                .request(MediaType.APPLICATION_JSON)
                .header("Authorization", "Bearer " + authenticationToken)
                .get();

        assertEquals(200, response.getStatus());

        String reply = response.readEntity(String.class);

        assertTrue(reply.contains("Web->Authentication"));
        assertFalse(reply.contains("Web->Bogus1"));
        assertFalse(reply.contains("Web->Bogus2"));
    }
}
