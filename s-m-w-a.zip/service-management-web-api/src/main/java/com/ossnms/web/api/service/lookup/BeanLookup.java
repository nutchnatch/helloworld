package com.ossnms.web.api.service.lookup;

import com.ossnms.web.provider.common.api.facade.EntityOperations;
import com.ossnms.web.provider.service.operations.PathEntityOperations;
import com.ossnms.web.provider.service.operations.ContainerEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Produces;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties;

/**
 *
 */
public class BeanLookup {

    private static final Logger LOGGER = LoggerFactory.getLogger(BeanLookup.class);

    private static final String SERVICE_MANAGER_BEAN_LOOKUP = "ejb:bicnet/CommonServiceList/%s!%s";

    /**
     *
     * @return
     */
    @Produces
    private PathEntityOperations getPathEntityOperations(){
        return getBean(PathEntityOperations.class);
    }

    /**
     *
     * @return
     */
    @Produces
    private ContainerEntityOperations getContainerEntityOperations(){
        return getBean(ContainerEntityOperations.class);
    }

    /**
     *
     * @param entityOperationsClass
     * @return
     */
    private <E extends EntityOperations> E getBean(Class<E> entityOperationsClass) {
        try {

            Object lookup = getContext().lookup(
                    String.format(SERVICE_MANAGER_BEAN_LOOKUP, entityOperationsClass.getSimpleName(), entityOperationsClass.getCanonicalName())
            );

            return (E) lookup;
        } catch (NamingException e) {
            LOGGER.warn("Could not reach remote bean. Falling back to local lookup");
        }

        try{
            return (E) getContext().lookup(entityOperationsClass.getSimpleName());
        } catch (NamingException e) {
            LOGGER.warn("Could not reach local bean. Lookup fails.");
        }

        return null;
    }

    /**
     *
     * @return
     * @throws NamingException
     */
    private Context getContext() throws NamingException{
        final Properties props = new Properties();
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
        // create the InitialString
        return new InitialContext(props);
    }
}
