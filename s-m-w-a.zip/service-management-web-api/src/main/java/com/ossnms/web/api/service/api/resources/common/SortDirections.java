package com.ossnms.web.api.service.api.resources.common;

/**
 *
 */
public enum SortDirections {
    ASC,
    DSC;
}
