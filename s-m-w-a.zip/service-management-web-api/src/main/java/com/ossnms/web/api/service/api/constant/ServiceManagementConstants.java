package com.ossnms.web.api.service.api.constant;

/**
 *
 */
public final class ServiceManagementConstants {

    //Utility class constructor
    private ServiceManagementConstants(){}

    public static final String SERVICE_BASE_URL      = "/network";

    public static final String PATH_BASE_URL         = "/path";
    public static final String PATH_ID_URL           = PATH_BASE_URL + "/{id}";
    public static final String PATH_ID_ALARMS_URL    = PATH_ID_URL + "/alarms";

    public static final String CONTAINER_BASE_URL    = "/container";
    public static final String CONTAINER_ID_URL      = CONTAINER_BASE_URL + "/{id}";
    public static final String CONTAINER_PATH_URL    = CONTAINER_ID_URL + PATH_BASE_URL;

    // inbound parameters
    public static final String DETAILS = "details";
    public static final String FALSE = "false";
    public static final String ID = "id";

    public static final String PAGE_SIZE = "size";
    public static final String PAGE = "page";
    public static final String DEFAULT_PAGE_SIZE = "10";
    public static final String DEFAULT_PAGE_NUMBER = "1";

    public static final String SORT = "sortBy";
    public static final String SORT_DIRECTION = "sortDirection";
    public static final String DEFAULT_SORT = "";
    public static final String DEFAULT_SORT_DIRECTION = "ASC";

    public static final String FILTER = "filterBy";
    public static final String DEFAULT_FILTER = "";
}
