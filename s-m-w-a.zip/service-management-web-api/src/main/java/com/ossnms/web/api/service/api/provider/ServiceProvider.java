package com.ossnms.web.api.service.api.provider;

import com.ossnms.web.api.service.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.service.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.service.api.resources.inbound.PageParameter;
import com.ossnms.web.api.service.api.resources.inbound.SortParameter;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.fault.Alarm;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;

import java.util.List;
import javax.ws.rs.ext.Provider;

/**
 * Interface to be implemented by a class prepared to access the Web Provider API's methods.
 */
@Provider
public interface ServiceProvider {

    /**
     *
     * @param pathId
     * @param details
     * @return
     */
    PathSummary getPathById (String pathId, DetailsParameter details);

    /**
     *
     * @param details
     * @param pagination
     * @param filterBy
     * @param sortBy
     * @return
     */
    OperationResult<? extends PathSummary,PathField> getAllPaths(DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy);

    /**
     *
     * @param containerId
     * @param details
     * @param pagination
     * @param filterBy
     * @param sortBy
     * @return
     */
    OperationResult<? extends PathSummary, PathField> getPathsByContainer(String containerId, DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy);

    /**
     *
     * @param containerId
     * @param details
     * @return
     */
    ContainerSummary getContainerById (String containerId, DetailsParameter details);

    /**
     *
     * @param details
     * @param pagination
     * @param filterBy
     * @param sortBy
     * @return
     */
    OperationResult<? extends ContainerSummary, ContainerField> getAllContainers(DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy);

    /**
     *
     * @param pathId
     * @return
     */
    List<Alarm> getPathAlarms(String pathId);
}
