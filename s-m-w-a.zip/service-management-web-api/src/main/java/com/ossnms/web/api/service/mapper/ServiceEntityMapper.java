package com.ossnms.web.api.service.mapper;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationEntityMapper;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.path.PathSummary;

import java.io.Serializable;

import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.CONTAINER_BASE_URL;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.PATH_BASE_URL;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.SERVICE_BASE_URL;

/**
 *
 */
public class ServiceEntityMapper implements NotificationEntityMapper{

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean accept(Notification notification) {
        if (isNotificationValid(notification)) {
            EntityBase entityBase = notification.getEntity();
            return entityBase != null && (entityBase instanceof ContainerSummary || entityBase instanceof PathSummary);
        }

        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Serializable map(EntityBase entityBase) {
        return entityBase;
    }

    /**
     *
     * @param notification
     * @return
     */
    private boolean isNotificationValid(Notification notification) {
        if(notification == null || notification.getChannel() == null || notification.getEntity() == null) {
            return true;
        }

        // extract relevant parts of the notification instance
        EntityBase entityBase = notification.getEntity();
        NotificationChannel channel = notification.getChannel();
        String channelId = channel.getChannelId();

        if(channelId.startsWith(SERVICE_BASE_URL + PATH_BASE_URL) && entityBase instanceof PathSummary) {
            return true;
        }

        return channelId.startsWith(SERVICE_BASE_URL + CONTAINER_BASE_URL) && entityBase instanceof ContainerSummary;
    }
}
