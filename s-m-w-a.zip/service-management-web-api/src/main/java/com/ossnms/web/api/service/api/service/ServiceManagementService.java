package com.ossnms.web.api.service.api.service;

import com.ossnms.web.api.service.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.service.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.service.api.resources.inbound.PageParameter;
import com.ossnms.web.api.service.api.resources.inbound.SortParameter;

import javax.annotation.security.PermitAll;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.CONTAINER_BASE_URL;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.CONTAINER_ID_URL;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.CONTAINER_PATH_URL;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.ID;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.PATH_BASE_URL;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.PATH_ID_ALARMS_URL;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.PATH_ID_URL;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.SERVICE_BASE_URL;

/**
 * Interface used to implement the endpoints regarding network management.
 */
@Path(SERVICE_BASE_URL)
public interface ServiceManagementService {

    /**
     *
     * @return
     */
    @GET
    @PermitAll
    @Path(PATH_BASE_URL)
    @Produces(MediaType.APPLICATION_JSON)
    Response getAllPaths(
            @BeanParam DetailsParameter detailsParameter,
            @BeanParam PageParameter pageParameter,
            @BeanParam SortParameter sortParameter,
            @BeanParam FilterParameter filterParameter);


    /**
     *
     * @param pathId
     * @return
     */
    @GET
    @PermitAll
    @Path(PATH_ID_URL)
    @Produces(MediaType.APPLICATION_JSON)
    Response getPathById(
            @BeanParam DetailsParameter detailsParameter,
            @PathParam(ID) String pathId
    );

    /**
     *
     * @return
     */
    @GET
    @PermitAll
    @Path(CONTAINER_BASE_URL)
    @Produces(MediaType.APPLICATION_JSON)
    Response getAllContainers(
            @BeanParam DetailsParameter detailsParameter,
            @BeanParam PageParameter parameterBean,
            @BeanParam SortParameter sortParameter,
            @BeanParam FilterParameter filterParameter);

    /**
     *
     * @param containerId
     * @return
     */
    @GET
    @PermitAll
    @Path(CONTAINER_ID_URL)
    @Produces(MediaType.APPLICATION_JSON)
    Response getContainerById(
            @BeanParam DetailsParameter detailsParameter,
            @PathParam(ID) String containerId
    );

    /**
     *
     * @param containerId
     * @param filterParameter
     * @return
     */
    @GET
    @PermitAll
    @Path(CONTAINER_PATH_URL)
    @Produces(MediaType.APPLICATION_JSON)
    Response getPathsByContainer(
            @BeanParam DetailsParameter detailsParameter,
            @PathParam(ID) String containerId,
            @BeanParam PageParameter pageParameter,
            @BeanParam SortParameter sortParameter,
            @BeanParam FilterParameter filterParameter);

    /**
     * It returns the list of alarms to that specified path.
     *
     * @param pathId path which alarms should be retrieved.
     * @return the list of alarms to the specified path.
     */
    @GET
    @PermitAll
    @Path(PATH_ID_ALARMS_URL)
    @Produces(MediaType.APPLICATION_JSON)
    Response getPathAlarms(
            @PathParam(ID) String pathId
    );
}
