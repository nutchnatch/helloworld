package com.ossnms.web.api.service.service;

import com.ossnms.web.api.service.api.provider.ServiceProvider;
import com.ossnms.web.api.service.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.service.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.service.api.resources.inbound.PageParameter;
import com.ossnms.web.api.service.api.resources.inbound.SortParameter;
import com.ossnms.web.api.service.api.service.ServiceManagementService;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.fault.Alarm;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.util.List;

import static javax.ws.rs.core.Response.Status.NOT_FOUND;
import static javax.ws.rs.core.Response.Status.OK;

/**
 * Implementation of endpoints regarding network management.
 */
public class ServiceManagementServiceImpl implements ServiceManagementService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceManagementServiceImpl.class);

    private static final String TAB_MESSAGE = "      ";

    @Inject
    private ServiceProvider serviceProvider;

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getAllPaths(
            DetailsParameter detailsParameter,
            PageParameter pageParameter,
            SortParameter sortParameter,
            FilterParameter filterParameter) {

        debug("Called getAllPaths with parameters:", detailsParameter, pageParameter, sortParameter, filterParameter);

        OperationResult<? extends PathSummary, PathField> result = serviceProvider.getAllPaths(detailsParameter, pageParameter, filterParameter, sortParameter);
        return Response.ok(result).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getPathById(
            DetailsParameter detailsParameter,
            String pathId) {

        PathSummary path = serviceProvider.getPathById(pathId, detailsParameter);

        // if the path is null, we could not find the id specified
        if(path == null){
            return Response.status(NOT_FOUND).build();
        }

        return Response.status(OK).entity(path).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getAllContainers(
            DetailsParameter detailsParameter,
            PageParameter pageParameter,
            SortParameter sortParameter,
            FilterParameter filterParameter) {

        debug("Called getAllContainers with parameters:", detailsParameter, pageParameter, sortParameter, filterParameter);

        OperationResult<? extends ContainerSummary, ContainerField> or = serviceProvider.getAllContainers(detailsParameter, pageParameter, filterParameter, sortParameter);
        return Response.status(OK).entity(or).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getContainerById(
            DetailsParameter detailsParameter,
            String containerId) {

        ContainerSummary container = serviceProvider.getContainerById(containerId, detailsParameter);
        // if the container is null for the id specified, the container is considered not found
        if(container == null){
            return Response.status(NOT_FOUND).build();
        }

        return Response.status(OK).entity(container).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getPathsByContainer(
            DetailsParameter detailsParameter,
            String containerId,
            PageParameter pageParameter,
            SortParameter sortParameter,
            FilterParameter filterParameter) {

        debug("Called getPathsByContainer with parameters:", detailsParameter, pageParameter, sortParameter, filterParameter);

        OperationResult<? extends PathSummary, PathField> or = serviceProvider.getPathsByContainer(containerId, detailsParameter, pageParameter, filterParameter, sortParameter);
        return Response.status(OK).entity(or).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getPathAlarms(String pathId) {

        debug("Called getPathAlarms with parameters:", pathId);

        List<Alarm> alarmList = serviceProvider.getPathAlarms(pathId);

        return Response.status(OK).entity(alarmList).build();
    }

    /**
     * Logs as debug a set of lines, after an initial message
     *
     * @param initialMessage the initial message to log
     * @param lines the lines to add as details
     */
    private void debug(String initialMessage, Object... lines){
        LOGGER.debug(initialMessage);

        for(Object line : lines){
            LOGGER.debug(TAB_MESSAGE + line.toString());
        }
    }
}
