package com.ossnms.web.api.service.provider;

import com.ossnms.web.api.common.provider.BaseProvider;
import com.ossnms.web.api.service.api.provider.ServiceProvider;
import com.ossnms.web.api.service.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.service.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.service.api.resources.inbound.PageParameter;
import com.ossnms.web.api.service.api.resources.inbound.SortParameter;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.filter.FilterOperation;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.params.sort.SortDirection;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.fault.Alarm;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;
import com.ossnms.web.provider.network.model.path.enumerable.PathType;
import com.ossnms.web.provider.service.operations.ContainerEntityOperations;
import com.ossnms.web.provider.service.operations.PathEntityOperations;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.CONTAINS;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.ENDS_WITH;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.EQUALS;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.GREATER_OR_EQUALS;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.GREATER_THAN;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.LESS_OR_EQUALS;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.LESS_THAN;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.SIMILAR;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.STARTS_WITH;

/**
 * {@inheritDoc}
 */
public class ServiceProviderImpl extends BaseProvider implements ServiceProvider{

    @Inject
    private PathEntityOperations pathEntityOperations;

    @Inject
    private ContainerEntityOperations containerEntityOperations;

    /**
     * {@inheritDoc}
     */
    @Override
    public PathSummary getPathById(String pathId, DetailsParameter details) {
        if(details != null && details.isDetails()){
            return pathEntityOperations.getDetails(getSecurityToken(), convertPathId(pathId));
        } else {
            return pathEntityOperations.getSummary(getSecurityToken(), convertPathId(pathId));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<? extends PathSummary, PathField> getAllPaths(DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy) {
        OperationResult<? extends PathSummary, PathField> res;

        boolean isDetails = details != null && details.isDetails();

        Page page = pagination.getPage();
        Sort<PathField> sort = toPathFieldSort(sortBy);
        Collection<Filter<PathField>> filters = toPathFieldFilter(filterBy);

        if(isDetails){
            res = pathEntityOperations.getAll(getSecurityToken(), filters, sort, page);
        } else {
            res = pathEntityOperations.getAllSummary(getSecurityToken(), filters, sort, page);
        }

        if(res == null){
            return new OperationResult.Builder<PathSummary, PathField>(Collections.emptyList() ,0).build();
        }

        return res;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<? extends PathSummary, PathField> getPathsByContainer(String containerId, DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy) {

        Page page = pagination.getPage();
        Sort<PathField> sort = toPathFieldSort(sortBy);
        Collection<Filter<PathField>> filters = toPathFieldFilter(filterBy);

        OperationResult<? extends PathSummary, PathField> res = pathEntityOperations.getPaths(getSecurityToken(), new ContainerID.Builder(Long.parseLong(containerId)).build(), page, sort, filters);

        if(res == null){
            return new OperationResult.Builder<PathSummary, PathField>(Collections.emptyList() ,0).build();
        }

        return res;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ContainerSummary getContainerById(String containerId, DetailsParameter details) {
        boolean isDetails = details != null && details.isDetails();

        if(isDetails){
            return containerEntityOperations.getDetails(getSecurityToken(), new ContainerID.Builder(Long.parseLong(containerId)).build());
        } else {
            return containerEntityOperations.getSummary(getSecurityToken(), new ContainerID.Builder(Long.parseLong(containerId)).build());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<? extends ContainerSummary, ContainerField> getAllContainers(DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy) {
        OperationResult<? extends ContainerSummary, ContainerField> res;

        boolean isDetails = details != null && details.isDetails();

        Page page = pagination.getPage();
        Sort<ContainerField> sort = toContainerFieldSort(sortBy);
        Collection<Filter<ContainerField>> filters = toContainerFieldFilter(filterBy);

        if(isDetails){
            res = containerEntityOperations.getAll(getSecurityToken(), filters, sort, page);
        } else {
            res = containerEntityOperations.getAllSummary(getSecurityToken(), filters, sort, page);
        }

        if(res == null){
            return new OperationResult.Builder<ContainerSummary, ContainerField>(Collections.emptyList() ,0).build();
        }

        return res;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Alarm> getPathAlarms(String pathId) {
        return pathEntityOperations.getPathAlarms(getSecurityToken(), convertPathId(pathId), true, false);
    }


    /**
     *
     * @param pathId
     * @return
     */
    private PathID convertPathId(String pathId){
        String[] pathString = pathId.split("-");

        PathID.Builder ret = new PathID.Builder(Long.parseLong(pathString[1]), PathType.fromName(pathString[0]));

        return ret.build();
    }

    /**
     *
     * @param sortParameter
     * @return
     */
    Sort<PathField> toPathFieldSort(SortParameter sortParameter){
        PathField field = PathField.fromName(sortParameter.getSortBy());
        SortDirection sortDirection = SortDirection.valueOf(sortParameter.getSortDirection().name());

        if(field == null){
            return null;
        }

        return new Sort.Builder<>(field, sortDirection).build();
    }

    /**
     *
     * @param sortParameter
     * @return
     */
    Sort<ContainerField> toContainerFieldSort(SortParameter sortParameter){
        ContainerField field = ContainerField.fromName(sortParameter.getSortBy());
        SortDirection sortDirection = SortDirection.valueOf(sortParameter.getSortDirection().name());

        if(field == null){
            return null;
        }

        return new Sort.Builder<>(field, sortDirection).build();
    }

    /**
     *
     * @param filterParameter
     * @return
     */
    Collection<Filter<PathField>> toPathFieldFilter(FilterParameter filterParameter){
        List<Filter<PathField>> filters = new ArrayList<>();

        if(filterParameter == null || filterParameter.isFilterEmpty()){
            return filters;
        }

        // get the filter criteria
        String filterBy = filterParameter.getFilterBy();
        // split the filter criteria by "AND" (the only supported operation)
        String[] filterArray = filterBy.split("AND");

        for(String filter : filterArray) {
            FilterOperation operation = getFilterOperation(filter);
            String[] ftr = filter.split(Pattern.quote(operation.getOperand()));
            PathField field = PathField.fromName(ftr[0].trim());

            if (field == null) {
                continue;
            }

            filters.add(new Filter.Builder<>(field, operation, ftr[1].trim()).build());
        }

        return filters;
    }

    /**
     *
     * @param filterParameter
     * @return
     */
    Collection<Filter<ContainerField>> toContainerFieldFilter(FilterParameter filterParameter){
        List<Filter<ContainerField>> filters = new ArrayList<>();

        if(filterParameter == null || filterParameter.isFilterEmpty()){
            return filters;
        }

        // get the filter criteria
        String filterBy = filterParameter.getFilterBy();
        // split the filter criteria by "AND" (the only supported operation)
        String[] filterArray = filterBy.split("AND");

        for(String filter : filterArray){
            FilterOperation operation;
            ContainerField field;

            operation = getFilterOperation(filter);

            String[] ftr = filter.split(Pattern.quote(operation.getOperand()));
            field = ContainerField.fromName(ftr[0].trim());

            if(field == null){
                continue;
            }

            filters.add(new Filter.Builder<>(field, operation, ftr[1]).build());
        }

        return filters;
    }

    /**
     *
     * @param filter
     * @return
     */
    private FilterOperation getFilterOperation(String filter) {
        FilterOperation operation;
        if(filter.contains(EQUALS.getOperand())){
            operation = EQUALS;
        } else if(filter.contains(GREATER_THAN.getOperand())){
            operation = GREATER_THAN;
        } else if(filter.contains(LESS_THAN.getOperand())){
            operation = LESS_THAN;
        } else if(filter.contains(GREATER_OR_EQUALS.getOperand())){
            operation = GREATER_OR_EQUALS;
        } else if(filter.contains(LESS_OR_EQUALS.getOperand())){
            operation = LESS_OR_EQUALS;
        } else if(filter.contains(SIMILAR.getOperand())){
            operation = SIMILAR;
        } else if(filter.contains(CONTAINS.getOperand())){
            operation = CONTAINS;
        } else if(filter.contains(STARTS_WITH.getOperand())){
            operation = STARTS_WITH;
        } else {
            operation = ENDS_WITH;
        }
        return operation;
    }
}
