package com.ossnms.web.api.service.api.resources.inbound;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.DETAILS;
import static com.ossnms.web.api.service.api.constant.ServiceManagementConstants.FALSE;

/**
 * Details Parameters.
 */
public class DetailsParameter {

    @DefaultValue(FALSE) @QueryParam(DETAILS) private boolean details;

    public boolean isDetails() {
        return details;
    }

    public String toString(){
        return isDetails() ? "Details enabled" : "Details disabled";
    }
}
