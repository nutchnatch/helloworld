package com.ossnms.web.api.service.service;

import com.ossnms.web.api.arquillian.ServiceManagementTest;
import com.ossnms.web.api.utils.TestConstants;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.ws.rs.core.Response;

import static javax.ws.rs.core.Response.Status.NOT_FOUND;
import static javax.ws.rs.core.Response.Status.OK;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 *
 */
@RunWith(Arquillian.class)
public class ServiceManagementServiceImplTest extends ServiceManagementTest {

    @Test
    @InSequence
    public void shouldInjectUrl(){
        assertNotNull(webAppUrl);
    }

    @Test
    @InSequence(1)
    public void shouldNotFind(){
        Response response = get("unknown");
        assertEquals(NOT_FOUND.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(10)
    public void shouldGetAllContainers(){
        Response response = get("network/container?details=true&page=1&size=10&sortBy=name&sortDirection=DSC");

        assertEquals(OK.getStatusCode(), response.getStatus());
        String res = response.readEntity(String.class);
        assertTrue(res.contains("{\"id\":" + TestConstants.testContainerId + "}"));
    }

    @Test
    @InSequence(20)
    public void shouldGetAllPaths(){
        Response response = get("network/path?details=true");
        assertEquals(OK.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(21)
    public void shouldGetAllPathsWithPagination(){
        Response response = get("network/path?page=3&size=20&details=true");
        assertEquals(OK.getStatusCode(), response.getStatus());
    }


    @Test
    @InSequence(22)
    public void shouldGetAllPathsWithFilter(){
        Response response = get("network/path?filterBy=name eq 'John'");
        assertEquals(OK.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(23)
    public void shouldGetAllPathsWithSort(){
        Response response = get("network/path?sortBy=name&sortDirection=ASC");
        assertEquals(OK.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(24)
    public void shouldGetAllPathsWithAllParameters(){
        Response response = get("network/path?sortBy=name&sortDirection=DSC&details=true&filterBy=name = John&page=3&size=30");
        assertEquals(OK.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(30)
    public void shouldGetContainer(){
        Response response = get("network/container/10?details=true");
        assertEquals(OK.getStatusCode(), response.getStatus());
        String res = response.readEntity(String.class);
        assertTrue(res.contains("{\"id\":" + TestConstants.testContainerId + "}"));
    }

    @Test
    @InSequence(31)
    public void shouldNotGetContainer(){
        Response response = get("network/container/" + TestConstants.ID_CONTAINER_NOT_TO_BE_FOUND_STRING + "?detils=true");
        assertEquals(NOT_FOUND.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(40)
    public void shouldNotGetPath(){
        Response response = get("network/path/" + TestConstants.ID_PATH_NOT_TO_BE_FOUND_STRING + "?details=true");
        assertEquals(NOT_FOUND.getStatusCode(), response.getStatus());
    }
}
