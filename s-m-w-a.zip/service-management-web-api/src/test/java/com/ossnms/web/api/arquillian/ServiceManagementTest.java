package com.ossnms.web.api.arquillian;

import com.ossnms.web.api.service.lookup.BeanLookup;
import com.ossnms.web.api.service.service.ServiceManagementServiceImpl;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 *
 */
public class ServiceManagementTest {

    private static Set<Class<?>> classes;
    static {
        classes = new HashSet<>();

        // resource classes
        classes.add(ServiceManagementServiceImpl.class);
    }

    /**
     * Method the will return the test version of the Customer Portal Rest API.
     *
     * @return
     */
    @Deployment(testable = false)
    public static WebArchive createArchive(){
        return ShrinkWrap.create(WebArchive.class)
                .addClass(BaseApplication.class)
                // add required packages
                .addPackages(true, "com.ossnms.web.api.service")
                .addPackages(true, "com.ossnms.web.api.arquillian")
                .deleteClass(BeanLookup.class)
                // add resources
                .addAsWebInfResource("web.xml")
                .addAsWebInfResource("beans.xml")
                .addAsResource("log4j.xml");
    }

    /**
     * URL that holds the base address where the API was deployed
     */
    @ArquillianResource
    protected URL webAppUrl;

    /**
     *
     */
    @ApplicationPath("")
    public static class BaseApplication extends Application {
        @Override
        public Set<Class<?>> getClasses() {
            return classes;
        }
    }

    /**
     *
     * @param target
     */
    public Response get(String target) {
        return ClientBuilder
                .newClient()
                .register(JacksonJsonProvider.class)
                .target(webAppUrl + target)
                .request()
                .get();
    }


}
