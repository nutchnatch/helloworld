package com.ossnms.web.api.service.provider;

import com.ossnms.web.api.service.api.resources.common.SortDirections;
import com.ossnms.web.api.service.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.service.api.resources.inbound.SortParameter;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;
import org.junit.Test;

import java.util.Collection;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
public class ServiceProviderImplTest {

    private static ServiceProviderImpl provider = new ServiceProviderImpl();

    @Test
    public void shouldParseEqualsFilter(){
        FilterParameter parameter = new FilterParameter("name = John");
        Collection<Filter<PathField>> filters = provider.toPathFieldFilter(parameter);
        assertEquals(1, filters.size());
    }

    @Test
    public void shouldParseContainsFilter(){
        FilterParameter parameter = new FilterParameter("name () John");
        Collection<Filter<PathField>> filters = provider.toPathFieldFilter(parameter);
        assertEquals(1, filters.size());
    }

    @Test
    public void shouldParseStartsWithFilter(){
        FilterParameter parameter = new FilterParameter("name ^ John");
        Collection<Filter<PathField>> filters = provider.toPathFieldFilter(parameter);
        assertEquals(1, filters.size());
    }

    @Test
    public void shouldParseStartsWithContainerFilter(){
        FilterParameter parameter = new FilterParameter("type () SUBSCRIBER");
        Collection<Filter<ContainerField>> filters = provider.toContainerFieldFilter(parameter);
        assertEquals(1, filters.size());
    }

    @Test
    public void shouldParseEqualsPathType(){
        FilterParameter parameter = new FilterParameter("pathType = PATH");
        Collection<Filter<PathField>> filters = provider.toPathFieldFilter(parameter);
        assertEquals(1, filters.size());
    }

    @Test
    public void shouldParseSortByPathType(){
        SortParameter parameter = new SortParameter("pathType", SortDirections.ASC);
        Sort<PathField> sort = provider.toPathFieldSort(parameter);
        assertNotNull(sort);
    }

    @Test
    public void shouldParseSortFilter() {
        SortParameter serviceLevel = new SortParameter("serviceLevel", SortDirections.ASC);
        Sort<ContainerField> containerFieldSort = provider.toContainerFieldSort(serviceLevel);
        assertNotNull(containerFieldSort);
    }
}
