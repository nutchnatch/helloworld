package com.ossnms.web.api.utils;

/**
 *
 */
public class TestConstants {

    public static long testContainerId                      = 10L;
    public static long testPathId                           = 10L;
    public static int totalContainerListSize                = 1;
    public static int totalPathListSize                     = 1;
    public static final long ID_NOT_TO_BE_FOUND             = 1000L;

    public static final String ID_CONTAINER_NOT_TO_BE_FOUND_STRING = "1000";
    public static final String ID_PATH_NOT_TO_BE_FOUND_STRING    = "CALL-1000";

}
