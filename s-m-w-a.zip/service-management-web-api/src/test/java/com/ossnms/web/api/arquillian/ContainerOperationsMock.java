package com.ossnms.web.api.arquillian;

import com.ossnms.web.api.utils.TestConstants;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.container.Container;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.service.operations.ContainerEntityOperations;
import java.util.ArrayList;
import java.util.Collection;


import static com.ossnms.web.api.utils.TestConstants.testContainerId;
import static com.ossnms.web.api.utils.TestConstants.totalContainerListSize;

/**
 *
 */
public class ContainerOperationsMock implements ContainerEntityOperations{

    public ContainerSummary getSummary(SecurityToken securityToken, ContainerID containerID) {
        return null;
    }

    public Container getDetails(SecurityToken securityToken, ContainerID containerID) {

        if(containerID.getId() != TestConstants.ID_NOT_TO_BE_FOUND) {
            return new Container.Builder(new ContainerID.Builder(containerID.getId()).build()).build();
        } else {
            return null;
        }
    }

    public OperationResult<ContainerSummary, ContainerField> getAllSummary(SecurityToken securityToken, Collection<ContainerID> collection) {
        return null;
    }

    public OperationResult<ContainerSummary, ContainerField> getAllSummary(SecurityToken securityToken, Collection<Filter<ContainerField>> collection, Sort<ContainerField> sort, Page page) {
        return null;
    }

    public OperationResult<Container, ContainerField> getAll(SecurityToken securityToken, Collection<ContainerID> collection) {
        return null;
    }

    public OperationResult<Container, ContainerField> getAll(SecurityToken securityToken, Collection<Filter<ContainerField>> filters, Sort<ContainerField> sort, Page page) {
        Collection<Container> collection = new ArrayList<>();
        collection.add(new Container.Builder(new ContainerID.Builder(testContainerId).build()).build());
        return new OperationResult.Builder<Container, ContainerField>(collection, totalContainerListSize).build();
    }

    @Override
    public OperationResult<ContainerID, ContainerField> getAllIds(SecurityToken securityToken, Collection<Filter<ContainerField>> collection, Sort<ContainerField> sort, Page page) {
        return null;
    }

    public ContainerID insert(SecurityToken securityToken, Container container) {
        return null;
    }

    public ContainerID update(SecurityToken securityToken, Container container) {
        return null;
    }

    public void delete(SecurityToken securityToken, ContainerID containerID) {

    }

    @Override
    public ContainerID assignToContainer(SecurityToken token, ContainerID container, PathID path) {
        return null;
    }
}
