package com.ossnms.web.api.arquillian;

import com.ossnms.web.api.utils.TestConstants;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.common.enumerable.ActiveRoute;
import com.ossnms.web.provider.network.model.common.enumerable.ActualCreationState;
import com.ossnms.web.provider.network.model.common.enumerable.AlarmCorrelationMode;
import com.ossnms.web.provider.network.model.common.enumerable.AlarmMask;
import com.ossnms.web.provider.network.model.common.enumerable.ConnectionClass;
import com.ossnms.web.provider.network.model.common.enumerable.ManagedState;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.common.enumerable.RequiredCreationState;
import com.ossnms.web.provider.network.model.common.enumerable.RouteState;
import com.ossnms.web.provider.network.model.common.enumerable.ServiceAdminState;
import com.ossnms.web.provider.network.model.common.enumerable.TransportType;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.fault.Alarm;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.network.enumerable.Direction;
import com.ossnms.web.provider.network.model.path.Path;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;
import com.ossnms.web.provider.network.model.path.enumerable.PathProtection;
import com.ossnms.web.provider.network.model.path.enumerable.PathType;
import com.ossnms.web.provider.service.operations.PathEntityOperations;
import java.sql.Date;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


import static com.ossnms.web.api.utils.TestConstants.testPathId;
import static com.ossnms.web.api.utils.TestConstants.totalPathListSize;

/**
 *
 */
public class PathOperationsMock implements PathEntityOperations {


    public OperationResult<Path, PathField> getPaths(SecurityToken securityToken, ContainerID containerID, Page page, Sort<PathField> sort, Collection<Filter<PathField>> filters) {
        Collection<Path> collection1 = new ArrayList<>();

        Path.Builder path = new Path.Builder(new PathID.Builder(testPathId, PathType.PATH).build());

        path
                .alarmSeverity(AlarmSeverity.CLEARED)
                .operationalState(OperationalState.DISABLED)
                .administrativeState(ServiceAdminState.ENABLED)
                .actualCreationState(ActualCreationState.ACTIVATION_FAILED)
                .requiredCreationState(RequiredCreationState.DISCOVERED)
                .managedState(ManagedState.MANAGED)
                .type("Paths")
                .aNode("A")
                .zNode("Z")
                .protection(PathProtection.DSR)
                .bandwidth("D")
                .lastDisabledTime(Date.from(Instant.EPOCH))
                .description("asd")
                .activeRoute(ActiveRoute.INCOMPLETE)
                .connectionClass(ConnectionClass.FRAGMENT_HALF_OPEN_SNC)
                .routeState(RouteState.ROUTE_MISMATCH)
                .createdBy("Admin")
                .direction(Direction.BIDIRECTIONAL)
                .numberOfNes(2)
                .aPtpTp("String")
                .zPtpTp("String")
                .tpConfiguration("r")
                .layer("String")
                .payloadCLFI("WE")
                .projectId("FD")
                .sVlanId(3)
                .transportType(TransportType.ETHERNET)
                .correlationMode(AlarmCorrelationMode.DISABLED)
                .alarmMask(AlarmMask.ALL_PRIMARY)
                .acknowledgedBy("d")
                .commonContainerId(10L)
                .occupancyAz(4.0f)
                .occupancyZa(4.0f);

        collection1.add(path.build());

        OperationResult<Path, PathField> res = new OperationResult.Builder<Path, PathField>(collection1, totalPathListSize).build();

        return res;
    }

    @Override
    public List<Alarm> getPathAlarms(SecurityToken token, PathID pathID, boolean endpointsOnly, boolean extended) {
        return null;
    }

    public PathSummary getSummary(SecurityToken securityToken, PathID pathID) {
        return null;
    }

    public Path getDetails(SecurityToken securityToken, PathID pathID) {

        if(pathID.getId() != TestConstants.ID_NOT_TO_BE_FOUND) {
            Path.Builder path = new Path.Builder(new PathID.Builder(testPathId, PathType.PATH).build());

            path
                    .alarmSeverity(AlarmSeverity.CLEARED)
                    .operationalState(OperationalState.DISABLED)
                    .administrativeState(ServiceAdminState.ENABLED)
                    .actualCreationState(ActualCreationState.ACTIVATION_FAILED)
                    .requiredCreationState(RequiredCreationState.DISCOVERED)
                    .managedState(ManagedState.MANAGED)
                    .type("Paths")
                    .aNode("A")
                    .zNode("Z")
                    .protection(PathProtection.DSR)
                    .bandwidth("D")
                    .lastDisabledTime(Date.from(Instant.EPOCH))
                    .description("asd")
                    .activeRoute(ActiveRoute.INCOMPLETE)
                    .connectionClass(ConnectionClass.FRAGMENT_HALF_OPEN_SNC)
                    .routeState(RouteState.ROUTE_MISMATCH)
                    .createdBy("Admin")
                    .direction(Direction.BIDIRECTIONAL)
                    .numberOfNes(2)
                    .aPtpTp("String")
                    .zPtpTp("String")
                    .tpConfiguration("r")
                    .layer("String")
                    .payloadCLFI("WE")
                    .projectId("FD")
                    .sVlanId(3)
                    .transportType(TransportType.ETHERNET)
                    .correlationMode(AlarmCorrelationMode.DISABLED)
                    .alarmMask(AlarmMask.ALL_PRIMARY)
                    .acknowledgedBy("d")
                    .commonContainerId(10L)
                    .occupancyAz(4.0f)
                    .occupancyZa(4.0f);

            return path.build();
        } else {
            return null;
        }

    }

    public OperationResult<PathSummary, PathField> getAllSummary(SecurityToken securityToken, Collection<PathID> collection) {
        return null;
    }

    public OperationResult<PathSummary, PathField> getAllSummary(SecurityToken securityToken, Collection<Filter<PathField>> collection, Sort<PathField> sort, Page page) {
        return null;
    }

    public OperationResult<Path, PathField> getAll(SecurityToken securityToken, Collection<PathID> collection) {
        return null;
    }

    public OperationResult<Path, PathField> getAll(SecurityToken securityToken, Collection<Filter<PathField>> collection, Sort<PathField> sort, Page page) {
        return null;
    }

    @Override
    public OperationResult<PathID, PathField> getAllIds(SecurityToken securityToken, Collection<Filter<PathField>> collection, Sort<PathField> sort, Page page) {
        return null;
    }

    public PathID insert(SecurityToken securityToken, Path path) {
        return null;
    }

    public PathID update(SecurityToken securityToken, Path path) {
        return null;
    }

    public void delete(SecurityToken securityToken, PathID pathID) {

    }
}
