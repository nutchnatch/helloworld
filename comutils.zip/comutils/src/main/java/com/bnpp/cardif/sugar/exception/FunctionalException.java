package com.bnpp.cardif.sugar.exception;

/**
 * Exception thrown on Functional issue.
 * 
 * @author 831743
 *
 */
public class FunctionalException extends ApplicationException
{
    private static final long serialVersionUID = -8836304566526326040L;

    /**
     * Empty constructor
     */
    public FunctionalException()
    {
    }

    /**
     * constructor
     * 
     * @param code
     *            ErrorCode
     */
    public FunctionalException(ErrorCode code)
    {
        this(code.getCode(), code.getMessage());
    }

    /**
     * constructor
     * 
     * @param message
     */
    public FunctionalException(String message)
    {
        super(message);
    }

    /**
     * constructor
     * 
     * @param message
     * @param cause
     */
    public FunctionalException(String message, Throwable cause)
    {
        super(message, cause);
    }

    /**
     * constructor
     * 
     * @param code
     * @param message
     */
    public FunctionalException(String code, String message)
    {
        super(code, message, null);
    }

    /**
     * constructor
     * 
     * @param code
     * @param message
     * @param cause
     */
    public FunctionalException(String code, String message, Throwable cause)
    {
        super(code, message, cause);
    }
}
