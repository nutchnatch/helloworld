package com.bnpp.cardif.sugar.exception;

/**
 * Exception thrown on technical issue.
 * 
 * @author 831743
 *
 */
public class TechnicalException extends ApplicationException
{
    private static final long serialVersionUID = 8115200654309086047L;

    /**
     * Empty constructor
     */
    public TechnicalException()
    {
    }

    /**
     * constructor
     * 
     * @param message
     */
    public TechnicalException(String message)
    {
        super(message);
    }

    /**
     * constructor
     * 
     * @param code
     *            ErrorCode
     */
    public TechnicalException(ErrorCode code)
    {
        this(code.getCode(), code.getMessage());
    }

    /**
     * constructor
     * 
     * @param code
     * @param message
     */
    public TechnicalException(String code, String message)
    {
        super(code, message, null);
    }

    /**
     * constructor
     * 
     * @param message
     * @param cause
     */
    public TechnicalException(String message, Throwable cause)
    {
        super(message, cause);
    }

    /**
     * constructor
     * 
     * @param code
     * @param message
     * @param cause
     */
    public TechnicalException(String code, String message, Throwable cause)
    {
        super(code, message, cause);
    }
}
