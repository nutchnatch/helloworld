package com.bnpp.cardif.sugar.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Generic utilities methods.
 * 
 * @author a84252
 */
public class CollectionUtils {
    /**
     * This should should be used in a static way.
     */
    private CollectionUtils() {
    }

    /**
     * Convert an interator in a collection using array list implementation.
     * 
     * @param iterator
     *            the iterator with values
     * @return the collection
     */
    public static <E> List<E> makeCollection(Iterable<E> iterator) {
        List<E> list = new ArrayList<E>();
        if (iterator != null) {
            for (E item : iterator) {
                list.add(item);
            }
        }
        return list;
    }

    public static <E> String collectionToString(List<E> collection) {
        String result = "[";
        if (collection != null) {
            result = result + Arrays.toString(collection.toArray());
        }
        result = result + "]";
        return result;
    }
}
