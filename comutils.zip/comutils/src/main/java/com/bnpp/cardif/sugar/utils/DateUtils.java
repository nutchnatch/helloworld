package com.bnpp.cardif.sugar.utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtils {

    private DateUtils() {
        // empty private constructor to prevent instance creation.
    }

    public static Date asDate(LocalDate localDate) {
        if (localDate == null) {
            return null;
        }
        return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date asDate(org.joda.time.LocalDate localDate) {
        if (localDate == null) {
            return null;
        }
        return localDate.toDate();
    }

    public static Date asDate(LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static Date asDate(org.joda.time.LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        return localDateTime.toDate();
    }

    public static Date asDate(ZonedDateTime localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        return Date.from(localDateTime.toInstant());
    }

    public static LocalDate asLocalDate(Date date) {
        if (date == null) {
            return null;
        }
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static LocalDateTime asLocalDateTime(Date date) {
        if (date == null) {
            return null;
        }
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static org.joda.time.LocalDate asJodaLocalDate(Date date) {
        if (date == null) {
            return null;
        }
        return new org.joda.time.LocalDate(date);
    }

    public static org.joda.time.LocalDateTime asJodaLocalDateTime(Date date) {
        if (date == null) {
            return null;
        }
        return new org.joda.time.LocalDateTime(date);
    }

    public static ZonedDateTime asZonedDateTime(Date date) {
        if (date == null) {
            return null;
        }
        return ZonedDateTime.of(DateUtils.asLocalDateTime(date), ZoneId.systemDefault());
    }

    /**
     * Parse string into ZonedDateTime using format: ISO_OFFSET_DATE_TIME
     * example "2017-12-08T10:37:30+01:00"
     * 
     * @param dateString
     * @return LocalDateTime
     */
    public static ZonedDateTime asZonedDateTimeISO(String dateString) {
        return ZonedDateTime.parse(dateString, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }

    /**
     * Parse string into LocalDateTime using format: "yyyy-MM-dd" adding null
     * time. example "2017-10-26"
     * 
     * @param dateString
     * @return LocalDateTime
     */
    public static LocalDateTime asLocalDateTimeISO(String dateString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate date = LocalDate.parse(dateString, formatter);
        LocalTime time = LocalTime.of(0, 1);
        return LocalDateTime.of(date, time);
    }

    /**
     * Parse string into LocalDate using format: "yyyy-MM-dd" example
     * "2017-10-26"
     * 
     * @param dateString
     * @return LocalDateTime
     */
    public static LocalDate asLocalDateISO(String dateString) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return LocalDate.parse(dateString, formatter);
    }

}
