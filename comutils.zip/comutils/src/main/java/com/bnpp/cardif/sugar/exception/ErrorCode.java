/**
 * 
 */
package com.bnpp.cardif.sugar.exception;

/**
 * @author Eric Le Bail
 *
 */
public enum ErrorCode
{

    TE003("TE003", "Technical Error : "),TE002("TE002", "One result expected and zero returned"),TE001("TE001", "One result expected and many returned"),
    FE007("FE007", "Cannot Update document, no existing document found."),
    FE006("FE006", "Cannot detach a document from a folder : "),FE005("FE005", "Cannot attach a document to a folder : "),FE004("FE004", "Cannot attach a document to a folder that is not Opened"),
    FE003("FE003", "Cannot delete an envelope that is indexed"),FE002("FE002", "A document must have related Data"),FE001("FE001", "Cannot invalidate a document."),
    IIE009("IIE009", "The passed ID doesn't match the expected object"),
    IIE008("IIE008", "Cannot create an object that already got an ID/URI"),IIE007("IIE007", "The passed value have an invalid format : "), 
    IIE006("IIE006", "The passed value must be positive or 0 : "),IIE005("IIE005", "The passed value is not matching the enum of values : "),
    IIE004("IIE004", "Missing input parameter : "),IIE003("IIE003", "Token cannot be null"), IIE002("IIE002", "Email and password cannot be null"),
    IIE001("IIE001", "loginParameters cannot be null");

    private final String code;

    private final String message; // error message

    private ErrorCode(String errorCode, String errorMessage)
    {
        this.code = errorCode;
        this.message = errorMessage;
    }

    /**
     * @return the code
     */
    public String getCode()
    {
        return code;
    }

    /**
     * @return the message
     */
    public String getMessage()
    {
        return message;
    }
}
