package com.ossnms.dcn_manager.identification.ne;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anySetOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NeIdentificationV5Test {

    private static final String ID_NAME = "id-name";
    private static final int VERSION = 1;
    private static final int ID = 1;
    private static final int CHANNEL_ID = 1;

    private NeEntityRepository repository;
    private NeInfoRepository infoRepository;
    private NeOperationRepository operationRepository;
    private NeUserPreferencesRepository preferencesRepository;
    private NeGatewayRoutesRepository gatewayRoutesRepository;
    private NeType type;
    private NeEntity entity;
    private StaticConfiguration staticConfiguration;
    private Types<NeType> types;

    @Before
    public void setUp() throws RepositoryException {
        repository = mock(NeEntityRepository.class);
        operationRepository = mock(NeOperationRepository.class);
        preferencesRepository = mock(NeUserPreferencesRepository.class);
        gatewayRoutesRepository = mock(NeGatewayRoutesRepository.class);
        infoRepository = mock(NeInfoRepository.class);
        staticConfiguration = mock(StaticConfiguration.class);
        types = mock(Types.class);
        type = MockFactory.mockNeType();

        when(operationRepository.queryByRealName(anyString())).thenReturn(Optional.empty());
        when(operationRepository.queryByNeighbourhoodId(anyString())).thenReturn(Optional.empty());
        when(preferencesRepository.query(anyString())).thenReturn(Optional.empty());
        when(preferencesRepository.queryByGlobalId(anyString())).thenReturn(Optional.empty());

        when(repository.getNeOperationRepository()).thenReturn(operationRepository);
        when(repository.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);
        when(repository.getNeGatewayRoutesRepository()).thenReturn(gatewayRoutesRepository);
        when(repository.getNeInfoRepository()).thenReturn(infoRepository);

        when(staticConfiguration.getNeTypes()).thenReturn(types);

        when(type.getProtocol()).thenReturn("TL1");

        entity = new NeEntity(
                new NeConnectionBuilder().build(ID, VERSION),
                new NeOperationBuilder().build(ID, VERSION),
                new NeInfoBuilder()
                    .setProxyType("proxy")
                    .build(ID, CHANNEL_ID, VERSION),
                new NeSynchronizationBuilder().build(ID, VERSION),
                new NeUserPreferencesBuilder()
                    .setName(ID_NAME)
                    .build(ID, VERSION));

        when(repository.queryNe(ID)).thenReturn(Optional.of(entity));
    }

    @Test
    public void findByNeighbourhoodIdAsName() throws Exception {
        final String neighbourhoodId = "sysname";
        final String typeName = "neType 1.0, 2.0, 3.X";
        final String scopeName = "scope";

        when(type.getName()).thenReturn(typeName);
        when(type.getNetworkScope()).thenReturn(scopeName);

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);
        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(preferencesRepository.query(neighbourhoodId)).thenReturn(Optional.of(
            new NeUserPreferencesBuilder()
                .setName(ID_NAME)
                .build(ID, VERSION)
        ));
        when(infoRepository.query(ID)).thenReturn(Optional.of(
            new NeInfoBuilder()
                    .setProxyType(typeName)
                    .build(ID, CHANNEL_ID, VERSION)
        ));

        when(types.get(typeName)).thenReturn(type);

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(present()));
        assertThat(ne.get(), is(entity));
    }

    @Test
    public void findByNeighbourhoodIdAsName_mismatchedType_returnsAbsent() throws Exception {
        final String neighbourhoodId = "sysname";
        final String typeName = "neType 1.0, 2.0, 3.X";
        final String scopeName = "scope";

        when(type.getName()).thenReturn(typeName);
        when(type.getNetworkScope()).thenReturn(scopeName);

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);
        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(preferencesRepository.query(neighbourhoodId)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder()
                        .setName(ID_NAME)
                        .build(ID, VERSION)
        ));
        when(infoRepository.query(ID)).thenReturn(Optional.of(
                new NeInfoBuilder()
                        .setProxyType("otherNeType 1.0")
                        .build(ID, CHANNEL_ID, VERSION)
        ));

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByNeighbourhoodIdAsName_mismatchedScope_returnsAbsent() throws Exception {
        final String neighbourhoodId = "sysname";
        final String typeName = "neType 1.0, 2.0, 3.X";
        final String scopeName = "scope";
        final String otherNeProxyTypeName = "otherNeType 1.0";

        final NeType otherNeType = MockFactory.mockNeType();

        when(type.getName()).thenReturn(typeName);
        when(type.getNetworkScope()).thenReturn(scopeName);

        when(otherNeType.getName()).thenReturn(otherNeProxyTypeName);
        when(otherNeType.getNetworkScope()).thenReturn("other scope");

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);
        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(preferencesRepository.query(neighbourhoodId)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder()
                        .setName(ID_NAME)
                        .build(ID, VERSION)
        ));
        when(infoRepository.query(ID)).thenReturn(Optional.of(
                new NeInfoBuilder()
                        .setProxyType(otherNeProxyTypeName)
                        .build(ID, CHANNEL_ID, VERSION)
        ));

        when(types.get(otherNeProxyTypeName)).thenReturn(otherNeType);

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByNeighbourhoodIdAsName_unknownNeInfo_returnsAbsent() throws Exception {
        final String neighbourhoodId = "sysname";
        final String typeName = "neType 1.0, 2.0, 3.X";

        when(type.getName()).thenReturn(typeName);

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);
        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(preferencesRepository.query(neighbourhoodId)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder()
                        .setName(ID_NAME)
                        .build(ID, VERSION)
        ));
        when(infoRepository.query(ID)).thenReturn(Optional.empty());

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByNeighbourhoodIdAsName_unknownNeName_returnsAbsent() throws Exception {
        final String neighbourhoodId = "sysname";
        final String typeName = "neType 1.0, 2.0, 3.X";

        when(type.getName()).thenReturn(typeName);

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);
        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(preferencesRepository.query(neighbourhoodId)).thenReturn(Optional.empty());

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByNeighbourhoodIdAsName_infoRepoError_returnsAbsent() throws Exception {
        final String neighbourhoodId = "sysname";
        final String typeName = "neType 1.0, 2.0, 3.X";

        when(type.getName()).thenReturn(typeName);

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);
        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(preferencesRepository.query(neighbourhoodId)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder()
                        .setName(ID_NAME)
                        .build(ID, VERSION)
        ));
        when(infoRepository.query(ID)).thenThrow(new RepositoryException());

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByNeighbourhoodIdAsName_preferencesRepoError_returnsAbsent() throws Exception {
        final String neighbourhoodId = "sysname";
        final String typeName = "neType 1.0, 2.0, 3.X";

        when(type.getName()).thenReturn(typeName);

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);
        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(preferencesRepository.query(neighbourhoodId)).thenThrow(new RepositoryException());

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByNeighbourhoodId() throws RepositoryException {
        final String neighbourhoodId = "tid";

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);

        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(operationRepository.queryByNeighbourhoodId(neighbourhoodId)).thenReturn(Optional.of(
                        new NeOperationBuilder()
                            .setNeighbourhoodId(Optional.of(neighbourhoodId))
                            .build(ID, VERSION)));

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(present()));
        assertThat(ne.get(), is(entity));
    }

    @Test
    public void findByNeighbourhoodId_notFound_returnsAbsent() throws RepositoryException {
        final String neighbourhoodId = "tid";

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);

        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(operationRepository.queryByNeighbourhoodId(neighbourhoodId)).thenReturn(Optional.empty());
        when(gatewayRoutesRepository.tryFindRouteKeys(anySetOf(String.class))).thenReturn(Collections.emptySet());

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByNeighbourhoodId_repoError_returnsAbsent() throws RepositoryException {
        final String neighbourhoodId = "tid";

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);

        descriptor.getOperation().setNeighbourhoodId(neighbourhoodId);

        when(operationRepository.queryByNeighbourhoodId(neighbourhoodId)).thenThrow(new RepositoryException());
        when(gatewayRoutesRepository.tryFindRouteKeys(anySetOf(String.class))).thenReturn(Collections.emptySet());

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByRoute() throws RepositoryException {

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);

        descriptor.putGatewayRoutes(Collections.singleton(
                new NeGatewayRouteBuilder().setKey("r1")
        ));

        when(gatewayRoutesRepository.tryFindRouteKeys(anySetOf(String.class))).thenReturn(
                Collections.singleton(Pair.of("r1", ID)));

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, hasValue(entity));
    }

    @Test
    public void findByRoute_notFound_returnsAbsent() throws RepositoryException {

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);

        descriptor.putGatewayRoutes(Collections.singleton(
                new NeGatewayRouteBuilder().setKey("r1")
        ));

        when(gatewayRoutesRepository.tryFindRouteKeys(anySetOf(String.class))).thenReturn(Collections.emptySet());

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void findByRoute_repoError_returnsAbsent() throws RepositoryException {

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);

        descriptor.putGatewayRoutes(Collections.singleton(
                new NeGatewayRouteBuilder().setKey("r1")
        ));

        when(gatewayRoutesRepository.tryFindRouteKeys(anySetOf(String.class))).thenThrow(new RepositoryException());

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));
    }

    @Test
    public void find_noNamesReceived_absent() throws RepositoryException {

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(ID, type);

        prepareFindByName();

        final Optional<NeEntity> ne = new NeIdentificationV5(repository, staticConfiguration).tryIdentifyNe(descriptor);

        assertThat(ne, is(absent()));

        verify(repository, never()).queryNe(anyInt());
    }

    private void prepareFindByName() throws RepositoryException {
        when(preferencesRepository.query(ID_NAME)).thenReturn(Optional.of(
                        new NeUserPreferencesBuilder()
                            .setName(ID_NAME)
                            .build(ID, VERSION)));
    }

}
