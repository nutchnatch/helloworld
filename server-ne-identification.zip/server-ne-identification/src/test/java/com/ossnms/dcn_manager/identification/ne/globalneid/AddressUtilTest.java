package com.ossnms.dcn_manager.identification.ne.globalneid;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.ossnms.dcn_manager.identification.ne.globalneid.AddressUtil;

public class AddressUtilTest {

    @Test
    public void isHexDigit() {
        assertTrue(AddressUtil.isHexDigit("0123456789abcdefABCDEF"));
        assertFalse(AddressUtil.isHexDigit("/0"));
        assertFalse(AddressUtil.isHexDigit("9:"));
        assertFalse(AddressUtil.isHexDigit("@"));
        assertFalse(AddressUtil.isHexDigit("FGa"));
        assertFalse(AddressUtil.isHexDigit("`a"));
        assertFalse(AddressUtil.isHexDigit("g"));
    }

    @Test
    public void convertUnsignedByteToInt() {
        assertThat(AddressUtil.convertUnsignedByteToInt((byte) 5), is(5));
        assertThat(AddressUtil.convertUnsignedByteToInt((byte) 127), is(127));
        assertThat(AddressUtil.convertUnsignedByteToInt((byte) 128), is(128));
        assertThat(AddressUtil.convertUnsignedByteToInt((byte) -1), is(255));
    }
}
