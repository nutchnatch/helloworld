package com.ossnms.dcn_manager.identification.ne.globalneid;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.identification.ne.globalneid.GlobalNeId;
import com.ossnms.dcn_manager.identification.ne.globalneid.GlobalNeIdGenerator;

public class GlobalNeIdTest {

    private static final String NE_TYPE_NAME = "neTypeName";

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void snmpId() {
        String id;

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "1.2.3.4"));
        assertThat(id, is("ZzEuMi4zLjQgICAgICAgICAgICAgoQAE"));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("snmpPort", "321"));
        assertThat(id, is(nullValue()));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "1.2.3.4", "snmpPort", "161"));
        assertThat(id, is("ZzEuMi4zLjQgICAgICAgICAgICAgoQAE"));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "1.2.3.4:999", "snmpPort", "161"));
        assertThat(id,  is("azEuMi4zLjQ6OTk5ICAgICAgICAgoQAE"));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "1.2.3.4:wtf", "snmpPort", "161"));
        assertThat(id,  is("azEuMi4zLjQ6d3RmICAgICAgICAgoQAE"));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "1.2.3.4:999"));
        assertThat(id,  is("azEuMi4zLjQ6OTk5ICAgICAgICAgoQAE"));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "1.2.3.4", "snmpPort", "321"));
        assertThat(id, is("ZzEuMi4zLjQgICAgICAgICAgICAgQQEE"));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "blah blah blah", "snmpPort", "321"));
        assertThat(id, is("bmJsYWggYmxhaCBibGFoICAgICAgQQEE"));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "1.2.3.4", "snmpPort", "blah blah"));
        assertThat(id, is(nullValue()));

        id = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME,
                ImmutableMap.of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "1.2.3.4:99999"));
        assertThat(id, is(nullValue()));
    }

    @Test
    public void rmtId() {
        String id;

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "1.2.3.4"));
        assertThat(id, is("ZzEuMi4zLjQgICAgICAgICAgICAgoQAE"));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.port", "321"));
        assertThat(id, is(nullValue()));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "1.2.3.4", "com.ossnms.mvm.hit7090.port", "161"));
        assertThat(id, is("ZzEuMi4zLjQgICAgICAgICAgICAgoQAE"));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "1.2.3.4:999", "com.ossnms.mvm.hit7090.port", "161"));
        assertThat(id,  is("azEuMi4zLjQ6OTk5ICAgICAgICAgoQAE"));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "1.2.3.4:wtf", "com.ossnms.mvm.hit7090.port", "161"));
        assertThat(id,  is("azEuMi4zLjQ6d3RmICAgICAgICAgoQAE"));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "1.2.3.4:999"));
        assertThat(id,  is("azEuMi4zLjQ6OTk5ICAgICAgICAgoQAE"));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "1.2.3.4", "com.ossnms.mvm.hit7090.port", "321"));
        assertThat(id, is("ZzEuMi4zLjQgICAgICAgICAgICAgQQEE"));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "blah blah blah", "com.ossnms.mvm.hit7090.port", "321"));
        assertThat(id, is("bmJsYWggYmxhaCBibGFoICAgICAgQQEE"));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
            ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "1.2.3.4", "com.ossnms.mvm.hit7090.port", "blah blah"));
        assertThat(id, is(nullValue()));

        id = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME,
                ImmutableMap.of("com.ossnms.mvm.hit7090.ip", "1.2.3.4:99999"));
        assertThat(id, is(nullValue()));
    }

    @Test
    public void tl1Id() {
        String id;

        id = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of("TL1_NE_TARGET_ID", "tid"));
        assertThat(id, is("Y3RpZCAgICAgICAgICAgICAgICAgICAE"));

        id = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of("TL1_NE_TARGET_ID", ""));
        assertThat(id, is(nullValue()));

        id = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.<String, String>of());
        assertThat(id, is(nullValue()));
    }

    /**
     * QST2 protocol NSAP test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdQST2Test() {
        final String id1, id2;

        // 7070
        id1 = GlobalNeId.QST2.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "E02A2D18-CAF9-48FB-8B1E-E2F5D16BEF87/NSAP", "540072872203010046040099",
                "E02A2D18-CAF9-48FB-8B1E-E2F5D16BEF87/TSEL", "QST"));
        assertThat(id1, is("LFQAcociAwEARgQAmSAgICAgICAgCQAC"));

        // 7070
        id2 = GlobalNeId.QST2.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "E02A2D18-CAF9-48FB-8B1E-E2F5D16BEF87/NSAP", "540072872203010046040116",
                "E02A2D18-CAF9-48FB-8B1E-E2F5D16BEF87/TSEL", "QST"));
        assertThat(id2, is("LFQAcociAwEARgQBFiAgICAgICAgCQAC"));

        assertNotSame(id1, id2);
    }

    /**
     * Q3 protocol with IP/Port test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdQ3withIpPortTest() {
        final String id1, id2;

        // 7500
        id1 = GlobalNeId.Q3.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP", "1.1.1.1:10002",
                "369AB9C2-B597-49BA-9190-7D1CEA0C924F/TSEL", "TSEL"));
        assertThat(id1, is("MVQAcociAwAQAQAQARAAIAABICAgAAAD"));

        // 7500
        id2 = GlobalNeId.Q3.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP", "127.0.0.1:1648",
                "369AB9C2-B597-49BA-9190-7D1CEA0C924F/TSEL", "tse"));
        assertThat(id2, is("MVQAcociAxJwAAAAAQFkgAABICAgCAAD"));

        assertNotSame(id1, id2);
    }

    /**
     * Q3 protocol with NSAP test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdQ3NsapTest() {
        final String id1, id2;

        // 7500
        id1 = GlobalNeId.Q3.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP", "540072872203010255130151",
                "369AB9C2-B597-49BA-9190-7D1CEA0C924F/TSEL", "tse"));
        assertThat(id1, is("LFQAcociAwECVRMBUSAgICAgICAgCAAD"));

        // 7500
        id2 = GlobalNeId.Q3.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP", "5400728722030102551301511000200001",
                "369AB9C2-B597-49BA-9190-7D1CEA0C924F/TSEL", "tse"));
        assertThat(id2, is("MVQAcociAwECVRMBURAAIAABICAgCAAD"));

        assertNotSame(id1, id2);
    }

    /**
     * SNMP protocol with IP test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdSNMPTest() {
        final String id1, id2;

        // 7300
        id1 = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "10.46.9.13",
                "snmpPort", "161"));
        assertThat(id1, is("ajEwLjQ2LjkuMTMgICAgICAgICAgoQAE"));

        // 7300
        id2 = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "10.46.9.14",
                "snmpPort", "161"));
        assertThat(id2, is("ajEwLjQ2LjkuMTQgICAgICAgICAgoQAE"));

        assertNotSame(id1, id2);
    }

    /**
     * SNMP protocol with IP/Port test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdSNMPIpPortTest() {
        final String id1, id2;

        // hiT7035
        id1 = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "192.168.20.20:1613"));
        assertThat(id1, is("cjE5Mi4xNjguMjAuMjA6MTYxMyAgoQAE"));

        // hiT7060HC
        id2 = GlobalNeId.SNMP.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "192.168.21.19:3365"));
        assertThat(id2, is("cjE5Mi4xNjguMjEuMTk6MzM2NSAgoQAE"));

        assertNotSame(id1, id2);
    }

    /**
     * RMT protocol with IP test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdRMTTest() {
        final String id1, id2;

        // hiT7090
        id1 = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "com.ossnms.mvm.hit7090.ip", "127.0.0.1",
                "com.ossnms.mvm.hit7090.port", "3333"));
        assertThat(id1, is("aTEyNy4wLjAuMSAgICAgICAgICAgBQ0E"));

        // hiT7090
        id2 = GlobalNeId.RMT.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "com.ossnms.mvm.hit7090.ip", "127.0.0.2",
                "com.ossnms.mvm.hit7090.port", "1611"));
        assertThat(id2, is("aTEyNy4wLjAuMiAgICAgICAgICAgSwYE"));

        assertNotSame(id1, id2);
    }

    /**
     * TL1 protocol TargetId equals test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdTL1Test() {
        // TL7100
        final String id = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "TL1_NE_TARGET_ID", "TL1_ID_NAME"));
        assertThat(id, is("a1RMMV9JRF9OQU1FICAgICAgICAgICAE"));
    }

    /**
     * TL1 protocol Target_ID changed test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdTL1targetIdTest() {
        final String id1, id2;

        // TL7100
        id1 = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "TL1_NE_TARGET_ID", "TL1_ID_NAME_1"));
        assertThat(id1, is("bVRMMV9JRF9OQU1FXzEgICAgICAgICAE"));

        id2 = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "TL1_NE_TARGET_ID", "TL1_ID_NAME_2"));
        assertThat(id2, is("bVRMMV9JRF9OQU1FXzIgICAgICAgICAE"));

        assertNotSame(id1, id2);
    }

    /**
     * TL1 protocol port changed test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdTL1portTest() {
        final String id1, id2;

        // TL7100
        id1 = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "127.0.0.3",
                "TL1_DEFAULT_PORT", "3332",
                "TL1_NE_TARGET_ID", "TL1_ID_NAME_3"));
        assertThat(id1, is("bVRMMV9JRF9OQU1FXzMgICAgICAgICAE"));

        id2 = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "127.0.0.3",
                "TL1_DEFAULT_PORT", "3333",
                "TL1_NE_TARGET_ID", "TL1_ID_NAME_3"));
        assertThat(id2, is("bVRMMV9JRF9OQU1FXzMgICAgICAgICAE"));

        assertEquals(id1, id2);
    }

    /**
     * TL1 protocol with TargetIDs out of #GlobalNeIdGenerator.MAX_RANGE_TL1_DEFAULT test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdTL1TargedIdTest() {
        // TL7100
        final StringBuilder builder = new StringBuilder();
        for (int i = 0; i < GlobalNeIdGenerator.MAX_RANGE_DEFAULT; i++) {
            builder.append(i);
        }
        testTL1Version(builder, "7100 NANO FP8.x");
    }

    private void testTL1Version(StringBuilder builder, String neType) {
        final String globalneid = GlobalNeId.TL1.generateGlobalNeId(neType, ImmutableMap.of(
                "TL1_NE_TARGET_ID", builder.toString()));

        assertNotNull(globalneid);
    }

    /**
     * TL1 protocol with different TargetIDs test.
     *
     * @throws BcbException
     */
    @Test
    public void generateGlobalNeIdTL1OutforMaxRangeTest() {
        final Set<String> globalNeIds = new HashSet<>();

        for (int i = 0; i <= 1000; i++) {
            final String globalNeId = GlobalNeId.TL1.generateGlobalNeId(NE_TYPE_NAME, ImmutableMap.of(
                    "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "127.0.0.1",
                    "TL1_DEFAULT_PORT", "3333",
                    "TL1_NE_TARGET_ID", String.format("TL7100ONE_DNP_LOCAL_%1$1s", i)));
            assertTrue(globalNeIds.add(globalNeId));
        }

        globalNeIds.clear();
    }

}
