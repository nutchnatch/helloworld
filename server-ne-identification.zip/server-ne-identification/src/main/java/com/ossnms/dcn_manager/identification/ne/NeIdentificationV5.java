package com.ossnms.dcn_manager.identification.ne;

import com.google.common.base.Throwables;
import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.google.common.base.Strings.nullToEmpty;

/**
 * Implements the new NE identification method in DCN Manager.
 */
public class NeIdentificationV5 implements NeIdentification {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeIdentificationV5.class);

    private final NeEntityRepository repository;
    private final StaticConfiguration staticConfiguration;

    public NeIdentificationV5(@Nonnull NeEntityRepository repository, @Nonnull StaticConfiguration staticConfiguration) {
        this.repository = repository;
        this.staticConfiguration = staticConfiguration;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Optional<NeEntity> tryIdentifyNe(@Nonnull NeCreateDescriptor createDescriptor) throws RepositoryException {
        final List<Function<NeCreateDescriptor, Optional<Integer>>> matchers =
                ImmutableList.of(
                        this::tryFindByNeighbourhoodId,
                        this::tryFindByRoutes,
                        this::tryFindByNeighbourhoodIdAsNamePerFamily);

        for (Function<NeCreateDescriptor, Optional<Integer>> matcher : matchers) {
            Optional<Integer> existingNeId = matcher.apply(createDescriptor);
            if (existingNeId.isPresent()) {
                return getRepository().queryNe(existingNeId.get());
            }
        }
        return Optional.empty();
    }

    private Optional<Integer> tryFindByNeighbourhoodId(@Nonnull NeCreateDescriptor createDescriptor) {
        final Optional<String> neighbourhoodId = createDescriptor.getOperation().getNeighbourhoodId();
        if (neighbourhoodId.isPresent()) {
            try {
                LOGGER.debug("Trying to find an NE by neighbourhood ID '{}'.", neighbourhoodId.get());
                return getRepository().getNeOperationRepository()
                        .queryByNeighbourhoodId(neighbourhoodId.get()).map(NeOperationData.GET_ID::apply);
            } catch (final RepositoryException exception) {
                LOGGER.error("Error searching for NE with neighbourhood ID '{}': {} {}", neighbourhoodId.get(),
                        exception.getMessage(), Throwables.getStackTraceAsString(exception));
            }
        }
        return Optional.empty();
    }

    private Optional<Integer> tryFindByRoutes(@Nonnull NeCreateDescriptor createDescriptor) {
        final Set<String> routeKeys = createDescriptor.getGatewayRoutes().stream()
                .map(NeGatewayRouteBuilder.GET_ROUTE_KEY).collect(Collectors.toSet());
        try {
            LOGGER.debug("Trying to find an NE by routes {}.", routeKeys);
            return repository.getNeGatewayRoutesRepository().tryFindRouteKeys(routeKeys).stream()
                    .findFirst().map(Pair::getValue);
        } catch (RepositoryException e) {
            LOGGER.error("Error searching for an NE with routes {}: {}",
                    routeKeys, Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    /**
     * <p>Third, last-resort auto-discovery rule to cover this case where NEs have incomplete routes: DCN Manager must
     * assume that the NE ID names in DCN manager (which can be either imported or manually input by the operator)
     * are identical to the Neighbor ID's of NEs <b>in the same network scope</b>. This is always true for AT&T profile;
     * for RoW there's two use cases that apply:</p>
     * <p>
     * <ul>
     * <li>The NE is configured by an XML which is the result of an XML export: The export will contain all the
     * routes so the discovery is on the "route" rule; defaulting to the NE ID name rule can only produce false
     * positives if the XML data is not current relative to the network, which is not a supported use case
     * (XML import is not a migration mechanism).</li>
     * <p>
     * <li>The NE is manually configured with a different route*: this new rule will take effect since neither the
     * GNE route nor the Neighbor ID is necessarily known. The operator must input an NE ID name which is identical
     * to the NE's network name in order to not have duplicates. This should be explicitly stated in the customer
     * documentation.</li>
     * </ul>
     * <p>
     * <p>The network scope is a name defined per NE Type which groups the NE Types that should be deemed equivalent
     * (or, if you prefer, within the same family) when running this kind of discovery. The network scope is not the
     * same as the NE Family, although it may coincide in some cases.</p>
     *
     * @param createDescriptor Creation information for the newly discovered NE.
     * @return The identifier of an existing NE, if any.
     * @see <a href="https://jira.intra.coriant.com/browse/TNMSCM-2661?page=com.atlassian.jira.plugin.system.issuetabpanels:comment-tabpanel&focusedCommentId=1390510#comment-1390510">
     * TNMSCM-2661 comment by David Pontes</a>
     */
    private Optional<Integer> tryFindByNeighbourhoodIdAsNamePerFamily(@Nonnull NeCreateDescriptor createDescriptor) {
        final String networkScope = createDescriptor.getType().getNetworkScope();
        final Optional<String> neighbourhoodId = createDescriptor.getOperation().getNeighbourhoodId();
        if (neighbourhoodId.isPresent()) {
            try {
                LOGGER.debug("Trying to find an NE by ID name equal to neighbourhood ID '{}' and scope '{}' (discovered type='{}').",
                        neighbourhoodId.get(), networkScope, createDescriptor.getTypeName());
                final Optional<NeUserPreferencesData> preferencesOptional =
                        repository.getNeUserPreferencesRepository().query(neighbourhoodId.get());
                if (preferencesOptional.isPresent()) {
                    final Optional<NeInfoData> infoOptional =
                            repository.getNeInfoRepository().query(preferencesOptional.get().getId());
                    if (infoOptional.isPresent() &&
                            networkScope.equalsIgnoreCase(findNetworkScope(infoOptional.get().getProxyType()))) {
                        return Optional.of(infoOptional.get().getNeId());
                    }
                }
            } catch (RepositoryException exception) {
                LOGGER.error("Error searching for NE with ID name equal to neighbourhood ID '{}': {} {}",
                        neighbourhoodId.get(), exception.getMessage(), Throwables.getStackTraceAsString(exception));
            }
        }
        return Optional.empty();
    }

    private String findNetworkScope(String typeName) {
        final NeType neType = staticConfiguration.getNeTypes().get(typeName);
        return nullToEmpty(null != neType ? neType.getNetworkScope() : null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NeEntityRepository getRepository() {
        return repository;
    }
}
