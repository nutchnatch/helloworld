package com.ossnms.dcn_manager.identification.ne.globalneid;

import com.google.common.base.Strings;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Map;

import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * Generates GlobalNeId to protocols which must be unique: IP and Port.
 */
abstract class IpPortGenerator extends GlobalNeIdGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(IpPortGenerator.class);

    private static final int INDEX = 20;
    private static final int _0X_FF = 0xFF;
    private static final int SHIFT_8 = 8;
    private static final int BASE_SHIFT = 96;
    private static final int MAX_PORT_NUMBER = 65536;

    protected abstract String getAddress(Map<String, String> properties);

    protected abstract String getPort(Map<String, String> properties);

    /**
     * Generates GlobalNeId for SNMP and RMT protocols.
     *
     * @param neType
     * @param properties
     * @return
     */
    @Override
    protected String generateGlobalNeId(String protocol, String neType, Map<String, String> properties) {
        LOGGER.debug("generateGlobalNeId::{}::Entry", protocol);

        String globalNeId = null;

        try {
            final String address = getAddress(properties);
            if (Strings.isNullOrEmpty(address)) {
                return null;
            }

            final String port = getPort(properties);

            globalNeId = createGlobalNeIdBased64ForIpPort(address, port);

        } catch (final Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        LOGGER.debug("generateGlobalNeId::{}::Exit", protocol);

        return globalNeId;
    }

    private static final int DEFAULT_PORT = 161;

    /**
     * Creates As Based64 For SNMP
     *
     * @param ip
     * @param port
     * @return string
     * @throws IllegalArgumentException
     * @throws NumberFormatException
     */
    private String createGlobalNeIdBased64ForIpPort(String ip, String port) {

        int index, portInt;
        final String ipString = ip;
        byte[] ipBytes = null;

        final byte[] rawData = new byte[MAX_RANGE_DEFAULT];
        final Base64 encoder = new Base64();

        Arrays.fill(rawData, (byte) INIT_WITH_SPACE_CHAR);

        index = ipString.indexOf(':');
        if (index != -1) {
            try {
                portInt = Integer.parseInt(ipString.substring(index + 1));
                if (portInt > MAX_PORT_NUMBER) {
                    throw new IllegalArgumentException("Port Number is invalid! Must not be higher than 65536.");
                }
            } catch (final NumberFormatException ex) {
                portInt = DEFAULT_PORT;
            }
        } else {
            if (!isNullOrEmpty(port)) {
                portInt = Integer.parseInt(port);
            }
        }

        if (!isNullOrEmpty(port)) {
            portInt = Integer.parseInt(port);
        } else {
            portInt = DEFAULT_PORT;
        }

        ipBytes = convertStringToByteArray(ipString);

        rawData[0] = (byte) (ipBytes.length | BASE_SHIFT);

        System.arraycopy(ipBytes, 0, rawData, 1, ipBytes.length);

        index = INDEX;

        rawData[++index] = (byte) (portInt & _0X_FF);
        rawData[++index] = (byte) (portInt >> SHIFT_8);
        rawData[++index] = ENDOFLINE;

        return new String(encoder.encode(rawData));
    }
}
