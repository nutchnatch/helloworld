package com.ossnms.dcn_manager.identification.ne.globalneid;


import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.StringTokenizer;

/******************************************************************************
 * Convenience class for handling OSI and IP layer 4/7 addresses.
 **/

class AddressUtil {

    private static final int NSAP_IP_LENGTH = 6;

    private static final int NSAP_IP_WITH_PORT_LENGTH = 11;

    private static final int BYTE_MASK = 0xff;

    private static final int HEX_RADIX = 16;

    private static final int NIBBLE_BIT_LENGTH = 4;

    private static final int MAX_NSAP_LENGTH = 40;

    private static final int MAX_UNSIGNED_BYTE = 255;

    private static final int IPv4_SEGMENT_COUNT = 4;

    private static final int LEAST_SIGNIFICANT_NIBBLE = 0xF;

    private static final byte[] RFC1277_PREFIX = { (byte) 0x54, (byte) 0x00, (byte) 0x72, (byte) 0x87, (byte) 0x22,
        (byte) 0x03 };

    private byte[] arrayNSAP = null;
    private String strIP = null;
    private int nPort = -1;

    /**************************************************************************
     * Constructs the object.
     *
     * @param strAddress Address string in one of the supported formats.
     * @throws MalformedURLException
     **************************************************************************/
    public AddressUtil(String strAddress) throws MalformedURLException {
        this(strAddress, ":");
    }

    /**************************************************************************
     * Constructs the object.
     *
     * @param strAddress Address string in one of the supported formats.
     * @param strDelimiter Address token delimiter
     * @throws MalformedURLException
     **************************************************************************/
    public AddressUtil(String strAddress, String strDelimiter) throws MalformedURLException {
        String strToken;

        // Break string into host and port/selectors
        final StringTokenizer tok = new StringTokenizer(strAddress, strDelimiter);
        int nTokensLeft = tok.countTokens();

        // Get host address
        if (nTokensLeft >= 1) {
            strToken = tok.nextToken();
            nTokensLeft--;

            // Parse host address for valid IP
            if (isValidIP(strToken)) {
                strIP = strToken;
            }

            // Parse host address for valid NSAP
            else if (isValidNSAP(strToken)) {
                arrayNSAP = convertHexStringToByteArray(strToken);

                // Generate IP address according to RFC1277
                if (isRfc1277NSAP(arrayNSAP)) {
                    strIP = convertNSAPToIP(arrayNSAP);
                    nPort = convertNSAPToPort(arrayNSAP);
                }
            } else {
                // Invalid format
                throw new MalformedURLException("Invalid NSAP or IP Address");
            }
        } else {
            throw new MalformedURLException("Host Address missing");
        }

        // Get port if unambiguously specified
        if (strIP != null && nTokensLeft == 1) {
            strToken = tok.nextToken();
            nTokensLeft--;

            if (isDigit(strToken)) {
                nPort = Integer.parseInt(strToken);
            } else {
                throw new MalformedURLException("Host Address missing");
            }
        }

        // Generate NSAP according to RFC1277
        if (arrayNSAP == null && strIP != null) {
            arrayNSAP = convertIPToNSAP(strIP, nPort);
        }
    }

    /**************************************************************************
     * Returns the NSAP address (OSI TP4 or RFC1006/1277).
     *
     * @return byte[] NSAP address or null.
     **************************************************************************/

    public final byte[] getNSAP() {
        if (arrayNSAP == null) {
            return null;
        } else {
            return Arrays.copyOf(arrayNSAP, arrayNSAP.length);
        }
    }

    /**************************************************************************
     * Returns the object members as string, mainly for debugging purposes.
     *
     * @return String String containing members.
     **************************************************************************/

    @Override
    public String toString() {
        final StringBuilder str = new StringBuilder();

        str.append("NSAP=");
        str.append(convertByteArrayToHexString(arrayNSAP));

        if (strIP != null) {
            str.append(" IP=");
            str.append(strIP);

            if (nPort != -1) {
                str.append(" Port=");
                str.append(nPort);
            }
        }
        return str.toString();
    }

    /**************************************************************************
     * Returns true if string determines a syntactically valid IP address.
     *
     * @param strIP String to test.
     * @return True if IP address.
     **************************************************************************/

    private static boolean isValidIP(String strIP) {
        final String[] ipNumbers = strIP.split("\\.", -1);

        if (ipNumbers.length == IPv4_SEGMENT_COUNT) {
            for (final String ip : ipNumbers) {
                try {
                    final int nPart = Integer.parseInt(ip);
                    if (nPart < 0 || nPart > MAX_UNSIGNED_BYTE) {
                        return false;
                    }
                } catch (final NumberFormatException nfe) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**************************************************************************
     * Returns true if string determines a syntactically valid IP address and port.
     *
     * @param strIPandPort String to test.
     * @param bPortRequired
     * @return True if IP address.
     **************************************************************************/

    public static boolean isValidIPandPort(String strIPandPort, boolean bPortRequired) {
        String strPart;
        boolean boolResult = false;
        final StringTokenizer tok = new StringTokenizer(strIPandPort, ":");

        if (tok.countTokens() == 2) {
            strPart = tok.nextToken();
            if (isValidIP(strPart)) {
                strPart = tok.nextToken();
                if (isDigit(strPart)) {
                    boolResult = true;
                }
            }
        }

        if (tok.countTokens() == 1 && !bPortRequired) {
            strPart = tok.nextToken();
            if (isValidIP(strPart)) {
                boolResult = true;
            }
        }

        return boolResult;
    }

    /**************************************************************************
     * Returns true if string determines a syntactically valid NSAP address.
     *
     * @param strNSAP String to test.
     * @return True if valid.
     **************************************************************************/

    private static boolean isValidNSAP(String strNSAP) {
        boolean boolResult = false;

        final int nLength = strNSAP.length();
        if (nLength >= 2 && nLength <= MAX_NSAP_LENGTH && (nLength % 2) == 0 && isHexDigit(strNSAP)) {
            boolResult = true;
        }

        return boolResult;
    }

    /**************************************************************************
     * Returns true if given array determines a valid RFC1277 NSAP address (= encoded IP address for use with RFC1006).
     * Accepts RFC1277 NSAPs with and without port/transport set parameter.
     *
     * @param arrayNSAP Array to test.
     * @return True if valid.
     **************************************************************************/

    private static boolean isRfc1277NSAP(byte[] arrayNSAP) {
        boolean boolResult = false;

        // Check length
        final int nLength = RFC1277_PREFIX.length;
        if (arrayNSAP.length == (nLength + NSAP_IP_LENGTH) || arrayNSAP.length == (nLength + NSAP_IP_WITH_PORT_LENGTH) ) {
            // Check prefix
            boolResult = true;
            for (int nByte = 0; nByte < nLength; nByte++) {
                if (arrayNSAP[nByte] != RFC1277_PREFIX[nByte]) {
                    boolResult = false;
                    break;
                }
            }
        }

        return boolResult;
    }

    /**************************************************************************
     * Converts IP address into NSAP address according to RFC1277. The given string must be a valid IP address, use
     * isValidIP() to guarantee this issue.
     *
     * @param strIP String to convert.
     * @param nPort Port or -1 to not include the port.
     * @return NSAP address.
     **************************************************************************/

    private static byte[] convertIPToNSAP(String strIP, int nPort) {
        // Get IP bytes (string is assumed to contain a valid IP address)
        final StringTokenizer tok = new StringTokenizer(strIP, ".");
        final int[] arrayIP = new int[IPv4_SEGMENT_COUNT];
        for (int i = 0; i < IPv4_SEGMENT_COUNT; i++) {
            arrayIP[i] = Integer.parseInt(tok.nextToken());
        }

        // Set length and prefix
        final int nPrefixLength = RFC1277_PREFIX.length;
        final byte[] arrayNSAP = (nPort != -1) ? new byte[nPrefixLength + NSAP_IP_WITH_PORT_LENGTH] : new byte[nPrefixLength + NSAP_IP_LENGTH];
        System.arraycopy(RFC1277_PREFIX, 0, arrayNSAP, 0, nPrefixLength);

        // Set IP bytes
        arrayNSAP[nPrefixLength] = (byte) ((getE2(arrayIP[0]) << NIBBLE_BIT_LENGTH) + getE1(arrayIP[0]));
        arrayNSAP[nPrefixLength + 1] = (byte) ((getE0(arrayIP[0]) << NIBBLE_BIT_LENGTH) + getE2(arrayIP[1]));
        arrayNSAP[nPrefixLength + 2] = (byte) ((getE1(arrayIP[1]) << NIBBLE_BIT_LENGTH) + getE0(arrayIP[1]));
        arrayNSAP[nPrefixLength + 3] = (byte) ((getE2(arrayIP[2]) << NIBBLE_BIT_LENGTH) + getE1(arrayIP[2]));
        arrayNSAP[nPrefixLength + 4] = (byte) ((getE0(arrayIP[2]) << NIBBLE_BIT_LENGTH) + getE2(arrayIP[3]));
        arrayNSAP[nPrefixLength + 5] = (byte) ((getE1(arrayIP[3]) << NIBBLE_BIT_LENGTH) + getE0(arrayIP[3]));

        // Set Port/Transport bytes
        if (nPort != -1) {
            arrayNSAP[nPrefixLength + 6] = (byte) ((getE4(nPort) << NIBBLE_BIT_LENGTH) + getE3(nPort));
            arrayNSAP[nPrefixLength + 7] = (byte) ((getE2(nPort) << NIBBLE_BIT_LENGTH) + getE1(nPort));
            arrayNSAP[nPrefixLength + 8] = (byte) (getE0(nPort) << NIBBLE_BIT_LENGTH);
            arrayNSAP[nPrefixLength + 9] = (byte) 0x00;
            arrayNSAP[nPrefixLength + 10] = (byte) 0x01; /* TCP */
        }

        return arrayNSAP;
    }

    /**************************************************************************
     * Converts NSAP address into IP address according to RFC1277. The given array must be a valid NSAP address
     * according to RFC1277, use isRfc1277NSAP() to guarantee this issue.
     *
     * @param arrayNSAP Array to convert.
     * @return String IP address.
     **************************************************************************/

    private static String convertNSAPToIP(byte[] arrayNSAP) {
        // Get IP bytes (arrayNSAP is assumed to contain a valid RFC1277
        // address)
        final int arrayIP0 = getFromBCD(arrayNSAP, RFC1277_PREFIX.length, false, 3);
        final int arrayIP1 = getFromBCD(arrayNSAP, RFC1277_PREFIX.length + 1, true, 3);
        final int arrayIP2 = getFromBCD(arrayNSAP, RFC1277_PREFIX.length + 3, false, 3);
        final int arrayIP3 = getFromBCD(arrayNSAP, RFC1277_PREFIX.length + 4, true, 3);

        // Format as IP string
        final StringBuilder strIP = new StringBuilder(15);
        strIP.append(arrayIP0);
        strIP.append('.');
        strIP.append(arrayIP1);
        strIP.append('.');
        strIP.append(arrayIP2);
        strIP.append('.');
        strIP.append(arrayIP3);

        return strIP.toString();
    }

    /**************************************************************************
     * Converts NSAP address into port according to RFC1277. The given array must be a valid NSAP address according to
     * RFC1277, use isRfc1277NSAP() to guarantee this issue.
     *
     * @param arrayNSAP Array to convert.
     * @return Port number or -1 if port is not contained in address.
     **************************************************************************/

    private static int convertNSAPToPort(byte[] arrayNSAP) {
        int nPort = -1;

        if (arrayNSAP.length == (RFC1277_PREFIX.length + NSAP_IP_WITH_PORT_LENGTH)) {
            nPort = getFromBCD(arrayNSAP, RFC1277_PREFIX.length + NSAP_IP_LENGTH, false, 5);
        }

        return nPort;
    }

    /**
     * Converts a BCD (Binary Coded Decimal) sequence of digits in a normal java int.
     *
     * @param inBCD The sequence of digits
     * @param indexOfFirstByte The index the array inBCD which has the first interesting digit. If the next parameter
     * @param bStartWithLowerNibble is true, the highest nibble of inBCD[indexOfFirstByte] will be ignored.
     * @param nNumberOfNibbles Number of digits to read.
     * @return the number
     */
    private static int getFromBCD(byte[] inBCD, int indexOfFirstByte, boolean bStartWithLowerNibble, int nNumberOfNibbles) {
        int result = 0;
        int index = indexOfFirstByte;
        boolean lowerNibble = bStartWithLowerNibble;
        for (int iD = 0; iD < nNumberOfNibbles; ++iD) {
            result *= 10;
            if (lowerNibble) {
                result += inBCD[index++] & LEAST_SIGNIFICANT_NIBBLE;
                lowerNibble = false;
            } else {
                result += (inBCD[index] >> NIBBLE_BIT_LENGTH) & LEAST_SIGNIFICANT_NIBBLE;
                lowerNibble = true;
            }
        }
        return result;
    }

    /**************************************************************************
     * Returns the 10E4 (10000) digit of the given number.
     *
     * @param nValue Number to calculate.
     * @return byte 10E4 digit.
     **************************************************************************/

    protected static final int getE4(int nValue) {
        return ((nValue % 100000) / 10000);
    }

    /**************************************************************************
     * Returns the 10E3 (1000) digit of the given number.
     *
     * @param nValue Number to calculate.
     * @return byte 10E3 digit.
     **************************************************************************/

    protected static final int getE3(int nValue) {
        return ((nValue % 10000) / 1000);
    }

    /**************************************************************************
     * Returns the 10E2 (100) digit of the given number.
     *
     * @param nValue Number to calculate.
     * @return 10E2 digit.
     **************************************************************************/

    protected static final int getE2(int nValue) {
        return ((nValue % 1000) / 100);
    }

    /**************************************************************************
     * Returns the 10E1 (10) digit of the given number.
     *
     * @param nValue Number to calculate.
     * @return 10E1 digit.
     **************************************************************************/

    protected static final int getE1(int nValue) {
        return ((nValue % 100) / 10);
    }

    /**************************************************************************
     * Returns the 10E0 (1) digit of the given number.
     *
     * @param nValue Number to calculate.
     * @return 10E0 digit.
     **************************************************************************/

    protected static final int getE0(int nValue) {
        return (nValue % 10);
    }

    /**
     * Converts Hex String to byte array
     *
     * @param str Hex String
     * @return byte array built from Hex String
     * @throws NumberFormatException
     */
    public static byte[] convertHexStringToByteArray(String str) throws NumberFormatException {
        // str is assumed to be a valid hexdump
        final int nSize = str.length() / 2;
        final byte[] array = new byte[nSize];
        for (int nByte = 0; nByte < nSize; nByte++) {
            array[nByte] = Integer.valueOf(str.substring(nByte * 2, (nByte + 1) * 2), HEX_RADIX).byteValue();
        }
        return array;
    }

    /**************************************************************************
     * Converts from byte array to hexdump string.
     *
     * @param array Array to convert.
     * @return Hexdump string.
     **************************************************************************/
    public static String convertByteArrayToHexString(byte[] array) {
        if (array != null) {
            final StringBuilder str = new StringBuilder(array.length * 2);

            for (final byte anArray : array) {
                str.append(formatHex(anArray));
            }

            return str.toString();

        } else {

            return "";

        }
    }

    private static String formatHex(byte bValue) {
        String strResult = null;
        final int nValue = convertUnsignedByteToInt(bValue);

        if (nValue < HEX_RADIX) {
            strResult = '0' + Integer.toHexString(nValue).toUpperCase();
        } else {
            strResult = Integer.toHexString(nValue).toUpperCase();
        }

        return strResult;
    }

    /**************************************************************************
     * Converts unsigned byte to integer value. Values > 127 are handled correctly.
     *
     * @param bValue Unsigned value as byte.
     * @return Unsigned value as int.
     **************************************************************************/
    protected static int convertUnsignedByteToInt(byte bValue) {
        return bValue & BYTE_MASK; // bytes are promoted to integers automatically, just truncate the signal bit extension.
    }

    /**************************************************************************
     * Returns true if string contains digits only. Static helper function.
     *
     * @param str String to test.
     * @return boolean True if only digits.
     **************************************************************************/
    private static boolean isDigit(String str) {
        final int nLength = str.length();
        for (int nChar = 0; nChar < nLength; nChar++) {
            if (!Character.isDigit(str.charAt(nChar))) {
                return false;
            }
        }

        return true;
    }

    /**************************************************************************
     * Returns true if string contains hexadecimal digits only. Static helper function.
     *
     * @param str String to test.
     * @return boolean True if only hexadecimal digits.
     **************************************************************************/
    protected static boolean isHexDigit(String str) {
        final int nLength = str.length();
        for (int nChar = 0; nChar < nLength; nChar++) {
            final char character = str.charAt(nChar);
            final boolean isNotDigit = character < '0' || character > '9';
            final boolean isNotLowercase = character < 'a' || character > 'f';
            final boolean isNotUppercase = character < 'A' || character > 'F';
            if (isNotDigit && isNotLowercase && isNotUppercase) {
                return false;
            }
        }

        return true;
    }

}
