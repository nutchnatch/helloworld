package com.ossnms.dcn_manager.identification.ne.globalneid;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

import static com.google.common.base.Strings.isNullOrEmpty;

class TargetIdGenerator extends GlobalNeIdGenerator {

    private static final int SHIFT_96 = 96;

    private static final Logger LOGGER = LoggerFactory.getLogger(TargetIdGenerator.class);

    private static final int DEFAULT_EDGED = 2;

    protected static final String TL1_PROTOCOL_PROPERTIES = "TL1 NE name";

    /**
     * Generates GlobalNeId for TL1 protocols.
     *
     * @param neType
     * @param properties
     * @return
     */
    @Override
    protected String generateGlobalNeId(String protocol, String neType, Map<String, String> properties) {

        LOGGER.debug("generateGlobalNeId::{}::Entry", protocol);

        String globalNeId = null;

        try {

            final String targetId = properties.get("TL1_NE_TARGET_ID");
            if (isNullOrEmpty(targetId)) {
                LOGGER.error("generateTL1::targetId == null");
                return null;
            }

            globalNeId = createGlobalNeIdBased64ForTargetId(targetId);

        } catch (final Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        LOGGER.debug("generateGlobalNeId::{}::Exit", protocol);

        return globalNeId;
    }

    /**
     * Creates global NE id Based64 For TL1.
     *
     * @param targetId MaxRange 30
     */
    private String createGlobalNeIdBased64ForTargetId(String targetId) {

        final int maxRange = targetId.length() >= (MAX_RANGE_DEFAULT - DEFAULT_EDGED) ? (targetId.length() + DEFAULT_EDGED) : MAX_RANGE_DEFAULT;

        final byte[] rawData = new byte[maxRange];
        final Base64 encoder = new Base64();

        byte[] targetIdBytes = null;

        for (int i = 0; i < maxRange; i++) {
            rawData[i] = INIT_WITH_SPACE_CHAR;
        }

        targetIdBytes = convertStringToByteArray(targetId);
        rawData[0] = (byte) (targetIdBytes.length | SHIFT_96);
        System.arraycopy(targetIdBytes, 0, rawData, 1, targetIdBytes.length);

        rawData[maxRange-1] = ENDOFLINE;

        return new String(encoder.encode(rawData));
    }
}
