package com.bnpp.cardif.sugar.frontend.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AngularController {
    
    /**
     * forward all request to URI "/static**" to the angular controller.
     * 
     * @return String
     */
    @RequestMapping({ "/static/app/**" })
    public String index() {
        return "forward:/static/index.html";
    }

}
