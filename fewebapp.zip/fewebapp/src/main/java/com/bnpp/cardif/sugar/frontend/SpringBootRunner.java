package com.bnpp.cardif.sugar.frontend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication(exclude = {

})
public class SpringBootRunner extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootRunner.class, args);
    }

}
