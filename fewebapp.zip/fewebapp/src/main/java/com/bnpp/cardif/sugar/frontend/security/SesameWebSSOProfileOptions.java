package com.bnpp.cardif.sugar.frontend.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.saml.websso.WebSSOProfileOptions;

/**
 * Customized version of WebSSOProfileOptions to add the following behavior. Add
 * the AttributeConsumingServiceIndex attribute.
 * 
 * @author 831743
 *
 */
public class SesameWebSSOProfileOptions extends WebSSOProfileOptions
{
    /**
     * 
     */
    private static final long serialVersionUID = -1487093883344197910L;

    // Logger
    private static final Logger LOGGER = LoggerFactory.getLogger(SesameWebSSOProfileOptions.class);

    private Integer attributeConsumerIndex;

    /**
     * @return the attributeConsumerIndex
     */
    public Integer getAttributeConsumerIndex()
    {
        return attributeConsumerIndex;
    }

    /**
     * @param attributeConsumerIndex
     *            the attributeConsumerIndex to set
     */
    public void setAttributeConsumerIndex(Integer attributeConsumerIndex)
    {
        LOGGER.debug("setAttributeConsumerIndex : value = " + attributeConsumerIndex);
        this.attributeConsumerIndex = attributeConsumerIndex;
    }

}
