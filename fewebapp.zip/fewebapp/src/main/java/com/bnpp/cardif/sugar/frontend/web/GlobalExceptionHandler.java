package com.bnpp.cardif.sugar.frontend.web;

import java.time.ZonedDateTime;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.bnpp.cardif.sugar.rest.ui.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;

/**
 * Class that handle exception from all the MVC controllers.
 * 
 * @author 831743
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler
{

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Requested URL not found")
    public ModelAndView handleError404(HttpServletRequest request, Exception e)
    {
        // log the error
        LOGGER.error("Request: {} raised {}", request.getRequestURL(), e);
        // then return 404 content
        ModelAndView model = new ModelAndView("404");
        model.addObject("exception", e);
        return model;
    }
    
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<RestResponse<String>> handleHttpMediaTypeNotSupportedException(HttpServletRequest request,
            Exception e) {
        // log the error
        LOGGER.error("Request: {}  raised {}", request.getRequestURL(), e);
        // then return 415 content
        RestResponse<String> restResponse = new RestResponse<>();
        restResponse.setStatus(false);
        ErrorCause errorCause = new ErrorCause();
        errorCause.setCode("415");
        errorCause.setErrorDate(ZonedDateTime.now());
        errorCause.setMessage("Unsupported Media Type : " + e.getMessage());
        restResponse.setError(errorCause);
        return ResponseEntity.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).body(restResponse);
    }
}
