package com.bnpp.cardif.sugar.frontend.security;

import java.io.IOException;
import java.time.ZonedDateTime;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.rest.ui.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The authentication entry point is called when the client makes a call to a
 * resource without proper authentication. In other words, the client has not
 * logged in.
 * 
 * @author 831743
 *
 */
@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(CustomAuthenticationEntryPoint.class);

    @Autowired
    private MappingJackson2HttpMessageConverter springMvcJacksonConverter;

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
            AuthenticationException authException) throws IOException, ServletException {
        RestResponse<String> restResponse = new RestResponse<>();
        restResponse.setStatus(false);
        ErrorCause errorCause = new ErrorCause();
        errorCause.setCode("401");
        errorCause.setErrorDate(ZonedDateTime.now());
        errorCause.setMessage("Access Denied : " + authException.getMessage());
        restResponse.setError(errorCause);

        ObjectMapper objectMapper = springMvcJacksonConverter.getObjectMapper();
        String content = objectMapper.writeValueAsString(restResponse);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Access is denied for request: [" + request.getRequestURI() + "] and queryString ["
                    + request.getQueryString() + "]");
            LOGGER.debug("Send following json response: " + content);
        }

        response.setContentType("application/json;charset=UTF-8");
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.getWriter().print(content);
    }

}
