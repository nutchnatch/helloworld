import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loading-bars',
  templateUrl: './loading-bars.component.html',
  styleUrls: ['./loading-bars.component.scss']
})
export class LoadingBarsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
