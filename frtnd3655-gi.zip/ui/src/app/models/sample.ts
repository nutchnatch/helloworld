
export class Sample {
  id: number;
  identifier: string;
  description: string;
}
