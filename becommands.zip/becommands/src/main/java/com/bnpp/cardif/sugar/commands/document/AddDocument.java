package com.bnpp.cardif.sugar.commands.document;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 17-08-2017.
 */
public class AddDocument<C extends CallContext> extends Command<C, Iterable<Document>> {

    private final DocumentService documentService;
    private final List<Document> documentList;

    public AddDocument(@Nonnull C context, DocumentService documentService, List<Document> documentList) {
        super(context);
        this.documentService = documentService;
        this.documentList = documentList;
    }

    @Override public Iterable<Document> call() throws SugarException {
        return documentService.store(documentList);
    }
}
