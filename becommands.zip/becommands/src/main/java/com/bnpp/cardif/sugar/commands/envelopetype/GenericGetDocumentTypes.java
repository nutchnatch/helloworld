package com.bnpp.cardif.sugar.commands.envelopetype;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

import javax.annotation.Nonnull;

/**
 * Created by b48489 on 17-08-2017.
 */
public class GenericGetDocumentTypes<C extends CallContext> extends Command<C, Iterable<DocumentClass>> {

    private final DocumentClassService documentClassService;
    private final String scope;
    private final Category category;
    private final boolean isActiveOnly;

    public GenericGetDocumentTypes(@Nonnull C context, @Nonnull DocumentClassService documentClassService, @Nonnull String scope,
            @Nonnull Category category,
            boolean isActiveOnly) {
        super(context);
        this.documentClassService = documentClassService;
        this.scope = scope;
        this.category = category;
        this.isActiveOnly = isActiveOnly;
    }

    @Override public Iterable<DocumentClass> call() throws SugarFunctionalException, SugarTechnicalException {
        return documentClassService.search(scope, category, isActiveOnly);
    }
}
