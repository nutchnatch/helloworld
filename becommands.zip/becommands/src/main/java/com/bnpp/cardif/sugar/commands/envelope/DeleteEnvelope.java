package com.bnpp.cardif.sugar.commands.envelope;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 17-08-2017.
 */
public class DeleteEnvelope<C extends CallContext> extends Command<C, List<Document>> {

    private final DocumentService documentService;
    private final List<Id> idList;
    private final String scope;

    public DeleteEnvelope(@Nonnull C context, @Nonnull DocumentService documentService, @Nonnull List<Id> idList, @Nonnull String scope) {
        super(context);
        this.documentService = documentService;
        this.idList = idList;
        this.scope = scope;
    }

    @Override public List<Document> call() throws SugarTechnicalException, SugarFunctionalException {
        return documentService.delete(idList, scope);
    }
}