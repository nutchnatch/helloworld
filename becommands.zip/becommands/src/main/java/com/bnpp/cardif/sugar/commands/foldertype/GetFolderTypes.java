package com.bnpp.cardif.sugar.commands.foldertype;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;

import javax.annotation.Nonnull;

/**
 * Created by b48489 on 02-10-2017.
 */
public class GetFolderTypes<C extends CallContext> extends Command<C, Iterable<FolderClass>>{

    private final FolderClassService folderClassService;
    private final String scope;

    public GetFolderTypes(C context, @Nonnull FolderClassService folderClassService, @Nonnull String scope) {

        super(context);
        this.folderClassService = folderClassService;
        this.scope = scope;
    }

    //TODO- this interface misses pagination
    @Override public Iterable<FolderClass> call() throws SugarFunctionalException, SugarTechnicalException {
        return folderClassService.getAll(scope, true);
    }
}
