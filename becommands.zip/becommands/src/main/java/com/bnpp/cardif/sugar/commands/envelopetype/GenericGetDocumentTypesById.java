package com.bnpp.cardif.sugar.commands.envelopetype;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 17-08-2017.
 */
public class GenericGetDocumentTypesById<C extends CallContext> extends Command<C, Iterable<DocumentClass>> {

    private final DocumentClassService documentClassService;
    private final String scope;
    private final List<ClassId> classIdList;

    public GenericGetDocumentTypesById(@Nonnull C context, @Nonnull DocumentClassService documentClassService, @Nonnull String scope,
            @Nonnull List<ClassId> classIdList) {
        super(context);
        this.documentClassService = documentClassService;
        this.scope = scope;
        this.classIdList = classIdList;
    }

    @Override public Iterable<DocumentClass> call() throws SugarFunctionalException, SugarTechnicalException {
        return documentClassService.get(scope, classIdList);
    }
}
