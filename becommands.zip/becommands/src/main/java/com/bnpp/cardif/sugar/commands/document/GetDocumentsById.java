package com.bnpp.cardif.sugar.commands.document;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 17-08-2017.
 */
public class GetDocumentsById<C extends CallContext> extends Command<C, Iterable<Document>> {

    private final DocumentService documentService;
    private final List<Id> idList;
    private final String scope;

    //TODO - idList should be an Iterable instead of a List
    public GetDocumentsById(@Nonnull C context, DocumentService documentService, List<Id> idList, String scope) {
        super(context);
        this.documentService = documentService;
        this.idList = idList;
        this.scope = scope;
    }

    @Override public Iterable<Document> call() throws SugarFunctionalException, SugarTechnicalException {
        //TODO - Check if isChildrenInclude and isDocumentInclude are true
        return documentService.get(scope, idList, true, false);
    }
}
