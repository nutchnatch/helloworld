package com.bnpp.cardif.sugar.commands.documentfile;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

import java.util.List;

/**
 * Created by b48489 on 29-08-2017.
 */
public class AddDocumentFile<C extends CallContext> extends Command<C, Iterable<DocumentFile>> {

    private DocumentFileService documentFileService;
    private List<DocumentFile> documentFileList;

    public AddDocumentFile(C context, DocumentFileService documentFileService, List<DocumentFile> documentFileList) {
        super(context);
        this.documentFileService = documentFileService;
        this.documentFileList = documentFileList;
    }

    @Override public Iterable<DocumentFile> call() throws SugarTechnicalException, SugarFunctionalException {
        return documentFileService.add(documentFileList);
    }
}
