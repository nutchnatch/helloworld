package com.bnpp.cardif.sugar.commands.foldertype;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 02-10-2017.
 */
public class GetFolderTypesById<C extends CallContext> extends Command<C, Iterable<FolderClass>>{

    private final FolderClassService folderClassService;
    private final List<ClassId> classIdList;
    private final String scope;

    public GetFolderTypesById(C context, @Nonnull FolderClassService folderClassService, @Nonnull String scope,
            @Nonnull List<ClassId> classIdList) {

        super(context);
        this.folderClassService = folderClassService;
        this.scope = scope;
        this.classIdList = classIdList;
    }

    @Override public Iterable<FolderClass> call() throws SugarFunctionalException, SugarTechnicalException {
        return folderClassService.get(classIdList, scope);
    }
}
