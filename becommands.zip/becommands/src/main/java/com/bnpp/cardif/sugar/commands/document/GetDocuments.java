package com.bnpp.cardif.sugar.commands.document;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

import javax.annotation.Nonnull;

/**
 * Created by b48489 on 17-08-2017.
 */
public class GetDocuments<C extends CallContext> extends Command<C, Iterable<Document>> {

    private final DocumentService documentService;
    private final Criteria criteria;
    private final OrderClause orderClause;
    private final int startPage;
    private final int endPage;

    public GetDocuments(@Nonnull C context, @Nonnull DocumentService documentService, Criteria criteria,
            OrderClause orderClause, int startPage, int endPage) {
        super(context);
        this.documentService = documentService;
        this.criteria = criteria;
        this.orderClause = orderClause;
        this.startPage = startPage;
        this.endPage = endPage;
    }

    @Override public Iterable<Document> call() throws SugarFunctionalException, SugarTechnicalException {
        return documentService.find(criteria, orderClause, startPage, endPage).getObjects();
    }
}
