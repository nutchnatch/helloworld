package com.bnpp.cardif.sugar.commands.envelope;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 17-08-2017.
 */
public class AddEnvelope<C extends CallContext> extends Command<C, List<Document>> {

    private final DocumentService documentService;
    private final List<Document> envelopeList;

    public AddEnvelope(@Nonnull C context, @Nonnull DocumentService documentService, @Nonnull List<Document> envelopeList) {
        super(context);
        this.documentService = documentService;
        this.envelopeList = envelopeList;
    }

    @Override public List<Document> call() throws SugarTechnicalException, SugarFunctionalException {
        return documentService.store(envelopeList);
    }
}
