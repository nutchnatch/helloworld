package com.bnpp.cardif.sugar.commands.folder;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 17-08-2017.
 */
public class AddFolder<C extends CallContext> extends Command<C, List<Folder>> {

    private final FolderService folderService;
    private final List<Folder> folderList;

    public AddFolder(@Nonnull C context, @Nonnull FolderService folderService, @Nonnull List<Folder> folderList) {
        super(context);
        this.folderService = folderService;
        this.folderList = folderList;
    }

    @Override public List<Folder> call() throws SugarTechnicalException, SugarFunctionalException {
        return folderService.add(folderList);
    }
}
