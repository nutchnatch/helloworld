package com.bnpp.cardif.sugar.commands.folder;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 17-08-2017.
 */
public class UpdateFolder<C extends CallContext> extends Command<C, Iterable<Folder>> {

    private final FolderService folderService;
    private final List<Folder> folderList;
    private final String scope;

    //TODO - idList should be an Iterable instead of a List
    public UpdateFolder(@Nonnull C context, FolderService folderService, List<Folder> folderList, String scope) {
        super(context);
        this.folderService = folderService;
        this.folderList = folderList;
        this.scope = scope;
    }

    @Override public Iterable<Folder> call() throws SugarFunctionalException, SugarTechnicalException {
        return folderService.update(folderList, scope);
    }
}
