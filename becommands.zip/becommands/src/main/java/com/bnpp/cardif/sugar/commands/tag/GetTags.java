package com.bnpp.cardif.sugar.commands.tag;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import javax.annotation.Nonnull;

/**
 * Created by b48489 on 17-08-2017.
 */
public class GetTags<C extends CallContext> extends Command<C, Iterable<TagClass>> {

    private final TagclassService tagclassService;
    private final String scope;

    public GetTags(@Nonnull C context, @Nonnull TagclassService tagclassService, @Nonnull String scope) {
        super(context);
        this.tagclassService = tagclassService;
        this.scope = scope;
    }

    @Override public Iterable<TagClass> call() throws SugarFunctionalException, SugarTechnicalException {
        return tagclassService.getAll(scope);
    }
}
