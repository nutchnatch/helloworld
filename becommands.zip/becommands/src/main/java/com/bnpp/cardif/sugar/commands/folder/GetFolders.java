package com.bnpp.cardif.sugar.commands.folder;

import com.bnpp.cardif.sugar.commands.Command;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * Created by b48489 on 29-09-2017.
 */
public class GetFolders<C extends CallContext> extends Command<C, Iterable<Folder>> {

    private final FolderService folderService;
    private final Criteria criteria;
    private final OrderClause orderClause;
    private final long startPage;
    private final long endPage;

    public GetFolders(@Nonnull C context, @Nonnull FolderService folderService, Criteria criteria, OrderClause orderClause,
            long startPage, long endPage) {

        super(context);
        this.folderService = folderService;
        this.criteria = criteria;
        this.orderClause = orderClause;
        this.startPage = startPage;
        this.endPage = endPage;
    }

    @Override public Iterable<Folder> call() throws SugarFunctionalException, SugarTechnicalException {
        return folderService.find(criteria, orderClause, startPage, endPage).getObjects();
    }
}
