package com.bnpp.cardif.sugar.commands;

import com.bnpp.cardif.sugar.core.context.CallContext;
import com.bnpp.cardif.sugar.domain.exception.SugarException;

import java.util.concurrent.Callable;

/**
 * Created by b48489 on 17-08-2017.
 */
public abstract class Command<C extends CallContext, T> implements Callable<T> {

    private final C context;

    protected Command(C context) {
        this.context = context;
    }

    public C getContext() {
        return context;
    }

    @Override abstract public T call() throws SugarException;
}
