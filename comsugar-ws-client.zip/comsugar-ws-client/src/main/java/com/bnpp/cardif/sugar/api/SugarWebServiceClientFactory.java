package com.bnpp.cardif.sugar.api;

import javax.xml.ws.BindingProvider;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.SugarAcl;
import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.SugarAcl_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.SugarBasket;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.SugarBasket_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.SugarBusinessScope;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.SugarBusinessScope_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.SugarDocument;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.SugarDocument_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.SugarDocumentAnnotation;
import com.bnpparibas.assurance.sugar.internal.service.app.documentannotation.v1.SugarDocumentAnnotation_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SugarDocumentClass;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SugarDocumentClass_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.SugarDocumentFile;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.SugarDocumentFile_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.SugarFolder;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.SugarFolder_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SugarFolderClass;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SugarFolderClass_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.SugarReporting;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.SugarReporting_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.SugarTagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.SugarTagClass_Service;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.SugarTask;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.SugarTask_Service;

/**
 * Sugar web service client factory. Provides methods to get web service
 * proxies.
 * 
 * @author tc-pearl
 */
@Component
@Scope("singleton")
public class SugarWebServiceClientFactory {
    // Web service clients
    private static SugarDocumentFile_Service sugarDocumentFileService = new SugarDocumentFile_Service();

    private static SugarDocument_Service sugarDocumentService = new SugarDocument_Service();

    private static SugarDocumentAnnotation_Service sugarDocumentAnnotationService = new SugarDocumentAnnotation_Service();

    private static SugarDocumentClass_Service sugarDocumentClassService = new SugarDocumentClass_Service();

    private static SugarBasket_Service sugarBasketService = new SugarBasket_Service();

    private static SugarFolder_Service sugarFolderService = new SugarFolder_Service();

    private static SugarFolderClass_Service sugarFolderClassService = new SugarFolderClass_Service();

    private static SugarTask_Service sugarTaskService = new SugarTask_Service();

    private static SugarTagClass_Service sugarTagClassService = new SugarTagClass_Service();

    private static SugarBusinessScope_Service sugarBusinessScopeService = new SugarBusinessScope_Service();

    private static SugarReporting_Service sugarReportingService = new SugarReporting_Service();

    private static SugarAcl_Service sugarAclService = new SugarAcl_Service();

    @Value("${sugar-web-service.document-file.url}")
    private String sugarDocumentFileEndpointUrl;

    @Value("${sugar-web-service.document.url}")
    private String sugarDocumentEndpointUrl;

    @Value("${sugar-web-service.document-annotation.url}")
    private String sugarDocumentAnnotationEndpointUrl;

    @Value("${sugar-web-service.document-class.url}")
    private String sugarDocumentClassEndpointUrl;

    @Value("${sugar-web-service.basket.url}")
    private String sugarBasketEndpointUrl;

    @Value("${sugar-web-service.folder.url}")
    private String sugarFolderEndpointUrl;

    @Value("${sugar-web-service.folder-class.url}")
    private String sugarFolderClassEndpointUrl;

    @Value("${sugar-web-service.task.url}")
    private String sugarTaskEndpointUrl;

    @Value("${sugar-web-service.tag-class.url}")
    private String sugarTagClassEndpointUrl;

    @Value("${sugar-web-service.business-scope.url}")
    private String sugarBusinessScopeEndpointUrl;

    @Value("${sugar-web-service.reporting.url}")
    private String sugarReportingEndpointUrl;

    @Value("${sugar-web-service.acl.url}")
    private String sugarAclEndpointUrl;

    public SugarWebServiceClientFactory() {
        // Not in use
    }

    /**
     * Get an {@link SugarAcl} web service proxy
     * 
     * @return the proxy client
     */
    public SugarAcl getSugarAclWSP() {
        SugarAcl sugarAcl = sugarAclService.getSugarAcl();
        BindingProvider sugarAclBp = (BindingProvider) sugarAcl;
        sugarAclBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sugarAclEndpointUrl);
        return sugarAcl;
    }

    /**
     * Get an {@link SugarReporting} web service proxy.
     * 
     * @return the proxy client
     */
    public SugarReporting getSugarReportingWSP() {
        SugarReporting sugarReporting = sugarReportingService.getSugarReporting();
        BindingProvider sugarReportingBp = (BindingProvider) sugarReporting;
        sugarReportingBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sugarReportingEndpointUrl);
        return sugarReporting;
    }

    /**
     * Get an {@link SugarBusinessScope} web service proxy.
     * 
     * @return the proxy client
     */
    public SugarBusinessScope getSugarBusinessScopeWSP() {
        SugarBusinessScope sugarBusinessScope = sugarBusinessScopeService.getSugarBusinessScope();
        BindingProvider sugarBusinessScopeBp = (BindingProvider) sugarBusinessScope;
        sugarBusinessScopeBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                sugarBusinessScopeEndpointUrl);
        return sugarBusinessScope;
    }

    /**
     * Get an {@link SugarTagClass} web service proxy.
     * 
     * @return the proxy client
     */
    public SugarTagClass getSugarTagClassWSP() {
        SugarTagClass sugarTagClass = sugarTagClassService.getSugarTagClass();
        BindingProvider sugarTagClassBp = (BindingProvider) sugarTagClass;
        sugarTagClassBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sugarTagClassEndpointUrl);
        return sugarTagClass;
    }

    /**
     * Get an {@link SugarTask} web service proxy.
     * 
     * @return the proxy client
     */
    public SugarTask getSugarTaskWSP() {
        SugarTask sugarTask = sugarTaskService.getSugarTask();
        BindingProvider sugarTaskBp = (BindingProvider) sugarTask;
        sugarTaskBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sugarTaskEndpointUrl);
        return sugarTask;
    }

    /**
     * Get an {@link SugarFolderClass} web service proxy.
     * 
     * @return the proxy
     */
    public SugarFolderClass getSugarFolderClassWSP() {
        SugarFolderClass sugarFolderClass = sugarFolderClassService.getSugarFolderClass();
        BindingProvider sugarFolderClassBp = (BindingProvider) sugarFolderClass;
        sugarFolderClassBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                sugarFolderClassEndpointUrl);
        return sugarFolderClass;
    }

    /**
     * Get an {@link SugarFolder} web service client proxy.
     * 
     * @return the proxy
     */
    public SugarFolder getSugarFolderWSP() {
        SugarFolder sugarFolder = sugarFolderService.getSugarFolder();
        BindingProvider sugarFolderBp = (BindingProvider) sugarFolder;
        sugarFolderBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sugarFolderEndpointUrl);
        return sugarFolder;
    }

    /**
     * Get an {@link SugarBasket} web service client proxy.
     * 
     * @return the proxy
     */
    public SugarBasket getSugarBasketWSP() {
        SugarBasket sugarBasket = sugarBasketService.getSugarBasket();
        BindingProvider sugarBasketBp = (BindingProvider) sugarBasket;
        sugarBasketBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sugarBasketEndpointUrl);
        return sugarBasket;
    }

    /**
     * Get and {@link SugarDocumentClass} web service client proxy.
     * 
     * @return the proxy
     */
    public SugarDocumentClass getSugarDocumentClassWSP() {
        SugarDocumentClass sugarDocumentClass = sugarDocumentClassService.getSugarDocumentClass();
        BindingProvider sugarDocumentClassBp = (BindingProvider) sugarDocumentClass;
        sugarDocumentClassBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                sugarDocumentClassEndpointUrl);
        return sugarDocumentClass;
    }

    /**
     * Get an {@link SugarDocument} web service client proxy.
     * 
     * @return the proxy
     */
    public SugarDocument getSugarDocumentWSP() {
        SugarDocument sugarDocument = sugarDocumentService.getSugarDocument();
        BindingProvider sugarDocumentBp = (BindingProvider) sugarDocument;
        sugarDocumentBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, sugarDocumentEndpointUrl);
        return sugarDocument;
    }

    /**
     * Get an {@link SugarDocumentFile} web service client proxy.
     * 
     * @return the proxy
     */
    public SugarDocumentFile getSugarDocumentFileWSP() {
        SugarDocumentFile sugarDocumentFile = sugarDocumentFileService.getSugarDocumentFile();
        BindingProvider sugarDocumentFileBp = (BindingProvider) sugarDocumentFile;
        sugarDocumentFileBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                sugarDocumentFileEndpointUrl);
        return sugarDocumentFile;
    }

    public String getSugarDocumentFileEndpointUrl() {
        return sugarDocumentFileEndpointUrl;
    }

    /**
     * Get an {@link SugarDocumentAnnotation} web service client proxy.
     * 
     * @return the proxy Instance
     */
    public SugarDocumentAnnotation getSugarDocumentAnnotationWSP() {
        SugarDocumentAnnotation sugarDocumentAnnotation = sugarDocumentAnnotationService.getSugarDocumentAnnotation();
        BindingProvider sugarDocumentAnnotationBp = (BindingProvider) sugarDocumentAnnotation;
        sugarDocumentAnnotationBp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                sugarDocumentAnnotationEndpointUrl);
        return sugarDocumentAnnotation;
    }

    /**
     * Setter for the Endpoint for the Annotations Service
     * 
     * @param sugarDocumentAnnotationEndpointUrl
     *            A string with a full path for the endpoint
     */
    public void setSugarDocumentAnnotationEndpointUrl(String sugarDocumentAnnotationEndpointUrl) {
        this.sugarDocumentAnnotationEndpointUrl = sugarDocumentAnnotationEndpointUrl;
    }

    /**
     * Returns the Endpoint for the Annotations Service
     * 
     * @return
     */
    public String getSugarDocumentAnnotationEndpointUrl() {
        return sugarDocumentAnnotationEndpointUrl;
    }

    public void setSugarDocumentFileEndpointUrl(String sugarDocumentFileEndpointUrl) {
        this.sugarDocumentFileEndpointUrl = sugarDocumentFileEndpointUrl;
    }

    public String getSugarDocumentEndpointUrl() {
        return sugarDocumentEndpointUrl;
    }

    public void setSugarDocumentEndpointUrl(String sugarDocumentEndpointUrl) {
        this.sugarDocumentEndpointUrl = sugarDocumentEndpointUrl;
    }

    public String getSugarDocumentClassEndpointUrl() {
        return sugarDocumentClassEndpointUrl;
    }

    public void setSugarDocumentClassEndpointUrl(String sugarDocumentClassEndpointUrl) {
        this.sugarDocumentClassEndpointUrl = sugarDocumentClassEndpointUrl;
    }

    public String getSugarBasketEndpointUrl() {
        return sugarBasketEndpointUrl;
    }

    public void setSugarBasketEndpointUrl(String sugarBasketEndpointUrl) {
        this.sugarBasketEndpointUrl = sugarBasketEndpointUrl;
    }

    public String getSugarFolderEndpointUrl() {
        return sugarFolderEndpointUrl;
    }

    public void setSugarFolderEndpointUrl(String sugarFolderEndpointUrl) {
        this.sugarFolderEndpointUrl = sugarFolderEndpointUrl;
    }

    public String getSugarFolderClassEndpointUrl() {
        return sugarFolderClassEndpointUrl;
    }

    public void setSugarFolderClassEndpointUrl(String sugarFolderClassEndpointUrl) {
        this.sugarFolderClassEndpointUrl = sugarFolderClassEndpointUrl;
    }

    public String getSugarTaskEndpointUrl() {
        return sugarTaskEndpointUrl;
    }

    public void setSugarTaskEndpointUrl(String sugarTaskEndpointUrl) {
        this.sugarTaskEndpointUrl = sugarTaskEndpointUrl;
    }

    public String getSugarTagClassEndpointUrl() {
        return sugarTagClassEndpointUrl;
    }

    public void setSugarTagClassEndpointUrl(String sugarTagClassEndpointUrl) {
        this.sugarTagClassEndpointUrl = sugarTagClassEndpointUrl;
    }

    public String getSugarBusinessScopeEndpointUrl() {
        return sugarBusinessScopeEndpointUrl;
    }

    public void setSugarBusinessScopeEndpointUrl(String sugarBusinessScopeEndpointUrl) {
        this.sugarBusinessScopeEndpointUrl = sugarBusinessScopeEndpointUrl;
    }

    public String getSugarReportingEndpointUrl() {
        return sugarReportingEndpointUrl;
    }

    public void setSugarReportingEndpointUrl(String sugarReportingEndpointUrl) {
        this.sugarReportingEndpointUrl = sugarReportingEndpointUrl;
    }

    public String getSugarAclEndpointUrl() {
        return sugarAclEndpointUrl;
    }

    public void setSugarAclEndpointUrl(String sugarAclEndpointUrl) {
        this.sugarAclEndpointUrl = sugarAclEndpointUrl;
    }
}
