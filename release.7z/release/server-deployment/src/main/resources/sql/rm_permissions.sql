-- Add permission Items
BEGIN
  DECLARE
    addPermissionItemVar NUMBER;
  BEGIN
    addPermissionItemVar := USMPERMISSIONITEMADD('Administration->System Preferences->Network Inventory', 'Network Inventory Export Settings');
    addPermissionItemVar := USMPERMISSIONITEMADD('Reports->Export Inventory Data', 'Export Inventory Data');
    addPermissionItemVar := USMPERMISSIONITEMADD('Reports->Export Configuration Data', 'Export Configuration Data');
	addPermissionItemVar := USMPERMISSIONITEMADD('Reports->Alarms Outage Data', 'Alarms Outage Data');
	addPermissionItemVar := USMPERMISSIONITEMADD('Reports->DCN List', 'DCN List');
	addPermissionItemVar := USMPERMISSIONITEMADD('Reports->Alarm Messaging', 'Alarm Messaging');
  END;
END;
/
BEGIN
  DECLARE
    vboolean BOOLEAN;
  BEGIN
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Administration->System Preferences->Network Inventory');
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->Export Inventory Data');
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->Export Configuration Data');
	vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->Alarms Outage Data');
	vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->DCN List');
	vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->Alarm Messaging');
  END;
END;
/
