-- Add permission Items
BEGIN
  DECLARE
    addPermissionItemVar NUMBER;
  BEGIN
	addPermissionItemVar := USMPERMISSIONITEMADD('Reports->Alarms Outage Data', 'Alarms Outage Data');
  END;
END;
/
BEGIN
  DECLARE
    vboolean BOOLEAN;
  BEGIN
	vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->Alarms Outage Data');
  END;
END;
/