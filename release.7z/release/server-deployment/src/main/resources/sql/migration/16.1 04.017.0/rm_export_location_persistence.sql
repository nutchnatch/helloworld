CREATE OR REPLACE FUNCTION tableExists(tableName IN VARCHAR2) RETURN BOOLEAN IS
  c number := 0;
  BEGIN
    Select count(*) into c
    from user_tables
    where table_name = tableName;

    if (c = 1) then
      return true;
    end if;
    return false;
  END tableExists;
/


BEGIN
  IF NOT tableExists('RM_EXPORT_LOCATION') THEN
    execute immediate 'CREATE TABLE RM_EXPORT_LOCATION (
  EXPORT_ID               VARCHAR2(255 CHAR) NOT NULL,
  EXPORT_LOCATION         VARCHAR2(255 CHAR) NOT NULL,
  KEEP_LOCAL              NUMBER(1) NOT NULL,
  CONSTRAINT RM_EXPORT_LOCATION_PK PRIMARY KEY (EXPORT_ID) USING INDEX TABLESPACE GEN_IDX)';
  END IF;
END;
/