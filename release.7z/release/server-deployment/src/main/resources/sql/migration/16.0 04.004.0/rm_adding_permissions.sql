--Export Configuration Permission
BEGIN
   DECLARE
   permitionCount number;

   BEGIN

     SELECT COUNT(*) INTO permitionCount FROM USM_PERMISSION_ITEM WHERE NAME = 'Reports->Export Configuration Data';

     IF permitionCount <= 0 THEN

       BEGIN
          DECLARE
            addPermissionItemVar NUMBER;
          BEGIN
            addPermissionItemVar := USMPERMISSIONITEMADD('Reports->Export Configuration Data', 'Export Configuration Data');
          END;
      END;

      BEGIN
        DECLARE
          vboolean BOOLEAN;
        BEGIN
          vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->Export Configuration Data');
        END;
      END;

     END IF;

   END;
 END;
 /

--DCN List Permission
BEGIN
   DECLARE
   permitionCount number;

   BEGIN

     SELECT COUNT(*) INTO permitionCount FROM USM_PERMISSION_ITEM WHERE NAME = 'Reports->DCN List';

     IF permitionCount <= 0 THEN

       BEGIN
          DECLARE
            addPermissionItemVar NUMBER;
          BEGIN
            addPermissionItemVar := USMPERMISSIONITEMADD('Reports->DCN List', 'DCN List');
          END;
      END;

      BEGIN
        DECLARE
          vboolean BOOLEAN;
        BEGIN
          vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->DCN List');
        END;
      END;

     END IF;

   END;
 END;
 /

 commit;