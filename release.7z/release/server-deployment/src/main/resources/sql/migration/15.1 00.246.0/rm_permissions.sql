-- Add permission Items
BEGIN
  DECLARE
    addPermissionItemVar NUMBER;
  BEGIN
    addPermissionItemVar := USMPERMISSIONITEMADD('Administration->System Preferences->Network Inventory', 'Network Inventory Export Settings');
  END;
END;
/
BEGIN
  DECLARE
    vboolean BOOLEAN;
  BEGIN
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Administration->System Preferences->Network Inventory');
  END;
END;
/
