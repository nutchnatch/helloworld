-- Add permission Items
BEGIN
  DECLARE
    addPermissionItemVar NUMBER;
  BEGIN
    addPermissionItemVar := USMPERMISSIONITEMADD('Reports->Export Configuration Data', 'Export Configuration Data');
  END;
END;
/
BEGIN
  DECLARE
    vboolean BOOLEAN;
  BEGIN
    vboolean := USMPERMISSIONITEMASSIGN('Network Configuration', 'Reports->Export Configuration Data');
  END;
END;
/
