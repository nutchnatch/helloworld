-- Allows to verify if a some some column exists in some table
CREATE OR REPLACE FUNCTION columnExists(tableName IN VARCHAR2, columnName IN VARCHAR2) RETURN BOOLEAN IS 
  v_column_exists number := 0;  
BEGIN
  Select count(*) into v_column_exists
    from user_tab_cols
    where table_name = tableName
      and column_name = columnName;
      
  if (v_column_exists <> 0) then
      return true;
  end if;
  return false;
END columnExists;
/

BEGIN
  IF columnExists('RM_SETTINGS','RETENTION_NUMBER') THEN
	 execute immediate 'ALTER TABLE RM_SETTINGS RENAME COLUMN RETENTION_NUMBER TO INVENTORY_RETENTION';
  END IF;
END;
/

BEGIN
  IF NOT columnExists('RM_SETTINGS','CONFIGURATION_RETENTION') THEN
	 execute immediate 'ALTER TABLE RM_SETTINGS ADD CONFIGURATION_RETENTION NUMBER(19, 0) DEFAULT 90 NOT NULL';
  END IF;
END;
/

commit;
