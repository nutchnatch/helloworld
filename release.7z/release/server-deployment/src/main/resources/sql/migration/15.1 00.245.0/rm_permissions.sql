-- Add permission Items
BEGIN
	DECLARE
		addPermissionItemVar NUMBER;
	BEGIN
    	addPermissionItemVar := USMPERMISSIONITEMADD('Reports->Export Inventory Data','Export Inventory Data');
	END;
END;
/
BEGIN
	DECLARE
		vboolean BOOLEAN;
	BEGIN
		vboolean := USMPERMISSIONITEMASSIGN('Network Configuration','Reports->Export Inventory Data');
	END;
END;
/
