package com.bnpp.cardif.yourapplication.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.bnpp.cardif.yourapplication.beans.Sample;
import com.bnpp.cardif.yourapplication.exception.TechnicalException;
import com.bnpp.cardif.yourapplication.frontend.beans.JSONSample;

/**
 * Unit tests for {@link SampleServiceImpl}
 * 
 * 
 * @author Andre Macedo
 */
public class SampleServiceImplTest
{
    public static final String ENDPOINT_URL_CREATE = "/create";

    public static final String ENDPOINT_URL_READ = "/read/";

    public static final String ENDPOINT_LIST = "/list";

    private static final Logger LOGGER = LoggerFactory.getLogger(SampleServiceImplTest.class);

    @Test
    public void testDeleteByList()
    {
        try
        {
            SampleServiceImpl sampleServiceImpl = spy(new SampleServiceImpl());
            RestTemplate restTemplate = mock(RestTemplate.class);

            String backendEndPointUrl = UUID.randomUUID().toString();
            when(sampleServiceImpl.getBackendEndpointUrl()).thenReturn(backendEndPointUrl);
            when(sampleServiceImpl.getRestTemplate()).thenReturn(restTemplate);

            // doNothing().when(sampleServiceImpl).delete(any(JSONSample.class));
            doNothing().when(sampleServiceImpl).delete(any(Long.class));

            List<JSONSample> sampleList = new ArrayList<JSONSample>();
            sampleList.add(createJSONSample(null));
            sampleList.add(createJSONSample(null));
            sampleList.add(createJSONSample(null));
            sampleList.add(createJSONSample(null));
            sampleList.add(createJSONSample(null));
            sampleList.add(createJSONSample(null));

            sampleServiceImpl.delete(sampleList);

            for (JSONSample jsonSample : sampleList)
            {
                verify(sampleServiceImpl, times(1)).delete(jsonSample.getId());
            }
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testDeleteByList", tex);
            Assert.fail("Error testing testDeleteByList : " + tex);
        }
    }

    @Test
    public void testDeleteByJSONSample()
    {
        try
        {
            SampleServiceImpl sampleServiceImpl = spy(new SampleServiceImpl());
            RestTemplate restTemplate = mock(RestTemplate.class);

            String backendEndPointUrl = UUID.randomUUID().toString();
            when(sampleServiceImpl.getBackendEndpointUrl()).thenReturn(backendEndPointUrl);
            when(sampleServiceImpl.getRestTemplate()).thenReturn(restTemplate);

            JSONSample sampleRequest = createJSONSample(null);

            doNothing().when(sampleServiceImpl).delete(sampleRequest.getId());

            sampleServiceImpl.delete(sampleRequest);

            verify(sampleServiceImpl, times(1)).delete(sampleRequest.getId());
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testDeleteByJSONSample", tex);
            Assert.fail("Error testing testDeleteByJSONSample : " + tex);
        }
    }

    @Test
    public void testFindAllByListIds() throws TechnicalException
    {
        try
        {
            SampleServiceImpl sampleServiceImpl = spy(new SampleServiceImpl());
            RestTemplate restTemplate = mock(RestTemplate.class);

            String backendEndPointUrl = UUID.randomUUID().toString();
            when(sampleServiceImpl.getBackendEndpointUrl()).thenReturn(backendEndPointUrl);
            when(sampleServiceImpl.getRestTemplate()).thenReturn(restTemplate);

            doReturn(new JSONSample()).when(sampleServiceImpl).findOne(any(Long.class));

            Random random = new Random();
            List<Long> idList = new ArrayList<Long>();
            idList.add(random.nextLong());
            idList.add(random.nextLong());
            idList.add(random.nextLong());
            idList.add(random.nextLong());

            List<JSONSample> findAll = sampleServiceImpl.findAll(idList);

            assertNotNull(findAll);
            assertEquals(idList.size(), findAll.size());

            for (Long id : idList)
            {
                verify(sampleServiceImpl, times(1)).findOneEntity(id);
            }
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testFindAllByListIds", tex);
            Assert.fail("Error testing testFindAllByListIds : " + tex);
        }
    }

    @Test
    public void testFindAll()
    {
        try
        {
            SampleServiceImpl sampleServiceImpl = spy(new SampleServiceImpl());
            RestTemplate restTemplate = mock(RestTemplate.class);

            String backendEndPointUrl = UUID.randomUUID().toString();
            when(sampleServiceImpl.getBackendEndpointUrl()).thenReturn(backendEndPointUrl);
            when(sampleServiceImpl.getRestTemplate()).thenReturn(restTemplate);

            when(restTemplate.exchange(eq(backendEndPointUrl + ENDPOINT_LIST), eq(HttpMethod.GET), any(HttpEntity.class), eq(List.class))).thenReturn(null);

            sampleServiceImpl.findAll();

            verify(restTemplate, times(1)).exchange(eq(backendEndPointUrl + ENDPOINT_LIST), eq(HttpMethod.GET), any(HttpEntity.class), eq(List.class));
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testFindAll", tex);
            Assert.fail("Error testing testFindAll : " + tex);
        }
    }

    @Test
    public void testFindOneAndExists()
    {
        try
        {
            SampleServiceImpl sampleServiceImpl = spy(new SampleServiceImpl());
            RestTemplate restTemplate = mock(RestTemplate.class);

            String backendEndPointUrl = UUID.randomUUID().toString();
            when(sampleServiceImpl.getBackendEndpointUrl()).thenReturn(backendEndPointUrl);
            when(sampleServiceImpl.getRestTemplate()).thenReturn(restTemplate);

            Sample sample = createSample(null, null);

            LinkedHashMap sampleResponse = new LinkedHashMap();
            sampleResponse.put("id", sample.getId());
            sampleResponse.put("description", sample.getDescription());
            when(restTemplate.getForEntity(backendEndPointUrl + ENDPOINT_URL_READ + sample.getId(), LinkedHashMap.class)).thenReturn(
                    ResponseEntity.ok(sampleResponse));

            JSONSample jsonSample = sampleServiceImpl.findOne(sample.getId());

            assertNotNull(jsonSample);
            assertEquals(sample.getId(), jsonSample.getId());
            assertEquals(sample.getDescription(), jsonSample.getDescription());
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testFindAll", tex);
            Assert.fail("Error testing testFindAll : " + tex);
        }
    }

    @Test
    public void testCreate()
    {
        try
        {
            SampleServiceImpl sampleServiceImpl = spy(new SampleServiceImpl());
            RestTemplate restTemplate = mock(RestTemplate.class);

            String backendEndPointUrl = UUID.randomUUID().toString();
            when(sampleServiceImpl.getBackendEndpointUrl()).thenReturn(backendEndPointUrl);
            when(sampleServiceImpl.getRestTemplate()).thenReturn(restTemplate);

            JSONSample jsonSampleRequest = createJSONSample(null);
            LinkedHashMap<String, Object> sampleResponse = new LinkedHashMap<String, Object>();
            sampleResponse.put("id", jsonSampleRequest.getId());
            sampleResponse.put("description", jsonSampleRequest.getDescription());
            when(restTemplate.postForObject(eq(backendEndPointUrl + ENDPOINT_URL_CREATE), any(HttpMethod.class), eq(LinkedHashMap.class))).thenReturn(
                    sampleResponse);

            JSONSample jsonSampleResponse = sampleServiceImpl.create(jsonSampleRequest);

            assertNotNull(jsonSampleResponse);
            assertEquals(jsonSampleResponse.getId(), jsonSampleRequest.getId());
            assertEquals(jsonSampleResponse.getDescription(), jsonSampleRequest.getDescription());
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testCreate", tex);
            Assert.fail("Error testing testCreate : " + tex);
        }
    }

    @Test
    public void testCreateList()
    {
        try
        {
            SampleServiceImpl sampleServiceImpl = spy(new SampleServiceImpl());
            RestTemplate restTemplate = mock(RestTemplate.class);

            String backendEndPointUrl = UUID.randomUUID().toString();
            when(sampleServiceImpl.getBackendEndpointUrl()).thenReturn(backendEndPointUrl);
            when(sampleServiceImpl.getRestTemplate()).thenReturn(restTemplate);

            // Sample sampleResponse = createSample(1L, null);
            String sampleDescription = UUID.randomUUID().toString();
            LinkedHashMap<String, Object> sampleResponse = new LinkedHashMap<String, Object>();
            sampleResponse.put("id", "1");
            sampleResponse.put("description", sampleDescription);
            when(restTemplate.postForObject(eq(backendEndPointUrl + ENDPOINT_URL_CREATE), any(HttpMethod.class), eq(LinkedHashMap.class))).thenReturn(
                    sampleResponse);

            List<JSONSample> jsonSampleList = new ArrayList<JSONSample>();
            jsonSampleList.add(createJSONSample(null));
            jsonSampleList.add(createJSONSample(null));
            jsonSampleList.add(createJSONSample(null));

            List<JSONSample> responseJSONSample = sampleServiceImpl.create(jsonSampleList);

            assertNotNull(responseJSONSample);
            assertEquals(3, responseJSONSample.size());

            for (JSONSample jsonSample : responseJSONSample)
            {
                Long expected = Long.parseLong(sampleResponse.get("id").toString());
                assertEquals(expected, jsonSample.getId());
                assertEquals(sampleDescription, jsonSample.getDescription());
            }
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testCreateList", tex);
            Assert.fail("Error testing testCreateList : " + tex);
        }
    }

    private static Sample createSample(Long id, String description)
    {
        Sample sample = new Sample();

        sample.setId(id != null ? id : new Random().nextInt());
        sample.setDescription(description != null ? description : UUID.randomUUID().toString());

        return sample;
    }

    private static JSONSample createJSONSample(Long id)
    {
        JSONSample sample = new JSONSample();

        sample.setId(id != null ? id : new Random().nextInt());
        sample.setDescription(UUID.randomUUID().toString());

        return sample;
    }
}
