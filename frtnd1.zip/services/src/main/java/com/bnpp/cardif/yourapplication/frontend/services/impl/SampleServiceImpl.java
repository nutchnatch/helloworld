package com.bnpp.cardif.yourapplication.frontend.services.impl;

import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.yourapplication.beans.Sample;
import com.bnpp.cardif.yourapplication.exception.TechnicalException;
import com.bnpp.cardif.yourapplication.frontend.beans.JSONSample;
import com.bnpp.cardif.yourapplication.frontend.services.SampleService;

/**
 * Implementation of service related to Sample Entities.
 * 
 * @author 831743
 *
 */
@Service("sampleService")
@Scope("singleton")
// default value specified to be obvious.
public class SampleServiceImpl extends FrontendCrudServiceImpl<JSONSample, Sample> implements SampleService
{
    @Value("${backend.sample.endpoint.url}")
    private String backendEndpointUrl;

    public String getBackendEndpointUrl()
    {
        return backendEndpointUrl;
    }

    public void setBackendEndpointUrl(String backendEndpointUrl)
    {
        this.backendEndpointUrl = backendEndpointUrl;
    }

    @Override
    public List<JSONSample> create(List<JSONSample> entities) throws TechnicalException
    {
        return super.createEntityList(entities);
    }

    @Override
    public JSONSample create(JSONSample entity) throws TechnicalException
    {
        return super.createEntity(entity);
    }

    @Override
    public List<JSONSample> update(List<JSONSample> entities) throws TechnicalException
    {
        return super.updateEntityList(entities);
    }

    @Override
    public JSONSample update(JSONSample entity) throws TechnicalException
    {
        return super.updateEntity(entity);
    }

    @Override
    public JSONSample findOne(Long id) throws TechnicalException
    {
        return super.findOneEntity(id);
    }

    @Override
    public boolean exists(Long id) throws TechnicalException
    {
        return super.existsEntity(id);
    }

    @Override
    public List<JSONSample> findAll() throws TechnicalException
    {
        return super.findAllEntities();
    }

    @Override
    public List<JSONSample> findAll(List<Long> ids) throws TechnicalException
    {
        return super.findAllEntities(ids);
    }

    @Override
    public long count() throws TechnicalException
    {
        return super.countEntities();
    }

    @Override
    public void delete(Long id) throws TechnicalException
    {
        super.deleteEntity(id);
    }

    @Override
    public void delete(JSONSample entity) throws TechnicalException
    {
        super.deleteEntity(entity);
    }

    @Override
    public void delete(List<JSONSample> entities) throws TechnicalException
    {
        super.deleteEntities(entities);
    }

    @Override
    public String getBackendUrl()
    {
        return getBackendEndpointUrl();
    }

    @Override
    public Class<Sample> getBackendClass()
    {
        return Sample.class;
    }

    @Override
    public Long getId(JSONSample entity)
    {
        return entity != null ? entity.getId() : null;
    }

    @Override
    public Sample convertEntityToBackend(JSONSample entity)
    {
        Sample sample = new Sample();

        if (entity != null)
        {
            sample.setId(entity.getId());
            sample.setDescription(entity.getDescription());
            sample.setCreationDate(entity.getCreationDate());
            sample.setCreationUser(entity.getCreationUser());
            sample.setIdentifier(entity.getIdentifier());
            sample.setModificationDate(entity.getModificationDate());
            sample.setModificationUser(entity.getModificationUser());
        }

        return sample;
    }

    @Override
    public JSONSample convertEntityFromBackend(LinkedHashMap<String, Object> entity)
    {
        JSONSample jsonSample = new JSONSample();

        if (entity != null)
        {
            jsonSample.setId(getAsLong(entity, "id"));
            jsonSample.setDescription(getAsString(entity, "description"));
            jsonSample.setCreationDate(getAsDate(entity, "creationDate"));
            jsonSample.setCreationUser(getAsString(entity, "creationUser"));
            jsonSample.setIdentifier(getAsString(entity, "identifier"));
            jsonSample.setModificationDate(getAsDate(entity, "modificationDate"));
            jsonSample.setModificationUser(getAsString(entity, "modificationUser"));
        }

        return jsonSample;
    }
}
