package com.bnpp.cardif.yourapplication.frontend.services;

import java.util.List;

import com.bnpp.cardif.yourapplication.exception.TechnicalException;

/**
 * 
 * @author Eric Le Bail
 *
 */
public interface FrontendBaseService<E>
{
    /**
     * Exposing the CRUD operation create
     * 
     * @param entities
     *            : List<E> the list of objects to save
     * @return List<E> : the saved object list.
     */
    public List<E> create(List<E> entities) throws TechnicalException;

    /**
     * Exposing the CRUD operation update
     * 
     * @param entities
     *            : List<E> the list of objects to save
     * @return List<E> : the saved object list.
     */
    public List<E> update(List<E> entities) throws TechnicalException;

    /**
     * Exposing the CRUD operation create
     * 
     * @param entity
     *            : E object to save.
     * @return E : the saved object.
     */
    public E create(E entity) throws TechnicalException;

    /**
     * Exposing the CRUD operation update
     * 
     * @param entity
     *            : E object to save.
     * @return E : the saved object.
     */
    public E update(E entity) throws TechnicalException;

    /**
     * Exposing the CRUD operation findOne
     * 
     * @param id
     *            : Integer the object identifier
     * @return E : the found object.
     */
    public E findOne(Long id) throws TechnicalException;

    /**
     * Exposing the CRUD operation exists
     * 
     * @param id
     *            : Integer the object identifier
     * @return E : the found object.
     */
    public boolean exists(Long id) throws TechnicalException;

    /**
     * Exposing the CRUD operation findAll
     * 
     * @return List<E> : the list of all E objects found
     */
    public List<E> findAll() throws TechnicalException;

    /**
     * Exposing the CRUD operation findAll
     * 
     * @param ids
     *            List<Integer> : the list of identifiers of the objects to be
     *            found.
     * @return List<E> : the list of all E objects found
     */
    public List<E> findAll(List<Long> ids) throws TechnicalException;

    /**
     * Exposing the CRUD operation count
     * 
     * @return the number of objects found.
     */
    public long count() throws TechnicalException;

    /**
     * Exposing the CRUD operation delete
     * 
     * @param id
     *            Integer : the identifier of the object to be deleted.
     */
    public void delete(Long id) throws TechnicalException;

    /**
     * Exposing the CRUD operation delete
     * 
     * @param entity
     *            E: the object to delete.
     */
    public void delete(E entity) throws TechnicalException;

    /**
     * Exposing the CRUD operation delete
     * 
     * @param entities
     *            List<E> : the list of objects to be deleted.
     */
    public void delete(List<E> entities) throws TechnicalException;
}
