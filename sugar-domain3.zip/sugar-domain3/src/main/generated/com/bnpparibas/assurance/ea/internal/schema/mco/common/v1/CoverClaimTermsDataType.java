
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Terms applied to claims and related benefit
 * 				calculation rules
 * 			
 * 
 * <p>Java class for CoverClaimTermsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverClaimTermsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="WaitngPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="Ddctble" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DeductibleTypeCodeSLN"/&gt;
 *                   &lt;element name="DdctblePrd" maxOccurs="unbounded" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *                             &lt;element name="BnftRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RlpsePrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="BnftMaxPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="BnftMaxAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="DeclrtnMaxPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="RightRetrvlPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="PolTermntnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="MaxClaimsNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="MaxBnftAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="MaxSumBnftAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="RvsbltyData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumOrBenefitRevisabilityTermsDataType" minOccurs="0"/&gt;
 *         &lt;element name="LoanExitBnft" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="InstllmntMaxNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *                   &lt;element name="InstllmntRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *                   &lt;element name="SurndrPnlty" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *                             &lt;element name="FixAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BnftCalctnAssmlbleRiskCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverClaimTermsDataType", propOrder = {
    "waitngPrd",
    "ddctble",
    "rlpsePrd",
    "bnftMaxPrd",
    "bnftMaxAge",
    "declrtnMaxPrd",
    "rightRetrvlPrd",
    "polTermntnIndic",
    "maxClaimsNumb",
    "maxBnftAmnt",
    "maxSumBnftAmnt",
    "rvsbltyData",
    "loanExitBnft",
    "bnftCalctnAssmlbleRiskCode"
})
public class CoverClaimTermsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "WaitngPrd")
    protected DurationType waitngPrd;
    @XmlElement(name = "Ddctble")
    protected CoverClaimTermsDataType.Ddctble ddctble;
    @XmlElement(name = "RlpsePrd")
    protected DurationType rlpsePrd;
    @XmlElement(name = "BnftMaxPrd")
    protected DurationType bnftMaxPrd;
    @XmlElement(name = "BnftMaxAge")
    protected BigInteger bnftMaxAge;
    @XmlElement(name = "DeclrtnMaxPrd")
    protected DurationType declrtnMaxPrd;
    @XmlElement(name = "RightRetrvlPrd")
    protected DurationType rightRetrvlPrd;
    @XmlElement(name = "PolTermntnIndic")
    protected String polTermntnIndic;
    @XmlElement(name = "MaxClaimsNumb")
    protected BigInteger maxClaimsNumb;
    @XmlElement(name = "MaxBnftAmnt")
    protected CurrencyAndAmountType maxBnftAmnt;
    @XmlElement(name = "MaxSumBnftAmnt")
    protected CurrencyAndAmountType maxSumBnftAmnt;
    @XmlElement(name = "RvsbltyData")
    protected PremiumOrBenefitRevisabilityTermsDataType rvsbltyData;
    @XmlElement(name = "LoanExitBnft")
    protected CoverClaimTermsDataType.LoanExitBnft loanExitBnft;
    @XmlElement(name = "BnftCalctnAssmlbleRiskCode")
    protected String bnftCalctnAssmlbleRiskCode;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverClaimTermsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverClaimTermsDataType(final DurationType waitngPrd, final CoverClaimTermsDataType.Ddctble ddctble, final DurationType rlpsePrd, final DurationType bnftMaxPrd, final BigInteger bnftMaxAge, final DurationType declrtnMaxPrd, final DurationType rightRetrvlPrd, final String polTermntnIndic, final BigInteger maxClaimsNumb, final CurrencyAndAmountType maxBnftAmnt, final CurrencyAndAmountType maxSumBnftAmnt, final PremiumOrBenefitRevisabilityTermsDataType rvsbltyData, final CoverClaimTermsDataType.LoanExitBnft loanExitBnft, final String bnftCalctnAssmlbleRiskCode) {
        this.waitngPrd = waitngPrd;
        this.ddctble = ddctble;
        this.rlpsePrd = rlpsePrd;
        this.bnftMaxPrd = bnftMaxPrd;
        this.bnftMaxAge = bnftMaxAge;
        this.declrtnMaxPrd = declrtnMaxPrd;
        this.rightRetrvlPrd = rightRetrvlPrd;
        this.polTermntnIndic = polTermntnIndic;
        this.maxClaimsNumb = maxClaimsNumb;
        this.maxBnftAmnt = maxBnftAmnt;
        this.maxSumBnftAmnt = maxSumBnftAmnt;
        this.rvsbltyData = rvsbltyData;
        this.loanExitBnft = loanExitBnft;
        this.bnftCalctnAssmlbleRiskCode = bnftCalctnAssmlbleRiskCode;
    }

    /**
     * Gets the value of the waitngPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getWaitngPrd() {
        return waitngPrd;
    }

    /**
     * Sets the value of the waitngPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setWaitngPrd(DurationType value) {
        this.waitngPrd = value;
    }

    public boolean isSetWaitngPrd() {
        return (this.waitngPrd!= null);
    }

    /**
     * Gets the value of the ddctble property.
     * 
     * @return
     *     possible object is
     *     {@link CoverClaimTermsDataType.Ddctble }
     *     
     */
    public CoverClaimTermsDataType.Ddctble getDdctble() {
        return ddctble;
    }

    /**
     * Sets the value of the ddctble property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverClaimTermsDataType.Ddctble }
     *     
     */
    public void setDdctble(CoverClaimTermsDataType.Ddctble value) {
        this.ddctble = value;
    }

    public boolean isSetDdctble() {
        return (this.ddctble!= null);
    }

    /**
     * Gets the value of the rlpsePrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getRlpsePrd() {
        return rlpsePrd;
    }

    /**
     * Sets the value of the rlpsePrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setRlpsePrd(DurationType value) {
        this.rlpsePrd = value;
    }

    public boolean isSetRlpsePrd() {
        return (this.rlpsePrd!= null);
    }

    /**
     * Gets the value of the bnftMaxPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getBnftMaxPrd() {
        return bnftMaxPrd;
    }

    /**
     * Sets the value of the bnftMaxPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setBnftMaxPrd(DurationType value) {
        this.bnftMaxPrd = value;
    }

    public boolean isSetBnftMaxPrd() {
        return (this.bnftMaxPrd!= null);
    }

    /**
     * Gets the value of the bnftMaxAge property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBnftMaxAge() {
        return bnftMaxAge;
    }

    /**
     * Sets the value of the bnftMaxAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBnftMaxAge(BigInteger value) {
        this.bnftMaxAge = value;
    }

    public boolean isSetBnftMaxAge() {
        return (this.bnftMaxAge!= null);
    }

    /**
     * Gets the value of the declrtnMaxPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDeclrtnMaxPrd() {
        return declrtnMaxPrd;
    }

    /**
     * Sets the value of the declrtnMaxPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDeclrtnMaxPrd(DurationType value) {
        this.declrtnMaxPrd = value;
    }

    public boolean isSetDeclrtnMaxPrd() {
        return (this.declrtnMaxPrd!= null);
    }

    /**
     * Gets the value of the rightRetrvlPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getRightRetrvlPrd() {
        return rightRetrvlPrd;
    }

    /**
     * Sets the value of the rightRetrvlPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setRightRetrvlPrd(DurationType value) {
        this.rightRetrvlPrd = value;
    }

    public boolean isSetRightRetrvlPrd() {
        return (this.rightRetrvlPrd!= null);
    }

    /**
     * Gets the value of the polTermntnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolTermntnIndic() {
        return polTermntnIndic;
    }

    /**
     * Sets the value of the polTermntnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolTermntnIndic(String value) {
        this.polTermntnIndic = value;
    }

    public boolean isSetPolTermntnIndic() {
        return (this.polTermntnIndic!= null);
    }

    /**
     * Gets the value of the maxClaimsNumb property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getMaxClaimsNumb() {
        return maxClaimsNumb;
    }

    /**
     * Sets the value of the maxClaimsNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setMaxClaimsNumb(BigInteger value) {
        this.maxClaimsNumb = value;
    }

    public boolean isSetMaxClaimsNumb() {
        return (this.maxClaimsNumb!= null);
    }

    /**
     * Gets the value of the maxBnftAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getMaxBnftAmnt() {
        return maxBnftAmnt;
    }

    /**
     * Sets the value of the maxBnftAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setMaxBnftAmnt(CurrencyAndAmountType value) {
        this.maxBnftAmnt = value;
    }

    public boolean isSetMaxBnftAmnt() {
        return (this.maxBnftAmnt!= null);
    }

    /**
     * Gets the value of the maxSumBnftAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getMaxSumBnftAmnt() {
        return maxSumBnftAmnt;
    }

    /**
     * Sets the value of the maxSumBnftAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setMaxSumBnftAmnt(CurrencyAndAmountType value) {
        this.maxSumBnftAmnt = value;
    }

    public boolean isSetMaxSumBnftAmnt() {
        return (this.maxSumBnftAmnt!= null);
    }

    /**
     * Gets the value of the rvsbltyData property.
     * 
     * @return
     *     possible object is
     *     {@link PremiumOrBenefitRevisabilityTermsDataType }
     *     
     */
    public PremiumOrBenefitRevisabilityTermsDataType getRvsbltyData() {
        return rvsbltyData;
    }

    /**
     * Sets the value of the rvsbltyData property.
     * 
     * @param value
     *     allowed object is
     *     {@link PremiumOrBenefitRevisabilityTermsDataType }
     *     
     */
    public void setRvsbltyData(PremiumOrBenefitRevisabilityTermsDataType value) {
        this.rvsbltyData = value;
    }

    public boolean isSetRvsbltyData() {
        return (this.rvsbltyData!= null);
    }

    /**
     * Gets the value of the loanExitBnft property.
     * 
     * @return
     *     possible object is
     *     {@link CoverClaimTermsDataType.LoanExitBnft }
     *     
     */
    public CoverClaimTermsDataType.LoanExitBnft getLoanExitBnft() {
        return loanExitBnft;
    }

    /**
     * Sets the value of the loanExitBnft property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverClaimTermsDataType.LoanExitBnft }
     *     
     */
    public void setLoanExitBnft(CoverClaimTermsDataType.LoanExitBnft value) {
        this.loanExitBnft = value;
    }

    public boolean isSetLoanExitBnft() {
        return (this.loanExitBnft!= null);
    }

    /**
     * Gets the value of the bnftCalctnAssmlbleRiskCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBnftCalctnAssmlbleRiskCode() {
        return bnftCalctnAssmlbleRiskCode;
    }

    /**
     * Sets the value of the bnftCalctnAssmlbleRiskCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBnftCalctnAssmlbleRiskCode(String value) {
        this.bnftCalctnAssmlbleRiskCode = value;
    }

    public boolean isSetBnftCalctnAssmlbleRiskCode() {
        return (this.bnftCalctnAssmlbleRiskCode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("waitngPrd", waitngPrd).add("ddctble", ddctble).add("rlpsePrd", rlpsePrd).add("bnftMaxPrd", bnftMaxPrd).add("bnftMaxAge", bnftMaxAge).add("declrtnMaxPrd", declrtnMaxPrd).add("rightRetrvlPrd", rightRetrvlPrd).add("polTermntnIndic", polTermntnIndic).add("maxClaimsNumb", maxClaimsNumb).add("maxBnftAmnt", maxBnftAmnt).add("maxSumBnftAmnt", maxSumBnftAmnt).add("rvsbltyData", rvsbltyData).add("loanExitBnft", loanExitBnft).add("bnftCalctnAssmlbleRiskCode", bnftCalctnAssmlbleRiskCode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(waitngPrd, ddctble, rlpsePrd, bnftMaxPrd, bnftMaxAge, declrtnMaxPrd, rightRetrvlPrd, polTermntnIndic, maxClaimsNumb, maxBnftAmnt, maxSumBnftAmnt, rvsbltyData, loanExitBnft, bnftCalctnAssmlbleRiskCode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverClaimTermsDataType o = ((CoverClaimTermsDataType) other);
        return (((((((((((((Objects.equal(waitngPrd, o.waitngPrd)&&Objects.equal(ddctble, o.ddctble))&&Objects.equal(rlpsePrd, o.rlpsePrd))&&Objects.equal(bnftMaxPrd, o.bnftMaxPrd))&&Objects.equal(bnftMaxAge, o.bnftMaxAge))&&Objects.equal(declrtnMaxPrd, o.declrtnMaxPrd))&&Objects.equal(rightRetrvlPrd, o.rightRetrvlPrd))&&Objects.equal(polTermntnIndic, o.polTermntnIndic))&&Objects.equal(maxClaimsNumb, o.maxClaimsNumb))&&Objects.equal(maxBnftAmnt, o.maxBnftAmnt))&&Objects.equal(maxSumBnftAmnt, o.maxSumBnftAmnt))&&Objects.equal(rvsbltyData, o.rvsbltyData))&&Objects.equal(loanExitBnft, o.loanExitBnft))&&Objects.equal(bnftCalctnAssmlbleRiskCode, o.bnftCalctnAssmlbleRiskCode));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DeductibleTypeCodeSLN"/&gt;
     *         &lt;element name="DdctblePrd" maxOccurs="unbounded" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
     *                   &lt;element name="BnftRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "type",
        "ddctblePrd",
        "amnt",
        "rate"
    })
    public static class Ddctble implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Type", required = true)
        protected String type;
        @XmlElement(name = "DdctblePrd")
        protected List<CoverClaimTermsDataType.Ddctble.DdctblePrd> ddctblePrd;
        @XmlElement(name = "Amnt")
        protected CurrencyAndAmountType amnt;
        @XmlElement(name = "Rate")
        protected BasisRateType rate;

        /**
         * Default no-arg constructor
         * 
         */
        public Ddctble() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Ddctble(final String type, final List<CoverClaimTermsDataType.Ddctble.DdctblePrd> ddctblePrd, final CurrencyAndAmountType amnt, final BasisRateType rate) {
            this.type = type;
            this.ddctblePrd = ddctblePrd;
            this.amnt = amnt;
            this.rate = rate;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

        public boolean isSetType() {
            return (this.type!= null);
        }

        /**
         * Gets the value of the ddctblePrd property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the ddctblePrd property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDdctblePrd().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link CoverClaimTermsDataType.Ddctble.DdctblePrd }
         * 
         * 
         */
        public List<CoverClaimTermsDataType.Ddctble.DdctblePrd> getDdctblePrd() {
            if (ddctblePrd == null) {
                ddctblePrd = new ArrayList<CoverClaimTermsDataType.Ddctble.DdctblePrd>();
            }
            return this.ddctblePrd;
        }

        public boolean isSetDdctblePrd() {
            return ((this.ddctblePrd!= null)&&(!this.ddctblePrd.isEmpty()));
        }

        public void unsetDdctblePrd() {
            this.ddctblePrd = null;
        }

        /**
         * Gets the value of the amnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getAmnt() {
            return amnt;
        }

        /**
         * Sets the value of the amnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setAmnt(CurrencyAndAmountType value) {
            this.amnt = value;
        }

        public boolean isSetAmnt() {
            return (this.amnt!= null);
        }

        /**
         * Gets the value of the rate property.
         * 
         * @return
         *     possible object is
         *     {@link BasisRateType }
         *     
         */
        public BasisRateType getRate() {
            return rate;
        }

        /**
         * Sets the value of the rate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BasisRateType }
         *     
         */
        public void setRate(BasisRateType value) {
            this.rate = value;
        }

        public boolean isSetRate() {
            return (this.rate!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("type", type).add("ddctblePrd", ddctblePrd).add("amnt", amnt).add("rate", rate).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(type, ddctblePrd, amnt, rate);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final CoverClaimTermsDataType.Ddctble o = ((CoverClaimTermsDataType.Ddctble) other);
            return (((Objects.equal(type, o.type)&&Objects.equal(ddctblePrd, o.ddctblePrd))&&Objects.equal(amnt, o.amnt))&&Objects.equal(rate, o.rate));
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
         *         &lt;element name="BnftRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "prd",
            "bnftRate"
        })
        public static class DdctblePrd implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Prd", required = true)
            protected DurationType prd;
            @XmlElement(name = "BnftRate")
            protected BasisRateType bnftRate;

            /**
             * Default no-arg constructor
             * 
             */
            public DdctblePrd() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public DdctblePrd(final DurationType prd, final BasisRateType bnftRate) {
                this.prd = prd;
                this.bnftRate = bnftRate;
            }

            /**
             * Gets the value of the prd property.
             * 
             * @return
             *     possible object is
             *     {@link DurationType }
             *     
             */
            public DurationType getPrd() {
                return prd;
            }

            /**
             * Sets the value of the prd property.
             * 
             * @param value
             *     allowed object is
             *     {@link DurationType }
             *     
             */
            public void setPrd(DurationType value) {
                this.prd = value;
            }

            public boolean isSetPrd() {
                return (this.prd!= null);
            }

            /**
             * Gets the value of the bnftRate property.
             * 
             * @return
             *     possible object is
             *     {@link BasisRateType }
             *     
             */
            public BasisRateType getBnftRate() {
                return bnftRate;
            }

            /**
             * Sets the value of the bnftRate property.
             * 
             * @param value
             *     allowed object is
             *     {@link BasisRateType }
             *     
             */
            public void setBnftRate(BasisRateType value) {
                this.bnftRate = value;
            }

            public boolean isSetBnftRate() {
                return (this.bnftRate!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("prd", prd).add("bnftRate", bnftRate).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(prd, bnftRate);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final CoverClaimTermsDataType.Ddctble.DdctblePrd o = ((CoverClaimTermsDataType.Ddctble.DdctblePrd) other);
                return (Objects.equal(prd, o.prd)&&Objects.equal(bnftRate, o.bnftRate));
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="InstllmntMaxNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
     *         &lt;element name="InstllmntRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
     *         &lt;element name="SurndrPnlty" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
     *                   &lt;element name="FixAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "instllmntMaxNumb",
        "instllmntRate",
        "surndrPnlty"
    })
    public static class LoanExitBnft implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "InstllmntMaxNumb")
        protected BigInteger instllmntMaxNumb;
        @XmlElement(name = "InstllmntRate")
        protected BasisRateType instllmntRate;
        @XmlElement(name = "SurndrPnlty")
        protected CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty surndrPnlty;

        /**
         * Default no-arg constructor
         * 
         */
        public LoanExitBnft() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public LoanExitBnft(final BigInteger instllmntMaxNumb, final BasisRateType instllmntRate, final CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty surndrPnlty) {
            this.instllmntMaxNumb = instllmntMaxNumb;
            this.instllmntRate = instllmntRate;
            this.surndrPnlty = surndrPnlty;
        }

        /**
         * Gets the value of the instllmntMaxNumb property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getInstllmntMaxNumb() {
            return instllmntMaxNumb;
        }

        /**
         * Sets the value of the instllmntMaxNumb property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setInstllmntMaxNumb(BigInteger value) {
            this.instllmntMaxNumb = value;
        }

        public boolean isSetInstllmntMaxNumb() {
            return (this.instllmntMaxNumb!= null);
        }

        /**
         * Gets the value of the instllmntRate property.
         * 
         * @return
         *     possible object is
         *     {@link BasisRateType }
         *     
         */
        public BasisRateType getInstllmntRate() {
            return instllmntRate;
        }

        /**
         * Sets the value of the instllmntRate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BasisRateType }
         *     
         */
        public void setInstllmntRate(BasisRateType value) {
            this.instllmntRate = value;
        }

        public boolean isSetInstllmntRate() {
            return (this.instllmntRate!= null);
        }

        /**
         * Gets the value of the surndrPnlty property.
         * 
         * @return
         *     possible object is
         *     {@link CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty }
         *     
         */
        public CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty getSurndrPnlty() {
            return surndrPnlty;
        }

        /**
         * Sets the value of the surndrPnlty property.
         * 
         * @param value
         *     allowed object is
         *     {@link CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty }
         *     
         */
        public void setSurndrPnlty(CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty value) {
            this.surndrPnlty = value;
        }

        public boolean isSetSurndrPnlty() {
            return (this.surndrPnlty!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("instllmntMaxNumb", instllmntMaxNumb).add("instllmntRate", instllmntRate).add("surndrPnlty", surndrPnlty).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(instllmntMaxNumb, instllmntRate, surndrPnlty);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final CoverClaimTermsDataType.LoanExitBnft o = ((CoverClaimTermsDataType.LoanExitBnft) other);
            return ((Objects.equal(instllmntMaxNumb, o.instllmntMaxNumb)&&Objects.equal(instllmntRate, o.instllmntRate))&&Objects.equal(surndrPnlty, o.surndrPnlty));
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
         *         &lt;element name="FixAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "rate",
            "fixAmnt"
        })
        public static class SurndrPnlty implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Rate")
            protected BasisRateType rate;
            @XmlElement(name = "FixAmnt")
            protected CurrencyAndAmountType fixAmnt;

            /**
             * Default no-arg constructor
             * 
             */
            public SurndrPnlty() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public SurndrPnlty(final BasisRateType rate, final CurrencyAndAmountType fixAmnt) {
                this.rate = rate;
                this.fixAmnt = fixAmnt;
            }

            /**
             * Gets the value of the rate property.
             * 
             * @return
             *     possible object is
             *     {@link BasisRateType }
             *     
             */
            public BasisRateType getRate() {
                return rate;
            }

            /**
             * Sets the value of the rate property.
             * 
             * @param value
             *     allowed object is
             *     {@link BasisRateType }
             *     
             */
            public void setRate(BasisRateType value) {
                this.rate = value;
            }

            public boolean isSetRate() {
                return (this.rate!= null);
            }

            /**
             * Gets the value of the fixAmnt property.
             * 
             * @return
             *     possible object is
             *     {@link CurrencyAndAmountType }
             *     
             */
            public CurrencyAndAmountType getFixAmnt() {
                return fixAmnt;
            }

            /**
             * Sets the value of the fixAmnt property.
             * 
             * @param value
             *     allowed object is
             *     {@link CurrencyAndAmountType }
             *     
             */
            public void setFixAmnt(CurrencyAndAmountType value) {
                this.fixAmnt = value;
            }

            public boolean isSetFixAmnt() {
                return (this.fixAmnt!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("rate", rate).add("fixAmnt", fixAmnt).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(rate, fixAmnt);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty o = ((CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty) other);
                return (Objects.equal(rate, o.rate)&&Objects.equal(fixAmnt, o.fixAmnt));
            }

        }

    }

}
