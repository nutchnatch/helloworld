
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Country(ies) in which the
 * 				product is commercialised
 * 			
 * 
 * <p>Java class for CoreProductCountryApplicationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoreProductCountryApplicationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cntry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN"/&gt;
 *         &lt;element name="ApplictnStartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ApplictnEndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreProductCountryApplicationType", propOrder = {
    "cntry",
    "applictnStartDate",
    "applictnEndDate"
})
public class CoreProductCountryApplicationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Cntry", required = true)
    protected String cntry;
    @XmlElement(name = "ApplictnStartDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date applictnStartDate;
    @XmlElement(name = "ApplictnEndDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date applictnEndDate;

    /**
     * Default no-arg constructor
     * 
     */
    public CoreProductCountryApplicationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoreProductCountryApplicationType(final String cntry, final Date applictnStartDate, final Date applictnEndDate) {
        this.cntry = cntry;
        this.applictnStartDate = applictnStartDate;
        this.applictnEndDate = applictnEndDate;
    }

    /**
     * Gets the value of the cntry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCntry() {
        return cntry;
    }

    /**
     * Sets the value of the cntry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCntry(String value) {
        this.cntry = value;
    }

    public boolean isSetCntry() {
        return (this.cntry!= null);
    }

    /**
     * Gets the value of the applictnStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getApplictnStartDate() {
        return applictnStartDate;
    }

    /**
     * Sets the value of the applictnStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplictnStartDate(Date value) {
        this.applictnStartDate = value;
    }

    public boolean isSetApplictnStartDate() {
        return (this.applictnStartDate!= null);
    }

    /**
     * Gets the value of the applictnEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getApplictnEndDate() {
        return applictnEndDate;
    }

    /**
     * Sets the value of the applictnEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplictnEndDate(Date value) {
        this.applictnEndDate = value;
    }

    public boolean isSetApplictnEndDate() {
        return (this.applictnEndDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cntry", cntry).add("applictnStartDate", applictnStartDate).add("applictnEndDate", applictnEndDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cntry, applictnStartDate, applictnEndDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoreProductCountryApplicationType o = ((CoreProductCountryApplicationType) other);
        return ((Objects.equal(cntry, o.cntry)&&Objects.equal(applictnStartDate, o.applictnStartDate))&&Objects.equal(applictnEndDate, o.applictnEndDate));
    }

}
