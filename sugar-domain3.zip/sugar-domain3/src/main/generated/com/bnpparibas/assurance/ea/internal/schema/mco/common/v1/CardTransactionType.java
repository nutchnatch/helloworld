
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on a card transaction and card
 * 			
 * 
 * <p>Java class for CardTransactionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardTransactionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CardTransactionDataType" minOccurs="0"/&gt;
 *         &lt;element name="CardData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentCardDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardTransactionType", propOrder = {
    "transData",
    "cardData"
})
public class CardTransactionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "TransData")
    protected CardTransactionDataType transData;
    @XmlElement(name = "CardData")
    protected PaymentCardDataType cardData;

    /**
     * Default no-arg constructor
     * 
     */
    public CardTransactionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CardTransactionType(final CardTransactionDataType transData, final PaymentCardDataType cardData) {
        this.transData = transData;
        this.cardData = cardData;
    }

    /**
     * Gets the value of the transData property.
     * 
     * @return
     *     possible object is
     *     {@link CardTransactionDataType }
     *     
     */
    public CardTransactionDataType getTransData() {
        return transData;
    }

    /**
     * Sets the value of the transData property.
     * 
     * @param value
     *     allowed object is
     *     {@link CardTransactionDataType }
     *     
     */
    public void setTransData(CardTransactionDataType value) {
        this.transData = value;
    }

    public boolean isSetTransData() {
        return (this.transData!= null);
    }

    /**
     * Gets the value of the cardData property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentCardDataType }
     *     
     */
    public PaymentCardDataType getCardData() {
        return cardData;
    }

    /**
     * Sets the value of the cardData property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentCardDataType }
     *     
     */
    public void setCardData(PaymentCardDataType value) {
        this.cardData = value;
    }

    public boolean isSetCardData() {
        return (this.cardData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("transData", transData).add("cardData", cardData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(transData, cardData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CardTransactionType o = ((CardTransactionType) other);
        return (Objects.equal(transData, o.transData)&&Objects.equal(cardData, o.cardData));
    }

}
