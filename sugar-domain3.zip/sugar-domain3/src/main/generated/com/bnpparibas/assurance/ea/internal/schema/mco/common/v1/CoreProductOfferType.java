
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Offer details for a
 * 				product or package
 * 			
 * 
 * <p>Java class for CoreProductOfferType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoreProductOfferType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType"/&gt;
 *         &lt;element name="OfferData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductOfferDataType"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductObjectStatusType"/&gt;
 *         &lt;element name="DistrbtnInfo" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductDistributionInformationType"/&gt;
 *         &lt;element name="CntryApplictn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductCountryApplicationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreProductOfferType", propOrder = {
    "idntfctn",
    "offerData",
    "status",
    "distrbtnInfo",
    "cntryApplictn"
})
public class CoreProductOfferType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn", required = true)
    protected ObjectIdentificationWithVersionType idntfctn;
    @XmlElement(name = "OfferData", required = true)
    protected CoreProductOfferDataType offerData;
    @XmlElement(name = "Status", required = true)
    protected CoreProductObjectStatusType status;
    @XmlElement(name = "DistrbtnInfo", required = true)
    protected CoreProductDistributionInformationType distrbtnInfo;
    @XmlElement(name = "CntryApplictn")
    protected List<CoreProductCountryApplicationType> cntryApplictn;

    /**
     * Default no-arg constructor
     * 
     */
    public CoreProductOfferType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoreProductOfferType(final ObjectIdentificationWithVersionType idntfctn, final CoreProductOfferDataType offerData, final CoreProductObjectStatusType status, final CoreProductDistributionInformationType distrbtnInfo, final List<CoreProductCountryApplicationType> cntryApplictn) {
        this.idntfctn = idntfctn;
        this.offerData = offerData;
        this.status = status;
        this.distrbtnInfo = distrbtnInfo;
        this.cntryApplictn = cntryApplictn;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setIdntfctn(ObjectIdentificationWithVersionType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the offerData property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductOfferDataType }
     *     
     */
    public CoreProductOfferDataType getOfferData() {
        return offerData;
    }

    /**
     * Sets the value of the offerData property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductOfferDataType }
     *     
     */
    public void setOfferData(CoreProductOfferDataType value) {
        this.offerData = value;
    }

    public boolean isSetOfferData() {
        return (this.offerData!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductObjectStatusType }
     *     
     */
    public CoreProductObjectStatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductObjectStatusType }
     *     
     */
    public void setStatus(CoreProductObjectStatusType value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the distrbtnInfo property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductDistributionInformationType }
     *     
     */
    public CoreProductDistributionInformationType getDistrbtnInfo() {
        return distrbtnInfo;
    }

    /**
     * Sets the value of the distrbtnInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductDistributionInformationType }
     *     
     */
    public void setDistrbtnInfo(CoreProductDistributionInformationType value) {
        this.distrbtnInfo = value;
    }

    public boolean isSetDistrbtnInfo() {
        return (this.distrbtnInfo!= null);
    }

    /**
     * Gets the value of the cntryApplictn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cntryApplictn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCntryApplictn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoreProductCountryApplicationType }
     * 
     * 
     */
    public List<CoreProductCountryApplicationType> getCntryApplictn() {
        if (cntryApplictn == null) {
            cntryApplictn = new ArrayList<CoreProductCountryApplicationType>();
        }
        return this.cntryApplictn;
    }

    public boolean isSetCntryApplictn() {
        return ((this.cntryApplictn!= null)&&(!this.cntryApplictn.isEmpty()));
    }

    public void unsetCntryApplictn() {
        this.cntryApplictn = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("offerData", offerData).add("status", status).add("distrbtnInfo", distrbtnInfo).add("cntryApplictn", cntryApplictn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, offerData, status, distrbtnInfo, cntryApplictn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoreProductOfferType o = ((CoreProductOfferType) other);
        return ((((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(offerData, o.offerData))&&Objects.equal(status, o.status))&&Objects.equal(distrbtnInfo, o.distrbtnInfo))&&Objects.equal(cntryApplictn, o.cntryApplictn));
    }

}
