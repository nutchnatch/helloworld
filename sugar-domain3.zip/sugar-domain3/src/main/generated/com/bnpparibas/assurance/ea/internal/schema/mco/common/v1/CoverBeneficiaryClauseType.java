
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on benficiary clause at cover
 * 				level
 * 			
 * 
 * <p>Java class for CoverBeneficiaryClauseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverBeneficiaryClauseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClauseType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClauseTypeCodeSLN"/&gt;
 *         &lt;element name="StdClauseId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StandardBeneficiaryClauseCode" minOccurs="0"/&gt;
 *         &lt;element name="FreeClauseText" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClauseTextType" minOccurs="0"/&gt;
 *         &lt;element name="NamedBenfciary" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverNamedBeneficiaryClauseType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverBeneficiaryClauseType", propOrder = {
    "clauseType",
    "stdClauseId",
    "freeClauseText",
    "namedBenfciary",
    "applctnPrd"
})
public class CoverBeneficiaryClauseType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClauseType", required = true)
    protected String clauseType;
    @XmlElement(name = "StdClauseId")
    protected String stdClauseId;
    @XmlElement(name = "FreeClauseText")
    protected String freeClauseText;
    @XmlElement(name = "NamedBenfciary")
    protected List<CoverNamedBeneficiaryClauseType> namedBenfciary;
    @XmlElement(name = "ApplctnPrd")
    protected DatePeriodType applctnPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverBeneficiaryClauseType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverBeneficiaryClauseType(final String clauseType, final String stdClauseId, final String freeClauseText, final List<CoverNamedBeneficiaryClauseType> namedBenfciary, final DatePeriodType applctnPrd) {
        this.clauseType = clauseType;
        this.stdClauseId = stdClauseId;
        this.freeClauseText = freeClauseText;
        this.namedBenfciary = namedBenfciary;
        this.applctnPrd = applctnPrd;
    }

    /**
     * Gets the value of the clauseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClauseType() {
        return clauseType;
    }

    /**
     * Sets the value of the clauseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClauseType(String value) {
        this.clauseType = value;
    }

    public boolean isSetClauseType() {
        return (this.clauseType!= null);
    }

    /**
     * Gets the value of the stdClauseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdClauseId() {
        return stdClauseId;
    }

    /**
     * Sets the value of the stdClauseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdClauseId(String value) {
        this.stdClauseId = value;
    }

    public boolean isSetStdClauseId() {
        return (this.stdClauseId!= null);
    }

    /**
     * Gets the value of the freeClauseText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeClauseText() {
        return freeClauseText;
    }

    /**
     * Sets the value of the freeClauseText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeClauseText(String value) {
        this.freeClauseText = value;
    }

    public boolean isSetFreeClauseText() {
        return (this.freeClauseText!= null);
    }

    /**
     * Gets the value of the namedBenfciary property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the namedBenfciary property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNamedBenfciary().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverNamedBeneficiaryClauseType }
     * 
     * 
     */
    public List<CoverNamedBeneficiaryClauseType> getNamedBenfciary() {
        if (namedBenfciary == null) {
            namedBenfciary = new ArrayList<CoverNamedBeneficiaryClauseType>();
        }
        return this.namedBenfciary;
    }

    public boolean isSetNamedBenfciary() {
        return ((this.namedBenfciary!= null)&&(!this.namedBenfciary.isEmpty()));
    }

    public void unsetNamedBenfciary() {
        this.namedBenfciary = null;
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("clauseType", clauseType).add("stdClauseId", stdClauseId).add("freeClauseText", freeClauseText).add("namedBenfciary", namedBenfciary).add("applctnPrd", applctnPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(clauseType, stdClauseId, freeClauseText, namedBenfciary, applctnPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverBeneficiaryClauseType o = ((CoverBeneficiaryClauseType) other);
        return ((((Objects.equal(clauseType, o.clauseType)&&Objects.equal(stdClauseId, o.stdClauseId))&&Objects.equal(freeClauseText, o.freeClauseText))&&Objects.equal(namedBenfciary, o.namedBenfciary))&&Objects.equal(applctnPrd, o.applctnPrd));
    }

}
