
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on a recipient
 * 				application of business objects
 * 			
 * 
 * <p>Java class for AcknowledgementRecipientApplicationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AcknowledgementRecipientApplicationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CompnentCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ApplicationComponentCodeSLN"/&gt;
 *         &lt;element name="User" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UserType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AcknowledgementRecipientApplicationType", propOrder = {
    "compnentCode",
    "user"
})
public class AcknowledgementRecipientApplicationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CompnentCode", required = true)
    protected String compnentCode;
    @XmlElement(name = "User")
    protected UserType user;

    /**
     * Default no-arg constructor
     * 
     */
    public AcknowledgementRecipientApplicationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AcknowledgementRecipientApplicationType(final String compnentCode, final UserType user) {
        this.compnentCode = compnentCode;
        this.user = user;
    }

    /**
     * Gets the value of the compnentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompnentCode() {
        return compnentCode;
    }

    /**
     * Sets the value of the compnentCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompnentCode(String value) {
        this.compnentCode = value;
    }

    public boolean isSetCompnentCode() {
        return (this.compnentCode!= null);
    }

    /**
     * Gets the value of the user property.
     * 
     * @return
     *     possible object is
     *     {@link UserType }
     *     
     */
    public UserType getUser() {
        return user;
    }

    /**
     * Sets the value of the user property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserType }
     *     
     */
    public void setUser(UserType value) {
        this.user = value;
    }

    public boolean isSetUser() {
        return (this.user!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("compnentCode", compnentCode).add("user", user).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(compnentCode, user);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AcknowledgementRecipientApplicationType o = ((AcknowledgementRecipientApplicationType) other);
        return (Objects.equal(compnentCode, o.compnentCode)&&Objects.equal(user, o.user));
    }

}
