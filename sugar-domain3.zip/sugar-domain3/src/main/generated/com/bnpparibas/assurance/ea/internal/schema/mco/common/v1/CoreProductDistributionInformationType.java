
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Distribution information
 * 				for a product or package offer
 * 			
 * 
 * <p>Java class for CoreProductDistributionInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoreProductDistributionInformationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CntrctlRltionship" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ContractualRelationshipTypeCodeSLN"/&gt;
 *         &lt;element name="DistribtnMarkt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionMarketTypeCodeSLN"/&gt;
 *         &lt;element name="DistribtnTechnc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionTechnicTypeCodeSLN"/&gt;
 *         &lt;element name="GlblPartnr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GlobalPartnerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreProductDistributionInformationType", propOrder = {
    "cntrctlRltionship",
    "distribtnMarkt",
    "distribtnTechnc",
    "glblPartnr"
})
public class CoreProductDistributionInformationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CntrctlRltionship", required = true)
    protected String cntrctlRltionship;
    @XmlElement(name = "DistribtnMarkt", required = true)
    protected String distribtnMarkt;
    @XmlElement(name = "DistribtnTechnc", required = true)
    protected String distribtnTechnc;
    @XmlElement(name = "GlblPartnr")
    protected GlobalPartnerType glblPartnr;

    /**
     * Default no-arg constructor
     * 
     */
    public CoreProductDistributionInformationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoreProductDistributionInformationType(final String cntrctlRltionship, final String distribtnMarkt, final String distribtnTechnc, final GlobalPartnerType glblPartnr) {
        this.cntrctlRltionship = cntrctlRltionship;
        this.distribtnMarkt = distribtnMarkt;
        this.distribtnTechnc = distribtnTechnc;
        this.glblPartnr = glblPartnr;
    }

    /**
     * Gets the value of the cntrctlRltionship property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCntrctlRltionship() {
        return cntrctlRltionship;
    }

    /**
     * Sets the value of the cntrctlRltionship property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCntrctlRltionship(String value) {
        this.cntrctlRltionship = value;
    }

    public boolean isSetCntrctlRltionship() {
        return (this.cntrctlRltionship!= null);
    }

    /**
     * Gets the value of the distribtnMarkt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistribtnMarkt() {
        return distribtnMarkt;
    }

    /**
     * Sets the value of the distribtnMarkt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistribtnMarkt(String value) {
        this.distribtnMarkt = value;
    }

    public boolean isSetDistribtnMarkt() {
        return (this.distribtnMarkt!= null);
    }

    /**
     * Gets the value of the distribtnTechnc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistribtnTechnc() {
        return distribtnTechnc;
    }

    /**
     * Sets the value of the distribtnTechnc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistribtnTechnc(String value) {
        this.distribtnTechnc = value;
    }

    public boolean isSetDistribtnTechnc() {
        return (this.distribtnTechnc!= null);
    }

    /**
     * Gets the value of the glblPartnr property.
     * 
     * @return
     *     possible object is
     *     {@link GlobalPartnerType }
     *     
     */
    public GlobalPartnerType getGlblPartnr() {
        return glblPartnr;
    }

    /**
     * Sets the value of the glblPartnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link GlobalPartnerType }
     *     
     */
    public void setGlblPartnr(GlobalPartnerType value) {
        this.glblPartnr = value;
    }

    public boolean isSetGlblPartnr() {
        return (this.glblPartnr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cntrctlRltionship", cntrctlRltionship).add("distribtnMarkt", distribtnMarkt).add("distribtnTechnc", distribtnTechnc).add("glblPartnr", glblPartnr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cntrctlRltionship, distribtnMarkt, distribtnTechnc, glblPartnr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoreProductDistributionInformationType o = ((CoreProductDistributionInformationType) other);
        return (((Objects.equal(cntrctlRltionship, o.cntrctlRltionship)&&Objects.equal(distribtnMarkt, o.distribtnMarkt))&&Objects.equal(distribtnTechnc, o.distribtnTechnc))&&Objects.equal(glblPartnr, o.glblPartnr));
    }

}
