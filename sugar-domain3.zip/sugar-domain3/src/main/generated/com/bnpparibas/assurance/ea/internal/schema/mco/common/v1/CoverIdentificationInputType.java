
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information about the identification
 * 				of a cover, package and plan
 * 			
 * 
 * <p>Java class for CoverIdentificationInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverIdentificationInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PdctCovId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="PdctCovPlanId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="PdctPckgeId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverIdentificationInputType", propOrder = {
    "pdctCovId",
    "pdctCovPlanId",
    "pdctPckgeId"
})
public class CoverIdentificationInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PdctCovId")
    protected String pdctCovId;
    @XmlElement(name = "PdctCovPlanId")
    protected String pdctCovPlanId;
    @XmlElement(name = "PdctPckgeId")
    protected String pdctPckgeId;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverIdentificationInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverIdentificationInputType(final String pdctCovId, final String pdctCovPlanId, final String pdctPckgeId) {
        this.pdctCovId = pdctCovId;
        this.pdctCovPlanId = pdctCovPlanId;
        this.pdctPckgeId = pdctPckgeId;
    }

    /**
     * Gets the value of the pdctCovId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctCovId() {
        return pdctCovId;
    }

    /**
     * Sets the value of the pdctCovId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctCovId(String value) {
        this.pdctCovId = value;
    }

    public boolean isSetPdctCovId() {
        return (this.pdctCovId!= null);
    }

    /**
     * Gets the value of the pdctCovPlanId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctCovPlanId() {
        return pdctCovPlanId;
    }

    /**
     * Sets the value of the pdctCovPlanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctCovPlanId(String value) {
        this.pdctCovPlanId = value;
    }

    public boolean isSetPdctCovPlanId() {
        return (this.pdctCovPlanId!= null);
    }

    /**
     * Gets the value of the pdctPckgeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctPckgeId() {
        return pdctPckgeId;
    }

    /**
     * Sets the value of the pdctPckgeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctPckgeId(String value) {
        this.pdctPckgeId = value;
    }

    public boolean isSetPdctPckgeId() {
        return (this.pdctPckgeId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdctCovId", pdctCovId).add("pdctCovPlanId", pdctCovPlanId).add("pdctPckgeId", pdctPckgeId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdctCovId, pdctCovPlanId, pdctPckgeId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverIdentificationInputType o = ((CoverIdentificationInputType) other);
        return ((Objects.equal(pdctCovId, o.pdctCovId)&&Objects.equal(pdctCovPlanId, o.pdctCovPlanId))&&Objects.equal(pdctPckgeId, o.pdctPckgeId));
    }

}
