
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for CoverAuthorizedBenficiaryClauseDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverAuthorizedBenficiaryClauseDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClauseTypeCodeSLN"/&gt;
 *         &lt;element name="StdClauseId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StandardBeneficiaryClauseCode" minOccurs="0"/&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverAuthorizedBenficiaryClauseDataType", propOrder = {
    "type",
    "stdClauseId",
    "applctnPrd"
})
public class CoverAuthorizedBenficiaryClauseDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "StdClauseId")
    protected String stdClauseId;
    @XmlElement(name = "ApplctnPrd")
    protected DatePeriodType applctnPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverAuthorizedBenficiaryClauseDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverAuthorizedBenficiaryClauseDataType(final String type, final String stdClauseId, final DatePeriodType applctnPrd) {
        this.type = type;
        this.stdClauseId = stdClauseId;
        this.applctnPrd = applctnPrd;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the stdClauseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdClauseId() {
        return stdClauseId;
    }

    /**
     * Sets the value of the stdClauseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdClauseId(String value) {
        this.stdClauseId = value;
    }

    public boolean isSetStdClauseId() {
        return (this.stdClauseId!= null);
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("stdClauseId", stdClauseId).add("applctnPrd", applctnPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, stdClauseId, applctnPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverAuthorizedBenficiaryClauseDataType o = ((CoverAuthorizedBenficiaryClauseDataType) other);
        return ((Objects.equal(type, o.type)&&Objects.equal(stdClauseId, o.stdClauseId))&&Objects.equal(applctnPrd, o.applctnPrd));
    }

}
