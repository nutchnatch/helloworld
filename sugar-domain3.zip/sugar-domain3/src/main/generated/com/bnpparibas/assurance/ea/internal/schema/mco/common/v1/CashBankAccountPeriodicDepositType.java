
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on periodic deposit for a cash
 * 				bank account
 * 			
 * 
 * <p>Java class for CashBankAccountPeriodicDepositType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountPeriodicDepositType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeSchedlrIdntcn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="SchedlrStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodicOperationSchedulerStatusDataType"/&gt;
 *         &lt;element name="SchedlrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CashBankAccountPeriodicDepositDataType"/&gt;
 *         &lt;element name="PaymntRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentMethodWithPayerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountPeriodicDepositType", propOrder = {
    "opeSchedlrIdntcn",
    "schedlrStatus",
    "schedlrData",
    "paymntRef"
})
public class CashBankAccountPeriodicDepositType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeSchedlrIdntcn")
    protected ObjectIdentificationType opeSchedlrIdntcn;
    @XmlElement(name = "SchedlrStatus", required = true)
    protected PeriodicOperationSchedulerStatusDataType schedlrStatus;
    @XmlElement(name = "SchedlrData", required = true)
    protected CashBankAccountPeriodicDepositDataType schedlrData;
    @XmlElement(name = "PaymntRef")
    protected PaymentMethodWithPayerType paymntRef;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountPeriodicDepositType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountPeriodicDepositType(final ObjectIdentificationType opeSchedlrIdntcn, final PeriodicOperationSchedulerStatusDataType schedlrStatus, final CashBankAccountPeriodicDepositDataType schedlrData, final PaymentMethodWithPayerType paymntRef) {
        this.opeSchedlrIdntcn = opeSchedlrIdntcn;
        this.schedlrStatus = schedlrStatus;
        this.schedlrData = schedlrData;
        this.paymntRef = paymntRef;
    }

    /**
     * Gets the value of the opeSchedlrIdntcn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getOpeSchedlrIdntcn() {
        return opeSchedlrIdntcn;
    }

    /**
     * Sets the value of the opeSchedlrIdntcn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setOpeSchedlrIdntcn(ObjectIdentificationType value) {
        this.opeSchedlrIdntcn = value;
    }

    public boolean isSetOpeSchedlrIdntcn() {
        return (this.opeSchedlrIdntcn!= null);
    }

    /**
     * Gets the value of the schedlrStatus property.
     * 
     * @return
     *     possible object is
     *     {@link PeriodicOperationSchedulerStatusDataType }
     *     
     */
    public PeriodicOperationSchedulerStatusDataType getSchedlrStatus() {
        return schedlrStatus;
    }

    /**
     * Sets the value of the schedlrStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link PeriodicOperationSchedulerStatusDataType }
     *     
     */
    public void setSchedlrStatus(PeriodicOperationSchedulerStatusDataType value) {
        this.schedlrStatus = value;
    }

    public boolean isSetSchedlrStatus() {
        return (this.schedlrStatus!= null);
    }

    /**
     * Gets the value of the schedlrData property.
     * 
     * @return
     *     possible object is
     *     {@link CashBankAccountPeriodicDepositDataType }
     *     
     */
    public CashBankAccountPeriodicDepositDataType getSchedlrData() {
        return schedlrData;
    }

    /**
     * Sets the value of the schedlrData property.
     * 
     * @param value
     *     allowed object is
     *     {@link CashBankAccountPeriodicDepositDataType }
     *     
     */
    public void setSchedlrData(CashBankAccountPeriodicDepositDataType value) {
        this.schedlrData = value;
    }

    public boolean isSetSchedlrData() {
        return (this.schedlrData!= null);
    }

    /**
     * Gets the value of the paymntRef property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodWithPayerType }
     *     
     */
    public PaymentMethodWithPayerType getPaymntRef() {
        return paymntRef;
    }

    /**
     * Sets the value of the paymntRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodWithPayerType }
     *     
     */
    public void setPaymntRef(PaymentMethodWithPayerType value) {
        this.paymntRef = value;
    }

    public boolean isSetPaymntRef() {
        return (this.paymntRef!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeSchedlrIdntcn", opeSchedlrIdntcn).add("schedlrStatus", schedlrStatus).add("schedlrData", schedlrData).add("paymntRef", paymntRef).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeSchedlrIdntcn, schedlrStatus, schedlrData, paymntRef);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountPeriodicDepositType o = ((CashBankAccountPeriodicDepositType) other);
        return (((Objects.equal(opeSchedlrIdntcn, o.opeSchedlrIdntcn)&&Objects.equal(schedlrStatus, o.schedlrStatus))&&Objects.equal(schedlrData, o.schedlrData))&&Objects.equal(paymntRef, o.paymntRef));
    }

}
