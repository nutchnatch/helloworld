
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Commercial offer on a cash bank account
 * 			
 * 
 * <p>Java class for CashBankAccountCommercialOfferType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountCommercialOfferType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommercialOfferTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="ComrclztnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType"/&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="StdRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType"/&gt;
 *         &lt;element name="PromtnlRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType"/&gt;
 *         &lt;element name="MaxAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountCommercialOfferType", propOrder = {
    "idntfctn",
    "type",
    "name",
    "comrclztnPrd",
    "applctnPrd",
    "stdRate",
    "promtnlRate",
    "maxAmnt"
})
public class CashBankAccountCommercialOfferType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn")
    protected ObjectIdentificationType idntfctn;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "ComrclztnPrd", required = true)
    protected DatePeriodType comrclztnPrd;
    @XmlElement(name = "ApplctnPrd")
    protected DatePeriodType applctnPrd;
    @XmlElement(name = "StdRate")
    protected double stdRate;
    @XmlElement(name = "PromtnlRate")
    protected double promtnlRate;
    @XmlElement(name = "MaxAmnt")
    protected double maxAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountCommercialOfferType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountCommercialOfferType(final ObjectIdentificationType idntfctn, final String type, final String name, final DatePeriodType comrclztnPrd, final DatePeriodType applctnPrd, final double stdRate, final double promtnlRate, final double maxAmnt) {
        this.idntfctn = idntfctn;
        this.type = type;
        this.name = name;
        this.comrclztnPrd = comrclztnPrd;
        this.applctnPrd = applctnPrd;
        this.stdRate = stdRate;
        this.promtnlRate = promtnlRate;
        this.maxAmnt = maxAmnt;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntfctn(ObjectIdentificationType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the comrclztnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getComrclztnPrd() {
        return comrclztnPrd;
    }

    /**
     * Sets the value of the comrclztnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setComrclztnPrd(DatePeriodType value) {
        this.comrclztnPrd = value;
    }

    public boolean isSetComrclztnPrd() {
        return (this.comrclztnPrd!= null);
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    /**
     * Gets the value of the stdRate property.
     * 
     */
    public double getStdRate() {
        return stdRate;
    }

    /**
     * Sets the value of the stdRate property.
     * 
     */
    public void setStdRate(double value) {
        this.stdRate = value;
    }

    public boolean isSetStdRate() {
        return true;
    }

    /**
     * Gets the value of the promtnlRate property.
     * 
     */
    public double getPromtnlRate() {
        return promtnlRate;
    }

    /**
     * Sets the value of the promtnlRate property.
     * 
     */
    public void setPromtnlRate(double value) {
        this.promtnlRate = value;
    }

    public boolean isSetPromtnlRate() {
        return true;
    }

    /**
     * Gets the value of the maxAmnt property.
     * 
     */
    public double getMaxAmnt() {
        return maxAmnt;
    }

    /**
     * Sets the value of the maxAmnt property.
     * 
     */
    public void setMaxAmnt(double value) {
        this.maxAmnt = value;
    }

    public boolean isSetMaxAmnt() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("type", type).add("name", name).add("comrclztnPrd", comrclztnPrd).add("applctnPrd", applctnPrd).add("stdRate", stdRate).add("promtnlRate", promtnlRate).add("maxAmnt", maxAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, type, name, comrclztnPrd, applctnPrd, stdRate, promtnlRate, maxAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountCommercialOfferType o = ((CashBankAccountCommercialOfferType) other);
        return (((((((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(type, o.type))&&Objects.equal(name, o.name))&&Objects.equal(comrclztnPrd, o.comrclztnPrd))&&Objects.equal(applctnPrd, o.applctnPrd))&&Objects.equal(stdRate, o.stdRate))&&Objects.equal(promtnlRate, o.promtnlRate))&&Objects.equal(maxAmnt, o.maxAmnt));
    }

}
