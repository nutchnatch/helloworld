
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Document ID(s)
 * 				description.
 * 			
 * 
 * <p>Java class for DocumentIdntfctnType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentIdntfctnType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Busnss" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="TechnId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EDMSIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentIdntfctnType", propOrder = {
    "busnss",
    "technId"
})
public class DocumentIdntfctnType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Busnss")
    protected ObjectIdentificationType busnss;
    @XmlElement(name = "TechnId")
    protected EDMSIdentificationType technId;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentIdntfctnType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentIdntfctnType(final ObjectIdentificationType busnss, final EDMSIdentificationType technId) {
        this.busnss = busnss;
        this.technId = technId;
    }

    /**
     * Gets the value of the busnss property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getBusnss() {
        return busnss;
    }

    /**
     * Sets the value of the busnss property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setBusnss(ObjectIdentificationType value) {
        this.busnss = value;
    }

    public boolean isSetBusnss() {
        return (this.busnss!= null);
    }

    /**
     * Gets the value of the technId property.
     * 
     * @return
     *     possible object is
     *     {@link EDMSIdentificationType }
     *     
     */
    public EDMSIdentificationType getTechnId() {
        return technId;
    }

    /**
     * Sets the value of the technId property.
     * 
     * @param value
     *     allowed object is
     *     {@link EDMSIdentificationType }
     *     
     */
    public void setTechnId(EDMSIdentificationType value) {
        this.technId = value;
    }

    public boolean isSetTechnId() {
        return (this.technId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("busnss", busnss).add("technId", technId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(busnss, technId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentIdntfctnType o = ((DocumentIdntfctnType) other);
        return (Objects.equal(busnss, o.busnss)&&Objects.equal(technId, o.technId));
    }

}
