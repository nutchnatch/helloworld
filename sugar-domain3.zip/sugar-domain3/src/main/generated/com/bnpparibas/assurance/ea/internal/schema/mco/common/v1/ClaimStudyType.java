
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Claim study type
 * 
 * <p>Java class for ClaimStudyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimStudyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimStudyFunctionalStatusDataType"/&gt;
 *         &lt;element name="LinkdObjcts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimStudyLinkedObjectsType"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimStudyDataType"/&gt;
 *         &lt;element name="AnalysisPnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimStudyPointType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Actn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimActionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ThrdPrtyDecsn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ThirdPartyDecisionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ExprtReprt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExpertReportType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Doc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ClaimBnft" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimBenefitType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PartyData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SimplifiedCustomerInputDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimStudyType", propOrder = {
    "id",
    "status",
    "linkdObjcts",
    "data",
    "analysisPnt",
    "actn",
    "thrdPrtyDecsn",
    "exprtReprt",
    "doc",
    "claimBnft",
    "partyData"
})
public class ClaimStudyType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id", required = true)
    protected String id;
    @XmlElement(name = "Status", required = true)
    protected ClaimStudyFunctionalStatusDataType status;
    @XmlElement(name = "LinkdObjcts", required = true)
    protected ClaimStudyLinkedObjectsType linkdObjcts;
    @XmlElement(name = "Data", required = true)
    protected ClaimStudyDataType data;
    @XmlElement(name = "AnalysisPnt")
    protected List<ClaimStudyPointType> analysisPnt;
    @XmlElement(name = "Actn")
    protected List<ClaimActionType> actn;
    @XmlElement(name = "ThrdPrtyDecsn")
    protected List<ThirdPartyDecisionType> thrdPrtyDecsn;
    @XmlElement(name = "ExprtReprt")
    protected List<ExpertReportType> exprtReprt;
    @XmlElement(name = "Doc")
    protected List<DocumentDataType> doc;
    @XmlElement(name = "ClaimBnft")
    protected List<ClaimBenefitType> claimBnft;
    @XmlElement(name = "PartyData")
    protected List<SimplifiedCustomerInputDataType> partyData;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimStudyType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimStudyType(final String id, final ClaimStudyFunctionalStatusDataType status, final ClaimStudyLinkedObjectsType linkdObjcts, final ClaimStudyDataType data, final List<ClaimStudyPointType> analysisPnt, final List<ClaimActionType> actn, final List<ThirdPartyDecisionType> thrdPrtyDecsn, final List<ExpertReportType> exprtReprt, final List<DocumentDataType> doc, final List<ClaimBenefitType> claimBnft, final List<SimplifiedCustomerInputDataType> partyData) {
        this.id = id;
        this.status = status;
        this.linkdObjcts = linkdObjcts;
        this.data = data;
        this.analysisPnt = analysisPnt;
        this.actn = actn;
        this.thrdPrtyDecsn = thrdPrtyDecsn;
        this.exprtReprt = exprtReprt;
        this.doc = doc;
        this.claimBnft = claimBnft;
        this.partyData = partyData;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimStudyFunctionalStatusDataType }
     *     
     */
    public ClaimStudyFunctionalStatusDataType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimStudyFunctionalStatusDataType }
     *     
     */
    public void setStatus(ClaimStudyFunctionalStatusDataType value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the linkdObjcts property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimStudyLinkedObjectsType }
     *     
     */
    public ClaimStudyLinkedObjectsType getLinkdObjcts() {
        return linkdObjcts;
    }

    /**
     * Sets the value of the linkdObjcts property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimStudyLinkedObjectsType }
     *     
     */
    public void setLinkdObjcts(ClaimStudyLinkedObjectsType value) {
        this.linkdObjcts = value;
    }

    public boolean isSetLinkdObjcts() {
        return (this.linkdObjcts!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimStudyDataType }
     *     
     */
    public ClaimStudyDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimStudyDataType }
     *     
     */
    public void setData(ClaimStudyDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the analysisPnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the analysisPnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAnalysisPnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClaimStudyPointType }
     * 
     * 
     */
    public List<ClaimStudyPointType> getAnalysisPnt() {
        if (analysisPnt == null) {
            analysisPnt = new ArrayList<ClaimStudyPointType>();
        }
        return this.analysisPnt;
    }

    public boolean isSetAnalysisPnt() {
        return ((this.analysisPnt!= null)&&(!this.analysisPnt.isEmpty()));
    }

    public void unsetAnalysisPnt() {
        this.analysisPnt = null;
    }

    /**
     * Gets the value of the actn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClaimActionType }
     * 
     * 
     */
    public List<ClaimActionType> getActn() {
        if (actn == null) {
            actn = new ArrayList<ClaimActionType>();
        }
        return this.actn;
    }

    public boolean isSetActn() {
        return ((this.actn!= null)&&(!this.actn.isEmpty()));
    }

    public void unsetActn() {
        this.actn = null;
    }

    /**
     * Gets the value of the thrdPrtyDecsn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the thrdPrtyDecsn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getThrdPrtyDecsn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ThirdPartyDecisionType }
     * 
     * 
     */
    public List<ThirdPartyDecisionType> getThrdPrtyDecsn() {
        if (thrdPrtyDecsn == null) {
            thrdPrtyDecsn = new ArrayList<ThirdPartyDecisionType>();
        }
        return this.thrdPrtyDecsn;
    }

    public boolean isSetThrdPrtyDecsn() {
        return ((this.thrdPrtyDecsn!= null)&&(!this.thrdPrtyDecsn.isEmpty()));
    }

    public void unsetThrdPrtyDecsn() {
        this.thrdPrtyDecsn = null;
    }

    /**
     * Gets the value of the exprtReprt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the exprtReprt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExprtReprt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExpertReportType }
     * 
     * 
     */
    public List<ExpertReportType> getExprtReprt() {
        if (exprtReprt == null) {
            exprtReprt = new ArrayList<ExpertReportType>();
        }
        return this.exprtReprt;
    }

    public boolean isSetExprtReprt() {
        return ((this.exprtReprt!= null)&&(!this.exprtReprt.isEmpty()));
    }

    public void unsetExprtReprt() {
        this.exprtReprt = null;
    }

    /**
     * Gets the value of the doc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the doc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDoc().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentDataType }
     * 
     * 
     */
    public List<DocumentDataType> getDoc() {
        if (doc == null) {
            doc = new ArrayList<DocumentDataType>();
        }
        return this.doc;
    }

    public boolean isSetDoc() {
        return ((this.doc!= null)&&(!this.doc.isEmpty()));
    }

    public void unsetDoc() {
        this.doc = null;
    }

    /**
     * Gets the value of the claimBnft property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the claimBnft property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClaimBnft().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClaimBenefitType }
     * 
     * 
     */
    public List<ClaimBenefitType> getClaimBnft() {
        if (claimBnft == null) {
            claimBnft = new ArrayList<ClaimBenefitType>();
        }
        return this.claimBnft;
    }

    public boolean isSetClaimBnft() {
        return ((this.claimBnft!= null)&&(!this.claimBnft.isEmpty()));
    }

    public void unsetClaimBnft() {
        this.claimBnft = null;
    }

    /**
     * Gets the value of the partyData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SimplifiedCustomerInputDataType }
     * 
     * 
     */
    public List<SimplifiedCustomerInputDataType> getPartyData() {
        if (partyData == null) {
            partyData = new ArrayList<SimplifiedCustomerInputDataType>();
        }
        return this.partyData;
    }

    public boolean isSetPartyData() {
        return ((this.partyData!= null)&&(!this.partyData.isEmpty()));
    }

    public void unsetPartyData() {
        this.partyData = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("status", status).add("linkdObjcts", linkdObjcts).add("data", data).add("analysisPnt", analysisPnt).add("actn", actn).add("thrdPrtyDecsn", thrdPrtyDecsn).add("exprtReprt", exprtReprt).add("doc", doc).add("claimBnft", claimBnft).add("partyData", partyData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, status, linkdObjcts, data, analysisPnt, actn, thrdPrtyDecsn, exprtReprt, doc, claimBnft, partyData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimStudyType o = ((ClaimStudyType) other);
        return ((((((((((Objects.equal(id, o.id)&&Objects.equal(status, o.status))&&Objects.equal(linkdObjcts, o.linkdObjcts))&&Objects.equal(data, o.data))&&Objects.equal(analysisPnt, o.analysisPnt))&&Objects.equal(actn, o.actn))&&Objects.equal(thrdPrtyDecsn, o.thrdPrtyDecsn))&&Objects.equal(exprtReprt, o.exprtReprt))&&Objects.equal(doc, o.doc))&&Objects.equal(claimBnft, o.claimBnft))&&Objects.equal(partyData, o.partyData));
    }

}
