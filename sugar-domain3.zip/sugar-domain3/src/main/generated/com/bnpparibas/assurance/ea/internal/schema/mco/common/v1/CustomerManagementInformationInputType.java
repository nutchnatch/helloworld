
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information for the communication
 * 				with the customer
 * 			
 * 
 * <p>Java class for CustomerManagementInformationInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomerManagementInformationInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Lang" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LocalType" minOccurs="0"/&gt;
 *         &lt;element name="ActvIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="FrstCntctChnnl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommunicationChannelCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ComrclInfoPrdcity" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ComrclInfoStop" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="EschetIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="ComrclMgmtSpecType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ManagementSpecificTypeCode" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerManagementInformationInputType", propOrder = {
    "lang",
    "actvIndic",
    "frstCntctChnnl",
    "comrclInfoPrdcity",
    "comrclInfoStop",
    "eschetIndic",
    "comrclMgmtSpecType"
})
public class CustomerManagementInformationInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Lang")
    protected LocalType lang;
    @XmlElement(name = "ActvIndic")
    protected String actvIndic;
    @XmlElement(name = "FrstCntctChnnl")
    protected String frstCntctChnnl;
    @XmlElement(name = "ComrclInfoPrdcity")
    protected String comrclInfoPrdcity;
    @XmlElement(name = "ComrclInfoStop")
    protected String comrclInfoStop;
    @XmlElement(name = "EschetIndic")
    protected String eschetIndic;
    @XmlElement(name = "ComrclMgmtSpecType")
    protected String comrclMgmtSpecType;

    /**
     * Default no-arg constructor
     * 
     */
    public CustomerManagementInformationInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CustomerManagementInformationInputType(final LocalType lang, final String actvIndic, final String frstCntctChnnl, final String comrclInfoPrdcity, final String comrclInfoStop, final String eschetIndic, final String comrclMgmtSpecType) {
        this.lang = lang;
        this.actvIndic = actvIndic;
        this.frstCntctChnnl = frstCntctChnnl;
        this.comrclInfoPrdcity = comrclInfoPrdcity;
        this.comrclInfoStop = comrclInfoStop;
        this.eschetIndic = eschetIndic;
        this.comrclMgmtSpecType = comrclMgmtSpecType;
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link LocalType }
     *     
     */
    public LocalType getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocalType }
     *     
     */
    public void setLang(LocalType value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    /**
     * Gets the value of the actvIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActvIndic() {
        return actvIndic;
    }

    /**
     * Sets the value of the actvIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActvIndic(String value) {
        this.actvIndic = value;
    }

    public boolean isSetActvIndic() {
        return (this.actvIndic!= null);
    }

    /**
     * Gets the value of the frstCntctChnnl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrstCntctChnnl() {
        return frstCntctChnnl;
    }

    /**
     * Sets the value of the frstCntctChnnl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrstCntctChnnl(String value) {
        this.frstCntctChnnl = value;
    }

    public boolean isSetFrstCntctChnnl() {
        return (this.frstCntctChnnl!= null);
    }

    /**
     * Gets the value of the comrclInfoPrdcity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComrclInfoPrdcity() {
        return comrclInfoPrdcity;
    }

    /**
     * Sets the value of the comrclInfoPrdcity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComrclInfoPrdcity(String value) {
        this.comrclInfoPrdcity = value;
    }

    public boolean isSetComrclInfoPrdcity() {
        return (this.comrclInfoPrdcity!= null);
    }

    /**
     * Gets the value of the comrclInfoStop property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComrclInfoStop() {
        return comrclInfoStop;
    }

    /**
     * Sets the value of the comrclInfoStop property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComrclInfoStop(String value) {
        this.comrclInfoStop = value;
    }

    public boolean isSetComrclInfoStop() {
        return (this.comrclInfoStop!= null);
    }

    /**
     * Gets the value of the eschetIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEschetIndic() {
        return eschetIndic;
    }

    /**
     * Sets the value of the eschetIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEschetIndic(String value) {
        this.eschetIndic = value;
    }

    public boolean isSetEschetIndic() {
        return (this.eschetIndic!= null);
    }

    /**
     * Gets the value of the comrclMgmtSpecType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComrclMgmtSpecType() {
        return comrclMgmtSpecType;
    }

    /**
     * Sets the value of the comrclMgmtSpecType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComrclMgmtSpecType(String value) {
        this.comrclMgmtSpecType = value;
    }

    public boolean isSetComrclMgmtSpecType() {
        return (this.comrclMgmtSpecType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("lang", lang).add("actvIndic", actvIndic).add("frstCntctChnnl", frstCntctChnnl).add("comrclInfoPrdcity", comrclInfoPrdcity).add("comrclInfoStop", comrclInfoStop).add("eschetIndic", eschetIndic).add("comrclMgmtSpecType", comrclMgmtSpecType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(lang, actvIndic, frstCntctChnnl, comrclInfoPrdcity, comrclInfoStop, eschetIndic, comrclMgmtSpecType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CustomerManagementInformationInputType o = ((CustomerManagementInformationInputType) other);
        return ((((((Objects.equal(lang, o.lang)&&Objects.equal(actvIndic, o.actvIndic))&&Objects.equal(frstCntctChnnl, o.frstCntctChnnl))&&Objects.equal(comrclInfoPrdcity, o.comrclInfoPrdcity))&&Objects.equal(comrclInfoStop, o.comrclInfoStop))&&Objects.equal(eschetIndic, o.eschetIndic))&&Objects.equal(comrclMgmtSpecType, o.comrclMgmtSpecType));
    }

}
