
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Rate with base (100, 1000, etc)
 * 
 * <p>Java class for BasisRateType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BasisRateType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;DecimalNumberType"&gt;
 *       &lt;attribute name="RateBasis" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BasisRateType", propOrder = {
    "value"
})
public class BasisRateType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected double value;
    @XmlAttribute(name = "RateBasis", required = true)
    protected BigInteger rateBasis;

    /**
     * Default no-arg constructor
     * 
     */
    public BasisRateType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BasisRateType(final double value, final BigInteger rateBasis) {
        this.value = value;
        this.rateBasis = rateBasis;
    }

    /**
     * To define the format of decimal numbers
     * 			
     * 
     */
    public double getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     */
    public void setValue(double value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return true;
    }

    /**
     * Gets the value of the rateBasis property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRateBasis() {
        return rateBasis;
    }

    /**
     * Sets the value of the rateBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRateBasis(BigInteger value) {
        this.rateBasis = value;
    }

    public boolean isSetRateBasis() {
        return (this.rateBasis!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("rateBasis", rateBasis).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, rateBasis);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BasisRateType o = ((BasisRateType) other);
        return (Objects.equal(value, o.value)&&Objects.equal(rateBasis, o.rateBasis));
    }

}
