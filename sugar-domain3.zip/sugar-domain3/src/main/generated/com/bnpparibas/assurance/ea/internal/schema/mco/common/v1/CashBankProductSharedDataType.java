
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage shared data on banking product
 * 			
 * 
 * <p>Java class for CashBankProductSharedDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankProductSharedDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PdctIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="PdctType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankingProductTypeCode"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankProductSharedDataType", propOrder = {
    "pdctIdntfctn",
    "pdctType"
})
public class CashBankProductSharedDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PdctIdntfctn")
    protected ObjectIdentificationType pdctIdntfctn;
    @XmlElement(name = "PdctType", required = true)
    protected String pdctType;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankProductSharedDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankProductSharedDataType(final ObjectIdentificationType pdctIdntfctn, final String pdctType) {
        this.pdctIdntfctn = pdctIdntfctn;
        this.pdctType = pdctType;
    }

    /**
     * Gets the value of the pdctIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPdctIdntfctn() {
        return pdctIdntfctn;
    }

    /**
     * Sets the value of the pdctIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPdctIdntfctn(ObjectIdentificationType value) {
        this.pdctIdntfctn = value;
    }

    public boolean isSetPdctIdntfctn() {
        return (this.pdctIdntfctn!= null);
    }

    /**
     * Gets the value of the pdctType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctType() {
        return pdctType;
    }

    /**
     * Sets the value of the pdctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctType(String value) {
        this.pdctType = value;
    }

    public boolean isSetPdctType() {
        return (this.pdctType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdctIdntfctn", pdctIdntfctn).add("pdctType", pdctType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdctIdntfctn, pdctType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankProductSharedDataType o = ((CashBankProductSharedDataType) other);
        return (Objects.equal(pdctIdntfctn, o.pdctIdntfctn)&&Objects.equal(pdctType, o.pdctType));
    }

}
