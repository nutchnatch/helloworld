
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on the addresses of a structure
 * 				element
 * 			
 * 
 * <p>Java class for AllCommunicationAddressesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AllCommunicationAddressesType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Post" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PostalAddressWithValidityStatusType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Phone" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PhoneAddressType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Email" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmailAddressType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Web" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}WebAddressType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AllCommunicationAddressesType", propOrder = {
    "post",
    "phone",
    "email",
    "web"
})
public class AllCommunicationAddressesType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Post")
    protected List<PostalAddressWithValidityStatusType> post;
    @XmlElement(name = "Phone")
    protected List<PhoneAddressType> phone;
    @XmlElement(name = "Email")
    protected List<EmailAddressType> email;
    @XmlElement(name = "Web")
    protected List<WebAddressType> web;

    /**
     * Default no-arg constructor
     * 
     */
    public AllCommunicationAddressesType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AllCommunicationAddressesType(final List<PostalAddressWithValidityStatusType> post, final List<PhoneAddressType> phone, final List<EmailAddressType> email, final List<WebAddressType> web) {
        this.post = post;
        this.phone = phone;
        this.email = email;
        this.web = web;
    }

    /**
     * Gets the value of the post property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the post property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPost().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PostalAddressWithValidityStatusType }
     * 
     * 
     */
    public List<PostalAddressWithValidityStatusType> getPost() {
        if (post == null) {
            post = new ArrayList<PostalAddressWithValidityStatusType>();
        }
        return this.post;
    }

    public boolean isSetPost() {
        return ((this.post!= null)&&(!this.post.isEmpty()));
    }

    public void unsetPost() {
        this.post = null;
    }

    /**
     * Gets the value of the phone property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phone property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhone().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PhoneAddressType }
     * 
     * 
     */
    public List<PhoneAddressType> getPhone() {
        if (phone == null) {
            phone = new ArrayList<PhoneAddressType>();
        }
        return this.phone;
    }

    public boolean isSetPhone() {
        return ((this.phone!= null)&&(!this.phone.isEmpty()));
    }

    public void unsetPhone() {
        this.phone = null;
    }

    /**
     * Gets the value of the email property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the email property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEmail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EmailAddressType }
     * 
     * 
     */
    public List<EmailAddressType> getEmail() {
        if (email == null) {
            email = new ArrayList<EmailAddressType>();
        }
        return this.email;
    }

    public boolean isSetEmail() {
        return ((this.email!= null)&&(!this.email.isEmpty()));
    }

    public void unsetEmail() {
        this.email = null;
    }

    /**
     * Gets the value of the web property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the web property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWeb().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WebAddressType }
     * 
     * 
     */
    public List<WebAddressType> getWeb() {
        if (web == null) {
            web = new ArrayList<WebAddressType>();
        }
        return this.web;
    }

    public boolean isSetWeb() {
        return ((this.web!= null)&&(!this.web.isEmpty()));
    }

    public void unsetWeb() {
        this.web = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("post", post).add("phone", phone).add("email", email).add("web", web).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(post, phone, email, web);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AllCommunicationAddressesType o = ((AllCommunicationAddressesType) other);
        return (((Objects.equal(post, o.post)&&Objects.equal(phone, o.phone))&&Objects.equal(email, o.email))&&Objects.equal(web, o.web));
    }

}
