
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage global data of a beneficiary claim
 * 				benefit
 * 			
 * 
 * <p>Java class for BeneficiaryClaimBenefitDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneficiaryClaimBenefitDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="DistribRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntsNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntsPrdcity" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneficiaryClaimBenefitDataType", propOrder = {
    "type",
    "amnt",
    "distribRate",
    "paymntsNumb",
    "paymntsPrdcity"
})
public class BeneficiaryClaimBenefitDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "DistribRate")
    protected Double distribRate;
    @XmlElement(name = "PaymntsNumb")
    protected BigInteger paymntsNumb;
    @XmlElement(name = "PaymntsPrdcity")
    protected String paymntsPrdcity;

    /**
     * Default no-arg constructor
     * 
     */
    public BeneficiaryClaimBenefitDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BeneficiaryClaimBenefitDataType(final String type, final CurrencyAndAmountType amnt, final Double distribRate, final BigInteger paymntsNumb, final String paymntsPrdcity) {
        this.type = type;
        this.amnt = amnt;
        this.distribRate = distribRate;
        this.paymntsNumb = paymntsNumb;
        this.paymntsPrdcity = paymntsPrdcity;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the distribRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDistribRate() {
        return distribRate;
    }

    /**
     * Sets the value of the distribRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDistribRate(Double value) {
        this.distribRate = value;
    }

    public boolean isSetDistribRate() {
        return (this.distribRate!= null);
    }

    /**
     * Gets the value of the paymntsNumb property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPaymntsNumb() {
        return paymntsNumb;
    }

    /**
     * Sets the value of the paymntsNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPaymntsNumb(BigInteger value) {
        this.paymntsNumb = value;
    }

    public boolean isSetPaymntsNumb() {
        return (this.paymntsNumb!= null);
    }

    /**
     * Gets the value of the paymntsPrdcity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymntsPrdcity() {
        return paymntsPrdcity;
    }

    /**
     * Sets the value of the paymntsPrdcity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymntsPrdcity(String value) {
        this.paymntsPrdcity = value;
    }

    public boolean isSetPaymntsPrdcity() {
        return (this.paymntsPrdcity!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("amnt", amnt).add("distribRate", distribRate).add("paymntsNumb", paymntsNumb).add("paymntsPrdcity", paymntsPrdcity).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, amnt, distribRate, paymntsNumb, paymntsPrdcity);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BeneficiaryClaimBenefitDataType o = ((BeneficiaryClaimBenefitDataType) other);
        return ((((Objects.equal(type, o.type)&&Objects.equal(amnt, o.amnt))&&Objects.equal(distribRate, o.distribRate))&&Objects.equal(paymntsNumb, o.paymntsNumb))&&Objects.equal(paymntsPrdcity, o.paymntsPrdcity));
    }

}
