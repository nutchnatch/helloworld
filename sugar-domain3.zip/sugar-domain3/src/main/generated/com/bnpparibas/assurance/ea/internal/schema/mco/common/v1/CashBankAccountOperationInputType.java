
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage specific data for operation request
 * 				for banking account (deposit and savings)
 * 			
 * 
 * <p>Java class for CashBankAccountOperationInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountOperationInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SignDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="AcctCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="SavngsAndPrtctnSubscrptnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="TaxationMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxationOptionTypeCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountOperationInputType", propOrder = {
    "signDate",
    "acctCurr",
    "savngsAndPrtctnSubscrptnIndic",
    "taxationMode"
})
public class CashBankAccountOperationInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SignDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date signDate;
    @XmlElement(name = "AcctCurr")
    protected String acctCurr;
    @XmlElement(name = "SavngsAndPrtctnSubscrptnIndic")
    protected String savngsAndPrtctnSubscrptnIndic;
    @XmlElement(name = "TaxationMode")
    protected String taxationMode;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountOperationInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountOperationInputType(final Date signDate, final String acctCurr, final String savngsAndPrtctnSubscrptnIndic, final String taxationMode) {
        this.signDate = signDate;
        this.acctCurr = acctCurr;
        this.savngsAndPrtctnSubscrptnIndic = savngsAndPrtctnSubscrptnIndic;
        this.taxationMode = taxationMode;
    }

    /**
     * Gets the value of the signDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSignDate() {
        return signDate;
    }

    /**
     * Sets the value of the signDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignDate(Date value) {
        this.signDate = value;
    }

    public boolean isSetSignDate() {
        return (this.signDate!= null);
    }

    /**
     * Gets the value of the acctCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctCurr() {
        return acctCurr;
    }

    /**
     * Sets the value of the acctCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctCurr(String value) {
        this.acctCurr = value;
    }

    public boolean isSetAcctCurr() {
        return (this.acctCurr!= null);
    }

    /**
     * Gets the value of the savngsAndPrtctnSubscrptnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSavngsAndPrtctnSubscrptnIndic() {
        return savngsAndPrtctnSubscrptnIndic;
    }

    /**
     * Sets the value of the savngsAndPrtctnSubscrptnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSavngsAndPrtctnSubscrptnIndic(String value) {
        this.savngsAndPrtctnSubscrptnIndic = value;
    }

    public boolean isSetSavngsAndPrtctnSubscrptnIndic() {
        return (this.savngsAndPrtctnSubscrptnIndic!= null);
    }

    /**
     * Gets the value of the taxationMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxationMode() {
        return taxationMode;
    }

    /**
     * Sets the value of the taxationMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxationMode(String value) {
        this.taxationMode = value;
    }

    public boolean isSetTaxationMode() {
        return (this.taxationMode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("signDate", signDate).add("acctCurr", acctCurr).add("savngsAndPrtctnSubscrptnIndic", savngsAndPrtctnSubscrptnIndic).add("taxationMode", taxationMode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(signDate, acctCurr, savngsAndPrtctnSubscrptnIndic, taxationMode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountOperationInputType o = ((CashBankAccountOperationInputType) other);
        return (((Objects.equal(signDate, o.signDate)&&Objects.equal(acctCurr, o.acctCurr))&&Objects.equal(savngsAndPrtctnSubscrptnIndic, o.savngsAndPrtctnSubscrptnIndic))&&Objects.equal(taxationMode, o.taxationMode));
    }

}
