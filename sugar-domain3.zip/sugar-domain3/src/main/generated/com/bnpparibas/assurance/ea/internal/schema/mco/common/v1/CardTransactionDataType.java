
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage data on a card transaction
 * 			
 * 
 * <p>Java class for CardTransactionDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardTransactionDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransacNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="AuthoriztnNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="TransacDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardTransactionDataType", propOrder = {
    "transacNumb",
    "authoriztnNumb",
    "transacDate"
})
public class CardTransactionDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "TransacNumb")
    protected ObjectIdentificationType transacNumb;
    @XmlElement(name = "AuthoriztnNumb")
    protected ObjectIdentificationType authoriztnNumb;
    @XmlElement(name = "TransacDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date transacDate;

    /**
     * Default no-arg constructor
     * 
     */
    public CardTransactionDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CardTransactionDataType(final ObjectIdentificationType transacNumb, final ObjectIdentificationType authoriztnNumb, final Date transacDate) {
        this.transacNumb = transacNumb;
        this.authoriztnNumb = authoriztnNumb;
        this.transacDate = transacDate;
    }

    /**
     * Gets the value of the transacNumb property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getTransacNumb() {
        return transacNumb;
    }

    /**
     * Sets the value of the transacNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setTransacNumb(ObjectIdentificationType value) {
        this.transacNumb = value;
    }

    public boolean isSetTransacNumb() {
        return (this.transacNumb!= null);
    }

    /**
     * Gets the value of the authoriztnNumb property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getAuthoriztnNumb() {
        return authoriztnNumb;
    }

    /**
     * Sets the value of the authoriztnNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setAuthoriztnNumb(ObjectIdentificationType value) {
        this.authoriztnNumb = value;
    }

    public boolean isSetAuthoriztnNumb() {
        return (this.authoriztnNumb!= null);
    }

    /**
     * Gets the value of the transacDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getTransacDate() {
        return transacDate;
    }

    /**
     * Sets the value of the transacDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransacDate(Date value) {
        this.transacDate = value;
    }

    public boolean isSetTransacDate() {
        return (this.transacDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("transacNumb", transacNumb).add("authoriztnNumb", authoriztnNumb).add("transacDate", transacDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(transacNumb, authoriztnNumb, transacDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CardTransactionDataType o = ((CardTransactionDataType) other);
        return ((Objects.equal(transacNumb, o.transacNumb)&&Objects.equal(authoriztnNumb, o.authoriztnNumb))&&Objects.equal(transacDate, o.transacDate));
    }

}
