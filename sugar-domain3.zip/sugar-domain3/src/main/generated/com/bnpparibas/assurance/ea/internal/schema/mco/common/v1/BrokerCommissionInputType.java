
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * broker commission description
 * 
 * <p>Java class for BrokerCommissionInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BrokerCommissionInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UpfrontAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="FlatAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BrokerCommissionInputType", propOrder = {
    "upfrontAmnt",
    "flatAmnt",
    "fqcy",
    "rate"
})
public class BrokerCommissionInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "UpfrontAmnt")
    protected CurrencyAndAmountType upfrontAmnt;
    @XmlElement(name = "FlatAmnt")
    protected CurrencyAndAmountType flatAmnt;
    @XmlElement(name = "Fqcy")
    protected String fqcy;
    @XmlElement(name = "Rate")
    protected BasisRateType rate;

    /**
     * Default no-arg constructor
     * 
     */
    public BrokerCommissionInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BrokerCommissionInputType(final CurrencyAndAmountType upfrontAmnt, final CurrencyAndAmountType flatAmnt, final String fqcy, final BasisRateType rate) {
        this.upfrontAmnt = upfrontAmnt;
        this.flatAmnt = flatAmnt;
        this.fqcy = fqcy;
        this.rate = rate;
    }

    /**
     * Gets the value of the upfrontAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getUpfrontAmnt() {
        return upfrontAmnt;
    }

    /**
     * Sets the value of the upfrontAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setUpfrontAmnt(CurrencyAndAmountType value) {
        this.upfrontAmnt = value;
    }

    public boolean isSetUpfrontAmnt() {
        return (this.upfrontAmnt!= null);
    }

    /**
     * Gets the value of the flatAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFlatAmnt() {
        return flatAmnt;
    }

    /**
     * Sets the value of the flatAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFlatAmnt(CurrencyAndAmountType value) {
        this.flatAmnt = value;
    }

    public boolean isSetFlatAmnt() {
        return (this.flatAmnt!= null);
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the rate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getRate() {
        return rate;
    }

    /**
     * Sets the value of the rate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setRate(BasisRateType value) {
        this.rate = value;
    }

    public boolean isSetRate() {
        return (this.rate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("upfrontAmnt", upfrontAmnt).add("flatAmnt", flatAmnt).add("fqcy", fqcy).add("rate", rate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(upfrontAmnt, flatAmnt, fqcy, rate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BrokerCommissionInputType o = ((BrokerCommissionInputType) other);
        return (((Objects.equal(upfrontAmnt, o.upfrontAmnt)&&Objects.equal(flatAmnt, o.flatAmnt))&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(rate, o.rate));
    }

}
