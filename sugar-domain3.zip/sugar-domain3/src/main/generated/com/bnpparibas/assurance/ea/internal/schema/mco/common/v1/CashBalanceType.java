
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on a cash balance
 * 			
 * 
 * <p>Java class for CashBalanceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBalanceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ValueDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="CreditDebtIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CreditDebitIndicatorCodeSLN"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBalanceType", propOrder = {
    "valueDate",
    "creditDebtIndic",
    "amnt"
})
public class CashBalanceType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ValueDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valueDate;
    @XmlElement(name = "CreditDebtIndic", required = true)
    protected String creditDebtIndic;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBalanceType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBalanceType(final Date valueDate, final String creditDebtIndic, final CurrencyAndAmountType amnt) {
        this.valueDate = valueDate;
        this.creditDebtIndic = creditDebtIndic;
        this.amnt = amnt;
    }

    /**
     * Gets the value of the valueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValueDate() {
        return valueDate;
    }

    /**
     * Sets the value of the valueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueDate(Date value) {
        this.valueDate = value;
    }

    public boolean isSetValueDate() {
        return (this.valueDate!= null);
    }

    /**
     * Gets the value of the creditDebtIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditDebtIndic() {
        return creditDebtIndic;
    }

    /**
     * Sets the value of the creditDebtIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditDebtIndic(String value) {
        this.creditDebtIndic = value;
    }

    public boolean isSetCreditDebtIndic() {
        return (this.creditDebtIndic!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("valueDate", valueDate).add("creditDebtIndic", creditDebtIndic).add("amnt", amnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(valueDate, creditDebtIndic, amnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBalanceType o = ((CashBalanceType) other);
        return ((Objects.equal(valueDate, o.valueDate)&&Objects.equal(creditDebtIndic, o.creditDebtIndic))&&Objects.equal(amnt, o.amnt));
    }

}
