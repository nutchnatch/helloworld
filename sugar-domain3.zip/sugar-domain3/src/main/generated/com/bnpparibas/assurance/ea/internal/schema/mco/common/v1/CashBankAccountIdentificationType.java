
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage the identification of a cash banking
 * 				account such as Livret A, Livret Jeune, etc
 * 			
 * 
 * <p>Java class for CashBankAccountIdentificationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountIdentificationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MainId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankAccountIdentificationType"/&gt;
 *         &lt;element name="AddId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountIdentificationType", propOrder = {
    "mainId",
    "addId"
})
public class CashBankAccountIdentificationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "MainId", required = true)
    protected BankAccountIdentificationType mainId;
    @XmlElement(name = "AddId")
    protected List<IdentificationType> addId;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountIdentificationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountIdentificationType(final BankAccountIdentificationType mainId, final List<IdentificationType> addId) {
        this.mainId = mainId;
        this.addId = addId;
    }

    /**
     * Gets the value of the mainId property.
     * 
     * @return
     *     possible object is
     *     {@link BankAccountIdentificationType }
     *     
     */
    public BankAccountIdentificationType getMainId() {
        return mainId;
    }

    /**
     * Sets the value of the mainId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankAccountIdentificationType }
     *     
     */
    public void setMainId(BankAccountIdentificationType value) {
        this.mainId = value;
    }

    public boolean isSetMainId() {
        return (this.mainId!= null);
    }

    /**
     * Gets the value of the addId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentificationType }
     * 
     * 
     */
    public List<IdentificationType> getAddId() {
        if (addId == null) {
            addId = new ArrayList<IdentificationType>();
        }
        return this.addId;
    }

    public boolean isSetAddId() {
        return ((this.addId!= null)&&(!this.addId.isEmpty()));
    }

    public void unsetAddId() {
        this.addId = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("mainId", mainId).add("addId", addId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mainId, addId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountIdentificationType o = ((CashBankAccountIdentificationType) other);
        return (Objects.equal(mainId, o.mainId)&&Objects.equal(addId, o.addId));
    }

}
