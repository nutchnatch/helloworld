
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on payment banking refrences :
 * 				BankAccountAndCreditor and payment card
 * 			
 * 
 * <p>Java class for BankingReferenceAndCreditorType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankingReferenceAndCreditorType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BnkAcct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankAccountAndCreditorDataType" minOccurs="0"/&gt;
 *         &lt;element name="Card" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentCardDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankingReferenceAndCreditorType", propOrder = {
    "bnkAcct",
    "card"
})
public class BankingReferenceAndCreditorType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "BnkAcct")
    protected BankAccountAndCreditorDataType bnkAcct;
    @XmlElement(name = "Card")
    protected PaymentCardDataType card;

    /**
     * Default no-arg constructor
     * 
     */
    public BankingReferenceAndCreditorType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BankingReferenceAndCreditorType(final BankAccountAndCreditorDataType bnkAcct, final PaymentCardDataType card) {
        this.bnkAcct = bnkAcct;
        this.card = card;
    }

    /**
     * Gets the value of the bnkAcct property.
     * 
     * @return
     *     possible object is
     *     {@link BankAccountAndCreditorDataType }
     *     
     */
    public BankAccountAndCreditorDataType getBnkAcct() {
        return bnkAcct;
    }

    /**
     * Sets the value of the bnkAcct property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankAccountAndCreditorDataType }
     *     
     */
    public void setBnkAcct(BankAccountAndCreditorDataType value) {
        this.bnkAcct = value;
    }

    public boolean isSetBnkAcct() {
        return (this.bnkAcct!= null);
    }

    /**
     * Gets the value of the card property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentCardDataType }
     *     
     */
    public PaymentCardDataType getCard() {
        return card;
    }

    /**
     * Sets the value of the card property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentCardDataType }
     *     
     */
    public void setCard(PaymentCardDataType value) {
        this.card = value;
    }

    public boolean isSetCard() {
        return (this.card!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("bnkAcct", bnkAcct).add("card", card).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(bnkAcct, card);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BankingReferenceAndCreditorType o = ((BankingReferenceAndCreditorType) other);
        return (Objects.equal(bnkAcct, o.bnkAcct)&&Objects.equal(card, o.card));
    }

}
