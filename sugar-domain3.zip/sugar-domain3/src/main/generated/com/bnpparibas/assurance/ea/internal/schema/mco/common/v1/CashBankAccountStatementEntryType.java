
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on cash bank account
 * 				movements
 * 			
 * 
 * <p>Java class for CashBankAccountStatementEntryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountStatementEntryType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeCategory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationCategoryCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="EvtCtgory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EventCategoryCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="EvtType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EventTypeCode" minOccurs="0"/&gt;
 *         &lt;element name="AFBEntryType"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="50"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SpecifOpeType" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="EntryDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="RfsalReasn" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ValueDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="LongName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="EntryRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="ChrgeExmptn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="AvlbltyIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="CreditDebtIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CreditDebitIndicatorCodeSLN"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="BookEntry" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountStatementEntryType", propOrder = {
    "opeCategory",
    "opeType",
    "evtCtgory",
    "evtType",
    "afbEntryType",
    "specifOpeType",
    "entryDate",
    "rfsalReasn",
    "valueDate",
    "longName",
    "entryRef",
    "chrgeExmptn",
    "avlbltyIndic",
    "creditDebtIndic",
    "amnt",
    "bookEntry"
})
public class CashBankAccountStatementEntryType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeCategory")
    protected String opeCategory;
    @XmlElement(name = "OpeType", required = true)
    protected String opeType;
    @XmlElement(name = "EvtCtgory")
    protected String evtCtgory;
    @XmlElement(name = "EvtType")
    protected String evtType;
    @XmlElement(name = "AFBEntryType", required = true)
    protected String afbEntryType;
    @XmlElement(name = "SpecifOpeType")
    protected String specifOpeType;
    @XmlElement(name = "EntryDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date entryDate;
    @XmlElement(name = "RfsalReasn")
    protected String rfsalReasn;
    @XmlElement(name = "ValueDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valueDate;
    @XmlElement(name = "LongName", required = true)
    protected String longName;
    @XmlElement(name = "EntryRef")
    protected String entryRef;
    @XmlElement(name = "ChrgeExmptn")
    protected String chrgeExmptn;
    @XmlElement(name = "AvlbltyIndic")
    protected String avlbltyIndic;
    @XmlElement(name = "CreditDebtIndic", required = true)
    protected String creditDebtIndic;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "BookEntry")
    protected String bookEntry;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountStatementEntryType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountStatementEntryType(final String opeCategory, final String opeType, final String evtCtgory, final String evtType, final String afbEntryType, final String specifOpeType, final Date entryDate, final String rfsalReasn, final Date valueDate, final String longName, final String entryRef, final String chrgeExmptn, final String avlbltyIndic, final String creditDebtIndic, final CurrencyAndAmountType amnt, final String bookEntry) {
        this.opeCategory = opeCategory;
        this.opeType = opeType;
        this.evtCtgory = evtCtgory;
        this.evtType = evtType;
        this.afbEntryType = afbEntryType;
        this.specifOpeType = specifOpeType;
        this.entryDate = entryDate;
        this.rfsalReasn = rfsalReasn;
        this.valueDate = valueDate;
        this.longName = longName;
        this.entryRef = entryRef;
        this.chrgeExmptn = chrgeExmptn;
        this.avlbltyIndic = avlbltyIndic;
        this.creditDebtIndic = creditDebtIndic;
        this.amnt = amnt;
        this.bookEntry = bookEntry;
    }

    /**
     * Gets the value of the opeCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeCategory() {
        return opeCategory;
    }

    /**
     * Sets the value of the opeCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeCategory(String value) {
        this.opeCategory = value;
    }

    public boolean isSetOpeCategory() {
        return (this.opeCategory!= null);
    }

    /**
     * Gets the value of the opeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeType() {
        return opeType;
    }

    /**
     * Sets the value of the opeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeType(String value) {
        this.opeType = value;
    }

    public boolean isSetOpeType() {
        return (this.opeType!= null);
    }

    /**
     * Gets the value of the evtCtgory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEvtCtgory() {
        return evtCtgory;
    }

    /**
     * Sets the value of the evtCtgory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEvtCtgory(String value) {
        this.evtCtgory = value;
    }

    public boolean isSetEvtCtgory() {
        return (this.evtCtgory!= null);
    }

    /**
     * Gets the value of the evtType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEvtType() {
        return evtType;
    }

    /**
     * Sets the value of the evtType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEvtType(String value) {
        this.evtType = value;
    }

    public boolean isSetEvtType() {
        return (this.evtType!= null);
    }

    /**
     * Gets the value of the afbEntryType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAFBEntryType() {
        return afbEntryType;
    }

    /**
     * Sets the value of the afbEntryType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAFBEntryType(String value) {
        this.afbEntryType = value;
    }

    public boolean isSetAFBEntryType() {
        return (this.afbEntryType!= null);
    }

    /**
     * Gets the value of the specifOpeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecifOpeType() {
        return specifOpeType;
    }

    /**
     * Sets the value of the specifOpeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecifOpeType(String value) {
        this.specifOpeType = value;
    }

    public boolean isSetSpecifOpeType() {
        return (this.specifOpeType!= null);
    }

    /**
     * Gets the value of the entryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEntryDate() {
        return entryDate;
    }

    /**
     * Sets the value of the entryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntryDate(Date value) {
        this.entryDate = value;
    }

    public boolean isSetEntryDate() {
        return (this.entryDate!= null);
    }

    /**
     * Gets the value of the rfsalReasn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRfsalReasn() {
        return rfsalReasn;
    }

    /**
     * Sets the value of the rfsalReasn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRfsalReasn(String value) {
        this.rfsalReasn = value;
    }

    public boolean isSetRfsalReasn() {
        return (this.rfsalReasn!= null);
    }

    /**
     * Gets the value of the valueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValueDate() {
        return valueDate;
    }

    /**
     * Sets the value of the valueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueDate(Date value) {
        this.valueDate = value;
    }

    public boolean isSetValueDate() {
        return (this.valueDate!= null);
    }

    /**
     * Gets the value of the longName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongName() {
        return longName;
    }

    /**
     * Sets the value of the longName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongName(String value) {
        this.longName = value;
    }

    public boolean isSetLongName() {
        return (this.longName!= null);
    }

    /**
     * Gets the value of the entryRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEntryRef() {
        return entryRef;
    }

    /**
     * Sets the value of the entryRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEntryRef(String value) {
        this.entryRef = value;
    }

    public boolean isSetEntryRef() {
        return (this.entryRef!= null);
    }

    /**
     * Gets the value of the chrgeExmptn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChrgeExmptn() {
        return chrgeExmptn;
    }

    /**
     * Sets the value of the chrgeExmptn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChrgeExmptn(String value) {
        this.chrgeExmptn = value;
    }

    public boolean isSetChrgeExmptn() {
        return (this.chrgeExmptn!= null);
    }

    /**
     * Gets the value of the avlbltyIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvlbltyIndic() {
        return avlbltyIndic;
    }

    /**
     * Sets the value of the avlbltyIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvlbltyIndic(String value) {
        this.avlbltyIndic = value;
    }

    public boolean isSetAvlbltyIndic() {
        return (this.avlbltyIndic!= null);
    }

    /**
     * Gets the value of the creditDebtIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditDebtIndic() {
        return creditDebtIndic;
    }

    /**
     * Sets the value of the creditDebtIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditDebtIndic(String value) {
        this.creditDebtIndic = value;
    }

    public boolean isSetCreditDebtIndic() {
        return (this.creditDebtIndic!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the bookEntry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBookEntry() {
        return bookEntry;
    }

    /**
     * Sets the value of the bookEntry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBookEntry(String value) {
        this.bookEntry = value;
    }

    public boolean isSetBookEntry() {
        return (this.bookEntry!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeCategory", opeCategory).add("opeType", opeType).add("evtCtgory", evtCtgory).add("evtType", evtType).add("afbEntryType", afbEntryType).add("specifOpeType", specifOpeType).add("entryDate", entryDate).add("rfsalReasn", rfsalReasn).add("valueDate", valueDate).add("longName", longName).add("entryRef", entryRef).add("chrgeExmptn", chrgeExmptn).add("avlbltyIndic", avlbltyIndic).add("creditDebtIndic", creditDebtIndic).add("amnt", amnt).add("bookEntry", bookEntry).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeCategory, opeType, evtCtgory, evtType, afbEntryType, specifOpeType, entryDate, rfsalReasn, valueDate, longName, entryRef, chrgeExmptn, avlbltyIndic, creditDebtIndic, amnt, bookEntry);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountStatementEntryType o = ((CashBankAccountStatementEntryType) other);
        return (((((((((((((((Objects.equal(opeCategory, o.opeCategory)&&Objects.equal(opeType, o.opeType))&&Objects.equal(evtCtgory, o.evtCtgory))&&Objects.equal(evtType, o.evtType))&&Objects.equal(afbEntryType, o.afbEntryType))&&Objects.equal(specifOpeType, o.specifOpeType))&&Objects.equal(entryDate, o.entryDate))&&Objects.equal(rfsalReasn, o.rfsalReasn))&&Objects.equal(valueDate, o.valueDate))&&Objects.equal(longName, o.longName))&&Objects.equal(entryRef, o.entryRef))&&Objects.equal(chrgeExmptn, o.chrgeExmptn))&&Objects.equal(avlbltyIndic, o.avlbltyIndic))&&Objects.equal(creditDebtIndic, o.creditDebtIndic))&&Objects.equal(amnt, o.amnt))&&Objects.equal(bookEntry, o.bookEntry));
    }

}
