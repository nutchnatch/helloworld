
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Description of a
 * 				document's nature.
 * 			
 * 
 * <p>Java class for DocumentNatureType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentNatureType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MIME" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MimeTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Specif" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentNatureType", propOrder = {
    "mime",
    "specif"
})
public class DocumentNatureType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "MIME")
    protected String mime;
    @XmlElement(name = "Specif")
    protected String specif;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentNatureType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentNatureType(final String mime, final String specif) {
        this.mime = mime;
        this.specif = specif;
    }

    /**
     * Gets the value of the mime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMIME() {
        return mime;
    }

    /**
     * Sets the value of the mime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMIME(String value) {
        this.mime = value;
    }

    public boolean isSetMIME() {
        return (this.mime!= null);
    }

    /**
     * Gets the value of the specif property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecif() {
        return specif;
    }

    /**
     * Sets the value of the specif property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecif(String value) {
        this.specif = value;
    }

    public boolean isSetSpecif() {
        return (this.specif!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("mime", mime).add("specif", specif).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mime, specif);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentNatureType o = ((DocumentNatureType) other);
        return (Objects.equal(mime, o.mime)&&Objects.equal(specif, o.specif));
    }

}
