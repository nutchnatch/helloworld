
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on the source application which
 * 				published business objetcs to be consumed by other applications
 * 			
 * 
 * <p>Java class for AcknowledgementSourceApplicationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AcknowledgementSourceApplicationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CompnentCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ApplicationComponentCodeSLN"/&gt;
 *         &lt;element name="Sndr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SenderOrReceiverType" minOccurs="0"/&gt;
 *         &lt;element name="FileData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FilePublicationDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AcknowledgementSourceApplicationType", propOrder = {
    "compnentCode",
    "sndr",
    "fileData"
})
public class AcknowledgementSourceApplicationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CompnentCode", required = true)
    protected String compnentCode;
    @XmlElement(name = "Sndr")
    protected SenderOrReceiverType sndr;
    @XmlElement(name = "FileData")
    protected FilePublicationDataType fileData;

    /**
     * Default no-arg constructor
     * 
     */
    public AcknowledgementSourceApplicationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AcknowledgementSourceApplicationType(final String compnentCode, final SenderOrReceiverType sndr, final FilePublicationDataType fileData) {
        this.compnentCode = compnentCode;
        this.sndr = sndr;
        this.fileData = fileData;
    }

    /**
     * Gets the value of the compnentCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompnentCode() {
        return compnentCode;
    }

    /**
     * Sets the value of the compnentCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompnentCode(String value) {
        this.compnentCode = value;
    }

    public boolean isSetCompnentCode() {
        return (this.compnentCode!= null);
    }

    /**
     * Gets the value of the sndr property.
     * 
     * @return
     *     possible object is
     *     {@link SenderOrReceiverType }
     *     
     */
    public SenderOrReceiverType getSndr() {
        return sndr;
    }

    /**
     * Sets the value of the sndr property.
     * 
     * @param value
     *     allowed object is
     *     {@link SenderOrReceiverType }
     *     
     */
    public void setSndr(SenderOrReceiverType value) {
        this.sndr = value;
    }

    public boolean isSetSndr() {
        return (this.sndr!= null);
    }

    /**
     * Gets the value of the fileData property.
     * 
     * @return
     *     possible object is
     *     {@link FilePublicationDataType }
     *     
     */
    public FilePublicationDataType getFileData() {
        return fileData;
    }

    /**
     * Sets the value of the fileData property.
     * 
     * @param value
     *     allowed object is
     *     {@link FilePublicationDataType }
     *     
     */
    public void setFileData(FilePublicationDataType value) {
        this.fileData = value;
    }

    public boolean isSetFileData() {
        return (this.fileData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("compnentCode", compnentCode).add("sndr", sndr).add("fileData", fileData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(compnentCode, sndr, fileData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AcknowledgementSourceApplicationType o = ((AcknowledgementSourceApplicationType) other);
        return ((Objects.equal(compnentCode, o.compnentCode)&&Objects.equal(sndr, o.sndr))&&Objects.equal(fileData, o.fileData));
    }

}
