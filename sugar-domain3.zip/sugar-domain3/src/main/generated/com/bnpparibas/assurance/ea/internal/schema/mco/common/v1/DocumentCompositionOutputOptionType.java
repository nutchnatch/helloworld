
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type which describes the output of a composition
 * 				and the options which apply to the output
 * 			
 * 
 * <p>Java class for DocumentCompositionOutputOptionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentCompositionOutputOptionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="Format" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentFormatTypeCodeSLN"/&gt;
 *         &lt;element name="Option" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="SeqId" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
 *                   &lt;element name="Code"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;maxLength value="50"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Value" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentCompositionOutputOptionType", propOrder = {
    "name",
    "format",
    "option"
})
public class DocumentCompositionOutputOptionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "Format", required = true)
    protected String format;
    @XmlElement(name = "Option")
    protected List<DocumentCompositionOutputOptionType.Option> option;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentCompositionOutputOptionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentCompositionOutputOptionType(final String name, final String format, final List<DocumentCompositionOutputOptionType.Option> option) {
        this.name = name;
        this.format = format;
        this.option = option;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormat(String value) {
        this.format = value;
    }

    public boolean isSetFormat() {
        return (this.format!= null);
    }

    /**
     * Gets the value of the option property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the option property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOption().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentCompositionOutputOptionType.Option }
     * 
     * 
     */
    public List<DocumentCompositionOutputOptionType.Option> getOption() {
        if (option == null) {
            option = new ArrayList<DocumentCompositionOutputOptionType.Option>();
        }
        return this.option;
    }

    public boolean isSetOption() {
        return ((this.option!= null)&&(!this.option.isEmpty()));
    }

    public void unsetOption() {
        this.option = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("format", format).add("option", option).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, format, option);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentCompositionOutputOptionType o = ((DocumentCompositionOutputOptionType) other);
        return ((Objects.equal(name, o.name)&&Objects.equal(format, o.format))&&Objects.equal(option, o.option));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="SeqId" type="{http://www.w3.org/2001/XMLSchema}anyType" minOccurs="0"/&gt;
     *         &lt;element name="Code"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;maxLength value="50"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Value" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "seqId",
        "code",
        "value"
    })
    public static class Option implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "SeqId")
        protected Object seqId;
        @XmlElement(name = "Code", required = true)
        protected String code;
        @XmlElement(name = "Value")
        protected String value;

        /**
         * Default no-arg constructor
         * 
         */
        public Option() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Option(final Object seqId, final String code, final String value) {
            this.seqId = seqId;
            this.code = code;
            this.value = value;
        }

        /**
         * Gets the value of the seqId property.
         * 
         * @return
         *     possible object is
         *     {@link Object }
         *     
         */
        public Object getSeqId() {
            return seqId;
        }

        /**
         * Sets the value of the seqId property.
         * 
         * @param value
         *     allowed object is
         *     {@link Object }
         *     
         */
        public void setSeqId(Object value) {
            this.seqId = value;
        }

        public boolean isSetSeqId() {
            return (this.seqId!= null);
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        public boolean isSetCode() {
            return (this.code!= null);
        }

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        public boolean isSetValue() {
            return (this.value!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("seqId", seqId).add("code", code).add("value", value).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(seqId, code, value);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final DocumentCompositionOutputOptionType.Option o = ((DocumentCompositionOutputOptionType.Option) other);
            return ((Objects.equal(seqId, o.seqId)&&Objects.equal(code, o.code))&&Objects.equal(value, o.value));
        }

    }

}
