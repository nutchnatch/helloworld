
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * assure sum by the insurance company
 * 			
 * 
 * <p>Java class for AssuredOutstandingsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AssuredOutstandingsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="InsrdPersn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="CovrdTotAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssuredOutstandingsDataType", propOrder = {
    "insrdPersn",
    "covrdTotAmnt"
})
public class AssuredOutstandingsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "InsrdPersn", required = true)
    protected PartyRoleType insrdPersn;
    @XmlElement(name = "CovrdTotAmnt", required = true)
    protected CurrencyAndAmountType covrdTotAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public AssuredOutstandingsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AssuredOutstandingsDataType(final PartyRoleType insrdPersn, final CurrencyAndAmountType covrdTotAmnt) {
        this.insrdPersn = insrdPersn;
        this.covrdTotAmnt = covrdTotAmnt;
    }

    /**
     * Gets the value of the insrdPersn property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsrdPersn() {
        return insrdPersn;
    }

    /**
     * Sets the value of the insrdPersn property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsrdPersn(PartyRoleType value) {
        this.insrdPersn = value;
    }

    public boolean isSetInsrdPersn() {
        return (this.insrdPersn!= null);
    }

    /**
     * Gets the value of the covrdTotAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getCovrdTotAmnt() {
        return covrdTotAmnt;
    }

    /**
     * Sets the value of the covrdTotAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setCovrdTotAmnt(CurrencyAndAmountType value) {
        this.covrdTotAmnt = value;
    }

    public boolean isSetCovrdTotAmnt() {
        return (this.covrdTotAmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("insrdPersn", insrdPersn).add("covrdTotAmnt", covrdTotAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(insrdPersn, covrdTotAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AssuredOutstandingsDataType o = ((AssuredOutstandingsDataType) other);
        return (Objects.equal(insrdPersn, o.insrdPersn)&&Objects.equal(covrdTotAmnt, o.covrdTotAmnt));
    }

}
