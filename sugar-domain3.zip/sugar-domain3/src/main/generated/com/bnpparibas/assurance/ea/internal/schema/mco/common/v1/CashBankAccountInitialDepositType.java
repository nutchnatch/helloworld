
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage data on initial deposit linked to a
 * 				cash bank account
 * 			
 * 
 * <p>Java class for CashBankAccountInitialDepositType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountInitialDepositType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="Date" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="SettlmntMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SettlementModeCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountInitialDepositType", propOrder = {
    "amnt",
    "date",
    "settlmntMode"
})
public class CashBankAccountInitialDepositType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "Date", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date date;
    @XmlElement(name = "SettlmntMode", required = true)
    protected String settlmntMode;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountInitialDepositType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountInitialDepositType(final CurrencyAndAmountType amnt, final Date date, final String settlmntMode) {
        this.amnt = amnt;
        this.date = date;
        this.settlmntMode = settlmntMode;
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDate(Date value) {
        this.date = value;
    }

    public boolean isSetDate() {
        return (this.date!= null);
    }

    /**
     * Gets the value of the settlmntMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlmntMode() {
        return settlmntMode;
    }

    /**
     * Sets the value of the settlmntMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlmntMode(String value) {
        this.settlmntMode = value;
    }

    public boolean isSetSettlmntMode() {
        return (this.settlmntMode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("amnt", amnt).add("date", date).add("settlmntMode", settlmntMode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(amnt, date, settlmntMode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountInitialDepositType o = ((CashBankAccountInitialDepositType) other);
        return ((Objects.equal(amnt, o.amnt)&&Objects.equal(date, o.date))&&Objects.equal(settlmntMode, o.settlmntMode));
    }

}
