
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a claim study has dependencies
 * 			
 * 
 * <p>Java class for ClaimStudyLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimStudyLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cov" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationCoverIdentificationType"/&gt;
 *         &lt;element name="Insrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="UndrlyngPdctOrTransac" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UnderlyingProductOrTransactionTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="InsrdObjct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsuredObjectDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimStudyLinkedObjectsType", propOrder = {
    "cov",
    "insrd",
    "undrlyngPdctOrTransac",
    "insrdObjct"
})
public class ClaimStudyLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Cov", required = true)
    protected OperationCoverIdentificationType cov;
    @XmlElement(name = "Insrd", required = true)
    protected PartyRoleType insrd;
    @XmlElement(name = "UndrlyngPdctOrTransac")
    protected String undrlyngPdctOrTransac;
    @XmlElement(name = "InsrdObjct")
    protected InsuredObjectDataType insrdObjct;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimStudyLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimStudyLinkedObjectsType(final OperationCoverIdentificationType cov, final PartyRoleType insrd, final String undrlyngPdctOrTransac, final InsuredObjectDataType insrdObjct) {
        this.cov = cov;
        this.insrd = insrd;
        this.undrlyngPdctOrTransac = undrlyngPdctOrTransac;
        this.insrdObjct = insrdObjct;
    }

    /**
     * Gets the value of the cov property.
     * 
     * @return
     *     possible object is
     *     {@link OperationCoverIdentificationType }
     *     
     */
    public OperationCoverIdentificationType getCov() {
        return cov;
    }

    /**
     * Sets the value of the cov property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationCoverIdentificationType }
     *     
     */
    public void setCov(OperationCoverIdentificationType value) {
        this.cov = value;
    }

    public boolean isSetCov() {
        return (this.cov!= null);
    }

    /**
     * Gets the value of the insrd property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsrd() {
        return insrd;
    }

    /**
     * Sets the value of the insrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsrd(PartyRoleType value) {
        this.insrd = value;
    }

    public boolean isSetInsrd() {
        return (this.insrd!= null);
    }

    /**
     * Gets the value of the undrlyngPdctOrTransac property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUndrlyngPdctOrTransac() {
        return undrlyngPdctOrTransac;
    }

    /**
     * Sets the value of the undrlyngPdctOrTransac property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUndrlyngPdctOrTransac(String value) {
        this.undrlyngPdctOrTransac = value;
    }

    public boolean isSetUndrlyngPdctOrTransac() {
        return (this.undrlyngPdctOrTransac!= null);
    }

    /**
     * Gets the value of the insrdObjct property.
     * 
     * @return
     *     possible object is
     *     {@link InsuredObjectDataType }
     *     
     */
    public InsuredObjectDataType getInsrdObjct() {
        return insrdObjct;
    }

    /**
     * Sets the value of the insrdObjct property.
     * 
     * @param value
     *     allowed object is
     *     {@link InsuredObjectDataType }
     *     
     */
    public void setInsrdObjct(InsuredObjectDataType value) {
        this.insrdObjct = value;
    }

    public boolean isSetInsrdObjct() {
        return (this.insrdObjct!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cov", cov).add("insrd", insrd).add("undrlyngPdctOrTransac", undrlyngPdctOrTransac).add("insrdObjct", insrdObjct).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cov, insrd, undrlyngPdctOrTransac, insrdObjct);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimStudyLinkedObjectsType o = ((ClaimStudyLinkedObjectsType) other);
        return (((Objects.equal(cov, o.cov)&&Objects.equal(insrd, o.insrd))&&Objects.equal(undrlyngPdctOrTransac, o.undrlyngPdctOrTransac))&&Objects.equal(insrdObjct, o.insrdObjct));
    }

}
