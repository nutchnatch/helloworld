
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage global data of a claim declaration
 * 			
 * 
 * <p>Java class for ClaimDeclarationRequestInputDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimDeclarationRequestInputDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClaimEvtType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimEventTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ClaimDeclardEvtDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ClaimRealEvtDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="DeclrtnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="FormType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MediaTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FreeDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongDescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="Login" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="NotfctnMedia" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MediaTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="OutbndDocMedia" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MediaTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimDeclarationRequestInputDataType", propOrder = {
    "claimEvtType",
    "claimDeclardEvtDate",
    "claimRealEvtDate",
    "declrtnDate",
    "formType",
    "freeDesc",
    "login",
    "notfctnMedia",
    "outbndDocMedia"
})
public class ClaimDeclarationRequestInputDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClaimEvtType")
    protected String claimEvtType;
    @XmlElement(name = "ClaimDeclardEvtDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date claimDeclardEvtDate;
    @XmlElement(name = "ClaimRealEvtDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date claimRealEvtDate;
    @XmlElement(name = "DeclrtnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date declrtnDate;
    @XmlElement(name = "FormType")
    protected String formType;
    @XmlElement(name = "FreeDesc")
    protected String freeDesc;
    @XmlElement(name = "Login")
    protected IdentificationType login;
    @XmlElement(name = "NotfctnMedia")
    protected List<String> notfctnMedia;
    @XmlElement(name = "OutbndDocMedia")
    protected List<String> outbndDocMedia;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimDeclarationRequestInputDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimDeclarationRequestInputDataType(final String claimEvtType, final Date claimDeclardEvtDate, final Date claimRealEvtDate, final Date declrtnDate, final String formType, final String freeDesc, final IdentificationType login, final List<String> notfctnMedia, final List<String> outbndDocMedia) {
        this.claimEvtType = claimEvtType;
        this.claimDeclardEvtDate = claimDeclardEvtDate;
        this.claimRealEvtDate = claimRealEvtDate;
        this.declrtnDate = declrtnDate;
        this.formType = formType;
        this.freeDesc = freeDesc;
        this.login = login;
        this.notfctnMedia = notfctnMedia;
        this.outbndDocMedia = outbndDocMedia;
    }

    /**
     * Gets the value of the claimEvtType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimEvtType() {
        return claimEvtType;
    }

    /**
     * Sets the value of the claimEvtType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimEvtType(String value) {
        this.claimEvtType = value;
    }

    public boolean isSetClaimEvtType() {
        return (this.claimEvtType!= null);
    }

    /**
     * Gets the value of the claimDeclardEvtDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getClaimDeclardEvtDate() {
        return claimDeclardEvtDate;
    }

    /**
     * Sets the value of the claimDeclardEvtDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimDeclardEvtDate(Date value) {
        this.claimDeclardEvtDate = value;
    }

    public boolean isSetClaimDeclardEvtDate() {
        return (this.claimDeclardEvtDate!= null);
    }

    /**
     * Gets the value of the claimRealEvtDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getClaimRealEvtDate() {
        return claimRealEvtDate;
    }

    /**
     * Sets the value of the claimRealEvtDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimRealEvtDate(Date value) {
        this.claimRealEvtDate = value;
    }

    public boolean isSetClaimRealEvtDate() {
        return (this.claimRealEvtDate!= null);
    }

    /**
     * Gets the value of the declrtnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDeclrtnDate() {
        return declrtnDate;
    }

    /**
     * Sets the value of the declrtnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclrtnDate(Date value) {
        this.declrtnDate = value;
    }

    public boolean isSetDeclrtnDate() {
        return (this.declrtnDate!= null);
    }

    /**
     * Gets the value of the formType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormType() {
        return formType;
    }

    /**
     * Sets the value of the formType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormType(String value) {
        this.formType = value;
    }

    public boolean isSetFormType() {
        return (this.formType!= null);
    }

    /**
     * Gets the value of the freeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeDesc() {
        return freeDesc;
    }

    /**
     * Sets the value of the freeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeDesc(String value) {
        this.freeDesc = value;
    }

    public boolean isSetFreeDesc() {
        return (this.freeDesc!= null);
    }

    /**
     * Gets the value of the login property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getLogin() {
        return login;
    }

    /**
     * Sets the value of the login property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setLogin(IdentificationType value) {
        this.login = value;
    }

    public boolean isSetLogin() {
        return (this.login!= null);
    }

    /**
     * Gets the value of the notfctnMedia property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the notfctnMedia property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNotfctnMedia().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getNotfctnMedia() {
        if (notfctnMedia == null) {
            notfctnMedia = new ArrayList<String>();
        }
        return this.notfctnMedia;
    }

    public boolean isSetNotfctnMedia() {
        return ((this.notfctnMedia!= null)&&(!this.notfctnMedia.isEmpty()));
    }

    public void unsetNotfctnMedia() {
        this.notfctnMedia = null;
    }

    /**
     * Gets the value of the outbndDocMedia property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the outbndDocMedia property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOutbndDocMedia().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getOutbndDocMedia() {
        if (outbndDocMedia == null) {
            outbndDocMedia = new ArrayList<String>();
        }
        return this.outbndDocMedia;
    }

    public boolean isSetOutbndDocMedia() {
        return ((this.outbndDocMedia!= null)&&(!this.outbndDocMedia.isEmpty()));
    }

    public void unsetOutbndDocMedia() {
        this.outbndDocMedia = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("claimEvtType", claimEvtType).add("claimDeclardEvtDate", claimDeclardEvtDate).add("claimRealEvtDate", claimRealEvtDate).add("declrtnDate", declrtnDate).add("formType", formType).add("freeDesc", freeDesc).add("login", login).add("notfctnMedia", notfctnMedia).add("outbndDocMedia", outbndDocMedia).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(claimEvtType, claimDeclardEvtDate, claimRealEvtDate, declrtnDate, formType, freeDesc, login, notfctnMedia, outbndDocMedia);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimDeclarationRequestInputDataType o = ((ClaimDeclarationRequestInputDataType) other);
        return ((((((((Objects.equal(claimEvtType, o.claimEvtType)&&Objects.equal(claimDeclardEvtDate, o.claimDeclardEvtDate))&&Objects.equal(claimRealEvtDate, o.claimRealEvtDate))&&Objects.equal(declrtnDate, o.declrtnDate))&&Objects.equal(formType, o.formType))&&Objects.equal(freeDesc, o.freeDesc))&&Objects.equal(login, o.login))&&Objects.equal(notfctnMedia, o.notfctnMedia))&&Objects.equal(outbndDocMedia, o.outbndDocMedia));
    }

}
