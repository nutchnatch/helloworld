
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage global data of a claim study
 * 			
 * 
 * <p>Java class for ClaimStudyDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimStudyDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeningDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="ClosngDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="DecsnTrgetDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="ReinsurerDecsnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="CoinsurerDecsnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="DdctblePrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="FreeDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongDescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="ReminngCovDurtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimStudyDataType", propOrder = {
    "openingDate",
    "closngDate",
    "decsnTrgetDate",
    "reinsurerDecsnIndic",
    "coinsurerDecsnIndic",
    "ddctblePrd",
    "freeDesc",
    "reminngCovDurtn"
})
public class ClaimStudyDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeningDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date openingDate;
    @XmlElement(name = "ClosngDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date closngDate;
    @XmlElement(name = "DecsnTrgetDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date decsnTrgetDate;
    @XmlElement(name = "ReinsurerDecsnIndic")
    protected String reinsurerDecsnIndic;
    @XmlElement(name = "CoinsurerDecsnIndic")
    protected String coinsurerDecsnIndic;
    @XmlElement(name = "DdctblePrd")
    protected DurationType ddctblePrd;
    @XmlElement(name = "FreeDesc")
    protected String freeDesc;
    @XmlElement(name = "ReminngCovDurtn")
    protected DurationType reminngCovDurtn;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimStudyDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimStudyDataType(final Date openingDate, final Date closngDate, final Date decsnTrgetDate, final String reinsurerDecsnIndic, final String coinsurerDecsnIndic, final DurationType ddctblePrd, final String freeDesc, final DurationType reminngCovDurtn) {
        this.openingDate = openingDate;
        this.closngDate = closngDate;
        this.decsnTrgetDate = decsnTrgetDate;
        this.reinsurerDecsnIndic = reinsurerDecsnIndic;
        this.coinsurerDecsnIndic = coinsurerDecsnIndic;
        this.ddctblePrd = ddctblePrd;
        this.freeDesc = freeDesc;
        this.reminngCovDurtn = reminngCovDurtn;
    }

    /**
     * Gets the value of the openingDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getOpeningDate() {
        return openingDate;
    }

    /**
     * Sets the value of the openingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeningDate(Date value) {
        this.openingDate = value;
    }

    public boolean isSetOpeningDate() {
        return (this.openingDate!= null);
    }

    /**
     * Gets the value of the closngDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getClosngDate() {
        return closngDate;
    }

    /**
     * Sets the value of the closngDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosngDate(Date value) {
        this.closngDate = value;
    }

    public boolean isSetClosngDate() {
        return (this.closngDate!= null);
    }

    /**
     * Gets the value of the decsnTrgetDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDecsnTrgetDate() {
        return decsnTrgetDate;
    }

    /**
     * Sets the value of the decsnTrgetDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecsnTrgetDate(Date value) {
        this.decsnTrgetDate = value;
    }

    public boolean isSetDecsnTrgetDate() {
        return (this.decsnTrgetDate!= null);
    }

    /**
     * Gets the value of the reinsurerDecsnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReinsurerDecsnIndic() {
        return reinsurerDecsnIndic;
    }

    /**
     * Sets the value of the reinsurerDecsnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReinsurerDecsnIndic(String value) {
        this.reinsurerDecsnIndic = value;
    }

    public boolean isSetReinsurerDecsnIndic() {
        return (this.reinsurerDecsnIndic!= null);
    }

    /**
     * Gets the value of the coinsurerDecsnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoinsurerDecsnIndic() {
        return coinsurerDecsnIndic;
    }

    /**
     * Sets the value of the coinsurerDecsnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoinsurerDecsnIndic(String value) {
        this.coinsurerDecsnIndic = value;
    }

    public boolean isSetCoinsurerDecsnIndic() {
        return (this.coinsurerDecsnIndic!= null);
    }

    /**
     * Gets the value of the ddctblePrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDdctblePrd() {
        return ddctblePrd;
    }

    /**
     * Sets the value of the ddctblePrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDdctblePrd(DurationType value) {
        this.ddctblePrd = value;
    }

    public boolean isSetDdctblePrd() {
        return (this.ddctblePrd!= null);
    }

    /**
     * Gets the value of the freeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeDesc() {
        return freeDesc;
    }

    /**
     * Sets the value of the freeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeDesc(String value) {
        this.freeDesc = value;
    }

    public boolean isSetFreeDesc() {
        return (this.freeDesc!= null);
    }

    /**
     * Gets the value of the reminngCovDurtn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getReminngCovDurtn() {
        return reminngCovDurtn;
    }

    /**
     * Sets the value of the reminngCovDurtn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setReminngCovDurtn(DurationType value) {
        this.reminngCovDurtn = value;
    }

    public boolean isSetReminngCovDurtn() {
        return (this.reminngCovDurtn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("openingDate", openingDate).add("closngDate", closngDate).add("decsnTrgetDate", decsnTrgetDate).add("reinsurerDecsnIndic", reinsurerDecsnIndic).add("coinsurerDecsnIndic", coinsurerDecsnIndic).add("ddctblePrd", ddctblePrd).add("freeDesc", freeDesc).add("reminngCovDurtn", reminngCovDurtn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(openingDate, closngDate, decsnTrgetDate, reinsurerDecsnIndic, coinsurerDecsnIndic, ddctblePrd, freeDesc, reminngCovDurtn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimStudyDataType o = ((ClaimStudyDataType) other);
        return (((((((Objects.equal(openingDate, o.openingDate)&&Objects.equal(closngDate, o.closngDate))&&Objects.equal(decsnTrgetDate, o.decsnTrgetDate))&&Objects.equal(reinsurerDecsnIndic, o.reinsurerDecsnIndic))&&Objects.equal(coinsurerDecsnIndic, o.coinsurerDecsnIndic))&&Objects.equal(ddctblePrd, o.ddctblePrd))&&Objects.equal(freeDesc, o.freeDesc))&&Objects.equal(reminngCovDurtn, o.reminngCovDurtn));
    }

}
