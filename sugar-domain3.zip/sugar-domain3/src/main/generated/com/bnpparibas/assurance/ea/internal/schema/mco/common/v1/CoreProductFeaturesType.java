
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for CoreProductFeaturesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoreProductFeaturesType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MainObjctvType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MainObjectiveCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="MaturtyType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MaturityTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="UndrlyngPdctType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UnderlyingProductOrTransactionTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CovrdItemType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoveredItemTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CovrdRiskType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoveredRiskTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BnftType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="GuarnteeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsurerGuaranteesTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="UndrlyngAsstType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UnderlyingAssetTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PremType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreProductFeaturesType", propOrder = {
    "mainObjctvType",
    "maturtyType",
    "undrlyngPdctType",
    "covrdItemType",
    "covrdRiskType",
    "bnftType",
    "guarnteeType",
    "undrlyngAsstType",
    "premType"
})
public class CoreProductFeaturesType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "MainObjctvType")
    protected List<String> mainObjctvType;
    @XmlElement(name = "MaturtyType")
    protected List<String> maturtyType;
    @XmlElement(name = "UndrlyngPdctType")
    protected List<String> undrlyngPdctType;
    @XmlElement(name = "CovrdItemType")
    protected List<String> covrdItemType;
    @XmlElement(name = "CovrdRiskType")
    protected List<String> covrdRiskType;
    @XmlElement(name = "BnftType")
    protected List<String> bnftType;
    @XmlElement(name = "GuarnteeType")
    protected List<String> guarnteeType;
    @XmlElement(name = "UndrlyngAsstType")
    protected List<String> undrlyngAsstType;
    @XmlElement(name = "PremType")
    protected List<String> premType;

    /**
     * Default no-arg constructor
     * 
     */
    public CoreProductFeaturesType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoreProductFeaturesType(final List<String> mainObjctvType, final List<String> maturtyType, final List<String> undrlyngPdctType, final List<String> covrdItemType, final List<String> covrdRiskType, final List<String> bnftType, final List<String> guarnteeType, final List<String> undrlyngAsstType, final List<String> premType) {
        this.mainObjctvType = mainObjctvType;
        this.maturtyType = maturtyType;
        this.undrlyngPdctType = undrlyngPdctType;
        this.covrdItemType = covrdItemType;
        this.covrdRiskType = covrdRiskType;
        this.bnftType = bnftType;
        this.guarnteeType = guarnteeType;
        this.undrlyngAsstType = undrlyngAsstType;
        this.premType = premType;
    }

    /**
     * Gets the value of the mainObjctvType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mainObjctvType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMainObjctvType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getMainObjctvType() {
        if (mainObjctvType == null) {
            mainObjctvType = new ArrayList<String>();
        }
        return this.mainObjctvType;
    }

    public boolean isSetMainObjctvType() {
        return ((this.mainObjctvType!= null)&&(!this.mainObjctvType.isEmpty()));
    }

    public void unsetMainObjctvType() {
        this.mainObjctvType = null;
    }

    /**
     * Gets the value of the maturtyType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the maturtyType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMaturtyType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getMaturtyType() {
        if (maturtyType == null) {
            maturtyType = new ArrayList<String>();
        }
        return this.maturtyType;
    }

    public boolean isSetMaturtyType() {
        return ((this.maturtyType!= null)&&(!this.maturtyType.isEmpty()));
    }

    public void unsetMaturtyType() {
        this.maturtyType = null;
    }

    /**
     * Gets the value of the undrlyngPdctType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the undrlyngPdctType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUndrlyngPdctType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getUndrlyngPdctType() {
        if (undrlyngPdctType == null) {
            undrlyngPdctType = new ArrayList<String>();
        }
        return this.undrlyngPdctType;
    }

    public boolean isSetUndrlyngPdctType() {
        return ((this.undrlyngPdctType!= null)&&(!this.undrlyngPdctType.isEmpty()));
    }

    public void unsetUndrlyngPdctType() {
        this.undrlyngPdctType = null;
    }

    /**
     * Gets the value of the covrdItemType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covrdItemType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovrdItemType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCovrdItemType() {
        if (covrdItemType == null) {
            covrdItemType = new ArrayList<String>();
        }
        return this.covrdItemType;
    }

    public boolean isSetCovrdItemType() {
        return ((this.covrdItemType!= null)&&(!this.covrdItemType.isEmpty()));
    }

    public void unsetCovrdItemType() {
        this.covrdItemType = null;
    }

    /**
     * Gets the value of the covrdRiskType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the covrdRiskType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCovrdRiskType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCovrdRiskType() {
        if (covrdRiskType == null) {
            covrdRiskType = new ArrayList<String>();
        }
        return this.covrdRiskType;
    }

    public boolean isSetCovrdRiskType() {
        return ((this.covrdRiskType!= null)&&(!this.covrdRiskType.isEmpty()));
    }

    public void unsetCovrdRiskType() {
        this.covrdRiskType = null;
    }

    /**
     * Gets the value of the bnftType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bnftType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBnftType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getBnftType() {
        if (bnftType == null) {
            bnftType = new ArrayList<String>();
        }
        return this.bnftType;
    }

    public boolean isSetBnftType() {
        return ((this.bnftType!= null)&&(!this.bnftType.isEmpty()));
    }

    public void unsetBnftType() {
        this.bnftType = null;
    }

    /**
     * Gets the value of the guarnteeType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the guarnteeType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGuarnteeType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getGuarnteeType() {
        if (guarnteeType == null) {
            guarnteeType = new ArrayList<String>();
        }
        return this.guarnteeType;
    }

    public boolean isSetGuarnteeType() {
        return ((this.guarnteeType!= null)&&(!this.guarnteeType.isEmpty()));
    }

    public void unsetGuarnteeType() {
        this.guarnteeType = null;
    }

    /**
     * Gets the value of the undrlyngAsstType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the undrlyngAsstType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUndrlyngAsstType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getUndrlyngAsstType() {
        if (undrlyngAsstType == null) {
            undrlyngAsstType = new ArrayList<String>();
        }
        return this.undrlyngAsstType;
    }

    public boolean isSetUndrlyngAsstType() {
        return ((this.undrlyngAsstType!= null)&&(!this.undrlyngAsstType.isEmpty()));
    }

    public void unsetUndrlyngAsstType() {
        this.undrlyngAsstType = null;
    }

    /**
     * Gets the value of the premType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the premType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPremType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getPremType() {
        if (premType == null) {
            premType = new ArrayList<String>();
        }
        return this.premType;
    }

    public boolean isSetPremType() {
        return ((this.premType!= null)&&(!this.premType.isEmpty()));
    }

    public void unsetPremType() {
        this.premType = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("mainObjctvType", mainObjctvType).add("maturtyType", maturtyType).add("undrlyngPdctType", undrlyngPdctType).add("covrdItemType", covrdItemType).add("covrdRiskType", covrdRiskType).add("bnftType", bnftType).add("guarnteeType", guarnteeType).add("undrlyngAsstType", undrlyngAsstType).add("premType", premType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mainObjctvType, maturtyType, undrlyngPdctType, covrdItemType, covrdRiskType, bnftType, guarnteeType, undrlyngAsstType, premType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoreProductFeaturesType o = ((CoreProductFeaturesType) other);
        return ((((((((Objects.equal(mainObjctvType, o.mainObjctvType)&&Objects.equal(maturtyType, o.maturtyType))&&Objects.equal(undrlyngPdctType, o.undrlyngPdctType))&&Objects.equal(covrdItemType, o.covrdItemType))&&Objects.equal(covrdRiskType, o.covrdRiskType))&&Objects.equal(bnftType, o.bnftType))&&Objects.equal(guarnteeType, o.guarnteeType))&&Objects.equal(undrlyngAsstType, o.undrlyngAsstType))&&Objects.equal(premType, o.premType));
    }

}
