
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Actual data flow content
 * 				(such as an actual document content or an actual metadata value).
 * 				When provided, one of the three following element.
 * 			
 * 
 * <p>Java class for ActualDataFlowContentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ActualDataFlowContentType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Text" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TextType" minOccurs="0"/&gt;
 *         &lt;element name="Bnry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Base64BinaryType" minOccurs="0"/&gt;
 *         &lt;element name="Locatn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}URLFormatType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActualDataFlowContentType", propOrder = {
    "text",
    "bnry",
    "locatn"
})
public class ActualDataFlowContentType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Text")
    protected String text;
    @XmlElement(name = "Bnry")
    protected byte[] bnry;
    @XmlElement(name = "Locatn")
    protected String locatn;

    /**
     * Default no-arg constructor
     * 
     */
    public ActualDataFlowContentType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ActualDataFlowContentType(final String text, final byte[] bnry, final String locatn) {
        this.text = text;
        this.bnry = bnry;
        this.locatn = locatn;
    }

    /**
     * Gets the value of the text property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getText() {
        return text;
    }

    /**
     * Sets the value of the text property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setText(String value) {
        this.text = value;
    }

    public boolean isSetText() {
        return (this.text!= null);
    }

    /**
     * Gets the value of the bnry property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getBnry() {
        return bnry;
    }

    /**
     * Sets the value of the bnry property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setBnry(byte[] value) {
        this.bnry = value;
    }

    public boolean isSetBnry() {
        return (this.bnry!= null);
    }

    /**
     * Gets the value of the locatn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocatn() {
        return locatn;
    }

    /**
     * Sets the value of the locatn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocatn(String value) {
        this.locatn = value;
    }

    public boolean isSetLocatn() {
        return (this.locatn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("text", text).add("bnry", bnry).add("locatn", locatn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(text, bnry, locatn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ActualDataFlowContentType o = ((ActualDataFlowContentType) other);
        return ((Objects.equal(text, o.text)&&Objects.equal(bnry, o.bnry))&&Objects.equal(locatn, o.locatn));
    }

}
