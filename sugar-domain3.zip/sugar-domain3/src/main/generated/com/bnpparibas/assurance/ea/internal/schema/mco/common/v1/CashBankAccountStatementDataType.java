
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on cash bank account
 * 				statement information
 * 			
 * 
 * <p>Java class for CashBankAccountStatementDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountStatementDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ValueDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountStatementDataType", propOrder = {
    "valueDate"
})
public class CashBankAccountStatementDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ValueDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valueDate;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountStatementDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountStatementDataType(final Date valueDate) {
        this.valueDate = valueDate;
    }

    /**
     * Gets the value of the valueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValueDate() {
        return valueDate;
    }

    /**
     * Sets the value of the valueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueDate(Date value) {
        this.valueDate = value;
    }

    public boolean isSetValueDate() {
        return (this.valueDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("valueDate", valueDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(valueDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountStatementDataType o = ((CashBankAccountStatementDataType) other);
        return Objects.equal(valueDate, o.valueDate);
    }

}
