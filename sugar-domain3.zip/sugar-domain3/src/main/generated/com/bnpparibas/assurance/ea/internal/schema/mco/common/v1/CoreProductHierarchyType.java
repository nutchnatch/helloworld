
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Product classification
 * 				hierarchy
 * 			
 * 
 * <p>Java class for CoreProductHierarchyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoreProductHierarchyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductTypeCodeSLN"&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Line" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductLineCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Grp" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductGroupCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreProductHierarchyType", propOrder = {
    "type",
    "line",
    "grp"
})
public class CoreProductHierarchyType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Line")
    protected String line;
    @XmlElement(name = "Grp")
    protected String grp;

    /**
     * Default no-arg constructor
     * 
     */
    public CoreProductHierarchyType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoreProductHierarchyType(final String type, final String line, final String grp) {
        this.type = type;
        this.line = line;
        this.grp = grp;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the line property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLine() {
        return line;
    }

    /**
     * Sets the value of the line property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLine(String value) {
        this.line = value;
    }

    public boolean isSetLine() {
        return (this.line!= null);
    }

    /**
     * Gets the value of the grp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGrp() {
        return grp;
    }

    /**
     * Sets the value of the grp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGrp(String value) {
        this.grp = value;
    }

    public boolean isSetGrp() {
        return (this.grp!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("line", line).add("grp", grp).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, line, grp);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoreProductHierarchyType o = ((CoreProductHierarchyType) other);
        return ((Objects.equal(type, o.type)&&Objects.equal(line, o.line))&&Objects.equal(grp, o.grp));
    }

}
