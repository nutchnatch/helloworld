
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for CoverPremiumCalculationAndRevisabiltyTermsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverPremiumCalculationAndRevisabiltyTermsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PremCalctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverPremiumCalculationRulesDataType" minOccurs="0"/&gt;
 *         &lt;element name="RvsbltyData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumOrBenefitRevisabilityTermsDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverPremiumCalculationAndRevisabiltyTermsDataType", propOrder = {
    "premCalctn",
    "rvsbltyData"
})
public class CoverPremiumCalculationAndRevisabiltyTermsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PremCalctn")
    protected CoverPremiumCalculationRulesDataType premCalctn;
    @XmlElement(name = "RvsbltyData")
    protected PremiumOrBenefitRevisabilityTermsDataType rvsbltyData;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverPremiumCalculationAndRevisabiltyTermsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverPremiumCalculationAndRevisabiltyTermsDataType(final CoverPremiumCalculationRulesDataType premCalctn, final PremiumOrBenefitRevisabilityTermsDataType rvsbltyData) {
        this.premCalctn = premCalctn;
        this.rvsbltyData = rvsbltyData;
    }

    /**
     * Gets the value of the premCalctn property.
     * 
     * @return
     *     possible object is
     *     {@link CoverPremiumCalculationRulesDataType }
     *     
     */
    public CoverPremiumCalculationRulesDataType getPremCalctn() {
        return premCalctn;
    }

    /**
     * Sets the value of the premCalctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverPremiumCalculationRulesDataType }
     *     
     */
    public void setPremCalctn(CoverPremiumCalculationRulesDataType value) {
        this.premCalctn = value;
    }

    public boolean isSetPremCalctn() {
        return (this.premCalctn!= null);
    }

    /**
     * Gets the value of the rvsbltyData property.
     * 
     * @return
     *     possible object is
     *     {@link PremiumOrBenefitRevisabilityTermsDataType }
     *     
     */
    public PremiumOrBenefitRevisabilityTermsDataType getRvsbltyData() {
        return rvsbltyData;
    }

    /**
     * Sets the value of the rvsbltyData property.
     * 
     * @param value
     *     allowed object is
     *     {@link PremiumOrBenefitRevisabilityTermsDataType }
     *     
     */
    public void setRvsbltyData(PremiumOrBenefitRevisabilityTermsDataType value) {
        this.rvsbltyData = value;
    }

    public boolean isSetRvsbltyData() {
        return (this.rvsbltyData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("premCalctn", premCalctn).add("rvsbltyData", rvsbltyData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(premCalctn, rvsbltyData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverPremiumCalculationAndRevisabiltyTermsDataType o = ((CoverPremiumCalculationAndRevisabiltyTermsDataType) other);
        return (Objects.equal(premCalctn, o.premCalctn)&&Objects.equal(rvsbltyData, o.rvsbltyData));
    }

}
