
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for CoreProductOfferDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoreProductOfferDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShortLbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="LongLbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongNameType"/&gt;
 *         &lt;element name="Desc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType"/&gt;
 *         &lt;element name="FreeTxt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreProductOfferDataType", propOrder = {
    "shortLbl",
    "longLbl",
    "desc",
    "freeTxt"
})
public class CoreProductOfferDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ShortLbl", required = true)
    protected String shortLbl;
    @XmlElement(name = "LongLbl", required = true)
    protected String longLbl;
    @XmlElement(name = "Desc", required = true)
    protected String desc;
    @XmlElement(name = "FreeTxt")
    protected String freeTxt;

    /**
     * Default no-arg constructor
     * 
     */
    public CoreProductOfferDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoreProductOfferDataType(final String shortLbl, final String longLbl, final String desc, final String freeTxt) {
        this.shortLbl = shortLbl;
        this.longLbl = longLbl;
        this.desc = desc;
        this.freeTxt = freeTxt;
    }

    /**
     * Gets the value of the shortLbl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortLbl() {
        return shortLbl;
    }

    /**
     * Sets the value of the shortLbl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortLbl(String value) {
        this.shortLbl = value;
    }

    public boolean isSetShortLbl() {
        return (this.shortLbl!= null);
    }

    /**
     * Gets the value of the longLbl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongLbl() {
        return longLbl;
    }

    /**
     * Sets the value of the longLbl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongLbl(String value) {
        this.longLbl = value;
    }

    public boolean isSetLongLbl() {
        return (this.longLbl!= null);
    }

    /**
     * Gets the value of the desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesc() {
        return desc;
    }

    /**
     * Sets the value of the desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesc(String value) {
        this.desc = value;
    }

    public boolean isSetDesc() {
        return (this.desc!= null);
    }

    /**
     * Gets the value of the freeTxt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeTxt() {
        return freeTxt;
    }

    /**
     * Sets the value of the freeTxt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeTxt(String value) {
        this.freeTxt = value;
    }

    public boolean isSetFreeTxt() {
        return (this.freeTxt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("shortLbl", shortLbl).add("longLbl", longLbl).add("desc", desc).add("freeTxt", freeTxt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(shortLbl, longLbl, desc, freeTxt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoreProductOfferDataType o = ((CoreProductOfferDataType) other);
        return (((Objects.equal(shortLbl, o.shortLbl)&&Objects.equal(longLbl, o.longLbl))&&Objects.equal(desc, o.desc))&&Objects.equal(freeTxt, o.freeTxt));
    }

}
