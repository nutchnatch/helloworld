
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage commercial communication data
 * 			
 * 
 * <p>Java class for CommercialCommunicationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CommercialCommunicationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Chnnl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MediaTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AuthoriztnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CommercialCommunicationType", propOrder = {
    "chnnl",
    "authoriztnIndic"
})
public class CommercialCommunicationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Chnnl")
    protected String chnnl;
    @XmlElement(name = "AuthoriztnIndic")
    protected String authoriztnIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public CommercialCommunicationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CommercialCommunicationType(final String chnnl, final String authoriztnIndic) {
        this.chnnl = chnnl;
        this.authoriztnIndic = authoriztnIndic;
    }

    /**
     * Gets the value of the chnnl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChnnl() {
        return chnnl;
    }

    /**
     * Sets the value of the chnnl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChnnl(String value) {
        this.chnnl = value;
    }

    public boolean isSetChnnl() {
        return (this.chnnl!= null);
    }

    /**
     * Gets the value of the authoriztnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthoriztnIndic() {
        return authoriztnIndic;
    }

    /**
     * Sets the value of the authoriztnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthoriztnIndic(String value) {
        this.authoriztnIndic = value;
    }

    public boolean isSetAuthoriztnIndic() {
        return (this.authoriztnIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("chnnl", chnnl).add("authoriztnIndic", authoriztnIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(chnnl, authoriztnIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CommercialCommunicationType o = ((CommercialCommunicationType) other);
        return (Objects.equal(chnnl, o.chnnl)&&Objects.equal(authoriztnIndic, o.authoriztnIndic));
    }

}
