
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Basic bloc for Indentification of object without
 * 				version (Customer, Third party, operation)
 * 			
 * 
 * <p>Java class for ClassIdentificationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClassIdentificationType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;DocumentCode"&gt;
 *       &lt;attribute name="Issuer" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IssuerCodeSLN" /&gt;
 *       &lt;attribute name="VersId" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClassIdentificationType", propOrder = {
    "value"
})
@XmlSeeAlso({
    ClassId.class
})
public class ClassIdentificationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected String value;
    @XmlAttribute(name = "Issuer", required = true)
    protected String issuer;
    @XmlAttribute(name = "VersId", required = true)
    protected int versId;

    /**
     * Default no-arg constructor
     * 
     */
    public ClassIdentificationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClassIdentificationType(final String value, final String issuer, final int versId) {
        this.value = value;
        this.issuer = issuer;
        this.versId = versId;
    }

    /**
     * Code of the type of a document 
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the issuer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuer() {
        return issuer;
    }

    /**
     * Sets the value of the issuer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuer(String value) {
        this.issuer = value;
    }

    public boolean isSetIssuer() {
        return (this.issuer!= null);
    }

    /**
     * Gets the value of the versId property.
     * 
     */
    public int getVersId() {
        return versId;
    }

    /**
     * Sets the value of the versId property.
     * 
     */
    public void setVersId(int value) {
        this.versId = value;
    }

    public boolean isSetVersId() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("issuer", issuer).add("versId", versId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, issuer, versId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClassIdentificationType o = ((ClassIdentificationType) other);
        return ((Objects.equal(value, o.value)&&Objects.equal(issuer, o.issuer))&&Objects.equal(versId, o.versId));
    }

}
