
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Currency and amount plus amount type code to manage
 * 				dynamically additional amounts
 * 			
 * 
 * <p>Java class for AdditionalAmountType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalAmountType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;AmountType"&gt;
 *       &lt;attribute name="AmntType" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN" /&gt;
 *       &lt;attribute name="Curr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalAmountType", propOrder = {
    "value"
})
public class AdditionalAmountType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected double value;
    @XmlAttribute(name = "AmntType", required = true)
    protected String amntType;
    @XmlAttribute(name = "Curr")
    protected String curr;

    /**
     * Default no-arg constructor
     * 
     */
    public AdditionalAmountType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AdditionalAmountType(final double value, final String amntType, final String curr) {
        this.value = value;
        this.amntType = amntType;
        this.curr = curr;
    }

    /**
     *  Used to limit the size of the amounts in
     * 				CurrencyandAmount
     * 			
     * 
     */
    public double getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     */
    public void setValue(double value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return true;
    }

    /**
     * Gets the value of the amntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmntType() {
        return amntType;
    }

    /**
     * Sets the value of the amntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmntType(String value) {
        this.amntType = value;
    }

    public boolean isSetAmntType() {
        return (this.amntType!= null);
    }

    /**
     * Gets the value of the curr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurr() {
        return curr;
    }

    /**
     * Sets the value of the curr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurr(String value) {
        this.curr = value;
    }

    public boolean isSetCurr() {
        return (this.curr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("amntType", amntType).add("curr", curr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, amntType, curr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AdditionalAmountType o = ((AdditionalAmountType) other);
        return ((Objects.equal(value, o.value)&&Objects.equal(amntType, o.amntType))&&Objects.equal(curr, o.curr));
    }

}
