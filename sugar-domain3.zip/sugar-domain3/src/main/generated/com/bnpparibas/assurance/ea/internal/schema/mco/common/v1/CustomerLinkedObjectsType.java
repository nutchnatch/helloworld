
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a customer has dependencies
 * 			
 * 
 * <p>Java class for CustomerLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomerLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerLinkedObjectsType", propOrder = {
    "distrbtr",
    "prdctr"
})
public class CustomerLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Distrbtr", required = true)
    protected List<PartnerPartyType> distrbtr;
    @XmlElement(name = "Prdctr")
    protected PartyRoleType prdctr;

    /**
     * Default no-arg constructor
     * 
     */
    public CustomerLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CustomerLinkedObjectsType(final List<PartnerPartyType> distrbtr, final PartyRoleType prdctr) {
        this.distrbtr = distrbtr;
        this.prdctr = prdctr;
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the distrbtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDistrbtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getDistrbtr() {
        if (distrbtr == null) {
            distrbtr = new ArrayList<PartnerPartyType>();
        }
        return this.distrbtr;
    }

    public boolean isSetDistrbtr() {
        return ((this.distrbtr!= null)&&(!this.distrbtr.isEmpty()));
    }

    public void unsetDistrbtr() {
        this.distrbtr = null;
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("distrbtr", distrbtr).add("prdctr", prdctr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(distrbtr, prdctr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CustomerLinkedObjectsType o = ((CustomerLinkedObjectsType) other);
        return (Objects.equal(distrbtr, o.distrbtr)&&Objects.equal(prdctr, o.prdctr));
    }

}
