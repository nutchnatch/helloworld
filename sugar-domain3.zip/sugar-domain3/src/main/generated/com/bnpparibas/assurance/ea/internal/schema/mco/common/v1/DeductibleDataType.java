
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage informationon deductible
 * 			
 * 
 * <p>Java class for DeductibleDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DeductibleDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DeductibleTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DeductibleDataType", propOrder = {
    "type",
    "amnt",
    "prd",
    "rate"
})
public class DeductibleDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "Prd")
    protected DurationType prd;
    @XmlElement(name = "Rate")
    protected Double rate;

    /**
     * Default no-arg constructor
     * 
     */
    public DeductibleDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DeductibleDataType(final String type, final CurrencyAndAmountType amnt, final DurationType prd, final Double rate) {
        this.type = type;
        this.amnt = amnt;
        this.prd = prd;
        this.rate = rate;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the prd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getPrd() {
        return prd;
    }

    /**
     * Sets the value of the prd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setPrd(DurationType value) {
        this.prd = value;
    }

    public boolean isSetPrd() {
        return (this.prd!= null);
    }

    /**
     * Gets the value of the rate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getRate() {
        return rate;
    }

    /**
     * Sets the value of the rate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setRate(Double value) {
        this.rate = value;
    }

    public boolean isSetRate() {
        return (this.rate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("amnt", amnt).add("prd", prd).add("rate", rate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, amnt, prd, rate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DeductibleDataType o = ((DeductibleDataType) other);
        return (((Objects.equal(type, o.type)&&Objects.equal(amnt, o.amnt))&&Objects.equal(prd, o.prd))&&Objects.equal(rate, o.rate));
    }

}
