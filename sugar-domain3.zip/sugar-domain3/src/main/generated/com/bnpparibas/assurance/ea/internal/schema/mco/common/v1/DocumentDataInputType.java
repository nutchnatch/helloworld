
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on document
 * 			
 * 
 * <p>Java class for DocumentDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentTypeCode"/&gt;
 *         &lt;element name="Lang" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LocalType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentDataInputType", propOrder = {
    "idntfctn",
    "type",
    "lang"
})
public class DocumentDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn")
    protected ObjectIdentificationType idntfctn;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "Lang")
    protected LocalType lang;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentDataInputType(final ObjectIdentificationType idntfctn, final String type, final LocalType lang) {
        this.idntfctn = idntfctn;
        this.type = type;
        this.lang = lang;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntfctn(ObjectIdentificationType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link LocalType }
     *     
     */
    public LocalType getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocalType }
     *     
     */
    public void setLang(LocalType value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("type", type).add("lang", lang).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, type, lang);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentDataInputType o = ((DocumentDataInputType) other);
        return ((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(type, o.type))&&Objects.equal(lang, o.lang));
    }

}
