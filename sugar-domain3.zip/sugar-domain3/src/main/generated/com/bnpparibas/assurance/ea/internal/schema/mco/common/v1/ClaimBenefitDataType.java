
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage global data of a claim benefit
 * 			
 * 
 * <p>Java class for ClaimBenefitDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimBenefitDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="JustfdPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="RefPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimBenefitDataType", propOrder = {
    "justfdPrd",
    "refPrd",
    "amnt"
})
public class ClaimBenefitDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "JustfdPrd")
    protected DatePeriodType justfdPrd;
    @XmlElement(name = "RefPrd")
    protected DatePeriodType refPrd;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimBenefitDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimBenefitDataType(final DatePeriodType justfdPrd, final DatePeriodType refPrd, final CurrencyAndAmountType amnt) {
        this.justfdPrd = justfdPrd;
        this.refPrd = refPrd;
        this.amnt = amnt;
    }

    /**
     * Gets the value of the justfdPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getJustfdPrd() {
        return justfdPrd;
    }

    /**
     * Sets the value of the justfdPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setJustfdPrd(DatePeriodType value) {
        this.justfdPrd = value;
    }

    public boolean isSetJustfdPrd() {
        return (this.justfdPrd!= null);
    }

    /**
     * Gets the value of the refPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getRefPrd() {
        return refPrd;
    }

    /**
     * Sets the value of the refPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setRefPrd(DatePeriodType value) {
        this.refPrd = value;
    }

    public boolean isSetRefPrd() {
        return (this.refPrd!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("justfdPrd", justfdPrd).add("refPrd", refPrd).add("amnt", amnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(justfdPrd, refPrd, amnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimBenefitDataType o = ((ClaimBenefitDataType) other);
        return ((Objects.equal(justfdPrd, o.justfdPrd)&&Objects.equal(refPrd, o.refPrd))&&Objects.equal(amnt, o.amnt));
    }

}
