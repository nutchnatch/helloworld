
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage customer external qualification data
 * 			
 * 
 * <p>Java class for CustomerExternalQualificationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomerExternalQualificationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Income" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IncomeType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="HoldngsAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="EductnLvl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EducationLevelCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="HseHoldrType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SubscriberOccupantTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="HseType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}HouseTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AreaZoningNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReferenceDataCodificationType" minOccurs="0"/&gt;
 *         &lt;element name="ChildBrthDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CustSegmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReferenceDataCodificationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FavCntctChnnl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommunicationChannelCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ComrclComnctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommercialCommunicationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerExternalQualificationDataType", propOrder = {
    "income",
    "holdngsAmnt",
    "eductnLvl",
    "hseHoldrType",
    "hseType",
    "areaZoningNumb",
    "childBrthDate",
    "custSegmnt",
    "favCntctChnnl",
    "comrclComnctn"
})
public class CustomerExternalQualificationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Income")
    protected List<IncomeType> income;
    @XmlElement(name = "HoldngsAmnt")
    protected CurrencyAndAmountType holdngsAmnt;
    @XmlElement(name = "EductnLvl")
    protected String eductnLvl;
    @XmlElement(name = "HseHoldrType")
    protected String hseHoldrType;
    @XmlElement(name = "HseType")
    protected String hseType;
    @XmlElement(name = "AreaZoningNumb")
    protected ReferenceDataCodificationType areaZoningNumb;
    @XmlElement(name = "ChildBrthDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected List<Date> childBrthDate;
    @XmlElement(name = "CustSegmnt")
    protected List<ReferenceDataCodificationType> custSegmnt;
    @XmlElement(name = "FavCntctChnnl")
    protected String favCntctChnnl;
    @XmlElement(name = "ComrclComnctn")
    protected List<CommercialCommunicationType> comrclComnctn;

    /**
     * Default no-arg constructor
     * 
     */
    public CustomerExternalQualificationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CustomerExternalQualificationDataType(final List<IncomeType> income, final CurrencyAndAmountType holdngsAmnt, final String eductnLvl, final String hseHoldrType, final String hseType, final ReferenceDataCodificationType areaZoningNumb, final List<Date> childBrthDate, final List<ReferenceDataCodificationType> custSegmnt, final String favCntctChnnl, final List<CommercialCommunicationType> comrclComnctn) {
        this.income = income;
        this.holdngsAmnt = holdngsAmnt;
        this.eductnLvl = eductnLvl;
        this.hseHoldrType = hseHoldrType;
        this.hseType = hseType;
        this.areaZoningNumb = areaZoningNumb;
        this.childBrthDate = childBrthDate;
        this.custSegmnt = custSegmnt;
        this.favCntctChnnl = favCntctChnnl;
        this.comrclComnctn = comrclComnctn;
    }

    /**
     * Gets the value of the income property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the income property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIncome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IncomeType }
     * 
     * 
     */
    public List<IncomeType> getIncome() {
        if (income == null) {
            income = new ArrayList<IncomeType>();
        }
        return this.income;
    }

    public boolean isSetIncome() {
        return ((this.income!= null)&&(!this.income.isEmpty()));
    }

    public void unsetIncome() {
        this.income = null;
    }

    /**
     * Gets the value of the holdngsAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getHoldngsAmnt() {
        return holdngsAmnt;
    }

    /**
     * Sets the value of the holdngsAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setHoldngsAmnt(CurrencyAndAmountType value) {
        this.holdngsAmnt = value;
    }

    public boolean isSetHoldngsAmnt() {
        return (this.holdngsAmnt!= null);
    }

    /**
     * Gets the value of the eductnLvl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEductnLvl() {
        return eductnLvl;
    }

    /**
     * Sets the value of the eductnLvl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEductnLvl(String value) {
        this.eductnLvl = value;
    }

    public boolean isSetEductnLvl() {
        return (this.eductnLvl!= null);
    }

    /**
     * Gets the value of the hseHoldrType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHseHoldrType() {
        return hseHoldrType;
    }

    /**
     * Sets the value of the hseHoldrType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHseHoldrType(String value) {
        this.hseHoldrType = value;
    }

    public boolean isSetHseHoldrType() {
        return (this.hseHoldrType!= null);
    }

    /**
     * Gets the value of the hseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHseType() {
        return hseType;
    }

    /**
     * Sets the value of the hseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHseType(String value) {
        this.hseType = value;
    }

    public boolean isSetHseType() {
        return (this.hseType!= null);
    }

    /**
     * Gets the value of the areaZoningNumb property.
     * 
     * @return
     *     possible object is
     *     {@link ReferenceDataCodificationType }
     *     
     */
    public ReferenceDataCodificationType getAreaZoningNumb() {
        return areaZoningNumb;
    }

    /**
     * Sets the value of the areaZoningNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReferenceDataCodificationType }
     *     
     */
    public void setAreaZoningNumb(ReferenceDataCodificationType value) {
        this.areaZoningNumb = value;
    }

    public boolean isSetAreaZoningNumb() {
        return (this.areaZoningNumb!= null);
    }

    /**
     * Gets the value of the childBrthDate property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the childBrthDate property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChildBrthDate().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<Date> getChildBrthDate() {
        if (childBrthDate == null) {
            childBrthDate = new ArrayList<Date>();
        }
        return this.childBrthDate;
    }

    public boolean isSetChildBrthDate() {
        return ((this.childBrthDate!= null)&&(!this.childBrthDate.isEmpty()));
    }

    public void unsetChildBrthDate() {
        this.childBrthDate = null;
    }

    /**
     * Gets the value of the custSegmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the custSegmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustSegmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReferenceDataCodificationType }
     * 
     * 
     */
    public List<ReferenceDataCodificationType> getCustSegmnt() {
        if (custSegmnt == null) {
            custSegmnt = new ArrayList<ReferenceDataCodificationType>();
        }
        return this.custSegmnt;
    }

    public boolean isSetCustSegmnt() {
        return ((this.custSegmnt!= null)&&(!this.custSegmnt.isEmpty()));
    }

    public void unsetCustSegmnt() {
        this.custSegmnt = null;
    }

    /**
     * Gets the value of the favCntctChnnl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFavCntctChnnl() {
        return favCntctChnnl;
    }

    /**
     * Sets the value of the favCntctChnnl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFavCntctChnnl(String value) {
        this.favCntctChnnl = value;
    }

    public boolean isSetFavCntctChnnl() {
        return (this.favCntctChnnl!= null);
    }

    /**
     * Gets the value of the comrclComnctn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comrclComnctn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComrclComnctn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommercialCommunicationType }
     * 
     * 
     */
    public List<CommercialCommunicationType> getComrclComnctn() {
        if (comrclComnctn == null) {
            comrclComnctn = new ArrayList<CommercialCommunicationType>();
        }
        return this.comrclComnctn;
    }

    public boolean isSetComrclComnctn() {
        return ((this.comrclComnctn!= null)&&(!this.comrclComnctn.isEmpty()));
    }

    public void unsetComrclComnctn() {
        this.comrclComnctn = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("income", income).add("holdngsAmnt", holdngsAmnt).add("eductnLvl", eductnLvl).add("hseHoldrType", hseHoldrType).add("hseType", hseType).add("areaZoningNumb", areaZoningNumb).add("childBrthDate", childBrthDate).add("custSegmnt", custSegmnt).add("favCntctChnnl", favCntctChnnl).add("comrclComnctn", comrclComnctn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(income, holdngsAmnt, eductnLvl, hseHoldrType, hseType, areaZoningNumb, childBrthDate, custSegmnt, favCntctChnnl, comrclComnctn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CustomerExternalQualificationDataType o = ((CustomerExternalQualificationDataType) other);
        return (((((((((Objects.equal(income, o.income)&&Objects.equal(holdngsAmnt, o.holdngsAmnt))&&Objects.equal(eductnLvl, o.eductnLvl))&&Objects.equal(hseHoldrType, o.hseHoldrType))&&Objects.equal(hseType, o.hseType))&&Objects.equal(areaZoningNumb, o.areaZoningNumb))&&Objects.equal(childBrthDate, o.childBrthDate))&&Objects.equal(custSegmnt, o.custSegmnt))&&Objects.equal(favCntctChnnl, o.favCntctChnnl))&&Objects.equal(comrclComnctn, o.comrclComnctn));
    }

}
