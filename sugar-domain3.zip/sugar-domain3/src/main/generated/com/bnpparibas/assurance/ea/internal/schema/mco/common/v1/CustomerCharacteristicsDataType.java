
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Descriptive Characteristics of the customer
 * 				(individua and legal entity)
 * 			
 * 
 * <p>Java class for CustomerCharacteristicsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomerCharacteristicsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CustData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CustomerGenericDataType"/&gt;
 *         &lt;element name="NaturlPersn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NaturalPersonType" minOccurs="0"/&gt;
 *         &lt;element name="LegalEntty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalEntityType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerCharacteristicsDataType", propOrder = {
    "custData",
    "naturlPersn",
    "legalEntty"
})
public class CustomerCharacteristicsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CustData", required = true)
    protected CustomerGenericDataType custData;
    @XmlElement(name = "NaturlPersn")
    protected NaturalPersonType naturlPersn;
    @XmlElement(name = "LegalEntty")
    protected LegalEntityType legalEntty;

    /**
     * Default no-arg constructor
     * 
     */
    public CustomerCharacteristicsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CustomerCharacteristicsDataType(final CustomerGenericDataType custData, final NaturalPersonType naturlPersn, final LegalEntityType legalEntty) {
        this.custData = custData;
        this.naturlPersn = naturlPersn;
        this.legalEntty = legalEntty;
    }

    /**
     * Gets the value of the custData property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerGenericDataType }
     *     
     */
    public CustomerGenericDataType getCustData() {
        return custData;
    }

    /**
     * Sets the value of the custData property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerGenericDataType }
     *     
     */
    public void setCustData(CustomerGenericDataType value) {
        this.custData = value;
    }

    public boolean isSetCustData() {
        return (this.custData!= null);
    }

    /**
     * Gets the value of the naturlPersn property.
     * 
     * @return
     *     possible object is
     *     {@link NaturalPersonType }
     *     
     */
    public NaturalPersonType getNaturlPersn() {
        return naturlPersn;
    }

    /**
     * Sets the value of the naturlPersn property.
     * 
     * @param value
     *     allowed object is
     *     {@link NaturalPersonType }
     *     
     */
    public void setNaturlPersn(NaturalPersonType value) {
        this.naturlPersn = value;
    }

    public boolean isSetNaturlPersn() {
        return (this.naturlPersn!= null);
    }

    /**
     * Gets the value of the legalEntty property.
     * 
     * @return
     *     possible object is
     *     {@link LegalEntityType }
     *     
     */
    public LegalEntityType getLegalEntty() {
        return legalEntty;
    }

    /**
     * Sets the value of the legalEntty property.
     * 
     * @param value
     *     allowed object is
     *     {@link LegalEntityType }
     *     
     */
    public void setLegalEntty(LegalEntityType value) {
        this.legalEntty = value;
    }

    public boolean isSetLegalEntty() {
        return (this.legalEntty!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("custData", custData).add("naturlPersn", naturlPersn).add("legalEntty", legalEntty).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(custData, naturlPersn, legalEntty);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CustomerCharacteristicsDataType o = ((CustomerCharacteristicsDataType) other);
        return ((Objects.equal(custData, o.custData)&&Objects.equal(naturlPersn, o.naturlPersn))&&Objects.equal(legalEntty, o.legalEntty));
    }

}
