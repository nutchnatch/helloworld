
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DocumentStatusCode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DocumentStatusCode"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="DELETED"/&gt;
 *     &lt;enumeration value="NEW"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "DocumentStatusCode")
@XmlEnum
public enum DocumentStatusCode {

    DELETED,
    NEW;

    public String value() {
        return name();
    }

    public static DocumentStatusCode fromValue(String v) {
        return valueOf(v);
    }

}
