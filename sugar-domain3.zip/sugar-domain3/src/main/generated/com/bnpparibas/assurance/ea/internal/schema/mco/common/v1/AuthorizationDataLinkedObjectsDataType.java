
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objets liés avec
 * 				l'élément d'autorisation
 * 			
 * 
 * <p>Java class for AuthorizationDataLinkedObjectsDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AuthorizationDataLinkedObjectsDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MgmtAreaId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType"/&gt;
 *         &lt;element name="ApplctnDomainId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AuthoriztnObjctLink" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AuthorizationObjectLinkType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuthorizationDataLinkedObjectsDataType", propOrder = {
    "mgmtAreaId",
    "applctnDomainId",
    "authoriztnObjctLink"
})
public class AuthorizationDataLinkedObjectsDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "MgmtAreaId", required = true)
    protected IdentificationType mgmtAreaId;
    @XmlElement(name = "ApplctnDomainId")
    protected List<IdentificationType> applctnDomainId;
    @XmlElement(name = "AuthoriztnObjctLink")
    protected List<AuthorizationObjectLinkType> authoriztnObjctLink;

    /**
     * Default no-arg constructor
     * 
     */
    public AuthorizationDataLinkedObjectsDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AuthorizationDataLinkedObjectsDataType(final IdentificationType mgmtAreaId, final List<IdentificationType> applctnDomainId, final List<AuthorizationObjectLinkType> authoriztnObjctLink) {
        this.mgmtAreaId = mgmtAreaId;
        this.applctnDomainId = applctnDomainId;
        this.authoriztnObjctLink = authoriztnObjctLink;
    }

    /**
     * Gets the value of the mgmtAreaId property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getMgmtAreaId() {
        return mgmtAreaId;
    }

    /**
     * Sets the value of the mgmtAreaId property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setMgmtAreaId(IdentificationType value) {
        this.mgmtAreaId = value;
    }

    public boolean isSetMgmtAreaId() {
        return (this.mgmtAreaId!= null);
    }

    /**
     * Gets the value of the applctnDomainId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the applctnDomainId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getApplctnDomainId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentificationType }
     * 
     * 
     */
    public List<IdentificationType> getApplctnDomainId() {
        if (applctnDomainId == null) {
            applctnDomainId = new ArrayList<IdentificationType>();
        }
        return this.applctnDomainId;
    }

    public boolean isSetApplctnDomainId() {
        return ((this.applctnDomainId!= null)&&(!this.applctnDomainId.isEmpty()));
    }

    public void unsetApplctnDomainId() {
        this.applctnDomainId = null;
    }

    /**
     * Gets the value of the authoriztnObjctLink property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the authoriztnObjctLink property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAuthoriztnObjctLink().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AuthorizationObjectLinkType }
     * 
     * 
     */
    public List<AuthorizationObjectLinkType> getAuthoriztnObjctLink() {
        if (authoriztnObjctLink == null) {
            authoriztnObjctLink = new ArrayList<AuthorizationObjectLinkType>();
        }
        return this.authoriztnObjctLink;
    }

    public boolean isSetAuthoriztnObjctLink() {
        return ((this.authoriztnObjctLink!= null)&&(!this.authoriztnObjctLink.isEmpty()));
    }

    public void unsetAuthoriztnObjctLink() {
        this.authoriztnObjctLink = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("mgmtAreaId", mgmtAreaId).add("applctnDomainId", applctnDomainId).add("authoriztnObjctLink", authoriztnObjctLink).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(mgmtAreaId, applctnDomainId, authoriztnObjctLink);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AuthorizationDataLinkedObjectsDataType o = ((AuthorizationDataLinkedObjectsDataType) other);
        return ((Objects.equal(mgmtAreaId, o.mgmtAreaId)&&Objects.equal(applctnDomainId, o.applctnDomainId))&&Objects.equal(authoriztnObjctLink, o.authoriztnObjctLink));
    }

}
