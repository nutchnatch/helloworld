
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on a bank account with
 * 				the identifier of the creditor
 * 			
 * 
 * <p>Java class for BankAccountAndCreditorDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankAccountAndCreditorDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Acct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankAccountIdentificationType"/&gt;
 *         &lt;element name="CreditrIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankAccountAndCreditorDataType", propOrder = {
    "acct",
    "creditrIdntfctn"
})
public class BankAccountAndCreditorDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Acct", required = true)
    protected BankAccountIdentificationType acct;
    @XmlElement(name = "CreditrIdntfctn")
    protected IdentificationType creditrIdntfctn;

    /**
     * Default no-arg constructor
     * 
     */
    public BankAccountAndCreditorDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BankAccountAndCreditorDataType(final BankAccountIdentificationType acct, final IdentificationType creditrIdntfctn) {
        this.acct = acct;
        this.creditrIdntfctn = creditrIdntfctn;
    }

    /**
     * Gets the value of the acct property.
     * 
     * @return
     *     possible object is
     *     {@link BankAccountIdentificationType }
     *     
     */
    public BankAccountIdentificationType getAcct() {
        return acct;
    }

    /**
     * Sets the value of the acct property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankAccountIdentificationType }
     *     
     */
    public void setAcct(BankAccountIdentificationType value) {
        this.acct = value;
    }

    public boolean isSetAcct() {
        return (this.acct!= null);
    }

    /**
     * Gets the value of the creditrIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getCreditrIdntfctn() {
        return creditrIdntfctn;
    }

    /**
     * Sets the value of the creditrIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setCreditrIdntfctn(IdentificationType value) {
        this.creditrIdntfctn = value;
    }

    public boolean isSetCreditrIdntfctn() {
        return (this.creditrIdntfctn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("acct", acct).add("creditrIdntfctn", creditrIdntfctn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(acct, creditrIdntfctn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BankAccountAndCreditorDataType o = ((BankAccountAndCreditorDataType) other);
        return (Objects.equal(acct, o.acct)&&Objects.equal(creditrIdntfctn, o.creditrIdntfctn));
    }

}
