
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage global data of a claim file
 * 			
 * 
 * <p>Java class for ClaimFileDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimFileDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeningDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="ClosngDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimFileDataType", propOrder = {
    "openingDate",
    "closngDate"
})
public class ClaimFileDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeningDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date openingDate;
    @XmlElement(name = "ClosngDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date closngDate;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimFileDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimFileDataType(final Date openingDate, final Date closngDate) {
        this.openingDate = openingDate;
        this.closngDate = closngDate;
    }

    /**
     * Gets the value of the openingDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getOpeningDate() {
        return openingDate;
    }

    /**
     * Sets the value of the openingDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeningDate(Date value) {
        this.openingDate = value;
    }

    public boolean isSetOpeningDate() {
        return (this.openingDate!= null);
    }

    /**
     * Gets the value of the closngDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getClosngDate() {
        return closngDate;
    }

    /**
     * Sets the value of the closngDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosngDate(Date value) {
        this.closngDate = value;
    }

    public boolean isSetClosngDate() {
        return (this.closngDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("openingDate", openingDate).add("closngDate", closngDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(openingDate, closngDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimFileDataType o = ((ClaimFileDataType) other);
        return (Objects.equal(openingDate, o.openingDate)&&Objects.equal(closngDate, o.closngDate));
    }

}
