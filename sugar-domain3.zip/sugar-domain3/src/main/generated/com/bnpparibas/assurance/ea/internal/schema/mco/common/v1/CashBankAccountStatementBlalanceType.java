
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on cash bank account
 * 				statement balance
 * 			
 * 
 * <p>Java class for CashBankAccountStatementBlalanceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountStatementBlalanceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Curr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="OpeningBalnce" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CashBalanceType"/&gt;
 *         &lt;element name="ClosngBalnce" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CashBalanceType"/&gt;
 *         &lt;element name="Entry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CashBankAccountStatementEntryType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountStatementBlalanceType", propOrder = {
    "curr",
    "openingBalnce",
    "closngBalnce",
    "entry"
})
public class CashBankAccountStatementBlalanceType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Curr", required = true)
    protected String curr;
    @XmlElement(name = "OpeningBalnce", required = true)
    protected CashBalanceType openingBalnce;
    @XmlElement(name = "ClosngBalnce", required = true)
    protected CashBalanceType closngBalnce;
    @XmlElement(name = "Entry")
    protected List<CashBankAccountStatementEntryType> entry;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountStatementBlalanceType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountStatementBlalanceType(final String curr, final CashBalanceType openingBalnce, final CashBalanceType closngBalnce, final List<CashBankAccountStatementEntryType> entry) {
        this.curr = curr;
        this.openingBalnce = openingBalnce;
        this.closngBalnce = closngBalnce;
        this.entry = entry;
    }

    /**
     * Gets the value of the curr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurr() {
        return curr;
    }

    /**
     * Sets the value of the curr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurr(String value) {
        this.curr = value;
    }

    public boolean isSetCurr() {
        return (this.curr!= null);
    }

    /**
     * Gets the value of the openingBalnce property.
     * 
     * @return
     *     possible object is
     *     {@link CashBalanceType }
     *     
     */
    public CashBalanceType getOpeningBalnce() {
        return openingBalnce;
    }

    /**
     * Sets the value of the openingBalnce property.
     * 
     * @param value
     *     allowed object is
     *     {@link CashBalanceType }
     *     
     */
    public void setOpeningBalnce(CashBalanceType value) {
        this.openingBalnce = value;
    }

    public boolean isSetOpeningBalnce() {
        return (this.openingBalnce!= null);
    }

    /**
     * Gets the value of the closngBalnce property.
     * 
     * @return
     *     possible object is
     *     {@link CashBalanceType }
     *     
     */
    public CashBalanceType getClosngBalnce() {
        return closngBalnce;
    }

    /**
     * Sets the value of the closngBalnce property.
     * 
     * @param value
     *     allowed object is
     *     {@link CashBalanceType }
     *     
     */
    public void setClosngBalnce(CashBalanceType value) {
        this.closngBalnce = value;
    }

    public boolean isSetClosngBalnce() {
        return (this.closngBalnce!= null);
    }

    /**
     * Gets the value of the entry property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the entry property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEntry().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CashBankAccountStatementEntryType }
     * 
     * 
     */
    public List<CashBankAccountStatementEntryType> getEntry() {
        if (entry == null) {
            entry = new ArrayList<CashBankAccountStatementEntryType>();
        }
        return this.entry;
    }

    public boolean isSetEntry() {
        return ((this.entry!= null)&&(!this.entry.isEmpty()));
    }

    public void unsetEntry() {
        this.entry = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("curr", curr).add("openingBalnce", openingBalnce).add("closngBalnce", closngBalnce).add("entry", entry).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(curr, openingBalnce, closngBalnce, entry);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountStatementBlalanceType o = ((CashBankAccountStatementBlalanceType) other);
        return (((Objects.equal(curr, o.curr)&&Objects.equal(openingBalnce, o.openingBalnce))&&Objects.equal(closngBalnce, o.closngBalnce))&&Objects.equal(entry, o.entry));
    }

}
