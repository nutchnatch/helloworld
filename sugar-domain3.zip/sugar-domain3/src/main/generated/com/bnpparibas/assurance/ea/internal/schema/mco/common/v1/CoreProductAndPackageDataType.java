
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * <p>Java class for CoreProductAndPackageDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoreProductAndPackageDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShortLbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="LongLbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongNameType"/&gt;
 *         &lt;element name="Desc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType"/&gt;
 *         &lt;element name="FreeTxt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FreeTextType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ComrclztnEndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ExtrnlDocLink" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}URLFormatType" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductObjectStatusType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreProductAndPackageDataType", propOrder = {
    "shortLbl",
    "longLbl",
    "desc",
    "freeTxt",
    "comrclztnEndDate",
    "extrnlDocLink",
    "status"
})
public class CoreProductAndPackageDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ShortLbl", required = true)
    protected String shortLbl;
    @XmlElement(name = "LongLbl", required = true)
    protected String longLbl;
    @XmlElement(name = "Desc", required = true)
    protected String desc;
    @XmlElement(name = "FreeTxt")
    protected List<String> freeTxt;
    @XmlElement(name = "ComrclztnEndDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date comrclztnEndDate;
    @XmlElement(name = "ExtrnlDocLink")
    protected String extrnlDocLink;
    @XmlElement(name = "Status", required = true)
    protected CoreProductObjectStatusType status;

    /**
     * Default no-arg constructor
     * 
     */
    public CoreProductAndPackageDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoreProductAndPackageDataType(final String shortLbl, final String longLbl, final String desc, final List<String> freeTxt, final Date comrclztnEndDate, final String extrnlDocLink, final CoreProductObjectStatusType status) {
        this.shortLbl = shortLbl;
        this.longLbl = longLbl;
        this.desc = desc;
        this.freeTxt = freeTxt;
        this.comrclztnEndDate = comrclztnEndDate;
        this.extrnlDocLink = extrnlDocLink;
        this.status = status;
    }

    /**
     * Gets the value of the shortLbl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortLbl() {
        return shortLbl;
    }

    /**
     * Sets the value of the shortLbl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortLbl(String value) {
        this.shortLbl = value;
    }

    public boolean isSetShortLbl() {
        return (this.shortLbl!= null);
    }

    /**
     * Gets the value of the longLbl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongLbl() {
        return longLbl;
    }

    /**
     * Sets the value of the longLbl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongLbl(String value) {
        this.longLbl = value;
    }

    public boolean isSetLongLbl() {
        return (this.longLbl!= null);
    }

    /**
     * Gets the value of the desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesc() {
        return desc;
    }

    /**
     * Sets the value of the desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesc(String value) {
        this.desc = value;
    }

    public boolean isSetDesc() {
        return (this.desc!= null);
    }

    /**
     * Gets the value of the freeTxt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the freeTxt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFreeTxt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFreeTxt() {
        if (freeTxt == null) {
            freeTxt = new ArrayList<String>();
        }
        return this.freeTxt;
    }

    public boolean isSetFreeTxt() {
        return ((this.freeTxt!= null)&&(!this.freeTxt.isEmpty()));
    }

    public void unsetFreeTxt() {
        this.freeTxt = null;
    }

    /**
     * Gets the value of the comrclztnEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getComrclztnEndDate() {
        return comrclztnEndDate;
    }

    /**
     * Sets the value of the comrclztnEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComrclztnEndDate(Date value) {
        this.comrclztnEndDate = value;
    }

    public boolean isSetComrclztnEndDate() {
        return (this.comrclztnEndDate!= null);
    }

    /**
     * Gets the value of the extrnlDocLink property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtrnlDocLink() {
        return extrnlDocLink;
    }

    /**
     * Sets the value of the extrnlDocLink property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtrnlDocLink(String value) {
        this.extrnlDocLink = value;
    }

    public boolean isSetExtrnlDocLink() {
        return (this.extrnlDocLink!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductObjectStatusType }
     *     
     */
    public CoreProductObjectStatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductObjectStatusType }
     *     
     */
    public void setStatus(CoreProductObjectStatusType value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("shortLbl", shortLbl).add("longLbl", longLbl).add("desc", desc).add("freeTxt", freeTxt).add("comrclztnEndDate", comrclztnEndDate).add("extrnlDocLink", extrnlDocLink).add("status", status).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(shortLbl, longLbl, desc, freeTxt, comrclztnEndDate, extrnlDocLink, status);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoreProductAndPackageDataType o = ((CoreProductAndPackageDataType) other);
        return ((((((Objects.equal(shortLbl, o.shortLbl)&&Objects.equal(longLbl, o.longLbl))&&Objects.equal(desc, o.desc))&&Objects.equal(freeTxt, o.freeTxt))&&Objects.equal(comrclztnEndDate, o.comrclztnEndDate))&&Objects.equal(extrnlDocLink, o.extrnlDocLink))&&Objects.equal(status, o.status));
    }

}
