
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage the payment of claim benefit
 * 			
 * 
 * <p>Java class for ClaimBenefitPaymentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimBenefitPaymentType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PaymntIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationPaymentInstrumentDataType" minOccurs="0"/&gt;
 *         &lt;element name="BnftPaymntAllctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationPaymentAllocationDataType" minOccurs="0"/&gt;
 *         &lt;element name="RecipintPrty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="SpecifRecipint" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentSpecificRecipientType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimBenefitPaymentType", propOrder = {
    "paymntIdntfctn",
    "paymntData",
    "bnftPaymntAllctn",
    "recipintPrty",
    "specifRecipint"
})
public class ClaimBenefitPaymentType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PaymntIdntfctn")
    protected ObjectIdentificationType paymntIdntfctn;
    @XmlElement(name = "PaymntData")
    protected OperationPaymentInstrumentDataType paymntData;
    @XmlElement(name = "BnftPaymntAllctn")
    protected OperationPaymentAllocationDataType bnftPaymntAllctn;
    @XmlElement(name = "RecipintPrty")
    protected PartyRoleType recipintPrty;
    @XmlElement(name = "SpecifRecipint")
    protected PaymentSpecificRecipientType specifRecipint;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimBenefitPaymentType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimBenefitPaymentType(final ObjectIdentificationType paymntIdntfctn, final OperationPaymentInstrumentDataType paymntData, final OperationPaymentAllocationDataType bnftPaymntAllctn, final PartyRoleType recipintPrty, final PaymentSpecificRecipientType specifRecipint) {
        this.paymntIdntfctn = paymntIdntfctn;
        this.paymntData = paymntData;
        this.bnftPaymntAllctn = bnftPaymntAllctn;
        this.recipintPrty = recipintPrty;
        this.specifRecipint = specifRecipint;
    }

    /**
     * Gets the value of the paymntIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPaymntIdntfctn() {
        return paymntIdntfctn;
    }

    /**
     * Sets the value of the paymntIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPaymntIdntfctn(ObjectIdentificationType value) {
        this.paymntIdntfctn = value;
    }

    public boolean isSetPaymntIdntfctn() {
        return (this.paymntIdntfctn!= null);
    }

    /**
     * Gets the value of the paymntData property.
     * 
     * @return
     *     possible object is
     *     {@link OperationPaymentInstrumentDataType }
     *     
     */
    public OperationPaymentInstrumentDataType getPaymntData() {
        return paymntData;
    }

    /**
     * Sets the value of the paymntData property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationPaymentInstrumentDataType }
     *     
     */
    public void setPaymntData(OperationPaymentInstrumentDataType value) {
        this.paymntData = value;
    }

    public boolean isSetPaymntData() {
        return (this.paymntData!= null);
    }

    /**
     * Gets the value of the bnftPaymntAllctn property.
     * 
     * @return
     *     possible object is
     *     {@link OperationPaymentAllocationDataType }
     *     
     */
    public OperationPaymentAllocationDataType getBnftPaymntAllctn() {
        return bnftPaymntAllctn;
    }

    /**
     * Sets the value of the bnftPaymntAllctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationPaymentAllocationDataType }
     *     
     */
    public void setBnftPaymntAllctn(OperationPaymentAllocationDataType value) {
        this.bnftPaymntAllctn = value;
    }

    public boolean isSetBnftPaymntAllctn() {
        return (this.bnftPaymntAllctn!= null);
    }

    /**
     * Gets the value of the recipintPrty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getRecipintPrty() {
        return recipintPrty;
    }

    /**
     * Sets the value of the recipintPrty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setRecipintPrty(PartyRoleType value) {
        this.recipintPrty = value;
    }

    public boolean isSetRecipintPrty() {
        return (this.recipintPrty!= null);
    }

    /**
     * Gets the value of the specifRecipint property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentSpecificRecipientType }
     *     
     */
    public PaymentSpecificRecipientType getSpecifRecipint() {
        return specifRecipint;
    }

    /**
     * Sets the value of the specifRecipint property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentSpecificRecipientType }
     *     
     */
    public void setSpecifRecipint(PaymentSpecificRecipientType value) {
        this.specifRecipint = value;
    }

    public boolean isSetSpecifRecipint() {
        return (this.specifRecipint!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("paymntIdntfctn", paymntIdntfctn).add("paymntData", paymntData).add("bnftPaymntAllctn", bnftPaymntAllctn).add("recipintPrty", recipintPrty).add("specifRecipint", specifRecipint).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(paymntIdntfctn, paymntData, bnftPaymntAllctn, recipintPrty, specifRecipint);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimBenefitPaymentType o = ((ClaimBenefitPaymentType) other);
        return ((((Objects.equal(paymntIdntfctn, o.paymntIdntfctn)&&Objects.equal(paymntData, o.paymntData))&&Objects.equal(bnftPaymntAllctn, o.bnftPaymntAllctn))&&Objects.equal(recipintPrty, o.recipintPrty))&&Objects.equal(specifRecipint, o.specifRecipint));
    }

}
