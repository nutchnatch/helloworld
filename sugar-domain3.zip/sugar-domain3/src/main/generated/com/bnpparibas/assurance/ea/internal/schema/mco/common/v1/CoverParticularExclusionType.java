
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage particular exclusion at cover level
 * 			
 * 
 * <p>Java class for CoverParticularExclusionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverParticularExclusionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ExclsnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExclusionTypeCodeSLN"/&gt;
 *         &lt;element name="FreeText" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FreeExclusionTextType" minOccurs="0"/&gt;
 *         &lt;element name="StdExclsnCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExclusionCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ExclsnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="MotivCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExclusionAndExtraPremiumMotiveCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="TotExclsnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverParticularExclusionType", propOrder = {
    "exclsnType",
    "freeText",
    "stdExclsnCode",
    "exclsnPrd",
    "motivCode",
    "totExclsnIndic"
})
public class CoverParticularExclusionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ExclsnType", required = true)
    protected String exclsnType;
    @XmlElement(name = "FreeText")
    protected String freeText;
    @XmlElement(name = "StdExclsnCode")
    protected String stdExclsnCode;
    @XmlElement(name = "ExclsnPrd")
    protected DatePeriodType exclsnPrd;
    @XmlElement(name = "MotivCode")
    protected String motivCode;
    @XmlElement(name = "TotExclsnIndic")
    protected String totExclsnIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverParticularExclusionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverParticularExclusionType(final String exclsnType, final String freeText, final String stdExclsnCode, final DatePeriodType exclsnPrd, final String motivCode, final String totExclsnIndic) {
        this.exclsnType = exclsnType;
        this.freeText = freeText;
        this.stdExclsnCode = stdExclsnCode;
        this.exclsnPrd = exclsnPrd;
        this.motivCode = motivCode;
        this.totExclsnIndic = totExclsnIndic;
    }

    /**
     * Gets the value of the exclsnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExclsnType() {
        return exclsnType;
    }

    /**
     * Sets the value of the exclsnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExclsnType(String value) {
        this.exclsnType = value;
    }

    public boolean isSetExclsnType() {
        return (this.exclsnType!= null);
    }

    /**
     * Gets the value of the freeText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeText() {
        return freeText;
    }

    /**
     * Sets the value of the freeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeText(String value) {
        this.freeText = value;
    }

    public boolean isSetFreeText() {
        return (this.freeText!= null);
    }

    /**
     * Gets the value of the stdExclsnCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdExclsnCode() {
        return stdExclsnCode;
    }

    /**
     * Sets the value of the stdExclsnCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdExclsnCode(String value) {
        this.stdExclsnCode = value;
    }

    public boolean isSetStdExclsnCode() {
        return (this.stdExclsnCode!= null);
    }

    /**
     * Gets the value of the exclsnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getExclsnPrd() {
        return exclsnPrd;
    }

    /**
     * Sets the value of the exclsnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setExclsnPrd(DatePeriodType value) {
        this.exclsnPrd = value;
    }

    public boolean isSetExclsnPrd() {
        return (this.exclsnPrd!= null);
    }

    /**
     * Gets the value of the motivCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotivCode() {
        return motivCode;
    }

    /**
     * Sets the value of the motivCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotivCode(String value) {
        this.motivCode = value;
    }

    public boolean isSetMotivCode() {
        return (this.motivCode!= null);
    }

    /**
     * Gets the value of the totExclsnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotExclsnIndic() {
        return totExclsnIndic;
    }

    /**
     * Sets the value of the totExclsnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotExclsnIndic(String value) {
        this.totExclsnIndic = value;
    }

    public boolean isSetTotExclsnIndic() {
        return (this.totExclsnIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("exclsnType", exclsnType).add("freeText", freeText).add("stdExclsnCode", stdExclsnCode).add("exclsnPrd", exclsnPrd).add("motivCode", motivCode).add("totExclsnIndic", totExclsnIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(exclsnType, freeText, stdExclsnCode, exclsnPrd, motivCode, totExclsnIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverParticularExclusionType o = ((CoverParticularExclusionType) other);
        return (((((Objects.equal(exclsnType, o.exclsnType)&&Objects.equal(freeText, o.freeText))&&Objects.equal(stdExclsnCode, o.stdExclsnCode))&&Objects.equal(exclsnPrd, o.exclsnPrd))&&Objects.equal(motivCode, o.motivCode))&&Objects.equal(totExclsnIndic, o.totExclsnIndic));
    }

}
