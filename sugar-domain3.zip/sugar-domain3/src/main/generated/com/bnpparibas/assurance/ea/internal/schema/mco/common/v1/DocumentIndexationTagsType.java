
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Extension buckets allowing for extensibility and
 * 				act as a container for adding elements used for the indexation of
 * 				documents: docuemnt type and other elementst that can defined in
 * 				another schema
 * 			
 * 
 * <p>Java class for DocumentIndexationTagsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentIndexationTagsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;any namespace='##other' maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentIndexationTagsType", propOrder = {
    "any"
})
public class DocumentIndexationTagsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlAnyElement(lax = true)
    protected List<Object> any;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentIndexationTagsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentIndexationTagsType(final List<Object> any) {
        this.any = any;
    }

    /**
     * Gets the value of the any property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the any property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAny().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Object }
     * 
     * 
     */
    public List<Object> getAny() {
        if (any == null) {
            any = new ArrayList<Object>();
        }
        return this.any;
    }

    public boolean isSetAny() {
        return ((this.any!= null)&&(!this.any.isEmpty()));
    }

    public void unsetAny() {
        this.any = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("any", any).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(any);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentIndexationTagsType o = ((DocumentIndexationTagsType) other);
        return Objects.equal(any, o.any);
    }

}
