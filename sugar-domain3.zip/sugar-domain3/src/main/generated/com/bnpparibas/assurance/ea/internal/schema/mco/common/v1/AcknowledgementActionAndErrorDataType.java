
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on the action and the
 * 				errors of processing in the recipent application of business objects
 * 			
 * 
 * <p>Java class for AcknowledgementActionAndErrorDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AcknowledgementActionAndErrorDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ActnData"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="ActnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *                   &lt;element name="ActnFailrReasnDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ErrDtail" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="SrceTag" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *                             &lt;element name="Value" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ValueType" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Data"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Code"&gt;
 *                               &lt;simpleType&gt;
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                   &lt;maxLength value="50"/&gt;
 *                                 &lt;/restriction&gt;
 *                               &lt;/simpleType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="SvrtyCode"&gt;
 *                               &lt;simpleType&gt;
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                   &lt;maxLength value="50"/&gt;
 *                                 &lt;/restriction&gt;
 *                               &lt;/simpleType&gt;
 *                             &lt;/element&gt;
 *                             &lt;element name="ShortDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType"/&gt;
 *                             &lt;element name="LongDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *                             &lt;element name="Lang" minOccurs="0"&gt;
 *                               &lt;simpleType&gt;
 *                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                                   &lt;maxLength value="2"/&gt;
 *                                 &lt;/restriction&gt;
 *                               &lt;/simpleType&gt;
 *                             &lt;/element&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AcknowledgementActionAndErrorDataType", propOrder = {
    "actnData",
    "errDtail"
})
public class AcknowledgementActionAndErrorDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ActnData", required = true)
    protected AcknowledgementActionAndErrorDataType.ActnData actnData;
    @XmlElement(name = "ErrDtail")
    protected List<AcknowledgementActionAndErrorDataType.ErrDtail> errDtail;

    /**
     * Default no-arg constructor
     * 
     */
    public AcknowledgementActionAndErrorDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AcknowledgementActionAndErrorDataType(final AcknowledgementActionAndErrorDataType.ActnData actnData, final List<AcknowledgementActionAndErrorDataType.ErrDtail> errDtail) {
        this.actnData = actnData;
        this.errDtail = errDtail;
    }

    /**
     * Gets the value of the actnData property.
     * 
     * @return
     *     possible object is
     *     {@link AcknowledgementActionAndErrorDataType.ActnData }
     *     
     */
    public AcknowledgementActionAndErrorDataType.ActnData getActnData() {
        return actnData;
    }

    /**
     * Sets the value of the actnData property.
     * 
     * @param value
     *     allowed object is
     *     {@link AcknowledgementActionAndErrorDataType.ActnData }
     *     
     */
    public void setActnData(AcknowledgementActionAndErrorDataType.ActnData value) {
        this.actnData = value;
    }

    public boolean isSetActnData() {
        return (this.actnData!= null);
    }

    /**
     * Gets the value of the errDtail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the errDtail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getErrDtail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AcknowledgementActionAndErrorDataType.ErrDtail }
     * 
     * 
     */
    public List<AcknowledgementActionAndErrorDataType.ErrDtail> getErrDtail() {
        if (errDtail == null) {
            errDtail = new ArrayList<AcknowledgementActionAndErrorDataType.ErrDtail>();
        }
        return this.errDtail;
    }

    public boolean isSetErrDtail() {
        return ((this.errDtail!= null)&&(!this.errDtail.isEmpty()));
    }

    public void unsetErrDtail() {
        this.errDtail = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("actnData", actnData).add("errDtail", errDtail).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(actnData, errDtail);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AcknowledgementActionAndErrorDataType o = ((AcknowledgementActionAndErrorDataType) other);
        return (Objects.equal(actnData, o.actnData)&&Objects.equal(errDtail, o.errDtail));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="ActnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
     *         &lt;element name="ActnFailrReasnDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "actnType",
        "actnFailrReasnDesc"
    })
    public static class ActnData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "ActnType", required = true)
        protected String actnType;
        @XmlElement(name = "ActnFailrReasnDesc")
        protected String actnFailrReasnDesc;

        /**
         * Default no-arg constructor
         * 
         */
        public ActnData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public ActnData(final String actnType, final String actnFailrReasnDesc) {
            this.actnType = actnType;
            this.actnFailrReasnDesc = actnFailrReasnDesc;
        }

        /**
         * Gets the value of the actnType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getActnType() {
            return actnType;
        }

        /**
         * Sets the value of the actnType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setActnType(String value) {
            this.actnType = value;
        }

        public boolean isSetActnType() {
            return (this.actnType!= null);
        }

        /**
         * Gets the value of the actnFailrReasnDesc property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getActnFailrReasnDesc() {
            return actnFailrReasnDesc;
        }

        /**
         * Sets the value of the actnFailrReasnDesc property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setActnFailrReasnDesc(String value) {
            this.actnFailrReasnDesc = value;
        }

        public boolean isSetActnFailrReasnDesc() {
            return (this.actnFailrReasnDesc!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("actnType", actnType).add("actnFailrReasnDesc", actnFailrReasnDesc).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(actnType, actnFailrReasnDesc);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final AcknowledgementActionAndErrorDataType.ActnData o = ((AcknowledgementActionAndErrorDataType.ActnData) other);
            return (Objects.equal(actnType, o.actnType)&&Objects.equal(actnFailrReasnDesc, o.actnFailrReasnDesc));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="SrceTag" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
     *                   &lt;element name="Value" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ValueType" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Data"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Code"&gt;
     *                     &lt;simpleType&gt;
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                         &lt;maxLength value="50"/&gt;
     *                       &lt;/restriction&gt;
     *                     &lt;/simpleType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="SvrtyCode"&gt;
     *                     &lt;simpleType&gt;
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                         &lt;maxLength value="50"/&gt;
     *                       &lt;/restriction&gt;
     *                     &lt;/simpleType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="ShortDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType"/&gt;
     *                   &lt;element name="LongDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
     *                   &lt;element name="Lang" minOccurs="0"&gt;
     *                     &lt;simpleType&gt;
     *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *                         &lt;maxLength value="2"/&gt;
     *                       &lt;/restriction&gt;
     *                     &lt;/simpleType&gt;
     *                   &lt;/element&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "srceTag",
        "data"
    })
    public static class ErrDtail implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "SrceTag")
        protected AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag srceTag;
        @XmlElement(name = "Data", required = true)
        protected AcknowledgementActionAndErrorDataType.ErrDtail.Data data;

        /**
         * Default no-arg constructor
         * 
         */
        public ErrDtail() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public ErrDtail(final AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag srceTag, final AcknowledgementActionAndErrorDataType.ErrDtail.Data data) {
            this.srceTag = srceTag;
            this.data = data;
        }

        /**
         * Gets the value of the srceTag property.
         * 
         * @return
         *     possible object is
         *     {@link AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag }
         *     
         */
        public AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag getSrceTag() {
            return srceTag;
        }

        /**
         * Sets the value of the srceTag property.
         * 
         * @param value
         *     allowed object is
         *     {@link AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag }
         *     
         */
        public void setSrceTag(AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag value) {
            this.srceTag = value;
        }

        public boolean isSetSrceTag() {
            return (this.srceTag!= null);
        }

        /**
         * Gets the value of the data property.
         * 
         * @return
         *     possible object is
         *     {@link AcknowledgementActionAndErrorDataType.ErrDtail.Data }
         *     
         */
        public AcknowledgementActionAndErrorDataType.ErrDtail.Data getData() {
            return data;
        }

        /**
         * Sets the value of the data property.
         * 
         * @param value
         *     allowed object is
         *     {@link AcknowledgementActionAndErrorDataType.ErrDtail.Data }
         *     
         */
        public void setData(AcknowledgementActionAndErrorDataType.ErrDtail.Data value) {
            this.data = value;
        }

        public boolean isSetData() {
            return (this.data!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("srceTag", srceTag).add("data", data).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(srceTag, data);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final AcknowledgementActionAndErrorDataType.ErrDtail o = ((AcknowledgementActionAndErrorDataType.ErrDtail) other);
            return (Objects.equal(srceTag, o.srceTag)&&Objects.equal(data, o.data));
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Code"&gt;
         *           &lt;simpleType&gt;
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *               &lt;maxLength value="50"/&gt;
         *             &lt;/restriction&gt;
         *           &lt;/simpleType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="SvrtyCode"&gt;
         *           &lt;simpleType&gt;
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *               &lt;maxLength value="50"/&gt;
         *             &lt;/restriction&gt;
         *           &lt;/simpleType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="ShortDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType"/&gt;
         *         &lt;element name="LongDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
         *         &lt;element name="Lang" minOccurs="0"&gt;
         *           &lt;simpleType&gt;
         *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
         *               &lt;maxLength value="2"/&gt;
         *             &lt;/restriction&gt;
         *           &lt;/simpleType&gt;
         *         &lt;/element&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "code",
            "svrtyCode",
            "shortDesc",
            "longDesc",
            "lang"
        })
        public static class Data implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Code", required = true)
            protected String code;
            @XmlElement(name = "SvrtyCode", required = true)
            protected String svrtyCode;
            @XmlElement(name = "ShortDesc", required = true)
            protected String shortDesc;
            @XmlElement(name = "LongDesc")
            protected String longDesc;
            @XmlElement(name = "Lang")
            protected String lang;

            /**
             * Default no-arg constructor
             * 
             */
            public Data() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public Data(final String code, final String svrtyCode, final String shortDesc, final String longDesc, final String lang) {
                this.code = code;
                this.svrtyCode = svrtyCode;
                this.shortDesc = shortDesc;
                this.longDesc = longDesc;
                this.lang = lang;
            }

            /**
             * Gets the value of the code property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getCode() {
                return code;
            }

            /**
             * Sets the value of the code property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setCode(String value) {
                this.code = value;
            }

            public boolean isSetCode() {
                return (this.code!= null);
            }

            /**
             * Gets the value of the svrtyCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getSvrtyCode() {
                return svrtyCode;
            }

            /**
             * Sets the value of the svrtyCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setSvrtyCode(String value) {
                this.svrtyCode = value;
            }

            public boolean isSetSvrtyCode() {
                return (this.svrtyCode!= null);
            }

            /**
             * Gets the value of the shortDesc property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getShortDesc() {
                return shortDesc;
            }

            /**
             * Sets the value of the shortDesc property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setShortDesc(String value) {
                this.shortDesc = value;
            }

            public boolean isSetShortDesc() {
                return (this.shortDesc!= null);
            }

            /**
             * Gets the value of the longDesc property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLongDesc() {
                return longDesc;
            }

            /**
             * Sets the value of the longDesc property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLongDesc(String value) {
                this.longDesc = value;
            }

            public boolean isSetLongDesc() {
                return (this.longDesc!= null);
            }

            /**
             * Gets the value of the lang property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLang() {
                return lang;
            }

            /**
             * Sets the value of the lang property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLang(String value) {
                this.lang = value;
            }

            public boolean isSetLang() {
                return (this.lang!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("code", code).add("svrtyCode", svrtyCode).add("shortDesc", shortDesc).add("longDesc", longDesc).add("lang", lang).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(code, svrtyCode, shortDesc, longDesc, lang);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final AcknowledgementActionAndErrorDataType.ErrDtail.Data o = ((AcknowledgementActionAndErrorDataType.ErrDtail.Data) other);
                return ((((Objects.equal(code, o.code)&&Objects.equal(svrtyCode, o.svrtyCode))&&Objects.equal(shortDesc, o.shortDesc))&&Objects.equal(longDesc, o.longDesc))&&Objects.equal(lang, o.lang));
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
         *         &lt;element name="Value" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ValueType" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "name",
            "value"
        })
        public static class SrceTag implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Name", required = true)
            protected String name;
            @XmlElement(name = "Value")
            protected String value;

            /**
             * Default no-arg constructor
             * 
             */
            public SrceTag() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public SrceTag(final String name, final String value) {
                this.name = name;
                this.value = value;
            }

            /**
             * Gets the value of the name property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getName() {
                return name;
            }

            /**
             * Sets the value of the name property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setName(String value) {
                this.name = value;
            }

            public boolean isSetName() {
                return (this.name!= null);
            }

            /**
             * Gets the value of the value property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getValue() {
                return value;
            }

            /**
             * Sets the value of the value property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setValue(String value) {
                this.value = value;
            }

            public boolean isSetValue() {
                return (this.value!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("name", name).add("value", value).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(name, value);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag o = ((AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag) other);
                return (Objects.equal(name, o.name)&&Objects.equal(value, o.value));
            }

        }

    }

}
