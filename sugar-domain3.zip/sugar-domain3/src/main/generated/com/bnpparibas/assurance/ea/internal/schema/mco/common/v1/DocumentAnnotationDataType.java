
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Document annotation
 * 				description
 * 			
 * 
 * <p>Java class for DocumentAnnotationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentAnnotationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DocumentFileURI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
 *         &lt;element name="Content" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="CreateDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="LastUpdateDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentAnnotationDataType", propOrder = {
    "documentFileURI",
    "content",
    "createDate",
    "lastUpdateDate"
})
public class DocumentAnnotationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "DocumentFileURI")
    @XmlSchemaType(name = "anyURI")
    protected String documentFileURI;
    @XmlElement(name = "Content", required = true)
    protected String content;
    @XmlElement(name = "CreateDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date createDate;
    @XmlElement(name = "LastUpdateDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date lastUpdateDate;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentAnnotationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentAnnotationDataType(final String documentFileURI, final String content, final Date createDate, final Date lastUpdateDate) {
        this.documentFileURI = documentFileURI;
        this.content = content;
        this.createDate = createDate;
        this.lastUpdateDate = lastUpdateDate;
    }

    /**
     * Gets the value of the documentFileURI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentFileURI() {
        return documentFileURI;
    }

    /**
     * Sets the value of the documentFileURI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentFileURI(String value) {
        this.documentFileURI = value;
    }

    public boolean isSetDocumentFileURI() {
        return (this.documentFileURI!= null);
    }

    /**
     * Gets the value of the content property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContent() {
        return content;
    }

    /**
     * Sets the value of the content property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContent(String value) {
        this.content = value;
    }

    public boolean isSetContent() {
        return (this.content!= null);
    }

    /**
     * Gets the value of the createDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreateDate(Date value) {
        this.createDate = value;
    }

    public boolean isSetCreateDate() {
        return (this.createDate!= null);
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastUpdateDate(Date value) {
        this.lastUpdateDate = value;
    }

    public boolean isSetLastUpdateDate() {
        return (this.lastUpdateDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("documentFileURI", documentFileURI).add("content", content).add("createDate", createDate).add("lastUpdateDate", lastUpdateDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(documentFileURI, content, createDate, lastUpdateDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentAnnotationDataType o = ((DocumentAnnotationDataType) other);
        return (((Objects.equal(documentFileURI, o.documentFileURI)&&Objects.equal(content, o.content))&&Objects.equal(createDate, o.createDate))&&Objects.equal(lastUpdateDate, o.lastUpdateDate));
    }

}
