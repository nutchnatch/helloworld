
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type which describes the information necessary for
 * 				the composition of a document (template and data
 * 			
 * 
 * <p>Java class for DocumentCompositionDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentCompositionDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TmpltAndActns" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="TmpltRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationtWithVersionType"/&gt;
 *                   &lt;element name="PreActn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentCompositionActionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                   &lt;element name="PostActn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentCompositionActionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                   &lt;element name="OutputAndOpts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentCompositionOutputOptionType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RecrsveCmpstn"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Data" maxOccurs="unbounded"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="Format" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentFormatTypeCodeSLN"/&gt;
 *                             &lt;element name="TextContent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="BnryContent" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *                             &lt;element name="DocURI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="CmpstnData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentCompositionDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentCompositionDataType", propOrder = {
    "tmpltAndActns",
    "recrsveCmpstn"
})
public class DocumentCompositionDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "TmpltAndActns")
    protected DocumentCompositionDataType.TmpltAndActns tmpltAndActns;
    @XmlElement(name = "RecrsveCmpstn", required = true)
    protected DocumentCompositionDataType.RecrsveCmpstn recrsveCmpstn;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentCompositionDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentCompositionDataType(final DocumentCompositionDataType.TmpltAndActns tmpltAndActns, final DocumentCompositionDataType.RecrsveCmpstn recrsveCmpstn) {
        this.tmpltAndActns = tmpltAndActns;
        this.recrsveCmpstn = recrsveCmpstn;
    }

    /**
     * Gets the value of the tmpltAndActns property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentCompositionDataType.TmpltAndActns }
     *     
     */
    public DocumentCompositionDataType.TmpltAndActns getTmpltAndActns() {
        return tmpltAndActns;
    }

    /**
     * Sets the value of the tmpltAndActns property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentCompositionDataType.TmpltAndActns }
     *     
     */
    public void setTmpltAndActns(DocumentCompositionDataType.TmpltAndActns value) {
        this.tmpltAndActns = value;
    }

    public boolean isSetTmpltAndActns() {
        return (this.tmpltAndActns!= null);
    }

    /**
     * Gets the value of the recrsveCmpstn property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentCompositionDataType.RecrsveCmpstn }
     *     
     */
    public DocumentCompositionDataType.RecrsveCmpstn getRecrsveCmpstn() {
        return recrsveCmpstn;
    }

    /**
     * Sets the value of the recrsveCmpstn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentCompositionDataType.RecrsveCmpstn }
     *     
     */
    public void setRecrsveCmpstn(DocumentCompositionDataType.RecrsveCmpstn value) {
        this.recrsveCmpstn = value;
    }

    public boolean isSetRecrsveCmpstn() {
        return (this.recrsveCmpstn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("tmpltAndActns", tmpltAndActns).add("recrsveCmpstn", recrsveCmpstn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(tmpltAndActns, recrsveCmpstn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentCompositionDataType o = ((DocumentCompositionDataType) other);
        return (Objects.equal(tmpltAndActns, o.tmpltAndActns)&&Objects.equal(recrsveCmpstn, o.recrsveCmpstn));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Data" maxOccurs="unbounded"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="Format" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentFormatTypeCodeSLN"/&gt;
     *                   &lt;element name="TextContent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="BnryContent" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
     *                   &lt;element name="DocURI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="CmpstnData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentCompositionDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "data",
        "cmpstnData"
    })
    public static class RecrsveCmpstn implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Data", required = true)
        protected List<DocumentCompositionDataType.RecrsveCmpstn.Data> data;
        @XmlElement(name = "CmpstnData")
        protected List<DocumentCompositionDataType> cmpstnData;

        /**
         * Default no-arg constructor
         * 
         */
        public RecrsveCmpstn() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public RecrsveCmpstn(final List<DocumentCompositionDataType.RecrsveCmpstn.Data> data, final List<DocumentCompositionDataType> cmpstnData) {
            this.data = data;
            this.cmpstnData = cmpstnData;
        }

        /**
         * Gets the value of the data property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the data property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getData().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DocumentCompositionDataType.RecrsveCmpstn.Data }
         * 
         * 
         */
        public List<DocumentCompositionDataType.RecrsveCmpstn.Data> getData() {
            if (data == null) {
                data = new ArrayList<DocumentCompositionDataType.RecrsveCmpstn.Data>();
            }
            return this.data;
        }

        public boolean isSetData() {
            return ((this.data!= null)&&(!this.data.isEmpty()));
        }

        public void unsetData() {
            this.data = null;
        }

        /**
         * Gets the value of the cmpstnData property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the cmpstnData property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCmpstnData().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DocumentCompositionDataType }
         * 
         * 
         */
        public List<DocumentCompositionDataType> getCmpstnData() {
            if (cmpstnData == null) {
                cmpstnData = new ArrayList<DocumentCompositionDataType>();
            }
            return this.cmpstnData;
        }

        public boolean isSetCmpstnData() {
            return ((this.cmpstnData!= null)&&(!this.cmpstnData.isEmpty()));
        }

        public void unsetCmpstnData() {
            this.cmpstnData = null;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("data", data).add("cmpstnData", cmpstnData).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(data, cmpstnData);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final DocumentCompositionDataType.RecrsveCmpstn o = ((DocumentCompositionDataType.RecrsveCmpstn) other);
            return (Objects.equal(data, o.data)&&Objects.equal(cmpstnData, o.cmpstnData));
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="Format" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentFormatTypeCodeSLN"/&gt;
         *         &lt;element name="TextContent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="BnryContent" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
         *         &lt;element name="DocURI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "format",
            "textContent",
            "bnryContent",
            "docURI"
        })
        public static class Data implements Serializable
        {

            private final static long serialVersionUID = 1L;
            @XmlElement(name = "Format", required = true)
            protected String format;
            @XmlElement(name = "TextContent")
            protected String textContent;
            @XmlElement(name = "BnryContent")
            protected byte[] bnryContent;
            @XmlElement(name = "DocURI")
            @XmlSchemaType(name = "anyURI")
            protected String docURI;

            /**
             * Default no-arg constructor
             * 
             */
            public Data() {
                super();
            }

            /**
             * Fully-initialising value constructor
             * 
             */
            public Data(final String format, final String textContent, final byte[] bnryContent, final String docURI) {
                this.format = format;
                this.textContent = textContent;
                this.bnryContent = bnryContent;
                this.docURI = docURI;
            }

            /**
             * Gets the value of the format property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFormat() {
                return format;
            }

            /**
             * Sets the value of the format property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFormat(String value) {
                this.format = value;
            }

            public boolean isSetFormat() {
                return (this.format!= null);
            }

            /**
             * Gets the value of the textContent property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getTextContent() {
                return textContent;
            }

            /**
             * Sets the value of the textContent property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setTextContent(String value) {
                this.textContent = value;
            }

            public boolean isSetTextContent() {
                return (this.textContent!= null);
            }

            /**
             * Gets the value of the bnryContent property.
             * 
             * @return
             *     possible object is
             *     byte[]
             */
            public byte[] getBnryContent() {
                return bnryContent;
            }

            /**
             * Sets the value of the bnryContent property.
             * 
             * @param value
             *     allowed object is
             *     byte[]
             */
            public void setBnryContent(byte[] value) {
                this.bnryContent = value;
            }

            public boolean isSetBnryContent() {
                return (this.bnryContent!= null);
            }

            /**
             * Gets the value of the docURI property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDocURI() {
                return docURI;
            }

            /**
             * Sets the value of the docURI property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDocURI(String value) {
                this.docURI = value;
            }

            public boolean isSetDocURI() {
                return (this.docURI!= null);
            }

            @Override
            public String toString() {
                return Objects.toStringHelper(this).add("format", format).add("textContent", textContent).add("bnryContent", bnryContent).add("docURI", docURI).toString();
            }

            @Override
            public int hashCode() {
                return Objects.hashCode(format, textContent, bnryContent, docURI);
            }

            @Override
            public boolean equals(Object other) {
                if (this == other) {
                    return true;
                }
                if (other == null) {
                    return false;
                }
                if (getClass()!= other.getClass()) {
                    return false;
                }
                final DocumentCompositionDataType.RecrsveCmpstn.Data o = ((DocumentCompositionDataType.RecrsveCmpstn.Data) other);
                return (((Objects.equal(format, o.format)&&Objects.equal(textContent, o.textContent))&&Objects.equal(bnryContent, o.bnryContent))&&Objects.equal(docURI, o.docURI));
            }

        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="TmpltRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationtWithVersionType"/&gt;
     *         &lt;element name="PreActn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentCompositionActionType" maxOccurs="unbounded" minOccurs="0"/&gt;
     *         &lt;element name="PostActn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentCompositionActionType" maxOccurs="unbounded" minOccurs="0"/&gt;
     *         &lt;element name="OutputAndOpts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentCompositionOutputOptionType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tmpltRef",
        "preActn",
        "postActn",
        "outputAndOpts"
    })
    public static class TmpltAndActns implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "TmpltRef", required = true)
        protected IdentificationtWithVersionType tmpltRef;
        @XmlElement(name = "PreActn")
        protected List<DocumentCompositionActionType> preActn;
        @XmlElement(name = "PostActn")
        protected List<DocumentCompositionActionType> postActn;
        @XmlElement(name = "OutputAndOpts", required = true)
        protected DocumentCompositionOutputOptionType outputAndOpts;

        /**
         * Default no-arg constructor
         * 
         */
        public TmpltAndActns() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public TmpltAndActns(final IdentificationtWithVersionType tmpltRef, final List<DocumentCompositionActionType> preActn, final List<DocumentCompositionActionType> postActn, final DocumentCompositionOutputOptionType outputAndOpts) {
            this.tmpltRef = tmpltRef;
            this.preActn = preActn;
            this.postActn = postActn;
            this.outputAndOpts = outputAndOpts;
        }

        /**
         * Gets the value of the tmpltRef property.
         * 
         * @return
         *     possible object is
         *     {@link IdentificationtWithVersionType }
         *     
         */
        public IdentificationtWithVersionType getTmpltRef() {
            return tmpltRef;
        }

        /**
         * Sets the value of the tmpltRef property.
         * 
         * @param value
         *     allowed object is
         *     {@link IdentificationtWithVersionType }
         *     
         */
        public void setTmpltRef(IdentificationtWithVersionType value) {
            this.tmpltRef = value;
        }

        public boolean isSetTmpltRef() {
            return (this.tmpltRef!= null);
        }

        /**
         * Gets the value of the preActn property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the preActn property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPreActn().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DocumentCompositionActionType }
         * 
         * 
         */
        public List<DocumentCompositionActionType> getPreActn() {
            if (preActn == null) {
                preActn = new ArrayList<DocumentCompositionActionType>();
            }
            return this.preActn;
        }

        public boolean isSetPreActn() {
            return ((this.preActn!= null)&&(!this.preActn.isEmpty()));
        }

        public void unsetPreActn() {
            this.preActn = null;
        }

        /**
         * Gets the value of the postActn property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the postActn property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPostActn().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DocumentCompositionActionType }
         * 
         * 
         */
        public List<DocumentCompositionActionType> getPostActn() {
            if (postActn == null) {
                postActn = new ArrayList<DocumentCompositionActionType>();
            }
            return this.postActn;
        }

        public boolean isSetPostActn() {
            return ((this.postActn!= null)&&(!this.postActn.isEmpty()));
        }

        public void unsetPostActn() {
            this.postActn = null;
        }

        /**
         * Gets the value of the outputAndOpts property.
         * 
         * @return
         *     possible object is
         *     {@link DocumentCompositionOutputOptionType }
         *     
         */
        public DocumentCompositionOutputOptionType getOutputAndOpts() {
            return outputAndOpts;
        }

        /**
         * Sets the value of the outputAndOpts property.
         * 
         * @param value
         *     allowed object is
         *     {@link DocumentCompositionOutputOptionType }
         *     
         */
        public void setOutputAndOpts(DocumentCompositionOutputOptionType value) {
            this.outputAndOpts = value;
        }

        public boolean isSetOutputAndOpts() {
            return (this.outputAndOpts!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("tmpltRef", tmpltRef).add("preActn", preActn).add("postActn", postActn).add("outputAndOpts", outputAndOpts).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(tmpltRef, preActn, postActn, outputAndOpts);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final DocumentCompositionDataType.TmpltAndActns o = ((DocumentCompositionDataType.TmpltAndActns) other);
            return (((Objects.equal(tmpltRef, o.tmpltRef)&&Objects.equal(preActn, o.preActn))&&Objects.equal(postActn, o.postActn))&&Objects.equal(outputAndOpts, o.outputAndOpts));
        }

    }

}
