
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Document's technical data
 * 				description.
 * 			
 * 
 * <p>Java class for DocumentTechnicalDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentTechnicalDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SeqId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="CharEncdng" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CharacterEncodingCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongNameType" minOccurs="0"/&gt;
 *         &lt;element name="Lang" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LanguageCode" minOccurs="0"/&gt;
 *         &lt;element name="Encapsltn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LosslessDataEncapsulationDescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="Intgrty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MetadataCryptographicDescriptionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentTechnicalDataType", propOrder = {
    "seqId",
    "charEncdng",
    "name",
    "lang",
    "encapsltn",
    "intgrty"
})
public class DocumentTechnicalDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SeqId")
    protected String seqId;
    @XmlElement(name = "CharEncdng")
    protected String charEncdng;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "Lang")
    protected String lang;
    @XmlElement(name = "Encapsltn")
    protected LosslessDataEncapsulationDescriptionType encapsltn;
    @XmlElement(name = "Intgrty")
    protected MetadataCryptographicDescriptionType intgrty;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentTechnicalDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentTechnicalDataType(final String seqId, final String charEncdng, final String name, final String lang, final LosslessDataEncapsulationDescriptionType encapsltn, final MetadataCryptographicDescriptionType intgrty) {
        this.seqId = seqId;
        this.charEncdng = charEncdng;
        this.name = name;
        this.lang = lang;
        this.encapsltn = encapsltn;
        this.intgrty = intgrty;
    }

    /**
     * Gets the value of the seqId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqId() {
        return seqId;
    }

    /**
     * Sets the value of the seqId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqId(String value) {
        this.seqId = value;
    }

    public boolean isSetSeqId() {
        return (this.seqId!= null);
    }

    /**
     * Gets the value of the charEncdng property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCharEncdng() {
        return charEncdng;
    }

    /**
     * Sets the value of the charEncdng property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCharEncdng(String value) {
        this.charEncdng = value;
    }

    public boolean isSetCharEncdng() {
        return (this.charEncdng!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    /**
     * Gets the value of the encapsltn property.
     * 
     * @return
     *     possible object is
     *     {@link LosslessDataEncapsulationDescriptionType }
     *     
     */
    public LosslessDataEncapsulationDescriptionType getEncapsltn() {
        return encapsltn;
    }

    /**
     * Sets the value of the encapsltn property.
     * 
     * @param value
     *     allowed object is
     *     {@link LosslessDataEncapsulationDescriptionType }
     *     
     */
    public void setEncapsltn(LosslessDataEncapsulationDescriptionType value) {
        this.encapsltn = value;
    }

    public boolean isSetEncapsltn() {
        return (this.encapsltn!= null);
    }

    /**
     * Gets the value of the intgrty property.
     * 
     * @return
     *     possible object is
     *     {@link MetadataCryptographicDescriptionType }
     *     
     */
    public MetadataCryptographicDescriptionType getIntgrty() {
        return intgrty;
    }

    /**
     * Sets the value of the intgrty property.
     * 
     * @param value
     *     allowed object is
     *     {@link MetadataCryptographicDescriptionType }
     *     
     */
    public void setIntgrty(MetadataCryptographicDescriptionType value) {
        this.intgrty = value;
    }

    public boolean isSetIntgrty() {
        return (this.intgrty!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("seqId", seqId).add("charEncdng", charEncdng).add("name", name).add("lang", lang).add("encapsltn", encapsltn).add("intgrty", intgrty).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(seqId, charEncdng, name, lang, encapsltn, intgrty);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentTechnicalDataType o = ((DocumentTechnicalDataType) other);
        return (((((Objects.equal(seqId, o.seqId)&&Objects.equal(charEncdng, o.charEncdng))&&Objects.equal(name, o.name))&&Objects.equal(lang, o.lang))&&Objects.equal(encapsltn, o.encapsltn))&&Objects.equal(intgrty, o.intgrty));
    }

}
