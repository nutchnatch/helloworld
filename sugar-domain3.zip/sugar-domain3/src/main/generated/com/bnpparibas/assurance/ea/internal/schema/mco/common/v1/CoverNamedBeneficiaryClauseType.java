
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type for named beneficairy clause linked to a cover
 * 			
 * 
 * <p>Java class for CoverNamedBeneficiaryClauseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverNamedBeneficiaryClauseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Benfciary" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="BenfciaryMinData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryMinimumDataType" minOccurs="0"/&gt;
 *         &lt;element name="DistrbtnRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="Rnk" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="EqulBnftDistrbtnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="BnftMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BenefitModeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AnntyType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AnnuityTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="AcceptntIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="AcceptatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverNamedBeneficiaryClauseType", propOrder = {
    "benfciary",
    "benfciaryMinData",
    "distrbtnRate",
    "rnk",
    "equlBnftDistrbtnIndic",
    "bnftMode",
    "anntyType",
    "amnt",
    "acceptntIndic",
    "acceptatnDate"
})
public class CoverNamedBeneficiaryClauseType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Benfciary")
    protected PartyRoleType benfciary;
    @XmlElement(name = "BenfciaryMinData")
    protected BeneficiaryMinimumDataType benfciaryMinData;
    @XmlElement(name = "DistrbtnRate")
    protected Double distrbtnRate;
    @XmlElement(name = "Rnk")
    protected BigInteger rnk;
    @XmlElement(name = "EqulBnftDistrbtnIndic")
    protected String equlBnftDistrbtnIndic;
    @XmlElement(name = "BnftMode")
    protected String bnftMode;
    @XmlElement(name = "AnntyType")
    protected String anntyType;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "AcceptntIndic")
    protected String acceptntIndic;
    @XmlElement(name = "AcceptatnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date acceptatnDate;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverNamedBeneficiaryClauseType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverNamedBeneficiaryClauseType(final PartyRoleType benfciary, final BeneficiaryMinimumDataType benfciaryMinData, final Double distrbtnRate, final BigInteger rnk, final String equlBnftDistrbtnIndic, final String bnftMode, final String anntyType, final CurrencyAndAmountType amnt, final String acceptntIndic, final Date acceptatnDate) {
        this.benfciary = benfciary;
        this.benfciaryMinData = benfciaryMinData;
        this.distrbtnRate = distrbtnRate;
        this.rnk = rnk;
        this.equlBnftDistrbtnIndic = equlBnftDistrbtnIndic;
        this.bnftMode = bnftMode;
        this.anntyType = anntyType;
        this.amnt = amnt;
        this.acceptntIndic = acceptntIndic;
        this.acceptatnDate = acceptatnDate;
    }

    /**
     * Gets the value of the benfciary property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getBenfciary() {
        return benfciary;
    }

    /**
     * Sets the value of the benfciary property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setBenfciary(PartyRoleType value) {
        this.benfciary = value;
    }

    public boolean isSetBenfciary() {
        return (this.benfciary!= null);
    }

    /**
     * Gets the value of the benfciaryMinData property.
     * 
     * @return
     *     possible object is
     *     {@link BeneficiaryMinimumDataType }
     *     
     */
    public BeneficiaryMinimumDataType getBenfciaryMinData() {
        return benfciaryMinData;
    }

    /**
     * Sets the value of the benfciaryMinData property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeneficiaryMinimumDataType }
     *     
     */
    public void setBenfciaryMinData(BeneficiaryMinimumDataType value) {
        this.benfciaryMinData = value;
    }

    public boolean isSetBenfciaryMinData() {
        return (this.benfciaryMinData!= null);
    }

    /**
     * Gets the value of the distrbtnRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDistrbtnRate() {
        return distrbtnRate;
    }

    /**
     * Sets the value of the distrbtnRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDistrbtnRate(Double value) {
        this.distrbtnRate = value;
    }

    public boolean isSetDistrbtnRate() {
        return (this.distrbtnRate!= null);
    }

    /**
     * Gets the value of the rnk property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRnk() {
        return rnk;
    }

    /**
     * Sets the value of the rnk property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRnk(BigInteger value) {
        this.rnk = value;
    }

    public boolean isSetRnk() {
        return (this.rnk!= null);
    }

    /**
     * Gets the value of the equlBnftDistrbtnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEqulBnftDistrbtnIndic() {
        return equlBnftDistrbtnIndic;
    }

    /**
     * Sets the value of the equlBnftDistrbtnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEqulBnftDistrbtnIndic(String value) {
        this.equlBnftDistrbtnIndic = value;
    }

    public boolean isSetEqulBnftDistrbtnIndic() {
        return (this.equlBnftDistrbtnIndic!= null);
    }

    /**
     * Gets the value of the bnftMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBnftMode() {
        return bnftMode;
    }

    /**
     * Sets the value of the bnftMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBnftMode(String value) {
        this.bnftMode = value;
    }

    public boolean isSetBnftMode() {
        return (this.bnftMode!= null);
    }

    /**
     * Gets the value of the anntyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnntyType() {
        return anntyType;
    }

    /**
     * Sets the value of the anntyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnntyType(String value) {
        this.anntyType = value;
    }

    public boolean isSetAnntyType() {
        return (this.anntyType!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the acceptntIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcceptntIndic() {
        return acceptntIndic;
    }

    /**
     * Sets the value of the acceptntIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcceptntIndic(String value) {
        this.acceptntIndic = value;
    }

    public boolean isSetAcceptntIndic() {
        return (this.acceptntIndic!= null);
    }

    /**
     * Gets the value of the acceptatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getAcceptatnDate() {
        return acceptatnDate;
    }

    /**
     * Sets the value of the acceptatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcceptatnDate(Date value) {
        this.acceptatnDate = value;
    }

    public boolean isSetAcceptatnDate() {
        return (this.acceptatnDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("benfciary", benfciary).add("benfciaryMinData", benfciaryMinData).add("distrbtnRate", distrbtnRate).add("rnk", rnk).add("equlBnftDistrbtnIndic", equlBnftDistrbtnIndic).add("bnftMode", bnftMode).add("anntyType", anntyType).add("amnt", amnt).add("acceptntIndic", acceptntIndic).add("acceptatnDate", acceptatnDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(benfciary, benfciaryMinData, distrbtnRate, rnk, equlBnftDistrbtnIndic, bnftMode, anntyType, amnt, acceptntIndic, acceptatnDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverNamedBeneficiaryClauseType o = ((CoverNamedBeneficiaryClauseType) other);
        return (((((((((Objects.equal(benfciary, o.benfciary)&&Objects.equal(benfciaryMinData, o.benfciaryMinData))&&Objects.equal(distrbtnRate, o.distrbtnRate))&&Objects.equal(rnk, o.rnk))&&Objects.equal(equlBnftDistrbtnIndic, o.equlBnftDistrbtnIndic))&&Objects.equal(bnftMode, o.bnftMode))&&Objects.equal(anntyType, o.anntyType))&&Objects.equal(amnt, o.amnt))&&Objects.equal(acceptntIndic, o.acceptntIndic))&&Objects.equal(acceptatnDate, o.acceptatnDate));
    }

}
