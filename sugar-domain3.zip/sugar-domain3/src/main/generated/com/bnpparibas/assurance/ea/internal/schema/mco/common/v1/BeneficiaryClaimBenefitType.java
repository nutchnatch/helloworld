
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Beneficiary claim benefit type
 * 
 * <p>Java class for BeneficiaryClaimBenefitType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneficiaryClaimBenefitType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Benfciary" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClaimBenefitDataType" minOccurs="0"/&gt;
 *         &lt;element name="Actn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimActionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="BnftPaymntStatmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClaimBenefitPaymentType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Doc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneficiaryClaimBenefitType", propOrder = {
    "benfciary",
    "data",
    "actn",
    "bnftPaymntStatmnt",
    "doc"
})
public class BeneficiaryClaimBenefitType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Benfciary", required = true)
    protected PartyRoleType benfciary;
    @XmlElement(name = "Data")
    protected BeneficiaryClaimBenefitDataType data;
    @XmlElement(name = "Actn")
    protected List<ClaimActionType> actn;
    @XmlElement(name = "BnftPaymntStatmnt", required = true)
    protected List<BeneficiaryClaimBenefitPaymentType> bnftPaymntStatmnt;
    @XmlElement(name = "Doc")
    protected List<DocumentDataType> doc;

    /**
     * Default no-arg constructor
     * 
     */
    public BeneficiaryClaimBenefitType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BeneficiaryClaimBenefitType(final PartyRoleType benfciary, final BeneficiaryClaimBenefitDataType data, final List<ClaimActionType> actn, final List<BeneficiaryClaimBenefitPaymentType> bnftPaymntStatmnt, final List<DocumentDataType> doc) {
        this.benfciary = benfciary;
        this.data = data;
        this.actn = actn;
        this.bnftPaymntStatmnt = bnftPaymntStatmnt;
        this.doc = doc;
    }

    /**
     * Gets the value of the benfciary property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getBenfciary() {
        return benfciary;
    }

    /**
     * Sets the value of the benfciary property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setBenfciary(PartyRoleType value) {
        this.benfciary = value;
    }

    public boolean isSetBenfciary() {
        return (this.benfciary!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link BeneficiaryClaimBenefitDataType }
     *     
     */
    public BeneficiaryClaimBenefitDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link BeneficiaryClaimBenefitDataType }
     *     
     */
    public void setData(BeneficiaryClaimBenefitDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the actn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClaimActionType }
     * 
     * 
     */
    public List<ClaimActionType> getActn() {
        if (actn == null) {
            actn = new ArrayList<ClaimActionType>();
        }
        return this.actn;
    }

    public boolean isSetActn() {
        return ((this.actn!= null)&&(!this.actn.isEmpty()));
    }

    public void unsetActn() {
        this.actn = null;
    }

    /**
     * Gets the value of the bnftPaymntStatmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bnftPaymntStatmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBnftPaymntStatmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BeneficiaryClaimBenefitPaymentType }
     * 
     * 
     */
    public List<BeneficiaryClaimBenefitPaymentType> getBnftPaymntStatmnt() {
        if (bnftPaymntStatmnt == null) {
            bnftPaymntStatmnt = new ArrayList<BeneficiaryClaimBenefitPaymentType>();
        }
        return this.bnftPaymntStatmnt;
    }

    public boolean isSetBnftPaymntStatmnt() {
        return ((this.bnftPaymntStatmnt!= null)&&(!this.bnftPaymntStatmnt.isEmpty()));
    }

    public void unsetBnftPaymntStatmnt() {
        this.bnftPaymntStatmnt = null;
    }

    /**
     * Gets the value of the doc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the doc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDoc().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentDataType }
     * 
     * 
     */
    public List<DocumentDataType> getDoc() {
        if (doc == null) {
            doc = new ArrayList<DocumentDataType>();
        }
        return this.doc;
    }

    public boolean isSetDoc() {
        return ((this.doc!= null)&&(!this.doc.isEmpty()));
    }

    public void unsetDoc() {
        this.doc = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("benfciary", benfciary).add("data", data).add("actn", actn).add("bnftPaymntStatmnt", bnftPaymntStatmnt).add("doc", doc).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(benfciary, data, actn, bnftPaymntStatmnt, doc);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BeneficiaryClaimBenefitType o = ((BeneficiaryClaimBenefitType) other);
        return ((((Objects.equal(benfciary, o.benfciary)&&Objects.equal(data, o.data))&&Objects.equal(actn, o.actn))&&Objects.equal(bnftPaymntStatmnt, o.bnftPaymntStatmnt))&&Objects.equal(doc, o.doc));
    }

}
