
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Java class for DocumentClassDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentClassDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ShortLabel" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="LongLabel" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Status" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Code"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;maxLength value="50"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="EffectiveDate" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DefaultRetentionDuration" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="CreateDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="LastUpdateDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="IndexValidatorType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="IndexValidatorData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Base64BinaryType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentClassDataType", propOrder = {
    "shortLabel",
    "longLabel",
    "status",
    "defaultRetentionDuration",
    "createDate",
    "lastUpdateDate",
    "indexValidatorType",
    "indexValidatorData"
})
public class DocumentClassDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ShortLabel", required = true)
    protected String shortLabel;
    @XmlElement(name = "LongLabel", required = true)
    protected String longLabel;
    @XmlElement(name = "Status")
    protected DocumentClassDataType.Status status;
    @XmlElement(name = "DefaultRetentionDuration")
    protected DurationType defaultRetentionDuration;
    @XmlElement(name = "CreateDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date createDate;
    @XmlElement(name = "LastUpdateDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date lastUpdateDate;
    @XmlElement(name = "IndexValidatorType", required = true)
    protected String indexValidatorType;
    @XmlElement(name = "IndexValidatorData", required = true)
    @XmlMimeType("application/octet-stream")
    protected DataHandler indexValidatorData;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentClassDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentClassDataType(final String shortLabel, final String longLabel, final DocumentClassDataType.Status status, final DurationType defaultRetentionDuration, final Date createDate, final Date lastUpdateDate, final String indexValidatorType, final DataHandler indexValidatorData) {
        this.shortLabel = shortLabel;
        this.longLabel = longLabel;
        this.status = status;
        this.defaultRetentionDuration = defaultRetentionDuration;
        this.createDate = createDate;
        this.lastUpdateDate = lastUpdateDate;
        this.indexValidatorType = indexValidatorType;
        this.indexValidatorData = indexValidatorData;
    }

    /**
     * Gets the value of the shortLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortLabel() {
        return shortLabel;
    }

    /**
     * Sets the value of the shortLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortLabel(String value) {
        this.shortLabel = value;
    }

    public boolean isSetShortLabel() {
        return (this.shortLabel!= null);
    }

    /**
     * Gets the value of the longLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongLabel() {
        return longLabel;
    }

    /**
     * Sets the value of the longLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongLabel(String value) {
        this.longLabel = value;
    }

    public boolean isSetLongLabel() {
        return (this.longLabel!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentClassDataType.Status }
     *     
     */
    public DocumentClassDataType.Status getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentClassDataType.Status }
     *     
     */
    public void setStatus(DocumentClassDataType.Status value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the defaultRetentionDuration property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDefaultRetentionDuration() {
        return defaultRetentionDuration;
    }

    /**
     * Sets the value of the defaultRetentionDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDefaultRetentionDuration(DurationType value) {
        this.defaultRetentionDuration = value;
    }

    public boolean isSetDefaultRetentionDuration() {
        return (this.defaultRetentionDuration!= null);
    }

    /**
     * Gets the value of the createDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreateDate(Date value) {
        this.createDate = value;
    }

    public boolean isSetCreateDate() {
        return (this.createDate!= null);
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastUpdateDate(Date value) {
        this.lastUpdateDate = value;
    }

    public boolean isSetLastUpdateDate() {
        return (this.lastUpdateDate!= null);
    }

    /**
     * Gets the value of the indexValidatorType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndexValidatorType() {
        return indexValidatorType;
    }

    /**
     * Sets the value of the indexValidatorType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndexValidatorType(String value) {
        this.indexValidatorType = value;
    }

    public boolean isSetIndexValidatorType() {
        return (this.indexValidatorType!= null);
    }

    /**
     * Gets the value of the indexValidatorData property.
     * 
     * @return
     *     possible object is
     *     {@link DataHandler }
     *     
     */
    public DataHandler getIndexValidatorData() {
        return indexValidatorData;
    }

    /**
     * Sets the value of the indexValidatorData property.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHandler }
     *     
     */
    public void setIndexValidatorData(DataHandler value) {
        this.indexValidatorData = value;
    }

    public boolean isSetIndexValidatorData() {
        return (this.indexValidatorData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("shortLabel", shortLabel).add("longLabel", longLabel).add("status", status).add("defaultRetentionDuration", defaultRetentionDuration).add("createDate", createDate).add("lastUpdateDate", lastUpdateDate).add("indexValidatorType", indexValidatorType).add("indexValidatorData", indexValidatorData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(shortLabel, longLabel, status, defaultRetentionDuration, createDate, lastUpdateDate, indexValidatorType, indexValidatorData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentClassDataType o = ((DocumentClassDataType) other);
        return (((((((Objects.equal(shortLabel, o.shortLabel)&&Objects.equal(longLabel, o.longLabel))&&Objects.equal(status, o.status))&&Objects.equal(defaultRetentionDuration, o.defaultRetentionDuration))&&Objects.equal(createDate, o.createDate))&&Objects.equal(lastUpdateDate, o.lastUpdateDate))&&Objects.equal(indexValidatorType, o.indexValidatorType))&&Objects.equal(indexValidatorData, o.indexValidatorData));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Code"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;maxLength value="50"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="EffectiveDate" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "code",
        "effectiveDate"
    })
    public static class Status implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Code", required = true)
        protected String code;
        @XmlElement(name = "EffectiveDate", required = true)
        protected Object effectiveDate;

        /**
         * Default no-arg constructor
         * 
         */
        public Status() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Status(final String code, final Object effectiveDate) {
            this.code = code;
            this.effectiveDate = effectiveDate;
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        public boolean isSetCode() {
            return (this.code!= null);
        }

        /**
         * Gets the value of the effectiveDate property.
         * 
         * @return
         *     possible object is
         *     {@link Object }
         *     
         */
        public Object getEffectiveDate() {
            return effectiveDate;
        }

        /**
         * Sets the value of the effectiveDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link Object }
         *     
         */
        public void setEffectiveDate(Object value) {
            this.effectiveDate = value;
        }

        public boolean isSetEffectiveDate() {
            return (this.effectiveDate!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("code", code).add("effectiveDate", effectiveDate).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(code, effectiveDate);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final DocumentClassDataType.Status o = ((DocumentClassDataType.Status) other);
            return (Objects.equal(code, o.code)&&Objects.equal(effectiveDate, o.effectiveDate));
        }

    }

}
