
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Payment Bank account identification with status
 * 			
 * 
 * <p>Java class for BankAccountIdentificationWithStatusType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankAccountIdentificationWithStatusType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ResdnceCntry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="IBANChckDgit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AccountCheckDigitType" minOccurs="0"/&gt;
 *         &lt;element name="FlatBBAN" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FlatBBANIdentifierType"/&gt;
 *         &lt;element name="BIC" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BICIdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="HoldrName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankAccountStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="StatusEffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankAccountIdentificationWithStatusType", propOrder = {
    "resdnceCntry",
    "ibanChckDgit",
    "flatBBAN",
    "bic",
    "holdrName",
    "status",
    "statusEffctveDate"
})
public class BankAccountIdentificationWithStatusType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ResdnceCntry")
    protected String resdnceCntry;
    @XmlElement(name = "IBANChckDgit")
    protected String ibanChckDgit;
    @XmlElement(name = "FlatBBAN", required = true)
    protected String flatBBAN;
    @XmlElement(name = "BIC")
    protected String bic;
    @XmlElement(name = "HoldrName")
    protected String holdrName;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "StatusEffctveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date statusEffctveDate;

    /**
     * Default no-arg constructor
     * 
     */
    public BankAccountIdentificationWithStatusType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BankAccountIdentificationWithStatusType(final String resdnceCntry, final String ibanChckDgit, final String flatBBAN, final String bic, final String holdrName, final String status, final Date statusEffctveDate) {
        this.resdnceCntry = resdnceCntry;
        this.ibanChckDgit = ibanChckDgit;
        this.flatBBAN = flatBBAN;
        this.bic = bic;
        this.holdrName = holdrName;
        this.status = status;
        this.statusEffctveDate = statusEffctveDate;
    }

    /**
     * Gets the value of the resdnceCntry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResdnceCntry() {
        return resdnceCntry;
    }

    /**
     * Sets the value of the resdnceCntry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResdnceCntry(String value) {
        this.resdnceCntry = value;
    }

    public boolean isSetResdnceCntry() {
        return (this.resdnceCntry!= null);
    }

    /**
     * Gets the value of the ibanChckDgit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIBANChckDgit() {
        return ibanChckDgit;
    }

    /**
     * Sets the value of the ibanChckDgit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIBANChckDgit(String value) {
        this.ibanChckDgit = value;
    }

    public boolean isSetIBANChckDgit() {
        return (this.ibanChckDgit!= null);
    }

    /**
     * Gets the value of the flatBBAN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlatBBAN() {
        return flatBBAN;
    }

    /**
     * Sets the value of the flatBBAN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlatBBAN(String value) {
        this.flatBBAN = value;
    }

    public boolean isSetFlatBBAN() {
        return (this.flatBBAN!= null);
    }

    /**
     * Gets the value of the bic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBIC() {
        return bic;
    }

    /**
     * Sets the value of the bic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBIC(String value) {
        this.bic = value;
    }

    public boolean isSetBIC() {
        return (this.bic!= null);
    }

    /**
     * Gets the value of the holdrName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldrName() {
        return holdrName;
    }

    /**
     * Sets the value of the holdrName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldrName(String value) {
        this.holdrName = value;
    }

    public boolean isSetHoldrName() {
        return (this.holdrName!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the statusEffctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getStatusEffctveDate() {
        return statusEffctveDate;
    }

    /**
     * Sets the value of the statusEffctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusEffctveDate(Date value) {
        this.statusEffctveDate = value;
    }

    public boolean isSetStatusEffctveDate() {
        return (this.statusEffctveDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("resdnceCntry", resdnceCntry).add("ibanChckDgit", ibanChckDgit).add("flatBBAN", flatBBAN).add("bic", bic).add("holdrName", holdrName).add("status", status).add("statusEffctveDate", statusEffctveDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(resdnceCntry, ibanChckDgit, flatBBAN, bic, holdrName, status, statusEffctveDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BankAccountIdentificationWithStatusType o = ((BankAccountIdentificationWithStatusType) other);
        return ((((((Objects.equal(resdnceCntry, o.resdnceCntry)&&Objects.equal(ibanChckDgit, o.ibanChckDgit))&&Objects.equal(flatBBAN, o.flatBBAN))&&Objects.equal(bic, o.bic))&&Objects.equal(holdrName, o.holdrName))&&Objects.equal(status, o.status))&&Objects.equal(statusEffctveDate, o.statusEffctveDate));
    }

}
