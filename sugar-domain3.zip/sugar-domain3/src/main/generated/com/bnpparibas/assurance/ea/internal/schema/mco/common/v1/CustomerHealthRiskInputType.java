
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Risk linked to the health of the customer
 * 			
 * 
 * <p>Java class for CustomerHealthRiskInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomerHealthRiskInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DisbltyDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="DisbltyRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="HandcpIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="SmkngIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="Weight" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MeasureType" minOccurs="0"/&gt;
 *         &lt;element name="Height" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MeasureType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerHealthRiskInputType", propOrder = {
    "disbltyDate",
    "disbltyRate",
    "handcpIndic",
    "smkngIndic",
    "weight",
    "height"
})
public class CustomerHealthRiskInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "DisbltyDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date disbltyDate;
    @XmlElement(name = "DisbltyRate")
    protected Double disbltyRate;
    @XmlElement(name = "HandcpIndic")
    protected String handcpIndic;
    @XmlElement(name = "SmkngIndic")
    protected String smkngIndic;
    @XmlElement(name = "Weight")
    protected MeasureType weight;
    @XmlElement(name = "Height")
    protected MeasureType height;

    /**
     * Default no-arg constructor
     * 
     */
    public CustomerHealthRiskInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CustomerHealthRiskInputType(final Date disbltyDate, final Double disbltyRate, final String handcpIndic, final String smkngIndic, final MeasureType weight, final MeasureType height) {
        this.disbltyDate = disbltyDate;
        this.disbltyRate = disbltyRate;
        this.handcpIndic = handcpIndic;
        this.smkngIndic = smkngIndic;
        this.weight = weight;
        this.height = height;
    }

    /**
     * Gets the value of the disbltyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDisbltyDate() {
        return disbltyDate;
    }

    /**
     * Sets the value of the disbltyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisbltyDate(Date value) {
        this.disbltyDate = value;
    }

    public boolean isSetDisbltyDate() {
        return (this.disbltyDate!= null);
    }

    /**
     * Gets the value of the disbltyRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getDisbltyRate() {
        return disbltyRate;
    }

    /**
     * Sets the value of the disbltyRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setDisbltyRate(Double value) {
        this.disbltyRate = value;
    }

    public boolean isSetDisbltyRate() {
        return (this.disbltyRate!= null);
    }

    /**
     * Gets the value of the handcpIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHandcpIndic() {
        return handcpIndic;
    }

    /**
     * Sets the value of the handcpIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHandcpIndic(String value) {
        this.handcpIndic = value;
    }

    public boolean isSetHandcpIndic() {
        return (this.handcpIndic!= null);
    }

    /**
     * Gets the value of the smkngIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSmkngIndic() {
        return smkngIndic;
    }

    /**
     * Sets the value of the smkngIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSmkngIndic(String value) {
        this.smkngIndic = value;
    }

    public boolean isSetSmkngIndic() {
        return (this.smkngIndic!= null);
    }

    /**
     * Gets the value of the weight property.
     * 
     * @return
     *     possible object is
     *     {@link MeasureType }
     *     
     */
    public MeasureType getWeight() {
        return weight;
    }

    /**
     * Sets the value of the weight property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeasureType }
     *     
     */
    public void setWeight(MeasureType value) {
        this.weight = value;
    }

    public boolean isSetWeight() {
        return (this.weight!= null);
    }

    /**
     * Gets the value of the height property.
     * 
     * @return
     *     possible object is
     *     {@link MeasureType }
     *     
     */
    public MeasureType getHeight() {
        return height;
    }

    /**
     * Sets the value of the height property.
     * 
     * @param value
     *     allowed object is
     *     {@link MeasureType }
     *     
     */
    public void setHeight(MeasureType value) {
        this.height = value;
    }

    public boolean isSetHeight() {
        return (this.height!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("disbltyDate", disbltyDate).add("disbltyRate", disbltyRate).add("handcpIndic", handcpIndic).add("smkngIndic", smkngIndic).add("weight", weight).add("height", height).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(disbltyDate, disbltyRate, handcpIndic, smkngIndic, weight, height);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CustomerHealthRiskInputType o = ((CustomerHealthRiskInputType) other);
        return (((((Objects.equal(disbltyDate, o.disbltyDate)&&Objects.equal(disbltyRate, o.disbltyRate))&&Objects.equal(handcpIndic, o.handcpIndic))&&Objects.equal(smkngIndic, o.smkngIndic))&&Objects.equal(weight, o.weight))&&Objects.equal(height, o.height));
    }

}
