
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on document
 * 			
 * 
 * <p>Java class for DocumentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DocIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentTypeCode"/&gt;
 *         &lt;element name="StatusCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="ValdtyStatusCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ValidityStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MedmType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MediaTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ValdtyStartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ValdtyEndtDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ReciptnIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="ReciptDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="ExpectDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentDataType", propOrder = {
    "docIdntfctn",
    "type",
    "statusCode",
    "effctveDate",
    "valdtyStatusCode",
    "medmType",
    "valdtyStartDate",
    "valdtyEndtDate",
    "reciptnIndic",
    "reciptDate",
    "expectDate"
})
public class DocumentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "DocIdntfctn")
    protected ObjectIdentificationType docIdntfctn;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "StatusCode")
    protected String statusCode;
    @XmlElement(name = "EffctveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date effctveDate;
    @XmlElement(name = "ValdtyStatusCode")
    protected String valdtyStatusCode;
    @XmlElement(name = "MedmType")
    protected String medmType;
    @XmlElement(name = "ValdtyStartDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valdtyStartDate;
    @XmlElement(name = "ValdtyEndtDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valdtyEndtDate;
    @XmlElement(name = "ReciptnIndic")
    protected String reciptnIndic;
    @XmlElement(name = "ReciptDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date reciptDate;
    @XmlElement(name = "ExpectDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date expectDate;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentDataType(final ObjectIdentificationType docIdntfctn, final String type, final String statusCode, final Date effctveDate, final String valdtyStatusCode, final String medmType, final Date valdtyStartDate, final Date valdtyEndtDate, final String reciptnIndic, final Date reciptDate, final Date expectDate) {
        this.docIdntfctn = docIdntfctn;
        this.type = type;
        this.statusCode = statusCode;
        this.effctveDate = effctveDate;
        this.valdtyStatusCode = valdtyStatusCode;
        this.medmType = medmType;
        this.valdtyStartDate = valdtyStartDate;
        this.valdtyEndtDate = valdtyEndtDate;
        this.reciptnIndic = reciptnIndic;
        this.reciptDate = reciptDate;
        this.expectDate = expectDate;
    }

    /**
     * Gets the value of the docIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getDocIdntfctn() {
        return docIdntfctn;
    }

    /**
     * Sets the value of the docIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setDocIdntfctn(ObjectIdentificationType value) {
        this.docIdntfctn = value;
    }

    public boolean isSetDocIdntfctn() {
        return (this.docIdntfctn!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusCode(String value) {
        this.statusCode = value;
    }

    public boolean isSetStatusCode() {
        return (this.statusCode!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the valdtyStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValdtyStatusCode() {
        return valdtyStatusCode;
    }

    /**
     * Sets the value of the valdtyStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValdtyStatusCode(String value) {
        this.valdtyStatusCode = value;
    }

    public boolean isSetValdtyStatusCode() {
        return (this.valdtyStatusCode!= null);
    }

    /**
     * Gets the value of the medmType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedmType() {
        return medmType;
    }

    /**
     * Sets the value of the medmType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedmType(String value) {
        this.medmType = value;
    }

    public boolean isSetMedmType() {
        return (this.medmType!= null);
    }

    /**
     * Gets the value of the valdtyStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValdtyStartDate() {
        return valdtyStartDate;
    }

    /**
     * Sets the value of the valdtyStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValdtyStartDate(Date value) {
        this.valdtyStartDate = value;
    }

    public boolean isSetValdtyStartDate() {
        return (this.valdtyStartDate!= null);
    }

    /**
     * Gets the value of the valdtyEndtDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValdtyEndtDate() {
        return valdtyEndtDate;
    }

    /**
     * Sets the value of the valdtyEndtDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValdtyEndtDate(Date value) {
        this.valdtyEndtDate = value;
    }

    public boolean isSetValdtyEndtDate() {
        return (this.valdtyEndtDate!= null);
    }

    /**
     * Gets the value of the reciptnIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReciptnIndic() {
        return reciptnIndic;
    }

    /**
     * Sets the value of the reciptnIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReciptnIndic(String value) {
        this.reciptnIndic = value;
    }

    public boolean isSetReciptnIndic() {
        return (this.reciptnIndic!= null);
    }

    /**
     * Gets the value of the reciptDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getReciptDate() {
        return reciptDate;
    }

    /**
     * Sets the value of the reciptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReciptDate(Date value) {
        this.reciptDate = value;
    }

    public boolean isSetReciptDate() {
        return (this.reciptDate!= null);
    }

    /**
     * Gets the value of the expectDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getExpectDate() {
        return expectDate;
    }

    /**
     * Sets the value of the expectDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpectDate(Date value) {
        this.expectDate = value;
    }

    public boolean isSetExpectDate() {
        return (this.expectDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("docIdntfctn", docIdntfctn).add("type", type).add("statusCode", statusCode).add("effctveDate", effctveDate).add("valdtyStatusCode", valdtyStatusCode).add("medmType", medmType).add("valdtyStartDate", valdtyStartDate).add("valdtyEndtDate", valdtyEndtDate).add("reciptnIndic", reciptnIndic).add("reciptDate", reciptDate).add("expectDate", expectDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(docIdntfctn, type, statusCode, effctveDate, valdtyStatusCode, medmType, valdtyStartDate, valdtyEndtDate, reciptnIndic, reciptDate, expectDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentDataType o = ((DocumentDataType) other);
        return ((((((((((Objects.equal(docIdntfctn, o.docIdntfctn)&&Objects.equal(type, o.type))&&Objects.equal(statusCode, o.statusCode))&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(valdtyStatusCode, o.valdtyStatusCode))&&Objects.equal(medmType, o.medmType))&&Objects.equal(valdtyStartDate, o.valdtyStartDate))&&Objects.equal(valdtyEndtDate, o.valdtyEndtDate))&&Objects.equal(reciptnIndic, o.reciptnIndic))&&Objects.equal(reciptDate, o.reciptDate))&&Objects.equal(expectDate, o.expectDate));
    }

}
