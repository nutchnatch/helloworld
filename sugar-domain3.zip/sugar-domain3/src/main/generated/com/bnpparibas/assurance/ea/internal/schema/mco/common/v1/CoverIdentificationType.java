
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information about the identification
 * 				of a cover
 * 			
 * 
 * <p>Java class for CoverIdentificationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverIdentificationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PdctCovId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="PdctPckgeId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="PdctCovPlanId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverIdentificationType", propOrder = {
    "pdctCovId",
    "pdctPckgeId",
    "pdctCovPlanId"
})
public class CoverIdentificationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PdctCovId", required = true)
    protected String pdctCovId;
    @XmlElement(name = "PdctPckgeId")
    protected String pdctPckgeId;
    @XmlElement(name = "PdctCovPlanId")
    protected String pdctCovPlanId;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverIdentificationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverIdentificationType(final String pdctCovId, final String pdctPckgeId, final String pdctCovPlanId) {
        this.pdctCovId = pdctCovId;
        this.pdctPckgeId = pdctPckgeId;
        this.pdctCovPlanId = pdctCovPlanId;
    }

    /**
     * Gets the value of the pdctCovId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctCovId() {
        return pdctCovId;
    }

    /**
     * Sets the value of the pdctCovId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctCovId(String value) {
        this.pdctCovId = value;
    }

    public boolean isSetPdctCovId() {
        return (this.pdctCovId!= null);
    }

    /**
     * Gets the value of the pdctPckgeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctPckgeId() {
        return pdctPckgeId;
    }

    /**
     * Sets the value of the pdctPckgeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctPckgeId(String value) {
        this.pdctPckgeId = value;
    }

    public boolean isSetPdctPckgeId() {
        return (this.pdctPckgeId!= null);
    }

    /**
     * Gets the value of the pdctCovPlanId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctCovPlanId() {
        return pdctCovPlanId;
    }

    /**
     * Sets the value of the pdctCovPlanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctCovPlanId(String value) {
        this.pdctCovPlanId = value;
    }

    public boolean isSetPdctCovPlanId() {
        return (this.pdctCovPlanId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdctCovId", pdctCovId).add("pdctPckgeId", pdctPckgeId).add("pdctCovPlanId", pdctCovPlanId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdctCovId, pdctPckgeId, pdctCovPlanId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverIdentificationType o = ((CoverIdentificationType) other);
        return ((Objects.equal(pdctCovId, o.pdctCovId)&&Objects.equal(pdctPckgeId, o.pdctPckgeId))&&Objects.equal(pdctCovPlanId, o.pdctCovPlanId));
    }

}
