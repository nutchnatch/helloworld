
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Beneficiary claim benefit payment type
 * 			
 * 
 * <p>Java class for BeneficiaryClaimBenefitPaymentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneficiaryClaimBenefitPaymentType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CovrdPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationStatusType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationPaymentInstrumentDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneficiaryClaimBenefitPaymentType", propOrder = {
    "covrdPrd",
    "paymntAmnt",
    "status",
    "paymntData"
})
public class BeneficiaryClaimBenefitPaymentType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CovrdPrd")
    protected DatePeriodType covrdPrd;
    @XmlElement(name = "PaymntAmnt")
    protected CurrencyAndAmountType paymntAmnt;
    @XmlElement(name = "Status")
    protected OperationStatusType status;
    @XmlElement(name = "PaymntData")
    protected OperationPaymentInstrumentDataType paymntData;

    /**
     * Default no-arg constructor
     * 
     */
    public BeneficiaryClaimBenefitPaymentType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BeneficiaryClaimBenefitPaymentType(final DatePeriodType covrdPrd, final CurrencyAndAmountType paymntAmnt, final OperationStatusType status, final OperationPaymentInstrumentDataType paymntData) {
        this.covrdPrd = covrdPrd;
        this.paymntAmnt = paymntAmnt;
        this.status = status;
        this.paymntData = paymntData;
    }

    /**
     * Gets the value of the covrdPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getCovrdPrd() {
        return covrdPrd;
    }

    /**
     * Sets the value of the covrdPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setCovrdPrd(DatePeriodType value) {
        this.covrdPrd = value;
    }

    public boolean isSetCovrdPrd() {
        return (this.covrdPrd!= null);
    }

    /**
     * Gets the value of the paymntAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPaymntAmnt() {
        return paymntAmnt;
    }

    /**
     * Sets the value of the paymntAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPaymntAmnt(CurrencyAndAmountType value) {
        this.paymntAmnt = value;
    }

    public boolean isSetPaymntAmnt() {
        return (this.paymntAmnt!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link OperationStatusType }
     *     
     */
    public OperationStatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationStatusType }
     *     
     */
    public void setStatus(OperationStatusType value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the paymntData property.
     * 
     * @return
     *     possible object is
     *     {@link OperationPaymentInstrumentDataType }
     *     
     */
    public OperationPaymentInstrumentDataType getPaymntData() {
        return paymntData;
    }

    /**
     * Sets the value of the paymntData property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationPaymentInstrumentDataType }
     *     
     */
    public void setPaymntData(OperationPaymentInstrumentDataType value) {
        this.paymntData = value;
    }

    public boolean isSetPaymntData() {
        return (this.paymntData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("covrdPrd", covrdPrd).add("paymntAmnt", paymntAmnt).add("status", status).add("paymntData", paymntData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(covrdPrd, paymntAmnt, status, paymntData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BeneficiaryClaimBenefitPaymentType o = ((BeneficiaryClaimBenefitPaymentType) other);
        return (((Objects.equal(covrdPrd, o.covrdPrd)&&Objects.equal(paymntAmnt, o.paymntAmnt))&&Objects.equal(status, o.status))&&Objects.equal(paymntData, o.paymntData));
    }

}
