
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on payment banking refrences :
 * 				Bank Account with status and Payment Card
 * 			
 * 
 * <p>Java class for BankingReferenceWithStatusType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BankingReferenceWithStatusType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Acct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankAccountIdentificationWithStatusType" minOccurs="0"/&gt;
 *         &lt;element name="Card" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentCardDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BankingReferenceWithStatusType", propOrder = {
    "acct",
    "card"
})
public class BankingReferenceWithStatusType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Acct")
    protected BankAccountIdentificationWithStatusType acct;
    @XmlElement(name = "Card")
    protected PaymentCardDataType card;

    /**
     * Default no-arg constructor
     * 
     */
    public BankingReferenceWithStatusType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BankingReferenceWithStatusType(final BankAccountIdentificationWithStatusType acct, final PaymentCardDataType card) {
        this.acct = acct;
        this.card = card;
    }

    /**
     * Gets the value of the acct property.
     * 
     * @return
     *     possible object is
     *     {@link BankAccountIdentificationWithStatusType }
     *     
     */
    public BankAccountIdentificationWithStatusType getAcct() {
        return acct;
    }

    /**
     * Sets the value of the acct property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankAccountIdentificationWithStatusType }
     *     
     */
    public void setAcct(BankAccountIdentificationWithStatusType value) {
        this.acct = value;
    }

    public boolean isSetAcct() {
        return (this.acct!= null);
    }

    /**
     * Gets the value of the card property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentCardDataType }
     *     
     */
    public PaymentCardDataType getCard() {
        return card;
    }

    /**
     * Sets the value of the card property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentCardDataType }
     *     
     */
    public void setCard(PaymentCardDataType value) {
        this.card = value;
    }

    public boolean isSetCard() {
        return (this.card!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("acct", acct).add("card", card).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(acct, card);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BankingReferenceWithStatusType o = ((BankingReferenceWithStatusType) other);
        return (Objects.equal(acct, o.acct)&&Objects.equal(card, o.card));
    }

}
