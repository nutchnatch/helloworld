
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on distribution
 * 				authorisation
 * 			
 * 
 * <p>Java class for DistrbutionAuthorizationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DistrbutionAuthorizationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ActvtyStatusCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributionAuthorizationStatusCodeSLN"/&gt;
 *         &lt;element name="ActvtyStatusDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="ComrclDistrbtrLcnseIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN"/&gt;
 *         &lt;element name="ComrclDistrbtrLcnseDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="DistrbtrLegalStatusCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DistributorLegalStatusCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DistrbutionAuthorizationDataType", propOrder = {
    "actvtyStatusCode",
    "actvtyStatusDate",
    "comrclDistrbtrLcnseIndic",
    "comrclDistrbtrLcnseDate",
    "distrbtrLegalStatusCode"
})
public class DistrbutionAuthorizationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ActvtyStatusCode", required = true)
    protected String actvtyStatusCode;
    @XmlElement(name = "ActvtyStatusDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date actvtyStatusDate;
    @XmlElement(name = "ComrclDistrbtrLcnseIndic", required = true)
    protected String comrclDistrbtrLcnseIndic;
    @XmlElement(name = "ComrclDistrbtrLcnseDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date comrclDistrbtrLcnseDate;
    @XmlElement(name = "DistrbtrLegalStatusCode", required = true)
    protected String distrbtrLegalStatusCode;

    /**
     * Default no-arg constructor
     * 
     */
    public DistrbutionAuthorizationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DistrbutionAuthorizationDataType(final String actvtyStatusCode, final Date actvtyStatusDate, final String comrclDistrbtrLcnseIndic, final Date comrclDistrbtrLcnseDate, final String distrbtrLegalStatusCode) {
        this.actvtyStatusCode = actvtyStatusCode;
        this.actvtyStatusDate = actvtyStatusDate;
        this.comrclDistrbtrLcnseIndic = comrclDistrbtrLcnseIndic;
        this.comrclDistrbtrLcnseDate = comrclDistrbtrLcnseDate;
        this.distrbtrLegalStatusCode = distrbtrLegalStatusCode;
    }

    /**
     * Gets the value of the actvtyStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActvtyStatusCode() {
        return actvtyStatusCode;
    }

    /**
     * Sets the value of the actvtyStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActvtyStatusCode(String value) {
        this.actvtyStatusCode = value;
    }

    public boolean isSetActvtyStatusCode() {
        return (this.actvtyStatusCode!= null);
    }

    /**
     * Gets the value of the actvtyStatusDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getActvtyStatusDate() {
        return actvtyStatusDate;
    }

    /**
     * Sets the value of the actvtyStatusDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActvtyStatusDate(Date value) {
        this.actvtyStatusDate = value;
    }

    public boolean isSetActvtyStatusDate() {
        return (this.actvtyStatusDate!= null);
    }

    /**
     * Gets the value of the comrclDistrbtrLcnseIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComrclDistrbtrLcnseIndic() {
        return comrclDistrbtrLcnseIndic;
    }

    /**
     * Sets the value of the comrclDistrbtrLcnseIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComrclDistrbtrLcnseIndic(String value) {
        this.comrclDistrbtrLcnseIndic = value;
    }

    public boolean isSetComrclDistrbtrLcnseIndic() {
        return (this.comrclDistrbtrLcnseIndic!= null);
    }

    /**
     * Gets the value of the comrclDistrbtrLcnseDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getComrclDistrbtrLcnseDate() {
        return comrclDistrbtrLcnseDate;
    }

    /**
     * Sets the value of the comrclDistrbtrLcnseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComrclDistrbtrLcnseDate(Date value) {
        this.comrclDistrbtrLcnseDate = value;
    }

    public boolean isSetComrclDistrbtrLcnseDate() {
        return (this.comrclDistrbtrLcnseDate!= null);
    }

    /**
     * Gets the value of the distrbtrLegalStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDistrbtrLegalStatusCode() {
        return distrbtrLegalStatusCode;
    }

    /**
     * Sets the value of the distrbtrLegalStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDistrbtrLegalStatusCode(String value) {
        this.distrbtrLegalStatusCode = value;
    }

    public boolean isSetDistrbtrLegalStatusCode() {
        return (this.distrbtrLegalStatusCode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("actvtyStatusCode", actvtyStatusCode).add("actvtyStatusDate", actvtyStatusDate).add("comrclDistrbtrLcnseIndic", comrclDistrbtrLcnseIndic).add("comrclDistrbtrLcnseDate", comrclDistrbtrLcnseDate).add("distrbtrLegalStatusCode", distrbtrLegalStatusCode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(actvtyStatusCode, actvtyStatusDate, comrclDistrbtrLcnseIndic, comrclDistrbtrLcnseDate, distrbtrLegalStatusCode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DistrbutionAuthorizationDataType o = ((DistrbutionAuthorizationDataType) other);
        return ((((Objects.equal(actvtyStatusCode, o.actvtyStatusCode)&&Objects.equal(actvtyStatusDate, o.actvtyStatusDate))&&Objects.equal(comrclDistrbtrLcnseIndic, o.comrclDistrbtrLcnseIndic))&&Objects.equal(comrclDistrbtrLcnseDate, o.comrclDistrbtrLcnseDate))&&Objects.equal(distrbtrLegalStatusCode, o.distrbtrLegalStatusCode));
    }

}
