
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage sales and after sales operations
 * 				requests for cash bank account periodic deposit
 * 			
 * 
 * <p>Java class for CashBankAccountPeriodicDepositInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountPeriodicDepositInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeSchedlrIdntcn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="SchedlrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CashBankAccountPeriodicDepositDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentMethodWithPayerInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountPeriodicDepositInputType", propOrder = {
    "opeSchedlrIdntcn",
    "schedlrData",
    "paymntData"
})
public class CashBankAccountPeriodicDepositInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeSchedlrIdntcn")
    protected ObjectIdentificationType opeSchedlrIdntcn;
    @XmlElement(name = "SchedlrData")
    protected CashBankAccountPeriodicDepositDataInputType schedlrData;
    @XmlElement(name = "PaymntData")
    protected PaymentMethodWithPayerInputType paymntData;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountPeriodicDepositInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountPeriodicDepositInputType(final ObjectIdentificationType opeSchedlrIdntcn, final CashBankAccountPeriodicDepositDataInputType schedlrData, final PaymentMethodWithPayerInputType paymntData) {
        this.opeSchedlrIdntcn = opeSchedlrIdntcn;
        this.schedlrData = schedlrData;
        this.paymntData = paymntData;
    }

    /**
     * Gets the value of the opeSchedlrIdntcn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getOpeSchedlrIdntcn() {
        return opeSchedlrIdntcn;
    }

    /**
     * Sets the value of the opeSchedlrIdntcn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setOpeSchedlrIdntcn(ObjectIdentificationType value) {
        this.opeSchedlrIdntcn = value;
    }

    public boolean isSetOpeSchedlrIdntcn() {
        return (this.opeSchedlrIdntcn!= null);
    }

    /**
     * Gets the value of the schedlrData property.
     * 
     * @return
     *     possible object is
     *     {@link CashBankAccountPeriodicDepositDataInputType }
     *     
     */
    public CashBankAccountPeriodicDepositDataInputType getSchedlrData() {
        return schedlrData;
    }

    /**
     * Sets the value of the schedlrData property.
     * 
     * @param value
     *     allowed object is
     *     {@link CashBankAccountPeriodicDepositDataInputType }
     *     
     */
    public void setSchedlrData(CashBankAccountPeriodicDepositDataInputType value) {
        this.schedlrData = value;
    }

    public boolean isSetSchedlrData() {
        return (this.schedlrData!= null);
    }

    /**
     * Gets the value of the paymntData property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodWithPayerInputType }
     *     
     */
    public PaymentMethodWithPayerInputType getPaymntData() {
        return paymntData;
    }

    /**
     * Sets the value of the paymntData property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodWithPayerInputType }
     *     
     */
    public void setPaymntData(PaymentMethodWithPayerInputType value) {
        this.paymntData = value;
    }

    public boolean isSetPaymntData() {
        return (this.paymntData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeSchedlrIdntcn", opeSchedlrIdntcn).add("schedlrData", schedlrData).add("paymntData", paymntData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeSchedlrIdntcn, schedlrData, paymntData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountPeriodicDepositInputType o = ((CashBankAccountPeriodicDepositInputType) other);
        return ((Objects.equal(opeSchedlrIdntcn, o.opeSchedlrIdntcn)&&Objects.equal(schedlrData, o.schedlrData))&&Objects.equal(paymntData, o.paymntData));
    }

}
