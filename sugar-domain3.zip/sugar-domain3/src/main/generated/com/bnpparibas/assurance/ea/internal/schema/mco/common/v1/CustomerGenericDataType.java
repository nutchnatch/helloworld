
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Customer generic data  
 * 
 * <p>Java class for CustomerGenericDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomerGenericDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LegalStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalPersonalityCodeSLN"/&gt;
 *         &lt;element name="CustCtgory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsuranceCustomerCategoryCode" minOccurs="0"/&gt;
 *         &lt;element name="LegalCapactyIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalCapacityIndicatorCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="LegalCapactyMotiv" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalCapacityMotiveCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AnonymtyIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="CollbrtrIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerGenericDataType", propOrder = {
    "legalStatus",
    "custCtgory",
    "legalCapactyIndic",
    "legalCapactyMotiv",
    "anonymtyIndic",
    "collbrtrIndic"
})
public class CustomerGenericDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "LegalStatus", required = true)
    protected String legalStatus;
    @XmlElement(name = "CustCtgory")
    protected String custCtgory;
    @XmlElement(name = "LegalCapactyIndic")
    protected String legalCapactyIndic;
    @XmlElement(name = "LegalCapactyMotiv")
    protected String legalCapactyMotiv;
    @XmlElement(name = "AnonymtyIndic")
    protected String anonymtyIndic;
    @XmlElement(name = "CollbrtrIndic")
    protected String collbrtrIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public CustomerGenericDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CustomerGenericDataType(final String legalStatus, final String custCtgory, final String legalCapactyIndic, final String legalCapactyMotiv, final String anonymtyIndic, final String collbrtrIndic) {
        this.legalStatus = legalStatus;
        this.custCtgory = custCtgory;
        this.legalCapactyIndic = legalCapactyIndic;
        this.legalCapactyMotiv = legalCapactyMotiv;
        this.anonymtyIndic = anonymtyIndic;
        this.collbrtrIndic = collbrtrIndic;
    }

    /**
     * Gets the value of the legalStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalStatus() {
        return legalStatus;
    }

    /**
     * Sets the value of the legalStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalStatus(String value) {
        this.legalStatus = value;
    }

    public boolean isSetLegalStatus() {
        return (this.legalStatus!= null);
    }

    /**
     * Gets the value of the custCtgory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustCtgory() {
        return custCtgory;
    }

    /**
     * Sets the value of the custCtgory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustCtgory(String value) {
        this.custCtgory = value;
    }

    public boolean isSetCustCtgory() {
        return (this.custCtgory!= null);
    }

    /**
     * Gets the value of the legalCapactyIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalCapactyIndic() {
        return legalCapactyIndic;
    }

    /**
     * Sets the value of the legalCapactyIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalCapactyIndic(String value) {
        this.legalCapactyIndic = value;
    }

    public boolean isSetLegalCapactyIndic() {
        return (this.legalCapactyIndic!= null);
    }

    /**
     * Gets the value of the legalCapactyMotiv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalCapactyMotiv() {
        return legalCapactyMotiv;
    }

    /**
     * Sets the value of the legalCapactyMotiv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalCapactyMotiv(String value) {
        this.legalCapactyMotiv = value;
    }

    public boolean isSetLegalCapactyMotiv() {
        return (this.legalCapactyMotiv!= null);
    }

    /**
     * Gets the value of the anonymtyIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnonymtyIndic() {
        return anonymtyIndic;
    }

    /**
     * Sets the value of the anonymtyIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnonymtyIndic(String value) {
        this.anonymtyIndic = value;
    }

    public boolean isSetAnonymtyIndic() {
        return (this.anonymtyIndic!= null);
    }

    /**
     * Gets the value of the collbrtrIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollbrtrIndic() {
        return collbrtrIndic;
    }

    /**
     * Sets the value of the collbrtrIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollbrtrIndic(String value) {
        this.collbrtrIndic = value;
    }

    public boolean isSetCollbrtrIndic() {
        return (this.collbrtrIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("legalStatus", legalStatus).add("custCtgory", custCtgory).add("legalCapactyIndic", legalCapactyIndic).add("legalCapactyMotiv", legalCapactyMotiv).add("anonymtyIndic", anonymtyIndic).add("collbrtrIndic", collbrtrIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(legalStatus, custCtgory, legalCapactyIndic, legalCapactyMotiv, anonymtyIndic, collbrtrIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CustomerGenericDataType o = ((CustomerGenericDataType) other);
        return (((((Objects.equal(legalStatus, o.legalStatus)&&Objects.equal(custCtgory, o.custCtgory))&&Objects.equal(legalCapactyIndic, o.legalCapactyIndic))&&Objects.equal(legalCapactyMotiv, o.legalCapactyMotiv))&&Objects.equal(anonymtyIndic, o.anonymtyIndic))&&Objects.equal(collbrtrIndic, o.collbrtrIndic));
    }

}
