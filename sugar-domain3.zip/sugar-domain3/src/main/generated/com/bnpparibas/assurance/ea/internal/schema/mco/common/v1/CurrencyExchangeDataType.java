
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 *  Exchange between two currencies
 * 
 * <p>Java class for CurrencyExchangeDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CurrencyExchangeDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UnitCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="QuotdCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="ExchngeRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType"/&gt;
 *         &lt;element name="FixngDateTime" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CurrencyExchangeDataType", propOrder = {
    "unitCurr",
    "quotdCurr",
    "exchngeRate",
    "fixngDateTime"
})
public class CurrencyExchangeDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "UnitCurr", required = true)
    protected String unitCurr;
    @XmlElement(name = "QuotdCurr", required = true)
    protected String quotdCurr;
    @XmlElement(name = "ExchngeRate")
    protected double exchngeRate;
    @XmlElement(name = "FixngDateTime", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date fixngDateTime;

    /**
     * Default no-arg constructor
     * 
     */
    public CurrencyExchangeDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CurrencyExchangeDataType(final String unitCurr, final String quotdCurr, final double exchngeRate, final Date fixngDateTime) {
        this.unitCurr = unitCurr;
        this.quotdCurr = quotdCurr;
        this.exchngeRate = exchngeRate;
        this.fixngDateTime = fixngDateTime;
    }

    /**
     * Gets the value of the unitCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnitCurr() {
        return unitCurr;
    }

    /**
     * Sets the value of the unitCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnitCurr(String value) {
        this.unitCurr = value;
    }

    public boolean isSetUnitCurr() {
        return (this.unitCurr!= null);
    }

    /**
     * Gets the value of the quotdCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotdCurr() {
        return quotdCurr;
    }

    /**
     * Sets the value of the quotdCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotdCurr(String value) {
        this.quotdCurr = value;
    }

    public boolean isSetQuotdCurr() {
        return (this.quotdCurr!= null);
    }

    /**
     * Gets the value of the exchngeRate property.
     * 
     */
    public double getExchngeRate() {
        return exchngeRate;
    }

    /**
     * Sets the value of the exchngeRate property.
     * 
     */
    public void setExchngeRate(double value) {
        this.exchngeRate = value;
    }

    public boolean isSetExchngeRate() {
        return true;
    }

    /**
     * Gets the value of the fixngDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getFixngDateTime() {
        return fixngDateTime;
    }

    /**
     * Sets the value of the fixngDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFixngDateTime(Date value) {
        this.fixngDateTime = value;
    }

    public boolean isSetFixngDateTime() {
        return (this.fixngDateTime!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("unitCurr", unitCurr).add("quotdCurr", quotdCurr).add("exchngeRate", exchngeRate).add("fixngDateTime", fixngDateTime).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(unitCurr, quotdCurr, exchngeRate, fixngDateTime);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CurrencyExchangeDataType o = ((CurrencyExchangeDataType) other);
        return (((Objects.equal(unitCurr, o.unitCurr)&&Objects.equal(quotdCurr, o.quotdCurr))&&Objects.equal(exchngeRate, o.exchngeRate))&&Objects.equal(fixngDateTime, o.fixngDateTime));
    }

}
