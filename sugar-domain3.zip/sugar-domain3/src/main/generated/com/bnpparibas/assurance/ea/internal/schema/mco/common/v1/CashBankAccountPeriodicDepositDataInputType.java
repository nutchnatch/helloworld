
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage specific data on regular deposit
 * 				operation requests linked to a cash bank account
 * 			
 * 
 * <p>Java class for CashBankAccountPeriodicDepositDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountPeriodicDepositDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountPeriodicDepositDataInputType", propOrder = {
    "type",
    "fqcy",
    "amnt",
    "applctnPrd"
})
public class CashBankAccountPeriodicDepositDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "Fqcy")
    protected String fqcy;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "ApplctnPrd")
    protected OptionalDatePeriodType applctnPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountPeriodicDepositDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountPeriodicDepositDataInputType(final String type, final String fqcy, final CurrencyAndAmountType amnt, final OptionalDatePeriodType applctnPrd) {
        this.type = type;
        this.fqcy = fqcy;
        this.amnt = amnt;
        this.applctnPrd = applctnPrd;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public OptionalDatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public void setApplctnPrd(OptionalDatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("fqcy", fqcy).add("amnt", amnt).add("applctnPrd", applctnPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, fqcy, amnt, applctnPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountPeriodicDepositDataInputType o = ((CashBankAccountPeriodicDepositDataInputType) other);
        return (((Objects.equal(type, o.type)&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(amnt, o.amnt))&&Objects.equal(applctnPrd, o.applctnPrd));
    }

}
