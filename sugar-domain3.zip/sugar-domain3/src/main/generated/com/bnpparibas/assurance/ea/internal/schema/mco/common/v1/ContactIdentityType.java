
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * identity of a contact
 * 
 * <p>Java class for ContactIdentityType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ContactIdentityType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Title" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CivilityUsualNamingCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="LastName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="FrstName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Cvlty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MainCivilityCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContactIdentityType", propOrder = {
    "title",
    "lastName",
    "frstName",
    "cvlty"
})
public class ContactIdentityType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Title")
    protected String title;
    @XmlElement(name = "LastName")
    protected String lastName;
    @XmlElement(name = "FrstName")
    protected List<String> frstName;
    @XmlElement(name = "Cvlty")
    protected String cvlty;

    /**
     * Default no-arg constructor
     * 
     */
    public ContactIdentityType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ContactIdentityType(final String title, final String lastName, final List<String> frstName, final String cvlty) {
        this.title = title;
        this.lastName = lastName;
        this.frstName = frstName;
        this.cvlty = cvlty;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    public boolean isSetTitle() {
        return (this.title!= null);
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    public boolean isSetLastName() {
        return (this.lastName!= null);
    }

    /**
     * Gets the value of the frstName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the frstName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFrstName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFrstName() {
        if (frstName == null) {
            frstName = new ArrayList<String>();
        }
        return this.frstName;
    }

    public boolean isSetFrstName() {
        return ((this.frstName!= null)&&(!this.frstName.isEmpty()));
    }

    public void unsetFrstName() {
        this.frstName = null;
    }

    /**
     * Gets the value of the cvlty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCvlty() {
        return cvlty;
    }

    /**
     * Sets the value of the cvlty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCvlty(String value) {
        this.cvlty = value;
    }

    public boolean isSetCvlty() {
        return (this.cvlty!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("title", title).add("lastName", lastName).add("frstName", frstName).add("cvlty", cvlty).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(title, lastName, frstName, cvlty);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ContactIdentityType o = ((ContactIdentityType) other);
        return (((Objects.equal(title, o.title)&&Objects.equal(lastName, o.lastName))&&Objects.equal(frstName, o.frstName))&&Objects.equal(cvlty, o.cvlty));
    }

}
