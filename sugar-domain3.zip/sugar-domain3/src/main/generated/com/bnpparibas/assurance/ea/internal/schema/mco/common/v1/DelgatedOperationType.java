
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on the delegated
 * 				operation types
 * 			
 * 
 * <p>Java class for DelgatedOperationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DelgatedOperationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="Threshold" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ValueDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DelgatedOperationType", propOrder = {
    "opeType",
    "threshold"
})
public class DelgatedOperationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeType", required = true)
    protected String opeType;
    @XmlElement(name = "Threshold")
    protected List<ValueDataType> threshold;

    /**
     * Default no-arg constructor
     * 
     */
    public DelgatedOperationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DelgatedOperationType(final String opeType, final List<ValueDataType> threshold) {
        this.opeType = opeType;
        this.threshold = threshold;
    }

    /**
     * Gets the value of the opeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeType() {
        return opeType;
    }

    /**
     * Sets the value of the opeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeType(String value) {
        this.opeType = value;
    }

    public boolean isSetOpeType() {
        return (this.opeType!= null);
    }

    /**
     * Gets the value of the threshold property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the threshold property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getThreshold().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValueDataType }
     * 
     * 
     */
    public List<ValueDataType> getThreshold() {
        if (threshold == null) {
            threshold = new ArrayList<ValueDataType>();
        }
        return this.threshold;
    }

    public boolean isSetThreshold() {
        return ((this.threshold!= null)&&(!this.threshold.isEmpty()));
    }

    public void unsetThreshold() {
        this.threshold = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeType", opeType).add("threshold", threshold).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeType, threshold);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DelgatedOperationType o = ((DelgatedOperationType) other);
        return (Objects.equal(opeType, o.opeType)&&Objects.equal(threshold, o.threshold));
    }

}
