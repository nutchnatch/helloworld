
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 *  Type to manage the question at declaration level
 * 			
 * 
 * <p>Java class for ClaimDeclarationQuestionnaryDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimDeclarationQuestionnaryDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Ctgory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="Lbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType"/&gt;
 *         &lt;element name="RspnseIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="RspnseData" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *                   &lt;element name="Lbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ApplctnPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimDeclarationQuestionnaryDataType", propOrder = {
    "ctgory",
    "lbl",
    "rspnseIndic",
    "rspnseData",
    "applctnPrd"
})
public class ClaimDeclarationQuestionnaryDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Ctgory", required = true)
    protected String ctgory;
    @XmlElement(name = "Lbl", required = true)
    protected String lbl;
    @XmlElement(name = "RspnseIndic")
    protected String rspnseIndic;
    @XmlElement(name = "RspnseData")
    protected List<ClaimDeclarationQuestionnaryDataType.RspnseData> rspnseData;
    @XmlElement(name = "ApplctnPrd")
    protected DatePeriodType applctnPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimDeclarationQuestionnaryDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimDeclarationQuestionnaryDataType(final String ctgory, final String lbl, final String rspnseIndic, final List<ClaimDeclarationQuestionnaryDataType.RspnseData> rspnseData, final DatePeriodType applctnPrd) {
        this.ctgory = ctgory;
        this.lbl = lbl;
        this.rspnseIndic = rspnseIndic;
        this.rspnseData = rspnseData;
        this.applctnPrd = applctnPrd;
    }

    /**
     * Gets the value of the ctgory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtgory() {
        return ctgory;
    }

    /**
     * Sets the value of the ctgory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtgory(String value) {
        this.ctgory = value;
    }

    public boolean isSetCtgory() {
        return (this.ctgory!= null);
    }

    /**
     * Gets the value of the lbl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLbl() {
        return lbl;
    }

    /**
     * Sets the value of the lbl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLbl(String value) {
        this.lbl = value;
    }

    public boolean isSetLbl() {
        return (this.lbl!= null);
    }

    /**
     * Gets the value of the rspnseIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRspnseIndic() {
        return rspnseIndic;
    }

    /**
     * Sets the value of the rspnseIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRspnseIndic(String value) {
        this.rspnseIndic = value;
    }

    public boolean isSetRspnseIndic() {
        return (this.rspnseIndic!= null);
    }

    /**
     * Gets the value of the rspnseData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rspnseData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRspnseData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClaimDeclarationQuestionnaryDataType.RspnseData }
     * 
     * 
     */
    public List<ClaimDeclarationQuestionnaryDataType.RspnseData> getRspnseData() {
        if (rspnseData == null) {
            rspnseData = new ArrayList<ClaimDeclarationQuestionnaryDataType.RspnseData>();
        }
        return this.rspnseData;
    }

    public boolean isSetRspnseData() {
        return ((this.rspnseData!= null)&&(!this.rspnseData.isEmpty()));
    }

    public void unsetRspnseData() {
        this.rspnseData = null;
    }

    /**
     * Gets the value of the applctnPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getApplctnPrd() {
        return applctnPrd;
    }

    /**
     * Sets the value of the applctnPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setApplctnPrd(DatePeriodType value) {
        this.applctnPrd = value;
    }

    public boolean isSetApplctnPrd() {
        return (this.applctnPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("ctgory", ctgory).add("lbl", lbl).add("rspnseIndic", rspnseIndic).add("rspnseData", rspnseData).add("applctnPrd", applctnPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(ctgory, lbl, rspnseIndic, rspnseData, applctnPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimDeclarationQuestionnaryDataType o = ((ClaimDeclarationQuestionnaryDataType) other);
        return ((((Objects.equal(ctgory, o.ctgory)&&Objects.equal(lbl, o.lbl))&&Objects.equal(rspnseIndic, o.rspnseIndic))&&Objects.equal(rspnseData, o.rspnseData))&&Objects.equal(applctnPrd, o.applctnPrd));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
     *         &lt;element name="Lbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "id",
        "lbl"
    })
    public static class RspnseData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Id", required = true)
        protected String id;
        @XmlElement(name = "Lbl")
        protected String lbl;

        /**
         * Default no-arg constructor
         * 
         */
        public RspnseData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public RspnseData(final String id, final String lbl) {
            this.id = id;
            this.lbl = lbl;
        }

        /**
         * Gets the value of the id property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getId() {
            return id;
        }

        /**
         * Sets the value of the id property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setId(String value) {
            this.id = value;
        }

        public boolean isSetId() {
            return (this.id!= null);
        }

        /**
         * Gets the value of the lbl property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLbl() {
            return lbl;
        }

        /**
         * Sets the value of the lbl property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLbl(String value) {
            this.lbl = value;
        }

        public boolean isSetLbl() {
            return (this.lbl!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("id", id).add("lbl", lbl).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(id, lbl);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final ClaimDeclarationQuestionnaryDataType.RspnseData o = ((ClaimDeclarationQuestionnaryDataType.RspnseData) other);
            return (Objects.equal(id, o.id)&&Objects.equal(lbl, o.lbl));
        }

    }

}
