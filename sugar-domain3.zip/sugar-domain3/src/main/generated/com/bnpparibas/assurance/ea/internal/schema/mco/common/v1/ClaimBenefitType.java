
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Claim benefit type
 * 
 * <p>Java class for ClaimBenefitType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimBenefitType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimBenefitStatusType" minOccurs="0"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimBenefitDataType"/&gt;
 *         &lt;element name="BenfciaryClaimBnft" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClaimBenefitType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimBenefitType", propOrder = {
    "id",
    "status",
    "data",
    "benfciaryClaimBnft"
})
public class ClaimBenefitType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id", required = true)
    protected String id;
    @XmlElement(name = "Status")
    protected ClaimBenefitStatusType status;
    @XmlElement(name = "Data", required = true)
    protected ClaimBenefitDataType data;
    @XmlElement(name = "BenfciaryClaimBnft", required = true)
    protected List<BeneficiaryClaimBenefitType> benfciaryClaimBnft;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimBenefitType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimBenefitType(final String id, final ClaimBenefitStatusType status, final ClaimBenefitDataType data, final List<BeneficiaryClaimBenefitType> benfciaryClaimBnft) {
        this.id = id;
        this.status = status;
        this.data = data;
        this.benfciaryClaimBnft = benfciaryClaimBnft;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimBenefitStatusType }
     *     
     */
    public ClaimBenefitStatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimBenefitStatusType }
     *     
     */
    public void setStatus(ClaimBenefitStatusType value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link ClaimBenefitDataType }
     *     
     */
    public ClaimBenefitDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaimBenefitDataType }
     *     
     */
    public void setData(ClaimBenefitDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the benfciaryClaimBnft property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the benfciaryClaimBnft property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBenfciaryClaimBnft().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BeneficiaryClaimBenefitType }
     * 
     * 
     */
    public List<BeneficiaryClaimBenefitType> getBenfciaryClaimBnft() {
        if (benfciaryClaimBnft == null) {
            benfciaryClaimBnft = new ArrayList<BeneficiaryClaimBenefitType>();
        }
        return this.benfciaryClaimBnft;
    }

    public boolean isSetBenfciaryClaimBnft() {
        return ((this.benfciaryClaimBnft!= null)&&(!this.benfciaryClaimBnft.isEmpty()));
    }

    public void unsetBenfciaryClaimBnft() {
        this.benfciaryClaimBnft = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("status", status).add("data", data).add("benfciaryClaimBnft", benfciaryClaimBnft).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, status, data, benfciaryClaimBnft);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimBenefitType o = ((ClaimBenefitType) other);
        return (((Objects.equal(id, o.id)&&Objects.equal(status, o.status))&&Objects.equal(data, o.data))&&Objects.equal(benfciaryClaimBnft, o.benfciaryClaimBnft));
    }

}
