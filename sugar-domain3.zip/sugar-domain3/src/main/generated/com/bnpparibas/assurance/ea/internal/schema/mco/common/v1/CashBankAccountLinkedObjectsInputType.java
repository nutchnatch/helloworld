
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage objects with which a cash bank account
 * 				has dependencies
 * 			
 * 
 * <p>Java class for CashBankAccountLinkedObjectsInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountLinkedObjectsInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CashBankProductSharedDataType" minOccurs="0"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="Cust" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PersonIdentificationAndRoleType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="ComrclOffer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CashBankAccountCommercialOfferInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="CashBnkAcct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CashBankAccountIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountLinkedObjectsInputType", propOrder = {
    "pdct",
    "distrbtr",
    "prdctr",
    "cust",
    "comrclOffer",
    "cashBnkAcct"
})
public class CashBankAccountLinkedObjectsInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct")
    protected CashBankProductSharedDataType pdct;
    @XmlElement(name = "Distrbtr", required = true)
    protected List<PartnerPartyType> distrbtr;
    @XmlElement(name = "Prdctr")
    protected PartyRoleType prdctr;
    @XmlElement(name = "Cust")
    protected List<PersonIdentificationAndRoleType> cust;
    @XmlElement(name = "ComrclOffer")
    protected List<CashBankAccountCommercialOfferInputType> comrclOffer;
    @XmlElement(name = "CashBnkAcct")
    protected CashBankAccountIdentificationType cashBnkAcct;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountLinkedObjectsInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountLinkedObjectsInputType(final CashBankProductSharedDataType pdct, final List<PartnerPartyType> distrbtr, final PartyRoleType prdctr, final List<PersonIdentificationAndRoleType> cust, final List<CashBankAccountCommercialOfferInputType> comrclOffer, final CashBankAccountIdentificationType cashBnkAcct) {
        this.pdct = pdct;
        this.distrbtr = distrbtr;
        this.prdctr = prdctr;
        this.cust = cust;
        this.comrclOffer = comrclOffer;
        this.cashBnkAcct = cashBnkAcct;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link CashBankProductSharedDataType }
     *     
     */
    public CashBankProductSharedDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CashBankProductSharedDataType }
     *     
     */
    public void setPdct(CashBankProductSharedDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the distrbtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDistrbtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getDistrbtr() {
        if (distrbtr == null) {
            distrbtr = new ArrayList<PartnerPartyType>();
        }
        return this.distrbtr;
    }

    public boolean isSetDistrbtr() {
        return ((this.distrbtr!= null)&&(!this.distrbtr.isEmpty()));
    }

    public void unsetDistrbtr() {
        this.distrbtr = null;
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    /**
     * Gets the value of the cust property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cust property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCust().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonIdentificationAndRoleType }
     * 
     * 
     */
    public List<PersonIdentificationAndRoleType> getCust() {
        if (cust == null) {
            cust = new ArrayList<PersonIdentificationAndRoleType>();
        }
        return this.cust;
    }

    public boolean isSetCust() {
        return ((this.cust!= null)&&(!this.cust.isEmpty()));
    }

    public void unsetCust() {
        this.cust = null;
    }

    /**
     * Gets the value of the comrclOffer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comrclOffer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComrclOffer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CashBankAccountCommercialOfferInputType }
     * 
     * 
     */
    public List<CashBankAccountCommercialOfferInputType> getComrclOffer() {
        if (comrclOffer == null) {
            comrclOffer = new ArrayList<CashBankAccountCommercialOfferInputType>();
        }
        return this.comrclOffer;
    }

    public boolean isSetComrclOffer() {
        return ((this.comrclOffer!= null)&&(!this.comrclOffer.isEmpty()));
    }

    public void unsetComrclOffer() {
        this.comrclOffer = null;
    }

    /**
     * Gets the value of the cashBnkAcct property.
     * 
     * @return
     *     possible object is
     *     {@link CashBankAccountIdentificationType }
     *     
     */
    public CashBankAccountIdentificationType getCashBnkAcct() {
        return cashBnkAcct;
    }

    /**
     * Sets the value of the cashBnkAcct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CashBankAccountIdentificationType }
     *     
     */
    public void setCashBnkAcct(CashBankAccountIdentificationType value) {
        this.cashBnkAcct = value;
    }

    public boolean isSetCashBnkAcct() {
        return (this.cashBnkAcct!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("distrbtr", distrbtr).add("prdctr", prdctr).add("cust", cust).add("comrclOffer", comrclOffer).add("cashBnkAcct", cashBnkAcct).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, distrbtr, prdctr, cust, comrclOffer, cashBnkAcct);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountLinkedObjectsInputType o = ((CashBankAccountLinkedObjectsInputType) other);
        return (((((Objects.equal(pdct, o.pdct)&&Objects.equal(distrbtr, o.distrbtr))&&Objects.equal(prdctr, o.prdctr))&&Objects.equal(cust, o.cust))&&Objects.equal(comrclOffer, o.comrclOffer))&&Objects.equal(cashBnkAcct, o.cashBnkAcct));
    }

}
