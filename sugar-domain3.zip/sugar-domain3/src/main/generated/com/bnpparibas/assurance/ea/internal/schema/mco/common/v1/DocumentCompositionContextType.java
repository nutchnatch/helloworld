
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Type which describes the the context linked to a
 * 				composition of a document
 * 			
 * 
 * <p>Java class for DocumentCompositionContextType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentCompositionContextType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ReqIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="ReqData"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Cntry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN"/&gt;
 *                   &lt;element name="Applctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ApplicationComponentCodeSLN"/&gt;
 *                   &lt;element name="ReqDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *                   &lt;element name="RspnseType" minOccurs="0"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;maxLength value="50"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentCompositionContextType", propOrder = {
    "reqIdntfctn",
    "reqData"
})
public class DocumentCompositionContextType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ReqIdntfctn")
    protected IdentificationType reqIdntfctn;
    @XmlElement(name = "ReqData", required = true)
    protected DocumentCompositionContextType.ReqData reqData;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentCompositionContextType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentCompositionContextType(final IdentificationType reqIdntfctn, final DocumentCompositionContextType.ReqData reqData) {
        this.reqIdntfctn = reqIdntfctn;
        this.reqData = reqData;
    }

    /**
     * Gets the value of the reqIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getReqIdntfctn() {
        return reqIdntfctn;
    }

    /**
     * Sets the value of the reqIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setReqIdntfctn(IdentificationType value) {
        this.reqIdntfctn = value;
    }

    public boolean isSetReqIdntfctn() {
        return (this.reqIdntfctn!= null);
    }

    /**
     * Gets the value of the reqData property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentCompositionContextType.ReqData }
     *     
     */
    public DocumentCompositionContextType.ReqData getReqData() {
        return reqData;
    }

    /**
     * Sets the value of the reqData property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentCompositionContextType.ReqData }
     *     
     */
    public void setReqData(DocumentCompositionContextType.ReqData value) {
        this.reqData = value;
    }

    public boolean isSetReqData() {
        return (this.reqData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("reqIdntfctn", reqIdntfctn).add("reqData", reqData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(reqIdntfctn, reqData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentCompositionContextType o = ((DocumentCompositionContextType) other);
        return (Objects.equal(reqIdntfctn, o.reqIdntfctn)&&Objects.equal(reqData, o.reqData));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Cntry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN"/&gt;
     *         &lt;element name="Applctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ApplicationComponentCodeSLN"/&gt;
     *         &lt;element name="ReqDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
     *         &lt;element name="RspnseType" minOccurs="0"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;maxLength value="50"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "cntry",
        "applctn",
        "reqDate",
        "rspnseType"
    })
    public static class ReqData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Cntry", required = true)
        protected String cntry;
        @XmlElement(name = "Applctn", required = true)
        protected String applctn;
        @XmlElement(name = "ReqDate", required = true, type = String.class)
        @XmlJavaTypeAdapter(Adapter1 .class)
        @XmlSchemaType(name = "dateTime")
        protected Date reqDate;
        @XmlElement(name = "RspnseType")
        protected String rspnseType;

        /**
         * Default no-arg constructor
         * 
         */
        public ReqData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public ReqData(final String cntry, final String applctn, final Date reqDate, final String rspnseType) {
            this.cntry = cntry;
            this.applctn = applctn;
            this.reqDate = reqDate;
            this.rspnseType = rspnseType;
        }

        /**
         * Gets the value of the cntry property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCntry() {
            return cntry;
        }

        /**
         * Sets the value of the cntry property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCntry(String value) {
            this.cntry = value;
        }

        public boolean isSetCntry() {
            return (this.cntry!= null);
        }

        /**
         * Gets the value of the applctn property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getApplctn() {
            return applctn;
        }

        /**
         * Sets the value of the applctn property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setApplctn(String value) {
            this.applctn = value;
        }

        public boolean isSetApplctn() {
            return (this.applctn!= null);
        }

        /**
         * Gets the value of the reqDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public Date getReqDate() {
            return reqDate;
        }

        /**
         * Sets the value of the reqDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setReqDate(Date value) {
            this.reqDate = value;
        }

        public boolean isSetReqDate() {
            return (this.reqDate!= null);
        }

        /**
         * Gets the value of the rspnseType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRspnseType() {
            return rspnseType;
        }

        /**
         * Sets the value of the rspnseType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRspnseType(String value) {
            this.rspnseType = value;
        }

        public boolean isSetRspnseType() {
            return (this.rspnseType!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("cntry", cntry).add("applctn", applctn).add("reqDate", reqDate).add("rspnseType", rspnseType).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(cntry, applctn, reqDate, rspnseType);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final DocumentCompositionContextType.ReqData o = ((DocumentCompositionContextType.ReqData) other);
            return (((Objects.equal(cntry, o.cntry)&&Objects.equal(applctn, o.applctn))&&Objects.equal(reqDate, o.reqDate))&&Objects.equal(rspnseType, o.rspnseType));
        }

    }

}
