
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage the data of the empoyee : Employment
 * 				Status, Employer Name and Employment Start and End date
 * 			
 * 
 * <p>Java class for ClaimDeclarationEmploymentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimDeclarationEmploymentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EmplmntStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmploymentStatusCodeSLN"/&gt;
 *         &lt;element name="EmplyrName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="EmplmntPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimDeclarationEmploymentDataType", propOrder = {
    "emplmntStatus",
    "emplyrName",
    "emplmntPrd"
})
public class ClaimDeclarationEmploymentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "EmplmntStatus", required = true)
    protected String emplmntStatus;
    @XmlElement(name = "EmplyrName", required = true)
    protected String emplyrName;
    @XmlElement(name = "EmplmntPrd")
    protected DatePeriodType emplmntPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimDeclarationEmploymentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimDeclarationEmploymentDataType(final String emplmntStatus, final String emplyrName, final DatePeriodType emplmntPrd) {
        this.emplmntStatus = emplmntStatus;
        this.emplyrName = emplyrName;
        this.emplmntPrd = emplmntPrd;
    }

    /**
     * Gets the value of the emplmntStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmplmntStatus() {
        return emplmntStatus;
    }

    /**
     * Sets the value of the emplmntStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmplmntStatus(String value) {
        this.emplmntStatus = value;
    }

    public boolean isSetEmplmntStatus() {
        return (this.emplmntStatus!= null);
    }

    /**
     * Gets the value of the emplyrName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmplyrName() {
        return emplyrName;
    }

    /**
     * Sets the value of the emplyrName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmplyrName(String value) {
        this.emplyrName = value;
    }

    public boolean isSetEmplyrName() {
        return (this.emplyrName!= null);
    }

    /**
     * Gets the value of the emplmntPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getEmplmntPrd() {
        return emplmntPrd;
    }

    /**
     * Sets the value of the emplmntPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setEmplmntPrd(DatePeriodType value) {
        this.emplmntPrd = value;
    }

    public boolean isSetEmplmntPrd() {
        return (this.emplmntPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("emplmntStatus", emplmntStatus).add("emplyrName", emplyrName).add("emplmntPrd", emplmntPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(emplmntStatus, emplyrName, emplmntPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimDeclarationEmploymentDataType o = ((ClaimDeclarationEmploymentDataType) other);
        return ((Objects.equal(emplmntStatus, o.emplmntStatus)&&Objects.equal(emplyrName, o.emplyrName))&&Objects.equal(emplmntPrd, o.emplmntPrd));
    }

}
