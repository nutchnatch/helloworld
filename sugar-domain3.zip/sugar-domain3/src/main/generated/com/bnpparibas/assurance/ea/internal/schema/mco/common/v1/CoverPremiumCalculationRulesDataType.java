
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * CoverPremiumCalculationRulesDataType
 * 			
 * 
 * <p>Java class for CoverPremiumCalculationRulesDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverPremiumCalculationRulesDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CalctnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountCalculationRuleTypeCodeSLN"/&gt;
 *         &lt;element name="PremPricingParam" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PremiumPricingParameterCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FixdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="FixdRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *         &lt;element name="RatePerAge" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="InsrdMinAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
 *                   &lt;element name="InsrdMaxAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
 *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *                   &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RatePerAmnt" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="InsrdMinAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *                   &lt;element name="InsrdMaxAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *                   &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *                   &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverPremiumCalculationRulesDataType", propOrder = {
    "calctnType",
    "premPricingParam",
    "fqcy",
    "fixdAmnt",
    "fixdRate",
    "ratePerAge",
    "ratePerAmnt"
})
public class CoverPremiumCalculationRulesDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CalctnType", required = true)
    protected String calctnType;
    @XmlElement(name = "PremPricingParam")
    protected List<String> premPricingParam;
    @XmlElement(name = "Fqcy")
    protected String fqcy;
    @XmlElement(name = "FixdAmnt")
    protected CurrencyAndAmountType fixdAmnt;
    @XmlElement(name = "FixdRate")
    protected BasisRateType fixdRate;
    @XmlElement(name = "RatePerAge")
    protected List<CoverPremiumCalculationRulesDataType.RatePerAge> ratePerAge;
    @XmlElement(name = "RatePerAmnt")
    protected List<CoverPremiumCalculationRulesDataType.RatePerAmnt> ratePerAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverPremiumCalculationRulesDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverPremiumCalculationRulesDataType(final String calctnType, final List<String> premPricingParam, final String fqcy, final CurrencyAndAmountType fixdAmnt, final BasisRateType fixdRate, final List<CoverPremiumCalculationRulesDataType.RatePerAge> ratePerAge, final List<CoverPremiumCalculationRulesDataType.RatePerAmnt> ratePerAmnt) {
        this.calctnType = calctnType;
        this.premPricingParam = premPricingParam;
        this.fqcy = fqcy;
        this.fixdAmnt = fixdAmnt;
        this.fixdRate = fixdRate;
        this.ratePerAge = ratePerAge;
        this.ratePerAmnt = ratePerAmnt;
    }

    /**
     * Gets the value of the calctnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalctnType() {
        return calctnType;
    }

    /**
     * Sets the value of the calctnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalctnType(String value) {
        this.calctnType = value;
    }

    public boolean isSetCalctnType() {
        return (this.calctnType!= null);
    }

    /**
     * Gets the value of the premPricingParam property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the premPricingParam property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPremPricingParam().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getPremPricingParam() {
        if (premPricingParam == null) {
            premPricingParam = new ArrayList<String>();
        }
        return this.premPricingParam;
    }

    public boolean isSetPremPricingParam() {
        return ((this.premPricingParam!= null)&&(!this.premPricingParam.isEmpty()));
    }

    public void unsetPremPricingParam() {
        this.premPricingParam = null;
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the fixdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFixdAmnt() {
        return fixdAmnt;
    }

    /**
     * Sets the value of the fixdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFixdAmnt(CurrencyAndAmountType value) {
        this.fixdAmnt = value;
    }

    public boolean isSetFixdAmnt() {
        return (this.fixdAmnt!= null);
    }

    /**
     * Gets the value of the fixdRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getFixdRate() {
        return fixdRate;
    }

    /**
     * Sets the value of the fixdRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setFixdRate(BasisRateType value) {
        this.fixdRate = value;
    }

    public boolean isSetFixdRate() {
        return (this.fixdRate!= null);
    }

    /**
     * Gets the value of the ratePerAge property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ratePerAge property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRatePerAge().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverPremiumCalculationRulesDataType.RatePerAge }
     * 
     * 
     */
    public List<CoverPremiumCalculationRulesDataType.RatePerAge> getRatePerAge() {
        if (ratePerAge == null) {
            ratePerAge = new ArrayList<CoverPremiumCalculationRulesDataType.RatePerAge>();
        }
        return this.ratePerAge;
    }

    public boolean isSetRatePerAge() {
        return ((this.ratePerAge!= null)&&(!this.ratePerAge.isEmpty()));
    }

    public void unsetRatePerAge() {
        this.ratePerAge = null;
    }

    /**
     * Gets the value of the ratePerAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ratePerAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRatePerAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverPremiumCalculationRulesDataType.RatePerAmnt }
     * 
     * 
     */
    public List<CoverPremiumCalculationRulesDataType.RatePerAmnt> getRatePerAmnt() {
        if (ratePerAmnt == null) {
            ratePerAmnt = new ArrayList<CoverPremiumCalculationRulesDataType.RatePerAmnt>();
        }
        return this.ratePerAmnt;
    }

    public boolean isSetRatePerAmnt() {
        return ((this.ratePerAmnt!= null)&&(!this.ratePerAmnt.isEmpty()));
    }

    public void unsetRatePerAmnt() {
        this.ratePerAmnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("calctnType", calctnType).add("premPricingParam", premPricingParam).add("fqcy", fqcy).add("fixdAmnt", fixdAmnt).add("fixdRate", fixdRate).add("ratePerAge", ratePerAge).add("ratePerAmnt", ratePerAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(calctnType, premPricingParam, fqcy, fixdAmnt, fixdRate, ratePerAge, ratePerAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverPremiumCalculationRulesDataType o = ((CoverPremiumCalculationRulesDataType) other);
        return ((((((Objects.equal(calctnType, o.calctnType)&&Objects.equal(premPricingParam, o.premPricingParam))&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(fixdAmnt, o.fixdAmnt))&&Objects.equal(fixdRate, o.fixdRate))&&Objects.equal(ratePerAge, o.ratePerAge))&&Objects.equal(ratePerAmnt, o.ratePerAmnt));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="InsrdMinAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
     *         &lt;element name="InsrdMaxAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType"/&gt;
     *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
     *         &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "insrdMinAge",
        "insrdMaxAge",
        "rate",
        "gendr"
    })
    public static class RatePerAge implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "InsrdMinAge", required = true)
        protected BigInteger insrdMinAge;
        @XmlElement(name = "InsrdMaxAge", required = true)
        protected BigInteger insrdMaxAge;
        @XmlElement(name = "Rate", required = true)
        protected BasisRateType rate;
        @XmlElement(name = "Gendr")
        protected String gendr;

        /**
         * Default no-arg constructor
         * 
         */
        public RatePerAge() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public RatePerAge(final BigInteger insrdMinAge, final BigInteger insrdMaxAge, final BasisRateType rate, final String gendr) {
            this.insrdMinAge = insrdMinAge;
            this.insrdMaxAge = insrdMaxAge;
            this.rate = rate;
            this.gendr = gendr;
        }

        /**
         * Gets the value of the insrdMinAge property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getInsrdMinAge() {
            return insrdMinAge;
        }

        /**
         * Sets the value of the insrdMinAge property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setInsrdMinAge(BigInteger value) {
            this.insrdMinAge = value;
        }

        public boolean isSetInsrdMinAge() {
            return (this.insrdMinAge!= null);
        }

        /**
         * Gets the value of the insrdMaxAge property.
         * 
         * @return
         *     possible object is
         *     {@link BigInteger }
         *     
         */
        public BigInteger getInsrdMaxAge() {
            return insrdMaxAge;
        }

        /**
         * Sets the value of the insrdMaxAge property.
         * 
         * @param value
         *     allowed object is
         *     {@link BigInteger }
         *     
         */
        public void setInsrdMaxAge(BigInteger value) {
            this.insrdMaxAge = value;
        }

        public boolean isSetInsrdMaxAge() {
            return (this.insrdMaxAge!= null);
        }

        /**
         * Gets the value of the rate property.
         * 
         * @return
         *     possible object is
         *     {@link BasisRateType }
         *     
         */
        public BasisRateType getRate() {
            return rate;
        }

        /**
         * Sets the value of the rate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BasisRateType }
         *     
         */
        public void setRate(BasisRateType value) {
            this.rate = value;
        }

        public boolean isSetRate() {
            return (this.rate!= null);
        }

        /**
         * Gets the value of the gendr property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getGendr() {
            return gendr;
        }

        /**
         * Sets the value of the gendr property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setGendr(String value) {
            this.gendr = value;
        }

        public boolean isSetGendr() {
            return (this.gendr!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("insrdMinAge", insrdMinAge).add("insrdMaxAge", insrdMaxAge).add("rate", rate).add("gendr", gendr).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(insrdMinAge, insrdMaxAge, rate, gendr);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final CoverPremiumCalculationRulesDataType.RatePerAge o = ((CoverPremiumCalculationRulesDataType.RatePerAge) other);
            return (((Objects.equal(insrdMinAge, o.insrdMinAge)&&Objects.equal(insrdMaxAge, o.insrdMaxAge))&&Objects.equal(rate, o.rate))&&Objects.equal(gendr, o.gendr));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="InsrdMinAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
     *         &lt;element name="InsrdMaxAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
     *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
     *         &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "insrdMinAmnt",
        "insrdMaxAmnt",
        "rate",
        "gendr"
    })
    public static class RatePerAmnt implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "InsrdMinAmnt", required = true)
        protected CurrencyAndAmountType insrdMinAmnt;
        @XmlElement(name = "InsrdMaxAmnt", required = true)
        protected CurrencyAndAmountType insrdMaxAmnt;
        @XmlElement(name = "Rate", required = true)
        protected BasisRateType rate;
        @XmlElement(name = "Gendr")
        protected String gendr;

        /**
         * Default no-arg constructor
         * 
         */
        public RatePerAmnt() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public RatePerAmnt(final CurrencyAndAmountType insrdMinAmnt, final CurrencyAndAmountType insrdMaxAmnt, final BasisRateType rate, final String gendr) {
            this.insrdMinAmnt = insrdMinAmnt;
            this.insrdMaxAmnt = insrdMaxAmnt;
            this.rate = rate;
            this.gendr = gendr;
        }

        /**
         * Gets the value of the insrdMinAmnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getInsrdMinAmnt() {
            return insrdMinAmnt;
        }

        /**
         * Sets the value of the insrdMinAmnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setInsrdMinAmnt(CurrencyAndAmountType value) {
            this.insrdMinAmnt = value;
        }

        public boolean isSetInsrdMinAmnt() {
            return (this.insrdMinAmnt!= null);
        }

        /**
         * Gets the value of the insrdMaxAmnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getInsrdMaxAmnt() {
            return insrdMaxAmnt;
        }

        /**
         * Sets the value of the insrdMaxAmnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setInsrdMaxAmnt(CurrencyAndAmountType value) {
            this.insrdMaxAmnt = value;
        }

        public boolean isSetInsrdMaxAmnt() {
            return (this.insrdMaxAmnt!= null);
        }

        /**
         * Gets the value of the rate property.
         * 
         * @return
         *     possible object is
         *     {@link BasisRateType }
         *     
         */
        public BasisRateType getRate() {
            return rate;
        }

        /**
         * Sets the value of the rate property.
         * 
         * @param value
         *     allowed object is
         *     {@link BasisRateType }
         *     
         */
        public void setRate(BasisRateType value) {
            this.rate = value;
        }

        public boolean isSetRate() {
            return (this.rate!= null);
        }

        /**
         * Gets the value of the gendr property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getGendr() {
            return gendr;
        }

        /**
         * Sets the value of the gendr property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setGendr(String value) {
            this.gendr = value;
        }

        public boolean isSetGendr() {
            return (this.gendr!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("insrdMinAmnt", insrdMinAmnt).add("insrdMaxAmnt", insrdMaxAmnt).add("rate", rate).add("gendr", gendr).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(insrdMinAmnt, insrdMaxAmnt, rate, gendr);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final CoverPremiumCalculationRulesDataType.RatePerAmnt o = ((CoverPremiumCalculationRulesDataType.RatePerAmnt) other);
            return (((Objects.equal(insrdMinAmnt, o.insrdMinAmnt)&&Objects.equal(insrdMaxAmnt, o.insrdMaxAmnt))&&Objects.equal(rate, o.rate))&&Objects.equal(gendr, o.gendr));
        }

    }

}
