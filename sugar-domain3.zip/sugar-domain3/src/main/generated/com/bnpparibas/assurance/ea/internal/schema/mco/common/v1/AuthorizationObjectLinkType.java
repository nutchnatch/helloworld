
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * gère les liens avec une
 * 				instance d'objet supérieur: groupe, rôle, etc
 * 			
 * 
 * <p>Java class for AuthorizationObjectLinkType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AuthorizationObjectLinkType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType"/&gt;
 *         &lt;element name="AuthoriztnObjctType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AuthorizationObjectTypeCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuthorizationObjectLinkType", propOrder = {
    "id",
    "authoriztnObjctType"
})
public class AuthorizationObjectLinkType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id", required = true)
    protected IdentificationType id;
    @XmlElement(name = "AuthoriztnObjctType", required = true)
    protected String authoriztnObjctType;

    /**
     * Default no-arg constructor
     * 
     */
    public AuthorizationObjectLinkType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AuthorizationObjectLinkType(final IdentificationType id, final String authoriztnObjctType) {
        this.id = id;
        this.authoriztnObjctType = authoriztnObjctType;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setId(IdentificationType value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the authoriztnObjctType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthoriztnObjctType() {
        return authoriztnObjctType;
    }

    /**
     * Sets the value of the authoriztnObjctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthoriztnObjctType(String value) {
        this.authoriztnObjctType = value;
    }

    public boolean isSetAuthoriztnObjctType() {
        return (this.authoriztnObjctType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("authoriztnObjctType", authoriztnObjctType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, authoriztnObjctType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AuthorizationObjectLinkType o = ((AuthorizationObjectLinkType) other);
        return (Objects.equal(id, o.id)&&Objects.equal(authoriztnObjctType, o.authoriztnObjctType));
    }

}
