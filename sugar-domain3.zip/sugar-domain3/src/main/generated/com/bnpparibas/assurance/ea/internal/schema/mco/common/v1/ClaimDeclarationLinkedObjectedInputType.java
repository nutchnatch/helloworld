
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a claims policy cover request
 * 				has dependencies
 * 			
 * 
 * <p>Java class for ClaimDeclarationLinkedObjectedInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimDeclarationLinkedObjectedInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Partnr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Claimnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="Vctm" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="Cust" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimDeclarationLinkedObjectedInputType", propOrder = {
    "pol",
    "partnr",
    "claimnt",
    "vctm",
    "cust"
})
public class ClaimDeclarationLinkedObjectedInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pol")
    protected List<ObjectIdentificationType> pol;
    @XmlElement(name = "Partnr")
    protected List<PartnerPartyType> partnr;
    @XmlElement(name = "Claimnt")
    protected PartyRoleType claimnt;
    @XmlElement(name = "Vctm")
    protected PartyRoleType vctm;
    @XmlElement(name = "Cust")
    protected List<PartyRoleType> cust;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimDeclarationLinkedObjectedInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimDeclarationLinkedObjectedInputType(final List<ObjectIdentificationType> pol, final List<PartnerPartyType> partnr, final PartyRoleType claimnt, final PartyRoleType vctm, final List<PartyRoleType> cust) {
        this.pol = pol;
        this.partnr = partnr;
        this.claimnt = claimnt;
        this.vctm = vctm;
        this.cust = cust;
    }

    /**
     * Gets the value of the pol property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pol property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPol().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ObjectIdentificationType }
     * 
     * 
     */
    public List<ObjectIdentificationType> getPol() {
        if (pol == null) {
            pol = new ArrayList<ObjectIdentificationType>();
        }
        return this.pol;
    }

    public boolean isSetPol() {
        return ((this.pol!= null)&&(!this.pol.isEmpty()));
    }

    public void unsetPol() {
        this.pol = null;
    }

    /**
     * Gets the value of the partnr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partnr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartnr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getPartnr() {
        if (partnr == null) {
            partnr = new ArrayList<PartnerPartyType>();
        }
        return this.partnr;
    }

    public boolean isSetPartnr() {
        return ((this.partnr!= null)&&(!this.partnr.isEmpty()));
    }

    public void unsetPartnr() {
        this.partnr = null;
    }

    /**
     * Gets the value of the claimnt property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getClaimnt() {
        return claimnt;
    }

    /**
     * Sets the value of the claimnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setClaimnt(PartyRoleType value) {
        this.claimnt = value;
    }

    public boolean isSetClaimnt() {
        return (this.claimnt!= null);
    }

    /**
     * Gets the value of the vctm property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getVctm() {
        return vctm;
    }

    /**
     * Sets the value of the vctm property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setVctm(PartyRoleType value) {
        this.vctm = value;
    }

    public boolean isSetVctm() {
        return (this.vctm!= null);
    }

    /**
     * Gets the value of the cust property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cust property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCust().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyRoleType }
     * 
     * 
     */
    public List<PartyRoleType> getCust() {
        if (cust == null) {
            cust = new ArrayList<PartyRoleType>();
        }
        return this.cust;
    }

    public boolean isSetCust() {
        return ((this.cust!= null)&&(!this.cust.isEmpty()));
    }

    public void unsetCust() {
        this.cust = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pol", pol).add("partnr", partnr).add("claimnt", claimnt).add("vctm", vctm).add("cust", cust).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pol, partnr, claimnt, vctm, cust);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimDeclarationLinkedObjectedInputType o = ((ClaimDeclarationLinkedObjectedInputType) other);
        return ((((Objects.equal(pol, o.pol)&&Objects.equal(partnr, o.partnr))&&Objects.equal(claimnt, o.claimnt))&&Objects.equal(vctm, o.vctm))&&Objects.equal(cust, o.cust));
    }

}
