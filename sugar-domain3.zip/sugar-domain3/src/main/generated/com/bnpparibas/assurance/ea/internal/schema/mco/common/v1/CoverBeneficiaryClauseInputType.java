
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on input benficiary clause
 * 			
 * 
 * <p>Java class for CoverBeneficiaryClauseInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoverBeneficiaryClauseInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClauseType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClauseTypeCodeSLN"/&gt;
 *         &lt;element name="StdClauseId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StandardBeneficiaryClauseCode" minOccurs="0"/&gt;
 *         &lt;element name="FreeClauseText" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClauseTextType" minOccurs="0"/&gt;
 *         &lt;element name="NamedBenfciary" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverNamedBeneficiaryClauseInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoverBeneficiaryClauseInputType", propOrder = {
    "clauseType",
    "stdClauseId",
    "freeClauseText",
    "namedBenfciary"
})
public class CoverBeneficiaryClauseInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClauseType", required = true)
    protected String clauseType;
    @XmlElement(name = "StdClauseId")
    protected String stdClauseId;
    @XmlElement(name = "FreeClauseText")
    protected String freeClauseText;
    @XmlElement(name = "NamedBenfciary")
    protected List<CoverNamedBeneficiaryClauseInputType> namedBenfciary;

    /**
     * Default no-arg constructor
     * 
     */
    public CoverBeneficiaryClauseInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoverBeneficiaryClauseInputType(final String clauseType, final String stdClauseId, final String freeClauseText, final List<CoverNamedBeneficiaryClauseInputType> namedBenfciary) {
        this.clauseType = clauseType;
        this.stdClauseId = stdClauseId;
        this.freeClauseText = freeClauseText;
        this.namedBenfciary = namedBenfciary;
    }

    /**
     * Gets the value of the clauseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClauseType() {
        return clauseType;
    }

    /**
     * Sets the value of the clauseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClauseType(String value) {
        this.clauseType = value;
    }

    public boolean isSetClauseType() {
        return (this.clauseType!= null);
    }

    /**
     * Gets the value of the stdClauseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdClauseId() {
        return stdClauseId;
    }

    /**
     * Sets the value of the stdClauseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdClauseId(String value) {
        this.stdClauseId = value;
    }

    public boolean isSetStdClauseId() {
        return (this.stdClauseId!= null);
    }

    /**
     * Gets the value of the freeClauseText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeClauseText() {
        return freeClauseText;
    }

    /**
     * Sets the value of the freeClauseText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeClauseText(String value) {
        this.freeClauseText = value;
    }

    public boolean isSetFreeClauseText() {
        return (this.freeClauseText!= null);
    }

    /**
     * Gets the value of the namedBenfciary property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the namedBenfciary property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNamedBenfciary().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CoverNamedBeneficiaryClauseInputType }
     * 
     * 
     */
    public List<CoverNamedBeneficiaryClauseInputType> getNamedBenfciary() {
        if (namedBenfciary == null) {
            namedBenfciary = new ArrayList<CoverNamedBeneficiaryClauseInputType>();
        }
        return this.namedBenfciary;
    }

    public boolean isSetNamedBenfciary() {
        return ((this.namedBenfciary!= null)&&(!this.namedBenfciary.isEmpty()));
    }

    public void unsetNamedBenfciary() {
        this.namedBenfciary = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("clauseType", clauseType).add("stdClauseId", stdClauseId).add("freeClauseText", freeClauseText).add("namedBenfciary", namedBenfciary).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(clauseType, stdClauseId, freeClauseText, namedBenfciary);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoverBeneficiaryClauseInputType o = ((CoverBeneficiaryClauseInputType) other);
        return (((Objects.equal(clauseType, o.clauseType)&&Objects.equal(stdClauseId, o.stdClauseId))&&Objects.equal(freeClauseText, o.freeClauseText))&&Objects.equal(namedBenfciary, o.namedBenfciary));
    }

}
