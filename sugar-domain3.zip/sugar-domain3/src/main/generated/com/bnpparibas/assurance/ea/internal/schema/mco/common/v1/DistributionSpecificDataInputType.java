
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Profiles recommended to the customer during the
 * 				subscription options on the product and other things. Managed only
 * 				at subscription process
 * 			
 * 
 * <p>Java class for DistributionSpecificDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DistributionSpecificDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence minOccurs="0"&gt;
 *         &lt;element name="Opt" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="OptionId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *                   &lt;element name="PolIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="SuggstdProf" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="ProfType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProfileTypeCode"/&gt;
 *                   &lt;element name="ProfIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DistributionSpecificDataInputType", propOrder = {
    "opt",
    "suggstdProf"
})
public class DistributionSpecificDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Opt")
    protected List<DistributionSpecificDataInputType.Opt> opt;
    @XmlElement(name = "SuggstdProf")
    protected List<DistributionSpecificDataInputType.SuggstdProf> suggstdProf;

    /**
     * Default no-arg constructor
     * 
     */
    public DistributionSpecificDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DistributionSpecificDataInputType(final List<DistributionSpecificDataInputType.Opt> opt, final List<DistributionSpecificDataInputType.SuggstdProf> suggstdProf) {
        this.opt = opt;
        this.suggstdProf = suggstdProf;
    }

    /**
     * Gets the value of the opt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the opt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOpt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DistributionSpecificDataInputType.Opt }
     * 
     * 
     */
    public List<DistributionSpecificDataInputType.Opt> getOpt() {
        if (opt == null) {
            opt = new ArrayList<DistributionSpecificDataInputType.Opt>();
        }
        return this.opt;
    }

    public boolean isSetOpt() {
        return ((this.opt!= null)&&(!this.opt.isEmpty()));
    }

    public void unsetOpt() {
        this.opt = null;
    }

    /**
     * Gets the value of the suggstdProf property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the suggstdProf property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSuggstdProf().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DistributionSpecificDataInputType.SuggstdProf }
     * 
     * 
     */
    public List<DistributionSpecificDataInputType.SuggstdProf> getSuggstdProf() {
        if (suggstdProf == null) {
            suggstdProf = new ArrayList<DistributionSpecificDataInputType.SuggstdProf>();
        }
        return this.suggstdProf;
    }

    public boolean isSetSuggstdProf() {
        return ((this.suggstdProf!= null)&&(!this.suggstdProf.isEmpty()));
    }

    public void unsetSuggstdProf() {
        this.suggstdProf = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opt", opt).add("suggstdProf", suggstdProf).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opt, suggstdProf);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DistributionSpecificDataInputType o = ((DistributionSpecificDataInputType) other);
        return (Objects.equal(opt, o.opt)&&Objects.equal(suggstdProf, o.suggstdProf));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="OptionId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
     *         &lt;element name="PolIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "optionId",
        "polIdntfctn"
    })
    public static class Opt implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "OptionId")
        protected String optionId;
        @XmlElement(name = "PolIdntfctn")
        protected ObjectIdentificationType polIdntfctn;

        /**
         * Default no-arg constructor
         * 
         */
        public Opt() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Opt(final String optionId, final ObjectIdentificationType polIdntfctn) {
            this.optionId = optionId;
            this.polIdntfctn = polIdntfctn;
        }

        /**
         * Gets the value of the optionId property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOptionId() {
            return optionId;
        }

        /**
         * Sets the value of the optionId property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOptionId(String value) {
            this.optionId = value;
        }

        public boolean isSetOptionId() {
            return (this.optionId!= null);
        }

        /**
         * Gets the value of the polIdntfctn property.
         * 
         * @return
         *     possible object is
         *     {@link ObjectIdentificationType }
         *     
         */
        public ObjectIdentificationType getPolIdntfctn() {
            return polIdntfctn;
        }

        /**
         * Sets the value of the polIdntfctn property.
         * 
         * @param value
         *     allowed object is
         *     {@link ObjectIdentificationType }
         *     
         */
        public void setPolIdntfctn(ObjectIdentificationType value) {
            this.polIdntfctn = value;
        }

        public boolean isSetPolIdntfctn() {
            return (this.polIdntfctn!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("optionId", optionId).add("polIdntfctn", polIdntfctn).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(optionId, polIdntfctn);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final DistributionSpecificDataInputType.Opt o = ((DistributionSpecificDataInputType.Opt) other);
            return (Objects.equal(optionId, o.optionId)&&Objects.equal(polIdntfctn, o.polIdntfctn));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="ProfType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProfileTypeCode"/&gt;
     *         &lt;element name="ProfIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "profType",
        "profIdntfctn"
    })
    public static class SuggstdProf implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "ProfType", required = true)
        protected String profType;
        @XmlElement(name = "ProfIdntfctn")
        protected ObjectIdentificationType profIdntfctn;

        /**
         * Default no-arg constructor
         * 
         */
        public SuggstdProf() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public SuggstdProf(final String profType, final ObjectIdentificationType profIdntfctn) {
            this.profType = profType;
            this.profIdntfctn = profIdntfctn;
        }

        /**
         * Gets the value of the profType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getProfType() {
            return profType;
        }

        /**
         * Sets the value of the profType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setProfType(String value) {
            this.profType = value;
        }

        public boolean isSetProfType() {
            return (this.profType!= null);
        }

        /**
         * Gets the value of the profIdntfctn property.
         * 
         * @return
         *     possible object is
         *     {@link ObjectIdentificationType }
         *     
         */
        public ObjectIdentificationType getProfIdntfctn() {
            return profIdntfctn;
        }

        /**
         * Sets the value of the profIdntfctn property.
         * 
         * @param value
         *     allowed object is
         *     {@link ObjectIdentificationType }
         *     
         */
        public void setProfIdntfctn(ObjectIdentificationType value) {
            this.profIdntfctn = value;
        }

        public boolean isSetProfIdntfctn() {
            return (this.profIdntfctn!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("profType", profType).add("profIdntfctn", profIdntfctn).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(profType, profIdntfctn);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final DistributionSpecificDataInputType.SuggstdProf o = ((DistributionSpecificDataInputType.SuggstdProf) other);
            return (Objects.equal(profType, o.profType)&&Objects.equal(profIdntfctn, o.profIdntfctn));
        }

    }

}
