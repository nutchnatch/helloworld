
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Objects with which a claim file has dependencies
 * 			
 * 
 * <p>Java class for ClaimFileLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimFileLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClaimDeclrtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType" minOccurs="0"/&gt;
 *         &lt;element name="CorePdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductIdentificationAndHierarchyDataType" minOccurs="0"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimFileLinkedObjectsType", propOrder = {
    "claimDeclrtn",
    "pol",
    "pdct",
    "corePdct",
    "prdctr",
    "distrbtr"
})
public class ClaimFileLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClaimDeclrtn", required = true)
    protected ObjectIdentificationType claimDeclrtn;
    @XmlElement(name = "Pol", required = true)
    protected ObjectIdentificationType pol;
    @XmlElement(name = "Pdct")
    protected ObjectIdentificationWithVersionType pdct;
    @XmlElement(name = "CorePdct")
    protected CoreProductIdentificationAndHierarchyDataType corePdct;
    @XmlElement(name = "Prdctr", required = true)
    protected PartyRoleType prdctr;
    @XmlElement(name = "Distrbtr")
    protected List<PartnerPartyType> distrbtr;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimFileLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimFileLinkedObjectsType(final ObjectIdentificationType claimDeclrtn, final ObjectIdentificationType pol, final ObjectIdentificationWithVersionType pdct, final CoreProductIdentificationAndHierarchyDataType corePdct, final PartyRoleType prdctr, final List<PartnerPartyType> distrbtr) {
        this.claimDeclrtn = claimDeclrtn;
        this.pol = pol;
        this.pdct = pdct;
        this.corePdct = corePdct;
        this.prdctr = prdctr;
        this.distrbtr = distrbtr;
    }

    /**
     * Gets the value of the claimDeclrtn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getClaimDeclrtn() {
        return claimDeclrtn;
    }

    /**
     * Sets the value of the claimDeclrtn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setClaimDeclrtn(ObjectIdentificationType value) {
        this.claimDeclrtn = value;
    }

    public boolean isSetClaimDeclrtn() {
        return (this.claimDeclrtn!= null);
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setPdct(ObjectIdentificationWithVersionType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the corePdct property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public CoreProductIdentificationAndHierarchyDataType getCorePdct() {
        return corePdct;
    }

    /**
     * Sets the value of the corePdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductIdentificationAndHierarchyDataType }
     *     
     */
    public void setCorePdct(CoreProductIdentificationAndHierarchyDataType value) {
        this.corePdct = value;
    }

    public boolean isSetCorePdct() {
        return (this.corePdct!= null);
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the distrbtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDistrbtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartnerPartyType }
     * 
     * 
     */
    public List<PartnerPartyType> getDistrbtr() {
        if (distrbtr == null) {
            distrbtr = new ArrayList<PartnerPartyType>();
        }
        return this.distrbtr;
    }

    public boolean isSetDistrbtr() {
        return ((this.distrbtr!= null)&&(!this.distrbtr.isEmpty()));
    }

    public void unsetDistrbtr() {
        this.distrbtr = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("claimDeclrtn", claimDeclrtn).add("pol", pol).add("pdct", pdct).add("corePdct", corePdct).add("prdctr", prdctr).add("distrbtr", distrbtr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(claimDeclrtn, pol, pdct, corePdct, prdctr, distrbtr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimFileLinkedObjectsType o = ((ClaimFileLinkedObjectsType) other);
        return (((((Objects.equal(claimDeclrtn, o.claimDeclrtn)&&Objects.equal(pol, o.pol))&&Objects.equal(pdct, o.pdct))&&Objects.equal(corePdct, o.corePdct))&&Objects.equal(prdctr, o.prdctr))&&Objects.equal(distrbtr, o.distrbtr));
    }

}
