
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Minimum data to manage on the beneficiary when he
 * 				is not or should not managed as a person in the I.S of the insurance
 * 				company
 * 			
 * 
 * <p>Java class for BeneficiaryMinimumDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BeneficiaryMinimumDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LastName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="FrstName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="BrthDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneficiaryMinimumDataType", propOrder = {
    "lastName",
    "frstName",
    "brthDate",
    "gendr"
})
public class BeneficiaryMinimumDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "LastName", required = true)
    protected String lastName;
    @XmlElement(name = "FrstName", required = true)
    protected List<String> frstName;
    @XmlElement(name = "BrthDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date brthDate;
    @XmlElement(name = "Gendr")
    protected String gendr;

    /**
     * Default no-arg constructor
     * 
     */
    public BeneficiaryMinimumDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BeneficiaryMinimumDataType(final String lastName, final List<String> frstName, final Date brthDate, final String gendr) {
        this.lastName = lastName;
        this.frstName = frstName;
        this.brthDate = brthDate;
        this.gendr = gendr;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    public boolean isSetLastName() {
        return (this.lastName!= null);
    }

    /**
     * Gets the value of the frstName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the frstName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFrstName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFrstName() {
        if (frstName == null) {
            frstName = new ArrayList<String>();
        }
        return this.frstName;
    }

    public boolean isSetFrstName() {
        return ((this.frstName!= null)&&(!this.frstName.isEmpty()));
    }

    public void unsetFrstName() {
        this.frstName = null;
    }

    /**
     * Gets the value of the brthDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getBrthDate() {
        return brthDate;
    }

    /**
     * Sets the value of the brthDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrthDate(Date value) {
        this.brthDate = value;
    }

    public boolean isSetBrthDate() {
        return (this.brthDate!= null);
    }

    /**
     * Gets the value of the gendr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGendr() {
        return gendr;
    }

    /**
     * Sets the value of the gendr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGendr(String value) {
        this.gendr = value;
    }

    public boolean isSetGendr() {
        return (this.gendr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("lastName", lastName).add("frstName", frstName).add("brthDate", brthDate).add("gendr", gendr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(lastName, frstName, brthDate, gendr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BeneficiaryMinimumDataType o = ((BeneficiaryMinimumDataType) other);
        return (((Objects.equal(lastName, o.lastName)&&Objects.equal(frstName, o.frstName))&&Objects.equal(brthDate, o.brthDate))&&Objects.equal(gendr, o.gendr));
    }

}
