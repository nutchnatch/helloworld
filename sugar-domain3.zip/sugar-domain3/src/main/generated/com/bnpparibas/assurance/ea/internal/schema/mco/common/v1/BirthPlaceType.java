
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * format type of birth place of a natural person
 * 			
 * 
 * <p>Java class for BirthPlaceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BirthPlaceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CityName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CityNameType" minOccurs="0"/&gt;
 *         &lt;element name="Cntry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="BrthArea" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AreaTypeCodeSLN" minOccurs="0"/&gt;
 *                   &lt;element name="Code" minOccurs="0"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;maxLength value="20"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BirthPlaceType", propOrder = {
    "cityName",
    "cntry",
    "brthArea"
})
public class BirthPlaceType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CityName")
    protected String cityName;
    @XmlElement(name = "Cntry")
    protected String cntry;
    @XmlElement(name = "BrthArea")
    protected BirthPlaceType.BrthArea brthArea;

    /**
     * Default no-arg constructor
     * 
     */
    public BirthPlaceType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BirthPlaceType(final String cityName, final String cntry, final BirthPlaceType.BrthArea brthArea) {
        this.cityName = cityName;
        this.cntry = cntry;
        this.brthArea = brthArea;
    }

    /**
     * Gets the value of the cityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCityName() {
        return cityName;
    }

    /**
     * Sets the value of the cityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCityName(String value) {
        this.cityName = value;
    }

    public boolean isSetCityName() {
        return (this.cityName!= null);
    }

    /**
     * Gets the value of the cntry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCntry() {
        return cntry;
    }

    /**
     * Sets the value of the cntry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCntry(String value) {
        this.cntry = value;
    }

    public boolean isSetCntry() {
        return (this.cntry!= null);
    }

    /**
     * Gets the value of the brthArea property.
     * 
     * @return
     *     possible object is
     *     {@link BirthPlaceType.BrthArea }
     *     
     */
    public BirthPlaceType.BrthArea getBrthArea() {
        return brthArea;
    }

    /**
     * Sets the value of the brthArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link BirthPlaceType.BrthArea }
     *     
     */
    public void setBrthArea(BirthPlaceType.BrthArea value) {
        this.brthArea = value;
    }

    public boolean isSetBrthArea() {
        return (this.brthArea!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cityName", cityName).add("cntry", cntry).add("brthArea", brthArea).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cityName, cntry, brthArea);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BirthPlaceType o = ((BirthPlaceType) other);
        return ((Objects.equal(cityName, o.cityName)&&Objects.equal(cntry, o.cntry))&&Objects.equal(brthArea, o.brthArea));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AreaTypeCodeSLN" minOccurs="0"/&gt;
     *         &lt;element name="Code" minOccurs="0"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;maxLength value="20"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "type",
        "code",
        "name"
    })
    public static class BrthArea implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Type")
        protected String type;
        @XmlElement(name = "Code")
        protected String code;
        @XmlElement(name = "Name")
        protected String name;

        /**
         * Default no-arg constructor
         * 
         */
        public BrthArea() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public BrthArea(final String type, final String code, final String name) {
            this.type = type;
            this.code = code;
            this.name = name;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

        public boolean isSetType() {
            return (this.type!= null);
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        public boolean isSetCode() {
            return (this.code!= null);
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

        public boolean isSetName() {
            return (this.name!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("type", type).add("code", code).add("name", name).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(type, code, name);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final BirthPlaceType.BrthArea o = ((BirthPlaceType.BrthArea) other);
            return ((Objects.equal(type, o.type)&&Objects.equal(code, o.code))&&Objects.equal(name, o.name));
        }

    }

}
