
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * données de l'objet
 * 				d'autorisation
 * 			
 * 
 * <p>Java class for AuthorizationObjctDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AuthorizationObjctDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AuthoriztnObjctType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AuthorizationObjectTypeCodeSLN"/&gt;
 *         &lt;element name="Wordng" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Wording" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Value" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AuthorizationObjctDataType", propOrder = {
    "authoriztnObjctType",
    "wordng",
    "value"
})
public class AuthorizationObjctDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "AuthoriztnObjctType", required = true)
    protected String authoriztnObjctType;
    @XmlElement(name = "Wordng")
    protected List<Wording> wordng;
    @XmlElement(name = "Value")
    protected String value;

    /**
     * Default no-arg constructor
     * 
     */
    public AuthorizationObjctDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AuthorizationObjctDataType(final String authoriztnObjctType, final List<Wording> wordng, final String value) {
        this.authoriztnObjctType = authoriztnObjctType;
        this.wordng = wordng;
        this.value = value;
    }

    /**
     * Gets the value of the authoriztnObjctType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthoriztnObjctType() {
        return authoriztnObjctType;
    }

    /**
     * Sets the value of the authoriztnObjctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthoriztnObjctType(String value) {
        this.authoriztnObjctType = value;
    }

    public boolean isSetAuthoriztnObjctType() {
        return (this.authoriztnObjctType!= null);
    }

    /**
     * Gets the value of the wordng property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the wordng property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getWordng().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Wording }
     * 
     * 
     */
    public List<Wording> getWordng() {
        if (wordng == null) {
            wordng = new ArrayList<Wording>();
        }
        return this.wordng;
    }

    public boolean isSetWordng() {
        return ((this.wordng!= null)&&(!this.wordng.isEmpty()));
    }

    public void unsetWordng() {
        this.wordng = null;
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("authoriztnObjctType", authoriztnObjctType).add("wordng", wordng).add("value", value).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(authoriztnObjctType, wordng, value);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AuthorizationObjctDataType o = ((AuthorizationObjctDataType) other);
        return ((Objects.equal(authoriztnObjctType, o.authoriztnObjctType)&&Objects.equal(wordng, o.wordng))&&Objects.equal(value, o.value));
    }

}
