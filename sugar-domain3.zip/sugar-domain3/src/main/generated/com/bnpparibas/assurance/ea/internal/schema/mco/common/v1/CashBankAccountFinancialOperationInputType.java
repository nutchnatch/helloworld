
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on sales and after sales
 * 				operation requests linked to a cash bank account
 * 			
 * 
 * <p>Java class for CashBankAccountFinancialOperationInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CashBankAccountFinancialOperationInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="OpePaymnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationPaymentInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CashBankAccountFinancialOperationInputType", propOrder = {
    "opeType",
    "amnt",
    "opePaymnt"
})
public class CashBankAccountFinancialOperationInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeType", required = true)
    protected String opeType;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "OpePaymnt")
    protected List<OperationPaymentInputType> opePaymnt;

    /**
     * Default no-arg constructor
     * 
     */
    public CashBankAccountFinancialOperationInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CashBankAccountFinancialOperationInputType(final String opeType, final CurrencyAndAmountType amnt, final List<OperationPaymentInputType> opePaymnt) {
        this.opeType = opeType;
        this.amnt = amnt;
        this.opePaymnt = opePaymnt;
    }

    /**
     * Gets the value of the opeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeType() {
        return opeType;
    }

    /**
     * Sets the value of the opeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeType(String value) {
        this.opeType = value;
    }

    public boolean isSetOpeType() {
        return (this.opeType!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the opePaymnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the opePaymnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOpePaymnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OperationPaymentInputType }
     * 
     * 
     */
    public List<OperationPaymentInputType> getOpePaymnt() {
        if (opePaymnt == null) {
            opePaymnt = new ArrayList<OperationPaymentInputType>();
        }
        return this.opePaymnt;
    }

    public boolean isSetOpePaymnt() {
        return ((this.opePaymnt!= null)&&(!this.opePaymnt.isEmpty()));
    }

    public void unsetOpePaymnt() {
        this.opePaymnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeType", opeType).add("amnt", amnt).add("opePaymnt", opePaymnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeType, amnt, opePaymnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CashBankAccountFinancialOperationInputType o = ((CashBankAccountFinancialOperationInputType) other);
        return ((Objects.equal(opeType, o.opeType)&&Objects.equal(amnt, o.amnt))&&Objects.equal(opePaymnt, o.opePaymnt));
    }

}
