
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * To manage the origin and the consequenies of the
 * 				claim event
 * 			
 * 
 * <p>Java class for ClaimEventOriginInputDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClaimEventOriginInputDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ClaimOrigin" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClaimOriginEventTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FreeDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongDescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="Date" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="Pthlgy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PathologyType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClaimEventOriginInputDataType", propOrder = {
    "claimOrigin",
    "freeDesc",
    "date",
    "pthlgy"
})
public class ClaimEventOriginInputDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClaimOrigin")
    protected String claimOrigin;
    @XmlElement(name = "FreeDesc")
    protected String freeDesc;
    @XmlElement(name = "Date", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date date;
    @XmlElement(name = "Pthlgy")
    protected List<PathologyType> pthlgy;

    /**
     * Default no-arg constructor
     * 
     */
    public ClaimEventOriginInputDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ClaimEventOriginInputDataType(final String claimOrigin, final String freeDesc, final Date date, final List<PathologyType> pthlgy) {
        this.claimOrigin = claimOrigin;
        this.freeDesc = freeDesc;
        this.date = date;
        this.pthlgy = pthlgy;
    }

    /**
     * Gets the value of the claimOrigin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaimOrigin() {
        return claimOrigin;
    }

    /**
     * Sets the value of the claimOrigin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaimOrigin(String value) {
        this.claimOrigin = value;
    }

    public boolean isSetClaimOrigin() {
        return (this.claimOrigin!= null);
    }

    /**
     * Gets the value of the freeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeDesc() {
        return freeDesc;
    }

    /**
     * Sets the value of the freeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeDesc(String value) {
        this.freeDesc = value;
    }

    public boolean isSetFreeDesc() {
        return (this.freeDesc!= null);
    }

    /**
     * Gets the value of the date property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDate() {
        return date;
    }

    /**
     * Sets the value of the date property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDate(Date value) {
        this.date = value;
    }

    public boolean isSetDate() {
        return (this.date!= null);
    }

    /**
     * Gets the value of the pthlgy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pthlgy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPthlgy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PathologyType }
     * 
     * 
     */
    public List<PathologyType> getPthlgy() {
        if (pthlgy == null) {
            pthlgy = new ArrayList<PathologyType>();
        }
        return this.pthlgy;
    }

    public boolean isSetPthlgy() {
        return ((this.pthlgy!= null)&&(!this.pthlgy.isEmpty()));
    }

    public void unsetPthlgy() {
        this.pthlgy = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("claimOrigin", claimOrigin).add("freeDesc", freeDesc).add("date", date).add("pthlgy", pthlgy).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(claimOrigin, freeDesc, date, pthlgy);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ClaimEventOriginInputDataType o = ((ClaimEventOriginInputDataType) other);
        return (((Objects.equal(claimOrigin, o.claimOrigin)&&Objects.equal(freeDesc, o.freeDesc))&&Objects.equal(date, o.date))&&Objects.equal(pthlgy, o.pthlgy));
    }

}
