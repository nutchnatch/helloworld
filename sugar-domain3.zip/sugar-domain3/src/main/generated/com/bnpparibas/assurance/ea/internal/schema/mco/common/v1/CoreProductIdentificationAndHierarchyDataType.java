
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Core product identification with hierarchy of the
 * 				product
 * 			
 * 
 * <p>Java class for CoreProductIdentificationAndHierarchyDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CoreProductIdentificationAndHierarchyDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationWithVersionType" minOccurs="0"/&gt;
 *         &lt;element name="Hierarchy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoreProductHierarchyType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoreProductIdentificationAndHierarchyDataType", propOrder = {
    "idntfctn",
    "hierarchy"
})
public class CoreProductIdentificationAndHierarchyDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn")
    protected ObjectIdentificationWithVersionType idntfctn;
    @XmlElement(name = "Hierarchy")
    protected CoreProductHierarchyType hierarchy;

    /**
     * Default no-arg constructor
     * 
     */
    public CoreProductIdentificationAndHierarchyDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CoreProductIdentificationAndHierarchyDataType(final ObjectIdentificationWithVersionType idntfctn, final CoreProductHierarchyType hierarchy) {
        this.idntfctn = idntfctn;
        this.hierarchy = hierarchy;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public ObjectIdentificationWithVersionType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationWithVersionType }
     *     
     */
    public void setIdntfctn(ObjectIdentificationWithVersionType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the hierarchy property.
     * 
     * @return
     *     possible object is
     *     {@link CoreProductHierarchyType }
     *     
     */
    public CoreProductHierarchyType getHierarchy() {
        return hierarchy;
    }

    /**
     * Sets the value of the hierarchy property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoreProductHierarchyType }
     *     
     */
    public void setHierarchy(CoreProductHierarchyType value) {
        this.hierarchy = value;
    }

    public boolean isSetHierarchy() {
        return (this.hierarchy!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("hierarchy", hierarchy).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, hierarchy);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CoreProductIdentificationAndHierarchyDataType o = ((CoreProductIdentificationAndHierarchyDataType) other);
        return (Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(hierarchy, o.hierarchy));
    }

}
