
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Descriptive Characteristics of the customer
 * 				(individua and legal entity)
 * 			
 * 
 * <p>Java class for CustomerCharacteristicsDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CustomerCharacteristicsDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CustData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CustomerGenericDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="NaturlPersn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NaturalPersonInputType" minOccurs="0"/&gt;
 *         &lt;element name="LegalEntty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalEntityInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerCharacteristicsDataInputType", propOrder = {
    "custData",
    "naturlPersn",
    "legalEntty"
})
public class CustomerCharacteristicsDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CustData")
    protected CustomerGenericDataInputType custData;
    @XmlElement(name = "NaturlPersn")
    protected NaturalPersonInputType naturlPersn;
    @XmlElement(name = "LegalEntty")
    protected LegalEntityInputType legalEntty;

    /**
     * Default no-arg constructor
     * 
     */
    public CustomerCharacteristicsDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public CustomerCharacteristicsDataInputType(final CustomerGenericDataInputType custData, final NaturalPersonInputType naturlPersn, final LegalEntityInputType legalEntty) {
        this.custData = custData;
        this.naturlPersn = naturlPersn;
        this.legalEntty = legalEntty;
    }

    /**
     * Gets the value of the custData property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerGenericDataInputType }
     *     
     */
    public CustomerGenericDataInputType getCustData() {
        return custData;
    }

    /**
     * Sets the value of the custData property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerGenericDataInputType }
     *     
     */
    public void setCustData(CustomerGenericDataInputType value) {
        this.custData = value;
    }

    public boolean isSetCustData() {
        return (this.custData!= null);
    }

    /**
     * Gets the value of the naturlPersn property.
     * 
     * @return
     *     possible object is
     *     {@link NaturalPersonInputType }
     *     
     */
    public NaturalPersonInputType getNaturlPersn() {
        return naturlPersn;
    }

    /**
     * Sets the value of the naturlPersn property.
     * 
     * @param value
     *     allowed object is
     *     {@link NaturalPersonInputType }
     *     
     */
    public void setNaturlPersn(NaturalPersonInputType value) {
        this.naturlPersn = value;
    }

    public boolean isSetNaturlPersn() {
        return (this.naturlPersn!= null);
    }

    /**
     * Gets the value of the legalEntty property.
     * 
     * @return
     *     possible object is
     *     {@link LegalEntityInputType }
     *     
     */
    public LegalEntityInputType getLegalEntty() {
        return legalEntty;
    }

    /**
     * Sets the value of the legalEntty property.
     * 
     * @param value
     *     allowed object is
     *     {@link LegalEntityInputType }
     *     
     */
    public void setLegalEntty(LegalEntityInputType value) {
        this.legalEntty = value;
    }

    public boolean isSetLegalEntty() {
        return (this.legalEntty!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("custData", custData).add("naturlPersn", naturlPersn).add("legalEntty", legalEntty).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(custData, naturlPersn, legalEntty);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final CustomerCharacteristicsDataInputType o = ((CustomerCharacteristicsDataInputType) other);
        return ((Objects.equal(custData, o.custData)&&Objects.equal(naturlPersn, o.naturlPersn))&&Objects.equal(legalEntty, o.legalEntty));
    }

}
