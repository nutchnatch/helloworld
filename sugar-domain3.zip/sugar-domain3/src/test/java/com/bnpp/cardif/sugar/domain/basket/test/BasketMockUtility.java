package com.bnpp.cardif.sugar.domain.basket.test;

import java.util.UUID;

import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.collect.Lists;

/**
 * Utility class allowing to generate baskets for test purposes
 * 
 * @author Romain
 * 
 */
public class BasketMockUtility {
    public static final String SCOPE = "Syldavia";

    /**
     * Build a claim basket
     * 
     * @return the built claim folder
     */
    public static Basket buildClaimBasket() {
        Basket basket = new Basket();
        BasketId id = buildBasketId();
        basket.setBasketId(id);
        basket.setSymbolicName("Claim Basket Test");

        basket.getDisplayName().addAll(Lists.newArrayList(new MCOI18NLabel("Claim_Basket_Test", "EN"),
                new MCOI18NLabel("Claim_Corbeille_Test", "FR")));
        basket.setScope(SCOPE);
        return basket;
    }

    public static BasketId buildBasketId() {
        BasketId id = new BasketId();
        id.setValue(UUID.randomUUID().toString());
        id.setIssuer("CARDIF");
        id.setScheme("Sugar");
        return id;
    }
}
