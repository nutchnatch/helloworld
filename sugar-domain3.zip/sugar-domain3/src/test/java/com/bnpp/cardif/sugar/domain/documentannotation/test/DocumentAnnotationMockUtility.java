package com.bnpp.cardif.sugar.domain.documentannotation.test;

import java.util.UUID;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentAnnotationDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.DocumentAnnotation;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.Id;

/**
 * Utility class allowing to generate Document Annotations for test purposes
 * 
 * @author Romain
 * 
 */
public class DocumentAnnotationMockUtility {

    public static DocumentAnnotation buildSimpleDocumentAnnotation() {

        Id id = new Id();
        id.setValue(UUID.randomUUID().toString());
        id.setIssuer("CARDIF");
        id.setScheme("Sugar");
        DocumentAnnotationDataType data = new DocumentAnnotationDataType();
        data.setContent("<blaBlaDUBLA><XXML>RECORECO</XXML</blaBlaDUBLA>");
        data.setDocumentFileURI(UUID.randomUUID().toString());
        DocumentAnnotation fakeAnnotation = new DocumentAnnotation();
        fakeAnnotation.setId(id);
        fakeAnnotation.setData(data);
        return fakeAnnotation;
    }

}
