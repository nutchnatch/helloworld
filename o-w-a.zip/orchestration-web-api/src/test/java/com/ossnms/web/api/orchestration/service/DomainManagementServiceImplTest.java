package com.ossnms.web.api.orchestration.service;

import com.ossnms.web.api.arquillian.ArquillianTestBase;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
@RunWith(Arquillian.class)
public class DomainManagementServiceImplTest extends ArquillianTestBase {

    @Test
    @InSequence
    public void shouldInjectUrl(){
        assertNotNull(webAppUrl);
    }

    @Test
    @InSequence(10)
    public void shouldCreateNMSDomain(){
        DomainRTO domainParameter = new DomainRTO();

        domainParameter.setName("Domain 11");
        domainParameter.setOifTopologyType("FULL");
        domainParameter.setNmsInfoOrganization("Organization 1");
        domainParameter.setNmsInfoAddress("Address 1");
        Entity<DomainRTO> entity = Entity.entity(domainParameter, MediaType.APPLICATION_JSON_TYPE);

        Response response = post("orchestration/domain", entity);

        assertEquals(200, response.getStatus());
    }

    @Test
    @InSequence(20)
    public void shouldGetNMSDomain(){
        Response response = get("orchestration/domain/NMS-1");
        assertEquals(200, response.getStatus());
        DomainRTO domainRTO = response.readEntity(DomainRTO.class);

        assertEquals("Domain 11",       domainRTO.getName());
        assertEquals("Organization 1",  domainRTO.getNmsInfoOrganization());
        assertEquals("Address 1",       domainRTO.getNmsInfoAddress());
    }

    @Test
    @InSequence(21)
    public void shouldNotGetNMSDomain(){
        Response response = get("orchestration/domain/NMS-5");
        assertEquals(404, response.getStatus());
    }


    @Test
    @InSequence(22)
    public void shouldGetAllDomains(){
        Response response = get("orchestration/domain");
        assertEquals(200, response.getStatus());

        FetchResult<DomainRTO> domainRTOFetchResult = response.readEntity(new GenericType<FetchResult<DomainRTO>>() {});

        assertNotNull(domainRTOFetchResult);
        assertEquals(1, domainRTOFetchResult.getResultList().size());
    }
}
