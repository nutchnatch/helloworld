package com.ossnms.web.api.arquillian.mock;


import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.params.sort.SortDirection;
import com.ossnms.web.provider.common.api.result.ProcessableResult;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.result.enumerable.Status;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallID.Builder;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.common.attributes.TrafficParam;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointID;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;
import com.ossnms.web.provider.sdn.operations.call.ProcessableCallEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CallEntityOperationsMock implements ProcessableCallEntityOperations {

    private static final Logger LOGGER = LoggerFactory.getLogger(CallEntityOperationsMock.class);

    private Call.Builder getCallBuilder() {
        EndpointID.Builder endPointIdBuilder = new EndpointID.Builder("1", "1");
        EndpointSummary.Builder endPointSummary = new EndpointSummary.Builder(endPointIdBuilder.build());
        TrafficParam.Builder trafficParamBuilder = new TrafficParam.Builder();
        trafficParamBuilder.setSigType("SigType");
        trafficParamBuilder.setBandwidth("Bandwidth");
        trafficParamBuilder.setMultiplier("Multiplier");

        Call.Builder fakeCallBuilder = new Call.Builder(createCallId());
        fakeCallBuilder.setName("Service1");
        fakeCallBuilder.setAdminStatus("Active");
        fakeCallBuilder.setRestorable(Boolean.FALSE);
        fakeCallBuilder.setOrderNumber("Order Number");
        fakeCallBuilder.setRoutingOverNotReservedResourcesOnly(Boolean.FALSE);
        fakeCallBuilder.setCallConfigStatus("Config Status");
        fakeCallBuilder.setCallLatency(1);
        fakeCallBuilder.setCallProvisioningStatus("Provisioning Status");
        fakeCallBuilder.setDirectionality("Directionality");
        fakeCallBuilder.setEncoding(1);
        fakeCallBuilder.setNetworkSyncStatus("Networking Status");
        fakeCallBuilder.setOrderNumber("Order 1");
        fakeCallBuilder.setPathRequestId("Req-Id 1");
        fakeCallBuilder.setRoutingOverEnabledResourcesOnly(Boolean.FALSE);
        fakeCallBuilder.setRoutingOverExistingServicesOnly(Boolean.FALSE);
        fakeCallBuilder.setServiceLatency(Arrays.asList(new Long[]{1234L}));
        fakeCallBuilder.setSwitchingType(1);
        fakeCallBuilder.setAEnd(endPointSummary.build());
        fakeCallBuilder.setZEnd(endPointSummary.build());
        fakeCallBuilder.setTrafficParam(trafficParamBuilder.build());
        return fakeCallBuilder;
    }

    private CallSummary.Builder getCallSummaryBuilder() {
        EndpointID.Builder endPointIdBuilder = new EndpointID.Builder("1", "1");
        EndpointSummary.Builder endPointSummary = new EndpointSummary.Builder(endPointIdBuilder.build());
        TrafficParam.Builder trafficParamBuilder = new TrafficParam.Builder();
        trafficParamBuilder.setSigType("SigType");
        trafficParamBuilder.setBandwidth("Bandwidth");
        trafficParamBuilder.setMultiplier("Multiplier");

        CallSummary.Builder fakeCallBuilder = new CallSummary.Builder(createCallId());
        fakeCallBuilder.setName("Service1");
        fakeCallBuilder.setAEnd(endPointSummary.build());
        fakeCallBuilder.setZEnd(endPointSummary.build());
        return fakeCallBuilder;
    }

    private CallID createCallId() {
        return new Builder("1", "1").build();
    }


    @Override
    public ProcessableSingleResult<CallSummary, ErrorCode> getSummary(SecurityToken securityToken, CallID callID) {
        LOGGER.trace("getSummary, {}", callID);
        ProcessableSingleResult<Call, ErrorCode> details = getDetails(securityToken, callID);

        if (details.getEntity() == null) {
            return new ProcessableSingleResult.Builder<CallSummary, ErrorCode>()
                    .operationStatus(Status.NOT_FOUND)
                    .errorMessage("Could not find OIF call!")
                    .build();
        } else {
            return new ProcessableSingleResult.Builder<CallSummary, ErrorCode>()
                    .ok(details.getEntity())
                    .build();
        }
    }

    @Override
    public ProcessableSingleResult<Call, ErrorCode> getDetails(SecurityToken securityToken, CallID callID) {
        LOGGER.trace("getDetails, {}", callID);
        ProcessableResult<Call, CallField, ErrorCode> callSummaryList = getAll(securityToken, Collections.singletonList(callID));

        Call call = callSummaryList.getResultCollection()
                .stream()
                .findFirst()
                .orElse(null);

        if (call == null) {
            return new ProcessableSingleResult.Builder<Call, ErrorCode>()
                    .operationStatus(Status.NOT_FOUND)
                    .errorMessage("Could not find OIF call!")
                    .build();
        } else {
            return new ProcessableSingleResult.Builder<Call, ErrorCode>()
                    .ok(call)
                    .build();
        }
    }

    @Override
    public ProcessableResult<CallSummary, CallField, ErrorCode> getAllSummary(SecurityToken securityToken, Collection<CallID> collection) {

        LOGGER.trace("getAllSummary, {}", collection);

        ProcessableResult<Call, CallField, ErrorCode> all = getAll(securityToken, collection);

        List<CallSummary> summaries = all.getResultCollection().stream()
                .map(call -> (CallSummary) call)
                .collect(Collectors.toList());

        return OperationHelper.getProcessableResult(summaries, null, Collections.emptyList(), null);
    }

    @Override
    public ProcessableResult<CallSummary, CallField, ErrorCode> getAllSummary(SecurityToken securityToken, Collection<Filter<CallField>> collection, Sort<CallField> sort, Page page) {

        LOGGER.trace("getAllSummary, {}", collection);

        ProcessableResult<Call, CallField, ErrorCode> all = getAll(securityToken, collection, sort, page);

        List<CallSummary> summaries = all.getResultCollection().stream()
                .map(call -> (CallSummary) call)
                .collect(Collectors.toList());

        return OperationHelper.getProcessableResult(summaries, all.getSortBy(), collection, all.getPage());
    }

    @Override
    public ProcessableResult<Call, CallField, ErrorCode> getAll(SecurityToken securityToken, Collection<CallID> collection) {

        LOGGER.trace("getAll, {}", collection);

        Map<String, CallID> idsToFilter = collection.stream()
                .collect(Collectors.toMap(callId -> callId.getDomainId() + "-" + callId.getID(), Function.identity()));

        ProcessableResult<Call, CallField, ErrorCode> callList =
                getAll(securityToken, Collections.emptyList(), null, null);

        List<Call> resultCallList = callList.getResultCollection().stream()
                .filter(item -> idsToFilter.get(item.getID().getDomainId() + "-" + item.getID().getID()) != null)
                .collect(Collectors.toList());

        return OperationHelper.getProcessableResult(resultCallList, null, Collections.emptyList(), null);
    }

    @Override
    public ProcessableResult<Call, CallField, ErrorCode> getAll(SecurityToken securityToken, Collection<Filter<CallField>> collection, Sort<CallField> sort, Page page) {

        Call call;
        List<Call> callList;
        Page thisPage;
        Sort<CallField> thisSort;

        if(collection.stream().anyMatch(filter -> filter.getField().equals(CallField.NAME) && filter.getValue().equals("NOT EXISTANT"))){
            callList = Collections.emptyList();
        } else {
            call = getCallBuilder().build();
            callList = new ArrayList<>(Collections.singletonList(call));
        }

        thisPage = new Page.Builder(1, 1).build();
        thisSort = new Sort.Builder<>(CallField.NAME, SortDirection.ASC).build();

        return OperationHelper.getProcessableResult(callList, thisSort, collection, thisPage);
    }


    @Override
    public ProcessableResult<CallID, CallField, ErrorCode> getAllIds(SecurityToken securityToken, Collection<Filter<CallField>> collection, Sort<CallField> sort, Page page) {

        ProcessableResult<Call, CallField, ErrorCode> all = getAll(securityToken, collection, sort, page);

        List<CallID> idsList = all.getResultCollection().stream()
                .map(CallSummary::getID)
                .collect(Collectors.toList());

        return OperationHelper.getProcessableResult(idsList, all.getSortBy(), collection, all.getPage());
    }


    @Override
    public ProcessableSingleResult<Call, ErrorCode> insert(SecurityToken securityToken, Call call) {



        return new ProcessableSingleResult.Builder<Call, ErrorCode>()
                .errorCode(ErrorCode.GENERIC)
                .operationStatus(Status.SERVER_ERROR)
                .errorMessage("Already exists")
                .build();
    }


    @Override
    public ProcessableSingleResult<Call, ErrorCode> update(SecurityToken securityToken, Call call) {
        ProcessableSingleResult<Call, ErrorCode> details = getDetails(securityToken, call.getID());

        if (details.getEntity() == null) {
            return new ProcessableSingleResult.Builder<Call, ErrorCode>()
                    .operationStatus(Status.NOT_FOUND)
                    .errorMessage("Could not find service")
                    .build();
        } else {
            return new ProcessableSingleResult.Builder<Call, ErrorCode>()
                    .ok(call)
                    .build();
        }
    }


    @Override
    public ProcessableSingleResult<CallID, ErrorCode> delete(SecurityToken securityToken, CallID callID) {

        ProcessableSingleResult<CallSummary, ErrorCode> summary = getSummary(securityToken, callID);

        if (summary.getEntity() == null) {

            return new ProcessableSingleResult.Builder<CallID, ErrorCode>()
                    .operationStatus(Status.NOT_FOUND)
                    .errorMessage("Could not find service")
                    .build();
        } else {

            return new ProcessableSingleResult.Builder<CallID, ErrorCode>()
                    .ok(summary.getEntity().getID())
                    .build();
        }
    }

    @Override
    public ProcessableSingleResult<CallID, ErrorCode> enforce(SecurityToken securityToken, CallID id) {

        ProcessableResult<CallSummary, CallField, ErrorCode> callSummaryList = getAllSummary(securityToken, Collections.singletonList(id));

        CallSummary callSummary = callSummaryList.getResultCollection().stream().findFirst().orElse(null);

        if (callSummary == null) {

            return new ProcessableSingleResult.Builder<CallID, ErrorCode>()
                    .operationStatus(Status.NOT_FOUND)
                    .errorMessage("Could not find service")
                    .build();
        } else {
            return new ProcessableSingleResult.Builder<CallID, ErrorCode>()
                    .ok(callSummary.getID())
                    .build();
        }

    }
}
