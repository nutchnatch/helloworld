package com.ossnms.web.api.arquillian.mock;

import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationService;
import com.ossnms.web.provider.sdn.api.annotation.Proxy;

import javax.enterprise.context.ApplicationScoped;
import java.util.Collection;

/**
 *
 */
@Proxy
@ApplicationScoped
public class ProxyNotificationService implements NotificationService {
    @Override
    public void subscribe(NotificationChannel channel, NotificationHandler handler) {

    }

    @Override
    public void unsubscribe(NotificationChannel channel, NotificationHandler handler) {

    }

    @Override
    public void subscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {

    }

    @Override
    public void unsubscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {

    }
}
