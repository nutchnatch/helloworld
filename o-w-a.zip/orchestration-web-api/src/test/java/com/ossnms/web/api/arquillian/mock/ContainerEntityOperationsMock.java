package com.ossnms.web.api.arquillian.mock;

import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.container.Container;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.service.operations.ContainerEntityOperations;

import javax.ejb.Local;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ossnms.web.provider.network.model.container.ContainerInfo.ADDRESS;
import static com.ossnms.web.provider.network.model.container.ContainerInfo.EXTERNAL_REFERENCE;
import static com.ossnms.web.provider.network.model.container.ContainerInfo.FAX;
import static com.ossnms.web.provider.network.model.container.ContainerInfo.ORGANIZATION;
import static com.ossnms.web.provider.network.model.container.ContainerInfo.PHONE;
import static com.ossnms.web.provider.network.model.container.ContainerInfo.URL;

/**
 *
 */
@Stateless(name = "ContainerEntityOperations")
@Local(ContainerEntityOperations.class)
public class ContainerEntityOperationsMock implements ContainerEntityOperations {

    private static Long index = 0L;
    private static final List<Container> containers = new ArrayList<>();

    @Override
    public ContainerID insert(SecurityToken securityToken, Container entity) {
        if(containers.stream().anyMatch(container -> container.getName().equals(entity.getName()))) {
            return null;
        }

        ContainerID containerID = new ContainerID.Builder(++index).build();

        Container container = createContainer(entity, containerID);
        containers.add(container);
        return containerID;
    }

    /**
     *
     * @param entity
     * @param containerID
     * @return
     */
    private Container createContainer(Container entity, ContainerID containerID) {
        return new Container.Builder(containerID)
                    .name(entity.getName())
                    .serviceLevel(entity.getServiceLevel())
                    .parentContainerId(entity.getParentContainerId())
                    .containerType(entity.getContainerType())
                    .putInfo(ADDRESS, entity.getInfo().get(ADDRESS))
                    .putInfo(ORGANIZATION, entity.getInfo().get(ORGANIZATION))
                    .putInfo(EXTERNAL_REFERENCE, entity.getInfo().get(EXTERNAL_REFERENCE))
                    .putInfo(PHONE, entity.getInfo().get(PHONE))
                    .putInfo(FAX, entity.getInfo().get(FAX))
                    .putInfo(URL, entity.getInfo().get(URL))
                    .putInfo(EXTERNAL_REFERENCE, entity.getInfo().get(EXTERNAL_REFERENCE))
                    .build();
    }

    @Override
    public ContainerID update(SecurityToken securityToken, Container entity) {
        return null;
    }

    @Override
    public void delete(SecurityToken securityToken, ContainerID id) {
        List<Container> collect = containers.stream().filter(container -> container.getID().equals(id)).collect(Collectors.toList());
        containers.removeAll(collect);
    }

    @Override
    public ContainerSummary getSummary(SecurityToken securityToken, ContainerID id) {
        Optional<Container> first = containers.stream().filter(container -> container.getID().getId() == id.getId()).findFirst();

        return first.isPresent() ? new ContainerSummary.Builder(first.get().getID()).build() : null;
    }

    @Override
    public Container getDetails(SecurityToken securityToken, ContainerID id) {
        Optional<Container> first = containers.stream().filter(container -> container.getID().equals(id)).findFirst();

        return first.isPresent() ? first.get() : null;
    }

    @Override
    public OperationResult<ContainerSummary, ContainerField> getAllSummary(SecurityToken securityToken, Collection<ContainerID> ids) {
        List<ContainerSummary> containerSummaries = new ArrayList<>();

        ids.forEach(id -> {
            ContainerSummary summary = getSummary(securityToken, id);

            if (null != summary) {
                containerSummaries.add(summary);
            }
        });

        return new OperationResult.Builder<ContainerSummary, ContainerField>(containerSummaries, containerSummaries.size()).build();
    }

    @Override
    public OperationResult<ContainerSummary, ContainerField> getAllSummary(SecurityToken securityToken, Collection<Filter<ContainerField>> filterBy, Sort<ContainerField> sortBy, Page page) {
        List<ContainerSummary> containerSummaries = containers.stream()
                .map(container -> new ContainerSummary.Builder(container.getID()).build()).collect(Collectors.toList());

        return new OperationResult.Builder<ContainerSummary, ContainerField>(containerSummaries, containerSummaries.size()).build();
    }

    @Override
    public OperationResult<Container, ContainerField> getAll(SecurityToken securityToken, Collection<ContainerID> ids) {
        List<Container> collected = containers.stream().filter(container -> ids.contains(container.getID())).collect(Collectors.toList());

        return new OperationResult.Builder<Container, ContainerField>(collected, collected.size()).build();
    }

    @Override
    public OperationResult<Container, ContainerField> getAll(SecurityToken securityToken, Collection<Filter<ContainerField>> filterBy, Sort<ContainerField> sortBy, Page page) {
        // TODO change method to use sorting, pagination and filtering.
        return new OperationResult.Builder<Container, ContainerField>(containers, containers.size()).build();
    }

    @Override
    public OperationResult<ContainerID, ContainerField> getAllIds(SecurityToken securityToken, Collection<Filter<ContainerField>> filterBy, Sort<ContainerField> sortBy, Page page) {
        // TODO change method to use sorting, pagination and filtering.
        List<ContainerID> collected = containers.stream().map(ContainerSummary::getID).collect(Collectors.toList());

        return new OperationResult.Builder<ContainerID, ContainerField>(collected, collected.size()).build();
    }

    @Override
    public ContainerID assignToContainer(SecurityToken token, ContainerID container, PathID path) {
        return null;
    }

    @Override
    public ContainerID assignToContainer(SecurityToken token, ContainerID container, String pathName) {
        return null;
    }
}
