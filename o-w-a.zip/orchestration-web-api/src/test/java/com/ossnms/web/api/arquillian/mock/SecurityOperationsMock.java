package com.ossnms.web.api.arquillian.mock;

import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.api.params.Permission;
import com.ossnms.web.provider.security.api.result.PermissionReply;
import com.ossnms.web.provider.security.model.VersionInformation;
import com.ossnms.web.provider.security.operations.SecurityOperations;

/**
 *
 */
public class SecurityOperationsMock implements SecurityOperations {

    @Override
    public SecurityToken login(String username, String password, String sourceAddress) {
        return null;
    }

    @Override
    public SecurityToken validateToken(String token) {
        return null;
    }

    @Override
    public SecurityToken validateToken(SecurityToken securityToken) {
        return null;
    }

    @Override
    public void logout(SecurityToken securityToken) {

    }

    @Override
    public VersionInformation getVersionInformation(SecurityToken securityToken) {
        return null;
    }

    @Override
    public PermissionReply hasPermission(SecurityToken securityToken, Permission... permission) {
        return null;
    }
}
