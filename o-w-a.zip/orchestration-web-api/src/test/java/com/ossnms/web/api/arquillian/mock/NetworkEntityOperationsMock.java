package com.ossnms.web.api.arquillian.mock;

import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkField;
import com.ossnms.web.provider.sdn.model.network.NetworkID;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;
import com.ossnms.web.provider.sdn.operations.network.NetworkEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import java.util.Collection;

/**
 *
 */
@Stateless(name = "NetworkEntityOperations")
@Local(NetworkEntityOperations.class)
public class NetworkEntityOperationsMock implements NetworkEntityOperations{

    private static final Logger LOGGER = LoggerFactory.getLogger(CallEntityOperationsMock.class);

    @Override
    public NetworkID insert(SecurityToken securityToken, Network entity) {
        LOGGER.trace(">> insert");
        return null;
    }

    @Override
    public NetworkID update(SecurityToken securityToken, Network entity) {
        LOGGER.trace(">> update");
        return null;
    }

    @Override
    public void delete(SecurityToken securityToken, NetworkID id) {
        LOGGER.trace(">> delete");

    }

    @Override
    public NetworkSummary getSummary(SecurityToken securityToken, NetworkID id) {
        return null;
    }

    @Override
    public Network getDetails(SecurityToken securityToken, NetworkID id) {
        return null;
    }

    @Override
    public OperationResult<NetworkSummary, NetworkField> getAllSummary(SecurityToken securityToken, Collection<NetworkID> ids) {
        return null;
    }

    @Override
    public OperationResult<NetworkSummary, NetworkField> getAllSummary(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        return null;
    }

    @Override
    public OperationResult<Network, NetworkField> getAll(SecurityToken securityToken, Collection<NetworkID> ids) {
        return null;
    }

    @Override
    public OperationResult<Network, NetworkField> getAll(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        return null;
    }

    @Override
    public OperationResult<NetworkID, NetworkField> getAllIds(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        return null;
    }
}
