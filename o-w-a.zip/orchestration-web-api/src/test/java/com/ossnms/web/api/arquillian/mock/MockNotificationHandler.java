package com.ossnms.web.api.arquillian.mock;

import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;

import javax.enterprise.context.ApplicationScoped;

/**
 *
 */
@ApplicationScoped
public class MockNotificationHandler implements NotificationHandler{
    @Override
    public void handle(Notification notification) throws NotificationHandlerException {

    }
}
