package com.ossnms.web.api.arquillian;

import com.ossnms.web.api.arquillian.mock.NetworkEntityOperationsMock;
import com.ossnms.web.api.orchestration.common.lookup.RemoteLookup;
import com.ossnms.web.api.orchestration.domain.service.DomainManagementServiceImpl;
import com.ossnms.web.api.orchestration.service.service.ServiceManagementServiceImpl;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 *
 */
public class ArquillianTestBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(ArquillianTestBase.class);

    private static final Set<Class<?>> classes;
    static {
        classes = new HashSet<>();

        // resource classes
        classes.add(DomainManagementServiceImpl.class);
        classes.add(ServiceManagementServiceImpl.class);
        classes.add(NetworkEntityOperationsMock.class);
    }

    /**
     * Method the will return the test version of the Customer Portal Rest API.
     *
     * @return
     */
    @Deployment(testable = false)
    public static WebArchive createArchive(){
        return ShrinkWrap.create(WebArchive.class)
                .addClass(BaseApplication.class)
                // add required packages
                .addPackages(true, "com.ossnms.web.api.orchestration")
                .addPackages(true, "com.ossnms.web.api.arquillian")
                // delete classes not eligible for test mode
                .deleteClass(RemoteLookup.class)
                // add resources
                .addAsWebInfResource("web.xml")
                .addAsWebInfResource("beans.xml")
                .addAsResource("log4j.xml");
    }

    /**
     * URL that holds the base address where the API was deployed
     */
    @ArquillianResource
    protected URL webAppUrl;

    /**
     *
     */
    @ApplicationPath("")
    public static class BaseApplication extends Application {
        @Override
        public Set<Class<?>> getClasses() {
            return classes;
        }
    }

    /**
     *
     * @param target
     */
    protected Response get(String target) {
        LOGGER.info("GET >> {} @ {}", webAppUrl, target);

        return ClientBuilder
                .newClient()
                .target(webAppUrl + target)
                .request()
                .get();
    }

    /**
     *
     * @param target
     * @param entity
     * @return
     */
    protected Response post(String target, Entity<?> entity) {
        LOGGER.info("POST >> {} @ {}", webAppUrl, target);

        return ClientBuilder
              .newClient()
              .target(webAppUrl + target)
              .request()
              .post(entity);
    }

    /**
     *
     * @param target
     * @param entity
     * @return
     */
    protected Response put(String target, Entity<?> entity) {
        LOGGER.info("PUT >> {} @ {}", webAppUrl, target);

        return ClientBuilder
              .newClient()
              .target(webAppUrl + target)
              .request()
              .put(entity);
    }

    /**
     *
     * @param target
     * @return
     */
    protected Response delete(String target) {
        LOGGER.info("DELETE >> {} @ {}", webAppUrl, target);

        return ClientBuilder
              .newClient()
              .target(webAppUrl + target)
              .request()
              .delete();
    }
}