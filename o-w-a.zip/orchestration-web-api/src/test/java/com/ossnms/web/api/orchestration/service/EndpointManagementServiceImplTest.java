package com.ossnms.web.api.orchestration.service;

import com.ossnms.web.api.arquillian.ArquillianTestBase;
import com.ossnms.web.api.orchestration.endpoint.api.service.EndpointManagementService;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.inject.Inject;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

/**
 *
 */
@RunWith(Arquillian.class)
public class EndpointManagementServiceImplTest extends ArquillianTestBase {

    @Inject
    private EndpointManagementService service;

    @Test
    @InSequence
    public void shouldInject() {
        assertNotNull(service);
        assertNull(service.get("123"));
    }

}
