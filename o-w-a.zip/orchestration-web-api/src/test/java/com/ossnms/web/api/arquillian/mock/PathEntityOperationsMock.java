package com.ossnms.web.api.arquillian.mock;


import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.params.sort.SortDirection;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.fault.Alarm;
import com.ossnms.web.provider.network.model.fault.enumerable.AlarmSeverity;
import com.ossnms.web.provider.network.model.path.Path;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;
import com.ossnms.web.provider.network.model.path.enumerable.PathStatus;
import com.ossnms.web.provider.network.model.path.enumerable.PathType;
import com.ossnms.web.provider.service.operations.PathEntityOperations;

import javax.ejb.Local;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Stateless(name = "PathEntityOperations")
@Local(PathEntityOperations.class)
public class PathEntityOperationsMock implements PathEntityOperations {
    @Override
    public OperationResult<Path, PathField> getPaths(SecurityToken securityToken, ContainerID containerID, Page page, Sort<PathField> sort, Collection<Filter<PathField>> collection) {
        return null;
    }

    @Override
    public List<Alarm> getPathAlarms(SecurityToken token, PathID pathID, boolean endpointsOnly, boolean extended) {
        return null;
    }

    @Override
    public PathID insert(SecurityToken securityToken, Path path) {
        return null;
    }

    @Override
    public PathID update(SecurityToken securityToken, Path path) {
        return null;
    }

    @Override
    public void delete(SecurityToken securityToken, PathID pathID) {

    }

    @Override
    public PathSummary getSummary(SecurityToken securityToken, PathID pathID) {
        return null;
    }

    @Override
    public Path getDetails(SecurityToken securityToken, PathID pathID) {

        ArrayList<PathID> listPathID = new ArrayList<>();
        listPathID.add(pathID);

        OperationResult<Path, PathField> result = getAll(securityToken, listPathID);

        return result.getResultCollection().stream().findFirst().orElse(null);
    }

    @Override
    public OperationResult<PathSummary, PathField> getAllSummary( SecurityToken securityToken, Collection<PathID> collection ) {

        Map<String, PathID> idsToFilter = collection.stream()
              .collect( Collectors.toMap( pathId -> pathId.getPathType().name() + "-" + pathId.getId(), Function.identity() ) );

        OperationResult<PathSummary, PathField> allSummary = getAllSummary( securityToken, Collections.emptyList(), null, null );

        List<PathSummary> resultPathList = allSummary.getResultCollection().stream()
              .filter( item -> idsToFilter.get( item.getID().getPathType() + "-" + item.getID().getId() ) != null )
              .collect( Collectors.toList() );

        return new OperationResult.Builder<PathSummary,PathField>( resultPathList, resultPathList.size() ).build();
    }

    @Override
    public OperationResult<PathSummary, PathField> getAllSummary(SecurityToken securityToken, Collection<Filter<PathField>> collection, Sort<PathField> sort, Page page) {

        PathSummary pathSummary = getPathSummaryBuilder().build();
        List<PathSummary> pathSummaryList = new ArrayList<>(Collections.singletonList(pathSummary));
        Page thisPage = new Page.Builder(1, 1).build();
        Sort<PathField> thisSort = new Sort.Builder<>(PathField.A_NODE, SortDirection.ASC).build();

        return OperationHelper.getOperationResult(pathSummaryList, thisSort, collection, thisPage);
    }

    @Override
    public OperationResult<Path, PathField> getAll(SecurityToken securityToken, Collection<PathID> collection) {

        Map<String, PathID> servicesFromSDN =
                collection.stream()
                        .collect(Collectors.toMap(pathId -> pathId.getPathType().getName() + "-" + pathId.getId(), Function.identity()));

        Path path = getPathBuilder().build();
        List<Path> pathList = new ArrayList<>(Collections.singletonList(path));


        List<Path> resultPathList = pathList.stream().filter(item -> servicesFromSDN.get(item.getID().getPathType().getName()+ "-" + item.getID().getId()) != null)
                .collect(Collectors.toList());

        return OperationHelper.getOperationResult(resultPathList, null, Collections.emptyList(), null);
    }

    @Override
    public OperationResult<Path, PathField> getAll(SecurityToken securityToken, Collection<Filter<PathField>> collection, Sort<PathField> sort, Page page) {

        List<Path> pathList;

        if(collection.stream().anyMatch(filter -> filter.getField().equals(PathField.NAME) && filter.getValue().equals("NOT EXISTANT"))){
            pathList = Collections.emptyList();
        } else {
            Path path = getPathBuilder().build();
            pathList = new ArrayList<>(Collections.singletonList(path));
        }

        Page thisPage = new Page.Builder(1, 1).build();
        Sort<PathField> thisSort = new Sort.Builder<>(PathField.A_NODE, SortDirection.ASC).build();

        return OperationHelper.getOperationResult(pathList, thisSort, collection, thisPage);
    }

    private Path.Builder getPathBuilder() {
        Path.Builder fakePathBuilder = new Path.Builder(createPathId());
        fakePathBuilder.name("Service1");
        fakePathBuilder.pathStatus(PathStatus.UNKNOWN);
        fakePathBuilder.pathSubType("Path-SubType");
        fakePathBuilder.alarmSeverity(AlarmSeverity.MINOR);
        fakePathBuilder.operationalState(OperationalState.DISABLED);
        return fakePathBuilder;
    }

    private PathSummary.Builder getPathSummaryBuilder() {

        PathSummary.Builder fakePathSummaryBuilder = new PathSummary.Builder(createPathId());

        fakePathSummaryBuilder.name("Service1");
        fakePathSummaryBuilder.pathStatus(PathStatus.UNKNOWN);
        fakePathSummaryBuilder.pathSubType("Path-SubType");
        return fakePathSummaryBuilder;
    }

    private PathID createPathId() {
        return new PathID.Builder(1L, PathType.PATH).build();
    }

    @Override
    public OperationResult<PathID, PathField> getAllIds(SecurityToken securityToken, Collection<Filter<PathField>> collection, Sort<PathField> sort, Page page) {


        List<PathID> resultPathList = getAll(securityToken, collection, sort, page).getResultCollection().stream()
                .map(item -> item.getID()).collect(Collectors.toList());

        return OperationHelper.getOperationResult(resultPathList, null, Collections.emptyList(), null);

    }
}
