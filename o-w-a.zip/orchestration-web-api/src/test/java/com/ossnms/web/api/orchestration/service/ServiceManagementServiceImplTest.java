package com.ossnms.web.api.orchestration.service;

import com.ossnms.web.api.arquillian.ArquillianTestBase;
import com.ossnms.web.api.orchestration.common.api.model.EndpointRTO;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;
import com.ossnms.web.api.orchestration.service.api.model.enumerable.ServiceType;
import com.ossnms.web.api.orchestration.service.api.model.packet.PacketServiceRTO;
import com.ossnms.web.api.orchestration.service.api.model.packet.VirtualConnectionRTO;
import com.ossnms.web.api.orchestration.service.api.model.packet.enumerable.PacketServiceBaseType;
import com.ossnms.web.api.orchestration.service.api.model.packet.enumerable.PacketServiceType;
import com.ossnms.web.api.orchestration.service.api.model.packet.enumerable.VirtualConnectionType;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 *
 */
@RunWith(Arquillian.class)
public class ServiceManagementServiceImplTest extends ArquillianTestBase {

    private static final String OIF_LOCATION = "oif.location";

    @Test
    @InSequence
    public void shouldInjectUrl() {
        assertNotNull(webAppUrl);
    }

    @Before
    public void beforeTest() {
        System.setProperty(OIF_LOCATION, webAppUrl.toString());
    }

    @Test
    @InSequence(10)
    public void shouldGetMergedServices() {
        Response response = get("orchestration/service");

        FetchResult<ServiceRTO> fetchResult = response.readEntity(new FetchResultGenericType());

        assertNotNull(fetchResult);
        assertThat(fetchResult.getResultList().size(), is(1));
        fetchResult.getResultList();
    }

    @Test
    @InSequence(30)
    public void shouldCreate() {
        // create a new instance and set the parameters
        ServiceRTO service = new ServiceRTO();
        service.setName("NOT EXISTANT");

        EndpointRTO endpointA = new EndpointRTO();
        endpointA.setOifId(123L);
        endpointA.setOifName("Endpoint A");
        // set endpoint A
        service.setOifAEnd(endpointA);

        EndpointRTO endpointZ = new EndpointRTO();
        endpointZ.setOifId(122L);
        endpointZ.setOifName("Endpoint Z");
        // set endpoint Z
        service.setOifZEnd(endpointZ);

        Response post = post("orchestration/service", Entity.entity(service, MediaType.APPLICATION_JSON_TYPE));
        assertEquals(400, post.getStatus());
    }

    @Test
    @InSequence(31)
    public void shouldNotCreateAlreadyExists() {
        // create a new instance and keep it empty
        ServiceRTO service = new ServiceRTO();
        service.setName("Service Failing to create");

        Response post = post("orchestration/service", Entity.entity(service, MediaType.APPLICATION_JSON_TYPE));
        assertEquals(409, post.getStatus());
    }

    @Test
    @InSequence( 50 )
    public void shouldUpdate() {

        Response response = get( "orchestration/service" );
        FetchResult<ServiceRTO> fetchResult = response.readEntity( new FetchResultGenericType() );

        ServiceRTO service = fetchResult.getResultList().get( 0 );
        service.setOifAdminStatus( "Inactive" );
        Entity<ServiceRTO> entity = Entity.entity( service, MediaType.APPLICATION_JSON_TYPE );

        response = put( "orchestration/service/PATH-1", entity );

        ServiceRTO updatedService = response.readEntity( ServiceRTO.class );

        assertNotNull( response );
        assertEquals( Response.Status.OK.getStatusCode(), response.getStatus() );
    }


    @Test
    @InSequence( 51 )
    public void shouldNotUpdate() {

        Response response = put( "orchestration/service/PATH-999", Entity.entity( new ServiceRTO(), MediaType.APPLICATION_JSON_TYPE ) );

        assertNotNull( response );
        assertEquals( Response.Status.NOT_FOUND.getStatusCode(), response.getStatus() );
        assertEquals( null, response.getEntity() );
    }


    @Test
    @InSequence(60)
    public void shouldDelete() {

        Response response = delete("orchestration/service/PATH-1");

        assertNotNull(response);
        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());

    }

    @Test
    @InSequence(61)
    public void shouldNotDelete() {

        Response response = delete("orchestration/service/PATH-2");

        assertNotNull(response);
        assertEquals(Response.Status.NOT_FOUND.getStatusCode(), response.getStatus());
    }

    @Test
    @InSequence(100)
    public void shouldCreatePacketService() {

        PacketServiceRTO packetService = new PacketServiceRTO()
                .setCeVlan("2017")
                .setPacketServiceBaseType(PacketServiceBaseType.PORT)
                .setPacketServiceType(PacketServiceType.ELINE);

        VirtualConnectionRTO virtualConnectionRTO = new VirtualConnectionRTO()
                .setVirtualConnectionType(VirtualConnectionType.EVC);

        // create a new instance and set the parameters
        ServiceRTO service = new ServiceRTO();
        service.setName("Packet 001");
        service.setServiceType(ServiceType.PACKET);

        service.setPacketService(packetService);


        Response post = post("orchestration/service", Entity.entity(service, MediaType.APPLICATION_JSON_TYPE));
        assertEquals(400, post.getStatus());
    }

    @After
    public void afterTest() {
        System.clearProperty(OIF_LOCATION);
    }

    private static class FetchResultGenericType extends GenericType<FetchResult<ServiceRTO>> {
    }

}