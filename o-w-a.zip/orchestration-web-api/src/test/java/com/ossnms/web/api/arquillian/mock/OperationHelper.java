package com.ossnms.web.api.arquillian.mock;

import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.result.ProcessableResult;

import java.util.Collection;
import java.util.List;

public final class OperationHelper {

    public static <ENTITY extends EntityBase, FIELD extends Enum<FIELD>, ERROR_CODE extends Enum<ERROR_CODE>> ProcessableResult<ENTITY, FIELD, ERROR_CODE> getProcessableResult(
            List<ENTITY> list, Sort<FIELD> sort, Collection<Filter<FIELD>> filters, Page page){

        return new ProcessableResult.Builder<ENTITY, FIELD, ERROR_CODE>(list, 1)
                .setPage(page)
                .setFilterBy(filters)
                .setSortBy(sort)
                .setTotalFilteredElements(1)
                .build();
    }

    public static <ENTITY extends EntityBase, FIELD extends Enum<FIELD>> OperationResult<ENTITY, FIELD> getOperationResult(
            List<ENTITY> list, Sort<FIELD> sort, Collection<Filter<FIELD>> filters, Page page){

        return new OperationResult.Builder<ENTITY, FIELD>(list, 1)
                .setPage(page)
                .setFilterBy(filters)
                .setSortBy(sort)
                .setTotalFilteredElements(1)
                .build();
    }
}
