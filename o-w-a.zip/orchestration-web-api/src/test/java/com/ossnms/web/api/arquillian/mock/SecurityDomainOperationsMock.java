package com.ossnms.web.api.arquillian.mock;

import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.security.model.domain.SecurityDomain;
import com.ossnms.web.provider.security.model.domain.SecurityDomainID;
import com.ossnms.web.provider.security.model.domain.SecurityDomainSummary;
import com.ossnms.web.provider.security.model.domain.enumerable.SecurityDomainField;
import com.ossnms.web.provider.security.model.element.SecurableElementID;
import com.ossnms.web.provider.security.operations.domain.SecurityDomainOperations;

import javax.ejb.Local;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 *
 */
@Stateless(name = "SecurityDomainOperations")
@Local(SecurityDomainOperations.class)
public class SecurityDomainOperationsMock implements SecurityDomainOperations {

    private static Long index = 0L;
    private static final List<SecurityDomain> domains = new ArrayList<>();

    @Override
    public SecurableElementID assign(SecurityToken securityToken, SecurityDomainID domainID, SecurableElementID element) {

        Optional<SecurityDomain> first = domains.stream().filter(domain -> domain.getID().equals(domainID)).findFirst();

        if (first.isPresent()) {
            SecurityDomain securityDomain = first.get();

            int index = domains.indexOf(securityDomain);
            domains.set(index, new SecurityDomain.Builder(domainID)
                    .name(securityDomain.getName())
                    .description(securityDomain.getDescription())
                    .addSecurableElement(element)
                    .build());

            return element;
        }

        return null;
    }

    @Override
    public List<SecurableElementID> assign(SecurityToken securityToken, SecurityDomainID domainID, List<SecurableElementID> elements) {
        List<SecurableElementID> securableElementIDs = new ArrayList<>();

        elements.forEach(element -> {
            SecurableElementID securableElementID = assign(securityToken, domainID, element);

            if (null != securableElementID) {
                securableElementIDs.add(element);
            }
        });

        return securableElementIDs;
    }

    @Override
    public SecurityDomain getDetailsByName(SecurityToken securityToken, String s) {
        Optional<SecurityDomain> first = domains.stream().filter(domain -> domain.getName().equals(s)).findFirst();

        return first.isPresent() ? first.get() : null;
    }

    @Override
    public SecurityDomainID insert(SecurityToken securityToken, SecurityDomain entity) {
        if(domains.stream().anyMatch(container -> container.getName().equals(entity.getName()))) {
            return null;
        }

        SecurityDomainID securityDomainID = new SecurityDomainID.Builder(++index).build();

        SecurityDomain securityDomain = createSecurityDomain(entity, securityDomainID);
        domains.add(securityDomain);

        return securityDomainID;
    }

    private SecurityDomain createSecurityDomain(SecurityDomain entity, SecurityDomainID securityDomainID) {
        return new SecurityDomain.Builder(securityDomainID)
                .name(entity.getName())
                .description(entity.getDescription())
                .build();
    }

    @Override
    public SecurityDomainID update(SecurityToken securityToken, SecurityDomain entity) {
        return null;
    }

    @Override
    public void delete(SecurityToken securityToken, SecurityDomainID domainID) {
        Optional<SecurityDomain> domainToDelete = domains.stream().filter(domain -> domain.getID().equals(domainID)).findFirst();

        if (domainToDelete.isPresent()) {
            SecurityDomain securityDomain = domainToDelete.get();
            domains.remove(domains.indexOf(securityDomain));
        }
    }

    @Override
    public SecurityDomainSummary getSummary(SecurityToken securityToken, SecurityDomainID id) {
        Optional<SecurityDomain> first = domains.stream().filter(domain -> domain.getID().getId() == id.getId()).findFirst();

        if (first.isPresent()) {
            SecurityDomain securityDomain = first.get();

            return new SecurityDomainSummary.Builder(securityDomain.getID())
                    .name(securityDomain.getName())
                    .description(securityDomain.getDescription())
                    .build();
        }

        return null;
    }

    @Override
    public SecurityDomain getDetails(SecurityToken securityToken, SecurityDomainID id) {
        Optional<SecurityDomain> first = domains.stream().filter(domain -> domain.getID().getId() == id.getId()).findFirst();

        if (first.isPresent()) {
            return first.get();
        }

        return null;
    }

    @Override
    public OperationResult<SecurityDomainSummary, SecurityDomainField> getAllSummary(SecurityToken securityToken, Collection<SecurityDomainID> ids) {
        List<SecurityDomainSummary> securityDomainSummaryList = new ArrayList<>();

            ids.forEach(id -> {
                SecurityDomainSummary summary = getSummary(securityToken, id);

                if (null != summary) {
                    securityDomainSummaryList.add(summary);
                }
        });

        return new OperationResult.Builder<SecurityDomainSummary, SecurityDomainField>(securityDomainSummaryList, securityDomainSummaryList.size()).build();
    }

    @Override
    public OperationResult<SecurityDomainSummary, SecurityDomainField> getAllSummary(SecurityToken securityToken, Collection<Filter<SecurityDomainField>> filterBy, Sort<SecurityDomainField> sortBy, Page page) {
        List<SecurityDomainSummary> securityDomainSummaryList = new ArrayList<>();

        domains.forEach(domain -> securityDomainSummaryList
                .add(new SecurityDomainSummary.Builder(domain.getID()).name(domain.getName()).description(domain.getDescription()).build()));

        return new OperationResult.Builder<SecurityDomainSummary, SecurityDomainField>(securityDomainSummaryList, securityDomainSummaryList.size()).build();
    }

    @Override
    public OperationResult<SecurityDomain, SecurityDomainField> getAll(SecurityToken securityToken, Collection<SecurityDomainID> ids) {
        List<SecurityDomain> securityDomainList = new ArrayList<>();

        ids.forEach(id -> {
            SecurityDomain summary = getDetails(securityToken, id);

            if (null != summary) {
                securityDomainList.add(summary);
            }
        });

        return new OperationResult.Builder<SecurityDomain, SecurityDomainField>(securityDomainList, securityDomainList.size()).build();
    }

    @Override
    public OperationResult<SecurityDomain, SecurityDomainField> getAll(SecurityToken securityToken, Collection<Filter<SecurityDomainField>> filterBy, Sort<SecurityDomainField> sortBy, Page page) {
        // TODO change method to use sorting, pagination and filtering.
        return new OperationResult.Builder<SecurityDomain, SecurityDomainField>(domains, domains.size()).build();
    }

    @Override
    public OperationResult<SecurityDomainID, SecurityDomainField> getAllIds(SecurityToken securityToken, Collection<Filter<SecurityDomainField>> filterBy, Sort<SecurityDomainField> sortBy, Page page) {
        // TODO change method to use sorting, pagination and filtering.
        List<SecurityDomainID> securityDomainIDList = domains
                .stream().map(domain -> new SecurityDomainID.Builder(domain.getID().getId()).build())
                .collect(Collectors.toList());

        return new OperationResult.Builder<SecurityDomainID, SecurityDomainField>(securityDomainIDList, securityDomainIDList.size()).build();
    }
}
