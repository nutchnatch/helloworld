package com.ossnms.web.api.orchestration.service.service;

import com.ossnms.web.api.orchestration.common.api.factory.ResponseFactory;
import com.ossnms.web.api.orchestration.common.api.model.AlarmRTO;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.PageParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.SortParameter;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import com.ossnms.web.api.orchestration.service.api.exception.ServiceProviderException;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;
import com.ossnms.web.api.orchestration.service.api.provider.ServiceProvider;
import com.ossnms.web.api.orchestration.service.api.service.ServiceManagementService;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.network.model.path.enumerable.PathType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import java.util.List;

/**
 *
 */
public class ServiceManagementServiceImpl implements ServiceManagementService {
   /**
    *
    */
   private static final Logger LOGGER = LoggerFactory.getLogger( ServiceManagementServiceImpl.class );

   /**
    * Service provider instance
    */
   private ServiceProvider serviceProvider;

   /**
    * Default constructor
    */
   public ServiceManagementServiceImpl() {

   }

   /**
    * Default constructor
    */
   @Inject
   public ServiceManagementServiceImpl( ServiceProvider serviceProvider ) {
      this.serviceProvider = serviceProvider;
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public Response get( @BeanParam DetailsParameter detailsParameter,
                        @BeanParam PageParameter pageParameter,
                        @BeanParam SortParameter sortParameter,
                        @BeanParam FilterParameter filterParameter ) {
      LOGGER.debug( "GET Services call" );
      FetchResult<ServiceRTO> allPaths = serviceProvider.getAllPaths( detailsParameter, pageParameter, filterParameter, sortParameter );
      return ResponseFactory.ok( allPaths );
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public Response get( @PathParam( "id" ) String id ) {
      LOGGER.debug( "GET Service call >> id = {}", id );
      ServiceRTO serviceRTO = serviceProvider.getPathById( id );
      // if the service is null, we could not find the id specified
      if ( serviceRTO == null ) {
         return ResponseFactory.notFound();
      }
      return ResponseFactory.ok( serviceRTO );
   }

   @Override
   public Response getAlarms( @BeanParam PageParameter pageParameter,
                              @BeanParam SortParameter sortParameter,
                              @BeanParam FilterParameter filterParameter,
                              @PathParam( "id" ) String id ) {

      LOGGER.debug( "GET Service Alarms >> id = {}", id );

      List<AlarmRTO> alarmList = serviceProvider.getPathAlarms( id );

      // if the alarm list is null (empty is valid) then the path was not found
      if ( alarmList == null ) {
         return ResponseFactory.notFound();
      }
      return ResponseFactory.ok( alarmList );
   }

   @Override
   public Response enforce(@PathParam("id") String id) {
      LOGGER.debug( "ENFORCE Service call >> id = {}", id );
      PathID pathID = extractPathId( id );

      if ( pathID == null ) {
         return ResponseFactory.notFound();
      }

      try {
         serviceProvider.enforce(id );
         return ResponseFactory.ok();
      }
      catch ( ServiceProviderException e ) {
         LOGGER.error( e.toString(), e );
         return ResponseFactory.getErrorResponse( e.getErrorCode() );
      }
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public Response add( ServiceRTO service ) {
      LOGGER.debug( "CREATE Service call >> name = {}", service.getName() );

      try {
         ServiceRTO response = serviceProvider.create( service );
         return ResponseFactory.ok( response );

      } catch ( ServiceProviderException e ) {
         LOGGER.error( e.toString(), e );
         return ResponseFactory.getErrorResponse( e.getErrorCode() );
      }
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public Response update( @PathParam( "id" ) String id, ServiceRTO service ) {
      LOGGER.debug( "UPDATE Service call >> id = {}", id );

      PathID pathID = extractPathId( id );

      if ( pathID == null ) {
         return ResponseFactory.notFound();
      }

      // Enforce pathID
      service.setNmsPathType( pathID.getPathType().name() );
      service.setNmsId( pathID.getId() );

      try {
         ServiceRTO response = serviceProvider.update( service );
         return ResponseFactory.ok( response );
      } catch ( ServiceProviderException e ) {
         LOGGER.error( e.toString(), e );
         return ResponseFactory.getErrorResponse( e.getErrorCode() );
      }
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public Response delete( @PathParam( "id" ) String id ) {
      LOGGER.debug( "DELETE Service call >> id = {}", id );

      try {
         serviceProvider.delete( id );
         return ResponseFactory.ok();
      }
      catch ( ServiceProviderException e ) {
         LOGGER.error( e.toString(), e );
         return ResponseFactory.getErrorResponse( e.getErrorCode() );
      }
   }


   /**
    *
    * @param pathId
    * @return
    */
   private PathID extractPathId( String pathId ) {
      String[] pathString = pathId.split( "-" );
      if ( pathString.length != 2 ) {
         return null;
      }

      return new PathID.Builder( Long.parseLong( pathString[ 1 ] ), PathType.fromName( pathString[ 0 ] ) ).build();
   }
}