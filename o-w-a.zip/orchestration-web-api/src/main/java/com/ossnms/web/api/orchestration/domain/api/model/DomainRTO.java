package com.ossnms.web.api.orchestration.domain.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Arrays;
import java.util.Objects;

/**
 *
 */
@XmlRootElement(name="domain")
@XmlAccessorType(XmlAccessType.NONE)
@JsonSerialize(include= JsonSerialize.Inclusion.NON_NULL)
public class DomainRTO extends BaseRTO {

    @XmlID
    @XmlAttribute
    private String id;

    @XmlAttribute
    private String name;

    @XmlAttribute(name = "nms.id")
    private String nmsId;

    @XmlAttribute(name = "oif.id")
    private String oifId;

    @XmlAttribute
    private String oifTopologyType;

    @XmlAttribute
    private String [] oifProtocols;

    @XmlAttribute
    private String oifUserDomain;

    @XmlAttribute
    private String oifAdminState;

    @XmlAttribute
    private String nmsDescription;

    @XmlAttribute
    private String nmsServiceLevel;

    @XmlAttribute
    private String nmsInfoOrganization;

    @XmlAttribute
    private String nmsInfoContactPerson;

    @XmlAttribute
    private String nmsInfoAddress;

    @XmlAttribute
    private String nmsInfoPhone;

    @XmlAttribute
    private String nmsInfoFax;

    @XmlAttribute
    private String nmsInfoEmail;

    @XmlAttribute
    private String nmsInfoExternalReference;

    @XmlAttribute
    private String nmsInfoURL;

    @XmlAttribute
    private String dataSource;

    /**
     *
     */
    public String getNmsId() {
        return nmsId;
    }

    public DomainRTO setNmsId(String nmsId) {
        this.nmsId = nmsId;
        return this;
    }

    /**
     *
     */
    public String getOifId() {
        return oifId;
    }

    public DomainRTO setOifId(String oifId) {
        this.oifId = oifId;
        return this;
    }

    /**
     *
     * @return
     */
    public String[] getOifProtocols() {
        return oifProtocols;
    }

    /**
     *
     * @param oifProtocols
     * @return
     */
    public DomainRTO setOifProtocols(String[] oifProtocols) {
        if(oifProtocols != null) {
            this.oifProtocols = Arrays.copyOf(oifProtocols, oifProtocols.length);
        }
        return this;
    }

    /**
     *
     * @return
     */
    public String getOifUserDomain() {

        return oifUserDomain;
    }

    /**
     *
     * @param oifUserDomain
     */
    public DomainRTO setOifUserDomain( String oifUserDomain ) {
        this.oifUserDomain = oifUserDomain;

        return this;
    }

    /**
     *
     * @return
     */
    public String getDataSource() {
        return dataSource;
    }

    /**
     *
     * @param dataSource
     * @return
     */
    public DomainRTO setDataSource( String dataSource ) {

        this.dataSource = dataSource;

        return this;
    }

    /**
     *
     * @return
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     * @return
     */
    public DomainRTO setId(String id) {
        this.id = id;
        return this;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     * @return
     */
    public DomainRTO setName(String name) {
        this.name = name;
        return this;
    }

    /**
     *
     * @return
     */
    public String getOifTopologyType() {
        return oifTopologyType;
    }

    /**
     *
     * @param oifTopologyType
     * @return
     */
    public DomainRTO setOifTopologyType(String oifTopologyType) {
        this.oifTopologyType = oifTopologyType;
        return this;
    }

    /**
     *
     * @return
     */
    public String getOifAdminState() {
        return oifAdminState;
    }

    /**
     *
     * @param oifAdminState
     * @return
     */
    public DomainRTO setOifAdminState(String oifAdminState) {
        this.oifAdminState = oifAdminState;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsDescription() {
        return nmsDescription;
    }

    public DomainRTO setNmsDescription(String nmsDescription) {
        this.nmsDescription = nmsDescription;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsServiceLevel() {
        return nmsServiceLevel;
    }

    /**
     *
     * @param nmsServiceLevel
     * @return
     */
    public DomainRTO setNmsServiceLevel(String nmsServiceLevel) {
        this.nmsServiceLevel = nmsServiceLevel;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsInfoOrganization() {
        return nmsInfoOrganization;
    }

    /**
     *
     * @param nmsInfoOrganization
     * @return
     */
    public DomainRTO setNmsInfoOrganization(String nmsInfoOrganization) {
        this.nmsInfoOrganization = nmsInfoOrganization;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsInfoContactPerson() {
        return nmsInfoContactPerson;
    }

    /**
     *
     * @param nmsInfoContactPerson
     * @return
     */
    public DomainRTO setNmsInfoContactPerson(String nmsInfoContactPerson) {
        this.nmsInfoContactPerson = nmsInfoContactPerson;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsInfoAddress() {
        return nmsInfoAddress;
    }

    /**
     *
     * @param nmsInfoAddress
     * @return
     */
    public DomainRTO setNmsInfoAddress(String nmsInfoAddress) {
        this.nmsInfoAddress = nmsInfoAddress;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsInfoPhone() {
        return nmsInfoPhone;
    }

    /**
     *
     * @param nmsInfoPhone
     * @return
     */
    public DomainRTO setNmsInfoPhone(String nmsInfoPhone) {
        this.nmsInfoPhone = nmsInfoPhone;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsInfoFax() {
        return nmsInfoFax;
    }

    public DomainRTO setNmsInfoFax(String nmsInfoFax) {
        this.nmsInfoFax = nmsInfoFax;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsInfoEmail() {
        return nmsInfoEmail;
    }

    /**
     *
     * @param nmsInfoEmail
     * @return
     */
    public DomainRTO setNmsInfoEmail(String nmsInfoEmail) {
        this.nmsInfoEmail = nmsInfoEmail;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsInfoExternalReference() {
        return nmsInfoExternalReference;
    }

    /**
     *
     * @param nmsInfoExternalReference
     * @return
     */
    public DomainRTO setNmsInfoExternalReference(String nmsInfoExternalReference) {
        this.nmsInfoExternalReference = nmsInfoExternalReference;
        return this;
    }

    /**
     *
     * @return
     */
    public String getNmsInfoURL() {
        return nmsInfoURL;
    }

    /**
     *
     * @param nmsInfoURL
     * @return
     */
    public DomainRTO setNmsInfoURL(String nmsInfoURL) {
        this.nmsInfoURL = nmsInfoURL;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        DomainRTO domainRTO = (DomainRTO) o;
        return Objects.equals(getId(), domainRTO.getId()) &&
                Objects.equals(getNmsId(), domainRTO.getNmsId()) &&
                Objects.equals(getName(), domainRTO.getName()) &&
                Objects.equals(getOifId(), domainRTO.getOifId()) &&
                Objects.equals(getOifTopologyType(), domainRTO.getOifTopologyType()) &&
                Arrays.equals(getOifProtocols(), domainRTO.getOifProtocols()) &&
                Objects.equals(getOifUserDomain(), domainRTO.getOifUserDomain()) &&
                Objects.equals(getOifAdminState(), domainRTO.getOifAdminState()) &&
                Objects.equals(getNmsDescription(), domainRTO.getNmsDescription()) &&
                Objects.equals(getNmsServiceLevel(), domainRTO.getNmsServiceLevel()) &&
                Objects.equals(getNmsInfoOrganization(), domainRTO.getNmsInfoOrganization()) &&
                Objects.equals(getNmsInfoContactPerson(), domainRTO.getNmsInfoContactPerson()) &&
                Objects.equals(getNmsInfoAddress(), domainRTO.getNmsInfoAddress()) &&
                Objects.equals(getNmsInfoPhone(), domainRTO.getNmsInfoPhone()) &&
                Objects.equals(getNmsInfoFax(), domainRTO.getNmsInfoFax()) &&
                Objects.equals(getNmsInfoEmail(), domainRTO.getNmsInfoEmail()) &&
                Objects.equals(getNmsInfoExternalReference(), domainRTO.getNmsInfoExternalReference()) &&
                Objects.equals(getNmsInfoURL(), domainRTO.getNmsInfoURL()) &&
                Objects.equals(getDataSource(), domainRTO.getDataSource());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getNmsId(), getName(), getOifId(), getOifTopologyType(), getOifProtocols(), getOifUserDomain(), getOifAdminState(), getNmsDescription(), getNmsServiceLevel(), getNmsInfoOrganization(), getNmsInfoContactPerson(), getNmsInfoAddress(), getNmsInfoPhone(), getNmsInfoFax(), getNmsInfoEmail(), getNmsInfoExternalReference(), getNmsInfoURL(), getDataSource());
    }
}
