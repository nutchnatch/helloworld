package com.ossnms.web.api.orchestration.common.api.resources.outbound;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 */
public class Error implements Serializable {

    private static final long serialVersionUID = -6655183807390654388L;

    private String errorCode = "0";
    private String errorMessage;

    /**
     *
     * @param errorMessage
     */
    public Error(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     *
     * @param errorCode
     * @param errorMessage
     */
    public Error(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /**
     *
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     *
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        Error error = (Error) o;
        return Objects.equals(getErrorCode(), error.getErrorCode()) &&
                Objects.equals(getErrorMessage(), error.getErrorMessage());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getErrorCode(), getErrorMessage());
    }
}
