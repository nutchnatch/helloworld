package com.ossnms.web.api.orchestration.common.api.resources.inbound;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.DEFAULT_SORT;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.DEFAULT_SORT_DIRECTION;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.SORT;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.SORT_DIRECTION;

/**
 *
 */
public class SortParameter {

    @DefaultValue(DEFAULT_SORT)            @QueryParam(SORT)            private  String sortBy;
    @DefaultValue(DEFAULT_SORT_DIRECTION)  @QueryParam(SORT_DIRECTION)  private  SortDirections sortDirection;


    /**
     *
     */
    public SortParameter(){}

    /**
     * Constructor
     * @param sortBy sort by field
     * @param sortDirection sort direction
     */
    public SortParameter(String sortBy, SortDirections sortDirection) {
        this.sortBy = sortBy;
        this.sortDirection = sortDirection;
    }

    /**
     *
     * @return
     */
    public String getSortBy() {
        return sortBy;
    }

    /**
     *
     * @return
     */
    public SortDirections getSortDirection() {
        return sortDirection;
    }

    /**
     *
     * @return
     */
    public boolean isSortEmpty(){
        return sortBy.isEmpty();
    }

    /**
     *
     * @return
     */
    public String toString(){
        return String.format("Sort by %s, direction %s", sortBy, sortDirection);
    }
}
