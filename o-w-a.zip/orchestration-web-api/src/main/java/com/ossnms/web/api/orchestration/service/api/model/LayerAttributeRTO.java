package com.ossnms.web.api.orchestration.service.api.model;


import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import com.ossnms.web.api.orchestration.common.api.model.EndpointRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

/**
 *
 */
@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "layerAttribute" )
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class LayerAttributeRTO extends BaseRTO {

   private static final long serialVersionUID = -2050035812421700422L;

   @XmlAttribute
   private Integer layerId;

   @XmlAttribute
   private String portMode;

   @XmlAttribute
   private Integer switchingType;

   @XmlAttribute
   private Integer encoding;

   @XmlAttribute
   private Integer sigType;

   @XmlAttribute
   private Integer adaptation;

   @XmlAttribute
   private Long minBitrate;

   @XmlAttribute
   private Long maxBitrate;

   @XmlAttribute
   private EndpointRTO endpoint;

   @XmlAttribute
   private Boolean currentConfiguration;


   public Integer getLayerId() {

      return layerId;
   }

   public void setLayerId( Integer layerId ) {

      this.layerId = layerId;
   }

   public String getPortMode() {

      return portMode;
   }

   public void setPortMode( String portMode ) {

      this.portMode = portMode;
   }

   public Integer getSwitchingType() {

      return switchingType;
   }

   public void setSwitchingType( Integer switchingType ) {

      this.switchingType = switchingType;
   }

   public Integer getEncoding() {

      return encoding;
   }

   public void setEncoding( Integer encoding ) {

      this.encoding = encoding;
   }

   public Integer getSigType() {

      return sigType;
   }

   public void setSigType( Integer sigType ) {

      this.sigType = sigType;
   }

   public Integer getAdaptation() {

      return adaptation;
   }

   public void setAdaptation( Integer adaptation ) {

      this.adaptation = adaptation;
   }

   public Long getMinBitrate() {

      return minBitrate;
   }

   public void setMinBitrate( Long minBitrate ) {

      this.minBitrate = minBitrate;
   }

   public Long getMaxBitrate() {

      return maxBitrate;
   }

   public void setMaxBitrate( Long maxBitrate ) {

      this.maxBitrate = maxBitrate;
   }

   public EndpointRTO getEndpoint() {

      return endpoint;
   }

   public void setEndpoint( EndpointRTO endpoint ) {

      this.endpoint = endpoint;
   }

   public Boolean getCurrentConfiguration() {

      return currentConfiguration;
   }

   public void setCurrentConfiguration( Boolean currentConfiguration ) {

      this.currentConfiguration = currentConfiguration;
   }


   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      LayerAttributeRTO that = (LayerAttributeRTO) o;
      return Objects.equals( layerId, that.layerId ) &&
             Objects.equals( portMode, that.portMode ) &&
             Objects.equals( switchingType, that.switchingType ) &&
             Objects.equals( encoding, that.encoding ) &&
             Objects.equals( sigType, that.sigType ) &&
             Objects.equals( adaptation, that.adaptation ) &&
             Objects.equals( minBitrate, that.minBitrate ) &&
             Objects.equals( maxBitrate, that.maxBitrate ) &&
             Objects.equals( endpoint, that.endpoint ) &&
             Objects.equals( currentConfiguration, that.currentConfiguration );
   }

   @Override
   public int hashCode() {

      return Objects.hash( layerId, portMode, switchingType, encoding, sigType, adaptation, minBitrate, maxBitrate, endpoint, currentConfiguration );
   }
}