package com.ossnms.web.api.orchestration.common.constant;

/**
 *
 */
public final class OrchestrationConstants {

    public static final String URL_BASE_ORCHESTRATION = "/orchestration";
    public static final String URL_DOMAIN = URL_BASE_ORCHESTRATION + "/domain";
    public static final String URL_ENDPOINT = URL_BASE_ORCHESTRATION + "/endpoint";
    public static final String URL_SERVICE = URL_BASE_ORCHESTRATION + "/service";

    public static final String CONTEXT_ROOT = "";
    public static final String CONTEXT_ID = "/{dataSource}-{id}";

    public static final String DETAILS = "details";
    public static final String FALSE = "false";
    public static final String ID = "id";
    public static final String DATA_SOURCE = "dataSource";

    public static final String PAGE_SIZE = "size";
    public static final String PAGE = "page";
    public static final String DEFAULT_PAGE_SIZE = "10";
    public static final String DEFAULT_PAGE_NUMBER = "1";

    public static final String SORT = "sortBy";
    public static final String SORT_DIRECTION = "sortDirection";
    public static final String DEFAULT_SORT = "";
    public static final String DEFAULT_SORT_DIRECTION = "ASC";

    public static final String FILTER = "filterBy";
    public static final String DEFAULT_FILTER = "";

    public static final String SDN_PROVIDER_ID = "1";
    public static final String SDN_PROVIDER_NAME = "PROVIDER";

    private OrchestrationConstants() {}
}