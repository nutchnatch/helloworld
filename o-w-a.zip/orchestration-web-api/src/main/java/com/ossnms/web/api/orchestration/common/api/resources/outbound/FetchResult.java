package com.ossnms.web.api.orchestration.common.api.resources.outbound;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 */
@XmlRootElement(name="result")
@XmlAccessorType(XmlAccessType.NONE)
public class FetchResult<E extends BaseRTO> implements Serializable {

    private static final long serialVersionUID = -1497982548930841092L;

    @XmlElement
    private List<E> resultList = new ArrayList<>();

    @XmlAttribute
    private int page;

    @XmlAttribute
    private int pageSize;

    @XmlAttribute
    private int totalResults;

    @XmlAttribute
    private int totalFilteredResults;

    public int getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(int totalResults) {
        this.totalResults = totalResults;
    }

    public int getTotalFilteredResults() {
        return totalFilteredResults;
    }

    public void setTotalFilteredResults(int totalFilteredResults) {
        this.totalFilteredResults = totalFilteredResults;
    }

    /**
     *
     */
    public List<E> getResultList() {
        return resultList;
    }

    public FetchResult setResultList(List<E> resultList) {
        this.resultList = resultList;
        return this;
    }

    /**
     *
     */
    public int getPage() {
        return page;
    }

    public FetchResult setPage(int page) {
        this.page = page;
        return this;
    }

    /**
     *
     */
    public int getPageSize() {
        return pageSize;
    }

    public FetchResult setPageSize(int pageSize) {
        this.pageSize = pageSize;
        return this;
    }
}
