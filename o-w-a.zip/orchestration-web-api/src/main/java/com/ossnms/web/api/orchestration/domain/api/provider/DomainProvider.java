package com.ossnms.web.api.orchestration.domain.api.provider;

import com.ossnms.web.api.orchestration.domain.api.exception.DomainProviderException;
import com.ossnms.web.api.orchestration.common.api.DataSource;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.PageParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.SortParameter;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import com.ossnms.web.provider.network.model.container.ContainerID;

import javax.ws.rs.ext.Provider;
/**
 *
 */
@Provider
public interface DomainProvider {

    /**
     *
     * @return
     */
    FetchResult<DomainRTO> getAll(
            DetailsParameter detailsParameter,
            PageParameter pageParameter,
            SortParameter sortParameter,
            FilterParameter filterParameter);

    /**
     *
     * @param id
     * @return
     */
    DomainRTO get(String id, DataSource dataSource);

    /**
     *
     * @param containerID
     * @return
     */
    DomainRTO get(ContainerID containerID);

    /**
     *
     * @param domainRTO
     * @return
     */
    DomainRTO update(DomainRTO domainRTO) throws DomainProviderException;

    /**
     *
     * @param domainRTO
     * @return
     */
    DomainRTO create(DomainRTO domainRTO) throws DomainProviderException;

    /**
     *
     * @param dataSource
     * @param id
     */
    void delete(DataSource dataSource, String id) throws DomainProviderException;
}
