package com.ossnms.web.api.orchestration.service.api.model.packet.enumerable;

/**
 *
 */
public enum VirtualConnectionType {

    /**
     *
     */
    EVC,

    /**
     *
     */
    OVC

}
