package com.ossnms.web.api.orchestration.service.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

/**
 * Created by 68500245 on 31-01-2017.
 */
@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "routingFailureDetail" )
@JsonSerialize( include = JsonSerialize.Inclusion.NON_NULL )
public class ProtectionGroupRTO extends BaseRTO {

   private static final long serialVersionUID = 4239071707388450372L;

   @XmlAttribute
   private String id;

   @XmlAttribute
   private String protectionMode;

   @XmlAttribute
   private String protectionState;

   @XmlAttribute
   private String protectionType;

   @XmlAttribute
   private String restorationGate;

   public String getId() {

      return id;
   }

   public void setId( String id ) {

      this.id = id;
   }

   public String getProtectionMode() {

      return protectionMode;
   }

   public void setProtectionMode( String protectionMode ) {

      this.protectionMode = protectionMode;
   }

   public String getProtectionState() {

      return protectionState;
   }

   public void setProtectionState( String protectionState ) {

      this.protectionState = protectionState;
   }

   public String getProtectionType() {

      return protectionType;
   }

   public void setProtectionType( String protectionType ) {

      this.protectionType = protectionType;
   }

   public String getRestorationGate() {

      return restorationGate;
   }

   public void setRestorationGate( String restorationGate ) {

      this.restorationGate = restorationGate;
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      ProtectionGroupRTO that = (ProtectionGroupRTO) o;
      return Objects.equals( id, that.id ) &&
             Objects.equals( protectionMode, that.protectionMode ) &&
             Objects.equals( protectionState, that.protectionState ) &&
             Objects.equals( protectionType, that.protectionType ) &&
             Objects.equals( restorationGate, that.restorationGate );
   }

   @Override
   public int hashCode() {

      return Objects.hash( id, protectionMode, protectionState, protectionType, restorationGate );
   }
}