package com.ossnms.web.api.orchestration.common.api.factory;

import com.ossnms.web.api.orchestration.common.api.model.RiskRTO;
import com.ossnms.web.provider.sdn.model.common.attributes.Risk;

/**
 * Created by 68500245 on 21-12-2016.
 */
public final class RiskFactory {

   private RiskRTO riskRto = new RiskRTO();

   public RiskFactory from( Risk risk ) {

      riskRto.setDomainId( risk.getDomainId() );
      riskRto.setId( risk.getId() );
      riskRto.setName( risk.getName() );

      return this;
   }


   /**
    * @return
    */
   public RiskRTO build() {

      return riskRto;
   }
}