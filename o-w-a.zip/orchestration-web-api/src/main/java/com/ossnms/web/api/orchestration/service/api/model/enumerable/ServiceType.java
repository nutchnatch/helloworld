package com.ossnms.web.api.orchestration.service.api.model.enumerable;

/**
 *
 */
public enum ServiceType  {

    OPTICAL,
    PACKET

}
