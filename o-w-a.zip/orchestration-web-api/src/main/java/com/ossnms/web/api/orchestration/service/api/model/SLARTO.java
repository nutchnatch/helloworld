package com.ossnms.web.api.orchestration.service.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "sla")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class SLARTO extends BaseRTO {

    private static final long serialVersionUID = -4828434799920483861L;

    @XmlAttribute
    private Boolean monitoring;

    @XmlAttribute
    private Double throughput;

    @XmlAttribute
    private String callImpairmentStatus;

    @XmlAttribute
    private String callLastImpairmentStatusTimestamp;

    /**
     *
     */
    public Boolean isMonitoring() {
        return monitoring;
    }

    public SLARTO setMonitoring( Boolean monitoring ) {
        this.monitoring = monitoring;
        return this;
    }

    /**
     *
     */
    public Double getThroughput() {
        return throughput;
    }

    public SLARTO setThroughput(Double throughput) {
        this.throughput = throughput;
        return this;
    }

    /**
     *
     */
    public String getCallImpairmentStatus() {
        return callImpairmentStatus;
    }

    public SLARTO setCallImpairmentStatus(String callImpairmentStatus) {
        this.callImpairmentStatus = callImpairmentStatus;
        return this;
    }

    /**
     *
     */
    public String getCallLastImpairmentStatusTimestamp() {
        return callLastImpairmentStatusTimestamp;
    }

    public SLARTO setCallLastImpairmentStatusTimestamp(String callLastImpairmentStatusTimestamp) {
        this.callLastImpairmentStatusTimestamp = callLastImpairmentStatusTimestamp;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        SLARTO slarto = (SLARTO) o;
        return Objects.equals( isMonitoring(), slarto.isMonitoring()) &&
               Objects.equals(getThroughput(), slarto.getThroughput()) &&
               Objects.equals(getCallImpairmentStatus(), slarto.getCallImpairmentStatus()) &&
               Objects.equals(getCallLastImpairmentStatusTimestamp(), slarto.getCallLastImpairmentStatusTimestamp());
    }

    @Override
    public int hashCode() {
        return Objects.hash( isMonitoring(), getThroughput(), getCallImpairmentStatus(), getCallLastImpairmentStatusTimestamp());
    }
}