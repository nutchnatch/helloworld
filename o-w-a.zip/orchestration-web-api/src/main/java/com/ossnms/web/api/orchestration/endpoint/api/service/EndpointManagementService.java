package com.ossnms.web.api.orchestration.endpoint.api.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.URL_ENDPOINT;

/**
 *
 */
@Path(URL_ENDPOINT)
@Consumes({"application/xml", "application/json"})
@Produces({"application/xml", "application/json"})
public interface EndpointManagementService {

    /**
     *
     * @return
     */
    @GET
    @Path("")
    Response get();

    /**
     *
     * @param id
     * @return
     */
    @GET
    @Path("/{id}")
    Response get(@PathParam("id") String id);

    /**
     *
     * @return
     */
    @POST
    @Path("")
    Response add();

    /**
     *
     * @param id
     * @return
     */
    @PUT
    @Path("/{id}")
    Response update(@PathParam("id") String id);

    /**
     *
     * @param id
     */
    @DELETE
    @Path("/{id}")
    void delete(@PathParam("id") String id);

}
