package com.ossnms.web.api.orchestration.common.api.resources.inbound;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.DEFAULT_FILTER;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.FILTER;

/**
 *
 */
public class FilterParameter {

    @DefaultValue(DEFAULT_FILTER) @QueryParam(FILTER) private String filterBy;

    /**
     *
     */
    public FilterParameter() {
    }

    /**
     *
     * @param filterBy
     */
    public FilterParameter(String filterBy) {
        this.filterBy = filterBy;
    }

    /**
     *
     * @return
     */
    public String getFilterBy() {
        return filterBy;
    }

    /**
     *
     * @return
     */
    public boolean isFilterEmpty(){
        return filterBy.isEmpty();
    }

    /**
     *
     * @return
     */
    public String toString(){
        return "Filter parameter : \'" + filterBy + "\'";
    }
}
