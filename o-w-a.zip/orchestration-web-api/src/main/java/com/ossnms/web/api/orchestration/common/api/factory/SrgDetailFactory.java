package com.ossnms.web.api.orchestration.common.api.factory;

import com.ossnms.web.api.orchestration.common.api.model.RiskRTO;
import com.ossnms.web.api.orchestration.common.api.model.SrgDetailRTO;
import com.ossnms.web.provider.sdn.model.common.attributes.SrgDetail;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by 68500245 on 21-12-2016.
 */
public final class SrgDetailFactory {

   private SrgDetailRTO srgDetailRto = new SrgDetailRTO();

   /**
    *
    * @param srgDetails
    * @return
    */
   public static List<SrgDetailRTO> buildSrgDetailList( List<SrgDetail> srgDetails ) {

      List<SrgDetailRTO> srgDetailsRto = new ArrayList<>();

      if ( srgDetails != null ) {

         return srgDetails.stream()
               .map( srgDetail -> new SrgDetailFactory().from( srgDetail ).build() )
               .collect( Collectors.toList() );
      }

      return srgDetailsRto;
   }

   /**
    *
    * @param srgDetail
    * @return
    */
   public SrgDetailFactory from( SrgDetail srgDetail ) {

      if ( srgDetail != null ) {

         srgDetailRto.setRiskClass( srgDetail.getRiskClass() );
         srgDetailRto.setRiskStartTime( srgDetail.getRiskStartTime() );
         srgDetailRto.setRiskStopTime( srgDetail.getRiskStopTime() );
         srgDetailRto.setRiskClass( srgDetail.getRiskClass() );
         srgDetailRto.setRiskClass( srgDetail.getRiskClass() );

         List<RiskRTO> risks =
            srgDetail.getRisks().stream()
            .map( risk -> new RiskFactory().from( risk ).build() )
            .collect( Collectors.toList() );

         srgDetailRto.setRisks( risks );
      }

      return this;
   }


   /**
    * @return
    */
   public SrgDetailRTO build() {

      return srgDetailRto;
   }
}