package com.ossnms.web.api.orchestration.common.api;

import java.io.Serializable;

/**
 *
 */
public abstract class BaseRTO implements Serializable {
    private static final long serialVersionUID = 8316492640845324730L;
}
