package com.ossnms.web.api.orchestration.service.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import com.ossnms.web.api.orchestration.common.api.model.SrgDetailRTO;
import com.ossnms.web.api.orchestration.common.api.model.TrafficParamRTO;
import com.ossnms.web.api.orchestration.topology.api.model.EdgeEndRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Objects;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "connections")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ConnectionRTO extends BaseRTO {

    private static final long serialVersionUID = 7512668974668359846L;

    @XmlAttribute
    private String domainId;

    @XmlAttribute
    private String id;

    @XmlAttribute
    private String name;

    @XmlAttribute
    private EdgeEndRTO aEnd;

    @XmlAttribute
    private EdgeEndRTO zEnd;

    @XmlAttribute
    private TrafficParamRTO trafficParams;

    @XmlAttribute
    private String adminStatus;

    @XmlAttribute
    private String operStatus;

    @XmlAttribute
    private String provisioningStatus;

    @XmlAttribute
    private String networkSyncStatus;

    @XmlAttribute
    private Integer switchingType;

    @XmlAttribute
    private Integer encoding;

    @XmlAttribute
    private String directionality;

    @XmlAttribute
    private Long frequency;

    @XmlAttribute
    private Long freqSlotWidth;

    @XmlAttribute
    private ConnectionTopoComponentRTO topoComponent;

    @XmlAttribute
    private List<SrgDetailRTO> srgDetails;

    public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EdgeEndRTO getaEnd() {
        return aEnd;
    }

    public void setaEnd(EdgeEndRTO aEnd) {
        this.aEnd = aEnd;
    }

    public EdgeEndRTO getzEnd() {
        return zEnd;
    }

    public void setzEnd(EdgeEndRTO zEnd) {
        this.zEnd = zEnd;
    }

    public TrafficParamRTO getTrafficParams() {
        return trafficParams;
    }

    public void setTrafficParams(TrafficParamRTO trafficParams) {
        this.trafficParams = trafficParams;
    }

    public String getAdminStatus() {
        return adminStatus;
    }

    public void setAdminStatus(String adminStatus) {
        this.adminStatus = adminStatus;
    }

    public String getOperStatus() {
        return operStatus;
    }

    public void setOperStatus(String operStatus) {
        this.operStatus = operStatus;
    }

    public String getProvisioningStatus() {
        return provisioningStatus;
    }

    public void setProvisioningStatus(String provisioningStatus) {
        this.provisioningStatus = provisioningStatus;
    }

    public String getNetworkSyncStatus() {
        return networkSyncStatus;
    }

    public void setNetworkSyncStatus(String networkSyncStatus) {
        this.networkSyncStatus = networkSyncStatus;
    }

    public Integer getSwitchingType() {
        return switchingType;
    }

    public void setSwitchingType(Integer switchingType) {
        this.switchingType = switchingType;
    }

    public Integer getEncoding() {
        return encoding;
    }

    public void setEncoding(Integer encoding) {
        this.encoding = encoding;
    }

    public String getDirectionality() {
        return directionality;
    }

    public void setDirectionality(String directionality) {
        this.directionality = directionality;
    }

    public Long getFrequency() {
        return frequency;
    }

    public void setFrequency(Long frequency) {
        this.frequency = frequency;
    }

    public Long getFreqSlotWidth() {
        return freqSlotWidth;
    }

    public void setFreqSlotWidth(Long freqSlotWidth) {
        this.freqSlotWidth = freqSlotWidth;
    }

    public ConnectionTopoComponentRTO getTopoComponent() {
        return topoComponent;
    }

    public void setTopoComponent(ConnectionTopoComponentRTO topoComponent) {
        this.topoComponent = topoComponent;
    }

    public List<SrgDetailRTO> getSrgDetails() {
        return srgDetails;
    }

    public void setSrgDetails(List<SrgDetailRTO> srgDetails) {
        this.srgDetails = srgDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        ConnectionRTO that = (ConnectionRTO) o;
        return Objects.equals(domainId, that.domainId) &&
                Objects.equals(id, that.id) &&
                Objects.equals(name, that.name) &&
                Objects.equals(aEnd, that.aEnd) &&
                Objects.equals(zEnd, that.zEnd) &&
                Objects.equals(trafficParams, that.trafficParams) &&
                Objects.equals(adminStatus, that.adminStatus) &&
                Objects.equals(operStatus, that.operStatus) &&
                Objects.equals(provisioningStatus, that.provisioningStatus) &&
                Objects.equals(networkSyncStatus, that.networkSyncStatus) &&
                Objects.equals(switchingType, that.switchingType) &&
                Objects.equals(encoding, that.encoding) &&
                Objects.equals(directionality, that.directionality) &&
                Objects.equals(frequency, that.frequency) &&
                Objects.equals(freqSlotWidth, that.freqSlotWidth) &&
                Objects.equals(topoComponent, that.topoComponent) &&
                Objects.equals(srgDetails, that.srgDetails);
    }

    @Override
    public int hashCode() {
        return Objects.hash(domainId, id, name, aEnd, zEnd, trafficParams, adminStatus, operStatus, provisioningStatus, networkSyncStatus, switchingType, encoding, directionality, frequency, freqSlotWidth, topoComponent, srgDetails);
    }
}