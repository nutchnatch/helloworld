package com.ossnms.web.api.orchestration.topology.api.factory;

import com.ossnms.web.api.orchestration.topology.api.model.EdgeEndRTO;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndID;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndSummary;
import com.ossnms.web.provider.sdn.model.vertex.VertexSummary;

/**
 * Created by 68500245 on 20-12-2016.
 */
public final class EdgeEndFactory {

   private EdgeEndRTO edgeEnd = new EdgeEndRTO();

   /**
    *
    * @param edgeEndId
    * @return
    */
   public EdgeEndFactory from( EdgeEndID edgeEndId ) {

      if ( edgeEndId != null ) {

         edgeEnd.setOifId( Long.parseLong( edgeEndId.getID() ) );
         edgeEnd.setOifDomainId( Long.parseLong( edgeEndId.getDomainId() ) );
      }

      return this;
   }

   /**
    *
    * @param vertexSummary
    * @return
    */
   public EdgeEndFactory from( VertexSummary vertexSummary ) {

      edgeEnd.setOifVertex( new VertexFactory().from( vertexSummary ).build() );

      return this;
   }

   /**
    *
    * @param edgeEndSummary
    * @return
    */
   public EdgeEndFactory from( EdgeEndSummary edgeEndSummary ) {

      from( edgeEndSummary.getID() );

      edgeEnd.setOifName( edgeEndSummary.getName() );
      edgeEnd.setOifOperState( edgeEndSummary.getOperState() );
      edgeEnd.setOifOwnership( edgeEndSummary.getOwnership() );

      from( edgeEndSummary.getVertex() );

      return this;
   }

   /**
    *
    * @return
    */
   public EdgeEndRTO build() {

      return this.edgeEnd;
   }
}