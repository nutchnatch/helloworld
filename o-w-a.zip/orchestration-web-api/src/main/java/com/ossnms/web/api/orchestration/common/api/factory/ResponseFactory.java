package com.ossnms.web.api.orchestration.common.api.factory;

import com.ossnms.web.api.orchestration.common.api.resources.outbound.Error;
import com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode;

import javax.ws.rs.core.Response;
import java.io.Serializable;
import java.util.Collection;

/**
 *
 */
public final class ResponseFactory {

    /**
     *
     */
    private ResponseFactory() {}

    /**
     *
     * @param errorCode
     * @return
     */
    public static Response getErrorResponse(OrchestrationErrorCode errorCode){
        return Response
                .status(errorCode.getHttpStatus())
                .entity(new Error(errorCode.getErrorCode(), errorCode.getMessage()))
                .build();
    }

    /**
     *
     * @return
     */
    public static Response ok() {

        return Response.ok().build();
    }

    /**
     *
     * @param entity
     * @param <T>
     * @return
     */
    public static <T extends Serializable> Response ok(T entity) {
        return Response.ok(entity).build();
    }

    /**
     *
     * @param entity
     * @param <T>
     * @return
     */
    public static <T extends Serializable> Response ok(Collection<T> entity) {
        return Response.ok(entity).build();
    }

    /**
     *
     * @return
     */
    public static Response notFound() {
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    /**
     *
     * @return
     */
    public static Response notImplemented() {
        return Response.status(Response.Status.NOT_IMPLEMENTED).build();
    }
}
