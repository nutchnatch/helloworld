package com.ossnms.web.api.orchestration.common.api.factory;

import com.ossnms.web.api.orchestration.common.api.model.TrafficParamRTO;
import com.ossnms.web.provider.sdn.model.common.attributes.TrafficParam;

/**
 * Created by 68500245 on 21-12-2016.
 */
public final class TrafficParamFactory {

   private TrafficParamRTO trafficParams = new TrafficParamRTO();

   /**
    * @param trafficParams
    * @return
    */
   public TrafficParamFactory from( TrafficParam trafficParams ) {

      if ( trafficParams != null ) {

         this.trafficParams.setBandwidth( trafficParams.getBandwidth() );
         this.trafficParams.setMultiplier( trafficParams.getMultiplier() );
         this.trafficParams.setSigType( trafficParams.getSigType() );
      }

      return this;
   }


   /**
    * @return
    */
   public TrafficParamRTO build() {

      return trafficParams;
   }
}