package com.ossnms.web.api.orchestration.common.notification;

import com.ossnms.web.api.orchestration.common.api.annotation.Orchestration;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

/**
 *
 */
@Orchestration
@ApplicationScoped
public class OrchestrationNotificationHandler implements NotificationHandler{

    private static final Logger LOGGER = LoggerFactory.getLogger(OrchestrationNotificationHandler.class);

    private NotificationHandler notificationHandler;

    /**
     * no-args constructor
     */
    public OrchestrationNotificationHandler(){}

    /**
     *
     * @param notificationHandler
     */
    @Inject
    public OrchestrationNotificationHandler(
            NotificationHandler notificationHandler
    ) {
        this.notificationHandler = notificationHandler;
    }

    /**
     * This notification handler is called to allow parse of oif objects
     * @param notification the notification to handle
     * @throws NotificationHandlerException if the notification handler failed to handle the notification
     */
    @Override
    public void handle(Notification notification) throws NotificationHandlerException {
        LOGGER.debug(notification.toString());

        NotificationChannel channel = notification.getChannel();
        String channelId = translate(channel.getChannelId());

        Notification parsedNotification = new Notification.NotificationBuilder()
                .setEntitySupplier(notification::getEntity)
                .setNotificationType(notification.getNotificationType())
                .setChannel(new NotificationChannel(channelId))
                .build();

        this.notificationHandler.handle(parsedNotification);
    }

    /**
     *
     * @param channelId
     * @return
     */
    private String translate(String channelId) {
        if(channelId.startsWith("network")) {
            return channelId.replace("network", "/orchestration/domain");
        } else if(channelId.startsWith("service")) {
            return channelId.replace("service", "/orchestration/service");
        }

        return channelId;
    }
}
