package com.ossnms.web.api.orchestration.common.api.factory;

import com.ossnms.web.api.orchestration.common.api.model.EndpointRTO;
import com.ossnms.web.api.orchestration.topology.api.factory.EdgeEndFactory;
import com.ossnms.web.provider.sdn.model.endpoint.Endpoint;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;

/**
 * Created by 68500245 on 20-12-2016.
 */
public final class EndpointFactory {

   private EndpointRTO endpoint = new EndpointRTO();


   public EndpointFactory from( Endpoint endp ) {

      from( (EndpointSummary) endp );

      // endpoint.setOifEdgeEnd( endp.get );
      // endpoint.setOifLongitude( endpointSummary.getVertex().getCoriantVertexIdentifier().getCoriantCoordLongitude() );

      return this;
   }



   public EndpointFactory from( EndpointSummary endpointSummary ) {

      if ( endpointSummary != null ) {

         endpoint.setOifDomainId( Long.parseLong( endpointSummary.getID().getDomainId() ) );
         endpoint.setOifId( Long.parseLong( endpointSummary.getID().getID() ) );
         endpoint.setOifName( endpointSummary.getName() );
         endpoint.setOifEdgeEnd( new EdgeEndFactory()
               .from( endpointSummary.getEdgeEndID() )
               .from( endpointSummary.getVertex() )
               .build()
         );
      }

      return this;
   }


   /**
    *
    * @return
    */
   public EndpointRTO build() {

      return endpoint;
   }
}