package com.ossnms.web.api.orchestration.common.notification;

import com.ossnms.web.api.orchestration.common.api.annotation.Orchestration;
import com.ossnms.web.api.orchestration.common.api.provider.BaseOrchestrationProvider;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationService;
import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Collection;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.URL_BASE_ORCHESTRATION;

/**
 *
 */
@ApplicationScoped
public class OrchestrationNotificationService extends BaseOrchestrationProvider implements NotificationService{

    private static final Logger LOGGER = LoggerFactory.getLogger(OrchestrationNotificationService.class);

    /**
     *
     */
    private NotificationService proxyNotificationService;

    /**
     *
     */
    private NotificationHandler notificationHandler;


    /**
     * CDI required constructor
     */
    public OrchestrationNotificationService() {}

    /**
     * CDI enabled constructor
     */
    @Inject
    public OrchestrationNotificationService(
            @Proxy NotificationService notificationService,
            @Orchestration NotificationHandler notificationHandler
    ) {
        this.notificationHandler = notificationHandler;
        this.proxyNotificationService = notificationService;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void subscribe(NotificationChannel channel, NotificationHandler handler) {
        LOGGER.debug(" >> Subscribe");
        // only accept the subscription to this service when the channel starts with the prefix /orchestration
        String channelId = channel.getChannelId();
        if(channelId.startsWith(URL_BASE_ORCHESTRATION)) {
            proxyNotificationService.subscribe(channel, this.notificationHandler);
        }
        LOGGER.debug(" << Subscribe");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void unsubscribe(NotificationChannel channel, NotificationHandler handler) {
        LOGGER.debug(" >> Unsubscribe");
        // only accept the subscription to this service when the channel starts with the prefix /orchestration
        String channelId = channel.getChannelId();
        if(channelId.startsWith(URL_BASE_ORCHESTRATION)) {
            proxyNotificationService.unsubscribe(channel, this.notificationHandler);
        }
        LOGGER.debug(" << Unsubscribe");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void subscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        LOGGER.debug(" >> Subscribe collection");
        channels.forEach(channel -> subscribe(channel, this.notificationHandler));
        LOGGER.debug(" << Subscribe collection");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void unsubscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        LOGGER.debug(" >> Subscribe collection");
        channels.forEach(channel -> unsubscribe(channel, this.notificationHandler));
        LOGGER.debug(" << Subscribe collection");
    }
}
