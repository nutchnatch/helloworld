package com.ossnms.web.api.orchestration.common.constant;

import javax.ws.rs.core.Response;

/**
 *
 */
public enum OrchestrationErrorCode {

    ERROR_GENERIC ("Generic error", Response.Status.INTERNAL_SERVER_ERROR, "0000"),
    ERROR_GENERIC_BAD_REQUEST ("Bad Request", Response.Status.BAD_REQUEST, "0000"),
    ERROR_OIF_NOT_AVAILABLE ("OIF not available", Response.Status.NOT_IMPLEMENTED, "0000"),
    ERROR_SERVICE_TYPE_UNSUPPORTED ("Service Unsupported", Response.Status.BAD_REQUEST, "0001"),

    // DOMAIN
    ERROR_DOMAIN_EXISTS ("Already exists in SDN",Response.Status.CONFLICT, "0101"),
    ERROR_SUBSCRIBER_EXISTS ("Already exists in NMS",Response.Status.CONFLICT, "0102"),
    ERROR_SECURITY_DOMAIN_EXISTS ("NMS misconfiguration",Response.Status.CONFLICT, "0103"),

    // SERVICE
    ERROR_CALL_EXISTS ("Service already exists", Response.Status.CONFLICT, "0301"),
    ERROR_CALL_NOT_FOUND ("Service not found", Response.Status.NOT_FOUND, "0302"),
    ERROR_CALL_ASSIGNMENT ("Service assignment to subscriver failed", Response.Status.INTERNAL_SERVER_ERROR, "0303");

    private String message;
    private Response.Status httpStatus;
    private String errorCode;

    /**
     *
     * @param message
     * @param httpStatus
     * @param errorCode
     */
    OrchestrationErrorCode(String message, Response.Status httpStatus, String errorCode) {
        this.message = message;
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
    }

    /**
     *
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     */
    public Response.Status getHttpStatus() {
        return httpStatus;
    }

    /**
     *
     */
    public String getErrorCode() {
        return errorCode;
    }

    public String toString() {
        return errorCode + " | " + message;
    }
}
