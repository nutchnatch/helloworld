package com.ossnms.web.api.orchestration.service.api.factory;

import com.ossnms.web.api.orchestration.common.api.factory.EndpointFactory;
import com.ossnms.web.api.orchestration.common.api.factory.SrgDetailFactory;
import com.ossnms.web.api.orchestration.common.api.factory.TrafficParamFactory;
import com.ossnms.web.api.orchestration.service.api.model.ProtectionGroupRTO;
import com.ossnms.web.api.orchestration.service.api.model.RoutingFailureDetailRTO;
import com.ossnms.web.api.orchestration.service.api.model.SLARTO;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;
import com.ossnms.web.api.orchestration.topology.api.factory.EdgeFactory;
import com.ossnms.web.api.orchestration.topology.api.model.EdgeRTO;
import com.ossnms.web.provider.network.model.path.Path;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.call.ProtectionGroup;
import com.ossnms.web.provider.sdn.model.call.RoutingFailureDetail;
import com.ossnms.web.provider.sdn.model.call.SLA;
import com.ossnms.web.provider.sdn.model.edge.EdgeSummary;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 */
public final class ServiceFactory {

    private ServiceRTO serviceRTO = new ServiceRTO();

    /**
     * @param callID
     * @return
     */
    public ServiceFactory from( CallID callID ) {

        if ( callID != null ) {

            serviceRTO.setOifId( Long.valueOf( callID.getID() ) );
            serviceRTO.setOifDomainId( Long.valueOf( callID.getDomainId() ) );
        }

        return this;
    }

    /**
     * @param callSummary
     * @return
     */
    public ServiceFactory from( CallSummary callSummary ) {

        if ( callSummary != null ) {

            from( callSummary.getID() );

            serviceRTO.setName( callSummary.getName() );

            serviceRTO.setOifAEnd( new EndpointFactory().from( callSummary.getAEnd() ).build() );
            serviceRTO.setOifZEnd( new EndpointFactory().from( callSummary.getZEnd() ).build() );

            serviceRTO.setOifCallOperStatus( callSummary.getOperStatus() );
        }

        return this;
    }

    /**
     * @param call
     * @return
     */
    public ServiceFactory from( Call call ) {

        if ( call != null ) {

            from( (CallSummary) call );

            serviceRTO.setOifPathRequestId( call.getPathRequestId() );

            serviceRTO.setOifTrafficParams( new TrafficParamFactory().from( call.getTrafficParam() ).build() );

            serviceRTO.setOifAdminStatus( call.getAdminStatus() );

            serviceRTO.setOifCallProvisioningStatus( call.getCallProvisioningStatus() );
            serviceRTO.setOifCallConfigStatus( call.getCallConfigStatus() );
            serviceRTO.setOifNetworkSyncStatus( call.getNetworkSyncStatus() );

            serviceRTO.setOifCallLatency( call.getCallLatency() );

            serviceRTO.setRoutingFailureDetail( buildRoutingFailureDetailRTO( call.getRoutingFailureDetail() ) );

            serviceRTO.setOifSwitchingType( call.getSwitchingType() );
            serviceRTO.setOifEncoding( call.getEncoding() );
            serviceRTO.setOifDirectionality( call.getDirectionality() );

            serviceRTO.setOifPath( buildPathRTOList( call.getPath() ) );

            serviceRTO.setOifServiceLatency( call.getServiceLatency() );

            serviceRTO.setOifRoutingOverExistingServicesOnly( call.getRoutingOverExistingServicesOnly() );
            serviceRTO.setOifRoutingOverEnabledResourcesOnly( call.getRoutingOverEnabledResourcesOnly() );
            serviceRTO.setOifRoutingOverNotReservedResourcesOnly( call.getRoutingOverNotReservedResourcesOnly() );

            serviceRTO.setOifOrderNumber( call.getOrderNumber() );

            serviceRTO.setOifSla( buildSLARTO( call.getSla() ) );

            serviceRTO.setOifSrgDetails( SrgDetailFactory.buildSrgDetailList( call.getSrgDetails() ) );

            serviceRTO.setOifRestorable( call.isRestorable() );

            serviceRTO.setOifConnections( ConnectionFactory.buildConnectionRTOList( call.getConnections() ) );

            serviceRTO.setOifProtectionGroups( buildProtectionGroupRTOList( call.getProtectionGroups() ) );
        }

        return this;
    }


    /**
     * @param pathID
     * @return
     */
    public ServiceFactory from( PathID pathID ) {

        if ( pathID != null ) {

            serviceRTO.setNmsId( pathID.getId() );
            serviceRTO.setNmsPathType( pathID.getPathType() == null ? null : pathID.getPathType().name() );
        }

        return this;
    }

    /**
     * @param pathSummary
     * @return
     */
    public ServiceFactory from( PathSummary pathSummary ) {

        if ( pathSummary != null ) {

            from( pathSummary.getID() );

            serviceRTO.setName( pathSummary.getName() );
            serviceRTO.setNmsPathSubType( pathSummary.getPathSubType() );
            serviceRTO.setNmsPathStatus( pathSummary.getPathStatus() == null ? null : pathSummary.getPathStatus().name() );
        }

        return this;
    }

    /**
     * @param path
     * @return
     */
    public ServiceFactory from( Path path ) {

        if ( path != null ) {

            from( (PathSummary) path );

            serviceRTO.setNmsActiveRoute( path.getActiveRoute() == null ? null : path.getActiveRoute().name() );
            serviceRTO.setNmsActualCreationState( path.getActualCreationState() == null ? null : path.getActualCreationState().name() );
            serviceRTO.setNmsAdministrativeState( path.getAdministrativeState() == null ? null : path.getAdministrativeState().name() );
            serviceRTO.setNmsAlarmSeverity( path.getAlarmSeverity() == null ? null : path.getAlarmSeverity().name() );
            serviceRTO.setNmsANode( path.getaNode() );
            serviceRTO.setNmsBandwidth( path.getBandwidth() );
            serviceRTO.setNmsConnectionClass( path.getConnectionClass() == null ? null : path.getConnectionClass().name() );
            serviceRTO.setNmsCreatedBy( path.getCreatedBy() );
            serviceRTO.setNmsDescription( path.getDescription() );
            serviceRTO.setNmsManagedState( path.getManagedState() == null ? null : path.getManagedState().name() );
            serviceRTO.setNmsOperationalState( path.getOperationalState() == null ? null : path.getOperationalState().name() );
            serviceRTO.setNmsType( path.getType() );
            serviceRTO.setNmsServiceName( path.getServiceName() );
            serviceRTO.setNmsSubscriberName( path.getSubscriberName() );
            serviceRTO.setNmsProtection( path.getProtection() == null ? null : path.getProtection().name() );
            serviceRTO.setNmsRequiredCreationState( path.getRequiredCreationState() == null ? null : path.getRequiredCreationState().name() );
            serviceRTO.setNmsRouteState( path.getRouteState() == null ? null : path.getRouteState().name() );
            serviceRTO.setNmsZNode( path.getzNode() );
            serviceRTO.setNmsAcknowledgedBy( path.getAcknowledgedBy() );
            serviceRTO.setNmsAlarmMask( path.getAlarmMask() == null ? null : path.getAlarmMask().name() );
            serviceRTO.setNmsAcknowledgedTime( path.getAcknowledgedTime() == null ? null : path.getAcknowledgedTime().getTime() );
            serviceRTO.setNmsAPtpTp( path.getaPtpTp() );
            serviceRTO.setNmsPayloadCLFI( path.getPayloadCLFI() );
            serviceRTO.setNmsLastDisabledTime( path.getLastDisabledTime() == null ? null : path.getLastDisabledTime().getTime() );
            serviceRTO.setNmsLayer( path.getLayer() );
            serviceRTO.setNmsVlanId( path.getSVLanId() );
            serviceRTO.setNmsTpConfiguration( path.getTpConfiguration() );
            serviceRTO.setNmsTransportType( path.getTransportType() == null ? null : path.getTransportType().name() );
            serviceRTO.setNmsZPtpTp( path.getzPtpTp() );
            serviceRTO.setNmsDirection( path.getDirection() == null ? null : path.getDirection().name() );
            serviceRTO.setNmsOccupancyAz( path.getOccupancyAz() );
            serviceRTO.setNmsOccupancyZa( path.getOccupancyZa() );
            serviceRTO.setNmsCommonContainerId( path.getCommonContainerId() );
        }

        return this;
    }

    /**
     * @return
     */
    public ServiceRTO build() {

        return serviceRTO;
    }


    /**
     * @param sla
     * @return
     */
    private static SLARTO buildSLARTO(SLA sla ) {

        SLARTO slaRto = new SLARTO();

        if ( sla != null ) {

            slaRto.setMonitoring( sla.isSLAMonitoring() );
            slaRto.setCallImpairmentStatus( sla.getCallImpairmentStatus() );
            slaRto.setCallLastImpairmentStatusTimestamp( sla.getCallLastImpairmentStatusTimestamp() );
            slaRto.setThroughput( sla.getThroughput() );
        }

        return slaRto;
    }

    /**
     * @param path
     * @return
     */
    private static List<EdgeRTO> buildPathRTOList( List<EdgeSummary> path ) {

        List<EdgeRTO> edges = new ArrayList<>();

        if ( path != null ) {

            edges = path.stream()
                    .map( edgeSummary -> new EdgeFactory().from( edgeSummary ).build() )
                    .collect( Collectors.toList() );
        }

        return edges;
    }

    /**
     * @param routingFailureDetail
     * @return
     */
    private static RoutingFailureDetailRTO buildRoutingFailureDetailRTO(RoutingFailureDetail routingFailureDetail ) {

        RoutingFailureDetailRTO routingFailureDetailRTO = new RoutingFailureDetailRTO();

        if ( routingFailureDetail != null ) {

            routingFailureDetailRTO.setFailureCode( routingFailureDetail.getFailureCode() );
            routingFailureDetailRTO.setFailureDescription( routingFailureDetail.getFailureDescription() );
        }

        return routingFailureDetailRTO;
    }

    /**
     *
     * @param protectionGroups
     * @return
     */
    private static List<ProtectionGroupRTO> buildProtectionGroupRTOList( List<ProtectionGroup> protectionGroups ) {

        if ( protectionGroups == null ) {

            return Collections.emptyList();
        }

        return protectionGroups.stream()
              .map( item -> {

                  ProtectionGroupRTO rto = new ProtectionGroupRTO();

                  rto.setId( item.getId() );
                  rto.setProtectionMode( item.getProtectionMode() );
                  rto.setProtectionType( item.getProtectionType() );
                  rto.setProtectionState( item.getProtectionState() );
                  rto.setRestorationGate( item.getRestorationGate() );

                  return rto;
              } )
              .collect( Collectors.toList() );
    }
}