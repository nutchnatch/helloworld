package com.ossnms.web.api.orchestration.service.api.model.packet;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import com.ossnms.web.api.orchestration.common.api.model.EndpointRTO;
import com.ossnms.web.api.orchestration.service.api.model.packet.enumerable.PacketServiceBaseType;
import com.ossnms.web.api.orchestration.service.api.model.packet.enumerable.PacketServiceType;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Objects;

/**
 *
 */
@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "service" )
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonSerialize( include = JsonSerialize.Inclusion.NON_NULL )
public class PacketServiceRTO extends BaseRTO {

    private static final long serialVersionUID = 7709641922804855552L;

    @XmlAttribute(name = "ceVLan")
    private String ceVlan;

    @XmlAttribute(name = "baseType")
    private PacketServiceBaseType packetServiceBaseType;

    @XmlAttribute(name = "serviceType")
    private PacketServiceType packetServiceType;

    @XmlAttribute (name = "vc")
    private VirtualConnectionRTO virtualConnectionRTO;

    @XmlAttribute(name = "endpoints")
    private List<EndpointRTO> endpoints;

    /**
     *
     */
    public String getCeVlan() {
        return ceVlan;
    }

    public PacketServiceRTO setCeVlan(String ceVlan) {
        this.ceVlan = ceVlan;
        return this;
    }

    /**
     *
     */
    public PacketServiceBaseType getPacketServiceBaseType() {
        return packetServiceBaseType;
    }

    public PacketServiceRTO setPacketServiceBaseType(PacketServiceBaseType packetServiceBaseType) {
        this.packetServiceBaseType = packetServiceBaseType;
        return this;
    }

    /**
     *
     */
    public PacketServiceType getPacketServiceType() {
        return packetServiceType;
    }

    public PacketServiceRTO setPacketServiceType(PacketServiceType packetServiceType) {
        this.packetServiceType = packetServiceType;
        return this;
    }

    /**
     *
     */
    public VirtualConnectionRTO getVirtualConnectionRTO() {
        return virtualConnectionRTO;
    }

    public PacketServiceRTO setVirtualConnectionRTO(VirtualConnectionRTO virtualConnectionRTO) {
        this.virtualConnectionRTO = virtualConnectionRTO;
        return this;
    }

    /**
     *
     */
    public List<EndpointRTO> getEndpoints() {
        return endpoints;
    }

    public PacketServiceRTO setEndpoints(List<EndpointRTO> endpoints) {
        this.endpoints = endpoints;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        PacketServiceRTO that = (PacketServiceRTO) o;
        return Objects.equals(getCeVlan(), that.getCeVlan()) &&
                getPacketServiceBaseType() == that.getPacketServiceBaseType() &&
                getPacketServiceType() == that.getPacketServiceType() &&
                Objects.equals(getVirtualConnectionRTO(), that.getVirtualConnectionRTO()) &&
                Objects.equals(getEndpoints(), that.getEndpoints());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCeVlan(), getPacketServiceBaseType(), getPacketServiceType(), getVirtualConnectionRTO(), getEndpoints());
    }
}
