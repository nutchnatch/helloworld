
package com.ossnms.web.api.orchestration.topology.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;


@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "vertex" )
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class VertexRTO extends BaseRTO {

   private static final long serialVersionUID = 593366871802210032L;

   @XmlAttribute( name = "name" )
   private String name;

   @XmlAttribute( name = "oif.domainId" )
   private String oifDomainId;

   @XmlAttribute( name = "oif.id" )
   private String oifId;

   @XmlAttribute( name = "oif.name" )
   private String oifName;

   @XmlAttribute( name = "oif.latitude" )
   private String oifLatitude;

   @XmlAttribute( name = "oif.longitude" )
   private String oifLongitude;

   @XmlAttribute( name = "oif.nodeType" )
   private String oifNodeType;

   @XmlAttribute( name = "oif.description" )
   private String oifDescription;


   public String getName() {

      return name;
   }

   public void setName( String name ) {

      this.name = name;
   }

   public String getOifDomainId() {

      return oifDomainId;
   }

   public void setOifDomainId( String oifDomainId ) {

      this.oifDomainId = oifDomainId;
   }

   public String getOifId() {

      return oifId;
   }

   public void setOifId( String oifId ) {

      this.oifId = oifId;
   }

   public String getOifName() {

      return oifName;
   }

   public void setOifName( String oifName ) {

      this.oifName = oifName;
   }

   public String getOifLatitude() {

      return oifLatitude;
   }

   public void setOifLatitude( String oifLatitude ) {

      this.oifLatitude = oifLatitude;
   }

   public String getOifLongitude() {

      return oifLongitude;
   }

   public void setOifLongitude( String oifLongitude ) {

      this.oifLongitude = oifLongitude;
   }

   public String getOifNodeType() {

      return oifNodeType;
   }

   public void setOifNodeType( String oifNodeType ) {

      this.oifNodeType = oifNodeType;
   }

   public String getOifDescription() {

      return oifDescription;
   }

   public void setOifDescription( String oifDescription ) {

      this.oifDescription = oifDescription;
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      VertexRTO vertexRTO = (VertexRTO) o;
      return Objects.equals( name, vertexRTO.name ) &&
             Objects.equals( oifDomainId, vertexRTO.oifDomainId ) &&
             Objects.equals( oifId, vertexRTO.oifId ) &&
             Objects.equals( oifName, vertexRTO.oifName ) &&
             Objects.equals( oifLatitude, vertexRTO.oifLatitude ) &&
             Objects.equals( oifLongitude, vertexRTO.oifLongitude ) &&
             Objects.equals( oifNodeType, vertexRTO.oifNodeType ) &&
             Objects.equals( oifDescription, vertexRTO.oifDescription );
   }

   @Override
   public int hashCode() {

      return Objects.hash( name, oifDomainId, oifId, oifName, oifLatitude, oifLongitude, oifNodeType, oifDescription );
   }
}