package com.ossnms.web.api.orchestration.service.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.*;
import java.util.Objects;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "routingFailureDetail")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class RoutingFailureDetailRTO extends BaseRTO {

    private static final long serialVersionUID = -1845002312126583496L;

    @XmlAttribute
    private String failureCode;

    @XmlAttribute
    private String failureDescription;

    public String getFailureCode() {
        return failureCode;
    }

    public void setFailureCode(String failureCode) {
        this.failureCode = failureCode;
    }

    public String getFailureDescription() {
        return failureDescription;
    }

    public void setFailureDescription(String failureDescription) {
        this.failureDescription = failureDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        RoutingFailureDetailRTO that = (RoutingFailureDetailRTO) o;
        return Objects.equals(failureCode, that.failureCode) &&
                Objects.equals(failureDescription, that.failureDescription);
    }

    @Override
    public int hashCode() {
        return Objects.hash(failureCode, failureDescription);
    }
}
