package com.ossnms.web.api.orchestration.service.api.exception;

/**
 *
 */
public class ServiceOperationNotSupportedException extends ServiceProviderException {

   private static final long serialVersionUID = -4621376681634143621L;

   public ServiceOperationNotSupportedException() {}

   public ServiceOperationNotSupportedException( String message ) {
      super( message );
   }

   public ServiceOperationNotSupportedException( String message, Throwable cause ) {
      super( message, cause );
   }

   public ServiceOperationNotSupportedException( Throwable cause ) {
      super( cause );
   }

   public ServiceOperationNotSupportedException( String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace ) {
      super( message, cause, enableSuppression, writableStackTrace );
   }
}