package com.ossnms.web.api.orchestration.common.api.resources.inbound;

import com.ossnms.web.provider.common.api.params.Page;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.DEFAULT_PAGE_NUMBER;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.DEFAULT_PAGE_SIZE;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.PAGE;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.PAGE_SIZE;

/**
 * Page parameters.
 */
public class PageParameter {

    @DefaultValue(DEFAULT_PAGE_NUMBER) @QueryParam(PAGE)        private  int pageNumber;
    @DefaultValue(DEFAULT_PAGE_SIZE)   @QueryParam(PAGE_SIZE)   private  int pageSize;

    public int getPageNumber() {
        return pageNumber;
    }

    public int getPageSize() {
        return pageSize;
    }

    public Page getPage(){
        return new Page.Builder(pageNumber, pageSize).build();
    }

    /**
     *
     * @return
     */
    public String toString(){
        return String.format("Page %d with size %d.", pageNumber, pageSize);
    }
}
