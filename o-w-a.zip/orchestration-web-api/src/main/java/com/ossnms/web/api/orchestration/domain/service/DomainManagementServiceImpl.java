package com.ossnms.web.api.orchestration.domain.service;

import com.ossnms.web.api.common.provider.BaseProvider;
import com.ossnms.web.api.orchestration.common.api.DataSource;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.PageParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.SortParameter;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.Error;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode;
import com.ossnms.web.api.orchestration.domain.api.exception.DomainProviderException;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.api.orchestration.domain.api.provider.DomainProvider;
import com.ossnms.web.api.orchestration.domain.api.service.DomainManagementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.DATA_SOURCE;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.ID;

/**
 *
 */
public class DomainManagementServiceImpl extends BaseProvider implements DomainManagementService {

    /**
     *
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DomainManagementServiceImpl.class);

    /**
     * Domain provider instance
     */
    private DomainProvider domainProvider;

    /**
     * Default constructor
     */
    public DomainManagementServiceImpl() {
    }

    /**
     * Default constructor
     */
    @Inject
    public DomainManagementServiceImpl(DomainProvider domainProvider) {
        this.domainProvider = domainProvider;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response getAll(
            @BeanParam DetailsParameter detailsParameter,
            @BeanParam PageParameter pageParameter,
            @BeanParam SortParameter sortParameter,
            @BeanParam FilterParameter filterParameter) {
        LOGGER.debug("called getAll.");

        FetchResult<DomainRTO> all = domainProvider.getAll(detailsParameter, pageParameter, sortParameter, filterParameter);
        return Response.ok(all).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response get(@PathParam(DATA_SOURCE) DataSource dataSource, @PathParam(ID) String id ) {
        LOGGER.debug("called get(...) for id {}, {}.", dataSource, id);
        DomainRTO domainRTO = domainProvider.get(id, dataSource);
        if ( domainRTO == null ) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        return Response.ok(domainRTO).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response add( DomainRTO domain ) {
        LOGGER.debug("DomainRTO >> ADD");
        DomainRTO domainRTO = null;
        try {
            domainRTO = domainProvider.create(domain);
            if (domainRTO == null) {
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
        } catch (DomainProviderException e) {
            return getErrorResponse(domain, e);
        }

        return Response.ok(domainRTO).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response update(@PathParam(DATA_SOURCE) DataSource dataSource, @PathParam(ID) String id, DomainRTO domain ) {
        LOGGER.debug("called update for id {}.", id);

        if ( domain == null || !id.equals(domain.getId())) {
            return Response.status( Response.Status.BAD_REQUEST ).build();
        }

        DomainRTO updated;

        try {
            updated = domainProvider.update( domain );
        } catch (DomainProviderException e) {
            LOGGER.error("Could not update domain {}, since: {}", domain.getName(), e.getMessage());
            LOGGER.error("Exception : ", e);
            return Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }

        if ( updated == null ) {
            return Response.status( Response.Status.BAD_REQUEST ).build();
        }

        return Response.ok( updated ).build();
    }

    /**
     *
     * @param domain the underlying domain
     * @param e the exception
     * @return and instance of response
     */
    private Response getErrorResponse(DomainRTO domain, DomainProviderException e) {
        String message = String.format("Could not create domain %s", domain.getName());
        LOGGER.error(message, e);

        OrchestrationErrorCode errorCode = e.getErrorCode();

        Error errorInstance = new Error(errorCode.getErrorCode(), errorCode.getMessage());
        // send the status and the error instance (code + message) in the response
        return Response.status(errorCode.getHttpStatus()).entity(errorInstance).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(@PathParam(DATA_SOURCE) DataSource dataSource, @PathParam(ID) String id ) {
        try {
            LOGGER.debug("called delete for id {}.", id);
            domainProvider.delete(dataSource, id);
        } catch (DomainProviderException e) {
            LOGGER.error("Could not delete domain {}, since: {}", id, e.getMessage());
        }
    }
}
