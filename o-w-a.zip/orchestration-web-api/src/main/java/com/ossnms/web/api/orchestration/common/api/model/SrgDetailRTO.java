package com.ossnms.web.api.orchestration.common.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Objects;


@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "srgDetail" )
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class SrgDetailRTO extends BaseRTO {

   private static final long serialVersionUID = 7116517381988670901L;

   @XmlAttribute
   private List<RiskRTO> risks;

   @XmlAttribute
   private String riskClass;

   @XmlAttribute
   private String riskStartTime;

   @XmlAttribute
   private String riskStopTime;


   public List<RiskRTO> getRisks() {

      return risks;
   }

   public void setRisks( List<RiskRTO> risks ) {

      this.risks = risks;
   }

   public String getRiskClass() {

      return riskClass;
   }

   public void setRiskClass( String riskClass ) {

      this.riskClass = riskClass;
   }

   public String getRiskStartTime() {

      return riskStartTime;
   }

   public void setRiskStartTime( String riskStartTime ) {

      this.riskStartTime = riskStartTime;
   }

   public String getRiskStopTime() {

      return riskStopTime;
   }

   public void setRiskStopTime( String riskStopTime ) {

      this.riskStopTime = riskStopTime;
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      SrgDetailRTO that = (SrgDetailRTO) o;
      return Objects.equals( risks, that.risks ) &&
             Objects.equals( riskClass, that.riskClass ) &&
             Objects.equals( riskStartTime, that.riskStartTime ) &&
             Objects.equals( riskStopTime, that.riskStopTime );
   }

   @Override
   public int hashCode() {

      return Objects.hash( risks, riskClass, riskStartTime, riskStopTime );
   }
}