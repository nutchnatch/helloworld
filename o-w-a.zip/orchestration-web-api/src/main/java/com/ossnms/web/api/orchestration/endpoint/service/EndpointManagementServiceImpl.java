package com.ossnms.web.api.orchestration.endpoint.service;

import com.ossnms.web.api.orchestration.endpoint.api.service.EndpointManagementService;

import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

/**
 *
 */
public class EndpointManagementServiceImpl implements EndpointManagementService{

    /**
     * {@inheritDoc}
     */
    @Override
    public Response get() {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response get(@PathParam("id") String id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response add() {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response update(@PathParam("id") String id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(@PathParam("id") String id) {

    }

}
