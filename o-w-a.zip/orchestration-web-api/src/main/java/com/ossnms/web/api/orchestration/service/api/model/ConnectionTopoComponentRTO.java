package com.ossnms.web.api.orchestration.service.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "ConnectionTopoComponent")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ConnectionTopoComponentRTO extends BaseRTO {

    private static final long serialVersionUID = -6543898665318559165L;
    @XmlAttribute
    private String domainId;

    @XmlAttribute
    private String connectionId;

    @XmlAttribute
    private String edgeId;

    public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    public String getId() {

        if (connectionId != null) {
            return connectionId;
        }

        if (edgeId != null) {
            return edgeId;
        }

        return null;
    }

    public void setConnectionId(String connectionId) {
        this.connectionId = connectionId;
    }

    public void setEdgeId(String edgeId) {
        this.edgeId = edgeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ConnectionTopoComponentRTO that = (ConnectionTopoComponentRTO) o;
        return Objects.equals(domainId, that.domainId) &&
                Objects.equals(connectionId, that.connectionId) &&
                Objects.equals(edgeId, that.edgeId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(domainId, connectionId, edgeId);
    }
}
