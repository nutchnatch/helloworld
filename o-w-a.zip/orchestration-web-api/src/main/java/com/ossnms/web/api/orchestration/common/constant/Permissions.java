package com.ossnms.web.api.orchestration.common.constant;

/**
 *
 */
public final class Permissions {

    public static final String PERMISSION_CARRIER_ACCESS    = "Web->Carrier Access";
    public static final String PERMISSION_CUSTOMER_ACCESS   = "Web->Customer Access";


    /**
     * Hidden utility class constructor
     */
    private Permissions(){}

}
