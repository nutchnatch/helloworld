package com.ossnms.web.api.orchestration.domain.mapper;

import com.ossnms.web.api.orchestration.domain.api.factory.DomainFactory;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationEntityMapper;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.URL_DOMAIN;

/**
 * {@inheritDoc}
 */
public class DomainEntityMapper implements NotificationEntityMapper {

    private static final Logger LOGGER = LoggerFactory.getLogger(DomainEntityMapper.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean accept(Notification notification) {
        if(notification == null || notification.getEntity() == null || notification.getChannel() == null) {
            return false;
        }

        // extract relevant parts of the notification instance
        EntityBase entityBase = notification.getEntity();
        NotificationChannel channel = notification.getChannel();
        String channelId = channel.getChannelId();

        return channelId.startsWith(URL_DOMAIN) && (entityBase instanceof NetworkSummary || entityBase instanceof ContainerSummary);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Serializable map(Notification notification) {
        DomainFactory domainFactory = new DomainFactory();
        EntityBase entity = notification.getEntity();

        LOGGER.debug("Mapping entity of type {}", entity.getClass());
        if(entity instanceof ContainerSummary) {
            return compute(domainFactory, (ContainerSummary) entity);
        } else if(entity instanceof NetworkSummary) {
            return compute(domainFactory, (NetworkSummary) entity);
        }

        return domainFactory.build();
    }

    /**
     *
     * @param factory
     * @param summary
     */
    private DomainRTO compute(DomainFactory factory, ContainerSummary summary) {
        return factory.from(summary).build();
    }

    /**
     *
     * @param factory
     * @param summary
     */
    private DomainRTO compute(DomainFactory factory, NetworkSummary summary) {
        return factory.from(summary).build();
    }

}
