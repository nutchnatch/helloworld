package com.ossnms.web.api.orchestration.common.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "risk")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class RiskRTO extends BaseRTO {

    private static final long serialVersionUID = -9023303517023808629L;

    @XmlAttribute
    private String domainId;

    @XmlAttribute
    protected String id;

    @XmlAttribute
    protected String name;


    public String getDomainId() { return domainId; }

    public void setDomainId( String domainId ) { this.domainId = domainId; }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        RiskRTO riskRTO = (RiskRTO) o;
        return Objects.equals( domainId, riskRTO.domainId ) &&
               Objects.equals( id, riskRTO.id ) &&
               Objects.equals( name, riskRTO.name );
    }

    @Override
    public int hashCode() {

        return Objects.hash( domainId, id, name );
    }
}