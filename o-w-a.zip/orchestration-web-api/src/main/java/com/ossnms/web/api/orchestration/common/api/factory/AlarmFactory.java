package com.ossnms.web.api.orchestration.common.api.factory;

import com.ossnms.web.api.orchestration.common.api.model.AlarmRTO;
import com.ossnms.web.provider.network.model.fault.Alarm;

/**
 *
 */
public final class AlarmFactory {

    /**
     * Instance variable
     */
    private AlarmRTO alarmRTO = new AlarmRTO();

    /**
     *
     * @param alarm
     * @return
     */
    public AlarmFactory from(Alarm alarm) {

        if(alarm != null) {
            String id = Long.toString(alarm.getID().getId());
            alarmRTO.setId(id);
            alarmRTO.setAffectedNEName(alarm.getAffectedNEName());
            alarmRTO.setAffectedObjectLocation(alarm.getAffectedObjectLocation());
            alarmRTO.setAlarmClass(alarm.getAlarmClass());
            alarmRTO.setAlarmSeverity(alarm.getAlarmSeverity() == null ? null : alarm.getAlarmSeverity().name());
            alarmRTO.setFaultCondition(alarm.getFaultCondition() == null ? null : alarm.getFaultCondition().name());
            alarmRTO.setProbableCause(alarm.getProbableCause());
            alarmRTO.setAcknowledgedBy(alarm.getAcknowledgedBy());
            alarmRTO.setAcknowledgeTime(alarm.getAcknowledgeTime());
            alarmRTO.setRaiseTime(alarm.getRaiseTime());
            alarmRTO.setTrafficDirection(alarm.getTrafficDirection().name());

            alarmRTO.setTimestamp(alarm.getTimestamp());
        }

        return this;
    }

    /**
     *
     * @return
     */
    public AlarmRTO build() {
        return this.alarmRTO;
    }
}
