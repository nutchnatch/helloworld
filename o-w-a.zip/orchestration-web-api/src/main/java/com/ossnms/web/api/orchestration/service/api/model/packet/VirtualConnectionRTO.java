package com.ossnms.web.api.orchestration.service.api.model.packet;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import com.ossnms.web.api.orchestration.service.api.model.packet.enumerable.VirtualConnectionType;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

/**
 *
 */

@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "service" )
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonSerialize( include = JsonSerialize.Inclusion.NON_NULL )
public class VirtualConnectionRTO extends BaseRTO {

    private static final long serialVersionUID = -1631306253651918522L;

    @XmlAttribute (name = "type")
    private VirtualConnectionType virtualConnectionType;

    /**
     *
     */
    public VirtualConnectionType getVirtualConnectionType() {
        return virtualConnectionType;
    }

    public VirtualConnectionRTO setVirtualConnectionType(VirtualConnectionType virtualConnectionType) {
        this.virtualConnectionType = virtualConnectionType;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        VirtualConnectionRTO that = (VirtualConnectionRTO) o;
        return getVirtualConnectionType() == that.getVirtualConnectionType();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getVirtualConnectionType());
    }
}
