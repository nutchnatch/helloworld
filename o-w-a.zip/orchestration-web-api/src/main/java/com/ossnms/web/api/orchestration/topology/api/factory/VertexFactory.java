package com.ossnms.web.api.orchestration.topology.api.factory;

import com.ossnms.web.api.orchestration.topology.api.model.VertexRTO;
import com.ossnms.web.provider.sdn.model.vertex.VertexSummary;

/**
 * Created by 68500245 on 20-12-2016.
 */
public final class VertexFactory {

   VertexRTO vertex = new VertexRTO();


   public VertexFactory from( VertexSummary vertexSummary ) {

      if ( vertexSummary != null ) {

         vertex.setName( vertexSummary.getCoriantEmsName() );
         vertex.setOifName( vertexSummary.getName() );
         vertex.setOifDomainId( vertexSummary.getID().getDomainId() );
         vertex.setOifId( vertexSummary.getID().getID() );
         vertex.setOifNodeType( vertexSummary.getCoriantVertexIdentifier().getCoriantNodeType() );
         vertex.setOifDescription( vertexSummary.getCoriantVertexIdentifier().getCoriantDescription() );
         vertex.setOifLatitude( vertexSummary.getCoriantVertexIdentifier().getCoriantCoordLatitude() );
         vertex.setOifLongitude( vertexSummary.getCoriantVertexIdentifier().getCoriantCoordLongitude() );
      }

      return this;
   }

   /**
    * @return
    */
   public VertexRTO build() {

      return vertex;
   }
}