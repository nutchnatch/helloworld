package com.ossnms.web.api.orchestration.service.mapper;

import com.ossnms.web.api.orchestration.service.api.factory.ServiceFactory;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;
import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationEntityMapper;
import com.ossnms.web.provider.network.model.path.Path;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

/**
 *
 */
public class ServiceEntityMapper implements NotificationEntityMapper {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceEntityMapper.class);

    private static final String URL_SERVICE = "/orchestration/service";

    @Override
    public boolean accept(Notification notification) {
        if(notification == null || notification.getEntity() == null || notification.getChannel() == null) {
            return false;
        }

        // extract relevant parts of the notification instance
        EntityBase entityBase = notification.getEntity();
        NotificationChannel channel = notification.getChannel();
        String channelId = channel.getChannelId();

        return channelId.startsWith(URL_SERVICE) && (entityBase instanceof CallSummary || entityBase instanceof PathSummary);
    }

    @Override
    public Serializable map(Notification notification) {
        ServiceFactory factory = new ServiceFactory();
        EntityBase entity = notification.getEntity();

        LOGGER.debug("Mapping entity of type {}", entity.getClass());
        if(entity instanceof CallSummary) {
            return compute(factory, (CallSummary) entity);
        } else if(entity instanceof Path) {
            return compute(factory, (Path) entity);
        } else if(entity instanceof PathSummary) {
            return compute(factory, (PathSummary) entity);
        }

        return factory.build();
    }

    /**
     *
     * @param factory
     * @return
     */
    private ServiceRTO compute(ServiceFactory factory, CallSummary summary) {
        return factory.from(summary).build();
    }

    /**
     *
     * @param factory
     * @param summary
     * @return
     */
    private ServiceRTO compute(ServiceFactory factory, PathSummary summary) {
        return factory.from(summary).build();
    }

    /**
     *
     * @param factory
     * @param path
     * @return
     */
    private ServiceRTO compute(ServiceFactory factory, Path path) {
        return factory.from(path).build();
    }
}
