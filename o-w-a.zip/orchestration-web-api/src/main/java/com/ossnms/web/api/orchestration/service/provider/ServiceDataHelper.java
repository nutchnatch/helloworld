package com.ossnms.web.api.orchestration.service.provider;

import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.sdn.model.call.CallField;

import java.util.List;

import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.EQUALS;

public final class ServiceDataHelper {


    protected static Filter<CallField> getCallFieldFilter(String pathName) {
        return new Filter.Builder<>(
                CallField.NAME,
                EQUALS,
                pathName
        ).build();
    }

    protected static FetchResult<ServiceRTO> getResultList( List<ServiceRTO> result, int totalResults, int totalFilteresResult, Page paging ) {

        FetchResult<ServiceRTO> fetchResult = new FetchResult<>();

        fetchResult.setResultList( result );
        fetchResult.setTotalResults( totalResults );
        fetchResult.setTotalFilteredResults( totalFilteresResult );

        if ( paging != null ) {

            fetchResult.setPage( paging.getPage() );
            fetchResult.setPageSize( paging.getPageSize() );
        }

        return fetchResult;
    }

    /**
     * Hidden utility class constructor
     */
    private ServiceDataHelper() {}
}
