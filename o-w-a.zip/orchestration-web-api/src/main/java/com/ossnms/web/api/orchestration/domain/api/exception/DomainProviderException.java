package com.ossnms.web.api.orchestration.domain.api.exception;

import com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode;

/**
 *
 */
public class DomainProviderException extends Exception {

    private static final long serialVersionUID = 5454465105554242062L;

    /**
     *
     */
    private OrchestrationErrorCode errorCode = OrchestrationErrorCode.ERROR_GENERIC;

    public DomainProviderException() {
    }

    public DomainProviderException(Throwable cause) {
        super(cause);
    }

    public DomainProviderException(String message) {
        super(message);
    }

    public DomainProviderException(String message, Throwable cause) {
        super(message, cause);
    }

    public DomainProviderException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public DomainProviderException(OrchestrationErrorCode errorCode) {
        this.errorCode = errorCode;
    }

    public DomainProviderException(OrchestrationErrorCode errorCode, Throwable cause) {
        super(cause);
        this.errorCode = errorCode;
    }

    public DomainProviderException(OrchestrationErrorCode errorCode, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(errorCode.toString(), cause, enableSuppression, writableStackTrace);
        this.errorCode = errorCode;
    }

    /**
     *
     */
    public OrchestrationErrorCode getErrorCode() {
        return errorCode;
    }
}
