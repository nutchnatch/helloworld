package com.ossnms.web.api.orchestration.service.api.factory;

import com.ossnms.web.api.orchestration.common.api.factory.SrgDetailFactory;
import com.ossnms.web.api.orchestration.common.api.factory.TrafficParamFactory;
import com.ossnms.web.api.orchestration.topology.api.factory.EdgeEndFactory;
import com.ossnms.web.api.orchestration.service.api.model.ConnectionRTO;
import com.ossnms.web.api.orchestration.service.api.model.ConnectionTopoComponentRTO;
import com.ossnms.web.provider.common.api.model.EntityID;
import com.ossnms.web.provider.sdn.model.call.Connection;
import com.ossnms.web.provider.sdn.model.call.ConnectionID;
import com.ossnms.web.provider.sdn.model.call.ConnectionTopoComponent;
import com.ossnms.web.provider.sdn.model.edge.EdgeID;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by 68500245 on 21-12-2016.
 */
public final class ConnectionFactory {

   private ConnectionRTO connection = new ConnectionRTO();

   /**
    * @param connections
    * @return
    */
   static List<ConnectionRTO> buildConnectionRTOList( List<Connection> connections ) {


      List<ConnectionRTO> connectionRTO = new ArrayList<>();

      if ( connections != null ) {

         return connections.stream()
               .map( connection -> new ConnectionFactory().from( connection ).build() )
               .collect( Collectors.toList() );
      }

      return connectionRTO;
   }

   /**
    * @param conn
    * @return
    */
   public ConnectionFactory from( Connection conn ) {

      if ( connection != null ) {

         connection.setDomainId( conn.getID().getDomainId() );
         connection.setId( conn.getID().getId() );
         connection.setaEnd( new EdgeEndFactory().from( conn.getAEnd() ).build() );
         connection.setzEnd( new EdgeEndFactory().from( conn.getZEnd() ).build() );
         connection.setAdminStatus( conn.getAdminStatus() );
         connection.setDirectionality( conn.getDirectionality() );
         connection.setEncoding( conn.getEncoding() );
         connection.setFreqSlotWidth( conn.getFreqSlotWidth() );
         connection.setFrequency( conn.getFrequency() );
         connection.setName( conn.getName() );
         connection.setNetworkSyncStatus( conn.getNetworkSyncStatus() );
         connection.setOperStatus( conn.getOperStatus() );
         connection.setProvisioningStatus( conn.getProvisioningStatus() );
         connection.setSrgDetails( SrgDetailFactory.buildSrgDetailList( conn.getSrgDetails() ) );
         connection.setSwitchingType( conn.getSwitchingType() );
         connection.setTopoComponent( buildConnectionTopoComponent( conn.getTopoComponent() ) );
         connection.setTrafficParams( new TrafficParamFactory().from( conn.getTrafficParam() ).build() );
      }

      return this;
   }

   /**
    * @param connectionTopoComponent
    * @return
    */
   private static ConnectionTopoComponentRTO buildConnectionTopoComponent(ConnectionTopoComponent connectionTopoComponent ) {

      ConnectionTopoComponentRTO connectionTopoComponentRTO = new ConnectionTopoComponentRTO();

      if ( connectionTopoComponent != null ) {

         EntityID entityID = connectionTopoComponent.getID();

         if ( entityID instanceof EdgeID ) {

            EdgeID edgeID = (EdgeID) connectionTopoComponent.getID();

            connectionTopoComponentRTO.setEdgeId( edgeID.getID() );
            connectionTopoComponentRTO.setDomainId( edgeID.getDomainId() );

         }
         else if ( entityID instanceof ConnectionID ) {

            ConnectionID connectionID = (ConnectionID) connectionTopoComponent.getID();

            connectionTopoComponentRTO.setConnectionId( connectionID.getId() );
            connectionTopoComponentRTO.setDomainId( connectionID.getDomainId() );
         }
      }

      return connectionTopoComponentRTO;
   }

   /**
    * @return
    */
   public ConnectionRTO build() {

      return connection;
   }
}