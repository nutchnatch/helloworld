
package com.ossnms.web.api.orchestration.topology.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;


@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "edge" )
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class EdgeRTO extends BaseRTO {

   private static final long serialVersionUID = 1024947663374698594L;

   @XmlAttribute( name = "oif.domainId" )
   private Long oifDomainId;

   @XmlAttribute( name = "oif.id" )
   private Long oifId;

   @XmlAttribute( name = "oif.name" )
   private String oifName;

   @XmlAttribute( name = "oif.oifAEnd" )
   private EdgeEndRTO oifAEnd;

   @XmlAttribute( name = "oif.oifZEnd" )
   private EdgeEndRTO oifZEnd;


   public Long getOifDomainId() {

      return oifDomainId;
   }

   public void setOifDomainId( Long oifDomainId ) {

      this.oifDomainId = oifDomainId;
   }

   public Long getOifId() {

      return oifId;
   }

   public void setOifId( Long oifId ) {

      this.oifId = oifId;
   }

   public String getOifName() {

      return oifName;
   }

   public void setOifName( String oifName ) {

      this.oifName = oifName;
   }

   public EdgeEndRTO getOifAEnd() {

      return oifAEnd;
   }

   public void setOifAEnd( EdgeEndRTO oifAEnd ) {

      this.oifAEnd = oifAEnd;
   }

   public EdgeEndRTO getOifZEnd() {

      return oifZEnd;
   }

   public void setOifZEnd( EdgeEndRTO oifZEnd ) {

      this.oifZEnd = oifZEnd;
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      EdgeRTO edgeRTO = (EdgeRTO) o;
      return Objects.equals( oifDomainId, edgeRTO.oifDomainId ) &&
             Objects.equals( oifId, edgeRTO.oifId ) &&
             Objects.equals( oifName, edgeRTO.oifName ) &&
             Objects.equals( oifAEnd, edgeRTO.oifAEnd ) &&
             Objects.equals( oifZEnd, edgeRTO.oifZEnd );
   }

   @Override
   public int hashCode() {

      return Objects.hash( oifDomainId, oifId, oifName, oifAEnd, oifZEnd );
   }
}