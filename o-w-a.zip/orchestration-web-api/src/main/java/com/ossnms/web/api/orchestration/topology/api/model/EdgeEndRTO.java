
package com.ossnms.web.api.orchestration.topology.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;


@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "edgeEnd" )
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class EdgeEndRTO extends BaseRTO {

   @XmlAttribute( name = "oif.id" )
   private Long oifId;

   @XmlAttribute( name = "oif.domainId" )
   private Long oifDomainId;

   @XmlAttribute( name = "oif.name" )
   private String oifName;

   @XmlAttribute( name = "oif.vertex" )
   private VertexRTO oifVertex;

   @XmlAttribute( name = "oif.operState" )
   private String oifOperState;

   @XmlAttribute( name = "oif.ownership" )
   private String oifOwnership;


   public Long getOifId() {

      return oifId;
   }

   public void setOifId( Long oifId ) {

      this.oifId = oifId;
   }

   public Long getOifDomainId() {

      return oifDomainId;
   }

   public void setOifDomainId( Long oifDomainId ) {

      this.oifDomainId = oifDomainId;
   }

   public String getOifName() {

      return oifName;
   }

   public void setOifName( String oifName ) {

      this.oifName = oifName;
   }

   public VertexRTO getOifVertex() {

      return oifVertex;
   }

   public void setOifVertex( VertexRTO oifVertex ) {

      this.oifVertex = oifVertex;
   }

   public String getOifOperState() {

      return oifOperState;
   }

   public void setOifOperState( String oifOperState ) {

      this.oifOperState = oifOperState;
   }

   public String getOifOwnership() {

      return oifOwnership;
   }

   public void setOifOwnership( String oifOwnership ) {

      this.oifOwnership = oifOwnership;
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      EdgeEndRTO that = (EdgeEndRTO) o;
      return Objects.equals( oifId, that.oifId ) &&
             Objects.equals( oifDomainId, that.oifDomainId ) &&
             Objects.equals( oifName, that.oifName ) &&
             Objects.equals( oifVertex, that.oifVertex ) &&
             Objects.equals( oifOperState, that.oifOperState ) &&
             Objects.equals( oifOwnership, that.oifOwnership );
   }

   @Override
   public int hashCode() {

      return Objects.hash( oifId, oifDomainId, oifName, oifVertex, oifOperState, oifOwnership );
   }
}