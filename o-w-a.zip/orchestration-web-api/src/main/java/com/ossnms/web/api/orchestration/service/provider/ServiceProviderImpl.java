package com.ossnms.web.api.orchestration.service.provider;

import com.ossnms.web.api.orchestration.common.api.DataSource;
import com.ossnms.web.api.orchestration.common.api.factory.AlarmFactory;
import com.ossnms.web.api.orchestration.common.api.model.AlarmRTO;
import com.ossnms.web.api.orchestration.common.api.provider.BaseOrchestrationProvider;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.PageParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.SortParameter;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants;
import com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode;
import com.ossnms.web.api.orchestration.domain.api.factory.DomainFactory;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.api.orchestration.domain.api.provider.DomainProvider;
import com.ossnms.web.api.orchestration.domain.provider.DomainProviderImpl;
import com.ossnms.web.api.orchestration.service.api.exception.ServiceConflictException;
import com.ossnms.web.api.orchestration.service.api.exception.ServiceOperationNotSupportedException;
import com.ossnms.web.api.orchestration.service.api.exception.ServiceProviderException;
import com.ossnms.web.api.orchestration.service.api.factory.CallFactory;
import com.ossnms.web.api.orchestration.service.api.factory.ServiceFactory;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;
import com.ossnms.web.api.orchestration.service.api.provider.ServiceProvider;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.filter.FilterOperation;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.params.sort.SortDirection;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.result.enumerable.Status;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.fault.Alarm;
import com.ossnms.web.provider.network.model.path.Path;
import com.ossnms.web.provider.network.model.path.PathID;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;
import com.ossnms.web.provider.network.model.path.enumerable.PathType;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.operations.call.ProcessableCallEntityOperations;
import com.ossnms.web.provider.security.api.params.Permission;
import com.ossnms.web.provider.security.operations.SecurityOperations;
import com.ossnms.web.provider.service.operations.ContainerEntityOperations;
import com.ossnms.web.provider.service.operations.PathEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode.ERROR_CALL_EXISTS;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode.ERROR_CALL_NOT_FOUND;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode.ERROR_GENERIC_BAD_REQUEST;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode.ERROR_CALL_ASSIGNMENT;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode.ERROR_SERVICE_TYPE_UNSUPPORTED;
import static com.ossnms.web.api.orchestration.common.constant.Permissions.PERMISSION_CARRIER_ACCESS;
import static com.ossnms.web.api.orchestration.common.constant.Permissions.PERMISSION_CUSTOMER_ACCESS;
import static com.ossnms.web.api.orchestration.domain.provider.DomainProviderImpl.SDN_PROVIDER_NAME;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.CONTAINS;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.ENDS_WITH;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.EQUALS;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.GREATER_OR_EQUALS;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.GREATER_THAN;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.LESS_OR_EQUALS;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.LESS_THAN;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.SIMILAR;
import static com.ossnms.web.provider.common.api.params.filter.FilterOperation.STARTS_WITH;

/**
 * {@inheritDoc}
 */
public class ServiceProviderImpl extends BaseOrchestrationProvider implements ServiceProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceProviderImpl.class);

    private static final String SDN_TOPOLOGY_FULL = "FULL";
    private static final String ONLY_TRANSCEND_SERVICES_CAN_BE_UPDATED_MSG = "Only Transcend services can be updated!";
    private static final String ONLY_TRANSCEND_SERVICES_CAN_BE_DELETED_MSG = "Only Transcend services can be deleted!";
    private static final String ONLY_TRANSCEND_SERVICES_CAN_BE_ENFORCED_MSG = "Only Transcend services can be enforced!";
    private static final String ID_PROVIDER = "1";


    @Inject
    private PathEntityOperations pathEntityOperations;

    @Inject
    private ContainerEntityOperations containerEntityOperations;

    @Inject
    private ProcessableCallEntityOperations callEntityOperations;

    @Inject
    private SecurityOperations securityOperations;

    @Inject
    private DomainProvider domainProvider;

    public ServiceProviderImpl() {
    }

    /**
     * @param service
     * @return
     */
    private static String getPathId(ServiceRTO service) {

        return service.getNmsPathType() + '-' + service.getNmsId();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ServiceRTO getPathById(String pathId) {

        Path path = pathEntityOperations.getDetails(getSecurityToken(), convertPathId(pathId));

        if (path == null) {
            return null;
        }

        ServiceFactory factory = new ServiceFactory().from(path);

        if (isOIFAvailable()) {
            Collection<Call> calls = callEntityOperations.getAll(getSecurityToken(), Collections.singletonList(ServiceDataHelper.getCallFieldFilter(path.getName())), null, null).getResultCollection();
            calls.stream()
                    .findFirst()
                    .map(factory::from);
        }

        ServiceRTO service = factory.build();

        service.setDomain(getOrchestratorDomain(path.getCommonContainerId()));

        return service;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public FetchResult<ServiceRTO> getAllPaths(DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy) {

        if (details.isDetails()) {
            return getAllPathsDetails(pagination, filterBy, sortBy);
        } else {
            return getAllPathsSummary(pagination, filterBy, sortBy);
        }
    }

    /**
     * @param pagination
     * @param filterBy
     * @param sortBy
     * @return
     */
    private FetchResult<ServiceRTO> getAllPathsDetails(PageParameter pagination, FilterParameter filterBy, SortParameter sortBy) {

        Sort<PathField> sort = toPathFieldSort(sortBy);
        Collection<Filter<PathField>> filters = toPathFieldFilter(filterBy);

        OperationResult<Path, PathField> paths = pathEntityOperations.getAll(getSecurityToken(), filters, sort, pagination.getPage());

        if (paths.getResultCollection().isEmpty()) {

            return ServiceDataHelper.getResultList(Collections.emptyList(), 0, paths.getTotalFilteredElements(), paths.getPage());
        }

        if (isOIFAvailable()) {

            // Name filter with service name string list
            String callNames =
                    paths.getResultCollection().stream()
                            .map(PathSummary::getName)
                            .collect(Collectors.joining("|"));

            List<Filter<CallField>> callNamesFilter =
                    Collections.singletonList(new Filter.Builder<>(CallField.NAME, FilterOperation.EQUALS, callNames).build());

            Map<String, Call> servicesFromSDN =
                    callEntityOperations.getAll(getSecurityToken(), callNamesFilter, null, null).getResultCollection().stream()
                            .collect(Collectors.toMap(CallSummary::getName, Function.identity()));

            List<ServiceRTO> serviceRTOs =
                    paths.getResultCollection().stream()
                            .map(path -> {
                                ServiceRTO service = new ServiceFactory()
                                        .from(path)
                                        .from(servicesFromSDN.get(path.getName()))
                                        .build();
                                service.setDomain(getOrchestratorDomain(path.getCommonContainerId()));
                                return service;
                            })
                            .collect(Collectors.toList());
            return ServiceDataHelper.getResultList(serviceRTOs, paths.getTotalElements(), paths.getTotalFilteredElements(), paths.getPage());
        }

        List<ServiceRTO> resList =
                paths.getResultCollection().stream()
                        .map(path -> {
                            ServiceRTO service = new ServiceFactory()
                                    .from(path)
                                    .build();
                            service.setDomain(getOrchestratorDomain(path.getCommonContainerId()));
                            return service;
                        })
                        .collect(Collectors.toList());

        return ServiceDataHelper.getResultList(resList, paths.getTotalElements(), paths.getTotalFilteredElements(), paths.getPage());
    }

    /**
     * @param commonContainerId
     * @return
     */
    private DomainRTO getOrchestratorDomain(long commonContainerId) {
        if (commonContainerId == 0) {
            return new DomainFactory().from(DomainProviderImpl.SDN_PROVIDER_ID, SDN_PROVIDER_NAME, DataSource.SDN).build();
        }

        return domainProvider.get(String.valueOf(commonContainerId), DataSource.NMS);
    }

    /**
     * @param pagination
     * @param filterBy
     * @param sortBy
     * @return
     */
    private FetchResult<ServiceRTO> getAllPathsSummary(PageParameter pagination, FilterParameter filterBy, SortParameter sortBy) {
        Sort<PathField> sort = toPathFieldSort(sortBy);
        Collection<Filter<PathField>> filters = toPathFieldFilter(filterBy);
        OperationResult<Path, PathField> paths = pathEntityOperations.getAll(getSecurityToken(), filters, sort, pagination.getPage());
        if (paths.getResultCollection().isEmpty()) {
            return ServiceDataHelper.getResultList(Collections.emptyList(), 0, paths.getTotalFilteredElements(), paths.getPage());
        }

        if (isOIFAvailable()) {
            // Name filter with service name string list
            String callNames = paths.getResultCollection().stream()
                    .map(Path::getName)
                    .collect(Collectors.joining("|"));

            List<Filter<CallField>> callNamesFilter =
                    Collections.singletonList(new Filter.Builder<>(CallField.NAME, FilterOperation.EQUALS, callNames).build());

            Map<String, CallSummary> servicesFromSDN =
                    callEntityOperations.getAllSummary(getSecurityToken(), callNamesFilter, null, null).getResultCollection().stream()
                            .collect(Collectors.toMap(CallSummary::getName, Function.identity()));

            List<ServiceRTO> serviceRTOs =
                    paths.getResultCollection().stream()
                            .map(path -> {
                                ServiceRTO service = new ServiceFactory()
                                        .from((PathSummary) path)
                                        .from(servicesFromSDN.get(path.getName()))
                                        .build();
                                service.setDomain(getOrchestratorDomain(path.getCommonContainerId()));
                                return service;
                            })
                            .collect(Collectors.toList());

            return ServiceDataHelper.getResultList(serviceRTOs, paths.getTotalElements(), paths.getTotalFilteredElements(), paths.getPage());
        }

        List<ServiceRTO> resList =
                paths.getResultCollection().stream()
                        .map(path -> {
                            ServiceRTO service = new ServiceFactory()
                                    .from((PathSummary) path)
                                    .build();
                            service.setDomain(getOrchestratorDomain(path.getCommonContainerId()));
                            return service;
                        }).collect(Collectors.toList());

        return ServiceDataHelper.getResultList(resList, paths.getTotalElements(), paths.getTotalFilteredElements(), paths.getPage());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<? extends PathSummary, PathField> getPathsByContainer(String containerId, DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy) {

        Page page = pagination.getPage();
        Sort<PathField> sort = toPathFieldSort(sortBy);
        Collection<Filter<PathField>> filters = toPathFieldFilter(filterBy);

        OperationResult<? extends PathSummary, PathField> res = pathEntityOperations.getPaths(getSecurityToken(), new ContainerID.Builder(Long.parseLong(containerId)).build(), page, sort, filters);

        if (res == null) {
            return new OperationResult.Builder<PathSummary, PathField>(Collections.emptyList(), 0).build();
        }

        return res;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ContainerSummary getContainerById(String containerId, DetailsParameter details) {
        boolean isDetails = details != null && details.isDetails();
        if (isDetails) {
            return containerEntityOperations.getDetails(getSecurityToken(), new ContainerID.Builder(Long.parseLong(containerId)).build());
        } else {
            return containerEntityOperations.getSummary(getSecurityToken(), new ContainerID.Builder(Long.parseLong(containerId)).build());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<? extends ContainerSummary, ContainerField> getAllContainers(DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy) {

        OperationResult<? extends ContainerSummary, ContainerField> res;

        boolean isDetails = details != null && details.isDetails();

        Page page = pagination.getPage();
        Sort<ContainerField> sort = toContainerFieldSort(sortBy);
        Collection<Filter<ContainerField>> filters = toContainerFieldFilter(filterBy);

        if (isDetails) {
            res = containerEntityOperations.getAll(getSecurityToken(), filters, sort, page);
        } else {
            res = containerEntityOperations.getAllSummary(getSecurityToken(), filters, sort, page);
        }

        if (res == null) {
            return new OperationResult.Builder<ContainerSummary, ContainerField>(Collections.emptyList(), 0).build();
        }

        return res;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<AlarmRTO> getPathAlarms(String pathId) {
        List<AlarmRTO> alarmList = Collections.emptyList();

        Permission carrierPermission = new Permission.Builder().setPermission(PERMISSION_CARRIER_ACCESS).build();
        Permission customerPermission = new Permission.Builder().setPermission(PERMISSION_CUSTOMER_ACCESS).build();

        if (hasPermission(carrierPermission)) {
            return getAlarmList(pathId, false, true);
        }

        if (hasPermission(customerPermission)) {
            // get the NMS container (supports security configuration)
            OperationResult<ContainerID, ContainerField> allIds = containerEntityOperations.getAllIds(getSecurityToken(), null, null, new Page.Builder(1, 1).build());
            if (allIds != null) {
                Optional<ContainerID> first = allIds.getResultCollection().stream().findFirst();
                if (first.isPresent()) {
                    // get the first container
                    ContainerID containerID = first.get();
                    // fetch the corresponding domainRTO from TC
                    DomainRTO domainRTO = domainProvider.get(String.valueOf(containerID.getId()), DataSource.TC);
                    if (domainRTO == null || !SDN_TOPOLOGY_FULL.equals(domainRTO.getOifTopologyType())) {
                        // if the domain is null, then it does not exist as TC (NMS only)
                        return getAlarmList(pathId, true, false);
                    } else {
                        return getAlarmList(pathId, false, true);
                    }
                }
            }
        }

        return alarmList;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ServiceRTO create(ServiceRTO serviceRTO) throws ServiceProviderException {
        switch (serviceRTO.getServiceType()) {
            case OPTICAL:
                return createOpticalService(serviceRTO);
            case PACKET:
                return createPacketService(serviceRTO);
            default:
                throw new ServiceProviderException(ERROR_SERVICE_TYPE_UNSUPPORTED);
        }
    }

    /**
     *
     * @param service
     * @return
     */
    private ServiceRTO createPacketService(ServiceRTO service) throws ServiceProviderException {
        LOGGER.debug(service.toString());
        throw new ServiceProviderException(ERROR_SERVICE_TYPE_UNSUPPORTED);
    }

    /**
     *
     * @param serviceRTO
     * @return
     * @throws ServiceProviderException
     */
    private ServiceRTO createOpticalService(ServiceRTO serviceRTO) throws ServiceProviderException {
        assertOIFAvailable();
        assertServicePresence(serviceRTO, false);
        assertServiceValid(serviceRTO);

        CallFactory factory = new CallFactory();
        Call callParameter = factory.from(serviceRTO).build();

        // create service
        ProcessableSingleResult<Call, ErrorCode> response = callEntityOperations.insert(getSecurityToken(), callParameter);
        String serviceName = serviceRTO.getName();

        switch (response.getOperationStatus()) {
            case OK:
                LOGGER.debug("Service {} request for creation was accepted.", serviceName);

                String id = serviceRTO.getDomain().getNmsId();
                if(!id.equals(ID_PROVIDER)){
                    ContainerID cID = new ContainerID.Builder(Long.parseLong(id)).build();

                    ContainerID containerID = containerEntityOperations.assignToContainer(getSecurityToken(), cID, serviceName);

                    if(containerID==null){
                        LOGGER.debug("Service {} assignment ContainerID {} request was rejected.", serviceName,cID);
                        throw new ServiceProviderException(ERROR_CALL_ASSIGNMENT);
                    }
                }

                Call entity = response.getEntity();
                ServiceFactory serviceFactory = new ServiceFactory();
                serviceFactory.from(entity);
                return serviceFactory.build();
            case ALREADY_EXISTS:
                LOGGER.debug("Service {} request for creation was rejected. Service already exists.", serviceName);
                throw new ServiceProviderException(ERROR_CALL_EXISTS);
            case BAD_REQUEST:
                LOGGER.debug("Service {} request for creation was rejected. Message: {}", serviceName, response.getErrorMessage());
                throw new ServiceProviderException(ERROR_GENERIC_BAD_REQUEST);
            default:
                LOGGER.warn("Invalid operation status.");
                throw new ServiceProviderException(ERROR_GENERIC_BAD_REQUEST);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ServiceRTO update( ServiceRTO service ) throws ServiceProviderException {

        assertOIFAvailable();

        assertServicePresence( service, true );

        if ( DataSource.NMS.equals( DataSource.fromName( service.getDataSource() ) ) ) {

            throw new ServiceOperationNotSupportedException( ONLY_TRANSCEND_SERVICES_CAN_BE_UPDATED_MSG );
        }

        ProcessableSingleResult<Call, ErrorCode> updatedCall =
              callEntityOperations.update( getSecurityToken(), new CallFactory().from( service ).build() );

        if ( Status.OK != updatedCall.getOperationStatus() ) {

            throw new ServiceConflictException( updatedCall.getErrorMessage() );
        }

        return getPathById( getPathId( service ) );
    }

    /**
     * {@inheritDoc}
     */
    @Override
   public void delete( String id ) throws ServiceProviderException {

        assertOIFAvailable();

      ServiceRTO service = getPathById( id );

      assertServicePresence( service, true );

      if ( DataSource.NMS.equals( DataSource.fromName( service.getDataSource() ) ) ) {

         throw new ServiceOperationNotSupportedException( ONLY_TRANSCEND_SERVICES_CAN_BE_DELETED_MSG );
        }

      ProcessableSingleResult<CallID, ErrorCode> deleteResponse = callEntityOperations.delete( getSecurityToken(), new CallID.Builder( String.valueOf( service.getOifDomainId() ), String.valueOf( service.getOifId() ) ).build() );

      if ( Status.OK != deleteResponse.getOperationStatus() ) {

         throw new ServiceConflictException( deleteResponse.getErrorMessage() );
        }
    }

    @Override
    public void enforce(String id) throws ServiceProviderException {


        assertOIFAvailable();

        ServiceRTO service = getPathById(id);

        assertServicePresence(service, true);

        if (DataSource.NMS.equals(DataSource.fromName(service.getDataSource()))) {

            throw new ServiceOperationNotSupportedException(ONLY_TRANSCEND_SERVICES_CAN_BE_ENFORCED_MSG);
        }

        ProcessableSingleResult<CallID, ErrorCode> enforceResponse = callEntityOperations.enforce(getSecurityToken(), new CallID.Builder(String.valueOf(service.getOifDomainId()), String.valueOf(service.getOifId())).build());

        if (Status.OK != enforceResponse.getOperationStatus()) {

            throw new ServiceConflictException(enforceResponse.getErrorMessage());
        }
    }

    /**
     * @param serviceRTO
     * @return
     */
    private boolean isServicePresent(ServiceRTO serviceRTO) {

        if ( serviceRTO == null ) {

            return false;
        }

        if ( serviceRTO.getNmsPathType() != null && serviceRTO.getNmsId() != null ) {

            // Find by id ...
            OperationResult<PathSummary, PathField> allSummary = pathEntityOperations.getAllSummary(
                  getSecurityToken(),
                  Collections.singleton( new PathID.Builder( serviceRTO.getNmsId(), PathType.fromName( serviceRTO.getNmsPathType() ) ).build() )
            );

            return allSummary != null && allSummary.getResultCollection().stream().findFirst().isPresent();
        }

        // Find by name ...
        String serviceName = serviceRTO.getName();
        Filter<PathField> serviceNameFilter = new Filter.Builder<>(PathField.NAME, FilterOperation.EQUALS, serviceName).build();
        List<Filter<PathField>> pathNamesFilter = Collections.singletonList(serviceNameFilter);

        OperationResult<PathID, PathField> allIds = pathEntityOperations.getAllIds(
              getSecurityToken(),
              pathNamesFilter,
              null,
              null
        );

        return allIds != null && allIds.getResultCollection().stream().findFirst().isPresent();
    }

    /**
     * Asserts that the service exists, by checking the underlying providers. If the service presence does not match the
     * requirement passed as parameter, an exception is thrown
     *
     * @param service
     * @throws ServiceProviderException
     */
    private void assertServicePresence(ServiceRTO service, boolean presenceRequired) throws ServiceProviderException {
        // if the service is not available
        if (isServicePresent(service) != presenceRequired) {
            throw new ServiceProviderException(presenceRequired ? ERROR_CALL_NOT_FOUND : ERROR_CALL_EXISTS);
        }
    }

    /**
     *
     * @param serviceRTO
     */
    private void assertServiceValid(ServiceRTO serviceRTO) throws ServiceProviderException {
        if(serviceRTO == null || serviceRTO.getName() == null || serviceRTO.getName().isEmpty()) {
            throw new ServiceProviderException(ERROR_GENERIC_BAD_REQUEST);
        }
    }

    /**
     * Asserts that OIF is available, throwing an exception if not
     *
     * @throws ServiceProviderException if oif is not available
     */
    private void assertOIFAvailable() throws ServiceProviderException {
        if (!isOIFAvailable()) {
            throw new ServiceProviderException(OrchestrationErrorCode.ERROR_OIF_NOT_AVAILABLE);
        }
    }

    /**
     * @param pathId
     * @param endpointsOnly
     * @param extended
     * @return
     */
    private List<AlarmRTO> getAlarmList(String pathId, boolean endpointsOnly, boolean extended) {
        List<AlarmRTO> alarmList;
        List<Alarm> pathAlarms = pathEntityOperations.getPathAlarms(getSecurityToken(), convertPathId(pathId), endpointsOnly, extended);
        alarmList = pathAlarms
                .stream()
                .map(alarm -> new AlarmFactory().from(alarm))
                .map(AlarmFactory::build)
                .collect(Collectors.toList());

        return alarmList;
    }

    /**
     * @param carrierPermission
     * @return
     */
    private boolean hasPermission(Permission carrierPermission) {
        return !securityOperations.hasPermission(getSecurityToken(), carrierPermission).getPermissionsGranted().isEmpty();
    }

    /**
     * @param pathId
     * @return
     */
   private PathID convertPathId( String pathId ) {
      String[] pathString = pathId.split( "-" );
      PathID.Builder ret = new PathID.Builder( Long.parseLong( pathString[ 1 ] ), PathType.fromName( pathString[ 0 ] ) );
        return ret.build();
    }

    /**
     * @param sortParameter
     * @return
     */
    private Sort<PathField> toPathFieldSort(SortParameter sortParameter) {
      PathField field = PathField.fromName( sortParameter.getSortBy() );
      SortDirection sortDirection = SortDirection.valueOf( sortParameter.getSortDirection().name() );
      if ( field == null ) {
            return null;
        }
      return new Sort.Builder<>( field, sortDirection ).build();
    }

    /**
     * @param sortParameter
     * @return
     */
    private Sort<ContainerField> toContainerFieldSort(SortParameter sortParameter) {
        ContainerField field = ContainerField.fromName(sortParameter.getSortBy());
        SortDirection sortDirection = SortDirection.valueOf(sortParameter.getSortDirection().name());

        if (field == null) {
            return null;
        }

        return new Sort.Builder<>(field, sortDirection).build();
    }

    /**
     * @param filterParameter
     * @return
     */
    private Collection<Filter<PathField>> toPathFieldFilter(FilterParameter filterParameter) {

        List<Filter<PathField>> filters = new ArrayList<>();

        if (filterParameter == null || filterParameter.isFilterEmpty()) {
            return filters;
        }

        // get the filter criteria
        String filterBy = filterParameter.getFilterBy();
        // split the filter criteria by "AND" (the only supported operation)
        String[] filterArray = filterBy.split("AND");

        for (String filter : filterArray) {

            FilterOperation operation = getFilterOperation(filter);
            String[] ftr = filter.split(Pattern.quote(operation.getOperand()));
            PathField field = PathField.fromName(ftr[0].trim());
            String value = ftr[1].trim();

            if (field == null) {

                continue;
            }

            // Special case for SDN's PROVIDER domain
            if (PathField.SUBSCRIBER_NAME.equals(field) &&
                    FilterOperation.EQUALS.equals(operation) &&
                    OrchestrationConstants.SDN_PROVIDER_NAME.equals(value)) {

                value = "";
            }

            filters.add(new Filter.Builder<>(field, operation, value).build());
        }

        return filters;
    }

    /**
     * @param filterParameter
     * @return
     */
    private Collection<Filter<ContainerField>> toContainerFieldFilter(FilterParameter filterParameter) {
        List<Filter<ContainerField>> filters = new ArrayList<>();
        if (filterParameter == null || filterParameter.isFilterEmpty()) {
            return filters;
        }
        // get the filter criteria
        String filterBy = filterParameter.getFilterBy();
        // split the filter criteria by "AND" (the only supported operation)
        String[] filterArray = filterBy.split("AND");

        for (String filter : filterArray) {
            FilterOperation operation;
            ContainerField field;
            operation = getFilterOperation(filter);
            String[] ftr = filter.split(Pattern.quote(operation.getOperand()));
            field = ContainerField.fromName(ftr[0].trim());
            if (field == null) {
                continue;
            }
            filters.add(new Filter.Builder<>(field, operation, ftr[1]).build());
        }

        return filters;
    }

    /**
     * @param filter
     * @return
     */
    private FilterOperation getFilterOperation(String filter) {
        FilterOperation operation;
        if (filter.contains(EQUALS.getOperand())) {
            operation = EQUALS;
        } else if (filter.contains(GREATER_THAN.getOperand())) {
            operation = GREATER_THAN;
        } else if (filter.contains(LESS_THAN.getOperand())) {
            operation = LESS_THAN;
        } else if (filter.contains(GREATER_OR_EQUALS.getOperand())) {
            operation = GREATER_OR_EQUALS;
        } else if (filter.contains(LESS_OR_EQUALS.getOperand())) {
            operation = LESS_OR_EQUALS;
        } else if (filter.contains(SIMILAR.getOperand())) {
            operation = SIMILAR;
        } else if (filter.contains(CONTAINS.getOperand())) {
            operation = CONTAINS;
        } else if (filter.contains(STARTS_WITH.getOperand())) {
            operation = STARTS_WITH;
        } else {
            operation = ENDS_WITH;
        }
        return operation;
    }
}