package com.ossnms.web.api.orchestration.service.api.exception;

import com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode;

/**
 *
 */
public class ServiceProviderException extends Exception {

    private static final long serialVersionUID = 3401025099638978166L;

    /**
     *
     */
    private OrchestrationErrorCode errorCode = OrchestrationErrorCode.ERROR_GENERIC;

    public ServiceProviderException() {
    }

    public ServiceProviderException(Throwable cause) {
        super(cause);
    }

    public ServiceProviderException(String message) {
        super(message);
    }

    public ServiceProviderException(String message, Throwable cause) {
        super(message, cause);
    }

    public ServiceProviderException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public ServiceProviderException(OrchestrationErrorCode errorCode) {
        this.errorCode = errorCode;
    }

    public ServiceProviderException(OrchestrationErrorCode errorCode, Throwable cause) {
        super(cause);
        this.errorCode = errorCode;
    }

    public ServiceProviderException(OrchestrationErrorCode errorCode, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(errorCode.toString(), cause, enableSuppression, writableStackTrace);
        this.errorCode = errorCode;
    }

    /**
     *
     */
    public OrchestrationErrorCode getErrorCode() {
        return errorCode;
    }
}
