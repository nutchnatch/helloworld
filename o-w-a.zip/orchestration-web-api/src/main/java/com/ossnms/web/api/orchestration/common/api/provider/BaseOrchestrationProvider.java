package com.ossnms.web.api.orchestration.common.api.provider;

import com.ossnms.web.api.common.provider.BaseProvider;
import com.ossnms.web.api.orchestration.common.api.annotation.SystemProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

/**
 *
 */
public class BaseOrchestrationProvider extends BaseProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseOrchestrationProvider.class);

    @Inject
    @SystemProperty("oif.location")
    String oifLocation;

    /**
     *
     * @return
     */
    public boolean isOIFAvailable(){
        LOGGER.trace("SYSPROP (oif.location) == {}", oifLocation);
        return !oifLocation.isEmpty();
    }

}
