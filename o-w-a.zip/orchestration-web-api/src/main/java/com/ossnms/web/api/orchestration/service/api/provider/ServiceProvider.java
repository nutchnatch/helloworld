package com.ossnms.web.api.orchestration.service.api.provider;

import com.ossnms.web.api.orchestration.common.api.model.AlarmRTO;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.PageParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.SortParameter;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import com.ossnms.web.api.orchestration.service.api.exception.ServiceProviderException;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.path.PathSummary;
import com.ossnms.web.provider.network.model.path.enumerable.PathField;

import javax.ws.rs.ext.Provider;
import java.util.List;

/**
 * Interface to be implemented by a class prepared to access the Web Provider API's methods.
 */
@Provider
public interface ServiceProvider {

    /**
     *
     * @param pathId
     * @return
     */
    ServiceRTO getPathById(String pathId);

    /**
     *
     * @param details
     * @param pagination
     * @param filterBy
     * @param sortBy
     * @return
     */
    FetchResult<ServiceRTO> getAllPaths(DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy);

    /**
     *
     * @param containerId
     * @param details
     * @param pagination
     * @param filterBy
     * @param sortBy
     * @return
     */
    OperationResult<? extends PathSummary, PathField> getPathsByContainer(String containerId, DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy);

    /**
     *
     * @param containerId
     * @param details
     * @return
     */
    ContainerSummary getContainerById(String containerId, DetailsParameter details);

    /**
     *
     * @param details
     * @param pagination
     * @param filterBy
     * @param sortBy
     * @return
     */
    OperationResult<? extends ContainerSummary, ContainerField> getAllContainers(DetailsParameter details, PageParameter pagination, FilterParameter filterBy, SortParameter sortBy);

    /**
     *
     * @param pathId
     * @return
     */
    List<AlarmRTO> getPathAlarms(String pathId);

    /**
     *
     * @param serviceRTO
     * @return
     * @throws ServiceProviderException
     */
    ServiceRTO create(ServiceRTO serviceRTO) throws ServiceProviderException;

    /**
     *
     * @param serviceRTO
     * @return
     * @throws ServiceProviderException
     */
    ServiceRTO update(ServiceRTO serviceRTO) throws ServiceProviderException;

    /**
     *
     * @param id
     * @throws ServiceProviderException
     */
    void delete(String id) throws ServiceProviderException;

    /**
     *
     * @param id
     * @throws ServiceProviderException
     */
    void enforce(String id) throws ServiceProviderException;
}
