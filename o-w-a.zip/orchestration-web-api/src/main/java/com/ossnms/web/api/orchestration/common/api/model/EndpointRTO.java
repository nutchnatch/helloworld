
package com.ossnms.web.api.orchestration.common.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import com.ossnms.web.api.orchestration.service.api.model.LayerAttributeRTO;
import com.ossnms.web.api.orchestration.topology.api.model.EdgeEndRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import java.util.Objects;


@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "endpoint" )
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class EndpointRTO extends BaseRTO {

   private static final long serialVersionUID = -256268438953594843L;

   @XmlAttribute( name = "oif.domainId" )
   private Long oifDomainId;

   @XmlAttribute( name = "oif.id" )
   private Long oifId;

   @XmlAttribute( name = "oif.name" )
   private String oifName;

   @XmlAttribute( name = "oif.edgeEnd" )
   private EdgeEndRTO oifEdgeEnd;

   @XmlAttribute( name = "oif.latitude" )
   private String oifLatitude;

   @XmlAttribute( name = "oif.longitude" )
   private String oifLongitude;

   @XmlAttribute( name = "oif.srgDetails" )
   private List<SrgDetailRTO> oifSrgDetails;

   @XmlAttribute( name = "oif.provisioningStatus" )
   private String oifProvisioningStatus;

   @XmlAttribute( name = "oif.networkSyncStatus" )
   private String oifNetworkSyncStatus;

   @XmlAttribute( name = "oif.layerAttrib" )
   private LayerAttributeRTO oifLayerAttributes;


   public Long getOifDomainId() {

      return oifDomainId;
   }

   public void setOifDomainId( Long oifDomainId ) {

      this.oifDomainId = oifDomainId;
   }

   public Long getOifId() {

      return oifId;
   }

   public void setOifId( Long oifId ) {

      this.oifId = oifId;
   }

   public String getOifName() {

      return oifName;
   }

   public void setOifName( String oifName ) {

      this.oifName = oifName;
   }

   public EdgeEndRTO getOifEdgeEnd() {

      return oifEdgeEnd;
   }

   public void setOifEdgeEnd( EdgeEndRTO oifEdgeEnd ) {

      this.oifEdgeEnd = oifEdgeEnd;
   }

   public String getOifLatitude() {

      return oifLatitude;
   }

   public void setOifLatitude( String oifLatitude ) {

      this.oifLatitude = oifLatitude;
   }

   public String getOifLongitude() {

      return oifLongitude;
   }

   public void setOifLongitude( String oifLongitude ) {

      this.oifLongitude = oifLongitude;
   }

   public List<SrgDetailRTO> getOifSrgDetails() {

      return oifSrgDetails;
   }

   public void setOifSrgDetails( List<SrgDetailRTO> oifSrgDetails ) {

      this.oifSrgDetails = oifSrgDetails;
   }

   public String getOifProvisioningStatus() {

      return oifProvisioningStatus;
   }

   public void setOifProvisioningStatus( String oifProvisioningStatus ) {

      this.oifProvisioningStatus = oifProvisioningStatus;
   }

   public String getOifNetworkSyncStatus() {

      return oifNetworkSyncStatus;
   }

   public void setOifNetworkSyncStatus( String oifNetworkSyncStatus ) {

      this.oifNetworkSyncStatus = oifNetworkSyncStatus;
   }

   public LayerAttributeRTO getOifLayerAttributes() {

      return oifLayerAttributes;
   }

   public void setOifLayerAttributes( LayerAttributeRTO oifLayerAttributes ) {

      this.oifLayerAttributes = oifLayerAttributes;
   }

   @Override
   public boolean equals( Object o ) {

      if ( this == o ) {
         return true;
      }
      if ( o == null || getClass() != o.getClass() ) {
         return false;
      }
      EndpointRTO that = (EndpointRTO) o;
      return Objects.equals( oifDomainId, that.oifDomainId ) &&
             Objects.equals( oifId, that.oifId ) &&
             Objects.equals( oifName, that.oifName ) &&
             Objects.equals( oifEdgeEnd, that.oifEdgeEnd ) &&
             Objects.equals( oifLatitude, that.oifLatitude ) &&
             Objects.equals( oifLongitude, that.oifLongitude ) &&
             Objects.equals( oifSrgDetails, that.oifSrgDetails ) &&
             Objects.equals( oifProvisioningStatus, that.oifProvisioningStatus ) &&
             Objects.equals( oifNetworkSyncStatus, that.oifNetworkSyncStatus ) &&
             Objects.equals( oifLayerAttributes, that.oifLayerAttributes );
   }

   @Override
   public int hashCode() {

      return Objects.hash( oifDomainId, oifId, oifName, oifEdgeEnd, oifLatitude, oifLongitude, oifSrgDetails, oifProvisioningStatus, oifNetworkSyncStatus, oifLayerAttributes );
   }
}