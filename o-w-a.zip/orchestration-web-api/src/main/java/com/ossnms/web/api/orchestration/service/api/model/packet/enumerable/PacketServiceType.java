package com.ossnms.web.api.orchestration.service.api.model.packet.enumerable;

/**
 *
 */
public enum PacketServiceType {

    /**
     *
     */
    ELINE,

    /**
     *
     */
    ELAN,

    /**
     *
     */
    ETREE,

    /**
     *
     */
    EACCESS,

    /**
     *
     */
    ETRANSIT;

}
