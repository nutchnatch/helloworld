package com.ossnms.web.api.orchestration.domain.provider;

import com.ossnms.web.api.orchestration.common.api.DataSource;
import com.ossnms.web.api.orchestration.common.api.provider.BaseOrchestrationProvider;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.PageParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.SortParameter;
import com.ossnms.web.api.orchestration.common.api.resources.outbound.FetchResult;
import com.ossnms.web.api.orchestration.common.constant.OrchestrationErrorCode;
import com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants;
import com.ossnms.web.api.orchestration.domain.api.exception.DomainProviderException;
import com.ossnms.web.api.orchestration.domain.api.factory.DomainFactory;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.api.orchestration.domain.api.provider.DomainProvider;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.filter.FilterOperation;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.network.model.container.Container;
import com.ossnms.web.provider.network.model.container.ContainerID;
import com.ossnms.web.provider.network.model.container.ContainerInfo;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerField;
import com.ossnms.web.provider.network.model.container.enumerable.ContainerType;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkField;
import com.ossnms.web.provider.sdn.model.network.NetworkID;
import com.ossnms.web.provider.sdn.operations.network.NetworkEntityOperations;
import com.ossnms.web.provider.security.model.domain.SecurityDomain;
import com.ossnms.web.provider.security.model.domain.SecurityDomainID;
import com.ossnms.web.provider.security.model.element.SecurableElementID;
import com.ossnms.web.provider.security.model.element.enumerable.SecurableElementType;
import com.ossnms.web.provider.security.operations.domain.SecurityDomainOperations;
import com.ossnms.web.provider.service.operations.ContainerEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ossnms.web.api.orchestration.common.api.DataSource.NMS;
import static com.ossnms.web.api.orchestration.common.api.DataSource.SDN;
import static com.ossnms.web.api.orchestration.common.api.DataSource.TC;

/**
 *
 */
public class DomainProviderImpl extends BaseOrchestrationProvider implements DomainProvider {

    /**
     *
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DomainProviderImpl.class);

    /**
     *
     */
    private static final String[] DEFAULT_DOMAIN_PROTOCOLS = {"SIMPLIFIED", "RESTCONF"};

    /**
     *
     */
    public static final String SDN_PROVIDER_ID = "1";
    public static final String SDN_PROVIDER_NAME = "PROVIDER";

    /**
     *
     */
    private NetworkEntityOperations networkEntityOperations;

    /**
     *
     */
    private SecurityDomainOperations securityDomainOperations;

    /**
     *
     */
    private ContainerEntityOperations containerEntityOperations;

    /**
     * Default no-args constructor
     */
    public DomainProviderImpl(){}

    /**
     * CDI constructor
     *
     * @param networkEntityOperations interface for network entity management
     * @param securityDomainOperations interface for security domain management
     * @param containerEntityOperations interface for container entity operations
     */
    @Inject
    public DomainProviderImpl(
            NetworkEntityOperations networkEntityOperations,
            SecurityDomainOperations securityDomainOperations,
            ContainerEntityOperations containerEntityOperations) {

        this.networkEntityOperations = networkEntityOperations;
        this.securityDomainOperations = securityDomainOperations;
        this.containerEntityOperations = containerEntityOperations;
    }

    /**
     * Get All Network Domains.
     * {@inheritDoc}
     */
    @Override
    public FetchResult<DomainRTO> getAll(DetailsParameter detailsParameter, PageParameter pageParameter, SortParameter sortParameter, FilterParameter filterParameter) {

        List<DomainRTO> domainRTOList = new ArrayList<>();

        // create filter by container type SUBSCRIBER
        Filter<ContainerField> containerFieldFilter = getSubscriberTypeFilter();

        // fetch from container entity operations - WPA
        OperationResult<Container, ContainerField> allFromNMS = containerEntityOperations.getAll(
                getSecurityToken(),
                Collections.singletonList(containerFieldFilter),
                null,
                null
        );

        if ( allFromNMS != null ) {
            domainRTOList.addAll(
                    allFromNMS.getResultCollection()
                            .stream()
                            .map( container -> new DomainFactory().from(container) )
                            .map(DomainFactory::build)
                            .collect( Collectors.toList()));
        }

        // only if oif is available we should do this
        if ( isOIFAvailable() ) {
            final List<DomainRTO> oifRTOs;
            OperationResult<Network, NetworkField> allFromOIF = networkEntityOperations.getAll( getSecurityToken(), Collections.emptyList() );

            if ( allFromOIF != null ) {
                oifRTOs = allFromOIF.getResultCollection()
                        .stream()
                        .map( network -> new DomainFactory().from(network) )
                        .map(DomainFactory::build)
                        .collect( Collectors.toList() );

                // merge NMS with SDN
                domainRTOList.forEach(domain -> {
                    DomainRTO oifMatchedByName = getByNameFrom( oifRTOs, domain.getName() );
                    if (oifMatchedByName != null) {
                        oifRTOs.remove(oifMatchedByName);
                        mergeRTO( domain, oifMatchedByName );
                    }
                });

                // the ones remaining are oif only
                domainRTOList.addAll(oifRTOs);
            }
        }

        // set the result list
        FetchResult<DomainRTO> result = new FetchResult<>();

        result.setResultList( domainRTOList );
        result.setTotalResults( domainRTOList.size() );
        result.setTotalFilteredResults( domainRTOList.size() );

        //TODO: Page computations! How?!
        result.setPage( 1 );
        result.setPageSize( domainRTOList.size() );

        return result;
    }

    /**
     * Get Network Domain.
     * {@inheritDoc}
     */
    @Override
    public DomainRTO get( String id, DataSource dataSource) {
        switch(dataSource) {
            case SDN:
                // get from OIF
                Network domain = networkEntityOperations.getDetails(
                        getSecurityToken(),
                        new NetworkID.Builder( id ).build()
                );
                return new DomainFactory().from(domain).build();
            default:
                // get from WPA
                ContainerID containerID = new ContainerID.Builder( Long.parseLong( id ) ).build();
                return get(containerID);
        }
    }

    /**
     *
     * @param containerID
     * @return
     */
    @Override
    public DomainRTO get(ContainerID containerID) {
        Container details = containerEntityOperations.getDetails( getSecurityToken(), containerID );

        if(details == null) {
            return null;
        }

        DomainFactory factory = new DomainFactory().from(details);
        decorateWithOIFData(factory);

        return factory.build();
    }

    /**
     * Update Network Domain.
     * {@inheritDoc}
     */
    @Override
    public DomainRTO update(DomainRTO domainRTO)  throws DomainProviderException {

        DataSource source = DataSource.fromName(domainRTO.getDataSource());
        // extract the id
        String id = domainRTO.getId();
        id = id.substring(id.indexOf('-') + 1);

        // update oif
        if (!updateOIF(domainRTO, source, id)){
            return null;
        }

        if (!updateNMS(domainRTO, source, id)){
            return null;
        }

        return get(id, source);
    }

    /**
     * Create Network Domain.
     * {@inheritDoc}
     */
    @Override
    public DomainRTO create(DomainRTO domainRTO) throws DomainProviderException {
        // validate that the domain does not exist (by name)
        String domainName = domainRTO.getName();
        if(domainExists(domainName)) {
            throw new DomainProviderException(OrchestrationErrorCode.ERROR_DOMAIN_EXISTS);
        }
        // validate that the subscriber does not exist (by name)
        if(subscriberExists(domainName)) {
            throw new DomainProviderException(OrchestrationErrorCode.ERROR_SUBSCRIBER_EXISTS);
        }
        // validate that the security domain does not exist (by name)
        if(securityDomainExists(domainName)) {
            throw new DomainProviderException(OrchestrationErrorCode.ERROR_SECURITY_DOMAIN_EXISTS);
        }

        // create domain
        // create subscriber
        // create security domain

        if (!createOIF(domainRTO)){
            return null;
        }

        // Create Subscriber Container - WPA
        ContainerID containerID = new ContainerID.Builder(0).build();
        Container container = new Container.Builder(containerID)
                .name(domainName)
                .serviceLevel(domainRTO.getNmsServiceLevel())
                .parentContainerId(0)
                .containerType(ContainerType.SUBSCRIBER)

                .putInfo(ContainerInfo.ADDRESS,             domainRTO.getNmsInfoAddress())
                .putInfo(ContainerInfo.PHONE,               domainRTO.getNmsInfoPhone())
                .putInfo(ContainerInfo.FAX,                 domainRTO.getNmsInfoFax())
                .putInfo(ContainerInfo.EMAIL,               domainRTO.getNmsInfoEmail())
                .putInfo(ContainerInfo.URL,                 domainRTO.getNmsInfoURL())
                .putInfo(ContainerInfo.ORGANIZATION,        domainRTO.getNmsInfoOrganization())
                .putInfo(ContainerInfo.CONTACT_PERSON,      domainRTO.getNmsInfoContactPerson())
                .putInfo(ContainerInfo.DESCRIPTION,         domainRTO.getNmsDescription())
                .putInfo(ContainerInfo.EXTERNAL_REFERENCE,  domainRTO.getNmsInfoExternalReference())

                .build();

        ContainerID newContainerID = containerEntityOperations.insert(getSecurityToken(), container);

        if (null == newContainerID || newContainerID.getId() == 0) {
            LOGGER.debug("Failed to create NMS Container. Returning null");
            return null;
        }

        // Create Security Domain - WPA
        SecurityDomainID securityDomainID = new SecurityDomainID.Builder(0L).build();
        SecurityDomain securityDomain = new SecurityDomain.Builder(securityDomainID)
                .name(domainName)
                .description(domainRTO.getNmsDescription())
                .build();

        SecurityDomainID newSecurityDomainID = securityDomainOperations.insert(getSecurityToken(), securityDomain);

        if (null == newSecurityDomainID) {
            LOGGER.debug("Failed to create NMS Security Domain. Returning null");
            return null;
        }

        // Associate Subscriber to Security Domain - WPA
        SecurableElementID securableElementID = securityDomainOperations.assign(
                getSecurityToken(),
                newSecurityDomainID,
                new SecurableElementID.Builder().setId(newContainerID.getId()).setType(SecurableElementType.COMMON_CONTAINER).build()
        );

        if (null == securableElementID) {
            LOGGER.debug("Failed to associate securable element to security domain. Returning null");
            return null;
        }

        DataSource source = isOIFAvailable() ? TC : NMS;
        String id = Long.toString(newContainerID.getId());

        return get(id, source);
    }

    /**
     * Delete Network Domain.
     * {@inheritDoc}
     */
    @Override
    public void delete(DataSource source, String id ) throws DomainProviderException {
        String domainId = id;
        id = id.substring(id.indexOf('-') + 1);

        switch(source) {
            // if the source is TC, then we require the name of the container to be obtained
            case TC :
                // fetch summary to retrieve name of the container
                Container container = containerEntityOperations.getDetails(
                        getSecurityToken(),
                        new ContainerID.Builder(Long.valueOf(id)).build()
                );
                String containerName = container.getName();
                domainId = fetchOIFId(containerName).orElse(null);
            case SDN :
                if(domainId != null) {
                    NetworkID networkId = new NetworkID.Builder(domainId).build();
                    networkEntityOperations.delete( getSecurityToken(), networkId );
                }
                break;
            default:
                LOGGER.warn("Delete command failed for domain with id {} and source {}. Operation unsupported", id, source);
        }
    }

    /**
     *
     * @param domain
     * @param oifMatchedByName
     * @return
     */
    private void mergeRTO( DomainRTO domain, DomainRTO oifMatchedByName ) {
        domain.setDataSource( TC.getName() );
        domain.setOifProtocols( oifMatchedByName.getOifProtocols() );
        domain.setOifTopologyType( oifMatchedByName.getOifTopologyType() );
        domain.setOifUserDomain( oifMatchedByName.getOifUserDomain() );
        domain.setOifAdminState( oifMatchedByName.getOifAdminState() );
        domain.setOifId(oifMatchedByName.getOifId());
    }

    /**
     *
     * @param oifRtos
     * @param domainName
     * @return
     */
    private DomainRTO getByNameFrom( List<DomainRTO> oifRtos, String domainName ) {
        for (DomainRTO oifDomain : oifRtos) {
            if (Objects.equals(oifDomain.getName(), domainName)) {
                return oifDomain;
            }
        }

        return null;
    }

    /**
     * Get Network Operation Result From Name.
     * @param containerName
     * @return
     */
    private OperationResult<Network, NetworkField> getNetworkOperationResultFromName(String containerName) {
        Filter<NetworkField> networkFieldFilter = new Filter.Builder<>(NetworkField.NAME, FilterOperation.EQUALS, containerName).build();

        return networkEntityOperations.getAll(getSecurityToken(),
                Collections.singletonList(networkFieldFilter), null, null);
    }

    /**
     *
     * @param domainRTO
     * @param source
     * @param id
     * @return
     */
    private boolean updateNMS(DomainRTO domainRTO, DataSource source, String id) {
        if((source.equals(NMS) || source.equals(TC))) {
            // Update Subscriber Container - WPA, only the description can be edited/updated
            ContainerID containerID = new ContainerID.Builder(Long.parseLong(id)).build();
            Container container = new Container.Builder(containerID)
                    .name(domainRTO.getName())
                    .serviceLevel(domainRTO.getNmsServiceLevel())
                    .parentContainerId(0) // use here?
                    .containerType(ContainerType.SUBSCRIBER)

                    .putInfo(ContainerInfo.ADDRESS,             domainRTO.getNmsInfoAddress())
                    .putInfo(ContainerInfo.PHONE,               domainRTO.getNmsInfoPhone())
                    .putInfo(ContainerInfo.FAX,                 domainRTO.getNmsInfoFax())
                    .putInfo(ContainerInfo.EMAIL,               domainRTO.getNmsInfoEmail())
                    .putInfo(ContainerInfo.URL,                 domainRTO.getNmsInfoURL())
                    .putInfo(ContainerInfo.ORGANIZATION,        domainRTO.getNmsInfoOrganization())
                    .putInfo(ContainerInfo.CONTACT_PERSON,      domainRTO.getNmsInfoContactPerson())
                    .putInfo(ContainerInfo.DESCRIPTION,         domainRTO.getNmsDescription())
                    .putInfo(ContainerInfo.EXTERNAL_REFERENCE,  domainRTO.getNmsInfoExternalReference())

                    .build();

            if ( containerEntityOperations.update(getSecurityToken(), container) == null ) {
                return false;
            }
        }
        // if the domain is not of the identified sources, and the previous operations were successful, then
        // the update operation is considered successful
        return true;
    }

    /**
     *
     * @param domainRTO
     * @param dataSource
     * @param id
     * @return
     */
    private boolean updateOIF(DomainRTO domainRTO, DataSource dataSource, String id) {
        if ((dataSource.equals(SDN) || dataSource.equals(TC))) {
            String sdnId = id;
            if(dataSource.equals(TC)) {
                Optional<String> optId = fetchOIFId(domainRTO.getName());
                if(optId.isPresent()) {
                    sdnId = optId.get();
                } else {
                    return false;
                }
            }

            NetworkID networkId = new NetworkID.Builder(sdnId).build();
            Network domain = new Network.Builder(networkId)
                    .setName(domainRTO.getName())
                    .setProtocols(domainRTO.getOifProtocols())
                    .build();

            if ( networkEntityOperations.update( getSecurityToken(), domain ) == null) {
                return false;
            }
        }
        // if the domain is not of the identified sources, and the previous operations were successful, then
        // the update operation is considered successful
        return true;
    }

    /**
     *
     * @param domainName
     * @return
     */
    private Optional<String> fetchOIFId(String domainName) {
        Filter<NetworkField> networkFieldFilter = new Filter.Builder<>(NetworkField.NAME, FilterOperation.EQUALS, domainName).build();
        OperationResult<NetworkID, NetworkField> allIds = networkEntityOperations.getAllIds(
                getSecurityToken(),
                Collections.singletonList(networkFieldFilter),
                null,
                null
        );
        return allIds.getResultCollection().stream().findFirst().map(NetworkID::getID);
    }

    /**
     *
     * @param domainName
     * @return
     */
    private Optional<ContainerID> fetchSubscriberId(String domainName) {
        // create the required filters
        Filter<ContainerField> containerFieldFilter = getSubscriberTypeFilter();
        Filter<ContainerField> nameFilter = getContainerNameFilter(domainName);

        // collect them
        List<Filter<ContainerField>> filters = new ArrayList<>(2);
        filters.add(containerFieldFilter);
        filters.add(nameFilter);

        // fetch from container entity operations - WPA
        OperationResult<ContainerID, ContainerField> allFromNMS = containerEntityOperations.getAllIds(
                getSecurityToken(),
                filters,
                null,
                null
        );

        return allFromNMS.getResultCollection().stream().findFirst();
    }

    /**
     *
     * @param domainName
     * @return
     */
    private Optional<SecurityDomain> fetchSecurityDomainId(String domainName) {
        // fetch from security domain entity operations - WPA
        SecurityDomain securityDomain = securityDomainOperations.getDetailsByName(
                getSecurityToken(),
                domainName
        );

        return Optional.ofNullable(securityDomain);
    }

    /**
     *
     * @return
     */
    private Filter<ContainerField> getSubscriberTypeFilter() {
        // create filter by container type SUBSCRIBER
        return new Filter.Builder<>(
                ContainerField.TYPE,
                FilterOperation.EQUALS,
                ContainerType.SUBSCRIBER.getName().toUpperCase()
        ).build();
    }

    /**
     *
     * @param name
     * @return
     */
    private Filter<ContainerField> getContainerNameFilter(String name) {
        // create filter by container type SUBSCRIBER
        return new Filter.Builder<>(
                ContainerField.NAME,
                FilterOperation.EQUALS,
                name
        ).build();
    }

    /**
     *
     * @param name
     * @return
     */
    private boolean securityDomainExists(String name) {
        Optional<SecurityDomain> securityDomainID = fetchSecurityDomainId(name);
        return securityDomainID.isPresent();
    }

    /**
     *
     * @param name
     * @return
     */
    private boolean subscriberExists(String name) {
        Optional<ContainerID> containerID = fetchSubscriberId(name);
        return containerID.isPresent();
    }

    /**
     *
     * @param name
     * @return
     */
    private boolean domainExists(String name) {
        if(isOIFAvailable()) {
            if(name.equals( OrchestrationConstants.SDN_PROVIDER_NAME)) {
                return true;
            }

            // produce filter by name
            Optional<String> optDomainId = fetchOIFId(name);
            return optDomainId.isPresent();
        }

        return false;
    }

    /**
     *
     * @param domainRTO
     * @return
     */
    private boolean createOIF(DomainRTO domainRTO) {
        if ( isOIFAvailable() ) {
            // Create Domain - OIF Rest
            Network network = new Network.Builder(null)
                    .setName(domainRTO.getName())
                    .setTopologyType(domainRTO.getOifTopologyType())
                    .setProtocols( domainRTO.getOifProtocols() == null || domainRTO.getOifProtocols().length == 0 ? DEFAULT_DOMAIN_PROTOCOLS : domainRTO.getOifProtocols() )
                    .setAdminState(domainRTO.getOifAdminState())
                    .build();

            NetworkID newDomainID = networkEntityOperations.insert(getSecurityToken(), network);

            if (null == newDomainID) {
                return false;
            }
        }
        return true;
    }

    /**
     *
     * @param domainFactory
     * @return
     */
    private void decorateWithOIFData(DomainFactory domainFactory) {
        if ( isOIFAvailable() && domainFactory != null ) {
            // obtain the current state
            DomainRTO rto = domainFactory.build();
            OperationResult<Network, NetworkField> operationResult = getNetworkOperationResultFromName(rto.getName());

            if ( null != operationResult && !operationResult.getResultCollection().isEmpty() ) {
                Network network = operationResult.getResultCollection().iterator().next();
                domainFactory.from(network);
            }
        }
    }
}