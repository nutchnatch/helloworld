package com.ossnms.web.api.orchestration.service.api.factory;

import com.ossnms.web.api.orchestration.common.api.model.EndpointRTO;
import com.ossnms.web.api.orchestration.common.api.model.TrafficParamRTO;
import com.ossnms.web.api.orchestration.service.api.model.ProtectionGroupRTO;
import com.ossnms.web.api.orchestration.service.api.model.RoutingFailureDetailRTO;
import com.ossnms.web.api.orchestration.service.api.model.SLARTO;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.ProtectionGroup;
import com.ossnms.web.provider.sdn.model.call.RoutingFailureDetail;
import com.ossnms.web.provider.sdn.model.call.SLA;
import com.ossnms.web.provider.sdn.model.common.attributes.TrafficParam;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointID;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by 68500245 on 13-01-2017.
 */
public final class CallFactory {

   private Call.Builder b = new Call.Builder( null );


   public CallFactory from( String domainId, String id ) {

      b = new Call.Builder( new CallID.Builder( domainId, id ).build() );

      return this;
   }


   /**
    *
     * @param service
    * @return
    */
   public CallFactory from( ServiceRTO service ) {

      from( getStringValueOrNull( service.getOifDomainId() ), getStringValueOrNull( service.getOifId() ) );

      b.setName( service.getName() );
      b.setPathRequestId( service.getOifPathRequestId() );

      EndpointRTO aEnd = service.getOifAEnd();

      if ( aEnd != null ) {

         b.setAEnd( new EndpointSummary.Builder( new EndpointID.Builder( String.valueOf( aEnd.getOifDomainId() ), String.valueOf( aEnd.getOifId() ) ).build() ).build() );
      }

      EndpointRTO zEnd = service.getOifZEnd();

      if ( zEnd != null ) {

         b.setZEnd( new EndpointSummary.Builder( new EndpointID.Builder( String.valueOf( zEnd.getOifDomainId() ), String.valueOf( zEnd.getOifId() ) ).build() ).build() );
      }

      TrafficParamRTO trafficParams = service.getOifTrafficParams();

      if ( trafficParams != null ) {

         b.setTrafficParam( new TrafficParam.Builder()
               .setSigType( trafficParams.getSigType() )
               .setBandwidth( trafficParams.getBandwidth() )
               .setMultiplier( trafficParams.getMultiplier() )
               .build()
         );
      }

      b.setOperStatus( service.getOifCallOperStatus() );
      b.setAdminStatus( service.getOifAdminStatus() );

      b.setCallProvisioningStatus( service.getOifCallProvisioningStatus() );
      b.setCallConfigStatus( service.getOifCallConfigStatus() );
      b.setNetworkSyncStatus( service.getOifNetworkSyncStatus() );

      b.setCallLatency( service.getOifCallLatency() );
      b.setRoutingFailureDetail( buildRoutingFailureDetail( service.getRoutingFailureDetail() ) );

      b.setSwitchingType( service.getOifSwitchingType() );
      b.setEncoding( service.getOifEncoding() );
      b.setDirectionality( service.getOifDirectionality() );

      b.setServiceLatency( service.getOifServiceLatency() );

      b.setRoutingOverExistingServicesOnly( service.getOifRoutingOverExistingServicesOnly() );
      b.setRoutingOverEnabledResourcesOnly( service.getOifRoutingOverEnabledResourcesOnly() );
      b.setRoutingOverNotReservedResourcesOnly( service.getOifRoutingOverNotReservedResourcesOnly() );

      b.setOrderNumber( service.getOifOrderNumber() );

      b.setSla( buildSLA( service.getOifSla() ) );

      b.setRestorable( service.getOifRestorable() );
      b.addProtectionGroups( buildProtectionGroups( service.getOifProtectionGroups() ) );

      return this;
   }

   /**
    * @param value
    * @return
    */
   private static String getStringValueOrNull( Long value ) {

      return value == null ? null : String.valueOf( value );
   }

   /**
    *
    * @param sla
    * @return
    */
   private static SLA buildSLA( SLARTO sla ) {

      if ( sla == null ) {

         return null;
      }

      return new SLA.Builder()
                 .setSLAMonitoring( sla.isMonitoring() )
                 .setThroughput( sla.getThroughput() )
                 .setCallImpairmentStatus( sla.getCallImpairmentStatus() )
                 .setCallLastImpairmentStatusTimestamp( sla.getCallLastImpairmentStatusTimestamp() )
                 .build();
   }

   /**
    *
    * @param routingFailureDetail
    * @return
    */
   private static RoutingFailureDetail buildRoutingFailureDetail( RoutingFailureDetailRTO routingFailureDetail ) {

      if ( routingFailureDetail == null ) {

         return null;
      }

      return new RoutingFailureDetail.Builder()
                 .setFailureCode( routingFailureDetail.getFailureCode() )
                 .setFailureDescription( routingFailureDetail.getFailureDescription() )
                 .build();
   }

   /**
    *
    * @param oifProtectionGroups
    * @return
    */
   private static List<ProtectionGroup> buildProtectionGroups( List<ProtectionGroupRTO> oifProtectionGroups ) {

      if ( oifProtectionGroups == null ) {

         return Collections.emptyList();
      }

      return oifProtectionGroups.stream()
            .map( item -> new ProtectionGroup.Builder()
                     .setId( item.getId() )
                     .setProtectionMode( item.getProtectionMode() )
                     .setProtectionType( item.getProtectionType() )
                     .setProtectionState( item.getProtectionState() )
                     .setRestorationGate( item.getRestorationGate() )
                     .build()
            )
            .collect( Collectors.toList() );
   }


   /**
    *
    * @return
    */
   public Call build() {

      return b.build();
   }
}