package com.ossnms.web.api.orchestration.topology.api.factory;

import com.ossnms.web.api.orchestration.topology.api.model.EdgeRTO;
import com.ossnms.web.provider.sdn.model.edge.EdgeSummary;

/**
 * Created by 68500245 on 20-12-2016.
 */
public final class EdgeFactory {

   private EdgeRTO edge = new EdgeRTO();


   public EdgeFactory from( EdgeSummary edgeSummary ) {

      if ( edgeSummary != null ) {

         if ( edgeSummary.getID() != null ) {

            edge.setOifId( Long.parseLong( edgeSummary.getID().getID() ) );
            edge.setOifDomainId( Long.parseLong( edgeSummary.getID().getDomainId() ) );
         }

         edge.setOifName( edgeSummary.getName() );
         edge.setOifAEnd( new EdgeEndFactory().from( edgeSummary.getAEnd() ).build() );
         edge.setOifZEnd( new EdgeEndFactory().from( edgeSummary.getZEnd() ).build() );
      }

      return this;
   }

   /**
    *
    * @return
    */
   public EdgeRTO build() {

      return edge;
   }
}