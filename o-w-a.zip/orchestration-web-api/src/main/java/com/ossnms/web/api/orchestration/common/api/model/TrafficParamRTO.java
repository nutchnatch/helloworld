package com.ossnms.web.api.orchestration.common.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "trafficParam")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class TrafficParamRTO extends BaseRTO {

    private static final long serialVersionUID = 1729163160524309168L;

    @XmlAttribute
    private String sigType;

    @XmlAttribute
    private String multiplier;

    @XmlAttribute
    private String bandwidth;

    public String getSigType() {
        return sigType;
    }

    public void setSigType(String sigType) {
        this.sigType = sigType;
    }

    public String getMultiplier() {
        return multiplier;
    }

    public void setMultiplier(String multiplier) {
        this.multiplier = multiplier;
    }

    public String getBandwidth() {
        return bandwidth;
    }

    public void setBandwidth(String bandwidth) {
        this.bandwidth = bandwidth;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        TrafficParamRTO that = (TrafficParamRTO) o;
        return Objects.equals(sigType, that.sigType) &&
                Objects.equals(multiplier, that.multiplier) &&
                Objects.equals(bandwidth, that.bandwidth);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sigType, multiplier, bandwidth);
    }
}
