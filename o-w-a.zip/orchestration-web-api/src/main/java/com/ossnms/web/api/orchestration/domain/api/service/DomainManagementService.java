package com.ossnms.web.api.orchestration.domain.api.service;

import com.ossnms.web.api.orchestration.common.api.DataSource;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.PageParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.SortParameter;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.CONTEXT_ID;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.CONTEXT_ROOT;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.DATA_SOURCE;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.ID;
import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.URL_DOMAIN;
import static com.ossnms.web.api.orchestration.common.constant.Permissions.PERMISSION_CARRIER_ACCESS;
import static com.ossnms.web.api.orchestration.common.constant.Permissions.PERMISSION_CUSTOMER_ACCESS;

/**
 *
 */
@Path( URL_DOMAIN )
@Consumes( { MediaType.APPLICATION_JSON } )
@Produces( { MediaType.APPLICATION_JSON } )
public interface DomainManagementService {

    /**
     *
     * @return
     */
    @GET
    @RolesAllowed({PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS})
    @Path(CONTEXT_ROOT)
    Response getAll(
            @BeanParam DetailsParameter detailsParameter,
            @BeanParam PageParameter pageParameter,
            @BeanParam SortParameter sortParameter,
            @BeanParam FilterParameter filterParameter
    );

    /**
     *
     * @param id
     * @return
     */
    @GET
    @RolesAllowed({PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS})
    @Path(CONTEXT_ID)
    Response get(
            @PathParam(DATA_SOURCE) DataSource dataSource,
            @PathParam(ID) String id
    );

    /**
     *
     * @return
     */
    @POST
    @RolesAllowed({PERMISSION_CARRIER_ACCESS})
    @Path(CONTEXT_ROOT)
    Response add(DomainRTO domain);

    /**
     *
     * @param id
     * @return
     */
    @PUT
    @RolesAllowed({PERMISSION_CARRIER_ACCESS})
    @Path(CONTEXT_ID)
    Response update(@PathParam(DATA_SOURCE) DataSource dataSource, @PathParam(ID) String id, DomainRTO domain);

    /**
     *
     * @param id
     */
    @DELETE
    @RolesAllowed({PERMISSION_CARRIER_ACCESS})
    @Path(CONTEXT_ID)
    void delete(@PathParam(DATA_SOURCE) DataSource dataSource, @PathParam(ID) String id);
}
