package com.ossnms.web.api.orchestration.common.api;

import com.ossnms.web.provider.common.utils.EnumHelper;

/**
 *
 */
public enum DataSource {
    SDN( "SDN" ),
    NMS( "NMS" ),
    TC( "TC" );

    private final String name;

    DataSource( String name ) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     * @return
     */
    public static DataSource fromName( String name ) {
        return EnumHelper.getValue(values(), (candidate) -> candidate.getName().toLowerCase().equals(name.toLowerCase()) );
    }
}
