package com.ossnms.web.api.orchestration.common.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;
import java.util.Objects;

/**
 *
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "alarm")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AlarmRTO extends BaseRTO {

    private static final long serialVersionUID = -3997396900831213352L;

    @XmlAttribute(name="nms.id")
    private String id;

    @XmlAttribute(name="nms.timestamp")
    private Date timestamp;

    @XmlAttribute(name="nms.alarmSeverity")
    private String alarmSeverity;

    @XmlAttribute(name="nms.alarmClass")
    private String alarmClass;

    @XmlAttribute(name="nms.probableCause")
    private String probableCause;

    @XmlAttribute(name="nms.faultCondition")
    private String faultCondition;

    @XmlAttribute(name="nms.affectedObjectLocation")
    private String affectedObjectLocation;

    @XmlAttribute(name="nms.affectedNEName")
    private String affectedNEName;

    @XmlAttribute(name = "nms.raiseTime")
    private Date raiseTime;

    @XmlAttribute(name = "nms.acknowledgeTime")
    private Date acknowledgeTime;

    @XmlAttribute(name = "nms.acknowledgedBy")
    private String acknowledgedBy;

    @XmlAttribute(name = "nms.trafficDirection")
    private String trafficDirection;

    /**
     *
     */
    public String getId() {
        return id;
    }

    public AlarmRTO setId(String id) {
        this.id = id;
        return this;
    }

    /**
     *
     */
    public Date getTimestamp() {
        return timestamp;
    }

    public AlarmRTO setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
        return this;
    }

    /**
     *
     */
    public String getAlarmSeverity() {
        return alarmSeverity;
    }

    public AlarmRTO setAlarmSeverity(String alarmSeverity) {
        this.alarmSeverity = alarmSeverity;
        return this;
    }

    /**
     *
     */
    public String getAlarmClass() {
        return alarmClass;
    }

    public AlarmRTO setAlarmClass(String alarmClass) {
        this.alarmClass = alarmClass;
        return this;
    }

    /**
     *
     */
    public String getProbableCause() {
        return probableCause;
    }

    public AlarmRTO setProbableCause(String probableCause) {
        this.probableCause = probableCause;
        return this;
    }

    /**
     *
     */
    public String getFaultCondition() {
        return faultCondition;
    }

    public AlarmRTO setFaultCondition(String faultCondition) {
        this.faultCondition = faultCondition;
        return this;
    }

    /**
     *
     */
    public String getAffectedObjectLocation() {
        return affectedObjectLocation;
    }

    public AlarmRTO setAffectedObjectLocation(String affectedObjectLocation) {
        this.affectedObjectLocation = affectedObjectLocation;
        return this;
    }

    /**
     *
     */
    public String getAffectedNEName() {
        return affectedNEName;
    }

    public AlarmRTO setAffectedNEName(String affectedNEName) {
        this.affectedNEName = affectedNEName;
        return this;
    }

    /**
     *
     */
    public Date getRaiseTime() {
        return raiseTime;
    }

    public AlarmRTO setRaiseTime(Date raiseTime) {
        this.raiseTime = raiseTime;
        return this;
    }

    /**
     *
     */
    public Date getAcknowledgeTime() {
        return acknowledgeTime;
    }

    public AlarmRTO setAcknowledgeTime(Date acknowledgeTime) {
        this.acknowledgeTime = acknowledgeTime;
        return this;
    }

    /**
     *
     */
    public String getAcknowledgedBy() {
        return acknowledgedBy;
    }

    public AlarmRTO setAcknowledgedBy(String acknowledgedBy) {
        this.acknowledgedBy = acknowledgedBy;
        return this;
    }

    /**
     *
     */
    public String getTrafficDirection() {
        return trafficDirection;
    }

    public AlarmRTO setTrafficDirection(String trafficDirection) {
        this.trafficDirection = trafficDirection;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AlarmRTO alarmRTO = (AlarmRTO) o;
        return Objects.equals(getId(), alarmRTO.getId()) &&
                Objects.equals(getTimestamp(), alarmRTO.getTimestamp()) &&
                Objects.equals(getAlarmSeverity(), alarmRTO.getAlarmSeverity()) &&
                Objects.equals(getAlarmClass(), alarmRTO.getAlarmClass()) &&
                Objects.equals(getProbableCause(), alarmRTO.getProbableCause()) &&
                Objects.equals(getFaultCondition(), alarmRTO.getFaultCondition()) &&
                Objects.equals(getAffectedObjectLocation(), alarmRTO.getAffectedObjectLocation()) &&
                Objects.equals(getAffectedNEName(), alarmRTO.getAffectedNEName()) &&
                Objects.equals(getRaiseTime(), alarmRTO.getRaiseTime()) &&
                Objects.equals(getAcknowledgeTime(), alarmRTO.getAcknowledgeTime()) &&
                Objects.equals(getAcknowledgedBy(), alarmRTO.getAcknowledgedBy()) &&
                Objects.equals(getTrafficDirection(), alarmRTO.getTrafficDirection());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getTimestamp(), getAlarmSeverity(), getAlarmClass(), getProbableCause(), getFaultCondition(), getAffectedObjectLocation(), getAffectedNEName(), getRaiseTime(), getAcknowledgeTime(), getAcknowledgedBy(), getTrafficDirection());
    }
}
