package com.ossnms.web.api.orchestration.common.api.resources.inbound;

/**
 *
 */
public enum SortDirections {
    ASC,
    DSC;
}
