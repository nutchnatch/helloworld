package com.ossnms.web.api.orchestration.service.api.model;

import com.ossnms.web.api.orchestration.common.api.BaseRTO;
import com.ossnms.web.api.orchestration.common.api.DataSource;
import com.ossnms.web.api.orchestration.common.api.model.EndpointRTO;
import com.ossnms.web.api.orchestration.common.api.model.SrgDetailRTO;
import com.ossnms.web.api.orchestration.common.api.model.TrafficParamRTO;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.api.orchestration.service.api.model.enumerable.ServiceType;
import com.ossnms.web.api.orchestration.service.api.model.packet.PacketServiceRTO;
import com.ossnms.web.api.orchestration.topology.api.model.EdgeRTO;
import com.ossnms.web.provider.network.model.common.enumerable.OperationalState;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@XmlAccessorType( XmlAccessType.NONE )
@XmlRootElement( name = "service" )
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonSerialize( include = JsonSerialize.Inclusion.NON_NULL )
public class ServiceRTO extends BaseRTO{

    private static final long serialVersionUID = 1267353791498308493L;

    @XmlAttribute (name = "name")
    private String name;

    @XmlAttribute (name = "serviceType")
    private ServiceType serviceType = ServiceType.OPTICAL;

    @XmlAttribute (name = "domain")
    private DomainRTO domain;

    @XmlAttribute (name = "provisioningState")
    private String provisioningState;

    @XmlAttribute(name = "nms.id")
    private Long nmsId;

    @XmlAttribute(name = "nms.pathType")
    private String nmsPathType;

    @XmlAttribute(name = "nms.pathSubType")
    private String nmsPathSubType;

    @XmlAttribute(name = "nms.pathStatus")
    private String nmsPathStatus;

    @XmlAttribute(name = "nms.serviceName")
    private String nmsServiceName;

    @XmlAttribute(name = "nms.subscriberName")
    private String nmsSubscriberName;

    @XmlAttribute(name = "nms.alarmSeverity")
    private String nmsAlarmSeverity;

    @XmlAttribute(name = "nms.operationalState")
    private String nmsOperationalState;

    @XmlAttribute(name = "nms.administrativeState")
    private String nmsAdministrativeState;

    @XmlAttribute(name = "nms.actualCreationState")
    private String nmsActualCreationState;

    @XmlAttribute(name = "nms.requiredCreationState")
    private String nmsRequiredCreationState;

    @XmlAttribute(name = "nms.managedState")
    private String nmsManagedState;

    @XmlAttribute(name = "nms.type")
    private String nmsType;

    @XmlAttribute(name = "nms.aNode")
    private String nmsANode;

    @XmlAttribute(name = "nms.zNode")
    private String nmsZNode;

    @XmlAttribute(name = "nms.protection")
    private String nmsProtection;

    @XmlAttribute(name = "nms.bandwidth")
    private String nmsBandwidth;

    @XmlAttribute(name = "nms.description")
    private String nmsDescription;

    @XmlAttribute(name = "nms.activeRoute")
    private String nmsActiveRoute;

    @XmlAttribute(name = "nms.connectionClass")
    private String nmsConnectionClass;

    @XmlAttribute(name = "nms.routeState")
    private String nmsRouteState;

    @XmlAttribute(name = "nms.createdBy")
    private String nmsCreatedBy;

    @XmlAttribute(name = "nms.direction")
    private String nmsDirection;

    @XmlAttribute(name = "nms.numberOfNes")
    private Integer nmsNumberOfNes;

    @XmlAttribute(name = "nms.aPtpTp")
    private String nmsAPtpTp;

    @XmlAttribute(name = "nms.zPtpTp")
    private String nmsZPtpTp;

    @XmlAttribute(name = "nms.tpConfiguration")
    private String nmsTpConfiguration;

    @XmlAttribute(name = "nms.lastDisabledTime")
    private Long nmsLastDisabledTime;

    @XmlAttribute(name = "nms.layer")
    private String nmsLayer;

    @XmlAttribute(name = "nms.payloadCLFI")
    private String nmsPayloadCLFI;

    @XmlAttribute(name = "nms.projectId")
    private Long nmsProjectId;

    @XmlAttribute(name = "nms.vlanId")
    private Integer nmsVlanId;

    @XmlAttribute(name = "nms.transportType")
    private String nmsTransportType;

    @XmlAttribute(name = "nms.correlationMode")
    private String nmsCorrelationMode;

    @XmlAttribute(name = "nms.alarmMask")
    private String nmsAlarmMask;

    @XmlAttribute(name = "nms.acknowledgedBy")
    private String nmsAcknowledgedBy;

    @XmlAttribute(name="nms.acknowledgedTime")
    private Long nmsAcknowledgedTime;

    @XmlAttribute(name="nms.commonContainerId")
    private Long nmsCommonContainerId;

    @XmlAttribute(name="nms.occupancyAz")
    private Float nmsOccupancyAz;

    @XmlAttribute(name="nms.occupancyZa")
    private Float nmsOccupancyZa;

    @XmlAttribute(name = "oif.id")
    private Long oifId;

    @XmlAttribute(name = "oif.domainId")
    private Long oifDomainId;

    @XmlAttribute(name = "oif.PathRequestId")
    private String oifPathRequestId;

    @XmlAttribute(name = "oif.trafficParams")
    private TrafficParamRTO oifTrafficParams;

    @XmlAttribute(name = "oif.adminStatus")
    private String oifAdminStatus;

    @XmlAttribute(name = "oif.callOperStatus")
    private String oifCallOperStatus;

    @XmlAttribute(name = "oif.callProvisioningStatus")
    private String oifCallProvisioningStatus;

    @XmlAttribute(name = "oif.callConfigStatus")
    private String oifCallConfigStatus;

    @XmlAttribute(name = "oif.networkSyncStatus")
    private String oifNetworkSyncStatus;

    @XmlAttribute(name = "oif.callLatency")
    private Integer oifCallLatency;

    @XmlAttribute(name = "oif.routingFailureDetail")
    private RoutingFailureDetailRTO routingFailureDetail;

    @XmlAttribute(name = "oif.switchingType")
    private Integer oifSwitchingType;

    @XmlAttribute(name = "oif.encoding")
    private Integer oifEncoding;

    @XmlAttribute(name = "oif.directionality")
    private String oifDirectionality;

    @XmlAttribute(name = "oif.path")
    private List<EdgeRTO> oifPath;

    @XmlAttribute(name = "oif.serviceLatency")
    private List<Long> oifServiceLatency;

    @XmlAttribute(name = "oif.routingOverExistingServicesOnly")
    private Boolean oifRoutingOverExistingServicesOnly;

    @XmlAttribute(name = "oif.routingOverEnabledResourcesOnly")
    private Boolean oifRoutingOverEnabledResourcesOnly;

    @XmlAttribute(name = "oif.routingOverNotReservedResourcesOnly")
    private Boolean oifRoutingOverNotReservedResourcesOnly;

    @XmlAttribute(name = "oif.orderNumber")
    private String oifOrderNumber;

    @XmlAttribute(name="oif.sla" )
    private SLARTO oifSla;

    @XmlAttribute(name = "oif.srgDetails")
    private List<SrgDetailRTO> oifSrgDetails;

    @XmlAttribute(name = "oif.restorable")
    private Boolean oifRestorable;

    @XmlAttribute(name = "oif.aEnd")
    private EndpointRTO oifAEnd;

    @XmlAttribute(name = "oif.zEnd")
    private EndpointRTO oifZEnd;

    @XmlAttribute(name = "oif.connections")
    private List<ConnectionRTO> oifConnections;

    @XmlAttribute(name = "oif.protectionGroups")
    private List<ProtectionGroupRTO> oifProtectionGroups;

    @XmlAttribute (name = "packet")
    private PacketServiceRTO packetService;


    /**
     *
     * @return
     */
    public String getName() { return name; }

    public ServiceRTO setName(String name ) {

        this.name = name;
        return this;
    }

    /**
     *
     */
    public ServiceType getServiceType() {
        return serviceType;
    }

    /**
     *
     * @param serviceType
     * @return
     */
    public ServiceRTO setServiceType(ServiceType serviceType) {
        this.serviceType = serviceType;
        return this;
    }

    /**
     *
     * @return
     */
    public DomainRTO getDomain() {

        return domain;
    }

    public ServiceRTO setDomain(DomainRTO domain ) {

        this.domain = domain;
        return this;
    }

    /**
     *
     */
    public Long getNmsId() {
        return nmsId;
    }

    public ServiceRTO setNmsId(Long nmsId) {
        this.nmsId = nmsId;
        return this;
    }

    /**
     *
     */
    public String getNmsPathType() {
        return nmsPathType;
    }

    public ServiceRTO setNmsPathType(String nmsPathType) {
        this.nmsPathType = nmsPathType;
        return this;
    }

    /**
     *
     */
    public String getNmsPathSubType() {
        return nmsPathSubType;
    }

    public ServiceRTO setNmsPathSubType(String nmsPathSubType) {
        this.nmsPathSubType = nmsPathSubType;
        return this;
    }

    /**
     *
     */
    public String getNmsPathStatus() {
        return nmsPathStatus;
    }

    public ServiceRTO setNmsPathStatus(String nmsPathStatus) {
        this.nmsPathStatus = nmsPathStatus;
        return this;
    }

    /**
     *
     */
    public String getNmsServiceName() {
        return nmsServiceName;
    }

    public ServiceRTO setNmsServiceName(String nmsServiceName) {
        this.nmsServiceName = nmsServiceName;
        return this;
    }

    /**
     *
     */
    public String getNmsSubscriberName() {
        return nmsSubscriberName;
    }

    public ServiceRTO setNmsSubscriberName(String nmsSubscriberName) {
        this.nmsSubscriberName = nmsSubscriberName;
        return this;
    }

    /**
     *
     */
    public String getNmsAlarmSeverity() {
        return nmsAlarmSeverity;
    }

    public ServiceRTO setNmsAlarmSeverity(String nmsAlarmSeverity) {
        this.nmsAlarmSeverity = nmsAlarmSeverity;
        return this;
    }

    /**
     *
     */
    public String getNmsOperationalState() {
        return nmsOperationalState;
    }

    public ServiceRTO setNmsOperationalState(String nmsOperationalState) {
        this.nmsOperationalState = nmsOperationalState;
        return this;
    }

    /**
     *
     */
    public String getNmsAdministrativeState() {
        return nmsAdministrativeState;
    }

    public ServiceRTO setNmsAdministrativeState( String nmsAdministrativeState ) {
        this.nmsAdministrativeState = nmsAdministrativeState;
        return this;
    }

    /**
     *
     */
    public String getNmsActualCreationState() {
        return nmsActualCreationState;
    }

    public ServiceRTO setNmsActualCreationState(String nmsActualCreationState) {
        this.nmsActualCreationState = nmsActualCreationState;
        return this;
    }

    /**
     *
     */
    public String getNmsRequiredCreationState() {
        return nmsRequiredCreationState;
    }

    public ServiceRTO setNmsRequiredCreationState(String nmsRequiredCreationState) {
        this.nmsRequiredCreationState = nmsRequiredCreationState;
        return this;
    }

    /**
     *
     */
    public String getNmsManagedState() {
        return nmsManagedState;
    }

    public ServiceRTO setNmsManagedState(String nmsManagedState) {
        this.nmsManagedState = nmsManagedState;
        return this;
    }

    /**
     *
     */
    public String getNmsType() {
        return nmsType;
    }

    public ServiceRTO setNmsType(String nmsType) {
        this.nmsType = nmsType;
        return this;
    }

    /**
     *
     */
    public String getNmsANode() {
        return nmsANode;
    }

    public ServiceRTO setNmsANode(String nmsANode) {
        this.nmsANode = nmsANode;
        return this;
    }

    /**
     *
     */
    public String getNmsZNode() {
        return nmsZNode;
    }

    public ServiceRTO setNmsZNode(String nmsZNode) {
        this.nmsZNode = nmsZNode;
        return this;
    }

    /**
     *
     */
    public String getNmsProtection() {
        return nmsProtection;
    }

    public ServiceRTO setNmsProtection(String nmsProtection) {
        this.nmsProtection = nmsProtection;
        return this;
    }

    /**
     *
     */
    public String getNmsBandwidth() {
        return nmsBandwidth;
    }

    public ServiceRTO setNmsBandwidth(String nmsBandwidth) {
        this.nmsBandwidth = nmsBandwidth;
        return this;
    }

    /**
     *
     */
    public String getNmsDescription() {
        return nmsDescription;
    }

    public ServiceRTO setNmsDescription(String nmsDescription) {
        this.nmsDescription = nmsDescription;
        return this;
    }

    /**
     *
     */
    public String getNmsActiveRoute() {
        return nmsActiveRoute;
    }

    public ServiceRTO setNmsActiveRoute(String nmsActiveRoute) {
        this.nmsActiveRoute = nmsActiveRoute;
        return this;
    }

    /**
     *
     */
    public String getNmsConnectionClass() {
        return nmsConnectionClass;
    }

    public ServiceRTO setNmsConnectionClass(String nmsConnectionClass) {
        this.nmsConnectionClass = nmsConnectionClass;
        return this;
    }

    /**
     *
     */
    public String getNmsRouteState() {
        return nmsRouteState;
    }

    public ServiceRTO setNmsRouteState(String nmsRouteState) {
        this.nmsRouteState = nmsRouteState;
        return this;
    }

    /**
     *
     */
    public String getNmsCreatedBy() {
        return nmsCreatedBy;
    }

    public ServiceRTO setNmsCreatedBy(String nmsCreatedBy) {
        this.nmsCreatedBy = nmsCreatedBy;
        return this;
    }

    /**
     *
     */
    public String getNmsDirection() {
        return nmsDirection;
    }

    public ServiceRTO setNmsDirection(String nmsDirection) {
        this.nmsDirection = nmsDirection;
        return this;
    }

    /**
     *
     */
    public Integer getNmsNumberOfNes() {
        return nmsNumberOfNes;
    }

    public ServiceRTO setNmsNumberOfNes(Integer nmsNumberOfNes) {
        this.nmsNumberOfNes = nmsNumberOfNes;
        return this;
    }

    /**
     *
     */
    public String getNmsAPtpTp() {
        return nmsAPtpTp;
    }

    public ServiceRTO setNmsAPtpTp(String nmsAPtpTp) {
        this.nmsAPtpTp = nmsAPtpTp;
        return this;
    }

    /**
     *
     */
    public String getNmsZPtpTp() {
        return nmsZPtpTp;
    }

    public ServiceRTO setNmsZPtpTp(String nmsZPtpTp) {
        this.nmsZPtpTp = nmsZPtpTp;
        return this;
    }

    /**
     *
     */
    public String getNmsTpConfiguration() {
        return nmsTpConfiguration;
    }

    public ServiceRTO setNmsTpConfiguration(String nmsTpConfiguration) {
        this.nmsTpConfiguration = nmsTpConfiguration;
        return this;
    }

    /**
     *
     */
    public Long getNmsLastDisabledTime() {
        return nmsLastDisabledTime;
    }

    public ServiceRTO setNmsLastDisabledTime(Long nmsLastDisabledTime) {
        this.nmsLastDisabledTime = nmsLastDisabledTime;
        return this;
    }

    /**
     *
     */
    public String getNmsLayer() {
        return nmsLayer;
    }

    public ServiceRTO setNmsLayer(String nmsLayer) {
        this.nmsLayer = nmsLayer;
        return this;
    }

    /**
     *
     */
    public String getNmsPayloadCLFI() {
        return nmsPayloadCLFI;
    }

    public ServiceRTO setNmsPayloadCLFI(String nmsPayloadCLFI) {
        this.nmsPayloadCLFI = nmsPayloadCLFI;
        return this;
    }

    /**
     *
     */
    public Long getNmsProjectId() {
        return nmsProjectId;
    }

    public ServiceRTO setNmsProjectId(Long nmsProjectId) {
        this.nmsProjectId = nmsProjectId;
        return this;
    }

    /**
     *
     */
    public Integer getNmsVlanId() {
        return nmsVlanId;
    }

    public ServiceRTO setNmsVlanId(Integer nmsVlanId) {
        this.nmsVlanId = nmsVlanId;
        return this;
    }

    /**
     *
     */
    public String getNmsTransportType() {
        return nmsTransportType;
    }

    public ServiceRTO setNmsTransportType(String nmsTransportType) {
        this.nmsTransportType = nmsTransportType;
        return this;
    }

    /**
     *
     */
    public String getNmsCorrelationMode() {
        return nmsCorrelationMode;
    }

    public ServiceRTO setNmsCorrelationMode(String nmsCorrelationMode) {
        this.nmsCorrelationMode = nmsCorrelationMode;
        return this;
    }

    /**
     *
     */
    public String getNmsAlarmMask() {
        return nmsAlarmMask;
    }

    public ServiceRTO setNmsAlarmMask(String nmsAlarmMask) {
        this.nmsAlarmMask = nmsAlarmMask;
        return this;
    }

    /**
     *
     */
    public String getNmsAcknowledgedBy() {
        return nmsAcknowledgedBy;
    }

    public ServiceRTO setNmsAcknowledgedBy(String nmsAcknowledgedBy) {
        this.nmsAcknowledgedBy = nmsAcknowledgedBy;
        return this;
    }

    /**
     *
     */
    public Long getNmsAcknowledgedTime() {
        return nmsAcknowledgedTime;
    }

    public ServiceRTO setNmsAcknowledgedTime(Long nmsAcknowledgedTime) {
        this.nmsAcknowledgedTime = nmsAcknowledgedTime;
        return this;
    }

    /**
     *
     */
    public Long getNmsCommonContainerId() {
        return nmsCommonContainerId;
    }

    public ServiceRTO setNmsCommonContainerId(Long nmsCommonContainerId) {
        this.nmsCommonContainerId = nmsCommonContainerId;
        return this;
    }

    /**
     *
     */
    public Float getNmsOccupancyAz() {
        return nmsOccupancyAz;
    }

    public ServiceRTO setNmsOccupancyAz(Float nmsOccupancyAz) {
        this.nmsOccupancyAz = nmsOccupancyAz;
        return this;
    }

    /**
     *
     */
    public Float getNmsOccupancyZa() {
        return nmsOccupancyZa;
    }

    public ServiceRTO setNmsOccupancyZa(Float nmsOccupancyZa) {
        this.nmsOccupancyZa = nmsOccupancyZa;
        return this;
    }

    /**
     *
     */
    public Long getOifId() {
        return oifId;
    }

    public ServiceRTO setOifId(Long oifId) {
        this.oifId = oifId;
        return this;
    }

    /**
     *
     */
    public Long getOifDomainId() {
        return oifDomainId;
    }

    public ServiceRTO setOifDomainId(Long oifDomainId) {
        this.oifDomainId = oifDomainId;
        return this;
    }

    /**
     *
     */
    public String getOifPathRequestId() {
        return oifPathRequestId;
    }

    public ServiceRTO setOifPathRequestId(String oifPathRequestId) {
        this.oifPathRequestId = oifPathRequestId;
        return this;
    }

    /**
     *
     */
    public TrafficParamRTO getOifTrafficParams() {
        return oifTrafficParams;
    }

    public ServiceRTO setOifTrafficParams( TrafficParamRTO oifTrafficParams ) {
        this.oifTrafficParams = oifTrafficParams;
        return this;
    }

    /**
     *
     */
    public String getOifAdminStatus() {
        return oifAdminStatus;
    }

    public ServiceRTO setOifAdminStatus(String oifAdminStatus) {
        this.oifAdminStatus = oifAdminStatus;
        return this;
    }

    /**
     *
     */
    public String getOifCallOperStatus() {

        return oifCallOperStatus;
    }

    public ServiceRTO setOifCallOperStatus( String oifCallOperStatus ) {

        this.oifCallOperStatus = oifCallOperStatus;
        return this;
    }

    /**
     *
     */
    public String getOifCallProvisioningStatus() {
        return oifCallProvisioningStatus;
    }

    public ServiceRTO setOifCallProvisioningStatus(String oifCallProvisioningStatus) {
        this.oifCallProvisioningStatus = oifCallProvisioningStatus;
        return this;
    }

    /**
     *
     */
    public String getOifCallConfigStatus() {
        return oifCallConfigStatus;
    }

    public ServiceRTO setOifCallConfigStatus(String oifCallConfigStatus) {
        this.oifCallConfigStatus = oifCallConfigStatus;
        return this;
    }

    /**
     *
     */
    public String getOifNetworkSyncStatus() {
        return oifNetworkSyncStatus;
    }

    public ServiceRTO setOifNetworkSyncStatus(String oifNetworkSyncStatus) {
        this.oifNetworkSyncStatus = oifNetworkSyncStatus;
        return this;
    }

    /**
     *
     */
    public Integer getOifCallLatency() {
        return oifCallLatency;
    }

    public ServiceRTO setOifCallLatency(Integer oifCallLatency) {
        this.oifCallLatency = oifCallLatency;
        return this;
    }

    /**
     *
     */
    public RoutingFailureDetailRTO getRoutingFailureDetail() {
        return routingFailureDetail;
    }

    public ServiceRTO setRoutingFailureDetail(RoutingFailureDetailRTO routingFailureDetail) {
        this.routingFailureDetail = routingFailureDetail;
        return this;
    }

    /**
     *
     */
    public Integer getOifSwitchingType() {
        return oifSwitchingType;
    }

    public ServiceRTO setOifSwitchingType(Integer oifSwitchingType) {
        this.oifSwitchingType = oifSwitchingType;
        return this;
    }

    /**
     *
     */
    public Integer getOifEncoding() {
        return oifEncoding;
    }

    public ServiceRTO setOifEncoding(Integer oifEncoding) {
        this.oifEncoding = oifEncoding;
        return this;
    }

    /**
     *
     */
    public String getOifDirectionality() {
        return oifDirectionality;
    }

    public ServiceRTO setOifDirectionality(String oifDirectionality) {
        this.oifDirectionality = oifDirectionality;
        return this;
    }

    /**
     *
     */
    public List<EdgeRTO> getOifPath() {
        return oifPath;
    }

    public ServiceRTO setOifPath( List<EdgeRTO> oifPath ) {

        this.oifPath = new ArrayList<>( oifPath );
        return this;
    }

    /**
     *
     */
    public List<Long> getOifServiceLatency() {
        return oifServiceLatency;
    }

    public ServiceRTO setOifServiceLatency( List<Long> oifServiceLatency ) {

        this.oifServiceLatency = new ArrayList<>( oifServiceLatency );
        return this;
    }

    /**
     *
     */
    public Boolean getOifRoutingOverExistingServicesOnly() {
        return oifRoutingOverExistingServicesOnly;
    }

    public ServiceRTO setOifRoutingOverExistingServicesOnly(Boolean oifRoutingOverExistingServicesOnly) {
        this.oifRoutingOverExistingServicesOnly = oifRoutingOverExistingServicesOnly;
        return this;
    }

    /**
     *
     */
    public Boolean getOifRoutingOverEnabledResourcesOnly() {
        return oifRoutingOverEnabledResourcesOnly;
    }

    public ServiceRTO setOifRoutingOverEnabledResourcesOnly(Boolean oifRoutingOverEnabledResourcesOnly) {
        this.oifRoutingOverEnabledResourcesOnly = oifRoutingOverEnabledResourcesOnly;
        return this;
    }

    /**
     *
     */
    public Boolean getOifRoutingOverNotReservedResourcesOnly() {
        return oifRoutingOverNotReservedResourcesOnly;
    }

    public ServiceRTO setOifRoutingOverNotReservedResourcesOnly(Boolean oifRoutingOverNotReservedResourcesOnly) {
        this.oifRoutingOverNotReservedResourcesOnly = oifRoutingOverNotReservedResourcesOnly;
        return this;
    }

    /**
     *
     */
    public String getOifOrderNumber() {
        return oifOrderNumber;
    }

    public ServiceRTO setOifOrderNumber(String oifOrderNumber) {
        this.oifOrderNumber = oifOrderNumber;
        return this;
    }

    /**
     *
     */
    public SLARTO getOifSla() {
        return oifSla;
    }

    public ServiceRTO setOifSla( SLARTO oifSla ) {
        this.oifSla = oifSla;
        return this;
    }

    /**
     *
     */
    public List<SrgDetailRTO> getOifSrgDetails() {
        return oifSrgDetails;
    }

    public ServiceRTO setOifSrgDetails( List<SrgDetailRTO> oifSrgDetails ) {

        this.oifSrgDetails = new ArrayList<>( oifSrgDetails );
        return this;
    }

    /**
     *
     */
    public Boolean getOifRestorable() {
        return oifRestorable;
    }

    public ServiceRTO setOifRestorable(Boolean oifRestorable) {
        this.oifRestorable = oifRestorable;
        return this;
    }

    public EndpointRTO getOifAEnd() {
        return oifAEnd;
    }

    public ServiceRTO setOifAEnd(EndpointRTO oifAEnd) {
        this.oifAEnd = oifAEnd;
        return this;
    }

    public EndpointRTO getOifZEnd() {
        return oifZEnd;
    }

    public ServiceRTO setOifZEnd(EndpointRTO oifZEnd) {
        this.oifZEnd = oifZEnd;
        return this;
    }


    public String getProvisioningState() {
        return provisioningState;
    }

    public ServiceRTO setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
        return this;
    }

    @JsonProperty( "operationalState" )
    @XmlAttribute( name = "operationalState" )
    public String getOperationalState() {
        if ( getNmsOperationalState() == null || getNmsOperationalState().isEmpty() ) {
            return null;
        }

        switch ( OperationalState.valueOf( getNmsOperationalState() ) ) {
            case ENABLED:
            case PROTECTION_DISTURBED:
            case SERVER_DISTURBED:
            case DEGRADED:
                return "Up";

            default:
                return "Down";
        }
    }

    public List<ConnectionRTO> getOifConnections() { return oifConnections; }

    public ServiceRTO setOifConnections( List<ConnectionRTO> oifConnections) {
        this.oifConnections = new ArrayList<>(oifConnections);
        return this;
    }

    public List<ProtectionGroupRTO> getOifProtectionGroups() { return oifProtectionGroups; }

    public ServiceRTO setOifProtectionGroups( List<ProtectionGroupRTO> oifProtectionGroups ) {

        this.oifProtectionGroups = oifProtectionGroups;
        return this;
    }

    @JsonProperty( "dataSource" )
    @XmlAttribute( name = "dataSource" )
    public String getDataSource() {

        if ( oifId == null ) {

            if ( nmsId == null ) {

                return null;
            }

            return DataSource.NMS.getName();
        }

        if ( nmsId == null ) {

            return DataSource.SDN.getName();
        }

        return DataSource.TC.getName();
    }

    public ServiceRTO setDataSource( String dataSource ) {

        return this;
    }

    /**
     *
     */
    public PacketServiceRTO getPacketService() {
        return packetService;
    }

    /**
     *
     * @param packetService
     * @return
     */
    public ServiceRTO setPacketService(PacketServiceRTO packetService) {
        this.packetService = packetService;
        return this;
    }

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        ServiceRTO that = (ServiceRTO) o;
        return Objects.equals( domain, that.domain ) &&
               Objects.equals( name, that.name ) &&
               Objects.equals( provisioningState, that.provisioningState ) &&
               Objects.equals( nmsId, that.nmsId ) &&
               Objects.equals( nmsPathType, that.nmsPathType ) &&
               Objects.equals( nmsPathSubType, that.nmsPathSubType ) &&
               Objects.equals( nmsPathStatus, that.nmsPathStatus ) &&
               Objects.equals( nmsServiceName, that.nmsServiceName ) &&
               Objects.equals( nmsSubscriberName, that.nmsSubscriberName ) &&
               Objects.equals( nmsAlarmSeverity, that.nmsAlarmSeverity ) &&
               Objects.equals( nmsOperationalState, that.nmsOperationalState ) &&
               Objects.equals( nmsAdministrativeState, that.nmsAdministrativeState ) &&
               Objects.equals( nmsActualCreationState, that.nmsActualCreationState ) &&
               Objects.equals( nmsRequiredCreationState, that.nmsRequiredCreationState ) &&
               Objects.equals( nmsManagedState, that.nmsManagedState ) &&
               Objects.equals( nmsType, that.nmsType ) &&
               Objects.equals( nmsANode, that.nmsANode ) &&
               Objects.equals( nmsZNode, that.nmsZNode ) &&
               Objects.equals( nmsProtection, that.nmsProtection ) &&
               Objects.equals( nmsBandwidth, that.nmsBandwidth ) &&
               Objects.equals( nmsDescription, that.nmsDescription ) &&
               Objects.equals( nmsActiveRoute, that.nmsActiveRoute ) &&
               Objects.equals( nmsConnectionClass, that.nmsConnectionClass ) &&
               Objects.equals( nmsRouteState, that.nmsRouteState ) &&
               Objects.equals( nmsCreatedBy, that.nmsCreatedBy ) &&
               Objects.equals( nmsDirection, that.nmsDirection ) &&
               Objects.equals( nmsNumberOfNes, that.nmsNumberOfNes ) &&
               Objects.equals( nmsAPtpTp, that.nmsAPtpTp ) &&
               Objects.equals( nmsZPtpTp, that.nmsZPtpTp ) &&
               Objects.equals( nmsTpConfiguration, that.nmsTpConfiguration ) &&
               Objects.equals( nmsLastDisabledTime, that.nmsLastDisabledTime ) &&
               Objects.equals( nmsLayer, that.nmsLayer ) &&
               Objects.equals( nmsPayloadCLFI, that.nmsPayloadCLFI ) &&
               Objects.equals( nmsProjectId, that.nmsProjectId ) &&
               Objects.equals( nmsVlanId, that.nmsVlanId ) &&
               Objects.equals( nmsTransportType, that.nmsTransportType ) &&
               Objects.equals( nmsCorrelationMode, that.nmsCorrelationMode ) &&
               Objects.equals( nmsAlarmMask, that.nmsAlarmMask ) &&
               Objects.equals( nmsAcknowledgedBy, that.nmsAcknowledgedBy ) &&
               Objects.equals( nmsAcknowledgedTime, that.nmsAcknowledgedTime ) &&
               Objects.equals( nmsCommonContainerId, that.nmsCommonContainerId ) &&
               Objects.equals( nmsOccupancyAz, that.nmsOccupancyAz ) &&
               Objects.equals( nmsOccupancyZa, that.nmsOccupancyZa ) &&
               Objects.equals( oifId, that.oifId ) &&
               Objects.equals( oifDomainId, that.oifDomainId ) &&
               Objects.equals( oifPathRequestId, that.oifPathRequestId ) &&
               Objects.equals( oifTrafficParams, that.oifTrafficParams ) &&
               Objects.equals( oifAdminStatus, that.oifAdminStatus ) &&
               Objects.equals( oifCallOperStatus, that.oifCallOperStatus ) &&
               Objects.equals( oifCallProvisioningStatus, that.oifCallProvisioningStatus ) &&
               Objects.equals( oifCallConfigStatus, that.oifCallConfigStatus ) &&
               Objects.equals( oifNetworkSyncStatus, that.oifNetworkSyncStatus ) &&
               Objects.equals( oifCallLatency, that.oifCallLatency ) &&
               Objects.equals( routingFailureDetail, that.routingFailureDetail ) &&
               Objects.equals( oifSwitchingType, that.oifSwitchingType ) &&
               Objects.equals( oifEncoding, that.oifEncoding ) &&
               Objects.equals( oifDirectionality, that.oifDirectionality ) &&
               Objects.equals( oifPath, that.oifPath ) &&
               Objects.equals( oifServiceLatency, that.oifServiceLatency ) &&
               Objects.equals( oifRoutingOverExistingServicesOnly, that.oifRoutingOverExistingServicesOnly ) &&
               Objects.equals( oifRoutingOverEnabledResourcesOnly, that.oifRoutingOverEnabledResourcesOnly ) &&
               Objects.equals( oifRoutingOverNotReservedResourcesOnly, that.oifRoutingOverNotReservedResourcesOnly ) &&
               Objects.equals( oifOrderNumber, that.oifOrderNumber ) &&
               Objects.equals( oifSla, that.oifSla ) &&
               Objects.equals( oifSrgDetails, that.oifSrgDetails ) &&
               Objects.equals( oifRestorable, that.oifRestorable ) &&
               Objects.equals( oifAEnd, that.oifAEnd ) &&
               Objects.equals( oifZEnd, that.oifZEnd ) &&
               Objects.equals( oifConnections, that.oifConnections ) &&
               Objects.equals( oifProtectionGroups, that.oifProtectionGroups );
    }

    @Override
    public int hashCode() {
        return Objects.hash( domain, name, provisioningState, nmsId, nmsPathType, nmsPathSubType, nmsPathStatus, nmsServiceName, nmsSubscriberName, nmsAlarmSeverity, nmsOperationalState, nmsAdministrativeState, nmsActualCreationState, nmsRequiredCreationState, nmsManagedState, nmsType, nmsANode, nmsZNode, nmsProtection, nmsBandwidth, nmsDescription, nmsActiveRoute, nmsConnectionClass, nmsRouteState, nmsCreatedBy, nmsDirection, nmsNumberOfNes, nmsAPtpTp, nmsZPtpTp, nmsTpConfiguration, nmsLastDisabledTime, nmsLayer, nmsPayloadCLFI, nmsProjectId, nmsVlanId, nmsTransportType, nmsCorrelationMode, nmsAlarmMask, nmsAcknowledgedBy, nmsAcknowledgedTime, nmsCommonContainerId, nmsOccupancyAz, nmsOccupancyZa, oifId, oifDomainId, oifPathRequestId, oifTrafficParams, oifAdminStatus, oifCallOperStatus, oifCallProvisioningStatus, oifCallConfigStatus, oifNetworkSyncStatus, oifCallLatency, routingFailureDetail, oifSwitchingType, oifEncoding, oifDirectionality, oifPath, oifServiceLatency, oifRoutingOverExistingServicesOnly, oifRoutingOverEnabledResourcesOnly, oifRoutingOverNotReservedResourcesOnly, oifOrderNumber, oifSla, oifSrgDetails, oifRestorable, oifAEnd, oifZEnd, oifConnections, oifProtectionGroups );
    }

    public static final String NEW_LINE = "\n";

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(NEW_LINE);
        builder.append("SERVICE ");
        appendString(builder, "Name", this.name);
        return builder.toString();
    }


    /**
     *
     * @param builder
     * @param label
     * @param object
     */
    public void appendString(StringBuilder builder, String label, Object object) {
        if(object != null) {
            builder.append(NEW_LINE);
            builder.append("            ");
            builder.append(label);
            builder.append(" :: ");
            builder.append(object.toString());
        }
    }
}