package com.ossnms.web.api.orchestration.service.api.service;

import com.ossnms.web.api.orchestration.common.api.resources.inbound.DetailsParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.FilterParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.PageParameter;
import com.ossnms.web.api.orchestration.common.api.resources.inbound.SortParameter;
import com.ossnms.web.api.orchestration.service.api.model.ServiceRTO;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.ossnms.web.api.orchestration.common.constant.OrchestrationConstants.URL_SERVICE;
import static com.ossnms.web.api.orchestration.common.constant.Permissions.PERMISSION_CARRIER_ACCESS;
import static com.ossnms.web.api.orchestration.common.constant.Permissions.PERMISSION_CUSTOMER_ACCESS;

/**
 *
 */
@Path( URL_SERVICE )
@Consumes( { MediaType.APPLICATION_JSON } )
@Produces( { MediaType.APPLICATION_JSON } )
public interface ServiceManagementService {

   /**
    * @return
    */
   @GET
   @RolesAllowed( { PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS } )
   @PermitAll
   Response get( @BeanParam DetailsParameter detailsParameter,
                 @BeanParam PageParameter pageParameter,
                 @BeanParam SortParameter sortParameter,
                 @BeanParam FilterParameter filterParameter );

   /**
    * @param id
    * @return
    */
   @GET
   @RolesAllowed( { PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS } )
   @Path( "/{id}" )
   Response get( @PathParam( "id" ) String id );

   /**
    * @return
    */
   @POST
   @RolesAllowed( { PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS } )
   @Path( "" )
   Response add(ServiceRTO serviceRTO);

   /**
    * @param id
    * @return
    */
   @PUT
   @RolesAllowed( { PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS } )
   @Path( "/{id}" )
   Response update( @PathParam( "id" ) String id, ServiceRTO serviceRTO);

   /**
    * @param id
    */
   @DELETE
   @RolesAllowed( { PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS } )
   @Path( "/{id}" )
   Response delete( @PathParam( "id" ) String id );

   @GET
   @RolesAllowed( { PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS } )
   @Path("/{id}/alarms")
   Response getAlarms(@BeanParam PageParameter pageParameter,
                      @BeanParam SortParameter sortParameter,
                      @BeanParam FilterParameter filterParameter,
                      @PathParam( "id" ) String id);

   /**
    * @param id
    * @return
    */
   @POST
   @RolesAllowed( { PERMISSION_CARRIER_ACCESS, PERMISSION_CUSTOMER_ACCESS } )
   @Path( "/{id}/enforce" )
   Response enforce( @PathParam( "id" ) String id );
}