package com.ossnms.web.api.orchestration.service.api.exception;

/**
 *
 */
public class ServiceConflictException extends ServiceProviderException {

    private static final long serialVersionUID = 8461990549126530417L;

    public ServiceConflictException() {
    }

    public ServiceConflictException(String message) {
        super(message);
    }

    public ServiceConflictException(String message, Throwable cause) {
        super(message, cause);
    }

    public ServiceConflictException(Throwable cause) {
        super(cause);
    }

    public ServiceConflictException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
