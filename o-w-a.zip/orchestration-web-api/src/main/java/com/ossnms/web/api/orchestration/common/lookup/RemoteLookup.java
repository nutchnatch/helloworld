package com.ossnms.web.api.orchestration.common.lookup;

import com.ossnms.web.provider.security.operations.domain.SecurityDomainOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.inject.Produces;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties;

/**
 *
 */
public class RemoteLookup {

    private static final Logger LOGGER = LoggerFactory.getLogger(RemoteLookup.class);

    private static final String SECURITY_MANAGER_BEAN_LOOKUP = "ejb:bicnet/securitymgmt/%s!%s";

    /**
     *
     * @return
     */
    @Produces
    private SecurityDomainOperations getSecurityDomainOperations(){
        return getBean(SecurityDomainOperations.class, SECURITY_MANAGER_BEAN_LOOKUP);
    }

    /**
     *
     * @param type
     * @param <E>
     * @return
     */
    @SuppressWarnings("unchecked")
    private <E> E getBean(Class<E> type, String lookup) {
        try {
            String name = String.format(lookup, type.getSimpleName(), type.getCanonicalName());
            return (E) getContext().lookup(name);
        } catch (NamingException e) {
            LOGGER.warn("Could not reach remote bean. Falling back to local lookup");
        }

        try{
            return (E) getContext().lookup(type.getSimpleName());
        } catch (NamingException e) {
            LOGGER.warn("Could not reach local bean. Lookup fails.");
        }

        return null;
    }

    /**
     *
     * @return
     * @throws NamingException
     */
    private Context getContext() throws NamingException{
        final Properties props = new Properties();
        props.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
        // create the InitialString
        return new InitialContext(props);
    }

}
