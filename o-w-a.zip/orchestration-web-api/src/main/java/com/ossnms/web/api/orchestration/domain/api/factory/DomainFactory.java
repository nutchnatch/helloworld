package com.ossnms.web.api.orchestration.domain.api.factory;

import com.ossnms.web.api.orchestration.common.api.DataSource;
import com.ossnms.web.api.orchestration.domain.api.model.DomainRTO;
import com.ossnms.web.provider.network.model.container.Container;
import com.ossnms.web.provider.network.model.container.ContainerInfo;
import com.ossnms.web.provider.network.model.container.ContainerSummary;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;

/**
 *
 */
public final class DomainFactory {

    public static final String SDN_PROVIDER_DOMAIN_ID = "1";
    public static final String SDN_PROVIDER_DOMAIN_NAME = "PROVIDER";
    public static final String SDN_PROVIDER_DOMAIN_TOPOLOGY = "FULL";
    public static final String DATA_SOURCE_SDN = "SDN";
    public static final String DATA_SOURCE_NMS = "NMS";

    private final DomainRTO domainRTO;

    /**
     *
     */
    public DomainFactory() {
        this.domainRTO = new DomainRTO();
    }

    /**
     *
     * @param domainRTO
     */
    public DomainFactory(DomainRTO domainRTO) {
        this.domainRTO = domainRTO;
    }

    /**
     *
     * @param id
     * @param name
     * @param dataSource
     * @return
     */
    public DomainFactory from(String id, String name, DataSource dataSource) {
       this.domainRTO.setId(id);
       this.domainRTO.setName(name);
       this.domainRTO.setDataSource(dataSource.getName());
       return this;
    }


   /**
     *
     * @param summary
     * @return
     */
    public DomainFactory from(NetworkSummary summary) {
        if(summary != null) {
            if(domainRTO.getDataSource() == null) {
                domainRTO.setId(summary.getID().getID());
                domainRTO.setDataSource(DataSource.SDN.getName());
            }else if(DATA_SOURCE_NMS.equals(domainRTO.getDataSource())) {
                domainRTO.setDataSource(DataSource.TC.getName());
            }

            if(domainRTO.getId().equals(SDN_PROVIDER_DOMAIN_ID)) {
                domainRTO.setName(SDN_PROVIDER_DOMAIN_NAME);
                domainRTO.setOifTopologyType(SDN_PROVIDER_DOMAIN_TOPOLOGY);
            } else {
                domainRTO.setName(summary.getName());
                domainRTO.setOifTopologyType(summary.getTopologyType());
            }

            domainRTO.setOifId(summary.getID().getID());
            domainRTO.setOifProtocols( summary.getProtocols() );
        }

        return this;
    }

    /**
     *
     * @param
     * @return
     */
    public DomainFactory from(Network network) {
        if(network != null) {
            from((NetworkSummary) network);

            domainRTO.setOifUserDomain( network.getUserDomain() );
            domainRTO.setOifAdminState( network.getAdminState() );
        }

        return this;
    }

    /**
     *
     * @param summary
     * @return
     */
    public DomainFactory from(ContainerSummary summary) {
        if(summary != null) {
            if(domainRTO.getDataSource() == null) {
                domainRTO.setDataSource(DataSource.NMS.getName());
            }else if(DATA_SOURCE_SDN.equals(domainRTO.getDataSource())) {
                domainRTO.setDataSource(DataSource.TC.getName());
            }

            domainRTO.setId(Long.toString(summary.getID().getId()));
            domainRTO.setNmsId(Long.toString(summary.getID().getId()));
        }
        return this;
    }

    /**
     *
     * @param
     * @return
     */
    public DomainFactory from(Container container) {
        from((ContainerSummary) container);

        domainRTO.setName(container.getName());
        domainRTO.setNmsServiceLevel(container.getServiceLevel());
        domainRTO.setNmsInfoAddress(container.getInfo().get(ContainerInfo.ADDRESS));
        domainRTO.setNmsInfoContactPerson(container.getInfo().get(ContainerInfo.CONTACT_PERSON));
        domainRTO.setNmsInfoEmail(container.getInfo().get(ContainerInfo.EMAIL));
        domainRTO.setNmsInfoURL(container.getInfo().get(ContainerInfo.URL));
        domainRTO.setNmsInfoExternalReference(container.getInfo().get(ContainerInfo.EXTERNAL_REFERENCE));
        domainRTO.setNmsInfoOrganization(container.getInfo().get(ContainerInfo.ORGANIZATION));
        domainRTO.setNmsInfoPhone(container.getInfo().get(ContainerInfo.PHONE));
        domainRTO.setNmsDescription(container.getInfo().get(ContainerInfo.DESCRIPTION));
        domainRTO.setNmsInfoFax(container.getInfo().get(ContainerInfo.FAX));

        return this;
    }

    /**
     *
     * @return
     */
    public DomainRTO build() {
        return domainRTO;
    }
}
