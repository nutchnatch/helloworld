
package com.bnppa.sesame.services.standard.proxy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="token" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="secretResponses" type="{http://proxy.standard.services.sesame.bnppa.com}ArrayOf_tns3_nillable_SecretResponse"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "token",
    "secretResponses"
})
@XmlRootElement(name = "setSecretResponses")
public class SetSecretResponses {

    @XmlElement(required = true, nillable = true)
    protected String token;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfTns3NillableSecretResponse secretResponses;

    /**
     * Gets the value of the token property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Sets the value of the token property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

    /**
     * Gets the value of the secretResponses property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTns3NillableSecretResponse }
     *     
     */
    public ArrayOfTns3NillableSecretResponse getSecretResponses() {
        return secretResponses;
    }

    /**
     * Sets the value of the secretResponses property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTns3NillableSecretResponse }
     *     
     */
    public void setSecretResponses(ArrayOfTns3NillableSecretResponse value) {
        this.secretResponses = value;
    }

}
