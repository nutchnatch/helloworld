@javax.xml.bind.annotation.XmlSchema(namespace = "http://model.common.services.sesame.bnppa.com")
package com.bnppa.sesame.services.common.model;
