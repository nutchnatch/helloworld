package com.bnpp.cardif.sesame.security.soap;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.util.StringUtils;

import com.bnpp.cardif.sesame.security.SesameWebServiceFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnppa.sesame.services.common.model.Joining;
import com.bnppa.sesame.services.common.model.UserIdentity;
import com.bnppa.sesame.services.standard.proxy.ArrayOfTns3NillableJoining;
import com.bnppa.sesame.services.standard.proxy.ArrayOfXsdNillableString;
import com.bnppa.sesame.services.standard.proxy.AuthorizationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.IdentityServicesWSP;
import com.bnppa.sesame.services.standard.proxy.InvalidParameterException;
import com.bnppa.sesame.services.standard.proxy.InvalidTokenException;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;

/**
 * Validate a sesame token and setup the corresponding user into security
 * context.
 * 
 * @author 831743
 *
 */
@Component
@Scope("singleton")
// default value specified to be obvious.
public class TokenValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(TokenValidator.class);

    @Value("${authentication-provider.appDomain}")
    private String appDomain;

    @Value("${authentication-provider.is-security-enabled}")
    private Boolean securityEnabled;

    private String joiningType = "SCOPE";

    @Autowired
    private SesameWebServiceFactory sesameWebServiceFactory;

    /**
     * Validate the token passed as a parameter. If validation if Ok, creates
     * the AuthenticatedUser object and set it into the security context.
     * 
     * @param tokenType
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public void validate(TokenType tokenType) throws TechnicalException, FunctionalException {
        if (tokenType == null || StringUtils.isEmpty(tokenType.getToken())) {
            throw new TechnicalException("Token not found!");
        }

        String tokenValue = tokenType.getToken();

        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        AuthenticatedUser authenticatedUser;
        if (isSecurityEnabled() != null && !isSecurityEnabled().booleanValue()) {
            LOGGER.debug("Security is not enable not performing check with Sesame");
            List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
            grantedAuthorities.add(new SimpleGrantedAuthority("Empty_Role"));
            authenticatedUser = new AuthenticatedUser("FakeUser", null, "FakeToken", "FakeUser", "", grantedAuthorities,
                    sesameWebServiceFactory.getCommercialVersion());
        }
        else {
            authenticatedUser = generateUser(tokenValue);
        }
        stopWatch.stop();
        // set user technical details
        authenticatedUser.setRequestId(UUID.randomUUID().toString());
        authenticatedUser.setTimeToSpentOnAuthentication(stopWatch.getTotalTimeMillis());
        // add user to the security context
        Authentication actualAuthentication = new UsernamePasswordAuthenticationToken(authenticatedUser, null,
                authenticatedUser.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(actualAuthentication);
        LOGGER.debug("Security context has been set with token={} for Backend", tokenValue);
    }

    private AuthenticatedUser generateUser(String tokenValue) throws FunctionalException, TechnicalException {
        AuthenticatedUser authenticatedUser;
        // get user details
        UserIdentity userIdentity;
        String invalidToken1 = "The token ";
        String invalidToken2 = " is invalid";
        try {
            userIdentity = getUserIdentity(tokenValue);
        }
        catch (InvalidTokenException e) {
            throw new FunctionalException(invalidToken1 + tokenValue + invalidToken2, e);
        }
        catch (com.bnppa.sesame.services.standard.proxy.TechnicalException e) {
            throw new TechnicalException("Error in login", e);
        }
        // get user Roles
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        try {
            for (String authority : getAuthorities(tokenValue)) {
                grantedAuthorities.add(new SimpleGrantedAuthority(authority));
            }
        }
        catch (InvalidTokenException e) {
            throw new FunctionalException(invalidToken1 + tokenValue + invalidToken2, e);
        }
        catch (com.bnppa.sesame.services.standard.proxy.TechnicalException | InvalidParameterException e) {
            throw new TechnicalException("Error getting the user roles", e);
        }
        // get user joining
        ArrayOfTns3NillableJoining joiningList = null;
        try {
            joiningList = fetchUserJoinings(tokenValue);
        }
        catch (InvalidTokenException e) {
            throw new FunctionalException(invalidToken1 + tokenValue + invalidToken2, e);
        }
        catch (com.bnppa.sesame.services.standard.proxy.TechnicalException | InvalidParameterException e) {
            throw new TechnicalException("Error getting the user joining", e);
        }

        // Create the User
        authenticatedUser = new AuthenticatedUser(userIdentity.getLogin(), null, tokenValue,
                userIdentity.getFirstName(), userIdentity.getLastName(), grantedAuthorities,
                sesameWebServiceFactory.getCommercialVersion());
        // Add the Business Scope
        authenticatedUser.getBusinessScopes().addAll(getBusinessScopeJoining(joiningList));
        return authenticatedUser;
    }

    protected List<String> getBusinessScopeJoining(ArrayOfTns3NillableJoining joinings) {
        List<String> scopes = new ArrayList<>();
        for (Joining joining : joinings.getJoining()) {
            if (joining.getJoiningType().equals(getJoiningType())) {
                scopes.add(joining.getInterv());
            }
        }
        return scopes;
    }

    /**
     * Get the user Joinings
     * 
     * @param token
     * @return ArrayOfTns3NillableJoining
     * @throws com.bnppa.sesame.services.standard.proxy.TechnicalException
     * @throws InvalidParameterException
     * @throws InvalidTokenException
     */
    private ArrayOfTns3NillableJoining fetchUserJoinings(final String token) throws InvalidTokenException,
            InvalidParameterException, com.bnppa.sesame.services.standard.proxy.TechnicalException {
        AuthorizationServicesWSP authorizationServicesWSP = sesameWebServiceFactory.getAuthorizationServicesWSP();
        return authorizationServicesWSP.getJoinings(token, getAppDomain());
    }

    /**
     * Get the user details
     * 
     * @param token
     * @return UserIdentity
     * @throws InvalidTokenException
     * @throws com.bnppa.sesame.services.standard.proxy.TechnicalException
     * @throws TechnicalException
     */
    private UserIdentity getUserIdentity(final String token)
            throws InvalidTokenException, com.bnppa.sesame.services.standard.proxy.TechnicalException {
        IdentityServicesWSP identityServicesWSP = sesameWebServiceFactory.getIdentityServicesWSP();
        return identityServicesWSP.getUserIdentity(token);
    }

    /**
     * Get the user Roles
     * 
     * @param token
     * @return List<String>
     * @throws InvalidTokenException
     * @throws InvalidParameterException
     * @throws com.bnppa.sesame.services.standard.proxy.TechnicalException
     */
    public List<String> getAuthorities(String token) throws InvalidTokenException, InvalidParameterException,
            com.bnppa.sesame.services.standard.proxy.TechnicalException {
        LOGGER.debug("Server : Getting authorities to initialize security context, token={}", token);
        AuthorizationServicesWSP authorizationServicesWSP = sesameWebServiceFactory.getAuthorizationServicesWSP();
        ArrayOfXsdNillableString roles = authorizationServicesWSP.getRoles(token, appDomain);
        return roles.getString();
    }

    /**
     * @return the appDomain
     */
    public String getAppDomain() {
        return appDomain;
    }

    /**
     * @param appDomain
     *            the appDomain to set
     */
    public void setAppDomain(String appDomain) {
        this.appDomain = appDomain;
    }

    /**
     * @return the securityEnabled
     */
    public Boolean isSecurityEnabled() {
        return securityEnabled;
    }

    /**
     * @param securityEnabled
     *            the securityEnabled to set
     */
    public void setSecurityEnabled(Boolean securityEnabled) {
        this.securityEnabled = securityEnabled;
    }

    /**
     * @return the sesameWebServiceFactory
     */
    public SesameWebServiceFactory getSesameWebServiceFactory() {
        return sesameWebServiceFactory;
    }

    /**
     * @param sesameWebServiceFactory
     *            the sesameWebServiceFactory to set
     */
    public void setSesameWebServiceFactory(SesameWebServiceFactory sesameWebServiceFactory) {
        this.sesameWebServiceFactory = sesameWebServiceFactory;
    }

    public String getJoiningType() {
        return joiningType;
    }

    public void setJoiningType(String joiningType) {
        this.joiningType = joiningType;
    }

    public Boolean getSecurityEnabled() {
        return securityEnabled;
    }

}