package com.bnpp.cardif.sesame.security.soap;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;

import java.util.Optional;

/**
 * Create a token type object with the user associated token.
 * 
 * @author Andre Macedo
 */
public class TokenCreator {
    
    private TokenCreator() {
        // private empty constructor to avoid instance creation.
    }
    
    /**
     * Get a token type to be inject in the web service.
     * 
     * @return
     */
    public static TokenType getTokenType() {
        TokenType tokenType = null;

        String token = getToken();
        if (token != null) {
            tokenType = new TokenType();
            tokenType.setToken(token);
        }

        return tokenType;
    }

    /**
     * Get user token authentication token.
     * 
     * @return the token to get
     */
    public static String getToken() {
        String token = null;

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {
            AuthenticatedUser springAuthenticatedUser = (AuthenticatedUser) authentication.getPrincipal();
            token = springAuthenticatedUser.getToken();
        }

        return token;
    }

    private static AuthenticatedUser getAuthenticateUser() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (AuthenticatedUser) Optional.ofNullable(authentication.getPrincipal()).orElse(null);
    }

    public static String getUsername() {

        return Optional.ofNullable(getAuthenticateUser().getUsername()).orElse(null);
    }
}